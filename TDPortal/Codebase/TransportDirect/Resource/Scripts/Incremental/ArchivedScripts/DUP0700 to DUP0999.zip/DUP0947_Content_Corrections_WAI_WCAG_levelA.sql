-- ***********************************************
-- NAME 		: DUP0947_Content_Corrections_WAI_WCAG_levelA.sql
-- DESCRIPTION 	: Script to update content to correct faults found in WAI audit post Del 10.1
-- AUTHOR		: Rich Broddle
-- DATE			: 05 June 2008
-- ************************************************

USE [Content]
GO


EXEC AddtblContent 1, 1, 'langStrings', 'HomePlanAJourney.imageFindCoachSkipLink.AlternateText', 'Skip to Find a coach', 'Neidiwch i Canfyddwch fws'

EXEC AddtblContent 1, 1, 'langStrings', 'HomePlanAJourney.imageFindBusSkipLink.AlternateText', 'Skip to Find a bus', 'Neidiwch i Canfyddwch fws'

EXEC AddtblContent 1, 1, 'langStrings', 'HomePlanAJourney.imageFindCarParkSkipLink.AlternateText', 'Skip to Find a car park', 'cy Skip to Find a car park'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 947
SET @ScriptDesc = 'Script to correct WAI WCAG levelA faults'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO