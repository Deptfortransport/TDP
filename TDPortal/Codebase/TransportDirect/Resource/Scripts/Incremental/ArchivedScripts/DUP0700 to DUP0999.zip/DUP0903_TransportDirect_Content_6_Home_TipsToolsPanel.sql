-- ***********************************************
-- NAME 		: DUP0903_TransportDirect_Content_6_Home_TipsToolsPanel.sql
-- DESCRIPTION 		: Script to add the list items in the Tips and Tools panel
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 Apr 2008 15:00:00
-- ************************************************

USE [Content]
GO


DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')


-- Tips and Tools panel on homepage
EXEC AddtblContent
1, @GroupId, 'TDTipsHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<DIV class="Column2Header">  <H1><SPAN class="txtsevenbwl">Tips and tools</SPAN></H1><A class="txtsevenbwrlink" title="Go to Tips and tools page" href="/Web2/Tools/Home.aspx">More... </A><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV></DIV>  <DIV class="Column2Content2">  <TABLE class="TipsToolsTable" cellSpacing="5" summary="">  <TBODY>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx"><IMG title="Check journey CO2" height="30" alt="Check CO2 emissions" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Co2_30x30.gif" width="30"></A></TD>  <TD><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check CO2 emissions</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/Tools/BusinessLinks.aspx"><IMG title="Business Links" height="30" alt="Business Links" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70.gif" width="30"></A></TD>  <TD><A href="/Web2/Tools/BusinessLinks.aspx">Add Transport Direct to your website for free</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/Tools/ToolbarDownload.aspx"><IMG title="Toolbar download" height="30" alt="Toolbar download" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Toolbox30.gif" width="30"></A></TD>  <TD><A href="/Web2/Tools/ToolbarDownload.aspx">Speed up your travel searches with our free toolbar</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/TDOnTheMove/TDOnTheMove.aspx"><IMG title="Services available on your mobile" height="30" alt="Services available on your mobile" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif" width="30"></A></TD>  <TD><A href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Get live departures on your mobile</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/Tools/Home.aspx#digitvinfo"><IMG title="Digital TV" height="30" alt="Digital TV" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/DigiTV_30x30.gif" width="30"></A></TD>  <TD><A href="/Web2/Tools/Home.aspx#digitvinfo">Get live departures through Digital TV</A></TD></TR></TBODY></TABLE></DIV>'
, '<DIV class="Column2Header">  <H1><SPAN class="txtsevenbwl">Awgrymiadau a theclynnau</SPAN></H1><A class="txtsevenbwrlink" title="Ewch i''r dudalen Awgrymiadau a thedynnau" href="/Web2/Tools/Home.aspx">Mwy... </A><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV></DIV>  <DIV class="Column2Content2">  <TABLE class="TipsToolsTable" cellSpacing="5" summary="">  <TBODY>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx"><IMG title="Mesur CO2 y siwrnai" height="30" alt="Mesur CO2 y siwrnai" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/Co2_30x30.gif" width="30"></A></TD>  <TD><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Mesur CO2 y siwrnai</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/Tools/BusinessLinks.aspx"><IMG title="Cysylltiadau Busnes" height="30" alt="Cysylltiadau Busnes" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70.gif" width="30"></A></TD>  <TD><A href="/Web2/Tools/BusinessLinks.aspx">Ychwanegwch Transport Direct at eich gwefan am ddim</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/Tools/ToolbarDownload.aspx"><IMG title="Lawrlwythwch y Bar Offer" height="30" alt="Lawrlwythwch y Bar Offer" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Toolbox30.gif" width="30"></A></TD>  <TD><A href="/Web2/Tools/ToolbarDownload.aspx">Cyflymwch eich chwiliadau teithio gyda''n bar offer am ddim</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/TDOnTheMove/TDOnTheMove.aspx"><IMG title="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" height="30" alt="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif" width="30"></A></TD>  <TD><A href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Derbyniwch ymadawiadau byw ar eich ff&#244;n symudol</A></TD></TR>  <TR>  <TD class="TipsToolsIconPadding"><A href="/Web2/Tools/Home.aspx#digitvinfo"><IMG title="Digital TV" height="30" alt="Digital TV" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/DigiTV_30x30.gif" width="30"></A></TD>  <TD><A href="/Web2/Tools/Home.aspx#digitvinfo">Get live departures through Digital TV</A></TD></TR></TBODY></TABLE></DIV>'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 903
SET @ScriptDesc = 'Script to add Homepage Tips and Tools panel list items'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO