-- ***********************************************
-- NAME 		: DUP0926_RepeatVisitor_Reporting_Tables.sql
-- DESCRIPTION 		: Script to create new Repeat Visitor reporting tables
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 May 2008 18:00:00
-- ************************************************

USE [Reporting]
GO

----------------------------------------------------------------
-- RepeatVisitorType
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_RepeatVisitorEvents_RepeatVisitorType]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[RepeatVisitorEvents] DROP CONSTRAINT FK_RepeatVisitorEvents_RepeatVisitorType
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RepeatVisitorType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RepeatVisitorType]
GO

CREATE TABLE [dbo].[RepeatVisitorType] (
	[RVTID] [int] NOT NULL ,
	[RVTCode] [varchar] (50) NOT NULL ,
	[RVTDescription] [varchar] (50) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[RepeatVisitorType] WITH NOCHECK ADD 
	CONSTRAINT [PK_RepeatVisitorType] PRIMARY KEY  CLUSTERED 
	(
		[RVTID]
	)  ON [PRIMARY] 
GO


----------------------------------------------------------------
-- RepeatVisitorEvents
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RepeatVisitorEvents]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RepeatVisitorEvents]
GO

CREATE TABLE [dbo].[RepeatVisitorEvents] (
	[RVEDate] [datetime] NOT NULL ,
	[RVEHour] [tinyint] NOT NULL ,
	[RVEHourQuarter] [tinyint] NOT NULL ,
	[RVEWeekDay] [tinyint] NOT NULL ,
	[RVERVTID] [int] NOT NULL ,
	[RVEPartnerID] [int] NOT NULL ,
	[RVECount] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE  INDEX [IX_RepeatVisitorEvents] ON [dbo].[RepeatVisitorEvents]([RVEDate], [RVEHour], [RVEHourQuarter], [RVERVTID], [RVEPartnerID]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[RepeatVisitorEvents] ADD 
	CONSTRAINT [FK_RepeatVisitorEvents_RepeatVisitorType] FOREIGN KEY 
	(
		[RVERVTID]
	) REFERENCES [dbo].[RepeatVisitorType] (
		[RVTID]
	)
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 926
SET @ScriptDesc = 'Repeat Visitor - Reporting tables created'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO