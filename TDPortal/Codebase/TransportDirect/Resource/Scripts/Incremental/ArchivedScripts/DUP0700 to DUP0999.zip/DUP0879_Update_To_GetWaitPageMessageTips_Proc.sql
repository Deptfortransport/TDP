-- ************************************************************
-- NAME 		: DUP0879_Update_To_GetWaitPageMessageTips_Proc.sql
-- DESCRIPTION 	: GetWaitPageMessageTips stored Procedure update
-- AUTHOR		: apatel
-- ************************************************************
USE TransientPortal
GO



ALTER PROCEDURE GetWaitPageMessageTips
AS


SELECT
	WaitPageTipTextEn,
	WaitPageTipTextCy,
	WaitPageMessageTips.ThemeId
FROM 
	WaitPageMessageTips
INNER JOIN [PermanentPortal].[dbo].[Properties] prop
	ON WaitPageMessageTips.ThemeId = prop.ThemeId
WHERE prop.pName = 'CurrentWaitPageTipID' and waitPageTipId = prop.pvalue

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 879
SET @ScriptDesc = 'GetWaitPageMessageTips stored Procedure update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------