-- ***********************************************
-- NAME 		: DUP0987_ZonalAccessibility_DataNotification_Add_To_Properties_Table.sql
-- DESCRIPTION 		: Add Zonal Accessibility data notification to properties table
--			: 
-- AUTHOR		: Sanjeev Johal
-- ************************************************

Use PermanentPortal
go
--insert into properties table
IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.ZonalAccessibilityCatalogue.Database')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('DataServices.DataNotification.ZonalAccessibilityCatalogue.Database', 'TransientPortalDB', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.ZonalAccessibilityCatalogue.Tables')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('DataServices.DataNotification.ZonalAccessibilityCatalogue.Tables', 'ZonalAccessibilityLinks', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 987
SET @ScriptDesc = 'Add Zonal Accessibility data notification to properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------