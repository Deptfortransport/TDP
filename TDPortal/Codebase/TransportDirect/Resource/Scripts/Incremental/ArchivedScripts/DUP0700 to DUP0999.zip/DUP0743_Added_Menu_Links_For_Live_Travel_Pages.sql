-- ***********************************************
-- NAME 		: DUP0743_Added_Menu_Links_For_Live_Travel_Pages.sql
-- DESCRIPTION 	: Menu links for Live Travel pages
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

EXEC AddInternalSuggestionLink 
	NULL,
	'Live travel', 
	'LiveTravel', 
	'Live travel', 
	'Teithio byw', 
	'Live travel', 
	4000, 
	1, 
	'HomePageMenuLiveTravel', 
	'Links for expandable menu on the Live Travel pages.'
GO

EXEC AddInternalSuggestionLink 
	'LiveTravel/TravelNews', 
	'Live Travel News Page', 
	'LiveTravelNews', 
	'Live Travel News', 
	'Newyddion teithio byw', 
	'Live travel', 4010, 
	0, 
	'HomePageMenuLiveTravel', 
	'Links for expandable menu on the Live Travel pages.'
GO

EXEC AddInternalSuggestionLink 
	'LiveTravel/DepartureBoards.aspx', 
	'Departure boards', 
	'DepartureBoards', 
	'Departure boards', 
	'Byrddau cyrraedd a chychwyn', 
	'Live travel', 
	4020, 
	0, 
	'HomePageMenuLiveTravel', 
	'Links for expandable menu on the Live Travel pages.'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 743
SET @ScriptDesc = 'Menu links for Live Travel pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------