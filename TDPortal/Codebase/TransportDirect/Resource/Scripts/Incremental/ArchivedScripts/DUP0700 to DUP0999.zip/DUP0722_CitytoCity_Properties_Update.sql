-- ***********************************************
-- NAME 		: DUP0722_CitytoCity_Properties_Update.sql
-- DESCRIPTION 		: sql to update the default outward and return time properties for car 
-- 			: and public transport journeys in city to city
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [PermanentPortal]
GO

-------------------------------------------------------------------------
-- ADD PROPERTIES
-------------------------------------------------------------------------

-- Delete all occurances of the City to city time values
IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    (	'CityToCity.CarJourney.OutwardTime',
	'CityToCity.CarJourney.ReturnTime',
	'CityToCity.PublicJourney.StartTime',
	'CityToCity.PublicJourney.Interval'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    (	'CityToCity.CarJourney.OutwardTime',
	'CityToCity.CarJourney.ReturnTime',
	'CityToCity.PublicJourney.StartTime',
	'CityToCity.PublicJourney.Interval')
  END

-- Insert properties
-- Web properties
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.CarJourney.OutwardTime','0830','Web','UserPortal','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.CarJourney.ReturnTime','1630','Web','UserPortal','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.PublicJourney.StartTime','0600','Web','UserPortal','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.PublicJourney.Interval','22','Web','UserPortal','0')

-- TDRemotingHost properties
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.CarJourney.OutwardTime','0830','TDRemotingHost ','TDRemotingHost ','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.CarJourney.ReturnTime','1630','TDRemotingHost ','TDRemotingHost ','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.PublicJourney.StartTime','0600','TDRemotingHost ','TDRemotingHost ','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('CityToCity.PublicJourney.Interval','22','TDRemotingHost ','TDRemotingHost ','0')

GO

-------------------------------------------------------------------------
-- Delete, Add the Cars in City to City flag
-------------------------------------------------------------------------
IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    (	'JourneyControl.UseCarsInCityToCity'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    (	'JourneyControl.UseCarsInCityToCity')
  END

-- Insert properties
-- Web properties
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('JourneyControl.UseCarsInCityToCity','True','Web','UserPortal','0')

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 722
SET @ScriptDesc = 'City to city default journey times update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------