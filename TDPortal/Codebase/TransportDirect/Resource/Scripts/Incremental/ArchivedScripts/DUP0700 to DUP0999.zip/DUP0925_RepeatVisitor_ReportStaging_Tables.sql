-- ***********************************************
-- NAME 		: DUP0925_RepeatVisitor_ReportStaging_Tables.sql
-- DESCRIPTION 		: Script to create new Repeat Visitor reporting tables
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 May 2008 18:00:00
-- ************************************************

USE [ReportStagingDB]
GO


----------------------------------------------------------------
-- RepeatVisitorEvent
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RepeatVisitorEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RepeatVisitorEvent]
GO

CREATE TABLE [dbo].[RepeatVisitorEvent] (
	[Id] [bigint] IDENTITY (1, 1) NOT NULL ,
	[RepeatVistorType] [varchar] (20) NULL ,
	[LastVisited] [datetime] NULL ,
	[SessionIdOld] [varchar] (50) NULL ,
	[SessionIdNew] [varchar] (50) NULL ,
	[DomainName] [varchar] (100) NULL ,
	[UserAgent] [varchar] (200) NULL ,
	[ThemeId] [int] NULL ,
	[TimeLogged] [datetime] NULL 
) ON [PRIMARY]
GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 925
SET @ScriptDesc = 'Repeat Visitor - RepeatVisitorEvent table created'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO