-- ***********************************************
-- NAME 		: DUP0988_Add_AccessibilityURL_To_Properties_Table.sql
-- DESCRIPTION 		: Add Station Accessibility URL to properties table
--			: 
-- AUTHOR		: Sanjeev Johal
-- ************************************************

Use PermanentPortal
go
--insert into properties table
IF NOT EXISTS (SELECT * FROM properties WHERE (([pName] = 'locationinformation.accessibilityurl') AND ([AID] = 'Microsite')))
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('locationinformation.accessibilityurl', 'http://www.nationalrail.co.uk/stations/{0}/details.html#Accessibility', 'Microsite', 'UserPortal', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE (([pName] = 'locationinformation.accessibilityurl') AND ([AID] = 'Web')))
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('locationinformation.accessibilityurl', 'http://www.nationalrail.co.uk/stations/{0}/details.html#Accessibility', 'Web', 'UserPortal', 0, 1)
END
go



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 988
SET @ScriptDesc = 'Add Station Accessibility URL to properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------