-- ************************************************************
-- NAME 		: DUP0872_Delete_Content_From_Waitpagemessagetips_Table.sql
-- DESCRIPTION 	: Delete content with click details text from waitpagemessagetips table
-- AUTHOR		: apatel
-- ************************************************************
USE TransientPortal
GO

DELETE FROM waitpagemessagetips WHERE waitPagetiptexten like '%Click <b>''Details''</b>%'

GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 872
SET @ScriptDesc = 'Delete content with click details text from waitpagemessagetips table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------