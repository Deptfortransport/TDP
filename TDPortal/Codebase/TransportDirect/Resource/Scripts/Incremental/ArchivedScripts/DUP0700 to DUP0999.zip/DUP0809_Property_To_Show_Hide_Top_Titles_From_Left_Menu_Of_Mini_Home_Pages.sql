-- *************************************************************************************
-- NAME 		: DUP0809_Property_To_Show_Hide_Top_Titles_From_Left_Menu_Of_Mini_Home_Pages.sql
-- DESCRIPTION  : Property added to show or hide top headings in Left Menu Min home pages.
-- AUTHOR		: Amit Patel
-- *************************************************************************************


USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'ExpandableMenu.MiniHomePages.ShowHeading')
BEGIN
	insert into properties values ('ExpandableMenu.MiniHomePages.ShowHeading', 'False', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 809
SET @ScriptDesc = 'Property added to show or hide top headings in Left Menu Min home pages.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO