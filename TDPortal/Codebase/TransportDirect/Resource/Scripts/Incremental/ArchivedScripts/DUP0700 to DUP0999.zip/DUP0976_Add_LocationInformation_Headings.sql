-- ***********************************************
-- NAME 		: DUP0976_Add_LocationInformation_Headings
-- DESCRIPTION 		: Add headings for LocationInformation page			: 
-- AUTHOR		: Sanjeev Johal
-- ************************************************

Use Content
go


EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.localInformation.Text', 'Locality Information', 'CY Locality information'

EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.stationFacilities.Text', 'Station facilities', 'CY Station facilities'

EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.realTimeInfo.Text', 'Real time information', 'CY Real time information'

EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.airportFacilities.Text', 'Airport facilities', 'CY Airport facilities'

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 976
SET @ScriptDesc = 'Add headings for LocationInformation page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------