-- ************************************************************
-- NAME 		: DUP0821_Correct_On_The_Move_Link.sql
-- DESCRIPTION 	: Fixes the link to the external TD on the move site
-- AUTHOR		: Steve Barker
-- ************************************************************
USE [PermanentPortal]
GO

UPDATE	
	Properties
SET
	pValue = 'http://tdti.kizoom.co.uk/en/deps/index'
WHERE
	pName = 'TDOnTheMove.TDMobileUI.URL'
		AND	
	AID = 'Web'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 821
SET @ScriptDesc = 'Fixes the link to the external TD on the move site'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------