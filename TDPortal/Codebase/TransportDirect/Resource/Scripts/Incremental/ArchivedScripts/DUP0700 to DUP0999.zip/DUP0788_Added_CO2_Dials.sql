-- *************************************************************************************
-- NAME 		: DUP0788_Added_CO2_Dials_.sql
-- DESCRIPTION  	: Added CO2 dials to JourneyEmissions.aspx
-- AUTHOR		: Sanjeev Johal
-- DATE			: 07 Mar 2008 18:00:00
-- *************************************************************************************


USE [Content]

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/medium_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.ImageUrl'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/large_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.LargeCO2.ImageUrl'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/medium_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.MediumCO2.ImageUrl'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/small_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.SmallCO2.ImageUrl'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/red_pump.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageFuel.ImageUrl'



Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/speedo_dial.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.imageSpeedoDial.ImageUrl'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/pointer.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.Pointer.ImageURL'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/pointer_compare.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.PointerCompare.ImageURL'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/pointer_noyellow.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.PointerNoYellowTip.ImageURL'

Update tblContent
Set [Value-En] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/gauge.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.Gauge.ImageURL'



Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/medium_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.ImageUrl'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/large_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.LargeCO2.ImageUrl'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/medium_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.MediumCO2.ImageUrl'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/small_Co2.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageEmissions.SmallCO2.ImageUrl'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/red_pump.gif'
Where PropertyName = 'JourneyEmissionsDashboard.imageFuel.ImageUrl'



Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/speedo_dial.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.imageSpeedoDial.ImageUrl'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/pointer.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.Pointer.ImageURL'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/pointer_compare.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.PointerCompare.ImageURL'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/pointer_noyellow.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.PointerNoYellowTip.ImageURL'

Update tblContent
Set [Value-Cy] = '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/gauge.gif'
Where PropertyName = 'JourneyEmissionsSpeedoDial.Gauge.ImageURL'

GO

USE [Content]

INSERT INTO [dbo].[tblContent] ([ThemeId], [GroupId], [ControlName], [PropertyName], [Value-En], [Value-Cy])
VALUES (1, 1, 'langStrings', 'JourneyEmissionsDashboard.journeyCosts.Text', 'Journey costs', 'cy Journey costs')

INSERT INTO [dbo].[tblContent] ([ThemeId], [GroupId], [ControlName], [PropertyName], [Value-En], [Value-Cy])
VALUES (1, 1, 'langStrings', 'JourneyEmissionsDashboard.compareEmissions.Text', 'Compare CO2', 'cy Compare CO2')

GO