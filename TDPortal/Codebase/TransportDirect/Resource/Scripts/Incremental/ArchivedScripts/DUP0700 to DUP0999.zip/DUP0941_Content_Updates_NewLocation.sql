-- ***********************************************
-- NAME 		: DUP0941_Content_Updates_NewLocation.sql
-- DESCRIPTION 	: Script to update new locations content 
-- AUTHOR		: Mitesh Modi
-- DATE			: 19 May 2008
-- ************************************************

USE [Content]
GO


EXEC AddtblContent 1, 1, 'langStrings', 'LocationSelectControl2.labelNewLocationNoteFrom', 'Select the kind of location you want to travel from and type in the location', 'Dewiswch y math o leoliad y dymunwch deithio ohono a theipiwch y lleoliad'
EXEC AddtblContent 1, 1, 'langStrings', 'LocationSelectControl2.labelNewLocationNoteTo', 'Select the kind of location you want to travel to and type in the location', 'Dewiswch y math o leoliad y dymunwch deithio iddo a theipiwch y lleoliad'
EXEC AddtblContent 1, 1, 'langStrings', 'LocationSelectControl2.labelNewLocationNoteNone', 'Select the kind of location and type in the location', 'Dewiswch y math o leoliad a theipiwch y lleoliad'
EXEC AddtblContent 1, 1, 'langStrings', 'LocationSelectControl2.labelNewLocationNoteVia', 'Select the kind of location you want to travel via and type in the location', 'Dewiswch y math o leoliad y dymunwch deithio drwyddo a theipiwch y lleoliad'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 941
SET @ScriptDesc = 'Script to update new locations content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO