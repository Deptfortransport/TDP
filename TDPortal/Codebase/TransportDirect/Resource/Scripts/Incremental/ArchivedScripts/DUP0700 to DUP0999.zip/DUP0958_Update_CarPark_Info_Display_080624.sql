-- ***********************************************
-- NAME 		: DUP0958_Update_CarPark_Info_Display_080624.sql
-- DESCRIPTION 		: Script to add (cms) to the Car Park height & width details
-- AUTHOR		: D. Scott Angle
-- DATE			: 25 Jun 2008 10:00:00
-- ************************************************

USE Content

UPDATE dbo.tblContent
[Value-EN] = 'Maximum Height (cms) : {0} &lt;br /&gt;Maximum Width : {1}';
[Value-Cy] = 'Uchder Mwyaf (cms) : {0} &lt;br /&gt;Lled Mwyaf : {1}'
WHERE (PropertyName = 'CarParkInformationControl.ParkingRestrictions')

UPDATE dbo.tblContent
[Value-EN] = 'Maximum Height (cms) : {0}
[Value-Cy] = 'Uchder Mwyaf (cms) : {0}
WHERE (PropertyName = 'CarParkInformationControl.ParkingRestrictions.Height')

UPDATE dbo.tblContent
[Value-EN] = 'Maximum Width (cms) : {0}
[Value-Cy] = 'Lled Mwyaf (cms) : {1}
WHERE (PropertyName = 'CarParkInformationControl.ParkingRestrictions.Width')

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 958
SET @ScriptDesc = 'Car Park height and width measurement details'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO