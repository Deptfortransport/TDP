-- ************************************************************
-- NAME 	: DUP0766_Property_Update_For_PageTransferDetailsPath.sql
-- DESCRIPTION 	: Updated Property for PageTransferDetails.xml Path
-- Author       : Darshan Sawe
-- Date         : 20-Feb-2008
-- ************************************************************
--

USE [PermanentPortal]
GO

-- 1.  ScreenFlow.PageTransferDetails.Path

IF EXISTS ( SELECT * FROM [dbo].[properties] WHERE pName = 'ScreenFlow.PageTransferDetails.Path')
BEGIN
	UPDATE [dbo].[properties]
	SET pValue = '/Web2/PageTransferDetails.xml'
	WHERE PName = 'ScreenFlow.PageTransferDetails.Path'

END
ELSE
BEGIN
	INSERT INTO [dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
	VALUES ('ScreenFlow.PageTransferDetails.Path', '/Web2/PageTransferDetails.xml', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

-- 2.  ScreenFlow.PageTransitionEvent.Path

IF EXISTS ( SELECT * FROM [dbo].[properties] WHERE pName = 'ScreenFlow.PageTransitionEvent.Path')
BEGIN
	UPDATE [dbo].[properties]
	SET pValue = '/Web2/PageTransitionEvent.xml'
	WHERE PName = 'ScreenFlow.PageTransitionEvent.Path'

END
ELSE
BEGIN
	INSERT INTO [dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
	VALUES ('ScreenFlow.PageTransitionEvent.Path', '/Web2/PageTransitionEvent.xml', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 766
SET @ScriptDesc = 'Updated Property for PageTransferDetails.xml Path'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

