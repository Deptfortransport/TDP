-- ************************************************************
-- NAME 		: DUP0847_Update_Welsh_Translation_For_FindATrain.sql
-- DESCRIPTION 	: Provides an updated Welsh translation for Find A Train
-- AUTHOR		: S Johal
-- ************************************************************
USE TransientPortal
GO

update Resource set Text ='Canfyddwch dr�n' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'FindATrain')
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 847
SET @ScriptDesc = 'Provides an updated Welsh translation for Find A Train'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------