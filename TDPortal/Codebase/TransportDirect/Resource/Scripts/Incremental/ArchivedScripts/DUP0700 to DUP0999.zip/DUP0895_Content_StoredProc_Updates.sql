-- ***********************************************
-- NAME 		: DUP0895_Content_StoredProc_Updates.sql
-- DESCRIPTION 		: Script to update AddtblContent stored procedure
--			: (Where value exists update, rather than delete before inserting)
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 Apr 2008 15:00:00
-- ************************************************

use [Content]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-------------------------------
--AddtblContent Stored Procedure
-------------------------------
ALTER PROCEDURE dbo.[AddtblContent]
(
	@themeId int,
	@groupId int,
	@controlName varchar(500),
	@propertyName varchar(100),
	@valueEn text,
	@valueCy text
)
AS
BEGIN
	IF EXISTS (SELECT * FROM [dbo].tblContent 
			WHERE tblContent.PropertyName = @propertyName 
				AND tblContent.ControlName = @controlName 
				AND tblContent.ThemeId = @themeId 
				AND tblContent.GroupId = @groupId )
    	   BEGIN
		UPDATE [dbo].tblContent
		SET [value-en] = @valueEn,
		    [value-cy] = @valueCy
		WHERE tblContent.PropertyName = @propertyName 
			AND tblContent.ControlName = @controlName 
			AND tblContent.ThemeId = @themeId 
			AND tblContent.GroupId = @groupId
    	   END
	ELSE
	   BEGIN
	    	INSERT INTO [dbo].tblContent (ThemeId, GroupId, ControlName, PropertyName, [Value-En], [Value-Cy])
        	VALUES (@themeId, @groupId, @controlName, @propertyName, @valueEn, @valueCy)
	   END

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 895
SET @ScriptDesc = 'Update to AddtblContent stored procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO