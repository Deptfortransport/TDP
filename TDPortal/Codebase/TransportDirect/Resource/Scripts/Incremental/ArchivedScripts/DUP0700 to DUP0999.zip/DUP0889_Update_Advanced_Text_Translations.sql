-- ***********************************************
-- NAME 		: DUP0889_Update_Advanced_Text_Translations.sql
-- DESCRIPTION 		: Script to update translations for the advanced text.
-- AUTHOR		: Steve Barker
-- DATE			: 9 Apr 2008
-- ************************************************

USE [Content]
GO

----------------------------------------------------------------
-- Correct some existing English text. English version
-- is missing " Options include:"
----------------------------------------------------------------

UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey).</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to walk?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/JourneyPlannerInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Number of changes (choose whether you are happy to change vehicle or would prefer a direct journey, and how quickly you think you would be able to make any changes)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindTrainInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Number of changes (choose whether you are happy to change vehicle or would prefer a direct journey, and how quickly you think you would be able to make any changes)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Advanced flight options (choose flights by specific operators and amend your average check-in time)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindFlightInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindCarInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Number of changes (choose whether you are happy to change vehicle or would prefer a direct journey, and how quickly you think you would be able to make any changes)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindCoachInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey).</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to walk?)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/VisitPlannerInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/ParkAndRideInput'
UPDATE tblContent SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey).</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to walk?)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindBusInput'
GO

----------------------------------------------------------------
-- Update the Welsh text - The following are complete
----------------------------------------------------------------

UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Manylion siwrnai car (dewiswch y math o siwrnai rydych chi eisiau ei gweld - e.e. y siwrnai gyflymaf neu rataf - yn ogystal �''r heolydd yr hoffech chi eu defnyddio neu eu hosgoi)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindCarInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Math o Gludiant (dewiswch pa fath(au) o gludiant yr hoffech ei ddefnyddio ar gyfer eich siwrnai)</li><li>Manylion siwrnai Cludiant Cyhoeddus (nodwch eich dewisiadau rhyng-newid rhwng mathau o gludiant - fyddai''n well gennych siwrneiau uniongyrchol yn unig, pa mor gyflym ydych chi eisiau cerdded?)</li><li>Manylion siwrnai car (dewiswch y math o siwrnai rydych chi eisiau ei gweld - e.e. y siwrnai gyflymaf neu rataf - yn ogystal �''r heolydd yr hoffech chi eu defnyddio neu eu hosgoi)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/JourneyPlannerInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Math o Gludiant (dewiswch pa fath(au) o gludiant yr hoffech ei ddefnyddio ar gyfer eich siwrnai)</li><li>Manylion siwrnai Cludiant Cyhoeddus (nodwch eich dewisiadau rhyng-newid rhwng mathau o gludiant - fyddai''n well gennych siwrneiau uniongyrchol yn unig, pa mor gyflym ydych chi eisiau cerdded?)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/VisitPlannerInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Math o Gludiant (dewiswch pa fath(au) o gludiant yr hoffech ei ddefnyddio ar gyfer eich siwrnai)</li><li>Manylion siwrnai Cludiant Cyhoeddus (nodwch eich dewisiadau rhyng-newid rhwng mathau o gludiant - fyddai''n well gennych siwrneiau uniongyrchol yn unig, pa mor gyflym ydych chi eisiau cerdded?)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindBusInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Manylion siwrnai car (dewiswch y math o siwrnai rydych chi eisiau ei gweld - e.e. y siwrnai gyflymaf neu rataf - yn ogystal �''r heolydd yr hoffech chi eu defnyddio neu eu hosgoi)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/ParkAndRideInput'
GO

----------------------------------------------------------------
-- Update the Welsh text - The following contain some 
-- translations that are not quite right...
----------------------------------------------------------------

UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Nifer y newidiadau (dewiswch faint o newidiadau yr ydych chi eisiau eu gwneud ar eich siwrnai)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindTrainInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Nifer y newidiadau (dewiswch faint o newidiadau yr ydych chi eisiau eu gwneud ar eich siwrnai)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Dewisiadau hedfan mwy cymhleth (dewiswch ehediadau yn �l cwmn�au penodol neu hyd yn oed dewis cwmn�au nad ydych chi eisiau cynllunio siwrneiau gyda nhw.  Newidiwch eich amser cofrestru cyfartalog)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindFlightInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Cliciwch y botwm Dewisiadau Mwy Cymhleth uchod i ddiwygio rhai o''r opsiynau canlynol ar gyfer eich taith. Mae opsiynau''n cynnwys:</p><br/><ul><li>Nifer y newidiadau (dewiswch faint o newidiadau yr ydych chi eisiau eu gwneud ar eich siwrnai)</li></ul><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindCoachInput'
GO

----------------------------------------------------------------
-- Update the Welsh text - The following contain some 
-- translations that are missing. Welsh text is still in English
----------------------------------------------------------------

UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>With the city-to-city planner you can compare train, plane, coach and car journeys between two cities or towns in Britain on a given day. Select your origin and destination from our dropdown lists of major locations within Britain and city-to-city will give you journey options broken down by transport type.</p><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/JourneyPlanning/FindTrunkInput'
UPDATE tblContent SET [Value-Cy] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Registering with Transport Direct is optional.  You can still access most of our features without registering but once registered you can:</p><br/><ul><li>Save your favourite journeys so you can access them again in the future without having to re-enter any information.</li><li>Save travel preferences when entering information for a journey so you don''t have to enter them again - but you still have the option to change them if you wish.</li><li>Email travel options to other people</li></ul><br/><p>It is easy to register, simply enter your email address in the box above, then choose a password between 4 and 12 characters, retype your password, click register and you''re done.</p><br/><p>If at any time you wish to change your registered email address simply enter your current address and password then click the ''change email address'' button and enter your new address.</p><br/></div></div>' WHERE ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName = '/Channels/TransportDirect/LoginRegister'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 889
SET @ScriptDesc = 'Script to update translations for the advanced text.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO