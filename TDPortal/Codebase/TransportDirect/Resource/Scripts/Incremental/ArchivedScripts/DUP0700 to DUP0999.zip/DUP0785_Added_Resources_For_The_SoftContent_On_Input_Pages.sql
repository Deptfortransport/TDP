-- *************************************************************************************
-- NAME 		: DUP0785_Added_Resources_For_The_SoftContent_On_Input_Pages.sql
-- DESCRIPTION  : Resources for soft content on Input Pages
-- AUTHOR		: Amit Patel
-- *************************************************************************************


USE Content
GO


-- information for JourneyPlannerInput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_journeyplannerinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_journeyplannerinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_journeyplannerinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/JourneyPlannerInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/JourneyPlannerInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for journeyplannerambiguity Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_journeyplannerambiguity')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_journeyplannerambiguity')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_journeyplannerambiguity'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/JourneyPlannerAmbiguity', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/JourneyPlannerAmbiguity', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for findtraininput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findtraininput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findtraininput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findtraininput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDFindTrainPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainInput', '<div class="Column3Header"><div class="txtsevenbbl">Get the latest travel info on your phone</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="txtseven">You can get our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Transport Direct Mobile</a> service on your mobile phone or PDA for free. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Get the latest travel info on your phone</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="txtseven">You can get our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Transport Direct Mobile</a> service on your mobile phone or PDA for free. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDFindTrainPromo2HtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainInput', '<div class="Column3Header"><div class="txtsevenbbl">Get Real Travel Information</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="txtseven">You can get information on today''s disruptions by selecting the links below: <br><a href="/Web2/LiveTravel/DepartureBoards.aspx#train">Go to the rail departure boards</a><br><a href="/Web2/LiveTravel/TravelNews.aspx">Go to public transport live travel news</a></td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Get Real Travel Information</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="txtseven">You can get information on today''s disruptions by selecting the links below: <br><a href="/Web2/LiveTravel/DepartureBoards.aspx#train">Go to the rail departure boards</a><br><a href="/Web2/LiveTravel/TravelNews.aspx">Go to public transport live travel news</a></td></tr></tbody></table></div>'

GO


-- information for findtraincostinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findtraincostinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findtraincostinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findtraincostinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDFindTrainPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput', '<div class="Column3Header"><div class="txtsevenbbl">Get the latest travel info on your phone</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="txtseven">You can get our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Transport Direct Mobile</a> service on your mobile phone or PDA for free. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Get the latest travel info on your phone</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="txtseven">You can get our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Transport Direct Mobile</a> service on your mobile phone or PDA for free. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.</td></tr></tbody></table></div>'

GO


-- information for findflightinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findflightinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findflightinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findflightinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindFlightInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindFlightInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for findcarinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findcarinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findcarinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findcarinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for findcoachinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findcoachinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findcoachinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findcoachinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCoachInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCoachInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO


-- information for findtrunkinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findtrunkinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findtrunkinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findtrunkinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrunkInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrunkInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

GO

-- information for visitplannerinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_visitplannerinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_visitplannerinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_visitplannerinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/VisitPlannerInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/VisitPlannerInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for parkandrideinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_parkandrideinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_parkandrideinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_parkandrideinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/ParkAndRideInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/ParkAndRideInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for findbusinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findbusinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findbusinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findbusinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindBusInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindBusInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for findcarparkinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findcarparkinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findcarparkinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findcarparkinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarParkInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarParkInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for findastationinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_findastationinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_findastationinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findastationinput'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindAStationInput', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindAStationInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for extendjourneyinput Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_extendjourneyinput')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_extendjourneyinput')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_extendjourneyinput'			

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/ExtendJourneyInput', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO



-- information for journeyplannerlocationmap Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'maps_journeyplannerlocationmap')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'maps_journeyplannerlocationmap')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'maps_journeyplannerlocationmap'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/Maps/JourneyPlannerLocationMap', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/JourneyPlannerLocationMap', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for trafficmaps Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'maps_trafficmaps')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'maps_trafficmaps')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'maps_trafficmaps'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/Maps/TrafficMaps', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/TrafficMaps', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for tdonthemove Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'tdonthemove_tdonthemove')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'tdonthemove_tdonthemove')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'tdonthemove_tdonthemove'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/TdOnTheMove/TdOnTheMove', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/TdOnTheMove/TdOnTheMove', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

-- information for home Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'home')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'home')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'home'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/Home', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

GO

-- information for journeyplanning home Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_home')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_home')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_home'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/Home', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

GO

-- information for maps home Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'maps_home')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'maps_home')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'maps_home'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/Maps/Home', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

GO

-- information for tools home Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'tools_home')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'tools_home')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'tools_home'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/Tools/Home', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

GO

-- information for live travel home Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'livetravel_home')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'livetravel_home')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'livetravel_home'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/LiveTravel/Home', '<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>','cy <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>'
 
EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/LiveTravel/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'

GO






-- information for loginregister Page
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'loginregister')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'loginregister')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'loginregister'			
EXEC AddtblContent
 1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/LoginRegister', '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Registering with Transport Direct is optional.  You can still access most of our features without registering but once registered you can:</p><br/><ul><li>Save your favourite journeys so you can access them again in the future without having to re-enter any information.</li><li>Save travel preferences when entering information for a journey so you don�t have to enter them again � but you still have the option to change them if you wish.</li><li>Email travel options to other people</li></ul><br/><p>It is easy to register, simply enter your email address in the box above, then choose a password between 4 and 12 characters, retype your password, click register and you�re done.</p><br/></div></div>','cy <div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Registering with Transport Direct is optional.  You can still access most of our features without registering but once registered you can:</p><br/><ul><li>Save your favourite journeys so you can access them again in the future without having to re-enter any information.</li><li>Save travel preferences when entering information for a journey so you don�t have to enter them again � but you still have the option to change them if you wish.</li><li>Email travel options to other people</li></ul><br/><p>It is easy to register, simply enter your email address in the box above, then choose a password between 4 and 12 characters, retype your password, click register and you�re done.</p><br/></div></div>'
GO


-- information for JourneyEmissions right hand info panel 
DECLARE @MaxGroupId INT
DECLARE @GroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'journeyplanning_journeyemissions')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'journeyplanning_journeyemissions')
			

SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_journeyemissions'			

EXEC AddtblContent
 1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/JourneyEmissions', '<DIV class="Column3Header">  <DIV class="txtsevenbbl">Save fuel and cut your CO2!</DIV><!-- Don"t remove spaces -->&nbsp;</DIV>  <DIV class="Column3Content">  <TABLE cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="txtseven" colSpan="2">  <TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">  <TBODY>  <TR>  <TD colSpan="2">Drive off peak to avoid congestion </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Congestion costs fuel and CO2. Use Transport Direct to find out the least congested time to drive. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Drive smoothly </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>You save 30% on fuel and CO2 when you drive at a steady 50 mph instead of 70 mph. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Drive at 70 mph&nbsp;on the motorway </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Sticking to the speed limit could save you up to �5 on a 100 mile motorway journey. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Check your tyres </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Soft tyres will increase your fuel bill by around �2 on a 100 mile round trip. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Service your car </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Dirty petrol and oil filters reduce your cars fuel efficiency. </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>','<DIV class="Column3Header">  <DIV class="txtsevenbbl">Arbedwch danwydd a chwtogi ar eich CO2!</DIV><!-- Don"t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</DIV>  <DIV class="Column3Content">  <TABLE cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="txtseven" colSpan="2">  <TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">  <TBODY>  <TR>  <TD colSpan="2">Gyrrwch yn ystod oriau allfrig i osgoi tagfeydd </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Mae tagfeydd yn costio tanwydd a CO2. Defnyddiwch Transport Direct i gael gwybod yr amser lleiaf prysur i yrru. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Gyrrwch yn esmwyth </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Rydych chi"n arbed 30% ar danwydd a CO2 pan fyddwch chi"n gyrru 50 m.y.a. yn gyson yn lle 70 m.y.a. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Gyrrwch 70 m.y.a. ar y draffordd</TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Drwy gadw at y cyfyngiad cyflymdra, fe allech arbed hyd at �5 ar siwrnai 100 milltir ar y draffordd.<BR><BR></TD></TR>  <TR>  <TD colSpan="2">Edrychwch dros eich teiars </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Bydd teiars meddal yn cynyddu eich bil tanwydd rhyw �2 ar daith ddydd 100 milltir. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Cofiwch drin eich car </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Mae hidlwyr petrol ac olew brwnt yn lleihau effeithlonrwydd tanwydd eich car. </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>'
GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 785
SET @ScriptDesc = 'Resources for soft content on Input Pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO