-- ***********************************************
-- NAME 		: DUP0892_Content_GeneralUpdate.sql.sql
-- DESCRIPTION 		: Script to add missing and updated strings to Content
-- AUTHOR		: Mitesh Modi
-- DATE			: 10 Apr 2008 15:00:00
-- ************************************************

use [Content]
GO

-- Find train results table sort column image
EXEC AddTblContent
1, 1, 'langStrings', 'SummaryResultTableControl.ImageSortIconDescending',
'/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryDescending.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryDescending.gif'

EXEC AddTblContent
1, 1, 'langStrings', 'SummaryResultTableControl.ImageSortIconAscending',
'/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryAscending.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryAscending.gif'


-- Map region control
EXEC AddTblContent
1, 1, 'langStrings', 'MapRegionControl.headingRegion',
'View travel news for a region',
'Gweld y newyddion i deithwyr ar gyfer rhanbarth'

EXEC AddTblContent
1, 1, 'langStrings', 'MapRegionSelectControl.headingRegion',
'Region',
'Rhanbarth'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 892
SET @ScriptDesc = 'Added missing and updated strings to content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO