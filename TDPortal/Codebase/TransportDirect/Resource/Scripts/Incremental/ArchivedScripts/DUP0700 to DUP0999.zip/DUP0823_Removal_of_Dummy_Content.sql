-- ************************************************************
-- NAME 		: DUP0823_Removal_of_Dummy_Content.sql
-- DESCRIPTION 	: Removes dummy text entries from the database
-- AUTHOR		: Steve Barker
-- ************************************************************
USE Content
GO

UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73509'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73468'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73500'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73512'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73506'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73503'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '66161'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73464'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73466'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73468'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73472'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73475'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73477'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73479'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73481'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73483'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73485'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73487'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73489'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73491'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73494'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73496'
UPDATE tblContent SET [Value-En] = '', [Value-Cy] = '' WHERE ContentId = '73498'

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 823
SET @ScriptDesc = 'Removes dummy text entries from the database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------