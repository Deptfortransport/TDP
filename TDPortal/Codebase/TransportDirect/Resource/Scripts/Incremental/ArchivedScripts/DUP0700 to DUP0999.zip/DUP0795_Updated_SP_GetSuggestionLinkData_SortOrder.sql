-- *************************************************************************************
-- NAME 		: DUP0795_Updated_SP_GetSuggestionLinkData_SortOrder.sql
-- DESCRIPTION  	: Updated order by to include ThemeId value
-- AUTHOR		: Mitesh Modi
-- DATE			: 10 Mar 2008 18:00:00
-- *************************************************************************************

USE [TransientPortal]
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


---------------------------------------------------------------------
-- Update to GetSuggestionLinkData Proc
---------------------------------------------------------------------
ALTER   PROCEDURE [dbo].GetSuggestionLinkData 
	
AS

SELECT 	Context.[Name] ContextName, 
	SuggestionLink.SuggestionLinkId, 
	LinkCategory.Priority CategoryPriority, 
	LinkCategory.[Name] CategoryName,
	SuggestionLink.Priority LinkPriority, 
	InternalLink.RelativeURL, 
	Resource.Culture, 
	Resource.[Text] ResourceString, 
	SuggestionLink.IsRoot,
	SuggestionLink.IsSubRootLink,
	SuggestionLink.SubRootLinkId,
	ContextSuggestionLink.ThemeId
FROM SuggestionLink 
	INNER JOIN ContextSuggestionLink 
		ON SuggestionLink.SuggestionLinkId = ContextSuggestionLink.SuggestionLinkId 
	INNER JOIN Context 
		ON ContextSuggestionLink.ContextId = Context.ContextId 
	INNER JOIN LinkCategory 
		ON SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId 
	INNER JOIN ResourceName 
		ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId 
	INNER JOIN Resource 
		ON ResourceName.ResourceNameId = Resource.ResourceNameId 
	INNER JOIN InternalLink 
		ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId 
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
ORDER BY Context.ContextID, CategoryPriority, LinkPriority, ContextSuggestionLink.ThemeId, Culture

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 795
SET @ScriptDesc = 'Updated GetSuggestionLinkData with ThemeId order by value'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
