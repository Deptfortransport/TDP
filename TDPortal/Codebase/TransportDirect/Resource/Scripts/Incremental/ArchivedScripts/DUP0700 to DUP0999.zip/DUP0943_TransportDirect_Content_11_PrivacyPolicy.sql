-- ***********************************************
-- NAME 		: DUPxxxx_TransportDirect_Content_11_PrivacyPolicy.sql
-- DESCRIPTION 	: Script to add Privacy Policy content
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 May 2008 15:00:00
-- ************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Content]
GO

DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'staticwithoutprint')

EXEC AddtblContent
1, @GroupId, 'Body Text', '/Channels/TransportDirect/About/PrivacyPolicy'
,'<DIV id="primcontent">  <DIV id="contentarea">  <DIV id="hdtypethree"> 
<H2><A id="PrivacyPolicy">Privacy policy</A></H2></DIV><BR>  <H6>1.&nbsp; General</H6>  <P>&nbsp;</P>  
<P>1.1 &nbsp;Transport Direct is a division of the Department for Transport whose main contact address for the purpose of this Privacy policy is Programme Support Office, Transport Direct, Department for Transport, Zone 1/F20, Ashdown House, 123 Victoria Street, LONDON, SW1E 6DE. ("<STRONG>Transport Direct</STRONG>").&nbsp;&nbsp; In the course of your use of the Transport Direct website located at www.TransportDirect.info (the "<STRONG>Website</STRONG>") we will only collect your email address.&nbsp;&nbsp; This Privacy Policy applies to the processing by Transport Direct of your email address.&nbsp; By accessing and using the Website you are agreeing or have agreed to be bound by the Website Terms and this Privacy policy and you consent to Transport Direct holding, processing and transferring your email address as set out herein.&nbsp;&nbsp; Transport Direct&nbsp; may at any time modify, recover, alter or update this Privacy policy</P><BR>  
<H6>2.&nbsp; Transport Direct Use of Your Email Address </H6>  <P>&nbsp;</P>  
<P>2.1 &nbsp;Transport Direct will use your e-mail address to profile the Website to better suit your needs and to contact you when necessary. </P><BR>  
<P>2.2&nbsp; Other than is required by law or as set out in this Privacy policy, Transport Direct will not disclose, rent or sell your email address to any third party without your permission.</P><BR>  
<P>2.3&nbsp; Transport Direct will hold your email address on its systems for as long as you remain a registered user of the Website.&nbsp; Transport Direct will remove it when requested by you. </P><BR>  
<H6>3. &nbsp;Cookies </H6>  <P>&nbsp;</P>  
<P>3.1&nbsp; You should be aware that information in data may be automatically collected through the use of "cookies".&nbsp; Cookies are small text files a Website can use to recognise you and allow Transport Direct to observe behaviour and compile accurate data in order to improve the Website experience for you. </P><BR>  
<P>3.2&nbsp; Most internet browsers enable you to delete cookies or receive a warning that cookies are being installed and if you do not want information collected through these cookies there is a simple procedure by which most browsers allow you to block or deny the cookies.&nbsp; Please refer to your browser instructions or help pages to learn more about these functions. <U>However, for you to make best use of the site&#8217;s full functionality we recommend you do not block or deny cookies.</U>&nbsp; </P><BR>  
<P>3.3&nbsp; Transport Direct will install a cookie named "TDP" containing the following details:</P>
<UL>
<LI id="bullet">Session ID</LI>
<LI id="bullet">Site theme id and domain</LI>
<LI id="bullet">Last visited date and time</LI>
<LI id="bullet">Last page visited</LI>
</UL><BR>
<P>The cookie will be used to detect new or repeat visitors of the site. To opt out of this process, please follow your browser instructions or help pages to block or deny the cookies. The cookies installed by Transport Direct will expire after six months.</P><BR>
<P>3.4&nbsp; Transport Direct uses pixels, or transparent GIF files, to help manage online advertising. These GIF files are provided by DoubleClick and enable DoubleClick to recognize a unique cookie on your web browser, which in turn helps us to learn which of our advertisements bring most users to our website. The cookie was placed by us, or by another advertiser who works with DoubleClick. With both cookies and Spotlight technology, the information that we collect and share is anonymous and not personally identifiable. It does not reveal your name, address, telephone number, or email address. For more information about DoubleClick, including information about how to opt out of these technologies, go to <A href="http://www.doubleclick.net/us/corporate/privacy" target="_blank">www.doubleclick.net/us/corporate/privacy</A>.</P><BR>  <P>&nbsp;</P>  <DIV></DIV></DIV></DIV>  <DIV></DIV>'

,'<DIV id="primcontent">  <DIV id="contentarea">  <DIV id="hdtypethree"> <H2><A id="PrivacyPolicy">Polisi preifatrwydd</A></H2></DIV><BR>  <H6>1.&nbsp; Cyffredinol</H6>  <P>&nbsp;</P>  <P>1.1&nbsp; Mae Transport Direct yn is-adran o''r Adran Cludiant a''i brif gyfeiriad cyswllt i bwrpas y Polisi Preifatrwydd hwn yw''r Programme Support Office, Transport Direct, Department for Transport, Zone 1/F20, Ashdown House, 123 Victoria Street, LONDON, SW1E 6DE ("<STRONG>Transport Direct</STRONG>"). Pan fyddwch yn defnyddio gwefan Transport Direct a leolir yn www.TransportDirect.info (y "<STRONG>Wefan</STRONG>") byddwn yn casglu eich cyfeiriad ebost yn unig.&nbsp; Mae''r Polisi Preifatrwydd hwn yn berthnasol i brosesu eich cyfeiriad ebost gan Transport Direct.&nbsp; Drwy gyrchu at a defnyddio''r Wefan&nbsp; rydych yn cytuno neu rydych wedi cytuno i gael eich rhwymo gan Delerau''r Wefan &nbsp;a''r Polisi Preifatrwydd hwn ac rydych yn caniat&#225;u i Transport Direct ddal, prosesu a throsglwyddo eich cyfeiriad ebost fel y cyflwynir yma.&nbsp; Gall Transport Direct ddiwygio, adfer, newid neu ddiweddaru''r Polisi Preifatrwydd hwn unrhyw bryd.</P><BR>  
<H6>2.&nbsp; Defnydd Transport Direct o''ch Cyfeiriad Ebost </H6>  <P>&nbsp;</P>  
<P>2.1 &nbsp;Bydd Transport Direct yn defnyddio eich cyfeiriad ebost i ddiwygio''r Wefan i fod yn fwy addas ar gyfer eich gofynion ac i gysylltu &#226; chi pan fo hynny yn angenrheidiol. </P><BR>  
<P>2.2&nbsp; Heblaw am yr hyn sy''n ofynnol yn &#244;l y ddeddf neu fel y cyflwynwyd yn y Polisi Preifatrwydd hwn, ni fydd Transport Direct yn datgelu, rhentu na gwerthu eich cyfeiriad ebost i unrhyw drydydd parti heb eich caniat&#226;d.</P><BR>  
<P>2.3 &nbsp;Bydd Transport Direct yn cadw eich gwybodaeth bersonol ar ei systemau cyhyd ag y bydd hynny yn gwbl angenrheidiol yn unig a bydd yn tynnu gwybodaeth bersonol o''r fath ymaith cyn gynted ag y bydd hynny''n rhesymol o ymarferol wedi derbyn cais ysgrifenedig oddi wrthych chi. </P><BR>  
<H6>3.&nbsp; "Cookies" </H6>  <P>&nbsp;</P>  
<P>3.1 &nbsp;Dylech fod yn ymwybodol y gall gwybodaeth mewn data gael ei chasglu yn awtomatig gan ddefnyddio "cookies".&nbsp; Mae "cookies" yn ffeiliau testun bychain y gall gwefan eu defnyddio i''ch adnabod chi a chaniat&#225;u i Transport Direct sylwi ar ymddygiad a chasglu gwybodaeth gywir er mwyn gwella''r profiad a gewch chi o''r Wefan.</P><BR>  
<P>3.2&nbsp; Mae''r rhan fwyaf o borwyr y rhyngrwyd yn eich galluogi i ddileu "cookies" neu dderbyn rhybudd bod "cookies" yn cael eu gosod ac os nad ydych am i wybodaeth gael ei chasglu drwy''r "cookies" hyn mae trefn syml lle gall y rhan fwyaf o borwyr ganiat&#225;u i chi rwystro neu atal "cookies".&nbsp; Cyfeiriwch at gyfarwyddiadau neu dudalennau cymorth eich porwr i ddysgu mwy am y swyddogaethau hyn.&nbsp; <U>Ond er mwyn i chi wneud y defnydd gorau o swyddogaeth llawn y safle rydym yn argymell nad ydych yn rhwystro nac yn atal y "cookies" hyn.</U>&nbsp; </P><BR>
<P>3.3&nbsp; Transport Direct will install a cookie named "TDP" containing the following details:</P>
<UL>
<LI id="bullet">Session ID</LI>
<LI id="bullet">Site theme id and domain</LI>
<LI id="bullet">Last visited date and time</LI>
<LI id="bullet">Last page visited</LI>
</UL><BR>
<P>The cookie will be used to detect new or repeat visitors of the site. To opt out of this process, please follow your browser instructions or help pages to block or deny the cookies. The cookies installed by Transport Direct will expire after six months.</P><BR>
<P>3.4&nbsp;Mae Transport Direct yn defnyddio picseli neu ffeiliau GIF tryloyw i helpu i reoli hysbysebu arlein. Darperir y ffeiliau GIF hyn gan DoubleClick ac maent yn galluogi DoubleClick i adnabod &#8216;cookie&#8217; unigryw ar eich porwr gwe, sydd yn ei dro yn ein helpu i ddysgu pa rai o&#8217;n hysbysebion sydd yn dod &#226;&#8217;r nifer mwyaf o ddefnyddwyr i&#8217;n gwefan. Gosodwyd y &#8216;cookie&#8217; gennym ni, neu gan hysbysebwr arall sy&#8217;n gweithio gyda DoubleClick. Gyda &#8216;cookies&#8217; a thechnoleg Spotlight, mae&#8217;r wybodaeth a gasglwn ac a rannwn yn anhysbys ac ni ellir adnabod unrhyw un yn bersonol oddi wrtho. Nid yw&#8217;n datgelu eich enw, cyfeiriad, rhif ff&#244;n na&#8217;ch cyfeiriad ebost. I gael mwy o wybodaeth am DoubleClick, gan gynnwys gwybodaeth am sut i optio allan o&#8217;r technolegau hyn ewch i <A href="http://www.doubleclick.net/us/corporate/privacy" target="_blank">www.doubleclick.net/us/corporate/privacy</A>.</P><BR>  <P>&nbsp;</P></DIV></DIV>  <DIV></DIV>  <DIV></DIV>  <DIV></DIV>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 998
SET @ScriptDesc = 'Add Privacy Policy content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO