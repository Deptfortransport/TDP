-- ***********************************************
-- NAME 		: DUP0802_Addition_Of_Related_Links_Title_Image.sql
-- DESCRIPTION 	: Addition of the title icon on the related sites screen
-- AUTHOR		: Steve Barker
-- ************************************************

USE [Content]
GO

UPDATE 
	[dbo].[tblContent]
SET 
	[value-En] = 
'<table>
	<tr>
		<td><img src="/Web2/App_Themes/TransportDirect/images/gifs/softcontent/relatedlinkslargeicon.gif" alt="Related sites" width="70px" height="36px" /></td>
		<td>Related sites</td>
	</tr>
</table>',
	[value-Cy] = 
'<table>
	<tr>
		<td><img src="/Web2/App_Themes/TransportDirect/images/gifs/softcontent/relatedlinkslargeicon.gif" alt="Safleoedd cysylltiedig" width="70px" height="36px" /></td>
		<td>Safleoedd cysylltiedig</td>
	</tr>
</table>'
WHERE 
	[ContentId] = 65843	
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 802
SET @ScriptDesc = 'Addition of the title icon on the related sites screen.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO