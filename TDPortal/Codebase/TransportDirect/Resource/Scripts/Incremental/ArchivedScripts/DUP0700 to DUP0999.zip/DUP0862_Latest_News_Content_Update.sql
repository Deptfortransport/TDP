-- ***********************************************
-- NAME 		: DUP0862_Latest_News_Content_Update.sql
-- DESCRIPTION 	: Update to Latest news table Content
-- AUTHOR		: amit Patel
-- Date 		: 28	-March-2008
-- ************************************************
USE [PermanentPortal]
GO


UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">For details of disruptions following the recent incidents in London please <A href="http://www.tfl.gov.uk/tfl/service_realtime_all.shtml" target="_child">click here.</A></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">For details of disruptions following the recent incidents in London please <A href="http://www.tfl.gov.uk/tfl/service_realtime_all.shtml" target="_child">click here.</A></td></tr>'
	WHERE Description = 'London Alert'
	
	
UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Public transport information for the Easter weekend (14th to 17th April) may not be correct at present. Please re-check nearer the time.</td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Public transport information for the Easter weekend (14th to 17th April) may not be correct at present. Please re-check nearer the time.</td></tr>'
	WHERE Description = 'Seasonal'

UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in London and the South East of England including the Isle of Wight.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in London and the South East of England including the Isle of Wight.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'SouthEast'


UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in South West England including Hampshire.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in South West England including Hampshire.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'SouthWest'
	
UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in East Anglia.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in East Anglia.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'EastAnglia'
	

UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the East Midlands including Derby and Nottingham.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the East Midlands including Derby and Nottingham.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'EastMidlands'
	

UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the West Midlands.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the West Midlands.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'WestMidlands'

UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Wales.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Wales.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'Wales'

UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the North East of England and Cumbria / Lake District.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the North East of England and Cumbria / Lake District.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'NorthEast'

UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the North West of England including Liverpool and Manchester.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the North West of England including Liverpool and Manchester.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'NorthWest'
	
UPDATE HomePageMessage SET 
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Scotland.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Scotland.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'Scotland'
	
UPDATE HomePageMessage SET
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Yorkshire.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Yorkshire.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE Description = 'Yorkshire'
	
UPDATE HomePageMessage SET 
	ValueEn='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/transportdirect/en/specialnoticeboard.aspx">Special Notice Board</a></td></tr>' 
	,ValueCy ='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/transportdirect/en/specialnoticeboard.aspx">Special Notice Board</a></td></tr>'
	WHERE Description = 'Special Notice Board'
	
IF NOT EXISTS (SELECT * FROM HomePageMessage WHERE Description = 'Special Notice Page')
	INSERT INTO HomePageMessage(SeqNo, Description, Changed, Display, ValueEn, ValueCy)
		VALUES (15, 'Special Notice Page', 0, 0,'Special Notice Content','Special Notice Content')

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 862
SET @ScriptDesc = 'Update to Latest news table Content '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------