-- ***********************************************
-- NAME 		: DUP0920_Correct_Partner_Page_Titles.sql
-- DESCRIPTION 		: Script to add extra content entries to ensure that partners show customised page title text.
-- AUTHOR		: Steve Barker
-- DATE			: 06 May 2008
-- ************************************************

/*
=========
Theme IDs
=========

1 = TransportDirect
2 = VisitBritain
3 = BBC
5 = DirectGov

*/

USE [Content]
GO

--Note that the Welsh entry was blank before the next three changes were made, so preserving the original values:
EXEC AddtblContent 2, 1, 'langStrings', 'SeasonalNoticeBoard.DefaultPageTitle', 'Visit Britain ', ''
EXEC AddtblContent 3, 1, 'langStrings', 'SeasonalNoticeBoard.DefaultPageTitle', 'BBC ', ''
EXEC AddtblContent 5, 1, 'langStrings', 'SeasonalNoticeBoard.DefaultPageTitle', 'Direct Gov ', ''

EXEC AddtblContent 2, 1, 'langStrings', 'JourneyPlanner.DefaultPageTitle', 'Visit Britain ', 'Visit Britain '
EXEC AddtblContent 3, 1, 'langStrings', 'JourneyPlanner.DefaultPageTitle', 'BBC ', 'BBC '
EXEC AddtblContent 5, 1, 'langStrings', 'JourneyPlanner.DefaultPageTitle', 'Directgov ', 'Directgov '

EXEC AddtblContent 2, 1, 'langStrings', 'HomeTravelInfo.PageTitle', 'Live travel | traffic news| travel news on public transport networks| Visit Britain', 'Visit Britain | Teithio byw | Newyddion teithio mewn amser real am rwydweithiau ffyrdd a chludiant cyhoeddus Prydain'
EXEC AddtblContent 3, 1, 'langStrings', 'HomeTravelInfo.PageTitle', 'Live travel | traffic news| travel news on public transport networks| BBC', 'BBC | Teithio byw | Newyddion teithio mewn amser real am rwydweithiau ffyrdd a chludiant cyhoeddus Prydain'
EXEC AddtblContent 5, 1, 'langStrings', 'HomeTravelInfo.PageTitle', 'Live travel | traffic news| travel news on public transport networks| Directgov', 'Directgov | Teithio byw | Newyddion teithio mewn amser real am rwydweithiau ffyrdd a chludiant cyhoeddus Prydain'

EXEC AddtblContent 2, 1, 'langStrings', 'HomePlanAJourney.PageTitle', 'Visit Britain | Plan a journey | Journey planners for public transport and car, plus travel options and costs', 'Visit Britain | Cynlluniwch siwrnai | Cynllunwyr siwrneion ar gyfer cludiant cyhoeddus a char, a dewisiadau teithio a chostau'
EXEC AddtblContent 3, 1, 'langStrings', 'HomePlanAJourney.PageTitle', 'BBC | Plan a journey | Journey planners for public transport and car, plus travel options and costs', 'BBC | Cynlluniwch siwrnai | Cynllunwyr siwrneion ar gyfer cludiant cyhoeddus a char, a dewisiadau teithio a chostau'
EXEC AddtblContent 5, 1, 'langStrings', 'HomePlanAJourney.PageTitle', 'Directgov | Plan a journey | Journey planners for public transport and car, plus travel options and costs', 'Directgov | Cynlluniwch siwrnai | Cynllunwyr siwrneion ar gyfer cludiant cyhoeddus a char, a dewisiadau teithio a chostau'

EXEC AddtblContent 2, 1, 'langStrings', 'HomeTipsTools.PageTitle', 'Visit Britain | Tips and tools| Additional features to help you get more from Transport Direct', 'Visit Britain | Awgrymiadau a theclynnau| Nodweddion ychwanegol i''ch helpu i gael mwy o Transport Direct'
EXEC AddtblContent 3, 1, 'langStrings', 'HomeTipsTools.PageTitle', 'BBC | Tips and tools| Additional features to help you get more from Transport Direct', 'BBC | Awgrymiadau a theclynnau| Nodweddion ychwanegol i''ch helpu i gael mwy o Transport Direct'
EXEC AddtblContent 5, 1, 'langStrings', 'HomeTipsTools.PageTitle', 'Directgov | Tips and tools| Additional features to help you get more from Transport Direct', 'Directgov | Awgrymiadau a theclynnau| Nodweddion ychwanegol i''ch helpu i gael mwy o Transport Direct'

EXEC AddtblContent 2, 1, 'langStrings', 'HomeFindAPlace.PageTitle', 'Visit Britain | Find a place | Street maps showing transport links, attractions and facilities', 'Visit Britain | Canfyddwch le | Mapiau stryd yn dangos cysylltiadau cludiant, atyniadau a chyfleusterau'
EXEC AddtblContent 3, 1, 'langStrings', 'HomeFindAPlace.PageTitle', 'BBC | Find a place | Street maps showing transport links, attractions and facilities', 'BBC | Canfyddwch le | Mapiau stryd yn dangos cysylltiadau cludiant, atyniadau a chyfleusterau'
EXEC AddtblContent 5, 1, 'langStrings', 'HomeFindAPlace.PageTitle', 'Directgov | Find a place | Street maps showing transport links, attractions and facilities', 'Directgov | Canfyddwch le | Mapiau stryd yn dangos cysylltiadau cludiant, atyniadau a chyfleusterau'

EXEC AddtblContent 2, 1, 'langStrings', 'Homepage.PageTitle', 'Visit Britain - Britain''s free online journey planner', 'Visit Britain � cynlluniwr siwrneion ar-lein am ddim Prydain'
EXEC AddtblContent 3, 1, 'langStrings', 'Homepage.PageTitle', 'BBC - Britain''s free online journey planner', 'BBC � cynlluniwr siwrneion ar-lein am ddim Prydain'
EXEC AddtblContent 5, 1, 'langStrings', 'Homepage.PageTitle', 'Directgov - Britain''s free online journey planner', 'Directgov � cynlluniwr siwrneion ar-lein am ddim Prydain'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 920
SET @ScriptDesc = 'Script to add extra content entries to ensure that partners show customised page title text.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO