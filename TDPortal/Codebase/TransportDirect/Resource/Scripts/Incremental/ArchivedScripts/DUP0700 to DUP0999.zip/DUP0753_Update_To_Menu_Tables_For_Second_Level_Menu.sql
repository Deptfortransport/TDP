-- *************************************************************************************
-- NAME 		: DUP0753_Update_To_Menu_Tables_For_Second_Level_Menu.sql
-- DESCRIPTION  : Update to left hand menu related tables to make it two level
-- AUTHOR		: Amit Patel
-- *************************************************************************************
USE [TransientPortal]
GO


IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('SuggestionLink')
						AND syscolumns.name = 'IsSubRootLink')

ALTER TABLE SuggestionLink ADD [IsSubRootLink] BIT  NOT NULL DEFAULT(0)
	
GO

IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('SuggestionLink')
						AND syscolumns.name = 'SubRootLinkId')

ALTER TABLE SuggestionLink ADD [SubRootLinkId] INT  NOT NULL DEFAULT(0)
	
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 753
SET @ScriptDesc = 'Update to left hand menu related tables to make it two level'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
