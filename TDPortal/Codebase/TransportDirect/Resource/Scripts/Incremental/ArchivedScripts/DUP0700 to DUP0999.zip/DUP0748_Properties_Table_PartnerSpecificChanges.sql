-- ************************************************************
-- NAME 	: DUP0748_Properties_Table_PartnerSpecificChanges.sql
-- DESCRIPTION 	: Updated Properties Table to add ThemeId column
-- ************************************************************
--

USE [PermanentPortal]
GO


IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('properties')
						AND syscolumns.name = 'ThemeId')
BEGIN
	ALTER TABLE properties ADD [ThemeId] INT  NOT NULL DEFAULT(1)
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
			WHERE CONSTRAINT_CATALOG = 'PermanentPortal'
			AND TABLE_NAME ='properties'
			AND CONSTRAINT_NAME = 'PK_PropertieswithPartnerId')		

BEGIN
	ALTER TABLE properties DROP 
		CONSTRAINT [PK_PropertieswithPartnerId]


	ALTER TABLE [dbo].[properties] ADD 
	CONSTRAINT [PK_PropertieswithPartnerId] PRIMARY KEY  CLUSTERED 
	(
		[pName],
		[AID],
		[GID],
		[PartnerId],
		[ThemeId]
	)  ON [PRIMARY] 

END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 748
SET @ScriptDesc = 'Updated Properties Table to add ThemeId column'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
