-- *************************************************************************************
-- NAME 		: DUP0752_Properties_To_Turn_Functional_Areas_On_Or_Off_For_White_Labelling.sql
-- DESCRIPTION 		: Properties Added to turn functionalities on or off on homepage and mini home pages.
-- AUTHOR		: Amit Patel
-- *************************************************************************************


USE [PermanentPortal]
GO

-----------------------------------------------------------------
--  Property to set Door to Door Journey functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='DoorToDoorJourneyAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'DoorToDoorJourneyAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('DoorToDoorJourneyAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Find A Train functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FindATrainAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FindATrainAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FindATrainAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Find A Flight functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FindAFlightAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FindAFlightAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FindAFlightAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Find A Car Route functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FindACarAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FindACarAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FindACarAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Find A Coach functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FindACoachAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FindACoachAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FindACoachAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set City To City Journey Compare functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='CompareCityToCityJourneyAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'CompareCityToCityJourneyAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('CompareCityToCityJourneyAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Plan A Day Trip functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='PlanADayTripAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'PlanADayTripAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('PlanADayTripAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Plan To Park And Ride functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='PlanToParkAndRideAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'PlanToParkAndRideAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('PlanToParkAndRideAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Find A Bus functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FindABusAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FindABusAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FindABusAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO


-----------------------------------------------------------------
--  Property to set Find A Station functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FindAStationAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FindAStationAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FindAStationAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Journey Planner Location Map (Find a Map) functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='JourneyPlannerLocationMapAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'JourneyPlannerLocationMapAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('JourneyPlannerLocationMapAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Traffic Maps functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='NetworkMapsAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'NetworkMapsAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('NetworkMapsAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Network Maps functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='TrafficMapsAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'TrafficMapsAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('TrafficMapsAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Live Travel News functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='TravelNewsAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'TravelNewsAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('TravelNewsAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Departure Boards functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='DepartureBoardsAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'DepartureBoardsAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('DepartureBoardsAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Link To Our Website functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='LinkToWebsiteAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'LinkToWebsiteAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('LinkToWebsiteAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Download Toolbar functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='ToolbarDownloadAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'ToolbarDownloadAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('ToolbarDownloadAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Mobile Demonstrator (TD on Move) functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='MobileDemonstratorAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'MobileDemonstratorAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('MobileDemonstratorAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Check Journey CO2 functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='CheckJourneyCO2Available' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'CheckJourneyCO2Available'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('CheckJourneyCO2Available','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Feedback functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FeedbackAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FeedbackAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FeedbackAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Related Sites functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='RelatedSitesAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'RelatedSitesAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('RelatedSitesAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set FAQ functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FAQAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FAQAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FAQAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Digital TV Info functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='DigitalTVInfoAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'DigitalTVInfoAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('DigitalTVInfoAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Tips And Tools functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='TipsAndToolsAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'TipsAndToolsAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('TipsAndToolsAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set Home Tab Button on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='HomeImageButtonAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'HomeImageButtonAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('HomeImageButtonAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set PlanAJourney Button on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='PlanAJourneyImageButtonAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'PlanAJourneyImageButtonAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('PlanAJourneyImageButtonAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set FindAPlace Button on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='FindAPlaceImageButtonAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'FindAPlaceImageButtonAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('FindAPlaceImageButtonAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set LiveTravel Button on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='LiveTravelImageButtonAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'LiveTravelImageButtonAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('LiveTravelImageButtonAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set TipsAndTools Button on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='TipsAndToolsImageButtonAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'TipsAndToolsImageButtonAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('TipsAndToolsImageButtonAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

-----------------------------------------------------------------
--  Property to set LoginRegister Button on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='LoginRegisterImageButtonAvailable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'LoginRegisterImageButtonAvailable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('LoginRegisterImageButtonAvailable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 752
SET @ScriptDesc = 'Properties Added to turn functionalities on or off on homepage and mini home pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
