-- ***********************************************
-- NAME 		: DUP0937_DirectGov_4_Content.sql
-- DESCRIPTION 	: Script to add specific content for a Theme - DirectGov
-- AUTHOR		: Dan Gath
-- DATE			: 30 Apr 2008 12:15:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT
SET @ThemeId = 5

----------------------------------------------------------
-- Header text
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.headerHomepageLink.AlternateText', 'Directgov', 'Directgov'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.TDSmallBannerImage.AlternateText', 'Directgov', 'Directgov'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.defaultActionButton.AlternateText', 'Directgov', 'Directgov'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableHeaderControl.transportDirectLogoImg.AlternateText', 'Directgov - Public services all in one place', 'Directgov - Public services all in one place'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableHeaderControl.connectingPeopleImg.AlternateText', 'Provided by Transport Direct', 'Provided by Transport Direct'


----------------------------------------------------------
-- Footer links
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FooterControl1.ContactUsLinkButton', 'Contact Transport Direct', 'cy Contact Transport Direct'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FooterControl1.AboutLinkButton', 'About Transport Direct', 'cy About Transport Direct'


----------------------------------------------------------
-- Contact us page
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FeedbackInitialPage.ContactUsLabel', 'Contact Transport Direct', 'cy Contact Transport Direct'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FeedbackInitialPage.labelTitle.Text', 'Send Transport Direct your feedback', 'cy Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.imageFeedback.AlternateText', 'Send Transport Direct your feedback', 'cy Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.imageFeedbackSkipLink.AlternateText', 'Skip to Send Transport Direct your feedback', 'cy Skip to Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.lblFeedback', 'Send Transport Direct <br /> your feedback', 'cy Send Transport Direct <br />your feedback'

----------------------------------------------------------
-- About us page
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 19, 'TitleText', '/Channels/TransportDirect/About/AboutUs', 'About Transport Direct', 'cy About Transport Direct'


----------------------------------------------------------
-- HomePage - Tips and Tools panel
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 15, 'TDTipsHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'<DIV class="Column2Header">
<H1><SPAN class="txtsevenbwl">Tips and tools</SPAN></H1>
<A class="txtsevenbwrlink" title="Go to Tips and tools page" href="/Web2/Tools/Home.aspx">More... </A><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>
<DIV></DIV>
<DIV class="clearboth"></DIV><DIV class="Column2Content2">
<TABLE class="TipsToolsTable" cellSpacing="5" summary="">
<TBODY>
<TR>
<TD class="TipsToolsIconPadding"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx"><IMG title="Check journey CO2" height="30" alt="Check CO2 emissions" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Co2_30x30.gif" width="30"></A></TD>
<TD><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check CO2 emissions</A></TD></TR>
<TR>
<TD class="TipsToolsIconPadding"><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492"><IMG title="Services available on your mobile" height="30" alt="Services available on your mobile" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif" width="30"></A></TD>
<TD><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Get departures on your mobile</A></TD></TR>
</TBODY></TABLE></DIV>', 
'<DIV class="Column2Header">
<H1><SPAN class="txtsevenbwl">Awgrymiadau a theclynnau</SPAN></H1><A class="txtsevenbwrlink" title="Ewch i''r dudalen Awgrymiadau a thedynnau" href="/Web2/Tools/Home.aspx">Mwy... </A><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>
<DIV></DIV>
<DIV class="clearboth"></DIV><DIV class="Column2Content2">
<TABLE class="TipsToolsTable" cellSpacing="5" summary="">
<TBODY>
<TR>
<TD class="TipsToolsIconPadding"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx"><IMG title="Mesur CO2 y siwrnai" height="30" alt="Mesur CO2 y siwrnai" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/Co2_30x30.gif" width="30"></A></TD>
<TD><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Mesur CO2 y siwrnai</A></TD></TR>
<TR>
<TD class="TipsToolsIconPadding"><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" ><IMG title="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" height="30" alt="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif" width="30"></A></TD>
<TD><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Derbyniwch ymadawiadau byw ar eich ff&#244;n symudol</A></TD></TR>
</TBODY></TABLE></DIV>'

GO


------------------------------------------------------------------------
-- Plan a Journey Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5


EXEC AddtblContent
@ThemeId, 18, 'PlanAJourneyInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/Home', 
'<DIV class="MinihomeHyperlinksInfoContent">  <DIV class="MinihomeHyperlinksInfoHeader">  <DIV class="txtsevenbbl">Getting what you want from the journey planners</DIV><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="MinihomeSoftContent">  <P>You can plan a journey in a number of different ways to suit your needs. </P><BR>  <H3>Plan me a journey door to door...</H3><BR><BR>  <P>The simplest way to search is using the <A href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">door-to-door journey planner</A>, which searches for up to five journey options - by joined-up public transport or by car. You can plan from postcodes, places, stations and even local attractions. </P><BR>  <P>You can type in where and when you want to travel from and travel to... </P><IMG style="PADDING-RIGHT: 10px" alt="An image showing a summary of journey results" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneySummary.JPG" align="left" border="0">   <P>...and the system will give you a list of options to choose from. </P><BR clear="left"><BR><IMG style="PADDING-RIGHT: 10px; PADDING-LEFT: 15px" alt="An image showing a diagram of the detail of a journey plan" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/journey_details_500L.GIF" align="right" border="0">   <p>Highlight your preferred journey, the "Details" button allows you to see step-by-step directions, including any connections you need to make, stations names, interchange times or driving instructions if you have selected the car journey. Some of the images and text on the Details page contain links to further useful information, too.</p>  <P>&nbsp;</P>  <P>The "Maps" and "Tickets/Costs" buttons allow you to see route maps, ticket prices and driving costs. <BR><BR>By clicking "Tickets/Costs", you can check the prices and availability of rail and coach tickets. If you want to book, we can automatically pass your journey details to one of our partner retailer sites so that you can buy online.<BR><BR>Similarly, you can see your route, or individual sections of it, on a map by clicking the "map button". You can also list stops for a service by clicking on the transport icon in your journey itinerary. </P><IMG alt="An image of a map showing the route of a specific journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyMap.JPG" align="left" border="0">   <P><IMG alt="An image showing a sample of car driving instructions" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyCarInstructions.JPG" align="top" border="0"><BR clear="left"></P>  <P>&nbsp;</P>  <H3>I know how I want to travel...</H3>  <P>&nbsp;</P>  <P>Perhaps you have already decided what form of transport to use for the main part of your journey. <BR><BR>In this case you would be better off starting with <A href="/Web2/JourneyPlanning/FindTrainInput.aspx">Find a train</A>, <A href="/Web2/JourneyPlanning/FindFlightInput.aspx">Find a flight</A>, <A href="/Web2/JourneyPlanning/FindCarInput.aspx">Find a car route</A> or <A href="/Web2/JourneyPlanning/FindCoachInput.aspx">Find a coach</A>. These will list journeys for just that type of transport. </P><BR><BR><IMG alt="Image showing the quick planner icons on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyQuickPlanners.JPG" border="0">   <P>&nbsp;</P>  <P>If you use <A href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Find a Train</A>, you can choose between a search by time or by price. A search by price allows you to choose from a range of fares before you see the journey details relevant to that ticket price.</P>  <P>&nbsp;</P>  <p>You may also want to compare train, plane, coach and car journeys between two cities or towns in Britain on a given day. You can do this using <a href="/Web2/JourneyPlanning/FindTrunkInput.aspx">compare how to get from city to city</a>.</p>  <P>&nbsp;</P>  <P>Alternatively you may want to find your nearest station or car park and then plan a journey to or from there. Or find a place on a map and then plan to or from there. This is easy to do - see our <A href="/Web2/Maps/Home.aspx">Find a Place</A> page for more details.</P>  <P>&nbsp;</P>  <H3>Amending my chosen journey</H3>  <P>&nbsp;</P>  <P>Once you have found a journey you want, you can add further parts to your journey or amend some or all of your journey. </P>  <TABLE class="txtseven" cellSpacing="0" cellPadding="2" border="0">  <TBODY>  <TR>  <TD><IMG alt="Image representing the action of adding to the overall journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyExtend.JPG" border="0"></TD>  <TD>You can find the main part of your journey and then extend the plan to show how to get from the station to your door by car or public transport. </TD></TR>  <TR>  <TD><IMG alt="Image representing the action of changing the journey plan" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyReplace.JPG" border="0"></TD>  <TD>You can modify your journey by replacing a section that uses public transport with a car journey, for example to travel home from the station by taxi rather than by bus. </TD></TR>  <TR>  <TD><IMG alt="Image representing the action of adjusting the timings of a journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAdjust.JPG" border="0"></TD>  <TD>If you would like to allow more time at the places where you have to change transport, you can adjust your journey.</TD></TR></TBODY></TABLE>  <P>&nbsp;</P><IMG alt="Image of the �Amend date and time� feature" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAmend.JPG" border="0">   <P>&nbsp;</P>  <P>Once you have found some journey options, you can adjust the times and the routes, either by clicking the "Amend" button or by using the "Amend date and time" feature, at the bottom of the page.</P>  <P>&nbsp;</P>  <H3>Can you remember my journey request? </H3>  <P>&nbsp;</P>  <P>Once you have found a journey, you can save it as a bookmark ("favourite") in your browser...</P>  <P>&nbsp;</P><IMG alt="Image showing feature to bookmark a journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyBookmark.JPG" border="0">   <P>&nbsp;</P>  <P>...and retrieve it at a future time from the "Favourites" menu in your browser. </P>  <P>&nbsp;</P><IMG alt="Screenshot showing the browser favourites menu bar" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyFavourites.jpg" border="0"> </DIV></DIV>',
'<DIV class="MinihomeHyperlinksInfoContent">  <DIV class="MinihomeHyperlinksInfoHeader">  <DIV class="txtsevenbbl">Dywedwch fwy wrthyf...<!-- New heading should read "Getting what you want from the journey planners" replacing "Tell me more" --></DIV><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="MinihomeSoftContent">  <P>Gallwch gynllunio eich siwrnai mewn nifer o wahanol ffyrdd i weddu i''ch anghenion. </P><BR>  <H3>Cynlluniwch siwrnai o ddrws i ddrws i mi...</H3><BR><BR>  <P>Y ffordd symlaf o chwilio yw defnyddio''r <A href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">cynllunydd siwrnai o ddrws-i-ddrws</A>, sy''n chwilio am hyd at bump o ddewisiadau o ran siwrneion � drwy gludiant cyhoeddus wedi ei gydlynu neu mewn car. Gallwch gynllunio o godau post, lleoedd, gorsafoedd a hyd yn oed atyniadau lleol. </P><BR>  <P>Gallwch deipio i mewn ble a phryd y dymunwch deithio ohono a theithio iddo... </P><IMG style="PADDING-RIGHT: 10px" alt="Delwedd yn dangos crynodeb o ganlyniadau''r siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneySummary.JPG" align="left" border="0">   <P>...a bydd y system yn rhoi rhestr o ddewisiadau i chi ddewis ohonynt. </P><BR clear="left"><BR><IMG style="PADDING-RIGHT: 10px; PADDING-LEFT: 15px" alt="Delwedd yn dangos diagram o fanylion cynllun siwrnai" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/journey_details_500L.GIF" align="right" border="0">   <P>Tynnwch sylw at eich hoff siwrnai, yna cliciwch ar ''Manylion'' i weld cyfarwyddiadau manwl, gan gynnwys unrhyw gysylltiadau y bydd angen i chi eu gwneud, enwau''r gorsafoedd, amserau rhyng-newid neu gyfarwyddiadau gyrru os ydych wedi dewis y siwrnai car. Mae rhai o''r delweddau a''r testun ar y dudalen Manylion yn cynnwys dolennau i wybodaeth ddefnyddiol arall hefyd. </P>  <P>&nbsp;</P>  <P>Mae''r botymau ''Mapiau'' a ''Tocynnau/Costau'' yn caniat�u i chi weld mapiau o lwybrau, prisiau tocynnau a chostau gyrru. <BR><BR>Drwy glicio ar ''Tocynnau/Costau'' gallwch wirio''r prisiau ac argaeledd tocynnau rheilffordd a bysiau moethus. Os dymunwch archebu, gallwn drosglwyddo manylion eich siwrnai yn awtomatig i safle adwerthu un o''n partneriaid fel y gallwch brynu ar-lein.<BR><BR>Yn yr un modd, gallwch weld eich llwybr neu adrannau unigol ohono, ar fap drwy glicio ar ''botwm y map''. Gallwch hefyd restru arosfannau ar gyfer gwasanaeth drwy glicio ar yr eicon cludiant yn nisgrifiad eich siwrnai. </P><IMG alt="Delwedd o fap yn dangos llwybr siwrnai benodol" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyMap.JPG" align="left" border="0">   <P><IMG alt="Delwedd yn dangos sampl o''r cyfarwyddiadau gyrru car" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyCarInstructions.JPG" align="top" border="0"><BR clear="left"></P>  <P>&nbsp;</P>  <H3>Rwy''n gwybod sut rydw i eisiau teithio...</H3>  <P>&nbsp;</P>  <P>Efallai eich bod eisoes wedi penderfynu pa fath o gludiant i''w ddefnyddio ar gyfer prif ran eich siwrnai. <BR><BR>Yn yr achos hwn, byddai''n well i chi ddechrau gyda <A href="/Web2/JourneyPlanning/FindTrainInput.aspx">Canfyddwch dr�n</A>, <A href="/Web2/JourneyPlanning/FindFlightInput.aspx">Canfyddwch ehediad</A>, <A href="/Web2/JourneyPlanning/FindCarInput.aspx">Canfyddwch lwybr car</A> neu <A href="/Web2/JourneyPlanning/FindCoachInput.aspx">Canfyddwch fws moethus</A>. Bydd y rhain yn rhestru''r siwrneion am y math hwnnw o gludiant yn unig. </P><BR><BR><IMG alt="Delwedd yn dangos eiconau''r cynllunydd cyflym ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyQuickPlanners.JPG" border="0">   <P>&nbsp;</P>  <P>Os defnyddiwch <A href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Canfyddwch Dr�n</A>, gallwch ddewis rhwng chwilio yn �l amser neu yn �l pris. Drwy chwilio yn �l pris gallwch ddewis o ystod o brisiau cyn i chi weld manylion y siwrnai sy''n berthnasol i''r pris tocyn hwnnw.</P>  <P>&nbsp;</P>  <P>Efallai hefyd y dymunwch gymharu siwrneion tr�n, awyren a bws moethus rhwng dwy ddinas neu dref ym Mhrydain ar ddiwrnod arbennig. Gallwch wneud hyn drwy ddefnyddio <A href="/Web2/JourneyPlanning/FindTrunkInput.aspx">cymharu siwrneion dinas-i-ddinas</A>. </P>  <P>&nbsp;</P>  <P>Neu efallai y dymunwch ddod o hyd i''ch gorsaf neu faes parcio agosaf ac yna cynllunio siwrnai i neu oddi yno. Neu ddarganfod lle ar fap ac yna cynllunio i fynd yno neu oddi yno. Mae hyn yn hawdd � gweler ein tudalen <A href="/Web2/Maps/Home.aspx">Canfyddwch le</A> am fwy o fanylion.</P>  <P>&nbsp;</P>  <H3>Diwygio fy newis siwrnai</H3>  <P>&nbsp;</P>  <P>Wedi i chi ddarganfod siwrnai a ddymunwch, gallwch ychwanegu rhannau pellach at eich siwrnai neu ddiwygio rhywfaint o''ch siwrnai neu''r siwrnai i gyd. </P>  <TABLE class="txtseven" cellSpacing="0" cellPadding="2" border="0">  <TBODY>  <TR>  <TD><IMG alt="Delwedd yn cynrychioli''r weithred o ychwanegu at y siwrnai gyffredinol" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyExtend.JPG" border="0"></TD>  <TD>Gallwch ddarganfod prif ran eich siwrnai ac yna ymestyn y cynllun i ddangos sut i fynd o''r orsaf i''ch drws mewn car neu gludiant cyhoeddus. </TD></TR>  <TR>  <TD><IMG alt="Delwedd yn cynrychioli''r weithred o newid cynllun y siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyReplace.JPG" border="0"></TD>  <TD>Gallwch ddiwygio eich siwrnai drwy amnewid adran sy''n defnyddio cludiant cyhoeddus gyda siwrnai mewn car, er enghraifft i deithio adref o''r orsaf mewn tacsi yn hytrach nag mewn bws. </TD></TR>  <TR>  <TD><IMG alt="Delwedd yn cynrychioli''r weithred o addasu amserau siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAdjust.JPG" border="0"></TD>  <TD>Os hoffech gael mwy o amser yn y mannau lle mae''n rhaid i chi newid cludiant, gallwch addasu eich siwrnai.</TD></TR></TBODY></TABLE>  <P>&nbsp;</P><IMG alt="Delwedd o''r nodwedd ''Newid dyddiad/amser''" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAmend.JPG" border="0">   <P>&nbsp;</P>  <P>Cyn gynted ag yr ydych wedi darganfod rhai dewisiadau ar gyfer siwrneion, gallwch addasu''r amserau a''r llwybrau, naill ai drwy glicio''r botwm ''Newid'' neu drwy ddefnyddio''r nodwedd ''Newid dyddiad/amser'' ar waelod y dudalen.</P>  <P>&nbsp;</P>  <H3>Fedrwch chi gofio fy nghais am siwrnai? </H3>  <P>&nbsp;</P>  <P>Wedi i chi ganfod siwrnai, gallwch ei chadw fel nod llyfr (''ffefryn'') yn eich porwr...</P>  <P>&nbsp;</P><IMG alt="Delwedd yn dangos nodwedd i roi nod llyfr ar siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyBookmark.JPG" border="0">   <P>&nbsp;</P>  <P>...a dod o hyd iddi rywbryd yn y dyfodol o''r ddewislen ''Ffefrynnau'' yn eich porwr. </P>  <P>&nbsp;</P><IMG alt="Delwedd o''r sgr�n yn dangos bar dewislen ffefrynnau''r porwr" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyFavourites.jpg" border="0"> </DIV></DIV>'

GO


------------------------------------------------------------------------
-- Find A Place Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 17, 'FindAPlaceInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/Home', 
'<DIV class="MinihomeHyperlinksInfoContent">  <DIV class="MinihomeHyperlinksInfoHeader">  <DIV class="txtsevenbbl">Finding the place you want</DIV><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="MinihomeSoftContent">  <H3>Find me a map...</H3><BR><BR>  <P>You can <A href="/Web2/Maps/JourneyPlannerLocationMap.aspx">find a map</A> of a place, city, attraction, station, stop, address or postcode. </P>  <P>&nbsp;</P><IMG style="PADDING-LEFT: 10px" alt="Image of a map showing a specific location" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceLocationMap1.JPG" align="right" border="0">   <P>You can view the local transport stops and stations in the area and local amenities such as hotels, attractions and public facilities.</P><BR clear="right">  <P>&nbsp;</P>  <H3>Now plan me a journey there...</H3>  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 70px; PADDING-LEFT: 10px" alt="Screenshot of a Transport Direct map and the buttons from which to plan a journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceMapPlan1.JPG" align="right" border="0">You can then choose to plan a journey to or from the location shown on the map.</P><BR clear="right">  <P>&nbsp;</P>  <H3>Where''s the nearest transport?</H3>  <P>&nbsp;</P>  <P>Alternatively, you may wish to <A href="/Web2/JourneyPlanning/FindAStationInput.aspx">find the nearest stations &amp; airports</A> to a location.</P><BR><IMG alt="Screenshot of the output from the Find nearest station/airport feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearest1.JPG" align="right" border="0">   <P>You can view them as a list, in order of their distance from your location...</P><BR clear="right">  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 10px" alt="Image of map showing numbered locations" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearestMap1.JPG" align="left" border="0">...or you can view them on a map.</P><BR clear="left">  <P>&nbsp;</P>  <H3>Now plan me a journey there...</H3>  <P>&nbsp;</P>  <P><IMG style="PADDING-LEFT: 10px" alt="Screenshot of the results from the Find nearest station/airport feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceStationJourneyResults.JPG" align="right" border="0">The closest station/airport is already selected. Once you have selected the station/airport required, click Travel from or Travel to. Then repeat for the other journey leg and click next.<BR><BR>You will then be able to ''Find journeys between stations/airports'' from the selection you have made.<BR><BR>You may not always get journeys to or from all of your selected stations but the results returned will be the best journeys available between the chosen origin(s) and destination(s).</P><BR clear="right">  <P>&nbsp;</P>  <H3>Where''s the nearest car park?</H3>  <P>&nbsp;</P>  <P>Similarly, you may wish to <A href="/Web2/JourneyPlanning/FindCarParkInput.aspx">find the nearest car parks</A> to a location.</P><BR><IMG alt="Screenshot of the output from the Find nearest car park feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkResults.JPG" align="right" border="0">   <P>You can view them as a list, in order of their distance from your location, the total number of spaces, and if they have disabled spaces...</P><BR clear="right">  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 10px" alt="Image of map showing available car parks" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkMap.JPG" align="left" border="0">...or you can view them on a map.</P><BR clear="left">  <P>&nbsp;</P>  <H3>Now plan me a journey there...</H3>  <P>&nbsp;</P>  <P><IMG style="PADDING-LEFT: 10px" alt="Screenshot of the output from the Find nearest car park feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkJourneyResults.JPG" align="right" border="0">The closest car park is already selected. Once you have selected the option required, click Drive from or Drive to.<BR><BR>You will then be able to ''Plan a car route'' from/to the car park selected.</P><BR clear="right">  <P>&nbsp;</P>  <H3>What will the roads be like?</H3>  <P>&nbsp;</P>  <P>If you are planning to visit a place, you may want to know what the traffic will be like when you travel there.</P><BR>  <P><IMG style="PADDING-LEFT: 10px" alt="Image of a map showing predicted traffic levels using different colours to represent estimated congestion" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceTrafficMap1.JPG" align="right" border="0">Our <A href="/Web2/Maps/TrafficMaps.aspx">traffic maps</A> are based on recorded traffic levels over the last few years and display an accurate prediction of the likely traffic levels at your precise time of travel.</P><BR clear="right">  <P>&nbsp;</P>  <H3>I need a tube map...</H3>  <P>&nbsp;</P>  <P>Finally, you may just need a map showing part of the rail network, bus routes or a map of the London Underground. Our <A href="/Web2/Maps/NetworkMaps.aspx">transport network maps</A> page links you to a range of sites containing these maps. </P></DIV></DIV>',
'<DIV class="MinihomeHyperlinksInfoContent">  <DIV class="MinihomeHyperlinksInfoHeader">  <DIV class="txtsevenbbl">Dywedwch fwy wrthyf...</DIV><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="MinihomeSoftContent">  <H3>Darganfyddwch fap i mi...</H3><BR><BR>  <P>Gallwch <A href="/Web2/Maps/JourneyPlannerLocationMap.aspx">ddarganfyddwch map</A> o le, dinas, atyniad, gorsaf, arhosfan, cyfeiriad neu god post. </P>  <P>&nbsp;</P><IMG style="PADDING-LEFT: 10px" alt="Delwedd o fap yn dangos lleoliad penodol" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceLocationMap.JPG" align="right" border="0">   <P>Gallwch weld yr arosfannau a''r gorsafoedd cludiant lleol yn yr ardal a mwynderau lleol fel gwestai, atyniadau a chyfleusterau cyhoeddus.</P><BR clear="right">  <P>&nbsp;</P>  <H3>Yn awr cynlluniwch siwrnai i mi yno...</H3>  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 70px; PADDING-LEFT: 10px" alt="Delwedd sgr�n o fap Transport Direct a''r botymau y bwriadwch gynllunio siwrneion ohonynt" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceMapPlan.JPG" align="right" border="0">Yna gallwch ddewis cynllunio siwrnai i neu o''r lleoliad a ddangosir ar y map.</P><BR clear="right">  <P>&nbsp;</P>  <H3>Ble mae''r cludiant agosaf?</H3>  <P>&nbsp;</P>  <P>Neu efallai y dymunwch <A href="/Web2/JourneyPlanning/FindAStationInput.aspx">dod o hyd i''r gorsafoedd a''r meysydd awyr agosaf</A> at leoliad.</P><BR><IMG alt="Delwedd sgr�n o''r allbwn o''r nodwedd Dod ohyd i''r orsaf/maes awyr agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearest.JPG" align="right" border="0">   <P>Gallwch edrych arnynt fel rhestr, yn nhrefn eu pellter o''ch lleoliad...</P><BR clear="right">  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 10px" alt="Delwedd o fap yn dangos lleoliadau wedi eu rhifo" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearestMap.JPG" align="left" border="0">...neu gallwch eu gweld ar fap.</P><BR clear="left">  <P>&nbsp;</P>  <H3>Yn awr cynlluniwch siwrnai i mi yno...</H3>  <P>&nbsp;</P>  <P><IMG style="PADDING-LEFT: 10px" alt="Llun sgr�n o''r allbwn o''r nodwedd Dod o hyd i''r orsaf/maes awyr agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceStationJourneyResults.JPG" align="right" border="0">Mae''r orsaf/maes awyr agosaf wedi ei dicio yn barod. Wedi i chi ddewis yr opsiwn/opsiynau angenrheidiol, cliciwch ar Teithio o neu Teithio i. Yna ailadroddwch hyn ar gyfer yr adran arall o''r siwrnai a chliciwch nesaf.<BR><BR>Yna byddwch yn gallu ''Darganfyddwch siwrneion rhwng gorsafoedd/meysydd awyr'' o''r dewis yr ydych wedi ei wneud.<BR><BR>Efallai na fydd wastad yn bosibl i chi gael siwrneion sy''n gadael neu''n cyrraedd pob gorsaf a ddewiswyd gennych ond byddwn yn dychwelyd manylion y siwrneion gorau sydd ar gael rhwng y man(nau) cychwyn a''r cyrchfan(nau) a ddewiswyd.</P><BR clear="right">  <P>&nbsp;</P>  <H3>Ble mae''r maes parcio agosaf?</H3>  <P>&nbsp;</P>  <P>Yn yr un modd, mae''n bosibl y byddwch yn dymuno <A href="/Web2/JourneyPlanning/FindCarParkInput.aspx">darganfod y meysydd parcio agosaf</A> i leoliad.</P><BR><IMG alt="Llun sgr�n o''r allbwn o''r nodwedd Darganfyddwch y maes parcio agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkResults.JPG" align="right" border="0">   <P>Gallwch eu gweld fel rhestr, yn nhrefn eu pellter o''ch lleoliad chi�</P><BR clear="right">  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 10px" alt="Delwedd o fap yn dangos y meysydd parcio sydd ar gael" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkMap.JPG" align="left" border="0">...neu gallwch eu gweld ar fap.</P><BR clear="left">  <P>&nbsp;</P>  <H3>Yn awr cynlluniwch siwrnai i mi yno...</H3>  <P>&nbsp;</P>  <P><IMG style="PADDING-LEFT: 10px" alt="Llun sgr�n o''r allbwn o''r nodwedd Darganfyddwch y maes parcio agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkJourneyResults.JPG" align="right" border="0">Mae''r maes parcio agosaf wedi ei ddewis yn barod. Wedi i chi ddewis yr opsiwn angenrheidiol, cliciwch ar Gyrrwch o neu Gyrrwch i.<BR><BR>Yna byddwch yn gallu ''Cynlluniwch lwybr car'' o/i''r maes parcio a ddewiswyd.</P><BR clear="right">  <P>&nbsp;</P>  <H3>Sut rai fydd y ffyrdd?</H3>  <P>&nbsp;</P>  <P>Os ydych chi''n cynllunio ymweld � lle, efallai y byddwch yn dymuno gwybod sut fydd y traffig pan deithiwch yno.</P><BR>  <P><IMG style="PADDING-LEFT: 10px" alt="Delwedd o fap yn dangos y lefelau traffig a ragfynegir gan ddefnyddio lliwiau gwahanol i gynrychioli amcangyfrif o''r tagfeydd" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceTrafficMap.JPG" align="right" border="0">Seilir ein <A href="/Web2/Maps/TrafficMaps.aspx">mapiau traffig</A> ar lefelau traffig a gofnodwyd dros yr ychydig flynyddoedd diwethaf ac maent yn dangos rhagfynegiad cywir o''r lefelau traffig tebygol ar yr union adeg y byddwch yn teithio.</P><BR clear="right">  <P>&nbsp;</P>  <H3>Mae arnaf angen map o''r trenau tanddaearol...</H3>  <P>&nbsp;</P>  <P>Yn olaf, efallai y bydd arnoch angen map yn dangos rhan o rwydwaith y rheilffordd, y llwybrau bysiau neu fap o drenau tanddaearol Llundain. Mae ein tudalen <A href="/Web2/Maps/NetworkMaps.aspx">mapiau''r rhwydwaith cludiant</A> yn eich cysylltu ag ystod o safleoedd yn cynnwys y mapiau hyn. </P></DIV></DIV>'

GO


------------------------------------------------------------------------
-- Live Travel Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5


EXEC AddtblContent
@ThemeId, 16, 'HomeTravelInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/LiveTravel/Home', 
'<DIV class="MinihomeHyperlinksInfoContent">  <DIV class="MinihomeHyperlinksInfoHeader">  <DIV class="txtsevenbbl">Finding your news</DIV><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="MinihomeSoftContent">  <H3>Are there any incidents that could affect my journey?</H3>  <P>&nbsp;</P><IMG style="PADDING-LEFT: 30px" alt="Image of a map showing incident symbols" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidents.JPG" align="right" border="0">   <P>You can check for any incidents on the roads or the public transport network that may affect your journey, either on a map or as a list, on our <A href="/Web2/LiveTravel/TravelNews.aspx">Live Travel news</A> page.</P><BR clear="right">  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 40px" alt="Screenshot of the map with additional hover-over info" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidentPopup1.JPG" align="left" border="0"></P>  <P>Hover-over the incident symbols on the map to find further details. <BR><BR>We also show future planned roadworks and public transport engineering works.</P><BR clear="left">  <P>&nbsp;</P>  <H3>When is the next train? </H3>  <P>&nbsp;</P>  <P>Find out when the next train or bus leaves, or whether there are any current delays to your service, by visiting our <A href="/Web2/LiveTravel/DepartureBoards.aspx">departure boards</A> page.</P></DIV></DIV>',
'<DIV class="MinihomeHyperlinksInfoContent">  <DIV class="MinihomeHyperlinksInfoHeader">  <DIV class="txtsevenbbl">Dywedwch fwy wrthyf...<!-- New heading should read "Finding your news" replacing "Tell me more" --></DIV><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="MinihomeSoftContent">  <H3>Oes yna unrhyw ddigwyddiadau a allai effeithio ar fy siwrnai?</H3>  <P>&nbsp;</P><IMG style="PADDING-LEFT: 30px" alt="Delwedd o fap yn dangos symbolau digwyddiadau" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidents.JPG" align="right" border="0">   <P>Gallwch weld a oes unrhyw ddigwyddiadau ar y ffyrdd neu''r rhwydwaith cludiant cyhoeddus a all effeithio ar eich siwrnai, naill ai ar fap neu fel rhestr, ar ein tudalen <A href="/Web2/LiveTravel/TravelNews.aspx">Newyddion teithio byw</A>.</P><BR clear="right">  <P>&nbsp;</P>  <P><IMG style="PADDING-RIGHT: 40px" alt="Delwedd sgr�n o fap gyda gwybodaeth ychwanegol i hofran drosto" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidentPopup2.JPG" align="left" border="0"></P>  <P>Arhoswch uwchben y symbolau digwyddiadau ar y map i ddarganfod manylion pellach. <BR><BR>Rydym hefyd yn dangos gwaith ffyrdd sy''n cael eu cynllunio yn y dyfodol a gwaith peirianyddol yn ymwneud � chludiant cyhoeddus.</P><BR clear="left">  <P>&nbsp;</P>  <H3>Pryd mae''r tr�n nesaf? </H3>  <P>&nbsp;</P>  <P>Darnganfyddwch pryd mae''r tr�n neu''r bws nesaf yn gadael, neu a oes unrhyw oedi i''ch gwasanaeth chi ar hyn o bryd drwy ymweld �''n tudalen <A href="/Web2/LiveTravel/DepartureBoards.aspx">byrddau cyrraedd a chychwyn</A>.</P></DIV></DIV>'

GO


------------------------------------------------------------------------
-- Tips and tools Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 14, 'TipsToolsInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home'
-- ENGLISH
,'<div class="MinihomeHyperlinksInfoContent">
<div class="MinihomeHyperlinksInfoHeader">
<div class="txtsevenbbl">
Helping you get the most from Transport Direct
</div>
<!-- Following spaces help   formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice   wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<div class="MinihomeSoftContent">
<h3>Compare CO2 emissions for your journey...</h3>

<p>&nbsp;</p>

<p>You can now compare the CO2 emissions of the four main modes of transport (Car, Rail,
Bus/coach, and Plane) for your journey.</p><br>
<img alt="Screen shot of CO2 Emissions page" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissions2.jpg" align=
"right" border="0">

<p>You can do a simple emissions comparison by inputting a distance in miles or
kilometres. TD will tell you how much CO2 would be emitted if you travelled that distance
by car, train, bus, or plane.</p><br clear="right">

<p>&nbsp;</p>

<p><img alt="Screen shot of CO2 Emissions for your journey" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissionsJourney2.jpg"
align="left" border="0">Or look at the emissions for your journey by different modes of
transport by following the links from your journey details page.</p><br clear="left">

<p>&nbsp;</p>

<p>Go to the <a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">CO2
emissions</a> page to find out.</p>

<p>&nbsp;</p>

<h3>I use a screen-reader...</h3>

<p>&nbsp;</p>

<p>We aim to provide an equivalent experience for screen-reader users as well as users
who do not need this technology. In order for you to best understand how the site works
and how to get the most out of the journey planning features, visit the <a href=
"/Web2/About/Accessibility.aspx">Accessibility</a> section.</p>
</div>
</div>
'
-- WELSH
,'<div class="MinihomeHyperlinksInfoContent">
<div class="MinihomeHyperlinksInfoHeader">
<div class="txtsevenbbl">
Dywedwch fwy wrthyf...
<!-- New heading text should read "Helping you get the most from Transport Direct" replacing "Tell me more" -->
</div>
<!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<div class="MinihomeSoftContent">
<h3>Cymharwch allyriadau CO2 ar gyfer eich siwrnai...</h3>

<p>&nbsp;</p>

<p>Nawr fe allwch gymharu allyriadau CO2 y pedwar prif fath o drafnidiaeth (Car,
Tr&ecirc;n, Bws/coets, ac Awyren) ar gyfer eich siwrnai.</p><br>
&nbsp;

<p><img alt="Llun sgrin o dudalen Allyriadau CO2" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissions2.jpg" align=
"right" border="0">Gallwch gymharu allyriadau yn syml drwy nodi pellter mewn milltiroedd
neu gilometrau. Bydd Transport Direct yn dweud wrthych faint o CO2 fyddai''n cael ei
ollwng pe byddech chi''n teithio''r pellter hwnnw mewn car, tr&ecirc;n, bws, neu
awyren.</p><br clear="right">

<p>&nbsp;</p>

<p><img alt="Llun sgrin o Allyriadau CO2 ar gyfer eich siwrnai" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissionsJourney2.jpg"
align="left" border="0">Neu edrychwch ar yr allyriadau ar gyfer eich siwrnai yn &ocirc;l
gwahanol fathau o drafnidiaeth drwy ddilyn y cysylltau o dudalen manylion eich
siwrnai.</p><br clear="left">

<p>&nbsp;</p>

<p>Ewch i''r dudalen <a href=
"/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">allyriadau CO2</a> i gael
gwybod.</p>

<p>&nbsp;</p>

<h3>Rwy&rsquo;n defnyddio darllenwr sgr&icirc;n...</h3>

<p>&nbsp;</p>

<p>Anelwn at ddarparu profiad cyfwerth ar gyfer defnyddwyr darllenwyr sgr&icirc;n yn
ogystal &acirc; defnyddwyr nad oes arnynt angen y dechnoleg hon. Er mwyn i chi ddeall
orau sut mae''r safle yn gweithio a sut i gael y gorau o''r nodweddion cynllunio siwrnai,
ymwelwch &acirc;"r adran <a href=
"/TransportDirect/cy/About/Accessibility.aspx">Hygyrchedd</a> yn y tudalennau Amdanom
ni.</p>
</div>
</div>
'

GO


---------------------------------------------------------------
-- Home Page - Right hand info panel
---------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

-- Second Third items
EXEC AddtblContent
@ThemeId, 15, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', '<DIV class="Column3Header">
<DIV class="txtsevenbbl">Blue Badge map</DIV>
<DIV class="clearboth" ></DIV>
</DIV>
<DIV class="Column3Content">
<TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="VertAlignTop">
<IMG src="/Web2/app_themes/directgov/images/gifs/partner/bb.gif" alt="Blue Badge">
</TD>
<TD class="txtseven" vAlign="top">
The Blue Badge map shows Blue Badge parking bays, accessible toilets, council car parks, petrol stations, shopmobility centres, accessible 
beaches and train stations in over 100 locations across the UK.
<br><br>
Discover the <A href="http://bluebadge.direct.gov.uk/index.php?br_wid=1280&br_hgt=768" >Blue Badge map here</A>
</TD></TR></TBODY></TABLE></DIV>
<DIV class="Column3Header">
<DIV class="txtsevenbbl">Find schools and childcare in your area</DIV>
<DIV class="clearboth" ></DIV>
</DIV>
<DIV class="Column3Content">
<TABLE id="Table2" cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="VertAlignTop">
<IMG src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare">
</TD>
<TD class="txtseven" vAlign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br><br>
<A href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</A>
</TD></TR></TBODY></TABLE></DIV>', 

'<DIV class="Column3Header">
<DIV class="txtsevenbbl">Blue Badge map</DIV>
<DIV class="clearboth" ></DIV>
</DIV>
<DIV class="Column3Content">
<TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="VertAlignTop">
<IMG src="/Web2/app_themes/directgov/images/gifs/partner/bb.gif" alt="Blue Badge">
</TD>
<TD class="txtseven" vAlign="top">
The Blue Badge map shows Blue Badge parking bays, accessible toilets, council car parks, petrol stations, shopmobility centres, accessible 
beaches and train stations in over 100 locations across the UK.
<br><br>
Discover the <A href="http://bluebadge.direct.gov.uk/index.php?br_wid=1280&br_hgt=768" >Blue Badge map here</A>
</TD></TR></TBODY></TABLE></DIV>
<DIV class="Column3Header">
<DIV class="txtsevenbbl">Find schools and childcare in your area</DIV>
<DIV class="clearboth" ></DIV>
</DIV>
<DIV class="Column3Content">
<TABLE id="Table2" cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="VertAlignTop">
<IMG src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare">
</TD>
<TD class="txtseven" vAlign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br><br>
<A href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</A>
</TD></TR></TBODY></TABLE></DIV>'


-- Last item
EXEC AddtblContent
@ThemeId, 15, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', '<DIV class="Column3Header">
<DIV class="txtsevenbbl">Brush up on your Highway Code</DIV>
<DIV class="clearboth" ></DIV>
</DIV>
<DIV class="Column3Content">
<TABLE cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="VertAlignTop">
<IMG src="/Web2/app_themes/directgov/images/gifs/partner/highway_code.gif" alt="Highway Code">
</TD>
<TD class="txtseven">
The complete Highway Code is now available online. Wherever you are going, make sure you know the rules of the road before you set off.
<br><BR>
<A href="http://www.direct.gov.uk/en/TravelAndTransport/Highwaycode/index.htm" >Click here</A> to read the Highway Code
</TD></TR></TBODY></TABLE></DIV>', 

'<DIV class="Column3Header">
<DIV class="txtsevenbbl">Brush up on your Highway Code</DIV>
<DIV class="clearboth" ></DIV>
</DIV>
<DIV class="Column3Content">
<TABLE cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="VertAlignTop">
<IMG src="/Web2/app_themes/directgov/images/gifs/partner/highway_code.gif" alt="Highway Code">
</TD>
<TD class="txtseven">
The complete Highway Code is now available online. Wherever you are going, make sure you know the rules of the road before you set off.
<br><BR>
<A href="http://www.direct.gov.uk/en/TravelAndTransport/Highwaycode/index.htm" >Click here</A> to read the Highway Code
</TD></TR></TBODY></TABLE></DIV>'

GO


---------------------------------------------------------
-- Find a train input
---------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 50, 'TDFindTrainPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainInput', 
'<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</a> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>',

 '<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</A> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>'


-- Second Third items
EXEC AddtblContent
@ThemeId, 51, 'TDFindTrainPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput', 
'<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</A> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>',

 '<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</A> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>'


----------------------------------------------------------------
-- Sitemap
----------------------------------------------------------------


-- Live travel
EXEC AddtblContent
@ThemeId, 43, 'LiveTravelBody', '/Channels/TransportDirect/SiteMap/SiteMap', 
'<P>
<DIV class="smcSiteMapLink"><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492">Travel information on your mobile</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check Journey CO2</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/FeedbackPage.aspx">Provide feedback</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/RelatedSites.aspx">Related sites</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/RelatedSites.aspx#NationalTransport">National transport</A><BR>
<LI><A href="/Web2/About/RelatedSites.aspx#LocalPublicTransport">Local public transport</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Motoring">Motoring</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#MotoringCosts">Motoring Costs</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#CarSharing">Car Sharing</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Government">Government</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Help/NewHelp.aspx">Frequently Asked Questions</A><BR></DIV></P>
', 

'<P>
<DIV class="smcSiteMapLink"><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492">cy Travel information on your mobile</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check Journey CO2</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/FeedbackPage.aspx">Rhowch adborth</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/RelatedSites.aspx">Safleoedd cysylltiedig</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/RelatedSites.aspx#NationalTransport">Cludiant cenedlaethol</A><BR>
<LI><A href="/Web2/About/RelatedSites.aspx#LocalPublicTransport">Cludiant cyhoeddus lleol</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Motoring">Moduro</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#MotoringCosts">Costau moduro</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#CarSharing">Rhannu ceir</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Government">Llywodraeth</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Help/NewHelp.aspx">Cwestiynau a Ofynnir yn Aml</A><BR></DIV></P>
'

-- TDOnTheMove title
EXEC AddtblContent
@ThemeId, 43, 'TDOnTheMoveTitle', '/Channels/TransportDirect/SiteMap/SiteMap',
'<H3>About Transport Direct</H3>',
'<H3>Amdanom Transport Direct</H3>'

-- TDOnTheMove body
EXEC AddtblContent
@ThemeId, 43, 'TDOnTheMoveBody', '/Channels/TransportDirect/SiteMap/SiteMap',
'<P><DIV class="smcSiteMapLink"><A href="/Web2/About/AboutUs.aspx">About Transport Direct</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/AboutUs.aspx#EnablingIntelligentTravel">Enabling intelligent travel</A><BR>
<LI><A href="/Web2/About/AboutUs.aspx#WhoOperates">Who operates Transport Direct? </A>
<LI><A href="/Web2/About/AboutUs.aspx#WhoBuilds">Who builds this site?</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhatsNext">What''s next?</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/About/Accessibility.aspx">Accessibility</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/Details.aspx">Contact details</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/DataProviders.aspx">Data providers</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/PrivacyPolicy.aspx">Privacy policy</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/TermsConditions.aspx">Terms &amp; conditions</A><BR></DIV>
</P>', 

'<P><DIV class="smcSiteMapLink"><A href="/Web2/About/AboutUs.aspx">Amdanom Transport Direct</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/AboutUs.aspx#EnablingIntelligentTravel">Galluogi teithio deallus</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhoOperates">Pwy sy''n gweithredu Transport Direct? </A>
<LI><A href="/Web2/About/AboutUs.aspx#WhoBuilds">Pwy sy''n adeiladu a datblygu''r safle hwn?</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhatsNext">Beth nesaf?</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/About/Accessibility.aspx">Hygyrchedd</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/Details.aspx">Manylion cyswllt</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/DataProviders.aspx">Darparwyr data</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/PrivacyPolicy.aspx">Polisi preifatrwydd</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/TermsConditions.aspx">Amodau a thelerau</A><BR></DIV>
</P>'


EXEC AddtblContent
@ThemeId, 43, 'sitemapFooterNote', '/Channels/TransportDirect/SiteMap/SiteMap',
' ',
' '

GO

----------------------------------------------------------------
-- Tips and Tools home - Mobile Demonstrator Icon link
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.PartnerSpecific.hyperlinkTDOnTheMove.NavigateURL',
'http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492',
'http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.PartnerSpecific.hyperlinkTDOnTheMove.Target',
'_blank',
'_blank'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.lblTDOnTheMove', 'Travel information on your mobile', 'cy Travel information on your mobile'

GO


----------------------------------------------------------------
-- Ambiguity page
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FindCarParkInput.labelNote.Ambiguous', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FindStationInput.labelNote.StationMode.NoValid', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'ValidateAndRun.SelectFromList', 'Select an option from each list below.', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'VisitPlannerInput.Instructional.Ambiguity', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

GO


----------------------------------------------------------------
-- Amend tab images
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendCarDetailsTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendCarDetailsTabSelected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendCarDetailsTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendCarDetailsTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendCarDetailsTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendCarDetailsTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendDayTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendDayTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendViewTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendViewTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendViewTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendViewTabUnSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendViewTabUnSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendViewTabUnSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonCostSearchDateTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonCostSearchDateTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonFareTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendFareDetailsTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendFareDetailsTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonFareTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendFareDetailsTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendFareDetailsTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonStopoverTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendStopoverBlue.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendStopoverBlue.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonStopoverTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendStopoverGrey.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendStopoverGrey.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSaveTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SaveTabSelected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SaveTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSaveTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SaveTabUnselected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SaveTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSendTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SendTabSelected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SendTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSendTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SendTabUnselected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SendTabUnselected.gif'

----------------------------------------------------------------
-- Back to top arrow
----------------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'DepartureBoards.TopOfPage.HyperlinkImage', '/Web2/App_Themes/DirectGov/images/gifs/Partner/back_to_top_icon.jpg', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/uarrow_icon_slim.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'DepartureBoards.TopOfPage.Text', '', ''


GO


----------------------------------------------------------------
-- Powered by Transport Direct content
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langstrings', 'PoweredByControl.HTMLContent',
'<div class="Column3PoweredBy">
<div class="Column3Header Column3HeaderPoweredBy">
<div class="txtsevenbbl">
Provided by
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</div>
</div>
<div class="Column3Content Column3ContentPoweredBy">
<table>
<tr>
<td>
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/Partner/td_logo_4whbg.gif" alt="Provided by Transport Direct" />
</a>
</td>
</tr>
</table>
</div>
</div>',

'<div class="Column3PoweredBy">
<div class="Column3Header Column3HeaderPoweredBy">
<div class="txtsevenbbl">
Provided by
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</div>
</div>
<div class="Column3Content Column3ContentPoweredBy">
<table>
<tr>
<td>
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/Partner/td_logo_4whbg.gif" alt="Provided by Transport Direct" />
</a>
</td>
</tr>
</table>
</div>
</div>'

EXEC AddtblContent
@ThemeId, 1, 'langstrings', 'PoweredByControl.HTMLContent.LogoOnly',
'<div class="PoweredByLogo">
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/ProvidedBy1a.gif" alt="Provided by Transport Direct" />
</a>
</div>',

'<div class="PoweredByLogo">
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/ProvidedBy1a.gif" alt="Provided by Transport Direct" />
</a>
</div>'

----------------------------------------------------------------
-- Wait page
----------------------------------------------------------------

EXEC AddtblContent
@ThemeId, 32, 'MessageDefinition', '/Channels/TransportDirect/JourneyPlanning/WaitPage',
'We are always seeking to improve our service. If you cannot find what you want, please tell Transport Direct by clicking <b>Contact Transport Direct</b>',
'cy We are always seeking to improve our service. If you cannot find what you want, please tell Transport Direct by clicking <b>Contact Transport Direct</b>'


EXEC dbo.[AddtblContent]
@ThemeId, 1, 'langStrings', 'WaitPage.TitleTipOfTheDay',
'<b>Tip of the Day</b>',
'cy <b>Tip of the Day</b>'


----------------------------------------------------------------
-- Send to friend text 
----------------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSendLoginControl.labelLoginRegisterNote',
'This feature is currently not used within this service.',
'cy This feature is currently not used within this service.'


GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 937
SET @ScriptDesc = 'Content added for theme Directgov'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO