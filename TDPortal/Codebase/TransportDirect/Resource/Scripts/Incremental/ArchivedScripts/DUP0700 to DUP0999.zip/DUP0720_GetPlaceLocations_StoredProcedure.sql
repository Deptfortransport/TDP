-- ***********************************************
-- NAME 		: DUP0720_GetPlaceLocations_StoredProcedure.sql
-- DESCRIPTION 		: sql to setup the GetPlaceLocations stored 
--	`		: procedure, which returns all car locations for a specified TDNPGID
-- AUTHOR		: Dan Gath
-- ************************************************

USE [PermanentPortal]
GO
-------------------------------------------------------------------------
-- ADD STORED PROCEDURE
-------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetPlaceLocations]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetPlaceLocations]
GO

CREATE PROCEDURE [dbo].[GetPlaceLocations]
		@TDNPGID int
AS 
	BEGIN
	SELECT Mode, OSGREasting, OSGRNorthing, StartTime, EndTime
	FROM [dbo].[ImportantPlaceLocationRelationship]
	WHERE TDNPGID = @TDNPGID
END
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 720
SET @ScriptDesc = 'GetPlaceLocations stored procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
--
----------------------------------------------------------