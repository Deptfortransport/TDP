-- *************************************************************************************
-- NAME 		: DUP0803_Content_Updates_PartnerRelatedChanges.sql
-- DESCRIPTION  	: Updates to contents (identified through partner config tests)
-- AUTHOR		: Mitesh Modi
-- *************************************************************************************


USE [Content]
GO
-------------------------------------------------------------
-- RELATED SITES 
-------------------------------------------------------------
EXEC AddtblContent
1, 20, 'Body Text', '/Channels/TransportDirect/About/RelatedSites', 
'<DIV id="primcontent">
<DIV id="contentarea">
<TABLE id="rsviewa" cellSpacing="0">
<TBODY>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="NationalTransport" name="NationalTransport"></A>
<H2>National transport</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National Rail</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the National Rail website" href="http://www.nationalrail.co.uk/" target="_blank">www.nationalrail.co.uk</A></TD>
<TD id="rscolthreea">Guide to UK national rail services, including timetables and real time travel information.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National Express</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the National Express website" href="http://www.nationalexpress.com/" target="_blank">www.nationalexpress.com</A></TD>
<TD id="rscolthreea">Homepage of the&nbsp;UK''s largest scheduled coach company. Timetable and fare information also available.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Scottish Citylink</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Scottish Citylink website" href="http://www.citylink.co.uk/" target="_blank">www.citylink.co.uk</A></TD>
<TD id="rscolthreea">Scotland''s leading provider of express coach services.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Translink Online - Northern Ireland</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Translink Online website" href="http://www.translink.co.uk/" target="_blank">www.translink.co.uk</A></TD>
<TD id="rscolthreea">The main public transport provider for Northern Ireland.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Sustrans</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Sustrans website" href="http://www.sustrans.org.uk/" target="_blank">www.sustrans.org.uk</A></TD>
<TD id="rscolthreea">Homepage of Sustrans, the sustainable transport charity, w', '<DIV id="primcontent">
<DIV id="contentarea">
<TABLE id="rsview" cellSpacing="0">
<TBODY>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="Top" name="Top"></A>
<H2>Cludiant cenedlaethol</H2></DIV></TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National Rail</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan National Rail (yr edrychir arni mewn ffenestr newydd)" href="http://www.nationalrail.co.uk/" target="_blank">www.nationalrail.co.uk</A></TD>
<TD id="rscolthreea">Canllaw i wasanaethau rheilffyrdd cenedlaethol y DG, gan gynnwys amserlenni a gwybodaeth am deithio mewn amser real.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National Express</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan National Express (yr edrychir arni mewn ffenestr newydd)" href="http://www.nationalexpress.com/" target="_blank">www.nationalexpress.com</A></TD>
<TD id="rscolthreea">Tudalen gartref cwmni bysiau moethus rheolaidd mwyaf y DG.&nbsp; Gellir cael gwybodaeth am amserlenni a phris tocynnau hefyd.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Scottish Citylink</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Scottish CityLink (yr edrychir arni mewn ffenestr newydd)" href="http://www.citylink.co.uk/" target="_blank">www.citylink.co.uk</A></TD>
<TD id="rscolthreea">Prif ddarparwr yr Alban o wasanaethau bysiau moethus cyflym.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Translink Online - Northern Ireland</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Translink Online (yr edrychir arni mewn ffenestr newydd)" href="http://www.translink.co.uk/" target="_blank">www.translink.co.uk</A></TD>
<TD id="rscolthreea">Y prif ddarparwr cludiant cyhoeddus ar gyfer Gogledd Iwerddon.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Sustrans</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Sustrans (yr edrychir arni mewn f'
DECLARE @ptrValText BINARY(16)

-- Update text field: Value-En
SET @ptrValText = NULL
SELECT @ptrValText = TEXTPTR([Value-En]) FROM [dbo].[tblContent] WHERE [ThemeId] = 1 AND [GroupId] = 20 AND [ControlName] = 'Body Text' AND [PropertyName] = '/Channels/TransportDirect/About/RelatedSites'

IF @ptrValText IS NOT NULL BEGIN

   UPDATETEXT [dbo].[tblContent].[Value-En] @ptrValText NULL 0 'orking on practical projects to encourage people to walk, cycle and use public transport. Contains information on the National Cycle Network.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National Trails</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the National Trails website" href="http://www.nationaltrail.co.uk/" target="_blank">www.nationaltrail.co.uk</A></TD>
<TD id="rscolthreea">Provides details of over 2500 miles (4000km) of the nation&#8217;s favourite walking, riding and cycling trails.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">BAA</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the BAA website" href="http://www.baa.co.uk/" target="_blank">www.baa.co.uk</A></TD>
<TD id="rscolthreea">UK flight arrivals, flight timetables, and booking service.</TD></TR>

<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">PLUSBUS</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the PLUSBUS website" href="http://www.plusbus.info/" target="_blank">www.plusbus.info</A></TD>
<TD id="rscolthreea">Integrated train and bus ticketing is now available across Britain, view this site for details.</TD></TR>

<TR>
<TD align="right" colSpan="3">
<DIV align="right"><A name="LocalPublicTransport"><A id="jpt" href="/Web2/About/RelatedSites.aspx#logoTop">Top of page <IMG alt="Go to top of page" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="LocalPublicTransport"></A>
<H2>Local public transport</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">traveline</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Public Transport Information website" href="http://www.traveline.org.uk/" target="_blank">www.traveline.org.uk</A></TD>
<TD id="rscolthreea">Covers all travel by air, rail, coach, bus, ferry, metro and tram within the UK. Sear'
   UPDATETEXT [dbo].[tblContent].[Value-En] @ptrValText NULL 0 'chable index to timetables, fares, maps, ticket types, and passenger facilities.</TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV id="jpt" align="right"><A name="Motoring"><A href="/Web2/About/RelatedSites.aspx#logoTop">Top of page <IMG alt="Go to top of page" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="Motoring"></A>
<H2>Motoring</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Traffic England</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Traffic England website" href="http://www.trafficengland.com/" target="_blank">www.trafficengland.com</A></TD>
<TD id="rscolthreea">Traffic England is a service, provided on behalf of the Highways Agency, displaying real-time traffic information for England''s motorways and A-roads.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Traffic Wales</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Traffic Wales website" href="http://www.traffic-wales.com/" target="_blank">www.traffic-wales.com</A></TD>
<TD id="rscolthreea">Maintains travel information for the motorways and trunk roads of Wales, providing network status, traffic maps, and live traffic information.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Traffic Scotland</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Traffic Scotland website" href="http://www.trafficscotland.org/" target="_blank">www.trafficscotland.org</A></TD>
<TD id="rscolthreea">Travel information for Scotland''s strategic road network.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">AA</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the AA website" href="http://www.theaa.com/" target="_blank">www.theaa.com</A></TD>
<TD id="rscolthreea">Motoring organisation providing breakdown cover, car insurance, road travel informatio'
   UPDATETEXT [dbo].[tblContent].[Value-En] @ptrValText NULL 0 'n and other travel and motoring products and services.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">RAC</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the RAC website" href="http://www.rac.co.uk/" target="_blank">www.rac.co.uk</A></TD>
<TD id="rscolthreea">Motoring organisation providing breakdown cover, car insurance, road travel information and other travel and motoring products and services.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">TfL Congestion Charging</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the London Congestion Charging website" href="http://www.cclondon.com/" target="_blank">www.cclondon.com</A> 
<P></P>
<TD id="rscolthreea">Information about the London Congestion Charging scheme. Allows on-line payment.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Park And Ride</TD>
<TD id="rscoltwoa"><A title="Redirect to local Park and Ride page" href="/Web2/JourneyPlanning/ParkAndRide.aspx">www.transportdirect.info</A> 
<P></P>
<TD id="rscolthreea">Information about Park and Ride schemes around Britain. </TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV id="jpt" align="right"><A name="MotoringCosts"></A><A href="/Web2/About/RelatedSites.aspx#logoTop">Top of page <IMG alt="Go to top of page" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="MotoringCosts"></A>
<H2>Motoring costs</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">AA car costs</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the car costs information on the AA website" href="http://www.theaa.com/motoring_advice/running_costs/index.html" target="_blank">www.theaa.com/motoring_advice/<BR>running_costs/index.html</A></TD>
<TD id="rscolthreea">Information about car running costs for petrol and diesel cars.</TD></TR>
<TR>
<T'
   UPDATETEXT [dbo].[tblContent].[Value-En] @ptrValText NULL 0 'D colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">RAC car costs</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the car costs information on the RAC website" href="http://www.emmerson-hill.co.uk/Motoring Costs 2007.pdf" target="_blank">www.emmerson-hill.co.uk/<BR>Motoring Costs 2007.pdf</A></TD>
<TD id="rscolthreea">Information about car running costs for petrol and diesel cars.</TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV id="jpt" align="right"><A name="CarSharing"></A><A href="/Web2/About/RelatedSites.aspx#logoTop">Top of page <IMG alt="Go to top of page" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="CarSharing"></A>
<H2>Car Sharing</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Liftshare</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the car sharing information on the Liftshare website" href="http://www.liftshare.com/" target="_blank">www.liftshare.com</A></TD>
<TD id="rscolthreea">Comprehensive national car sharing database. Free registration.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National CarShare</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the car sharing information on the National Car Share website" href="http://www.nationalcarshare.co.uk/" target="_blank">www.nationalcarshare.co.uk</A></TD>
<TD id="rscolthreea">National car sharing database. Free registration.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">ShareAcar</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the car sharing information on the Share a car website" href="http://www.shareacar.com/" target="_blank">www.shareacar.com</A></TD>
<TD id="rscolthreea">National car sharing database. Annual fee.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Freewheelers</TD>
<TD id="rscoltwoa"><A title="Open'
   UPDATETEXT [dbo].[tblContent].[Value-En] @ptrValText NULL 0 ' a new window to view the car sharing information on the Freewheelers website" href="http://www.freewheelers.com/" target="_blank">www.freewheelers.com</A></TD>
<TD id="rscolthreea">National and international journey database. Free registration.</TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV id="jpt" align="right"><A name="Government"></A><A href="/Web2/About/RelatedSites.aspx#logoTop">Top of page <IMG alt="Go to top of page" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="Government"></A>
<H2>Government</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Department for Transport</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Department for Transport website" href="http://www.dft.gov.uk/" target="_blank">www.dft.gov.uk</A></TD>
<TD id="rscolthreea">Homepage of the Government Department responsible for Transport.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Directgov</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the direct gov website" href="http://www.direct.gov.uk/" target="_blank">www.direct.gov.uk</A></TD>
<TD id="rscolthreea">Interactive portal to latest and widest range of public service information including links to other UK Government sites.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Scottish Government</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Scottish Executive website" href="http://www.scotland.gov.uk/" target="_blank">www.scotland.gov.uk</A></TD>
<TD id="rscolthreea">Scottish politics, reports, consultations and government office publications from the devolved government.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Welsh Assembly</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Welsh Assembly website" href="http://www.wales.gov.uk/" target="_blank">ww'
   UPDATETEXT [dbo].[tblContent].[Value-En] @ptrValText NULL 0 'w.wales.gov.uk</A></TD>
<TD id="rscolthreea">Homepage of the Welsh Assembly.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Northern Ireland Executive</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Northern Ireland Executive website" href="http://www.northernireland.gov.uk/" target="_blank">www.northernireland.gov.uk</A></TD>
<TD id="rscolthreea">Homepage of the Northern Ireland Executive.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Transport Scotland</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the Transport Scotland website" href="http://www.transportscotland.gov.uk/" target="_blank">www.transportscotland.gov.uk</A></TD>
<TD id="rscolthreea">Transport Scotland is the new national transport agency for Scotland.&nbsp;Its purpose is to help deliver the vision of the Scottish Government for transport, with a focus on the national rail and road networks. </TD></TR></TBODY></TABLE></DIV></DIV>'

END


-- Update text field: Value-Cy
SET @ptrValText = NULL
SELECT @ptrValText = TEXTPTR([Value-Cy]) FROM [dbo].[tblContent] WHERE [ThemeId] = 1 AND [GroupId] = 20 AND [ControlName] = 'Body Text' AND [PropertyName] = '/Channels/TransportDirect/About/RelatedSites'

IF @ptrValText IS NOT NULL BEGIN

   UPDATETEXT [dbo].[tblContent].[Value-Cy] @ptrValText NULL 0 'fenestr newydd)" href="http://www.sustrans.org.uk/" target="_blank">www.sustrans.org.uk</A></TD>
<TD id="rscolthreea">Tudalen gartref Sustrans, yr elusen cludiant cynaladwy, sy&#8217;n gweithio ar brosiectau ymarferol i annog pobl i gerdded, seiclo a defnyddio cludiant cyhoeddus.&nbsp; Mae hefyd yn cynnwys gwybodaeth am y Rhwydwaith Seiclo Genedlaethol.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National Trails</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan National Trails (yr edrychir arni mewn ffenestr newydd)" href="http://www.nationaltrail.co.uk/" target="_blank">www.nationaltrail.co.uk</A></TD>
<TD id="rscolthreea">Mae&#8217;n darparu manylion am dros 2500 milltir (4000km) o hoff lwybrau cerdded, merlota a seiclo&#8217;r genedl..</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">BAA</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan BAA (yr edrychir arni mewn ffenestr newydd)" href="http://www.baa.co.uk/" target="_blank">www.baa.co.uk</A></TD>
<TD id="rscolthreea">Awyrennau sy&#8217;n hedfan i mewn i&#8217;r DG, amserlenni hedfan a gwasanaeth archebu.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">PLUSBUS</TD>
<TD id="rscoltwoa"><A title="Open a new window to view the PLUSBUS website" href="http://www.plusbus.info/" target="_blank">www.plusbus.info</A></TD>
<TD id="rscolthreea">cy Integrated train and bus ticketing is now available across Britain, view this site for details.</TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV align="right"><A name="LocalPublicTransport"><A id="jpt" href="/Web2/About/RelatedSites.aspx#logoTop">Yn &#244;l i&#8217;r brig <IMG alt="Yn &#269;l i&#8217;r brig" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="LocalPublicTransport"></A>
<H2>Cludiant cyhoeddus lleol</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="'
   UPDATETEXT [dbo].[tblContent].[Value-Cy] @ptrValText NULL 0 'rscolonea">Traveline</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Public Transport Information (Gwybodaeth Cludiant Cyhoeddus) (yr edrychir arni mewn ffenestr newydd)" href="http://www.traveline.org.uk/" target="_blank">www.traveline.org.uk</A></TD>
<TD id="rscolthreea">Mae&#8217;n ymdrin &#226; phob math o deithio drwy&#8217;r awyr, ar y rheilffyrdd, bysiau moethus, bysiau, fferi, metro a thramiau o fewn y DG.&nbsp; Mynegai y gellir ei chwilio o amserlenni, prisiau tocynnau, mapiau, mathau o docynnau a chyfleusterau i deithwyr.</TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV align="right"><A name="Motoring"><A id="jpt" href="/Web2/About/RelatedSites.aspx#logoTop">Yn &#244;l i&#8217;r brig <IMG alt="Yn &#269;l i&#8217;r brig" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="Motoring"></A>
<H2>Moduro</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Traffic England</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Highways Agency (yr edrychir arni mewn ffenestr newydd)" href="http://www.trafficengland.com" target="_blank">www.trafficengland.com</A></TD>
<TD id="rscolthreea">Mae Traffic England yn wasanaeth a ddarperir ar ran Asiantaeth y Priffyddd, sy&#8217;n arddangos gwybodaeth am draffig mewn amser real ar gyfer traffyrdd a ffyrdd A Lloegr.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Traffic Wales</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Traffic Wales (yr edrychir arni mewn ffenestr newydd)" href="http://www.traffic-wales.com/" target="_blank">www.traffic-wales.com</A></TD>
<TD id="rscolthreea">Mae&#8217;n cynnal gwybodaeth am deithio ar gyfer y traffyrdd a&#8217;r cefnffyrdd yng Nghymru gan ddarparu gwybodaeth am statws y rhwydwaith, mapiau trafnidiaeth a gwybodaeth fyw am drafnidiaeth.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Traffic'
   UPDATETEXT [dbo].[tblContent].[Value-Cy] @ptrValText NULL 0 ' Scotland</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Traffic Scotland (yr edrychir arni mewn ffenestr newydd)" href="http://www.trafficscotland.org/" target="_blank">www.trafficscotland.org</A></TD>
<TD id="rscolthreea">Gwybodaeth am deithio ar gyfer rhwydwaith ffyrdd strategol yr Alban.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">AA</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan AA  (yr edrychir arni mewn ffenestr newydd)" href="http://www.theaa.com/" target="_blank">www.theaa.com</A></TD>
<TD id="rscolthreea">Corff morduro sy&#8217;n darparu gwarchodaeth rhag torri i lawr, yswiriant ceir, gwybodaeth am deithio ar y ffyrdd a chynhyrchion a gwasanaethau eraill yn ymwneud &#226; theithio a moduro.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">RAC</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan RAC (yr edrychir arni mewn ffenestr newydd)" href="http://www.rac.co.uk/" target="_blank">www.rac.co.uk</A></TD>
<TD id="rscolthreea">Corff morduro sy&#8217;n darparu gwarchodaeth rhag torri i lawr, yswiriant ceir, gwybodaeth am deithio ar y ffyrdd a chynhyrchion a gwasanaethau eraill yn ymwneud &#226; theithio a moduro.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">TfL Congestion Charging</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan London Congestion Charging (yr edrychir arni mewn ffenestr newydd)" href="http://www.cclondon.com/" target="_blank">www.cclondon.com</A></TD>
<TD id="rscolthreea">Gwybodaeth am gynllun Codi T&#226;l Gorlawnder Llundain.&nbsp; Caniateir talu ar-lein.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Parcio a Theithio</TD>
<TD id="rscoltwoa"><A title="Ailgyfeiriwch i''r dudalen Parcio a Theithio lleol" href="/Web2/JourneyPlanning/ParkAndRide.aspx">www.transportdirect.info</A> 
<P></P>
<TD id="rscolthreea">Gwybodaeth am gynlluniau Parcio a Theithio o amgylch Prydain. </TD></TR>
<TR>

<TD '
   UPDATETEXT [dbo].[tblContent].[Value-Cy] @ptrValText NULL 0 'align="right" colSpan="3">
<DIV align="right"><A name="MotoringCosts"><A id="jpt" href="/Web2/About/RelatedSites.aspx#logoTop">Yn &#244;l i&#8217;r brig <IMG alt="Yn &#269;l i&#8217;r brig" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="MotoringCosts"></A>
<H2>Costau moduro</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">AA car costs</TD>
<TD id="rscoltwoa"><A title="Agorwch ffenestr newydd i weld gwybodaeth am gostau ceir ar wefan AA" href="http://www.theaa.com/motoring_advice/running_costs/index.html" target="_blank">www.theaa.com/motoring_advice/<BR>running_costs/index.html</A></TD>
<TD id="rscolthreea">Gwybodaeth am gostau rhedeg car ar gyfer ceir petrol a disel.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">RAC car costs</TD>
<TD id="rscoltwoa"><A title="Agorwch ffenestr newydd i weld gwybodaeth am gostau ceir ar wefan RAC" href="http://www.emmerson-hill.co.uk/Motoring Costs 2007.pdf">www.emmerson-hill.co.uk/<BR>Motoring Costs 2007.pdf</A></TD>
<TD id="rscolthreea">Gwybodaeth am gostau rhedeg car ar gyfer ceir petrol a disel.</TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV id="jpt" align="right"><A name="CarSharing"></A><A href="/Web2/About/RelatedSites.aspx#logoTop">Yn &#244;l i&#8217;r brig <IMG alt="Go to top of page" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="CarSharing"></A>
<H2>Rhannu ceir</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Liftshare</TD>
<TD id="rscoltwoa"><A title="Agorwch ffenestr newydd i weld gwybodaeth rhannu ceir ar y wefan Liftshare" href="http://www.liftshare.com/" target="_blank">www.liftshare.com</A></TD>
<TD id="rscolthreea">Cronfa ddata rhannu ceir cenedlaethol cynhwysfawr. Cofrestru am ddim.</TD></TR>
<TR>
<TD colSp'
   UPDATETEXT [dbo].[tblContent].[Value-Cy] @ptrValText NULL 0 'an="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">National CarShare</TD>
<TD id="rscoltwoa"><A title="Agorwch ffenestr newydd i weld gwybodaeth rhannu ceir ar y wefan National Car Share" href="http://www.nationalcarshare.co.uk/" target="_blank">www.nationalcarshare.co.uk</A></TD>
<TD id="rscolthreea">Cronfa ddata rhannu ceir cenedlaethol. Cofrestru am ddim.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">ShareAcar</TD>
<TD id="rscoltwoa"><A title="Agorwch ffenestr newydd i weld gwybodaeth rhannu ceir ar y wefan Share a car" href="http://www.shareacar.com/" target="_blank">www.shareacar.com</A></TD>
<TD id="rscolthreea">Cronfa ddata rhannu ceir cenedlaethol. Ffi blynyddol.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Freewheelers</TD>
<TD id="rscoltwoa"><A title="Agorwch ffenestr newydd i weld gwybodaeth rhannu ceir ar y wefan Freewheelers" href="http://www.freewheelers.com/" target="_blank">www.freewheelers.com</A></TD>
<TD id="rscolthreea">Cronfa ddata siwrneion cenedlaethol a rhyngwladol. Cofrestru am ddim.</TD></TR>
<TR>
<TD align="right" colSpan="3">
<DIV id="jpt" align="right"><A name="Government"><A href="/Web2/About/RelatedSites.aspx#logoTop">Yn &#244;l i&#8217;r brig <IMG alt="Yn &#269;l i&#8217;r brig" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/uarrow_icon_slim.gif" border="0"></A></DIV></TD></TR>
<TR>
<TD colSpan="3">
<DIV id="hdtypethree"><A id="Government"></A>
<H2>Llywodraeth</H2></DIV></TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Department for Transport</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Department for Transport  (yr edrychir arni mewn ffenestr newydd)" href="http://www.dft.gov.uk/" target="_blank">www.dft.gov.uk</A></TD>
<TD id="rscolthreea">Tudalen gartref Adran y Llywodraeth sy&#8217;n gyfrifol am Gludiant.&nbsp;&nbsp;&nbsp; </TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Directgov</TD>
<TD id="rscoltwoa"><'
   UPDATETEXT [dbo].[tblContent].[Value-Cy] @ptrValText NULL 0 'A title="Edrychwch ar wefan Directgov (yr edrychir arni mewn ffenestr newydd)" href="http://www.direct.gov.uk/" target="_blank">www.direct.gov.uk</A></TD>
<TD id="rscolthreea">Porth rhyngweithiol i&#8217;r ystod diweddaraf ac ehangaf o wybodaeth y gwasanaeth cyhoeddus gan gynnwys dolennau i safleoedd eraill Llywodraeth y DU.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Scottish Government</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Scottish Executive (yr edrychir arni mewn ffenestr newydd)." href="http://www.scotland.gov.uk/" target="_blank">www.scotland.gov.uk</A></TD>
<TD id="rscolthreea">Gwleidyddiaeth, adroddiadau, ymgynghoriadau a chyhoeddiadau Swyddfa Llywodraeth yr Alban oddi wrth y llywodraeth ddatganoledig.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Welsh Assembly</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Welsh Assembly (yr edrychir arni mewn ffenestr newydd)" href="http://www.wales.gov.uk/" target="_blank">www.wales.gov.uk</A></TD>
<TD id="rscolthreea">Tudalen gartref Cynulliad Cenedlaethol Cymru.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Northern Ireland Executive</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Northern Ireland Executive (yr edrychir arni mewn ffenestr newydd)" href="http://www.northernireland.gov.uk/" target="_blank">www.northernireland.gov.uk</A></TD>
<TD id="rscolthreea">Tudalen gartref Gweithrediaeth Gogledd Iwerddon.</TD></TR>
<TR>
<TD colSpan="3">&nbsp;</TD></TR>
<TR class="rsviewcontentrow">
<TD id="rscolonea">Transport Scotland</TD>
<TD id="rscoltwoa"><A title="Edrychwch ar wefan Transport Scotland (yr edrychir arni mewn ffenestr newydd)" href="http://www.transportscotland.gov.uk/" target="_blank">www.transportscotland.gov.uk</A></TD>
<TD id="rscolthreea">Transport Scotland yw&#8217;r asiantaeth cludiant cenedlaethol newydd ar gyfer yr Alban.&nbsp;Ei bwrpas yw helpu i gyflwyno gweledigaeth Gweithrediaeth yr Alban ar gyfer'
   UPDATETEXT [dbo].[tblContent].[Value-Cy] @ptrValText NULL 0 ' cludiant, gan ganolbwyntio ar y rhwydweithiau rheilffyrdd a ffyrdd cenedlaethol. </TD></TR></TBODY></TABLE></DIV></DIV>'

END

GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 803
SET @ScriptDesc = 'Updates to Content - partner related changes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
