-- ************************************************************
-- NAME 		: DUP0984_Updated_text_for_AirOperators.sql
-- DESCRIPTION 		: Provides updated text for Air Operators text
-- AUTHOR		: S Johal
-- ************************************************************
USE Content
GO

IF EXISTS (SELECT * FROM [dbo].[tblContent] WHERE ContentId = '54724')
  BEGIN
    UPDATE [dbo].[tblContent]
    set [Value-En]=' airport has domestic scheduled services provided by the following operators (select each link to find out more details about each operator).' where ContentId='54724'
  END
  GO
  
  IF EXISTS (SELECT * FROM [dbo].[tblContent] WHERE ContentId = '54724')
  BEGIN
    UPDATE [dbo].[tblContent]
    set [Value-Cy]=' Mae gan faes awyr wasanaethau rhestredig domestig sy�n cael eu darparu gan y gweithredwyr a ganlyn (cliciwch ar bob dolen er mwyn cael rhagor o fanylion ar bob gweithredwr).' where ContentId='54724'
  END
  GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 984
SET @ScriptDesc = 'Provides updated text for Air Operators text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------