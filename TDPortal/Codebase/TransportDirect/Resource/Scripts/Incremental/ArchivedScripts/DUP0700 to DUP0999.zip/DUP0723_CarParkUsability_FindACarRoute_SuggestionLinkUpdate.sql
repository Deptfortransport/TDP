-- ***********************************************
-- NAME 		: DUP0723_CarParkUsability_FindACarRoute_SuggestionLinkUpdate.sql
-- DESCRIPTION 		: Update to display Drive to a car park link on Find a car route page
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [TransientPortal]
GO

-------------------------------------------------------------------------
-- Update the Drive to a car park suggestion link used on Find a car route page
-------------------------------------------------------------------------

DECLARE @OldResourceLinkID int
DECLARE @NewResourceLinkID int

-- Get resource ids
SET @OldResourceLinkID = (SELECT [ResourceNameID] FROM [ResourceName] WHERE [ResourceName] = 'FindNearestCarParkPlanTo')
SET @NewResourceLinkID = (SELECT [ResourceNameID] FROM [ResourceName] WHERE [ResourceName] = 'FindNearestCarParkDriveTo')

-- Update the suggestion link (ID and Priority values will be the same across all environments, but ResourceID may not be)
UPDATE [SuggestionLink]
SET [ResourceNameID] = @NewResourceLinkID
WHERE [LinkCategoryID] = 1 AND [Priority] = 93 AND [ResourceNameID] = @OldResourceLinkID

GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 723
SET @ScriptDesc = 'Update Drive to car park link in Find a car route'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------