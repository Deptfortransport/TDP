USE TransientPortal

UPDATE dbo.SpecialContent SET
		Text = '<Table id="Table2" cellSpacing="0" cellPadding="5" width="100%" border="0">
			<TR>
				<TD><BR>
					<P><b>What is the English Concessionary Travel Scheme?</b><BR>
						From 1 April 2008 people living in England who are aged 60 and over, and 
						eligible disabled people, will be able to use their new England-wide passes 
						which entitle them to free off-peak local bus travel <b>anywhere</b> in 
						England. The statutory minimum time period to which this applies is Monday to 
						Friday, from 9.30am to 11pm and any time at weekends and bank holidays. Local 
						authorities may offer extra benefits to their residents as part of their 
						concessionary scheme � for example, free or reduced off-peak tram or rail 
						travel, or free bus travel before 9.30am Monday to Friday; details should be 
						checked with the local authority.
						<BR>
						<BR>
						Further information can be found at:<br>
						<A target="child" href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640">
							http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640</A></P>
					<BR>
					<P><b>Which bus services on Transport Direct are included in the English Concessionary 
							Travel Scheme?</b><br>
						The scheme applies to off-peak journeys on almost all services in England 
						described on this site as �bus�. We hope to indicate where this is not the case 
						as more information about exclusions becomes available. For journeys shown as 
						�coach�, passengers are advised to check details costs and associated issues in 
						advance with the operator. For example if the service requires pre-booking, a 
						booking fee may still be charged. Most long-distance coach services are not 
						included in the scheme, although coach operators such as National Express 
						already have special fares for the over-60''s so please check with the 
						operator.</P>
					<BR>
					<P><b>What is the Scottish Concessionary Travel Scheme?</b><br>
						Scotland-Wide Free Bus Travel started on 1st April 2006 and allows anyone aged 
						over 60 and eligible disabled people, to travel free on both local registered 
						services and long distance bus services within Scotland. There are no peak-time 
						restrictions.
						<BR>
						To take advantage of this free bus travel you need to have a National 
						Entitlement Card. Only a small number of services will not recognise the card, 
						for example premium fare buses and City Sightseeing buses.
						<BR>
						<BR>
						Further information can be found at: <A target="child" href="http://www.transportscotland.gov.uk/concessionarytravel">
							http://www.transportscotland.gov.uk/concessionarytravel</A></P>
					<BR>
					<P><B>What is the Welsh Concessionary Travel Scheme?</B><br>
						The Welsh Assembly Government provides financial support to enable local 
						authorities in Wales to provide freetravel on registered local bus services for 
						residents of Wales aged over 60 years and disabled of any age. Italso provides 
						free travel on local buses by companions to disabled persons.
						<BR>
						<br>
						The scheme operates across Wales and concessionary pass holders can travel free 
						at any time of day.<BR>
						<br>
						Further information can be found at:<br>
						<A target="child" href="http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en">
							http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en</A></P>
					<BR>
				</TD>
			</TR>
		</Table>'


Where Posting = 'SpecialNoticeBoard' and Culture = 'en-GB'


UPDATE dbo.SpecialContent SET
		Text = '<Table id="Table1" cellSpacing="0" cellPadding="5" width="100%" border="0">
			<TR>
				<TD><BR>
					<P><b>Beth yw Cynllun Teithio Rhatach Lloegr?</b><br>
						O 1af Ebrill 2008 ymlaen, bydd pobl dros 60 oed, a phobl anabl cymwys, sy''n 
						byw yn Lloegr yn gallu defnyddio''u cardiau Lloegr-gyfan newydd sy''n rhoi''r 
						hawl iddynt deithio''n ddi-d�l ar fysiau lleol ar adegau tawel yn unrhyw le yn 
						Lloegr. Y cyfnod amser minimwm statudol y mae hyn yn berthnasol iddo yw dydd 
						Llun i ddydd Gwener, o 9.30am i 11pm ac unrhyw bryd ar benwythnosau a gwyliau 
						banc. Gall awdurdodau lleol gynnig buddion ychwanegol i''w trigolion fel rhan 
						o''u cynllun teithio rhatach � er enghraifft, teithiau di-d�l neu brisiau 
						gostyngol ar dramiau neu drenau ar adegau tawel, neu deithiau di-d�l ar fysiau 
						cyn 9.30 am o Ddydd Llun i Ddydd Gwener; dylid gwirio''r manylion drwy gysylltu 
						�''r awdurdod lleol.<BR>
						<BR>
						Gellir cael mwy o wybodaeth ar:<br>
						<A target="child" href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640">
							http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640</A></P>
					<BR>
					<P><b>Pa wasanaethau bysiau Transport Direct sy''n gynwysedig yng Nghynllun Teithio 
							Rhatach Lloegr?</b><br>
						Mae''r cynllun yn gymwys i deithiau ar adegau tawel ar bron bob gwasanaeth yn 
						Lloegr a ddisgrifir ar y wefan hon fel �gwasanaeth bysiau�. Gobeithiwn nodi pan 
						na fydd hyn yn gymwys wrth inni gael mwy o wybodaeth am eithriadau. Yn achos 
						teithiau a ddisgrifir fel teithiau �bysiau moethus/coets�, cynghorir teithwyr i 
						wirio manylion, costau a materion cysylltiedig ymlaen llaw gyda''r gweithredwr. 
						Er enghraifft, os bydd angen archebu''r gwasanaeth ymlaen llaw, efallai y bydd 
						ffi yn daladwy. Nid yw''r rhan fwyaf o wasanaethau bysiau moethus pellter hir 
						yn gynwysedig yn y cynllun, er bod gan gwmn�au bysiau moethus megis National 
						Express eisoes brisiau arbennig i bobl dros 60 felly gwiriwch drwy gysylltu 
						�''r cwmni.</P>
					<BR>
					<P><b>Beth yw Cynllun Teithio Rhatach yr Alban?</b><br>
						Cychwynodd Scotland-Wide Free Bus Travel ar 1af Ebrill 2006 ac mae''n caniat�u 
						i unrhyw un sydd dros 60 ac i bobl anabl cymwys, deithio''n ddi-d�l ar 
						wasanaethau bysiau rheolaidd ar deithiau lleol a phell o fewn yr Alban. Nid oes 
						unrhyw gyfyngiadau amseroedd brig.
						<BR>
						<BR>
						Er mwyn manteisio ar y gwasanaeth bysiau di-d�l hwn mae angen ichi gael Cerdyn 
						Hawl Cenedlaethol. Nifer fechan yn unig o wasanaethau na fyddant yn cydnabod y 
						cerdyn, er enghraifft bysiau prisiau premiwm a bysiau City Sightseeing.<BR>
						<BR>
						Gellir cael mwy o wybodaeth ar: <A target="child" href="http://www.transportscotland.gov.uk/concessionarytravel">
							http://www.transportscotland.gov.uk/concessionarytravel</A></P>
					<BR>
					<P><B>Beth yw Cynllun Teithio Rhatach Cymru?</B><br>
						<BR>
						Mae Llywodraeth Cynulliad Cymru yn rhoi cymorth ariannol i ganiat�u i 
						awdurdodau lleol yng Nghymru ddarparu teithiau di-d�l ar wasanaethau bysiau 
						rheolaidd yn lleol i drigolion Cymru sy''n 60 neu hyn ac i bobl anabl o unrhyw 
						oedran. Mae hefyd yn darparu gwasanaeth teithio di-d�l ar fysiau lleol i rai 
						sy''n cyd-deithio � phobl anabl.
						<BR>
						<br>
						Mae''r cynllun yn gweithredu ledled Cymru a gall deiliaid p�s rhatach 
						deithio''n ddi-d�l ar unrhyw adeg o''r dydd.
						<BR>
						<BR>
						Gellir cael mwy o wybodaeth ar:<br>
						<A target="child" href="http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en">
							http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en</A></P>
					<BR>
				</TD>
			</TR>
		</Table>'

Where Posting = 'SpecialNoticeBoard' and Culture = 'cy-GB'