-- ***********************************************
-- NAME 		: DUP0799_Update_Version_Number.sql
-- DESCRIPTION 	: Updates the version number shown at the bottom of the page to v10.0
-- AUTHOR		: Steve Barker
-- ************************************************


USE [PermanentPortal]
GO

UPDATE 
	properties
SET
	pValue = 'v10.0'
WHERE
	pName = 'footer.versionnumber'
		AND
	AID = 'Web'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 799
SET @ScriptDesc = 'Updates the version number shown at the bottom of the page to v10.0'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
