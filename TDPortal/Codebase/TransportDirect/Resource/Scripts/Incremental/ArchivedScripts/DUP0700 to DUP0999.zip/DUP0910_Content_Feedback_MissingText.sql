-- ***********************************************
-- NAME 		: DUP0910_Content_Feedback_MissingText.sql
-- DESCRIPTION 		: Script to add missing Feedback page text
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Apr 2008 15:00:00
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackJourneyConfirm.No' ,'No' ,'Na'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackJourneyConfirm.Yes' ,'Yes' ,'Le'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackJourneyResult.I didn''t get any results' ,'I didn�t get any results' ,'Ni chefais unrhyw ganlyniadau'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackJourneyResult.I had a problem with the results' ,'I had a problem with the results' ,'Cefais broblem gyda''r canlyniadau'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.City-to-city' ,'City-to-city' ,'Dinas-i-ddinas'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Day trip planner' ,'Day trip planner' ,'Cynllunydd teithiau dydd'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Door-to-door' ,'Door-to-door' ,'Drws-i-ddrws'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Find a bus' ,'Find a bus' ,'Canfyddwch fws'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Find a car route' ,'Find a car route' ,'Canfyddwch lwybr car'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Find a coach' ,'Find a coach' ,'Canfyddwch fws moethus'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Find a flight' ,'Find a flight' ,'Canfyddwch ehediad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Find a train' ,'Find a train' ,'Canfyddwch dr�n'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Plan to park and ride' ,'Plan to park and ride' ,'Cynlluniwch i barcio a theithio'


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 910
SET @ScriptDesc = 'Added missing Feedback page text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO