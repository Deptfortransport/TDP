-- *************************************************************************************
-- NAME 		: DUP0755_Update_To_Stored_Proc_GetSuggestionLinkData_And_GetExternalSuggestionLinkData.sql
-- DESCRIPTION  : Update to Stored Proc GetSuggestionLinkData And GetExternalSuggestionLinkData
-- AUTHOR		: Amit Patel
-- *************************************************************************************
USE [TransientPortal]
GO

---------------------------------------------------------------------
-- Update to GetSuggestionLinkData Proc
---------------------------------------------------------------------

ALTER PROCEDURE [dbo].GetSuggestionLinkData 
	@ThemeName VARCHAR(100)
AS

DECLARE @ThemeId INT

EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT 
	
IF @ThemeId IS NULL
	BEGIN
	RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
	END

	
If NOT EXISTS (SELECT * 
					FROM ContextSuggestionLink
					WHERE ThemeId = @ThemeId)
	EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 
	

SELECT 	Context.[Name] ContextName, 
	SuggestionLink.SuggestionLinkId, 
	LinkCategory.Priority CategoryPriority, 
	LinkCategory.[Name] CategoryName,
	SuggestionLink.Priority LinkPriority, 
	InternalLink.RelativeURL, 
	Resource.Culture, 
	Resource.[Text] ResourceString, 
	SuggestionLink.IsRoot,
	SuggestionLink.IsSubRootLink,
	SuggestionLink.SubRootLinkId
FROM SuggestionLink 
	INNER JOIN ContextSuggestionLink 
		ON SuggestionLink.SuggestionLinkId = ContextSuggestionLink.SuggestionLinkId 
	INNER JOIN Context 
		ON ContextSuggestionLink.ContextId = Context.ContextId 
	INNER JOIN LinkCategory 
		ON SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId 
	INNER JOIN ResourceName 
		ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId 
	INNER JOIN Resource 
		ON ResourceName.ResourceNameId = Resource.ResourceNameId 
	INNER JOIN InternalLink 
		ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId 
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
WHERE ThemeId = @ThemeId
ORDER BY Context.ContextID, CategoryPriority, LinkPriority, Culture


GO

---------------------------------------------------------------------
-- Update to GetExternalSuggestionLinkData Proc
---------------------------------------------------------------------

ALTER PROCEDURE [dbo].[GetExternalSuggestionLinkData]
AS
	SELECT 	
		Context.[Name] ContextName, 
		SuggestionLink.SuggestionLinkId, 
		LinkCategory.Priority CategoryPriority, 
		LinkCategory.[Name] CategoryName,
		SuggestionLink.Priority LinkPriority, 
		ExternalLinks.URL, 
		Resource.Culture, 
		Resource.[Text] ResourceString, 
		SuggestionLink.IsRoot,
		SuggestionLink.IsSubRootLink,
		SuggestionLink.SubRootLinkId
	FROM SuggestionLink 
	INNER JOIN ContextSuggestionLink 
		ON SuggestionLink.SuggestionLinkId = ContextSuggestionLink.SuggestionLinkId 
	INNER JOIN Context 
		ON ContextSuggestionLink.ContextId = Context.ContextId 
	INNER JOIN LinkCategory 
		ON SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId 
	INNER JOIN ResourceName 
		ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId 
	INNER JOIN Resource 
		ON ResourceName.ResourceNameId = Resource.ResourceNameId 
	INNER JOIN ExternalSuggestionLink
		ON SuggestionLink.ExternalInternalLinkId = ExternalSuggestionLink.ExternalSuggestionLinkId
	INNER JOIN ExternalLinks
		ON ExternalSuggestionLink.ExternalLinkId = ExternalLinks.[Id]
			AND SuggestionLink.ExternalInternalLinkType = 'External'
ORDER BY Context.ContextID, CategoryPriority, LinkPriority, Culture


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 755
SET @ScriptDesc = 'Update to Stored Proc GetSuggestionLinkData And GetExternalSuggestionLinkData'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
