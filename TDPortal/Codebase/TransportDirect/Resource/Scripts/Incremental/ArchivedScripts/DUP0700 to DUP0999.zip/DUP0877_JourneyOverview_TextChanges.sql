-- ***********************************************
-- NAME 		: DUP0877_JourneyOverview_TextChanges.sql
-- DESCRIPTION 		: Script to add content for Journey Overview page and updated result footnotes
-- AUTHOR		: Mitesh Modi
-- DATE			: 4 Apr 2008 18:00:00
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'JourneyOverview.labelResultsTableNotes.Text', 
'The table above shows the possible transport options for your journey.  Click the �more� button next to the transport type you prefer to see more details of the options available using that transport type.  You can return to the summary table of transport options by pressing the back button.',
'cy The table above shows the possible transport options for your journey.  Click the �more� button next to the transport type you prefer to see more details of the options available using that transport type.  You can return to the summary table of transport options by pressing the back button.'

-- Updates to results footnotes
EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelFootnote2.Text', 
'Please (re)check your journey details within 2 weeks of travelling as some services may change.',
'A fyddech cystal hefyd ag ailwirio manylion eich siwrnai o fewn 2 wythnos o deithio oherwydd gall rhai gwasanaethau newid'

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelFootnote1.JourneyEmissions.Text', 
'Typical CO2 shows kg CO2 per traveller. For more information on how this is calculated please <a href="{0}" >click here</a>.',
'Mae allyriadau CO2 yn dangos y kg CO2 i bob teithiwr. I gael mwy o wybodaeth ar sut y mae hyn yn cael ei gyfrifo <a href="{0}" >cliciwch yma</a>.'
	

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 877
SET @ScriptDesc = 'Journey Overview page text added and result footnotes updated'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO