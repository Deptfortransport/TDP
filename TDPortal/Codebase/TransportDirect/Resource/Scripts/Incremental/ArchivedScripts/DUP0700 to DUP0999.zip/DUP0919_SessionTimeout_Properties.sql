-- ***********************************************
-- NAME 		: DUP0919_SessionTimeout_Properties.sql
-- DESCRIPTION 		: Script to add Session timeout property values, including the PageGrouping.xml file
-- AUTHOR		: Mitesh Modi
-- DATE			: 25 Apr 2008 18:00:00
-- ************************************************

USE [PermanentPortal]
GO


-- Page Group setup
IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageGrouping.Path')
BEGIN
	insert into properties values ('ScreenFlow.PageGrouping.Path', '/Web2/PageGrouping.xml', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/PageGrouping.xml'
	where pname = 'ScreenFlow.PageGrouping.Path'
END



IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageGrouping.Xml.Attribute.PageId')
BEGIN
	insert into properties values ('ScreenFlow.PageGrouping.Xml.Attribute.PageId', 'PageId', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'PageId'
	where pname = 'ScreenFlow.PageGrouping.Xml.Attribute.PageId'
END



IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageGrouping.Xml.Attribute.Group')
BEGIN
	insert into properties values ('ScreenFlow.PageGrouping.Xml.Attribute.Group', 'Group', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Group'
	where pname = 'ScreenFlow.PageGrouping.Xml.Attribute.Group'
END



IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageGrouping.Xml.Node.Page')
BEGIN
	insert into properties values ('ScreenFlow.PageGrouping.Xml.Node.Page', 'page', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'page'
	where pname = 'ScreenFlow.PageGrouping.Xml.Node.Page'
END



IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageGrouping.Xml.Node.Root')
BEGIN
	insert into properties values ('ScreenFlow.PageGrouping.Xml.Node.Root', 'PageGrouping', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'PageGrouping'
	where pname = 'ScreenFlow.PageGrouping.Xml.Node.Root'
END




-- XSDs

IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageTransferDetails.Xsd')
BEGIN
	insert into properties values ('ScreenFlow.PageTransferDetails.Xsd', '/Web2/PageTransferDetails.xsd', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/PageTransferDetails.xsd'
	where pname = 'ScreenFlow.PageTransferDetails.Xsd'
END



IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageTransitionEvent.Xsd')
BEGIN
	insert into properties values ('ScreenFlow.PageTransitionEvent.Xsd', '/Web2/PageTransitionEvent.xsd', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/PageTransitionEvent.xsd'
	where pname = 'ScreenFlow.PageTransitionEvent.Xsd'
END


IF not exists (select top 1 * from properties where pName = 'ScreenFlow.PageGrouping.Xsd')
BEGIN
	insert into properties values ('ScreenFlow.PageGrouping.Xsd', '/Web2/PageGrouping.xsd', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/PageGrouping.xsd'
	where pname = 'ScreenFlow.PageGrouping.Xsd'
END






-- Auto Redirect values
IF not exists (select top 1 * from properties where pName = 'TimeoutPage.AutoRedirect')
BEGIN
	insert into properties values ('TimeoutPage.AutoRedirect', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'TimeoutPage.AutoRedirect'
END


IF not exists (select top 1 * from properties where pName = 'TimeoutPage.AutoRedirect.Seconds')
BEGIN
	insert into properties values ('TimeoutPage.AutoRedirect.Seconds', '5', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '5'
	where pname = 'TimeoutPage.AutoRedirect.Seconds'
END


IF not exists (select top 1 * from properties where pName = 'TimeoutPage.AutoRedirect.URL')
BEGIN
	insert into properties values ('TimeoutPage.AutoRedirect.URL', '/Web2/Home.aspx?abandon=true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/Home.aspx?abandon=true'
	where pname = 'TimeoutPage.AutoRedirect.URL'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 919
SET @ScriptDesc = 'Session timeout properties including PageGrouping.xml'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO