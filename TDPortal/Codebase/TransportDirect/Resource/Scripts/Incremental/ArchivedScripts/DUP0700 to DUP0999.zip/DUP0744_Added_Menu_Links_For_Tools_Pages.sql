-- ***********************************************
-- NAME 		: DUP0744_Added_Menu_Links_For_Tools_Pages.sql
-- DESCRIPTION 	: Menu links for Tips And Tools pages
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

EXEC AddInternalSuggestionLink 
	NULL, 
	'Tips and tools', 
	'TipsAndTools', 
	'Tips and tools', 
	'Awgrymiadau a theclynnau', 
	'Tips and tools', 
	5000, 
	1, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

EXEC AddInternalSuggestionLink 
	'Tools/BusinessLinks.aspx', 
	'Link to our website', 
	'LinksToOurWebsite', 
	'Link to our website', 
	'Creu dolen i''n gwefan', 
	'Tips and tools', 
	5010, 
	0, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

EXEC AddInternalSuggestionLink 
	'Tools/ToolbarDownload.aspx', 
	'Toolbar download', 
	'ToolbarDownload', 
	'Toolbar download', 
	'Lawrlwythwch y bar offer', 
	'Tips and tools', 
	5020, 
	0, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

EXEC AddInternalSuggestionLink 
	'TDOnTheMove/TDOnTheMove.aspx', 
	'Mobile/PDA', 
	'MobileDemonstrator', 
	'Mobile demonstrator', 
	'Symudol/PDA', 
	'Tips and tools', 
	5030, 
	0, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/JourneyEmissionsCompare.aspx', 
	'Journey Emissions Compare Page', 
	'JourneyEmissionsCompare', 
	'Check journey CO2', 
	'Mesur CO2 y siwrnai ', 
	'Tips and tools', 
	5040, 
	0, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

EXEC AddInternalSuggestionLink 
	'ContactUs/FeedbackPage.aspx', 
	'Provide feedback', 
	'ProvideFeedback', 
	'Provide feedback', 
	'Rhowch adborth', 
	'Tips and tools', 
	5050, 
	0, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

EXEC AddInternalSuggestionLink 
	'About/RelatedSites.aspx', 
	'Related sites', 
	'RelatedSites', 
	'Related sites', 
	'Safleoedd cysylltiedig', 
	'Tips and tools', 
	5060, 
	0, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

EXEC AddInternalSuggestionLink 
	'Help/NewHelp.aspx', 
	'FAQ Page', 
	'HELPFAQ', 
	'Frequently Asked Questions', 
	'Cwestiynau a Ofynnir yn Aml', 
	'Tips and tools', 
	5070, 
	0, 
	'HomePageMenuTipsAndTools', 
	'Links for expandable menu on the Tips and Tools pages.'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 744
SET @ScriptDesc = 'Menu links for Tips And Tools pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------