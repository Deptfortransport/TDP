-- *************************************************************************************
-- NAME 		: DUP0792_Updated_SP_GetExternalSuggestionLinkData.sql
-- DESCRIPTION  	: Updated GetExternalSuggestionLinkData with ThemeId value
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Mar 2008 18:00:00
-- *************************************************************************************

USE [TransientPortal]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


---------------------------------------------------------------------
-- Update to GetExternalSuggestionLinkData Proc
---------------------------------------------------------------------

ALTER  PROCEDURE [dbo].[GetExternalSuggestionLinkData]
AS
	SELECT 	
		Context.[Name] ContextName, 
		SuggestionLink.SuggestionLinkId, 
		LinkCategory.Priority CategoryPriority, 
		LinkCategory.[Name] CategoryName,
		SuggestionLink.Priority LinkPriority, 
		ExternalLinks.URL, 
		Resource.Culture, 
		Resource.[Text] ResourceString, 
		SuggestionLink.IsRoot,
		SuggestionLink.IsSubRootLink,
		SuggestionLink.SubRootLinkId,
		ContextSuggestionLink.ThemeId
	FROM SuggestionLink 
	INNER JOIN ContextSuggestionLink 
		ON SuggestionLink.SuggestionLinkId = ContextSuggestionLink.SuggestionLinkId 
	INNER JOIN Context 
		ON ContextSuggestionLink.ContextId = Context.ContextId 
	INNER JOIN LinkCategory 
		ON SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId 
	INNER JOIN ResourceName 
		ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId 
	INNER JOIN Resource 
		ON ResourceName.ResourceNameId = Resource.ResourceNameId 
	INNER JOIN ExternalSuggestionLink
		ON SuggestionLink.ExternalInternalLinkId = ExternalSuggestionLink.ExternalSuggestionLinkId
	INNER JOIN ExternalLinks
		ON ExternalSuggestionLink.ExternalLinkId = ExternalLinks.[Id]
			AND SuggestionLink.ExternalInternalLinkType = 'External'
ORDER BY Context.ContextID, CategoryPriority, LinkPriority, Culture
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 792
SET @ScriptDesc = 'Updated GetExternalSuggestionLinkData with ThemeId value'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
