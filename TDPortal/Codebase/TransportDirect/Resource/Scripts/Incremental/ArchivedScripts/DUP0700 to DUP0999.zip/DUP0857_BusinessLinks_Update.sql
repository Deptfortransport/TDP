-- ***********************************************
-- NAME 		: DUP0857_BusinessLinks_Update.sql
-- DESCRIPTION 	: Corrects bugs with paths in Business Links
-- AUTHOR		: Steve Barker
-- Date 		: 28 March 2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [PermanentPortal]
GO

/* Delete existing templates */
DELETE FROM BusinessLinkTemplates
GO

/* Create empty items */
INSERT INTO BusinessLinkTemplates (BusinessLinkTemplatesId, NameResourceId, ImageUrl, HTMLScript) VALUES (1, 'BusinessLinks.Template1Radio', '/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/BusinessLinksTemplate1.gif', '')
INSERT INTO BusinessLinkTemplates (BusinessLinkTemplatesId, NameResourceId, ImageUrl, HTMLScript) VALUES (2, 'BusinessLinks.Template2Radio', '/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/BusinessLinksTemplate2.gif', '')
INSERT INTO BusinessLinkTemplates (BusinessLinkTemplatesId, NameResourceId, ImageUrl, HTMLScript) VALUES (3, 'BusinessLinks.Template3Radio', '/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/BusinessLinksTemplate3.gif', '')
INSERT INTO BusinessLinkTemplates (BusinessLinkTemplatesId, NameResourceId, ImageUrl, HTMLScript) VALUES (4, 'BusinessLinks.Template4Radio', '/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/BusinessLinksTemplate4.gif', '')
INSERT INTO BusinessLinkTemplates (BusinessLinkTemplatesId, NameResourceId, ImageUrl, HTMLScript) VALUES (5, 'BusinessLinks.Template5Radio', '/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/BusinessLinksTemplate5.gif', '')
GO

/*************
* Template 1 *
*************/

DECLARE @ptrval varbinary(16)
SELECT @ptrval = TEXTPTR(HTMLScript)
FROM BusinessLinkTemplates
WHERE BusinessLinkTemplatesId = 1

WRITETEXT BusinessLinkTemplates.HTMLScript @ptrval
'<form method="post" id="TransportDirectPlanningForm" target="_blank" action="{TARGET_URL}/web2/journeyplanning/jplandingpage.aspx">
    <table width="230px" cellspacing="0" style="margin: 3px 3px 3px 3px;">
        <tr bgcolor="#330099">
            <td>
                <p style="margin: 2px 2px 2px 4px">
                    <img alt="Transport Direct" src="{TARGET_URL}/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/TDLogo38.gif" /></p>
            </td>
        </tr>
        <tr bgcolor="#99ccff">
            <td>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    Get directions by public transport and car with <a href="{TARGET_URL}/web2/Home.aspx"
                        target="_blank">Transport Direct</a>.</p>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    Enter your postcode</p>
            </td>
        </tr>
        <tr bgcolor="#99ccff">
            <td>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    <input type="text" id="txtOrigin" name="o" style="width: 80px; border-color: lightgrey;
                        border-width: 1px; border-style: solid; font-size: 12px; font-family: verdana, arial, helvetica, sans-serif;
                        background-color: white; height: 16px;" />
                    <input type="submit" id="btnSubmit" value="Go" style="color: #264266; background-color: #ebebeb;
                        font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px;
                        text-align: center; text-decoration: none; border-bottom-color: #808080; border-top-color: #C0C0C0;
                        border-right-color: #808080; border-left-color: #C0C0C0; border-width: 1px; border-style: solid;
                        cursor: pointer; cursor: hand; width: auto; overflow: visible; padding: 0px 3px 1px 3px;" />
                    <input type="hidden" name="oo" value="p" />
                    <input type="hidden" name="et" value="jp" />
                    <input type="hidden" name="m" value="m" />
                    <input type="hidden" name="do" value="{DESTINATION_TYPE}" />
                    <input type="hidden" name="dn" value="{DESTINATION_NAME}" /><input type="hidden"
                        name="d" value="{DESTINATION_DATA}" />
                    <input type="hidden" name="p" value="1" />
                    <input type="hidden" name="id" value="{PARTNER_ID}" />
                </p>
            </td>
        </tr>
	</table>
</form>'
GO

/*************
* Template 2 *
*************/

DECLARE @ptrval varbinary(16)
SELECT @ptrval = TEXTPTR(HTMLScript)
FROM BusinessLinkTemplates
WHERE BusinessLinkTemplatesId = 2

WRITETEXT BusinessLinkTemplates.HTMLScript @ptrval
'<form method="post" id="Form1" target="_blank" action="{TARGET_URL}/web2/journeyplanning/jplandingpage.aspx">
    <table id="Table1" width="230px" style="background: #99ccff; margin: 3px 3px 3px 3px;"
        cellspacing="0">
        <tr bgcolor="#330099">
            <td colspan="2">
                <p style="margin: 2px 2px 2px 4px">
                    <img alt="Transport Direct" src="{TARGET_URL}/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/TDLogo38.gif" /></p>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    Get directions by public transport and car with <a href="{TARGET_URL}/web2/Home.aspx"
                        target="_blank">Transport Direct</a>.</p>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    Enter your postcode</p>
            </td>
        </tr>
        <tr>
            <th>
                &nbsp;
            </th>
            <td>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    <input type="text" id="txtOrigin2" name="o" style="width: 80px; border-color: lightgrey;
                        border-width: 1px; border-style: solid; font-size: 12px; font-family: verdana, arial, helvetica, sans-serif;
                        background-color: white; height: 16px;" />
                </p>
            </td>
        </tr>
        <tr>
            <th>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; font-weight: bold;
                    text-align: left; text-decoration: none; margin: 5px 0px 5px 5px;">
                    On</p>
            </th>
            <td>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    <select id="dtd" name="dtd" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid;
                        font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid;
                        font-family: verdana, arial, helvetica, sans-serif; background-color: white;
                        height: 18px;">
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option value="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option value="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option>
                    </select>
                    &nbsp;
                    <!--        !IMPORTANT!       Month/year dropdown values will need to be maintained over time. Only the current month        and the following two months should be selectable because complete public transport data is only        available for journeys up to three months in the future.       Client-side script should be added to default the dropdown values to the current date and time.        -->
                    <select id="dtm" name="dtm" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid;
                        font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid;
                        font-family: verdana, arial, helvetica, sans-serif; background-color: white;
                        height: 18px;">
                        {MONTH_OPTIONS}</select>
                </p>
            </td>
        </tr>
        <tr>
            <th>
                &nbsp;</th>
            <td>
                <p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left;
                    margin: 5px 5px 5px 5px;">
                    <select id="th" name="th" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid;
                        font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid;
                        font-family: verdana, arial, helvetica, sans-serif; background-color: white;
                        height: 18px;">
                        <option value="00">00</option>
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option value="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option value="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                    </select>
                    &nbsp;
                    <select id="tm" name="tm" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid;
                        font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid;
                        font-family: verdana, arial, helvetica, sans-serif; background-color: white;
                        height: 18px;">
                        <option value="00">00</option>
                        <option value="05">05</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                        <option value="20">20</option>
                        <option value="25">25</option>
                        <option value="30">30</option>
                        <option value="35">35</option>
                        <option value="40">40</option>
                        <option value="45">45</option>
                        <option value="50">50</option>
                        <option value="55">55</option>
                    </select>
                    &nbsp;
                    <input type="submit" id="Submit1" value="Go" style="color: #264266; background-color: #ebebeb;
                        font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px;
                        text-align: center; text-decoration: none; border-bottom-color: #808080; border-top-color: #C0C0C0;
                        border-right-color: #808080; border-left-color: #C0C0C0; border-width: 1px; border-style: solid;
                        cursor: pointer; cursor: hand; width: auto; overflow: visible; padding: 0px 3px 1px 3px;"
                        name="Submit1" />
                    <input type="hidden" name="dt" id="departureDate" />
                    <input type="hidden" name="t" id="departureTime" />
                    <input type="hidden" name="oo" value="p" />
                    <input type="hidden" name="et" value="jp" />
                    <input type="hidden" name="m" value="m" />
                    <input type="hidden" name="do" value="{DESTINATION_TYPE}" />
                    <input type="hidden" name="dn" value="{DESTINATION_NAME}" /><input type="hidden"
                        name="d" value="{DESTINATION_DATA}" />
                    <input type="hidden" name="p" value="1" />
                    <input type="hidden" name="id" value="{PARTNER_ID}" />
                </p>
            </td>
        </tr>
    </table>
</form>'
GO

/*************
* Template 3 *
*************/

DECLARE @ptrval varbinary(16)
SELECT @ptrval = TEXTPTR(HTMLScript)
FROM BusinessLinkTemplates
WHERE BusinessLinkTemplatesId = 3
		
WRITETEXT BusinessLinkTemplates.HTMLScript @ptrval
'<style type="text/css">
.hidelabel { display: none; }
</style>
<form method="post" id="Form1" onsubmit="AssembleParameters()" target="_blank" action="{TARGET_URL}/web2/journeyplanning/jplandingpage.aspx">
<table width="230px" cellspacing="0" style="margin: 3px 3px 3px 3px;">
		<tr bgcolor="#330099">
		<td><p style="margin: 2px 2px 2px 4px"><img alt="Transport Direct" src="{TARGET_URL}/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/TDLogo38.gif" /></p>
		</td>
			<td>
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: right; margin: 5px 5px 5px 5px; color: white;">To or from:</p>
			</td>
			<td>
			<span class="hidelabel"><label for="fromTo">Select journey from or to</label></span>
				<select id="fromTo" name="ft" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white; height: 18px;">
					<option value="From" selected="selected">From</option>
					<option value="To">To</option>
				</select>
			</td>

	</tr>

	<tr bgcolor="#99ccff">
		<td colspan="3">
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">Get directions by public transport and car with <a href="{TARGET_URL}/web2/Home.aspx" target="_blank">Transport Direct</a>.</p>
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">Enter your postcode</p>
		</td>
	</tr>
		
	<tr bgcolor="#99ccff">
		<td colspan="3">
		<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">

<input type="text" id="txtOrigin" name="txtOrigin" style="width: 80px; border-color: lightgrey; border-width: 1px; border-style: solid; font-size: 12px; font-family: verdana, arial, helvetica, sans-serif; background-color: white; height: 16px;" />
<input type="submit" id="btnSubmit" value="Go" style="color: #264266; background-color: #ebebeb; font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: center; text-decoration: none; border-bottom-color: #808080; border-top-color: #C0C0C0; border-right-color: #808080;  border-left-color: #C0C0C0; border-width: 1px; border-style: solid; cursor: pointer; cursor: hand; width: auto; overflow: visible; padding: 0px 0px 1px 0px;" />
<input type="hidden" name="o" id="originData" value="" />					
<input type="hidden" name="oo" id="originType" value="p" /> 
<input type="hidden" name="on" id="originName" value="" />
<input type="hidden" name="et" id="entryType" value="jp" />
<input type="hidden" name="m" id="modes" value="m" /> 
<input type="hidden" name="do" id="destinationType" value="{DESTINATION_TYPE}" />
<input type="hidden" name="dn" id="destinationName" value="{DESTINATION_NAME}" />
<input type="hidden" name="d" id="destinationData" value="{DESTINATION_DATA}" />
<input type="hidden" name="originaltype" id="originaltype" value="{DESTINATION_TYPE}" />
<input type="hidden" name="originalname" id="originalname" value="{DESTINATION_NAME}" />
<input type="hidden" name="originaldata" id="originaldata" value="{DESTINATION_DATA}" />
<input type="hidden" name="p" id="autoPlan" value="1" /> 
<input type="hidden" name="id" id="partnerID" value="{PARTNER_ID}" /> 
			</p>

		</td>
	</tr>
</table>

</form>
<script language="javascript" type="text/javascript">
<!--
function AssembleParameters()
{
	var fixedType = document.getElementById("originaltype").value;  
	var fixedData = document.getElementById("originaldata").value;  
	var fixedName =  document.getElementById("originalname").value;

	var directionList = document.getElementById("fromTo"); 
	var inputText = document.getElementById("txtOrigin").value;  
	var selection = directionList.options[directionList.selectedIndex].value;

	if( selection == "From") 
	{
		document.getElementById("originData").value = fixedData;    
		document.getElementById("originName").value = fixedName;	 
		document.getElementById("originType").value = fixedType;   	
		
		// destination is the entered postcode
		document.getElementById("destinationData").value = inputText;  
	    document.getElementById("destinationName").value = inputText;  
	    document.getElementById("destinationType").value = "p";
	}
	else 
	{	
		document.getElementById("destinationData").value = fixedData;  
    	document.getElementById("destinationName").value = fixedName;  
    	document.getElementById("destinationType").value = fixedType;

		// origin is the entered postcode 
		document.getElementById("originData").value = inputText;        
		document.getElementById("originType").value = "p";       
		document.getElementById("originName").value = inputText; 
	}
}
//-->
</script>'
GO

/*************
* Template 4 *
*************/

DECLARE @ptrval varbinary(16)
SELECT @ptrval = TEXTPTR(HTMLScript)
FROM BusinessLinkTemplates
WHERE BusinessLinkTemplatesId = 4

WRITETEXT BusinessLinkTemplates.HTMLScript @ptrval 
'<style type="text/css">
.hidelabel { display: none; }
</style>
<script language="javascript" type="text/javascript">
<!--
function SetDateTimeDropDown()
{
	var currentDate = new Date();
	var hour = currentDate.getHours();
	var minute = currentDate.getMinutes();
	
	// round up the minutes to the nearest 15
	var minutes = (Math.round(minute/5))* 5	
	minutes = minutes+15;
	
	if (minutes > 59)
	{
		minutes = minutes % 60;
		// increment the hour
		hour++; 
		
		if(hour > 23) 
		{
			// increment the day
			day++;
			
			// set the hour to midnight
			hour = 0;
		} 
	}
		
	var month = currentDate.getMonth();
	var day = currentDate.getDate();
	var year = currentDate.getFullYear();
	
	var monthList = new Array(12);
	monthList[0]="Jan";
	monthList[1]="Feb";
	monthList[2]="Mar";
	monthList[3]="Apr";
	monthList[4]="May";
	monthList[5]="Jun";
	monthList[6]="Jul";
	monthList[7]="Aug";
	monthList[8]="Sep";
	monthList[9]="Oct";
	monthList[10]="Nov";
	monthList[11]="Dec";
	
	var displayMonthsText = new Array(3);
	var displayMonthsNumber = new Array(3);
	var followingYear = year+1;
	
	switch(month)
	{
	    case 10: 
		displayMonthsText[0] = monthList[month]+" "+year;
		displayMonthsText[1] = monthList[month+1]+" "+year;
		displayMonthsText[2] = monthList[0]+" "+followingYear;
			
		var month2 = month+1;
		var month3 = month+2;
		
		displayMonthsNumber[0] = month2+""+year;
		displayMonthsNumber[1] = month3+""+year;
		displayMonthsNumber[2] = "01"+followingYear;
		break;
			
	    case 11: 
		displayMonthsText[0] = monthList[month]+" "+year;
		displayMonthsText[1] = monthList[0]+" "+followingYear;
		displayMonthsText[2] = monthList[1]+" "+followingYear;
		
		var currentMonth = month+1;
		displayMonthsNumber[0] = currentMonth+""+year;
		displayMonthsNumber[1] = "01"+followingYear;
		displayMonthsNumber[2] = "02"+followingYear;
		break;
				
	    default:
		var month2 = month+1;
		var month3 = month+2;
		var month4 = month+3;
			
		displayMonthsText[0] = monthList[month]+" "+year;
		displayMonthsText[1] = monthList[month2]+" "+year;
		displayMonthsText[2] = monthList[month3]+" "+year;
		
		displayMonthsNumber[0] = "0"+month2+year;
		displayMonthsNumber[1] = "0"+month3+year;
		displayMonthsNumber[2] = "0"+month4+year;

		break;
	}

	// Get a reference to the drop-down
	var hourDropDownList = document.getElementById("timeHours"); 
	var minutesDropDownList = document.getElementById("timeMinutes");
	var daysDropDownList = document.getElementById("dateTimeDay");
	var monthsDropDownList = document.getElementById("dateTimeMonth");

	// Loop through hours
	for (i = 0; i< hourDropDownList.options.length; i++)
	{    
    	if (hourDropDownList.options[i].value == hour)
		{
			hourDropDownList.options[i].selected = true;
			break;
		}
	}

	// Loop through minutes
	for (k = 0; k< minutesDropDownList.options.length; k++)
	{	    
    	if (minutesDropDownList.options[k].value == minutes)
		{
			minutesDropDownList.options[k].selected = true;
			break;
		}
	}

	// Loop through days
	for (m = 0; m< daysDropDownList.options.length; m++)
	{    
		if (daysDropDownList.options[m].value == day)
		{
			daysDropDownList.options[m].selected = true;
			break;
		}
	}

	// Loop through months
	for (n = 0; n< displayMonthsText.length; n++)
	{	    
		 //name, value  e.g. ("May 2006", "052006")
		monthsDropDownList.options[n]=new Option(displayMonthsText[n], displayMonthsNumber[n]);
	}
	// set current month (the first item in the array) as the selected item
	monthsDropDownList.selectedIndex = 0;
}

//-->
</script>
	<form method="post" id="Form1" target="_blank" onsubmit="AssembleParameters()" action="{TARGET_URL}/web2/journeyplanning/jplandingpage.aspx">
		<table id="table1" width="320px" style="background: #99ccff; margin: 3px 3px 3px 3px;" cellspacing="0" cellpadding="0">

		<tr bgcolor="#330099">
			<td>
				<p style="margin: 2px 2px 2px 4px"><img alt="Transport Direct" src="{TARGET_URL}/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/TDLogo38.gif" /></p>
			</td>
		
			<td nowrap>
				<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: right; margin: 5px 5px 5px 5px; color: white;">To or from:</p>
			</td>

			<td>
				<span class="hidelabel">
					<label for="fromTo">Select journey from or to</label>
				</span>
				<select id="fromTo" name="ft" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white;">
					<option value="From" selected="selected">From</option>
					<option value="To">To</option>
				</select>
			</td>
		</tr>

	<tr bgcolor="#99ccff">
		<td colspan="3">
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">Get directions by public transport and car with <a href="{TARGET_URL}/web2/Home.aspx" target="_blank">Transport Direct</a>.</p>
		</td>

	</tr>

	<tr>
		<td>
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: right; margin: 5px 5px 5px 5px;">Enter your postcode</p>
		</td>
		<td colspan="2">
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">
			<input type="text" id="txtOrigin" name="txtOrigin" style="width: 80px; border-color: lightgrey; border-width: 1px; border-style: solid; font-size: 12px; font-family: verdana, arial, helvetica, sans-serif; background-color: white; height: 16px;" />
			</p>
		</td>
	</tr>

	<tr>
		<td>
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; font-weight: bold; text-align: right; text-decoration: none; margin: 5px 5px 5px 5px;">On</p>
		</td>

		<td colspan="2">
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">
			<span class="hidelabel"><label for="dateTimeDay">Select a day</label></span>
			<select id="dateTimeDay" name="dtd" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white;">
						<option value="01">01</option>
						<option value="02">02</option>
						<option value="03">03</option>
						<option value="04">04</option>
						<option value="05">05</option>
						<option value="06">06</option>
						<option value="07">07</option>
						<option value="08">08</option>
						<option value="09">09</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
					</select>

			<span class="hidelabel"><label for="dateTimeMonth">Select a month</label></span>
			<select id="dateTimeMonth" name="dtm" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white;">	
			<no script>{MONTH_OPTIONS}</no script>
			</select>
			</p>
		</td>
	</tr>
	<tr>
		<td>				
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; font-weight: bold; text-align: right; margin: 5px 5px 5px 5px;">
			<input type=radio id="departArrive" name="da" value="d" checked>Depart<input type=radio name="da" value="a">Arrive</p>
		</td>
		<td  colspan="2">
				<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">
				<span class="hidelabel"><label for="timeHours">Select an hour</label></span>
				<select id="timeHours" name="th" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white;">
						<option value="00">00</option>
						<option value="01">01</option>
						<option value="02">02</option>
						<option value="03">03</option>
						<option value="04">04</option>
						<option value="05">05</option>
						<option value="06">06</option>
						<option value="07">07</option>
						<option value="08">08</option>
						<option value="09">09</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
					</select>
				<span class="hidelabel"><label for="timeMinutes">Select the minutes</label></span>
				<select id="timeMinutes" name="tm" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white;">
						<option value="00">00</option>
						<option value="05">05</option>
						<option value="10">10</option>
						<option value="15">15</option>
						<option value="20">20</option>
						<option value="25">25</option>
						<option value="30">30</option>
						<option value="35">35</option>
						<option value="40">40</option>
						<option value="45">45</option>
						<option value="50">50</option>
						<option value="55">55</option>
					</select>&nbsp; 

				<input type="submit" id="Submit1" value="Go" style="color: #264266; background-color: #ebebeb; font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: center; text-decoration: none; border-bottom-color: #808080; border-top-color: #C0C0C0; border-right-color: #808080;  border-left-color: #C0C0C0; border-width: 1px; border-style: solid; cursor: pointer; cursor: hand; width: auto; overflow: visible; padding: 0px 3px 1px 3px;"
						name="Submit1" /> 
					<input type="hidden" name="dt" id="departureDate" value=""/> 
					<input type="hidden" name="t" id="departureTime" value=""/>
					<input type="hidden" name="o" id="originData" value="" />					
					<input type="hidden" name="oo" id="originType" value="p" /> 
					<input type="hidden" name="on" id="originName" value="" />
					<input type="hidden" name="et" id="entryType" value="jp" />
					<input type="hidden" name="m" id="modes" value="m" /> 
					<input type="hidden" name="do" id="destinationType" value="{DESTINATION_TYPE}" />
					<input type="hidden" name="dn" id="destinationName" value="{DESTINATION_NAME}" />
					<input type="hidden" name="d" id="destinationData" value="{DESTINATION_DATA}" />
					<input type="hidden" name="originaltype" id="originaltype" value="{DESTINATION_TYPE}" />
					<input type="hidden" name="originalname" id="originalname" value="{DESTINATION_NAME}" />
					<input type="hidden" name="originaldata" id="originaldata" value="{DESTINATION_DATA}" />
					<input type="hidden" name="p" id="autoPlan" value="1" /> 
					<input type="hidden" name="id" id="partnerID" value="BusinessLinks" /> 
				</p>
			</td>
		</tr>
	</table>
</form>

<script language="javascript" type="text/javascript">
<!--
function AssembleParameters()
{

	var fixedType = document.getElementById("originaltype").value;  
	var fixedData = document.getElementById("originaldata").value;  
	var fixedName =  document.getElementById("originalname").value;

	var directionList = document.getElementById("fromTo"); 
	var inputText = document.getElementById("txtOrigin").value;  
	var selection = directionList.options[directionList.selectedIndex].value;

	//set the date and time
	document.getElementById("departureDate").value = GetDate();  
	document.getElementById("departureTime").value = GetTime();

	if( selection == "From") 
	{
		document.getElementById("originData").value = fixedData;    
		document.getElementById("originName").value = fixedName;	 
		document.getElementById("originType").value = fixedType;   	
		
		// destination is the entered postcode
		document.getElementById("destinationData").value = inputText;  
	    document.getElementById("destinationName").value = inputText;  
	    document.getElementById("destinationType").value = "p";
	}
	else 
	{	
		document.getElementById("destinationData").value = fixedData;  
    	document.getElementById("destinationName").value = fixedName;  
    	document.getElementById("destinationType").value = fixedType;

		// origin is the entered postcode 
		document.getElementById("originData").value = inputText;        
		document.getElementById("originType").value = "p";       
		document.getElementById("originName").value = inputText; 
	}
}

function GetTime()
{
	var hour = document.getElementById("timeHours").options[document.getElementById("timeHours").selectedIndex].value; 
	var min = document.getElementById("timeMinutes").options[document.getElementById("timeMinutes").selectedIndex].value; 
	return hour+""+min;
}

function GetDate() 
{
   var day = document.getElementById("dateTimeDay").options[document.getElementById("dateTimeDay").selectedIndex].value; 
   var monthYear = document.getElementById("dateTimeMonth").options[document.getElementById("dateTimeMonth").selectedIndex].value; 
   
   return day+""+monthYear;
}
//-->
</script>'
GO

/*************
* Template 5 *
*************/

DECLARE @ptrval varbinary(16)
SELECT @ptrval = TEXTPTR(HTMLScript)
FROM BusinessLinkTemplates
WHERE BusinessLinkTemplatesId = 5

WRITETEXT BusinessLinkTemplates.HTMLScript @ptrval
'<style type="text/css">
.hidelabel { display: none; }
</style>
<form method="post" id="Form1" onsubmit="AssembleParameters()" target="_blank" action="{TARGET_URL}/web2/journeyplanning/FindNearestLandingPage.aspx">
<table width="230px" cellspacing="0" style="margin: 3px 3px 3px 3px;">
		<tr bgcolor="#330099">
		<td><p style="margin: 2px 2px 2px 4px"><img alt="Transport Direct" src="{TARGET_URL}/Web2/App_Themes/{PARTNER_NAME}/images/gifs/misc/TDLogo38.gif" /></p>
		</td>
		<td colspan="2"></td>
	</tr>
	
	<tr bgcolor="#99ccff">
		<td colspan="3">
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">Enter a location and let <a href="{TARGET_URL}/web2/Home.aspx" target="_blank">Transport Direct</a> find the nearest car parks.</p>
		</td>
	</tr>
		
	<tr bgcolor="#99ccff">
		<td colspan="3">
		<p style="font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">
		<table cellpadding="2" cellspacing="0" border="0">
			<tr>
				<td><p style="font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: left;">Place</p></td>
				<td><input type="text" id="txtLocation" name="txtLocation" style="width: 120px; border-color: lightgrey; border-width: 1px; border-style: solid; font-size: 12px; font-family: verdana, arial, helvetica, sans-serif; background-color: white; height: 20px; width: 160px;" /></td>
			</tr>
			<tr>
				<td></td>
				<td>
					<span class="hidelabel"><label for="drpLocationType">Select the location type</label></span>
					<select id="drpLocationType" name="drpLocationType" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white; height: 20px; width: 160px;">
						<option value="AddressPostcode" selected="selected">Address/postcode</option>
						<option value="CityTownSuburb">Town/district/village</option>
						<option value="StationAirport">Station/airport</option>
						<option value="AttractionFacility">Facility/attraction</option>
					</select>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="right">

					<input type="submit" id="btnSubmit" value="Go" style="color: #264266; background-color: #ebebeb; font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: center; text-decoration: none; border-bottom-color: #808080; border-top-color: #C0C0C0; border-right-color: #808080;  border-left-color: #C0C0C0; border-width: 1px; border-style: solid; cursor: pointer; cursor: hand; width: auto; overflow: visible; padding: 0px 0px 1px 0px; " />
	
					<input type="hidden" name="et" id="entryType" value="fn" />
					<input type="hidden" name="ft" id="originData" value="cp" />					
					<input type="hidden" name="pn" id="placeName" value="" /> 
					<input type="hidden" name="lg" id="locationGazetteer" value="" />
					<input type="hidden" name="nd" id="numberDisplayed" value="50" />

					<input type="hidden" name="id" id="partnerID" value="{PARTNER_ID}" /> 
					<input type="hidden" name="p" id="autoPlan" value="1" />
				</td>
			</tr>
		</table>
		</p>

		</td>
	</tr>
</table>

</form>
<script language="javascript" type="text/javascript">
<!--
function AssembleParameters()
{
	var inputText = document.getElementById("txtLocation").value;
	var locationTypeList = document.getElementById("drpLocationType");
	var locationType = locationTypeList.options[locationTypeList.selectedIndex].value;

	document.getElementById("placeName").value = inputText;    
	document.getElementById("locationGazetteer").value = locationType;	 
}
//-->
</script>'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 857
SET @ScriptDesc = 'Corrects bugs with paths in Business Links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------