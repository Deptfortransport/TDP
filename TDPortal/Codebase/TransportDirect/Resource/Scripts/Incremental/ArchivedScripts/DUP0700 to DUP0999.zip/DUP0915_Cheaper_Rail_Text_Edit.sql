-- *************************************************************************************
-- NAME 		: DUP0915_Cheaper_Rail_Text_Edit.sql
-- DESCRIPTION  	: Updates cosmetic text on rail by price screen
-- AUTHOR		: Steve Barker
-- *************************************************************************************

USE [Content]
GO

--Note that the Welsh text for the second entry has always been missing...
EXEC AddtblContent 1, 1, 'langStrings', 'JourneyPlannerOutputTitle.FindFareDateSelectionText', 'Step 1 of 4: Select the date option with suitable fares', 'Cam 1 o 4: Dewiswch ddewis o ddyddiad gyda thocynnau addas'
EXEC AddtblContent 1, 1, 'FindAFare', 'FindFareDateSelection.AppendPageTitle', '| Find a Fare | Select the date option with suitable fares', ''
EXEC AddtblContent 1, 1, 'FindAFare', 'FindFareDateSelection.Help.AlternateText', 'Help with selecting a date option with suitable fares', 'Cymorth gyda dewis dyddiad gyda thocynnau addas'
EXEC AddtblContent 1, 1, 'FindAFare', 'FindFareDateSelection.ReturnSinglesNote', 'Notes:<br>���Some fares shown may be a combination of two single fares.<br>���Availability is not guaranteed at this stage.<br>���"*" means that all the fares for that date are unlikely to be available.', 'Nodiadau:<br>���Gall rhai tocynnau fod yn gyfuniad o ddau docyn sengl.<br>���Ni ellir gwarantu fod y tocynnau ar gael ar hyn o bryd.<br>���Mae "*" yn golygu bod yr holl docynnau ar gyfer y cyfuniad o ddyddiad hwnnw yn annhebyg o fod ar gael.'
EXEC AddtblContent 1, 1, 'FindAFare', 'FindFareDateSelection.SingleNote', 'Notes:<br>���Availability is not guaranteed at this stage.<br>���"*" means that all the fares for that date are unlikely to be available.', 'Nodiadau:<br>���Ni ellir gwarantu fod y tocynnau ar gael ar hyn o bryd.<br>���Mae "*" yn golygu bod yr holl docynnau ar gyfer y cyfuniad o ddyddiad hwnnw yn annhebyg o fod ar gael.'
EXEC AddtblContent 1, 1, 'FindAFare', 'FindFareDateSelection.InstructionText', 'The range of fares and the lowest fare that is likely to be available for each date are listed below.  To see the full range of fares for a given date select the option.  Then click ''Next''.', 'Rhestrir y dewis o docynnau a''r tocyn isaf sy''n debygol o fod ar gael ar gyfer pob dyddiad a math o gludiant isod.  I weld y dewis llawn o docynnau am ddyddiad a roddir a''r cyfuniad o gludiant dewiswch y dewis.  Yna cliciwch ''Nesaf''.'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 915
SET @ScriptDesc = 'Updates cosmetic text on rail by price screen'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
