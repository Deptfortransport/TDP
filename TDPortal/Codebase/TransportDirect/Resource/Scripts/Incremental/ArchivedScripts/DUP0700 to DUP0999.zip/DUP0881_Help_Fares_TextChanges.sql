-- ************************************************************
-- NAME 		: DUP0881_Help_Fares_TextChanges.sql
-- DESCRIPTION 		: Help fares page updated to include car help
-- AUTHOR		: mmodi
-- ************************************************************
USE [Content]
GO

EXEC AddtblContent
1, 1,'langStrings','helpJourneyFaresLabelControl'
,'This page shows the fares for the selected journey. A diagram of your journey is on the left hand side of the 
page and the fares are listed in tables next to it. If you would like to see fares for this journey, 
without the diagram, click "Show in table". <br><br> 
<p><strong>Public Transport costs</strong></p>
<p>The fares are listed for each leg of the journey if Transport Direct has the fare information.<br><br> 
To view the Ticket Retailers for these fares:<br> <u1> 
1. Select the fare(s) you are interested in buying. You do not need to buy a ticket for all parts of the 
journey<br>
2. Click "Buy tickets"<br><br>
<p><strong>Car Journey costs:</strong></p><br><ul><li>The costs below are related to your journey.<br></li></ul>
<p> If the journey involves ferries or tolls, the costs for these will be indicated if they are available.  
For more information on the ferries or tolls you can click on the name to be taken to their websites.</p>
<br>
<p><strong>Amend fare details</strong></p>
<p>To amend fare details: <br><br></p>
<p><strong>Discount cards</strong></p>
<ul> <li>Select the discount rail card you have from the drop-down list</li>
<li>Select the discount coach card you have from the drop-down list</li></ul></p><br>
<p><strong>Type of fare </strong></p>
<ul> <li>Select whether you''d like to see Adult or Child fares</li>
<li>Select whether you''d like to see Single or Return fares.</li>
<li>Then click "Ok"</li></ul><br>
<p>These details will then be applied to the fares listed in the results.</p> 
<br><p><strong>Amend date and time</strong><br>To amend the dates and times of your journey:
<br>1. Select the new date(s) and time(s) in the drop-down lists
<br>2. Click ''Search with new dates/times''<br><br>
To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br><p><strong>Save as a favourite journey</strong><br>To save the journey:
<br>1.   Make sure you are logged in<br>2.   Enter a meaningful name for the journey (e.g. �Journey to work�)
<br>3. Click ''OK''<br><br>You can save up to five journeys and you can overwrite existing journeys.</p>
<br><p><strong>Send to a friend</strong>To send this page to a friend:<br>1. Make sure you are logged in.
<br>  2. If you are not logged in, you will need to enter your username and password.
<br>3. Type in the email address of the person you would like to send the page to in the box<br>4. Click ''Send''
<br><br>A text-based email with a summary of the journey and the details/directions will be sent to that 
email address.  Maps (if applicable) will be attached as an image file (Avg. email size 150k).
Your email address will be shown in the email.</p><br>'
,
'Mae''r dudalen hon yn dangos y tocynnau am y siwrnai a ddewisisyd. Ceir diagram o''ch siwrnai ar ochr 
llaw chwith y dudalen a rhestrir y tocynnau teitho yn y tablau yn ei ymyl. Os hoffech weld 
tocynnau teithio am y siwrnai hon yn unig, heb y diagram, cliciwch ar "Dangos mewn tabl".<br><br>
<p><strong>Public Transport</strong></p>
<p>Rhestrir y tocynnau teithio ar gyfer pob adran o''r daith os oes gan Transport Direct yr wybodaeth am
 y tocyn teithio.<br><br>    I weld yr Adwerthwyr tocynnau am y tocynnau hyn:<br>
<u1>1. Dewiswch y tocyn(nau) teithio y mae gennych yn ey prynu. Nid oes raid i chi brynu tocyn am bob
 rhan o''r siwrnai
<br>�2. Cliciwch ar "Prynu tocynnau"<br><br>
<p><strong>Costau siwrneion:</strong> <br></p><ul><li>Mae''r costau isod yn gysylltiedig �''ch siwrnai<br></li></ul><p>
Os yw''r siwrnai yn ymwneud � ffer�au neu dollau, nodir costau''r rhain os ydynt ar gael. 
I gael mwy o wybodaeth ynglyn �''r ffer�au neu''r tollau gallwch glicio ar yr enw i gael eich cymryd i''w gwefannau.
</p>
<br>
<p><strong>Diwygiwch fanylion y tocyn</strong></p>
<p> I ddiwygio manylion am docynnau:<br><br> <strong>Cardiau disgownt</strong>
<ul> <li>Dewiswch y cerdyn rheilffordd disgownt sydd gennych o''r rhestr a ollyngir i lawr</li>
<li>Dewiswch y cerdyn bws disgownt sydd gennych o''r rhestr a ollyngir i lawr</li></ul></p><br>
<p><strong>Math o docyn</strong></p>
<ul> <li>Dewiswch p''run ai a hoffech weld tocynnau Oedolion neu Blant</li>
<li>Dewiswch p''run ai a hoffech weld tocynnau Sengl neu Fynd a Dod</li>
<li>Yna cliciwch ''Iawn''</li></ul><br>
<p>Cymhwysir y manylion hyn wedyn at y tocynnau a restrwyd yn y canlyniadau.</p><br>
<p><strong>Newidiwch y dyddiad a''r amser</strong><br>I ddiwygio dyddiadau ac amserau eich siwrnai:
<br>1. Dewiswch y dyddiad(au) a''r amser(au) newydd yn y rhestrau a ollyngir i lawr
<br>2. Cliciwch ar ''Chwiliwch gyda dyddiadau/amserau newydd''<br><br>
I ddiwygio''r siwrnai gyfan, gallwch glicio ''Diwygiwch y siwrnai'' ar frig y dudalen.</p>
<br><p><strong>Cadwch fel hoff siwrnai</strong><br>I gadw''r siwrnai:
<br>1.   Gofalwch eich bod wedi logio i mewn
<br>2.   Rhowch enw ystyrlon i''r siwrnai (e.e. ''Siwrnai i''r gwaith'')
<br>3. Cliciwch ar ''Iawn''.<br><br>Gallwch gadw hyd at bump siwrnai a gallwch ysgrifennu dros 
siwrneion presennol.</p><br><p><strong>Anfonwch y dudalen hon at ffrind drwy ebost</strong>
<br>I anfon y dudalen hon at ffrind:<br>1. Gofalwch eich bod wedi logio i mewn.
<br>  2. Os nad ydych wedi logio i mewn, bydd yn rhaid i chi roi eich enw defnyddiwr a''ch cyfrinair.
<br>3. Teipiwch gyfeiriad ebost y sawl yr hoffech anfon y dudalen atynt yn y blwch
<br>4. Cliciwch ''Anfon''<br><br>Anfonir ebost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau 
at y cyfeiriad ebost hwnnw.  Atodir mapiau (os yn berthnasol) fel ffeil ddelwedd (maint ebost cyfartalog 150k). 
Dangosir eich cyfeiriad ebost yn yr e-bost.</p><br>'


GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 881
SET @ScriptDesc = 'Help fares page updated to include car help'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------