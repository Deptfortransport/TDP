-- ************************************************************
-- NAME 		: DUP0811_Special_NoticeBoard.sql
-- DESCRIPTION 	: Provides content for SpecialNoticeBoard.aspx
-- AUTHOR		: apatel
-- ************************************************************
USE Content
GO

DECLARE @MaxGroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'specialnoticeboard')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'specialnoticeboard')
GO


DECLARE @GroupId INT
SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'specialnoticeboard'

EXEC AddtblContent
1, @GroupId,'SpecialNoticeBoardHtmlPlaceholder','/Channels/TransportDirect/SpecialNoticeBoard'
,' <br><table id="Table2" cellspacing="0" cellpadding="0" width="100%" border="0"><tr><td width="40">&nbsp;</td><td><h2>Car Park Information (20th December 2006)</h2><br><p style="font-size: 0.8em; text-align: justify">Transport Direct is developing a Car Parking Database which will ultimately cover the whole of Great Britain. The first set of car park information is now available on the site. The latest set of car park information has been added. This includes local authority and NCP sites in the towns and cities listed below. We will be expanding our information to include other privately-operated car parks in these areas. We will keep this page updated.</p><br><table style="font-size: 0.8em; text-align: justify" id="Table3" cellspacing="1" cellpadding="1" width="100%" border="0"><tr><td width="33%" colspan="1" rowspan="1">Aberdeen</td><td width="33%" colspan="1" rowspan="1">Folkestone</td><td>Plymouth</td></tr><tr><td>Aberystwyth</td><td>Frome</td><td>Portsmouth</td></tr><tr><td>Ashford (Kent)</td><td>Glasgow</td><td>Preston (Lancs)</td></tr><tr><td>Banbury</td><td>Grantham</td><td>Reading</td></tr><tr><td>Bangor</td><td>Greater London</td><td>Ripon</td></tr><tr><td>Barnsley</td><td>Great Yarmouth</td><td>Rotherham</td></tr><tr><td>Barnstaple</td><td>Grimsby</td><td>Royal Leamington Spa</td></tr><tr><td>Basingstoke</td><td>Guildford</td><td>St. Albans</td></tr><tr><td>Bath</td><td>Halifax</td><td>St. Davids</td></tr><tr><td>Bedford</td><td>Harrogate</td><td>Salford (Greater Manchester)</td></tr><tr><td>Berwick-upon-Tweed</td><td>Hartlepool</td><td>Salisbury</td></tr><tr><td>Birmingham</td><td>Harwich</td><td>Scarborough</td></tr><tr><td>Blackpool</td><td>Hastings</td><td>Scunthorpe</td></tr><tr><td>Bolton (Greater Manchester)</td><td>Hereford</td>
<td>Sheffield</td></tr><tr><td>Bournemouth</td><td>Huddersfield</td><td>Shrewsbury</td></tr><tr><td>Bradford</td>
<td>Hull</td><td>Skegness</td></tr><tr><td>Brighton</td><td>Inverness</td><td>Southampton</td></tr><tr><td>
Bristol</td><td>Ipswich</td><td>Southend-on-Sea</td></tr><tr><td>Burnley</td><td>Kettering</td><td>Southport</td>
</tr><tr><td>Bury St. Edmonds</td><td>Kings Lynn</td><td>Stafford</td></tr><tr><td>Cambridge</td><td>Kingston-upon-Hill</td><td>Stevenage</td></tr><tr><td>Canterbury</td><td>Lancaster</td><td>Stirling</td></tr><tr><td>
Cardiff</td><td>Leamington Spa</td><td>Stockport</td></tr><tr><td>Carlisle</td><td>Leeds</td><td>Stockton-on-Tees</td></tr></table></td></tr></table>',' <br><table id="Table2" cellspacing="0" cellpadding="0" width="100%" border="0"><tr><td width="40">&nbsp;</td><td><h2>Car Park Information (20th December 2006)</h2><br><p style="font-size: 0.8em; text-align: justify">Transport Direct is developing a Car Parking Database which will ultimately cover the whole of Great Britain. The first set of car park information is now available on the site. The latest set of car park information has been added. This includes local authority and NCP sites in the towns and cities listed below. We will be expanding our information to include other privately-operated car parks in these areas. We will keep this page updated.</p><br><table style="font-size: 0.8em; text-align: justify" id="Table3" cellspacing="1" cellpadding="1" width="100%" border="0"><tr><td width="33%" colspan="1" rowspan="1">Aberdeen</td><td width="33%" colspan="1" rowspan="1">Folkestone</td><td>Plymouth</td></tr><tr><td>Aberystwyth</td><td>Frome</td><td>Portsmouth</td></tr><tr><td>Ashford (Kent)</td><td>Glasgow</td><td>Preston (Lancs)</td></tr><tr><td>Banbury</td><td>Grantham</td><td>Reading</td></tr><tr><td>Bangor</td><td>Greater London</td><td>Ripon</td></tr><tr><td>Barnsley</td><td>Great Yarmouth</td><td>Rotherham</td></tr><tr><td>Barnstaple</td><td>Grimsby</td><td>Royal Leamington Spa</td></tr><tr><td>Basingstoke</td><td>Guildford</td><td>St. Albans</td></tr><tr><td>Bath</td><td>Halifax</td><td>St. Davids</td></tr><tr><td>Bedford</td><td>Harrogate</td><td>Salford (Greater Manchester)</td></tr><tr><td>Berwick-upon-Tweed</td><td>Hartlepool</td><td>Salisbury</td></tr><tr><td>Birmingham</td><td>Harwich</td><td>Scarborough</td></tr><tr><td>Blackpool</td><td>Hastings</td><td>Scunthorpe</td></tr><tr><td>Bolton (Greater Manchester)</td><td>Hereford</td><td>Sheffield</td></tr><tr><td>Bournemouth</td><td>Huddersfield</td><td>Shrewsbury</td></tr><tr><td>Bradford</td><td>Hull</td><td>Skegness</td></tr><tr><td>Brighton</td><td>Inverness</td><td>Southampton</td></tr><tr><td>Bristol</td><td>Ipswich</td><td>Southend-on-Sea</td></tr><tr><td>Burnley</td><td>Kettering</td><td>Southport</td></tr><tr><td>Bury St. Edmonds</td><td>Kings Lynn</td><td>Stafford</td></tr><tr><td>Cambridge</td><td>Kingston-upon-Hill</td><td>Stevenage</td></tr><tr><td>Canterbury</td><td>Lancaster</td><td>Stirling</td></tr><tr><td>Cardiff</td><td>Leamington Spa</td><td>Stockport</td></tr><tr><td>Carlisle</td><td>Leeds</td><td>Stockton-on-Tees</td></tr></table></td></tr></table>'
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 811
SET @ScriptDesc = 'Adds content to the Special NoticeBoard page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------