-- ***********************************************
-- NAME 		: DUP0810_TipofTheDay_changes.sql
-- DESCRIPTION 		: Database changes for displaying TipofTheDay on Wait Page
-- AUTHOR		: darshan sawe
-- Date 		: 17-March-2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [Content]
GO

If exists (select * from [dbo].tblGroup where GroupId = 32)
  Begin
    Update [dbo].tblGroup
    Set Name = 'journeyplanning_waitpage'
    where GroupId = 32
  End
Else
  Begin
    Insert Into [dbo].tblGroup (GroupId, Name)
    Values (32, 'journeyplanning_waitpage')
  End
Go


EXEC dbo.[AddtblContent]
	1,
	32,
	'MessageDefinition',
	'/Channels/TransportDirect/JourneyPlanning/WaitPage',
	'We are always seeking to improve our service. If you cannot find what you want, please tell us by clicking <b>Contact us</b>',
	'cy - We are always seeking to improve our service. If you cannot find what you want, please tell us by clicking <b>Contact us</b>'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'WaitPage.TitleTipOfTheDay',
	'<b>Tip of the Day</b><br /><br />',
	'cy - <b>Tip of the Day</b><br /><br />'



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 810
SET @ScriptDesc = 'Database changes for displaying TipofTheDay on Wait Page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------