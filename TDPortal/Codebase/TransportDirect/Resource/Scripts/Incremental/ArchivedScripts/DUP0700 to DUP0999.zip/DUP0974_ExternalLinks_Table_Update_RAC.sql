-- ***********************************************
-- NAME 		: DUP0974_ExternalLinks_Update.sql
-- DESCRIPTION 		: Script to change RAC Related links URL
-- DESCRIPTION 		: on C02 Fuel Consumption page
-- AUTHOR		: Neil Rankin
-- DATE			: 26 June 2008 14:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT - External Link
-----------------------------------------------------

USE TransientPortal
Go


UPDATE dbo.ExternalLinks SET
		URL = 'http://www.rac.co.uk/web/know-how/hints-tips/fuel-consumption.htm' , 
		TestURL = 'http://www.rac.co.uk/web/know-how/hints-tips/fuel-consumption.htm'
		WHERE Description like '%Fuel Saving Tips%'
Go


UPDATE dbo.ChangeNotification SET
		Version = Version + 1
		Where [Table] like '%ExternalLinks%'
Go


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 974
SET @ScriptDesc = 'Change RAC Related links URL on C02 Fuel Consumption page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO