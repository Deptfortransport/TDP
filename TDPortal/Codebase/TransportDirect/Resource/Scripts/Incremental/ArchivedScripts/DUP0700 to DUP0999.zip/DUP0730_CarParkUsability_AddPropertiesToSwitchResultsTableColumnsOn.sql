-- ***********************************************
-- NAME 		: DUP0730_CarParkUsability_AddPropertiesToSwitchResultsTableColumnsOn.sql
-- DESCRIPTION 	: Add property table entries for the new columns on the
--				: Car Park results table
-- AUTHOR		: mmodi
-- ************************************************
USE PermanentPortal
GO

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.ShowIsSecure')
BEGIN
	insert into properties values ('FindCarParkResults.ShowIsSecure', 'True', '<DEFAULT>', '<DEFAULT>', 0)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'FindCarParkResults.ShowIsSecure'
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.ShowNumberOfSpaces')
BEGIN
	insert into properties values ('FindCarParkResults.ShowNumberOfSpaces', 'True', '<DEFAULT>', '<DEFAULT>', 0)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'FindCarParkResults.ShowNumberOfSpaces'
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.ShowDisabledSpaces')
BEGIN
	insert into properties values ('FindCarParkResults.ShowDisabledSpaces', 'True', '<DEFAULT>', '<DEFAULT>', 0)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'FindCarParkResults.ShowDisabledSpaces'
END

GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 730
SET @ScriptDesc = 'Update properties to turn on Car Park results table data columns'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------