-- ***********************************************
-- NAME 		: DUP0999_SaveApplicableTocs.sql
-- DESCRIPTION 		: Script to add saveapplicatbletocs stored proc
-- AUTHOR		: James Chapman
-- DATE			: 26 June 2008 18:00:00
-- ************************************************

 USE [TransientPortal]
GO

/****** Object:  StoredProcedure [dbo].[SaveApplicableTocs]    Script Date: 06/12/2008 14:44:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SaveApplicableTocs]
	-- Add the parameters for the stored procedure here
		@TicketTypeCode	varchar(10),
		@AllTocs bit,
		@TocAndConnections text
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	Declare @ApplicableTocsId Int

	Select @ApplicableTocsId = ApplicableTocs_Id From ApplicableTocs Where TicketTypeCode = @TicketTypeCode
	
	Delete From IncludedTocs Where ApplicableTocs_Id = @ApplicableTocsId
	
	Delete From ExcludedTocs Where ApplicableTocs_Id = @ApplicableTocsId
	
	Delete From ApplicableTocs Where TicketTypeCode = @TicketTypeCode

    -- Insert statements for procedure here
	Insert Into ApplicableTocs 
		(
		TicketTypeCode,
		AllTocs,
		TocAndConnections
		)
		Values
		(
		@TicketTypeCode,
		@AllTocs,
		@TocAndConnections
		)
		
		select @@Identity
		
	
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 999
SET @ScriptDesc = 'Script to add saveapplicatbletocs stored proc'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO