-- ***********************************************
-- NAME 		: DUP0800_Correct_Homepage_Left_Hand_Typos.sql
-- DESCRIPTION 	: Corrects some typos on the left menu homepage
-- AUTHOR		: Steve Barker
-- ************************************************


USE [TransientPortal]
GO

-- 'Transport Network Maps' --> 'Network Maps'
UPDATE
	Resource
SET
	[Text] = 'Network maps'
WHERE
	ResourceNameId = 18
		AND 
	Culture = 'en-GB'
	
-- 'Mobile demonstrator' --> 'Mobile/PDA'
UPDATE
	Resource
SET
	[Text] = 'Mobile/PDA'
WHERE
	ResourceNameId = 25
		AND 
	Culture = 'en-GB'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 800
SET @ScriptDesc = 'Corrects some typos on the left menu homepage'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
