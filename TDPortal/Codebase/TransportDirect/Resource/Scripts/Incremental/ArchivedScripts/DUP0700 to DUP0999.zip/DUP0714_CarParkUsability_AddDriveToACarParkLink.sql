-- ***********************************************
-- NAME 		: DUP0704_CarParkUsability_AddDriveToACarParkLink.sql
-- DESCRIPTION 	: Add the Drive to a car park link to the homepage =
--				: context
--
-- ************************************************

Use TransientPortal
GO

exec AddInternalSuggestionLink 
'JourneyPlanning/FindCarParkInput.aspx?DriveFromTo=true',
				'link to find nearest carpark with drivefromto',
				'FindNearestCarParkDriveTo',
				'Drive to a car park',
				'cy-Drive to a car park',
				'Plan a journey',
				120,
				0,
				'HomePageMenu',
				''
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 714
SET @ScriptDesc = 'Add Drive to car park link to homepage'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------