-- *************************************************************************************
-- NAME 		: DUP0772_Added_Menu_For_TermsAndPolicy_Page.sql
-- DESCRIPTION  : Added left menu for Terms And Conditions, Privacy policy, Data Providers, Accessibility  pages
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- This will set up menu for Terms And Policy pages

USE [TransientPortal]
GO

-----------------------------------------------------------
-- Add Link Category for AboutUs

-- Adding Link Categories we want
DECLARE @LinkCategoryId INT
DECLARE @LinkPriority INT

-- Adding Link Category for AboutUs

SELECT @LinkCategoryId = Max(LinkCategoryId)+1 FROM LinkCategory

SELECT @LinkPriority = Max(Priority) + 10 FROM LinkCategory 

IF NOT EXISTS (SELECT TOP 1 * from LinkCategory WHERE [Name] = 'TermsAndPolicy')
BEGIN
	INSERT INTO LinkCategory VALUES(@LinkCategoryId, @LinkPriority, 'TermsAndPolicy', 'Terms And Policy pages menu')
END

GO

------------------------------------------------------------
-- Add the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link 1 for the Terms And Condition page title link at top
SET @RelativeURL = NULL
SET @InternalLinkDescription = 'Terms And Condition'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

-- Link 2 for the Privacy Policy page title link at top
SET @RelativeURL = NULL
SET @InternalLinkDescription = 'Privacy Policy'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 3 for the Data Providers page title link at top
SET @RelativeURL = NULL
SET @InternalLinkDescription = 'Data Providers'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 4 for the Data Providers page title link at top
SET @RelativeURL = NULL
SET @InternalLinkDescription = 'Accessibility'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	

-- Link 5 for the Introduction
SET @RelativeURL = 'About/TermsConditions.aspx'
SET @InternalLinkDescription = 'TermsConditions Link'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 6 for the privacy policy link
SET @RelativeURL = 'About/PrivacyPolicy.aspx'
SET @InternalLinkDescription = 'Privacy Policy link'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 7 for the data provider link
SET @RelativeURL = 'About/DataProviders.aspx'
SET @InternalLinkDescription = 'Data Provider link'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 8 for the accessibility link
SET @RelativeURL = 'About/Accessibility.aspx'
SET @InternalLinkDescription = 'Accessibility link'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	


GO

------------------------------------------------------------
-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT

-- Link 1
SET @LinkResourceName = 'TermsConditions'
SET @LinkResourceNameEN = 'Terms & conditions'
SET @LinkResourceNameCY = 'Amodau a thelerau''r wefan'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
	

-- Link 2
SET @LinkResourceName = 'PrivacyPolicy'
SET @LinkResourceNameEN = 'Privacy policy'
SET @LinkResourceNameCY = 'Polisi preifatrwydd'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
	

-- Link 3
SET @LinkResourceName = 'DataProviders'
SET @LinkResourceNameEN = 'Data Providers'
SET @LinkResourceNameCY = 'Darparwyr data'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-- Link 4
SET @LinkResourceName = 'Accessibility'
SET @LinkResourceNameEN = 'Accessibility'
SET @LinkResourceNameCY = 'Hygyrchedd'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



GO	


------------------------------------------------------------
--insert into SuggestionLink table
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100)

DECLARE @InternalLinkDescription varchar(500)

-- Link 1
SET @LinkResourceName = 'TermsConditions'
SET @InternalLinkDescription = 'Terms And Condition'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7300
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1, 0 , 0

-- Link 2
SET @LinkResourceName = 'PrivacyPolicy'
SET @InternalLinkDescription = 'Privacy Policy'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7310
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1,0,0

-- Link 3
SET @LinkResourceName = 'DataProviders'
SET @InternalLinkDescription = 'Data Providers'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7320
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal',1,0,0

-- Link 4
SET @LinkResourceName = 'Accessibility'
SET @InternalLinkDescription = 'Accessibility'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7330
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1,0,0


-- Link 5
SET @LinkResourceName = 'TermsConditions'
SET @InternalLinkDescription = 'TermsConditions Link'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7400
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0
	
-- Link 6
SET @LinkResourceName = 'PrivacyPolicy'
SET @InternalLinkDescription = 'Privacy Policy link'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7410
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0

-- Link 7
SET @LinkResourceName = 'DataProviders'
SET @InternalLinkDescription = 'Data Provider link'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7420
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0

-- Link 8
SET @LinkResourceName = 'Accessibility'
SET @InternalLinkDescription = 'Accessibility link'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @LinkPriority = 7430
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0

GO

----------------------------------------------------------------------------------------------------
-- Add menu for Terms & Condition Page
----------------------------------------------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'TermsConditionsMenu'
SET @ContextDescription = 'Links for expandable menu on the Terms & Conditions page.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT,
	@InternalExternalLinkID INT

DECLARE @InternalLinkDescription varchar(500)

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'TermsConditions'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Terms And Condition'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'TermsConditions'

SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'TermsConditions Link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'PrivacyPolicy'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Privacy Policy link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'DataProviders'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Data Provider link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 5
SET @LinkResourceName = 'Accessibility'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Accessibility link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


GO

----------------------------------------------------------------------------------------------------
-- Add menu for Privacy Policy Page
----------------------------------------------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'PrivacyPolicyMenu'
SET @ContextDescription = 'Links for expandable menu on the Privacy Policy page.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT,
	@InternalExternalLinkID INT

DECLARE @InternalLinkDescription varchar(500)

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'PrivacyPolicy'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Privacy Policy'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'TermsConditions'

SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'TermsConditions Link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'PrivacyPolicy'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Privacy Policy link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'DataProviders'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Data Provider link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 5
SET @LinkResourceName = 'Accessibility'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Accessibility link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


GO

----------------------------------------------------------------------------------------------------
-- Add menu for Data Providers Page
----------------------------------------------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'DataProvidersMenu'
SET @ContextDescription = 'Links for expandable menu on the Data Providers page.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT,
	@InternalExternalLinkID INT

DECLARE @InternalLinkDescription varchar(500)

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'DataProviders'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Data Providers'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'TermsConditions'

SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'TermsConditions Link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'PrivacyPolicy'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Privacy Policy link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'DataProviders'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Data Provider link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 5
SET @LinkResourceName = 'Accessibility'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Accessibility link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

GO

----------------------------------------------------------------------------------------------------
-- Add menu for Accessibility Page
----------------------------------------------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'AccessibilityMenu'
SET @ContextDescription = 'Links for expandable menu on the Accessibility page.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT,
	@InternalExternalLinkID INT

DECLARE @InternalLinkDescription varchar(500)

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'Accessibility'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Accessibility'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'TermsConditions'

SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'TermsConditions Link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'PrivacyPolicy'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Privacy Policy link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'DataProviders'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Data Provider link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 5
SET @LinkResourceName = 'Accessibility'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'TermsAndPolicy'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @InternalLinkDescription = 'Accessibility link'
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND ExternalInternalLinkId =@InternalExternalLinkID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 772
SET @ScriptDesc = 'Added left menu for Terms And Conditions, Privacy policy, Data Providers, Accessibility  pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO