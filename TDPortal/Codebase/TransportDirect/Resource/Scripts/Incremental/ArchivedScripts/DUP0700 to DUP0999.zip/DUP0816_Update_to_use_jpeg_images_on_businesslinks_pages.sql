-- ************************************************************
-- NAME 		: DUP0816_Update_to_use_jpeg_images_on_businesslinks_pages.sql
-- DESCRIPTION 		: Updates the database to refer to some images on the BusinessLinks.aspx pages with a .jpg extension instead of .gif
-- AUTHOR		: Dan Gath
-- ************************************************************
USE Content
GO

update tblContent set [Value-EN]='/Web2/App_Themes/TransportDirect/images/gifs/Misc/BusinessLinksExample1.jpg',[Value-CY]='/Web2/App_Themes/TransportDirect/images/gifs/Misc/BusinessLinksExample1Welsh.jpg' where PropertyName='BusinessLinks.imageBusinessLinksExample1.ImageURL'
update tblContent set [Value-EN]='/Web2/App_Themes/TransportDirect/images/gifs/Misc/BusinessLinksExample2.jpg',[Value-CY]='/Web2/App_Themes/TransportDirect/images/gifs/Misc/BusinessLinksExample2Welsh.jpg' where PropertyName='BusinessLinks.imageBusinessLinksExample2.ImageURL'
update tblContent set [Value-EN]='/Web2/App_Themes/TransportDirect/images/gifs/Misc/BusinessLinksExample3.jpg',[Value-CY]='/Web2/App_Themes/TransportDirect/images/gifs/Misc/BusinessLinksExample3Welsh.jpg' where PropertyName='BusinessLinks.imageBusinessLinksExample3.ImageURL'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 816
SET @ScriptDesc = 'Updates file extensions for some image files on BusinessLinks page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------