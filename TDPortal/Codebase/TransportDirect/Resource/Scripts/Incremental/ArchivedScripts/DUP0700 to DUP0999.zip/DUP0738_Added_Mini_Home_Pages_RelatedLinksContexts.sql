-- ***********************************************
-- NAME 		: DUP0738_Added_Mini_Home_Pages_RelatedLinksContexts.sql
-- DESCRIPTION 	: Added Mini Home page related links
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

-------------------------------------------------------------------------
-- Journey Planning Home Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextHomeJourneyPlanning'
SET @ContextDescription = 'Related Link Context - Suggestions for Journey Planning Home Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO

-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'LiveTravel/TravelNews.aspx',
	'Travel News Page',
	'LiveTravelNews',
	'Live Travel News',
	'Newyddion teithio byw',
	'Related links',
	1140,
	0,
	'RelatedLinksContextHomeJourneyPlanning',
	'Related Link Context - Suggestions for Journey Planning Home Page'
GO

EXEC AddInternalSuggestionLink 
	'LiveTravel/DepartureBoards.aspx',
	'Departure boards',
	'DepartureBoards',
	'Departure boards',
	'Byrddau cyrraedd a chychwyn',
	'Related links',
	1150,
	0,
	'RelatedLinksContextHomeJourneyPlanning',
	'Related Link Context - Suggestions for Journey Planning Home Page'
GO

EXEC AddInternalSuggestionLink 
	'TDOnTheMove/TDOnTheMove.aspx',
	'Mobile/PDA',
	'MobileDemonstrator',
	'Mobile demonstrator',
	'Symudol/PDA',
	'Related links',
	1160,
	0,
	'RelatedLinksContextHomeJourneyPlanning',
	'Related Link Context - Suggestions for Journey Planning Home Page'
GO


EXEC AddInternalSuggestionLink 
	'Help/NewHelp.aspx',
	'FAQ Page',
	'HELPFAQ',
	'Frequently Asked Questions',
	'Cwestiynau a Ofynnir yn Aml',
	'Related links',
	1170,
	0,
	'RelatedLinksContextHomeJourneyPlanning',
	'Related Link Context - Suggestions for Journey Planning Home Page'
GO


EXEC AddInternalSuggestionLink 
	'JourneyPlanning/ParkAndRide.aspx',
	'Park And Ride Page',
	'ParkAndRide',
	'Park and ride schemes',
	'Cynlluniau Parcio a Theithio',
	'Related links',
	1180,
	0,
	'RelatedLinksContextHomeJourneyPlanning',
	'Related Link Context - Suggestions for Journey Planning Home Page'
GO


-------------------------------------------------------------------------
-- Maps Home Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextHomeMaps'
SET @ContextDescription = 'Related Link Context - Suggestions for Maps Home Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

--insert into ContextSuggestionLink table
DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT
	
-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO


-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'LiveTravel/TravelNews.aspx',
	'Travel News Page',
	'LiveTravelNews',
	'Live Travel News',
	'Newyddion teithio byw',
	'Related links',
	1190,
	0,
	'RelatedLinksContextHomeMaps',
	'Related Link Context - Suggestions for Maps Home Page'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/Home.aspx',
	'Journey Planning Homepage',
	'PlanAJourneyHomepage',
	'Plan a journey',
	'Cynlluniwch siwrnai',
	'Related links',
	1200,
	0,
	'RelatedLinksContextHomeMaps',
	'Related Link Context - Suggestions for Maps Home Page'
GO


EXEC AddInternalSuggestionLink 
	'Help/NewHelp.aspx',
	'FAQ Page',
	'HELPFAQ',
	'Frequently Asked Questions',
	'Cwestiynau a Ofynnir yn Aml',
	'Related links',
	1210,
	0,
	'RelatedLinksContextHomeMaps',
	'Related Link Context - Suggestions for Maps Home Page'
GO

-------------------------------------------------------------------------
-- Tips and Tools Home Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT
	
SET @ContextName = 'RelatedLinksContextHomeTools'
SET @ContextDescription = 'Related Link Context - Suggestions for Tools Home Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

--insert into ContextSuggestionLink table
DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT
	

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO




EXEC AddInternalSuggestionLink 
	'JourneyPlanning/Home.aspx',
	'Journey Planning Homepage',
	'PlanAJourneyHomepage',
	'Plan a journey',
	'Cynlluniwch siwrnai',
	'Related links',
	1220,
	0,
	'RelatedLinksContextHomeTools',
	'Related Link Context - Suggestions for Tools Home Page'
GO

-------------------------------------------------------------------------
-- Live Travel News Home Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT
	
SET @ContextName = 'RelatedLinksContextHomeLiveTravel'
SET @ContextDescription = 'Related Link Context - Suggestions for Live Travel News Home Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

--insert into ContextSuggestionLink table
DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO



EXEC AddInternalSuggestionLink 
	'JourneyPlanning/Home.aspx',
	'Journey Planning Homepage',
	'PlanAJourneyHomepage',
	'Plan a journey',
	'Cynlluniwch siwrnai',
	'Related links',
	1230,
	0,
	'RelatedLinksContextHomeLiveTravel',
	'Related Link Context - Suggestions for Live Travel News Home Page'
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 738
SET @ScriptDesc = 'Added Mini Home page related links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------