-- ***********************************************
-- NAME 		: DUP0955_Content_Update_for_outward_return_missing_errors.sql
-- DESCRIPTION 		: Script to add error messages
-- AUTHOR		: Phil Scott
-- DATE			: 20 Jun 2008 15:00:00
-- ************************************************

USE [Content]
GO

insert into tblContent (ThemeId,GroupId,ControlName,PropertyName,[Value-En],[Value-Cy]) values (1,1,'LangStrings','JourneyPlannerOutput.JourneyWebNoResultsOutward',
'Sorry we are currently unable to obtain outward journey options using the details you have entered. Please try changing the dates/times of travel or changing some of the details entered, such as the types of transport. Click ''Amend'' to revise your journey request.',
'Mae''n ddrwg gennym, rydym yn methu � chael dewisiadau siwrnai allan ar hyn o bryd gan ddefnyddio''r manylion a roddoch. Rhowch gynnig ar newid y dyddiadau/amser teithio neu newid rai o''r manylion a roddwyd, fel y mathau o gludiant. Cliciwch "Newid" i newid eich c'); 

insert into tblContent (ThemeId,GroupId,ControlName,PropertyName,[Value-En],[Value-Cy]) values (1,1,'LangStrings','JourneyPlannerOutput.JourneyWebNoResultsReturn',
'Sorry we are currently unable to obtain return journey options using the details you have entered. Please try changing the dates/times of travel or changing some of the details entered, such as the types of transport. Click ''Amend'' to revise your journey request.',
'Mae''n ddrwg gennym, rydym yn methu � chael dewisiadau siwrnai ddychwel ar hyn o bryd gan ddefnyddio''r manylion a roddoch. Rhowch gynnig ar newid y dyddiadau/amser teithio neu newid rai o''r manylion a roddwyd, fel y mathau o gludiant. Cliciwch "Newid" i newid eich c');




GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 955
SET @ScriptDesc = 'DUP0955_Content_Update_for_outward_return_missing_errors'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO