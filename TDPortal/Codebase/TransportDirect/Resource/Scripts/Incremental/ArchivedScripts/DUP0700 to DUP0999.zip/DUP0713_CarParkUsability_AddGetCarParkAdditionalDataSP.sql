-- ***********************************************
-- NAME 		: DUP0713_CarParkUsability_AddGetCarParkAdditionalDataSP.sql
-- DESCRIPTION 		: Add the getCarparkadditinaldatasp
--
-- ************************************************

Use TransientPortal
GO

-- create car parking additional data sp
/*
Returns row from the CarParkingAdditionalData, CarParkingOpenningTimes, =
and CarParkingCarParkSpace tablesfor the supplied=20
AddionalDataID.  The key is supplied as a parameter of type int.
*/
CREATE PROCEDURE dbo.GetCarParkAdditionalData
 @AdditionalDataID int
AS
BEGIN

select  
	cpOpeningTimes.OpensAt, cpOpeningTimes.ClosesAt, cpCarParkingSpace.NumberOfSpaces, 
	cpAdditional.MaximumWidth, cpAdditional.MaximumHeight, 
	cpAdditional.PMSPA, cpAdditional.AdvancedReservationsAvailable,
	cpCarParkingType.Description 
from 
	CarParkingAdditionalData as cpAdditional left join CarParkingOpeningTimes as cpOpeningTimes on cpOpeningTimes.Id = cpAdditional.OpeningTimesID
	left join CarParkingCarParkSpace as cpCarParkingSpace on cpCarParkingSpace.Id = cpAdditional.SpacesID
	left join CarParkingCarParkType as cpCarParkingType on cpCarParkingType.Id = cpAdditional.TypeID
where 
	cpAdditional.Id = @AdditionalDataID
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 713
SET @ScriptDesc = 'Add GetCarParkAdditionalData stored proc'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------