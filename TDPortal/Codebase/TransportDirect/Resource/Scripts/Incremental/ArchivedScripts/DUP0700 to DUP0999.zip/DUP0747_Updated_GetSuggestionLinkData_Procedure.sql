-- *************************************************************************************
-- NAME 		: DUP0747_Updated_GetSuggestionLinkData_Procedure.sql
-- DESCRIPTION 		: Update to GetSuggestionLinkData stored procedure for partner specific configuration
-- *************************************************************************************
USE [TransientPortal]
GO


-- Alter GetSuggestionLinkData stored procedure to select the IsRoot column
ALTER PROCEDURE [dbo].GetSuggestionLinkData 
	@ThemeName VARCHAR(100)
AS

DECLARE @ThemeId INT

EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT 
	
IF @ThemeId IS NULL
	BEGIN
	RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
	END

	
If NOT EXISTS (SELECT * 
					FROM ContextSuggestionLink
					WHERE ThemeId = @ThemeId)
	EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 
	

SELECT 	Context.[Name] ContextName, 
	SuggestionLink.SuggestionLinkId, 
	LinkCategory.Priority CategoryPriority, 
	LinkCategory.[Name] CategoryName,
	SuggestionLink.Priority LinkPriority, 
	InternalLink.RelativeURL, 
	Resource.Culture, 
	Resource.[Text] ResourceString, 
	SuggestionLink.IsRoot
FROM SuggestionLink 
	INNER JOIN ContextSuggestionLink 
		ON SuggestionLink.SuggestionLinkId = ContextSuggestionLink.SuggestionLinkId 
	INNER JOIN Context 
		ON ContextSuggestionLink.ContextId = Context.ContextId 
	INNER JOIN LinkCategory 
		ON SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId 
	INNER JOIN ResourceName 
		ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId 
	INNER JOIN Resource 
		ON ResourceName.ResourceNameId = Resource.ResourceNameId 
	INNER JOIN InternalLink 
		ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId 
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
WHERE ThemeId = @ThemeId
ORDER BY Context.ContextID, CategoryPriority, LinkPriority, Culture

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 747
SET @ScriptDesc = 'Update to GetSuggestionLinkData stored procedure for partner specific configuration'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
