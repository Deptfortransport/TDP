-- *************************************************************************************
-- NAME 		: DUP0790_CreateDefaultPartnerMenuLinks.sql
-- DESCRIPTION  	: This is a script to setup all the navigation links for a Partner.
-- 			: Part 1 is a stored procedure which returns all the links currently 
--			: in the left hand navigation and related links used by Transport Direct.
--			: The results of this stored procedure should be copied into a new script, 
--			: the links not requried deleted, see Part 2 for sample
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Mar 2008 18:00:00
-- *************************************************************************************

USE [TransientPortal]
GO

------------------------------------------------------------
-- Part 1. Returns all current links used sql to inset
------------------------------------------------------------
SELECT 'EXEC AddContextSuggestionLink '''
	+ ResourceName.ResourceName +''','''
	+ LinkCategory.[Name] +''','''
	+ Context.[Name] + '' 
	+ ''', @ThemeId'
	FROM ContextSuggestionLink
		Inner Join Context
			on ContextSuggestionLink.ContextId = Context.ContextId
		Inner Join SuggestionLink
			on ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		Inner Join ResourceName
			On SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
		Inner Join LinkCategory
			On SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId

	WHERE ContextSuggestionLink.ThemeId = 1 -- The default Transport Direct site
	ORDER BY Context.[Name]

GO

-----------------------------------------------------------------------------------------------------
-- Part 2. Sample partner script
-- - Ensure sections marked are updated with results from above querry
-----------------------------------------------------------------------------------------------------

USE [TransientPortal]
GO

DECLARE @ThemeId INT

-- Change to actual Theme Id value from Content.tblTheme
SET @ThemeId = 99 

-- Copy results of query in Part 1 here
-- Then delete any links not required.
--
-- HEADINGS: ResourceName, LinkCategory, Context, Theme
-- Context value determines the page it is displayed on
--
-- e.g. 
-- EXEC AddContextSuggestionLink 'FindCarInput','General','ParkAndRide', @ThemeId
-- EXEC AddContextSuggestionLink 'FindCarInput','General','ParkAndRide', @ThemeId
-- --link not included EXEC AddContextSuggestionLink 'LiveTravelNews','General','ParkAndRide', @ThemeId
-- --link not included EXEC AddContextSuggestionLink 'HELPFAQ','General','ParkAndRide', @ThemeId
-- EXEC AddContextSuggestionLink 'ParkAndRide','General','FindCarInput', @ThemeId
-- ...

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 790
SET @ScriptDesc = 'Added script to set up partner left hand menu links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
