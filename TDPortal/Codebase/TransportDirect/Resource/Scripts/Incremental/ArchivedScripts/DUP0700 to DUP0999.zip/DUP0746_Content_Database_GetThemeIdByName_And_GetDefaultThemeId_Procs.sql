-- *************************************************************************************
-- NAME 		: DUP0746_Content_Database_GetThemeIdByName_And_GetDefaultThemeId_Procs.sql
-- DESCRIPTION 		: Added GetThemeIdByName and GetDefaultThemeId stored procedures in Content Database
-- *************************************************************************************
USE [Content]
GO

--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetThemeIdByName'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetThemeIdByName] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------

ALTER PROCEDURE [dbo].GetThemeIdByName
	@ThemeName VARCHAR(100),
	@ThemeId INT OUTPUT
AS
BEGIN
	SELECT 
		@ThemeId = ThemeId 
	FROM tblTheme
	WHERE [Name] = @ThemeName
END

GO


--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetDefaultThemeId'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetDefaultThemeId] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------

ALTER PROCEDURE [dbo].GetDefaultThemeId
	@ThemeId INT OUTPUT
AS 
BEGIN
	SELECT 
		@ThemeId = ThemeId 
	FROM tblTheme
	WHERE [Name] = 'TransportDirect'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 746
SET @ScriptDesc = 'Added GetThemeIdByName and GetDefaultThemeId stored procedures in Content Database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
