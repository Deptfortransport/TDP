-- ************************************************************
-- NAME 		: DUP0814_Updated_text_for_RefineDetails_Map_Button_Welsh.sql
-- DESCRIPTION 	: Provides updated text for Welsh Label for Map Button on RefineDetails.aspx
-- AUTHOR		: S Johal
-- ************************************************************
USE Content
GO

update tblContent set [Value-CY]='Map o�r rhan hon o�r siwrnai' where ContentId='54181'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 814
SET @ScriptDesc = 'Provides updated text for Welsh Label for Map Button on RefineDetails.aspx'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------