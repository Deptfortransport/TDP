-- ***********************************************
-- NAME 		: DUP0871_ITP_Content_Update.sql
-- DESCRIPTION 		: Script to add URL and Alt Text for ITP journey icon to database
-- AUTHOR		: Dan Gath
-- DATE			: 18 Jun 2008 10:00:00
-- ************************************************

USE [Content]
GO

insert into tblContent (ThemeId,GroupId,ControlName,PropertyName,[Value-En],[Value-Cy]) values (1,1,'VisitPlanner','TransportModesControl.imageAir_Coach_RailAltText','Travel by combined modes','cy- Travel by combined modes');
insert into tblContent (ThemeId,GroupId,ControlName,PropertyName,[Value-En],[Value-Cy]) values (1,1,'VisitPlanner','TransportModesControl.imageAir_Coach_RailURL',' /Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/mixedmodes.gif',' /Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/mixedmodes.gif');
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 871
SET @ScriptDesc = 'URL and Alt Text for ITP journey icon'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO