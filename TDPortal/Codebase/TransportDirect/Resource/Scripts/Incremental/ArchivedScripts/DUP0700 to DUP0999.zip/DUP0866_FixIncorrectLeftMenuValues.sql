-- ***********************************************
-- NAME 		: DUP0866_FixIncorrectLeftMenuValues.sql
-- DESCRIPTION 		: Fixes incorrect left menu values
-- AUTHOR		: Dan Gath
-- DATE			: 30 Mar 2008 20:23:00
-- ************************************************

-----------------------------------------------------------------------
-- Properties 
-----------------------------------------------------------------------

USE [TransientPortal]
GO

update Resource set Text='Find nearest car park' where ResourceId='61'
update Resource set Text='Darganfyddwch y maes parcio agosaf' where ResourceId='62'
update Resource set Text='How can I offset my car''s carbon emissions?' where ResourceId='65'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 866
SET @ScriptDesc = 'Fix incorrect left menu values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO