-- ***********************************************
-- NAME 		: DUP0728_Added_Car_Parking_Data_Delete_Proc.sql
-- DESCRIPTION 		: Adds sql procedure to delete data from CarParks database tables
-- AUTHOR		: Devfactory
-- ************************************************

-- *****
-- ***** EXECUTE permissions below MUST be checked for each environment prior to implementation
-- *****

USE CarParks
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteCarParkingData]')  
AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[DeleteCarParkingData]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- Create new stored procedure
CREATE PROCEDURE dbo.DeleteCarParkingData 
AS

SET NOCOUNT ON
SET XACT_ABORT ON



BEGIN TRANSACTION T1
		DELETE FROM [dbo].[CarParkingAdditionalData]
		DELETE FROM [dbo].[CarParkingPaymentType] 
		DELETE FROM [dbo].[CarParkingPaymentMethods] 
		DELETE FROM [dbo].[CarParkingOpeningTimes]
		DELETE FROM [dbo].[CarParkingFacilities] 
		DELETE FROM [dbo].[CarParkingAttractions] 
		DELETE FROM [dbo].[CarParkingFacilitiesType] 
		DELETE FROM [dbo].[CarParkingAttractionType]
		DELETE FROM [dbo].[CarParkingCarParkCharges]
		DELETE FROM [dbo].[CarParkingCarParkChargeType] 
		DELETE FROM [dbo].[CarParkingSpaceAvailability] 
		DELETE FROM [dbo].[CarParkingCarParkConcessions] 	
		DELETE FROM [dbo].[CarParkingCalendar]
		DELETE FROM [dbo].[CarParkingCarParkSpace] 
		DELETE FROM [dbo].[CarParkingSpaceType]
		DELETE FROM [dbo].[CarParkingCarParkType] 
		DELETE FROM [dbo].[CarParkingNPTGLocality]
		DELETE FROM [dbo].[CarParking] 
		DELETE FROM [dbo].[CarParkingOperator] 
		DELETE FROM [dbo].[CarParkingTrafficNewsRegion]
		DELETE FROM [dbo].[CarParkingAccessPoints]
		DELETE FROM [dbo].[CarParkingNPTGAdminDistrict]
		
		DELETE FROM [dbo].[CarParkingParkAndRideScheme]
		DELETE FROM [dbo].[CarParkingLinkedNaPTANS] 
		
COMMIT TRANSACTION T1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 728
SET @ScriptDesc = 'Add new DeleteCarParkingData procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------