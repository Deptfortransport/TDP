-- ************************************************************
-- NAME 	: DUP0707_TravelNewsAll_Update_To_Add_RoadType_Column.sql
-- DESCRIPTION 	: Updates the TraveNewsAll stored proc to return the RoadType column
-- ************************************************************

USE [TransientPortal]
GO

---------------------------------------------------------------------
-- Update TravelNewsAll
----------------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE dbo.TravelNewsAll
AS
SET NOCOUNT ON


SELECT
	TN.UID,
	TN.SeverityLevel,
	TNS.SeverityDescription,
	TN.PublicTransportOperator,
	ISNULL(TN.PublicTransportOperator, '-') Operator,
	TN.ModeOfTransport,
	TN.Regions,
	TN.Location,
	TN.Regions + ' (' + TN.Location + ')' RegionsLocation,
	TN.IncidentType,
	TN.HeadlineText,
	TN.DetailText,
	TN.IncidentStatus,
	TN.Easting,
	TN.Northing,
	TN.ReportedDateTime,
	TN.StartDateTime,
	DateDiff(mi, TN.StartDateTime, GetDate()) StartToNowMinDiff,
	TN.LastModifiedDateTime,
	TN.ClearedDateTime,
	TN.ExpiryDateTime,
	TN.PlannedIncident,
	TN.RoadType
FROM (((TravelNews TN INNER JOIN TravelNewsSeverity TNS ON TN.SeverityLevel = TNS.SeverityID)
	 INNER JOIN TravelNewsDataSource TNDS1 ON TN.UID = TNDS1.UID)
	 INNER JOIN TravelNewsDataSources TNDSS ON TNDS1.DataSourceId = TNDSS.DataSourceId)

WHERE TNDSS.Trusted = 1
ORDER BY SeverityLevel ASC, StartDateTime DESC



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber =707
SET @ScriptDesc = 'Updated again TravelNewsAll stored procedure to return new RoadType column'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
