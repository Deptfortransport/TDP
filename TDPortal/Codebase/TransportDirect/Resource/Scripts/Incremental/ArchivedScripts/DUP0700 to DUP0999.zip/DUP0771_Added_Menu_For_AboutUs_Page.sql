-- *************************************************************************************
-- NAME 		: DUP0771_Added_Menu_For_AboutUs_Page.sql
-- DESCRIPTION  : Added left menu for About us page
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- This will set up menu for AboutUs page

USE [TransientPortal]
GO

-----------------------------------------------------------
-- Add Link Category for AboutUs

-- Adding Link Categories we want
DECLARE @LinkCategoryId INT
DECLARE @LinkPriority INT

-- Adding Link Category for AboutUs

SELECT @LinkCategoryId = Max(LinkCategoryId)+1 FROM LinkCategory

SELECT @LinkPriority = Max(Priority) + 10 FROM LinkCategory 

IF NOT EXISTS (SELECT TOP 1 * from LinkCategory WHERE [Name] = 'AboutUs')
BEGIN
	INSERT INTO LinkCategory VALUES(@LinkCategoryId, @LinkPriority, 'AboutUs', 'AboutUs menu')
END

GO

------------------------------------------------------------
-- Add the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link 1 for the AboutUs page
SET @RelativeURL = NULL
SET @InternalLinkDescription = 'AboutUs'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	

-- Link 2 for the Introduction
SET @RelativeURL = 'About/AboutUs.aspx#Introduction'
SET @InternalLinkDescription = 'Introduction'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 3 for the Enabling Intelligent Travel
SET @RelativeURL = 'About/AboutUs.aspx#EnablingIntelligentTravel'
SET @InternalLinkDescription = 'Enabling Intelligent Travel'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 4 for the Who operates transport direct
SET @RelativeURL = 'About/AboutUs.aspx#WhoOperates'
SET @InternalLinkDescription = 'Who operates transport direct'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 5 for the Who builds transport direct
SET @RelativeURL = 'About/AboutUs.aspx#WhoBuilds'
SET @InternalLinkDescription = 'Who builds transport direct'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 6 for the What's Next
SET @RelativeURL = 'About/AboutUs.aspx#WhatsNext'
SET @InternalLinkDescription = 'What is Next'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

GO

------------------------------------------------------------
-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT

-- Link 1
SET @LinkResourceName = 'AboutUs'
SET @LinkResourceNameEN = 'About us'
SET @LinkResourceNameCY = 'Amdanom ni'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 2
SET @LinkResourceName = 'AboutUs.Introduction'
SET @LinkResourceNameEN = 'Introduction'
SET @LinkResourceNameCY = 'Rhagarweiniad'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 3
SET @LinkResourceName = 'AboutUs.EnablingIntelligentTravel'
SET @LinkResourceNameEN = 'Enabling intelligent travel'
SET @LinkResourceNameCY = 'Galluogi teithio deallus'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 4
SET @LinkResourceName = 'AboutUs.WhoOperates'
SET @LinkResourceNameEN = 'Who operates Transport Direct?'
SET @LinkResourceNameCY = 'Pwy sy''n gweithredu Transport Direct?' 

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
	
-- Link 5
SET @LinkResourceName = 'AboutUs.WhoBuilds'
SET @LinkResourceNameEN = 'Who builds and develops this site?'
SET @LinkResourceNameCY = 'Pwy sy''n adeiladu a datblygu''r safle hwn?' 

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
	
-- Link 6
SET @LinkResourceName = 'AboutUs.WhatNext'
SET @LinkResourceNameEN = 'What''s next?'
SET @LinkResourceNameCY = 'Beth nesaf?' 

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

GO	


------------------------------------------------------------
--insert into SuggestionLink table
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100)

DECLARE @InternalLinkDescription varchar(500)

-- Link 1
SET @LinkResourceName = 'AboutUs'
SET @InternalLinkDescription = 'AboutUs'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @LinkPriority = 7000
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1, 0 , 0

-- Link 2
SET @LinkResourceName = 'AboutUs.Introduction'
SET @InternalLinkDescription = 'Introduction'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @LinkPriority = 7010
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0

-- Link 3
SET @LinkResourceName = 'AboutUs.EnablingIntelligentTravel'
SET @InternalLinkDescription = 'Enabling Intelligent Travel'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @LinkPriority = 7020
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal',0,0,0

-- Link 4
SET @LinkResourceName = 'AboutUs.WhoOperates'
SET @InternalLinkDescription = 'Who operates transport direct'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @LinkPriority = 7030
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0


-- Link 5
SET @LinkResourceName = 'AboutUs.WhoBuilds'
SET @InternalLinkDescription = 'Who builds transport direct'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @LinkPriority = 7040
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0
	
-- Link 6
SET @LinkResourceName = 'AboutUs.WhatNext'
SET @InternalLinkDescription = 'What is Next'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @LinkPriority = 7050
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0

GO


------------------------------------------------------------
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'AboutUsMenu'
SET @ContextDescription = 'Links for expandable menu on the AboutUs page.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'AboutUs'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'AboutUs.Introduction'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'AboutUs.EnablingIntelligentTravel'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'AboutUs.WhoOperates'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 5
SET @LinkResourceName = 'AboutUs.WhoBuilds'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 6
SET @LinkResourceName = 'AboutUs.WhatNext'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'AboutUs'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 771
SET @ScriptDesc = 'Added left menu for About us page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

-----------------------------------------------------------------
-- Update text in resource
-----------------------------------------------------------------

USE [TransientPortal]
GO

update [dbo].[Resource]
set text = 'Estimating my car''s CO2 emissions' where resourceid = 85
GO