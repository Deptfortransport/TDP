-- ***********************************************
-- NAME 		: DUP0751_Update_FindNearestCarPark_InternalLink.sql
-- DESCRIPTION 		: Add find nearest true parameter to FindNearestCarPark link
-- AUTHOR		: mmodi
-- ************************************************
USE [TransientPortal]
GO

-- The link already exists so will update based on the link description
EXEC AddInternalLink 
	'JourneyPlanning/FindCarParkInput.aspx?FindNearest=true',
	'Find Nearest Car Park Input Page'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 751
SET @ScriptDesc = 'Update Find car park input internal link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------