-- ************************************************************
-- NAME 		: DUP0837_Car_Park_Brackets_Removed.sql
-- DESCRIPTION 	: Removes the brackets from "car park(s)"
-- AUTHOR		: SBarker
-- ************************************************************
USE Content
GO

UPDATE tblContent SET [Value-en] = 'Nearest car parks' WHERE ContentId = 53406	
UPDATE tblContent SET [Value-en] = 'Car parks found for' WHERE ContentId = 53421	
UPDATE tblContent SET [Value-en] = 'Car parks found for' WHERE ContentId = 53420	
UPDATE tblContent SET [Value-en] = 'Car parks found for' WHERE ContentId = 54657
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 837
SET @ScriptDesc = 'Removes the brackets from "car park(s)"'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------