-- ***********************************************
-- NAME 		: DUP0851_Repair_Corrupted_Symbols.sql
-- DESCRIPTION 		: Replaces some corrupted symbols with the correct characters
-- AUTHOR		: Dan Gath
-- Date 		: 27 March 2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [Content]
GO

update tblContent
Set [value-en] = '
<DIV class="Column3Header"> <DIV class="txtsevenbbl">MITESH Save fuel and cut your CO2!</DIV><!-- Don''t remove spaces -->
&nbsp;</DIV> <DIV class="Column3Content"> 
<TABLE cellSpacing="0" cellPadding="2" width="100%" border="0"> <TBODY> <TR> 
<TD class="txtseven" colSpan="2"> <TABLE cellSpacing="0" cellPadding="0" width="100%" border="0"> 
<TBODY> <TR> <TD colSpan="2">Drive off peak to avoid congestion </TD></TR> <TR> <TD vAlign="top" width="15"> 
<LI></LI></TD> <TD>Congestion costs fuel and CO2. 
Use Transport Direct to find out the least congested time to drive. <BR><BR></TD></TR> <TR> 
<TD colSpan="2">Drive smoothly </TD></TR> <TR> <TD vAlign="top" width="15"> <LI></LI></TD> 
<TD>You save 30% on fuel and CO2 when you drive at a steady 50 mph instead of 70 mph. <BR><BR></TD></TR> <TR> 
<TD colSpan="2">Drive at 70 mph&nbsp;on the motorway </TD></TR> <TR> <TD vAlign="top" width="15"> 
<LI></LI></TD> <TD>Sticking to the speed limit could save you up to �5 on a 100 mile motorway journey. <BR><BR>
</TD></TR> <TR> <TD colSpan="2">Check your tyres </TD></TR> <TR> <TD vAlign="top" width="15"> <LI></LI></TD>
<TD>Soft tyres will increase your fuel bill by around �2 on a 100 mile round trip. <BR><BR></TD></TR> <TR> 
<TD colSpan="2">Service your car </TD></TR> <TR> <TD vAlign="top" width="15"> <LI></LI></TD> 
<TD>Dirty petrol and oil filters reduce your cars fuel efficiency. </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>',
[value-cy]='<DIV class="Column3Header">  <DIV class="txtsevenbbl">Arbedwch danwydd a chwtogi ar eich CO2!</DIV><!-- Don"t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</DIV>  <DIV class="Column3Content">  <TABLE cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="txtseven" colSpan="2">  <TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">  <TBODY>  <TR>  <TD colSpan="2">Gyrrwch yn ystod oriau allfrig i osgoi tagfeydd </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Mae tagfeydd yn costio tanwydd a CO2. Defnyddiwch Transport Direct i gael gwybod yr amser lleiaf prysur i yrru. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Gyrrwch yn esmwyth </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Rydych chi"n arbed 30% ar danwydd a CO2 pan fyddwch chi"n gyrru 50 m.y.a. yn gyson yn lle 70 m.y.a. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Gyrrwch 70 m.y.a. ar y draffordd</TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Drwy gadw at y cyfyngiad cyflymdra, fe allech arbed hyd at �5 ar siwrnai 100 milltir ar y draffordd.<BR><BR></TD></TR>  <TR>  <TD colSpan="2">Edrychwch dros eich teiars </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Bydd teiars meddal yn cynyddu eich bil tanwydd rhyw �2 ar daith ddydd 100 milltir. <BR><BR></TD></TR>  <TR>  <TD colSpan="2">Cofiwch drin eich car </TD></TR>  <TR>  <TD vAlign="top" width="15">  <LI></LI></TD>  <TD>Mae hidlwyr petrol ac olew brwnt yn lleihau effeithlonrwydd tanwydd eich car. </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>'
WHERE ContentId='73516' AND groupid = 66

update tblContent
Set [value-en] ='<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Registering with Transport Direct is optional.  You can still access most of our features without registering but once registered you can:</p><br/><ul><li>Save your favourite journeys so you can access them again in the future without having to re-enter any information.</li><li>Save travel preferences when entering information for a journey so you don''t have to enter them again � but you still have the option to change them if you wish.</li><li>Email travel options to other people</li></ul><br/><p>It is easy to register, simply enter your email address in the box above, then choose a password between 4 and 12 characters, retype your password, click register and you''re done.</p><br/></div></div>',
[value-cy]='cy <div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Registering with Transport Direct is optional.  You can still access most of our features without registering but once registered you can:</p><br/><ul><li>Save your favourite journeys so you can access them again in the future without having to re-enter any information.</li><li>Save travel preferences when entering information for a journey so you don�t have to enter them again � but you still have the option to change them if you wish.</li><li>Email travel options to other people</li></ul><br/><p>It is easy to register, simply enter your email address in the box above, then choose a password between 4 and 12 characters, retype your password, click register and you''re done.</p><br/></div></div>'
where ContentId='73515' AND groupid = 65

update tblContent set [value-cy]='Map o''r rhan hon o''r siwrnai' where ContentId='54181' and GroupId='1'

GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 851
SET @ScriptDesc = 'Replaces some corrupted symbols with the correct characters'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------
