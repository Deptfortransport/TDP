-- ************************************************************
-- NAME 	: DUP0749_SelectProperties_Procedure_Update.sql
-- DESCRIPTION 	: Updating SelectProperties Procedures
-- ************************************************************
--

USE [PermanentPortal]
GO

---------------------------------------------------
-- 1. SelectApplicationPropertiesWithPartnerId Procedure change
----------------------------------------------------


--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'SelectApplicationPropertiesWithPartnerId'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[SelectApplicationPropertiesWithPartnerId] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
ALTER PROCEDURE SelectApplicationPropertiesWithPartnerId
(
	@AID char(50),
	@ThemeName varchar(100)
)	 
AS
BEGIN

DECLARE @ThemeId INT
DECLARE @DefaultThemeId INT

EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT

IF @ThemeId IS NULL
	BEGIN
	RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
	END

EXEC [Content].[dbo].[GetDefaultThemeId] @DefaultThemeId OUTPUT 
	

	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE
	FROM PROPERTIES P
	WHERE P.AID = @AID
	AND P.ThemeId = @ThemeId
	
	UNION ALL
	(
	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE
	FROM PROPERTIES P
	WHERE 
		[PNAME] + '|' + [PVALUE] IN
		(
			SELECT DISTINCT [PNAME] + '|' + [PVALUE]
			FROM PROPERTIES P
			WHERE P.AID = @AID
			--1 is the TransportDirect ThemeId
			AND P.ThemeId = @DefaultThemeId 
			AND [PNAME] + '|' + [PVALUE] NOT IN
			(
				SELECT DISTINCT [PNAME] + '|' + [PVALUE]
				FROM PROPERTIES P
				WHERE P.AID = @AID
				AND P.ThemeId = @ThemeId
			)
		)
	AND
	P.AID = @AID
	AND 
	P.ThemeId = @DefaultThemeId 

	)

END
GO

----------------------------------------------------------------
-- 2.SelectGlobalPropertiesWithPartnerId
----------------------------------------------------------------

--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'SelectGlobalPropertiesWithPartnerId'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[SelectGlobalPropertiesWithPartnerId] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
ALTER PROCEDURE SelectGlobalPropertiesWithPartnerId
(
	@ThemeName varchar(100)
)
AS
BEGIN
DECLARE @ThemeId INT
DECLARE @DefaultThemeId INT

EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT

IF @ThemeId IS NULL
	BEGIN
	RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
	END

EXEC [Content].[dbo].[GetDefaultThemeId] @DefaultThemeId OUTPUT 


	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE
	FROM PROPERTIES P
	WHERE P.AID = '<DEFAULT>'
	AND P.GID = '<DEFAULT>'
	AND P.ThemeId = @ThemeId

UNION ALL
	(
	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE
	FROM PROPERTIES P
	WHERE 
		[PNAME] + '|' + [PVALUE] IN
		(
			SELECT DISTINCT [PNAME] + '|' + [PVALUE]
			FROM PROPERTIES P
			WHERE P.AID = '<DEFAULT>'
			AND P.GID = '<DEFAULT>'
			--1 is the TransportDirect ThemeId
			AND P.ThemeId = @DefaultThemeId 
			AND [PNAME] + '|' + [PVALUE] NOT IN
			(
				SELECT DISTINCT [PNAME] + '|' + [PVALUE]
				FROM PROPERTIES P
				WHERE P.AID = '<DEFAULT>'
				AND P.GID = '<DEFAULT>'
				AND P.ThemeId = @ThemeId
			)
		)
	AND
	P.AID = '<DEFAULT>'
	AND 
	P.GID = '<DEFAULT>'
	AND
	P.ThemeId = @DefaultThemeId 
	)

END
GO

-----------------------------------------------------------
-- 3. SelectGroupPropertiesWithPartnerId
-----------------------------------------------------------

--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'SelectGroupPropertiesWithPartnerId'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[SelectGroupPropertiesWithPartnerId] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
ALTER PROCEDURE SelectGroupPropertiesWithPartnerId
(
	@GID char(50),
	@ThemeName varchar(100)
)
AS
BEGIN

DECLARE @ThemeId INT
DECLARE @DefaultThemeId INT

EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT

IF @ThemeId IS NULL
	BEGIN
	RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
	END

EXEC [Content].[dbo].[GetDefaultThemeId] @DefaultThemeId OUTPUT 


	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE
	FROM PROPERTIES P
	WHERE P.GID = @GID
	AND P.ThemeId = @ThemeId
UNION ALL
	(
	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE
	FROM PROPERTIES P
	WHERE 
		[PNAME] + '|' + [PVALUE] IN
		(
			SELECT DISTINCT [PNAME] + '|' + [PVALUE]
			FROM PROPERTIES P
			WHERE P.GID = @GID
			--1 is the TransportDirect ThemeId (DEFAULT)
			AND P.ThemeId = @DefaultThemeId 
			AND [PNAME] + '|' + [PVALUE] NOT IN
			(
				SELECT DISTINCT [PNAME] + '|' + [PVALUE]
				FROM PROPERTIES P
				WHERE P.GID = @GID
				AND P.ThemeId = @ThemeId
			)
		)
	AND 
	P.GID = @GID
	AND
	P.ThemeId = @DefaultThemeId 
	)

END
GO



-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 749
SET @ScriptDesc = 'Updating SelectProperties Procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO