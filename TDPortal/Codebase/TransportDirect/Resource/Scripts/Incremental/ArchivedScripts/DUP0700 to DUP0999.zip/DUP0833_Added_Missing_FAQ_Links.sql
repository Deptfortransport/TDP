-- *************************************************************************************
-- NAME 		: DUP0833_Added_Missing_FAQ_Links.sql
-- DESCRIPTION  	: Add missing FAQ resource text and links
-- AUTHOR		: Mitesh Modi
-- *************************************************************************************


USE [TransientPortal]
GO

EXEC AddResource 
'FAQ.Train','Train','Tr�n'

EXEC AddResource 
'FAQ.Bus','Bus','Bws'

EXEC AddResource 
'FAQ.LiveTravel','Live travel','Teithio byw'

EXEC AddResource 
'FAQ.CO2Information','CO2 Information','Gwybodaeth CO2'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 833
SET @ScriptDesc = 'Added missing FAQ links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO