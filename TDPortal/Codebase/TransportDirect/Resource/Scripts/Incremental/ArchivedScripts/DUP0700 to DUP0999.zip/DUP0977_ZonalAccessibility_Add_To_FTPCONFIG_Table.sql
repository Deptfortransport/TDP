-- ***********************************************
-- NAME 		: DUP0977_ZonalAccessibility_Add_To_FTPCONFIG_Table.sql
-- DESCRIPTION 		: Add Zonal Accessibility data to FTP_CONFIG table
-- AUTHOR		: Sanjeev Johal
-- ************************************************

Use PermanentPortal
go
--insert into FTP_Config table
IF NOT EXISTS (SELECT * FROM FTP_CONFIGURATION WHERE [FTP_CLIENT] = 1)
BEGIN
INSERT INTO [dbo].[FTP_CONFIGURATION] ([FTP_CLIENT], [DATA_FEED], [IP_ADDRESS], [USERNAME], [PASSWORD], [LOCAL_DIR], [REMOTE_DIR], [FILENAME_FILTER], [MISSING_FEED_COUNTER], [MISSING_FEED_THRESHOLD], [DATA_FEED_DATETIME], [DATA_FEED_FILENAME], [REMOVE_FILES])
VALUES ('1', 'ert444', 'Localhost', 'TDP28Nov', 'sI1732#3-', 'c:/Gateway/dat/Incoming/ert444', '../ert444', '*.zip', 0, 1, '2007-11-11 00:00:00.000', ' ', 1)
END
go


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 977
SET @ScriptDesc = 'Add Zonal Accessibility data to FTP_CONFIG table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------