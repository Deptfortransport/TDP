-- ************************************************************
-- NAME 		: DUP0843_Welsh_Translation_For_Related_Links_Heading.sql
-- DESCRIPTION 	: Provides Welsh translation for Related Links Headings
-- AUTHOR		: S Johal
-- ************************************************************
USE TransientPortal
GO

update Resource set Text ='Dolennau cysylltiedig' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'RelatedLinks')
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 843
SET @ScriptDesc = 'Provides Welsh translation for Related Links Headings'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------