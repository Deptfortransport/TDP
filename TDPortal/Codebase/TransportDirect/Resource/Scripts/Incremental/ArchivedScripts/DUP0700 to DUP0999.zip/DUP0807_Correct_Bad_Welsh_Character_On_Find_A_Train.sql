-- *************************************************************************************
-- NAME 		: DUP0807_Correct_Bad_Welsh_Character_On_Find_A_Train.sql
-- DESCRIPTION  : Corrects a dodgy character that found its way into the script for the Welsh version of Find a Train
-- AUTHOR		: Steve Barker
-- *************************************************************************************


USE [TransientPortal]
GO


-- Correcting a dodgy character for find a train...
UPDATE
	Resource
SET
	[Text] = 'Canfyddwch dr�n'
WHERE
	ResourceNameId = 8
		AND 
	Culture = 'cy-GB'


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 807
SET @ScriptDesc = 'Corrects a dodgy character that found its way into the script for the Welsh version of Find a Train'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
