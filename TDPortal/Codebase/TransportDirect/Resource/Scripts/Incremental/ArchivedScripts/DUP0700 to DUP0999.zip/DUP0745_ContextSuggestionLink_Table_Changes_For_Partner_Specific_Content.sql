-- *************************************************************************************
-- NAME 		: DUP0745_ContextSuggestionLink_Table_Changes_For_Partner_Specific_Content.sql
-- DESCRIPTION 		: Adds new column ThemeId in ContextSuggestionLink Table for partner specific configuration
-- *************************************************************************************
USE [TransientPortal]
GO


IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('ContextSuggestionLink')
						AND syscolumns.name = 'ThemeId')

ALTER TABLE ContextSuggestionLink ADD [ThemeId] INT  NOT NULL DEFAULT(1)
	
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 745
SET @ScriptDesc = 'Adds new column ThemeId in ContextSuggestionLink Table for partner specific configuration'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
