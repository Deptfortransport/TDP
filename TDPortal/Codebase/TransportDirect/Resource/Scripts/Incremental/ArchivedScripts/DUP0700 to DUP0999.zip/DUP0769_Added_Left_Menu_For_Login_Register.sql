-- *************************************************************************************
-- NAME 		: DUP0769_Added_Left_Menu_For_Login_Register.sql
-- DESCRIPTION  : Added left menu for login register
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- This will set up menu for Login/Register page

USE [TransientPortal]
GO

-----------------------------------------------------------
-- Add Link Category for Login/Register

-- Adding Link Categories we want
DECLARE @LinkCategoryId INT
DECLARE @LinkPriority INT

-- Adding Link Category for Network Maps

SELECT @LinkCategoryId = Max(LinkCategoryId)+1 FROM LinkCategory

SELECT @LinkPriority = Max(Priority) + 10 FROM LinkCategory 

IF NOT EXISTS (SELECT TOP 1 * from LinkCategory WHERE [Name] = 'LoginRegister')
BEGIN
	INSERT INTO LinkCategory VALUES(@LinkCategoryId, @LinkPriority, 'LoginRegister', 'Login register menu')
END

GO

------------------------------------------------------------
-- Add the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link 1 for the Login/Register page
SET @RelativeURL = NULL
SET @InternalLinkDescription = 'Login/Register'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	

-- Link 2 for the existing user
SET @RelativeURL = 'LoginRegister.aspx'
SET @InternalLinkDescription = 'Existing user'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 3 for the register
SET @RelativeURL = 'LoginRegister.aspx'
SET @InternalLinkDescription = 'Register'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link 4 for the Why Should I Register
SET @RelativeURL = 'LoginRegister.aspx'
SET @InternalLinkDescription = 'Why should I register'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

GO


------------------------------------------------------------
-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT

-- Link 1
SET @LinkResourceName = 'LoginRegister'
SET @LinkResourceNameEN = 'Login/Register'
SET @LinkResourceNameCY = 'cy Login/Register'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 2
SET @LinkResourceName = 'LoginRegister.ExistingUser'
SET @LinkResourceNameEN = 'Existing user'
SET @LinkResourceNameCY = 'cy Existing user'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 3
SET @LinkResourceName = 'LoginRegister.Register'
SET @LinkResourceNameEN = 'Register'
SET @LinkResourceNameCY = 'cy Register'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 4
SET @LinkResourceName = 'LoginRegister.WhyRegister'
SET @LinkResourceNameEN = 'Why should I register'
SET @LinkResourceNameCY = 'cy Why should I register' 

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
GO	
------------------------------------------------------------
--insert into SuggestionLink table
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100)

DECLARE @InternalLinkDescription varchar(500)

-- Link 1
SET @LinkResourceName = 'LoginRegister'
SET @InternalLinkDescription = 'Login/Register'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @LinkPriority = 6000
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1, 0 , 0

-- Link 2
SET @LinkResourceName = 'LoginRegister.ExistingUser'
SET @InternalLinkDescription = 'Existing user'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @LinkPriority = 6010
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0

-- Link 3
SET @LinkResourceName = 'LoginRegister.Register'
SET @InternalLinkDescription = 'Register'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @LinkPriority = 6020
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal',0,0,0

-- Link 4
SET @LinkResourceName = 'LoginRegister.WhyRegister'
SET @InternalLinkDescription = 'Why should I register'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @LinkPriority = 6030
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,0,0
GO

------------------------------------------------------------
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'HomePageMenuLoginRegister'
SET @ContextDescription = 'Links for expandable menu on the Login / Register pages.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'LoginRegister'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'LoginRegister.ExistingUser'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'LoginRegister.Register'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'LoginRegister.WhyRegister'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'LoginRegister'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkID, @ContextId, @SuggestionLinkID, @ThemeId


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 769
SET @ScriptDesc = 'Added left menu for login register'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
