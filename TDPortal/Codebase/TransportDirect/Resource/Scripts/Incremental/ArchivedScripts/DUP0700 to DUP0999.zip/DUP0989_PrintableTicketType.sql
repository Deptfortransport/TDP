-- ***********************************************
-- NAME 		: DUP0989_PrintableTicketType.sql
-- DESCRIPTION 		: Script to add content for the Printable Ticket Type page
-- AUTHOR		: James Chapman
-- DATE			: 26 June 2008 18:00:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT
SET @ThemeId = 1

----------------------------------------------------------
-- Header text
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.labelPageTitle', 'Rail Ticket Type Information', 'cy-Rail Ticket Type Information'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.descriptionTitle', 'Description', 'cy-Description'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.validityTitle', 'Validity', 'cy-Validity'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.sleepersTitle', 'Sleepers', 'cy-Sleepers'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.discountTitle', 'Discounts', 'cy-Discounts'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.availabilityTitle', 'Availability', 'cy-Availability'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.bookingDeadlinesTitle', 'Booking Deadlines', 'cy-Booking Deadlines'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.refundsTitle', 'Refunds', 'cy-Refunds'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.ticketNotFound', 'Ticket Type Not Recognised', 'cy-Ticket Type Not Recognised'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.conditions', 'Conditions', 'cy-Ticket Conditions'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.breakOfJourney', 'Breaks of Journey', 'cy-Breaks of Journey'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.internetOnly', 'Internet Only', 'cy-Internet Only'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.changesToTravelPlans', 'Changes to Travel Plans', 'cy-Changes to Travel Plans'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.retailing', 'Retailing', 'cy-Retailing'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableTicketType.packages', 'Packages', 'cy-Packages'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 989
SET @ScriptDesc = 'Content added for Printable Ticket Type page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO