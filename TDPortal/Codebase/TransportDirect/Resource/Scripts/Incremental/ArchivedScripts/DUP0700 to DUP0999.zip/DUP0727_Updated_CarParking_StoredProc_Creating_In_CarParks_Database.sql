-- ***********************************************
-- NAME 		: DUP0727_Updated_CarParking_StoredProc_Creating_In_CarParks_Database.sql
-- DESCRIPTION 		: Change it to generate the stored proc used by carparking interface
--					  in new CarParks Database
-- AUTHOR		: Devfactory
-- ************************************************

Use CarParks
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingData]
END
GO

CREATE PROCEDURE dbo.GetCarParkingData
@CarParkKey varchar(50)
AS
	BEGIN
    SELECT 
	CarParking.Reference,
	CarParking.OperatorId,
	CarParking.AccessPointsMapId,
	CarParking.AccessPointsEntranceId,
	CarParking.AccessPointsExitId,
	CarParking.TrafficNewsRegionId, 
	CarParking.ParkAndRideSchemeId,
	CarParking.NPTGAdminDistrictId,
	CarParking.Name,
	CarParking.Location,
	CarParking.Address,
	CarParking.Postcode,
	CarParking.Notes,
	CarParking.Telephone,
	CarParking.Url,
	CarParking.MinCost,
	CarParking.ParkAndRide,
	CarParking.StayType,
	CarParking.PlanningPoint,
	CarParking.DateRecordLastUpdated,
	CarParking.WEUDate,
	CarParking.WEFDate

FROM
	CarParking 

	WHERE Reference = @CarParkKey
END
GO

-- create get car parking operator sp

/*
Returns columns from the CarParkingOperator table for the supplied 
operator key.  The operator key is supplied as a parameter of type int.
*/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkOperatorData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkOperatorData]
END
GO

CREATE PROCEDURE dbo.GetCarParkOperatorData
 @OperatorKey varchar (50)
AS
BEGIN
SELECT
	CarParkingOperator.OperatorCode, 
	CarParkingOperator.OperatorName, 
	CarParkingOperator.OperatorURL, 
	CarParkingOperator.OperatorTsAndCs, 
	CarParkingOperator.OperatorEmail

FROM
	CarParkingOperator 

WHERE
	CarParkingOperator.OperatorCode = @OperatorKey
END
GO

-- create get car parking park and ride scheme sp
/*
Returns columns from the CarParkingParkAndRideScheme table for the supplied 
scheme key.  The scheme key is supplied as a parameter of type int.
*/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingParkAndRideData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingParkAndRideData]
END
GO

CREATE PROCEDURE dbo.GetCarParkingParkAndRideData
@SchemeKey int
AS
BEGIN
SELECT
	CarParkingParkAndRideScheme.Id, 
	CarParkingParkAndRideScheme.Location, 
	CarParkingParkAndRideScheme.SchemeURL, 
	CarParkingParkAndRideScheme.Comments, 
	CarParkingParkAndRideScheme.LocationEasting, 
	CarParkingParkAndRideScheme.LocationNorthing,
	CarParkingParkAndRideScheme.TransferFrequency, 
	CarParkingParkAndRideScheme.TransferFrom, 
	CarParkingParkAndRideScheme.TransferTo

FROM
	CarParkingParkAndRideScheme 

WHERE
	CarParkingParkAndRideScheme.Id = @SchemeKey
END
GO

-- create get traffic news region sp
/*
Returns columns from the CarParkingTrafficNewsRegion table for the supplied 
traffic news region key.  The region key is supplied as a parameter of type int.
*/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingRegionData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingRegionData]
END
GO

CREATE PROCEDURE dbo.GetCarParkingRegionData
    @RegionKey int
AS
BEGIN
    SELECT
            CPTNR.Id,
            CPTNR.RegionName
            
    FROM
            dbo.CarParkingTrafficNewsRegion as CPTNR

	WHERE
            CPTNR.Id = @RegionKey
END
GO

-- create get nptg admin district sp
/*
Returns columns from the CarParkingParkAndRideScheme table for the supplied 
NPTG admin district key.  The district key is supplied as a parameter of type int.
*/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingAdminData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingAdminData]
END
GO

CREATE PROCEDURE dbo.GetCarParkingAdminData
 @DistrictKey int

AS
BEGIN
SELECT
	CarParkingNPTGAdminDistrict.Id, 
	CarParkingNPTGAdminDistrict.AdminAreaCode,
	CarParkingNPTGAdminDistrict.DistrictCode

FROM
	CarParkingNPTGAdminDistrict 

WHERE
	CarParkingNPTGAdminDistrict.Id = @DistrictKey

END
GO

-- create car parking access points stored procedure
/*
Returns row from the CarParkingAccessPoints table for the supplied 
access point key.  The key is supplied as a parameter of type int.
*/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkAccessPointData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkAccessPointData]
END
GO

CREATE PROCEDURE dbo.GetCarParkAccessPointData
 @AccessKey int
AS
BEGIN
SELECT

CarParkingAccessPoints.Id,
CarParkingAccessPoints.GeocodeType,
CarParkingAccessPoints.Easting,
CarParkingAccessPoints.Northing,
CarParkingAccessPoints.StreetName,
CarParkingAccessPoints.BarrierInOperation

FROM
	CarParkingAccessPoints 

WHERE
	CarParkingAccessPoints.Id = @AccessKey
END
GO

-- create car parking additional data sp
/*
Returns row from the CarParkingAdditionalData, CarParkingOpenningTimes, 
and CarParkingCarParkSpace tables for the supplied
CarParkingId. 
*/

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkAdditionalData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkAdditionalData]
END
GO

CREATE PROCEDURE dbo.GetCarParkAdditionalData
 @CarParkingId varchar (50)
AS
BEGIN

SELECT 
	cpOpeningTimes.OpensAt, cpOpeningTimes.ClosesAt, ISNULL(cpCarParkingSpace.totalSpaces,0) NumberOfSpaces, 
	ISNULL(cpAdditional.MaximumWidth,0) MaximumWidth, ISNULL(cpAdditional.MaximumHeight,0) MaximumHeight, 
	cpAdditional.PMSPA, cpAdditional.AdvancedReservationsAvailable,
	ISNULL(cpCarParkingType.Description,'') Description, ISNULL(disabledSpaces.totalDisabledSpaces,0) totalDisabledSpaces
FROM
	CarParkingAdditionalData AS cpAdditional 
	LEFT JOIN CarParkingOpeningTimes AS cpOpeningTimes 
		ON cpOpeningTimes.CarParkRef = cpAdditional.CarParkingId
	LEFT JOIN (SELECT CarParkRef,SUM(ISNULL(NumberOfSpaces,0)) as totalSpaces
			FROM CarParkingCarParkSpace
			INNER JOIN CarParkingSpaceType
				ON CarParkingCarParkSpace.SpaceTypeId = CarParkingSpaceType.TypeCode
			GROUP BY CarParkRef) cpCarParkingSpace 
		ON cpCarParkingSpace.CarParkRef = cpAdditional.CarParkingId
	LEFT JOIN CarParkingCarParkType AS cpCarParkingType 
		ON cpCarParkingType.CarParkRef = cpAdditional.CarParkingId
	LEFT JOIN (SELECT CarParkRef,SUM(ISNULL(NumberOfSpaces,0)) as totalDisabledSpaces
			FROM CarParkingCarParkSpace
			INNER JOIN CarParkingSpaceType
				ON CarParkingCarParkSpace.SpaceTypeId = CarParkingSpaceType.TypeCode
			WHERE CarParkingSpaceType.Description = 'Disabled' 
				OR CarParkingSpaceType.Description = 'Shopmobility'
			GROUP BY CarParkRef) disabledSpaces
		ON disabledSpaces.CarParkRef = cpAdditional.CarParkingId
WHERE
	cpAdditional.CarParkingId= @CarParkingId
END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber =727
SET @ScriptDesc = 'Created CarPark Stored Proc in CarParks Database instead of Transient Portal Database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO