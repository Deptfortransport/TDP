-- ***********************************************
-- NAME 		: DUP0797_CarParks_ContentUpdates.sql
-- DESCRIPTION 		: Added car park right hand content
-- AUTHOR		: Mitesh Modi
-- DATE			: 10 Mar 2008 18:00:00
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 59, 'carParksPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarParkInput', 
'<DIV class="Column3Header">
<DIV class="txtsevenbbl">Car Parks in Transport Direct</DIV>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</DIV>
<DIV class="Column3Content">
<TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="txtseven">We can provide&nbsp; a comprehensive&nbsp;list of car parks near to your chosen 
location and then plan your car journey to the one you select. You can also use this function to find 
out details for each car park and to see on a map the location of the car park.</TD></TR></TBODY></TABLE>
</DIV>',


'<DIV class="Column3Header">
<DIV class="txtsevenbbl">Car Parks in Transport Direct&nbsp;</DIV>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</DIV>
<DIV class="Column3Content">
<TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">
<TBODY>
<TR>
<TD class="txtseven">cy We can provide&nbsp; a comprehensive&nbsp;list of car parks near to your chosen 
location and then plan your car journey to the one you select. You can also use this function to find 
out details for each car park and to see on a map the location of the car park.</TD></TR></TBODY></TABLE>
</DIV>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 797
SET @ScriptDesc = 'Added car park right hand content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO