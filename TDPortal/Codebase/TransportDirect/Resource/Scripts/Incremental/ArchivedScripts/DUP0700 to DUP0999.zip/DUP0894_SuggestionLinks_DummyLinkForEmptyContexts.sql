-- ***********************************************
-- NAME 		: DUP0894_SuggestionLinks_DummyLinkForEmptyContexts.sql
-- DESCRIPTION 		: Script to insert a dummy suggestion link for contexts which have no links associated.
--			: This corrects a problem where Operation Events are raised when it detects an empty link
--			: This change will be removed in a future release as this is a temporary fix and will 
--			: require a code change to correct properly
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Apr 2008 15:00:00
-- ************************************************

USE [TransientPortal]
GO


DECLARE 
		@StringLinkURL    	  	varchar(100),	
		@StringLinkDescription    	varchar(500),	
		@StringLinkResourceName		varchar(100),  	
		@StringLinkResourceNameEN 	varchar(100),	
		@StringLinkResourceNameCY	varchar(100),	
		@LinkCategoryName 		varchar(100),  	
		@LinkPriority 			int,		
		@IsRoot				bit,		
		@StringContextName		varchar(100),	
		@StringContextDescription	varchar(500),	


		@SuggestionLinkID INT,
		@LinkCategoryID INT, 
		@ResourceNameID INT,
		@InternalExternalLinkID INT,
		@StringInternalExternal varchar (10),
		@ContextSuggestionLinkId INT

-- Set the empty link paramerters
SET @StringLinkURL = ''
SET @StringLinkDescription = 'Empty link'
SET @StringLinkResourceName = 'EmptyLink'
SET @StringLinkResourceNameEN = ''
SET @StringLinkResourceNameCY = ''
SET @LinkCategoryName = 'General'
SET @LinkPriority = 9999
SET @IsRoot = 0


-- Add the link
EXEC AddInternalLink @StringLinkURL, @StringLinkDescription

EXEC AddResource @StringLinkResourceName, @StringLinkResourceNameEN, @StringLinkResourceNameCY


	-- Get the ID's needed for a new suggestion link record
	SET @LinkCategoryID = (select LinkCategoryID from [dbo].[LinkCategory] where [Name] = @LinkCategoryName)
	SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @StringLinkResourceName)

	-- Set internal link details
	SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @StringLinkDescription)
	SET @StringInternalExternal = 'Internal'
	
	-- Add to Suggestion link table
	SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from [dbo].[SuggestionLink]) + 1

	IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
		BEGIN
			INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot], [IsSubRootLink], [SubRootLinkId])
			SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, @StringInternalExternal, @IsRoot, @IsRoot, @IsRoot
		END
	ELSE
		BEGIN
			-- Unable to add as link already exists, so reuse existing
			SET @SuggestionLinkID = (SELECT SuggestionLinkId FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
		END


-- Now need to add need to add the above suggestion link to all those contexts entries which currently have no links
INSERT INTO ContextSuggestionLink
(
    ContextSuggestionLinkId,
    ContextId,
    SuggestionLinkId,
    ThemeId
)

SELECT 	(
		SELECT COUNT(*) FROM Context C1
			LEFT JOIN ContextSuggestionLink L1
			ON L.ContextId = C.ContextId
 			WHERE L1.ContextSuggestionLinkId IS NULL
   			AND C1.contextid < C.contextid )+ (select max(L2.ContextSuggestionLinkId) from ContextSuggestionLink L2
	),
        C.ContextId,
	@SuggestionLinkID,
	1	-- ThemeId
	FROM Context C
  		LEFT JOIN ContextSuggestionLink L
         	ON L.ContextId = C.ContextId
 		WHERE L.ContextSuggestionLinkId IS NULL

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 894
SET @ScriptDesc = 'Added a dummy suggestion link for contexts which have no links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO