-- ***********************************************
-- NAME 		: DUP0948_ExternalLinks_Update_CityTransport.org.uk.sql
-- DESCRIPTION 		: Script to add specific content for a Theme - VisitBritain
-- AUTHOR		: Neil Rankin
-- DATE			: 06 June 2008 15:20
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT - External Link
-----------------------------------------------------

USE TransientPortal
Go


UPDATE dbo.ExternalLinks SET
		URL = 'http://www.journeyon.co.uk/buses.asp' , 
		TestURL = 'http://www.journeyon.co.uk/buses.asp' , 
		WHERE Description like '%Departure Board - City Transport%'
Go


UPDATE dbo.ChangeNotification SET
		Version = Version + 1
		Where [Table] like '%ExternalLinks%'

Go

----------------------------------------------------------------
-- Update change catalogue - Description
----------------------------------------------------------------

USE Content
Go

UPDATE dbo.tblContent SET
		[Value-En] = 'Journey On' 
		WHERE [Value-En] like '%City Transport%'

Go

USE Content
Go

UPDATE dbo.tblContent SET
		[Value-Cy] = 'Journey On' 
		WHERE [Value-Cy] like '%City Transport%'

Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 948
SET @ScriptDesc = 'Change URL from citytransport.org.uk to Journeyon.co.uk'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO