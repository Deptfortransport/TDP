-- ***********************************************
-- NAME 	: DUP0725_Creating_CarParking_Database_Tables.sql
-- DESCRIPTION 	: Creates the CarParks database tables
-- ************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0725_Creating_CarParking_Database_Tables.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:58:36   mmodi
--Initial revision.
--
--   Rev 1.0   Feb 07 2008 15:32:26   build
--Initial revision.
--Resolution for 4540: IR to cover Del 9.10
--
--   Rev Devfactory   Jan 15 2008 14:57:24   apatel
--Initial revision.

USE [CarParks]
GO

-----------------------------------------------
-- Drop Existing Tables
-----------------------------------------------



IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingPaymentType] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingAttractions] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractionType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingAttractionType]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilities') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingFacilities] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilitiesType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingFacilitiesType] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAdditionalData') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingAdditionalData] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkType]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingLinkedNaPTANS') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingLinkedNaPTANS] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGLocality') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingNPTGLocality]
END
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOpeningTimes') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingOpeningTimes]
END
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentMethods') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingPaymentMethods] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkCharges') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN 
	DROP TABLE [dbo].[CarParkingCarParkCharges]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkChargeType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkChargeType]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkConcessions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkConcessions]  
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceAvailability') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingSpaceAvailability] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkSpace') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkSpace] 
END
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingSpaceType]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCalendar') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCalendar]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParking') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParking] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOperator') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingOperator] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingTrafficNewsRegion') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingTrafficNewsRegion]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAccessPoints') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingAccessPoints]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingParkAndRideScheme') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingParkAndRideScheme]
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGAdminDistrict') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingNPTGAdminDistrict]
END
GO


-----------------------------------------------
-- Create CarParkingOperator table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOperator') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingOperator (
		[OperatorCode] [varchar] (50) NOT NULL,
		[OperatorName] [varchar] (100) NULL,
		[OperatorURL] [varchar] (2048) NULL,
		[OperatorTsAndCs] [varchar] (2048) NULL,
		[OperatorEmail] [varchar] (100) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingOperator ADD CONSTRAINT
		PK_CarParkingOperator PRIMARY KEY CLUSTERED ( OperatorCode ) 

END
GO


-----------------------------------------------
-- Create CarParkingTrafficNewsRegion
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingTrafficNewsRegion') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingTrafficNewsRegion (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[RegionName] [varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingTrafficNewsRegion ADD CONSTRAINT
		PK_CarParkingTrafficNewsRegion PRIMARY KEY CLUSTERED ( Id ) 

END
GO

-----------------------------------------------
-- Create CarParkingAccessPoints table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAccessPoints') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAccessPoints (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[GeocodeType] [varchar] (10) NOT NULL,
		[Easting] [varchar] (7) NOT NULL,
		[Northing] [varchar] (7) NOT NULL,
		[StreetName] [varchar] (100) NULL,
		[BarrierInOperation] [char] (3) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingAccessPoints ADD CONSTRAINT
		PK_CarParkingAccessPoints PRIMARY KEY CLUSTERED ( Id ) 

END
GO

-----------------------------------------------
-- Create CarParkingParkAndRideScheme
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingParkAndRideScheme') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingParkAndRideScheme (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Location] [varchar] (100) NULL,
		[SchemeURL] [varchar] (2048) NULL,
		[Comments] [varchar] (200) NULL,
		[LocationEasting] [varchar] (7) NULL,
		[LocationNorthing] [varchar] (7) NULL,
		[TransferFrequency] [varchar] (100) NULL,
		[TransferFrom] [varchar] (250) NULL,
		[TransferTo] [varchar] (250) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingParkAndRideScheme ADD CONSTRAINT
		PK_CarParkingParkAndRideScheme PRIMARY KEY CLUSTERED ( Id ) 

END
GO

-----------------------------------------------
-- Create CarParkingNPTGAdminDistrict
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGAdminDistrict') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingNPTGAdminDistrict (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[AdminAreaCode] [varchar] (50) NULL,
		[DistrictCode] [varchar] (50) NULL

	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingNPTGAdminDistrict ADD CONSTRAINT
		PK_CarParkingNPTGAdminDistrict PRIMARY KEY CLUSTERED ( Id ) 


END
GO

-----------------------------------------------
-- Create CarParkingCalendar table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCalendar') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCalendar (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Start] [datetime] NULL,
		[End] [datetime] NULL,
		[Days] [varchar] (7) NULL,
		[PublicHols] [varchar] (8) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCalendar ADD CONSTRAINT
		PK_CarParkingCalendar PRIMARY KEY CLUSTERED ( Id )

END
GO


		

----------------------------------------------
-- Create CarParkAttractionType
----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractionType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAttractionType (
		[TypeCode] [int] NOT NULL,
		[Description] [varchar] (50) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingAttractionType ADD CONSTRAINT
		PK_CarParkingAttractionType PRIMARY KEY CLUSTERED ( TypeCode )

END
GO

-----------------------------------------------
-- Create CarParkingFacilitiesType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilitiesType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingFacilitiesType (
		[TypeCode] [varchar] (100) NOT NULL,
		[Description] [varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingFacilitiesType ADD CONSTRAINT
		PK_CarParkingFacilitiesType PRIMARY KEY CLUSTERED ( TypeCode )
END
GO



-----------------------------------------------
-- Create CarParkingSpaceType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingSpaceType (
		[TypeCode] [varchar] (50) NOT NULL,
		[Description] [varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingSpaceType ADD CONSTRAINT
		PK_CarParkingCarParkSpaceType PRIMARY KEY CLUSTERED ( TypeCode )

END
GO


-----------------------------------------------
-- Create CarParkingCarParkChargeType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkChargeType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkChargeType (
		[ChargeType] [varchar] (50) NOT NULL,
		[ChargeDescription] [varchar] (100) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkChargeType ADD CONSTRAINT
		PK_CarParkingCarChargeType PRIMARY KEY CLUSTERED ( ChargeType )


END
GO


-----------------------------------------------
-- Create CarParking table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParking') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParking (
		[Reference] [varchar] (50) NOT NULL,	
		[OperatorId] [varchar] (50) NOT NULL,
		[AccessPointsMapId] [int] NULL,
		[AccessPointsEntranceId] [int] NULL,
		[AccessPointsExitId] [int] NULL,
		[TrafficNewsRegionId] [int] NOT NULL,
		[ParkAndRideSchemeId] [int],
		[NPTGAdminDistrictId] [int],
		[Name] [varchar] (50) NULL,
		[Location] [varchar] (50) NULL,
		[Address] [varchar] (100) NULL,
		[Postcode] [varchar] (8) NULL,
		[Notes] [varchar] (250) NULL,
		[Telephone] [varchar] (11) NULL,
		[Url] [varchar] (2048) NULL,
		[MinCost] [int] NULL,
		[ParkAndRide] [bit] DEFAULT 0 NOT NULL,
		[StayType] [varchar] (20) NULL,
		[PlanningPoint] [bit] DEFAULT 0 NOT NULL,
		[DateRecordLastUpdated] [datetime] DEFAULT 0 NOT NULL,
		[WEUDate] [datetime] NULL,
		[WEFDate] [datetime] NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		PK_CarParking PRIMARY KEY CLUSTERED ( Reference ) 

	--ALTER TABLE dbo.CarParking ADD CONSTRAINT
	--	FK_CarParking_CarParkingAdditionalData FOREIGN KEY ( AdditionalDataId)
	--	REFERENCES dbo.CarParkingAdditionalData ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingOperator FOREIGN KEY ( OperatorId )
		REFERENCES dbo.CarParkingOperator ( OperatorCode )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingTrafficNewsRegion FOREIGN KEY ( TrafficNewsRegionId )
		REFERENCES dbo.CarParkingTrafficNewsRegion ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingAccessPointsMap FOREIGN KEY ( AccessPointsMapId )
		REFERENCES dbo.CarParkingAccessPoints ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingAccessPointsEntrance FOREIGN KEY ( AccessPointsEntranceId )
		REFERENCES dbo.CarParkingAccessPoints ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingAccessPointsExit FOREIGN KEY ( AccessPointsExitId )
		REFERENCES dbo.CarParkingAccessPoints ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingParkAndRideScheme FOREIGN KEY ( ParkAndRideSchemeId )
		REFERENCES dbo.CarParkingParkAndRideScheme ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingNPTGAdminAndDistrict FOREIGN KEY ( NPTGAdminDistrictId )
		REFERENCES dbo.CarParkingNPTGAdminDistrict ( Id )

END
GO

-----------------------------------------------
-- Create CarParkingFacilities
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilities') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingFacilities (
		[FacilitiesTypeId] [varchar] (100) NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL,
		[Name] [varchar] (100) NULL,
		[Location] [varchar] (100) NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingFacilities ADD CONSTRAINT
		PK_CarParkingFacilities PRIMARY KEY CLUSTERED ( FacilitiesTypeId, CarParkRef )

	ALTER TABLE dbo.CarParkingFacilities ADD CONSTRAINT
		FK_CarParkingFacilitiesType_CarParkingFacilities FOREIGN KEY ( FacilitiesTypeId )
		REFERENCES dbo.CarParkingFacilitiesType ( TypeCode )
	
	ALTER TABLE dbo.CarParkingFacilities ADD CONSTRAINT
		FK_CarParkingFacilities_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )


END
GO

-----------------------------------------------
-- Create CarParkingAttractions
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAttractions (
		[TypeId] [int] NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL,
		[Name] [varchar] (100) NULL,
		[WalkingDistance] [varchar] (6) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingAttractions ADD CONSTRAINT
		PK_CarParkingAttractions PRIMARY KEY CLUSTERED ( TypeID, CarParkRef )

	ALTER TABLE dbo.CarParkingAttractions ADD CONSTRAINT
		FK_CarParkingAttractions_CarParkingAttractionType FOREIGN KEY ( TypeId )
		REFERENCES dbo.CarParkingAttractionType ( TypeCode )
	
	ALTER TABLE dbo.CarParkingAttractions ADD CONSTRAINT
		FK_CarParkingAttractions_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )


END
GO

-----------------------------------------------
-- Create CarParkingCarParkSpace
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkSpace') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkSpace (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[SpaceTypeId] [varchar] (50) NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL,
		[NumberOfSpaces] int DEFAULT 0 NOT NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkSpace ADD CONSTRAINT
		PK_CarParkingCarParkSpace PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingCarParkSpace ADD CONSTRAINT
		FK_CarParkingCarParkSpace_CarParkingSpaceType FOREIGN KEY ( SpaceTypeId )
		REFERENCES dbo.CarParkingSpaceType ( TypeCode )

	ALTER TABLE dbo.CarParkingCarParkSpace ADD CONSTRAINT
		FK_CarParkingCarParkSpace_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )

END
GO




-----------------------------------------------
-- Create CarParkingSpaceAvailability
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceAvailability') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingSpaceAvailability (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[SpaceId] int NOT NULL,
		[CalendarId] [int] NULL, -- modified to have NULL value as there may be no calendar associated.
		[AvailabilityDayType] [varchar] (50) NOT NULL,
		[StartTime] [varchar](8) NOT NULL,
		[EndTime] [varchar](8) NULL,
		[PercentageAvailability] [int] NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingSpaceAvailability ADD CONSTRAINT
		PK_CarParkingSpaceTypeAvailability PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingSpaceAvailability ADD CONSTRAINT
		FK_CarParkingSpaceAvailability_CarParkingCarParkSpace FOREIGN KEY ( SpaceId )
		REFERENCES dbo.CarParkingCarParkSpace ( Id)

	ALTER TABLE dbo.CarParkingSpaceAvailability ADD CONSTRAINT
		FK_CarParkingAvailability_CarParkingCalendar FOREIGN KEY ( CalendarId )
		REFERENCES dbo.CarParkingCalendar ( Id )

END
GO

	
-----------------------------------------------
-- Create CarParkingPaymentMethods
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentMethods') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN		
	CREATE TABLE dbo.CarParkingPaymentMethods (
		[CarParkRef] [varchar] (50) NOT NULL,
		[Code] [varchar] (50) NOT NULL,
		[Description] [varchar] (100),
		[ChangeAvailable] [varchar] (3) DEFAULT 'No' NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingPaymentMethods ADD CONSTRAINT
		PK_CarParkingPaymentMethods PRIMARY KEY CLUSTERED ( CarParkRef, Code ) 

	ALTER TABLE dbo.CarParkingPaymentMethods ADD CONSTRAINT
		FK_CarParkingPaymentMethods_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )


END
GO


-----------------------------------------------
-- Create CarParkingPaymentType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingPaymentType (
		[TypeCode] [varchar] (50) NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL,
		[TypeDescription] [varchar] (50) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingPaymentType ADD CONSTRAINT
		PK_CarParkingPaymentType PRIMARY KEY CLUSTERED ( TypeCode, CarParkRef ) 

	ALTER TABLE dbo.CarParkingPaymentType ADD CONSTRAINT
		FK_CarParkingPaymentType_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )

END
GO

-----------------------------------------------
-- Create CarParkingNPTGLocality
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGLocality') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingNPTGLocality (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL,
		[NationalGazeteerId] [varchar] (100) NULL,
		[Easting] [varchar] (7) NULL,
		[Northing] [varchar] (7) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingNPTGLocality ADD CONSTRAINT
		PK_CarParkingNPTGLocality PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingNPTGLocality ADD CONSTRAINT
		FK_CarParkingNPTGLocality_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )

END
GO

-----------------------------------------------
-- Create CarParkingLinkedNaptans
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingLinkedNaPTANS') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingLinkedNaPTANS (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL,	
		[StopPointType] [varchar] (50) NULL,
		[StopCode] [varchar] (20) NULL,
		[InterchangeTime] [int] NULL,
		[InterchangeMode] [varchar] (50) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingLinkedNaPTANS ADD CONSTRAINT
		PK_CarParkingLinkedNaPTANS PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingLinkedNaPTANS ADD CONSTRAINT
		FK_CarParkingLinkedNaPTANS_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )


END
GO

-----------------------------------------------
-- Create CarParkingCarParkType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkType (
		[CarParkRef] [varchar] (50) NOT NULL,	
		[TypeCode] [varchar] (50) NOT NULL,
		[Description] [varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkType ADD CONSTRAINT
		PK_CarParkingCarParkType PRIMARY KEY CLUSTERED ( CarParkRef, TypeCode )
	
	ALTER TABLE dbo.CarParkingCarParkType ADD CONSTRAINT
		FK_CarParkingCarParkType_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )

END
GO

-----------------------------------------------
-- Create CarParkingCarParkConcessions
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkConcessions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkConcessions (
		[Code] [varchar] (50) NOT NULL,
		[Description] [varchar] (200) NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkConcessions ADD CONSTRAINT
		PK_CarParkingCarParkConcessions PRIMARY KEY CLUSTERED ( Code, CarParkRef )

	ALTER TABLE dbo.CarParkingCarParkConcessions ADD CONSTRAINT
		FK_CarParkingCarParkConcessions_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )

END
GO




		
-----------------------------------------------
-- Create CarParkingOpeningTimes table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOpeningTimes') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingOpeningTimes (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[CarParkRef] [varchar] (50) NOT NULL,
		[CalendarId] [int] NULL, -- modified to have NULL value as there may be no calendar associated
		[DayType] [varchar] (50) NULL,
		[OpensAt] [varchar] (8) NOT NULL,
		[LastEntranceAt] [varchar] (8) NOT NULL,
		[ClosesAt] [varchar] (8) NOT NULL,
		[MaxStaysDays] [int] NULL,
		[MaxStayMinutes] [int] NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingOpeningTimes ADD CONSTRAINT
		PK_CarParkingOpeningTimes PRIMARY KEY CLUSTERED ( Id ) 
	
	ALTER TABLE dbo.CarParkingOpeningTimes ADD CONSTRAINT
		FK_CarParkingOpeningTimes_CarParking FOREIGN KEY ( CarParkRef )
		REFERENCES dbo.CarParking ( Reference )


	ALTER TABLE dbo.CarParkingOpeningTimes ADD CONSTRAINT
		FK_CarParkingCalendar_OpeningTimes FOREIGN KEY ( CalendarId )
		REFERENCES dbo.CarParkingCalendar ( Id )
	
	

END
GO


-----------------------------------------------
-- Create CarParkingCarParkCharges
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkCharges') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkCharges (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[SpaceId] [int] NULL,
		[CalendarId] [int] NULL, -- modified to have NULL values as there may be no calendar associated.
		[ChargeTypeId] [varchar] (50) NULL,
		[DayType] [varchar] (50) NULL, -- modified make it accept null apatel
		[StartTime] [varchar] (8) NULL,
		[EndTime] [varchar] (8) NULL,
		[TimeRangeDays] [int] NOT NULL,
		[TimeRangeMinutes] [int] NOT NULL,
		[Comments] [varchar] (200) NULL,
		[ChargeAmount] [int] NOT NULL,
		[ChargeDayEndTime] [varchar] (10) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkCharges ADD CONSTRAINT
		PK_CarParkingCarParkCharges PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingCarParkCharges ADD CONSTRAINT
		FK_CarParkingCarParkCharges_CarParkingCarParkSpace FOREIGN KEY ( SpaceId )
		REFERENCES dbo.CarParkingCarParkSpace ( Id )

	ALTER TABLE dbo.CarParkingCarParkCharges ADD CONSTRAINT 
		FK_CarParkingCarParkCharges_CarParkingCalendar FOREIGN KEY ( CalendarId )
		REFERENCES dbo.CarParkingCalendar ( Id )
		
	-- modified add constraint for FK_CarParkingChargeType_CarParkCharges apatel
	ALTER TABLE dbo.CarParkingCarParkCharges ADD CONSTRAINT 
		FK_CarParkingCarParkCharges_CarParkingCarParkChargeType FOREIGN KEY ( ChargeTypeId )
		REFERENCES dbo.CarParkingCarParkChargeType( ChargeType )
	

END
GO




-----------------------------------------------
-- Create CarParkingAdditionalData table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAdditionalData') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAdditionalData (
		[CarParkingId] [varchar] (50) NOT NULL,
		[ClosingDate] [datetime] NOT NULL,
		[ReopeningDate] [datetime] NOT NULL,
		[MaximumHeight] [int] NULL,
		[MaximumWidth] [int] NULL,
		[PMSPA] [varchar] (3) DEFAULT 'No' NOT NULL,
		[EmergencyNumber] [varchar] (13) NULL,
		[EmailAddressOfCarPark] [varchar] (100) NULL,
		[CCTVAvailable] [varchar] (3) DEFAULT 'N' NOT NULL,
		[Staffed] [varchar] (3) DEFAULT 'No' NOT NULL,
		[Patrolled] [varchar] (3) DEFAULT 'No' NOT NULL,
		[VehicleRestrictions] [varchar] (150) NULL,
		[LiftsAvailable] [varchar] (3) DEFAULT 'No' NOT NULL,
		[AdvancedReservationsAvailable] [varchar] (3) DEFAULT 'No' NOT NULL,
		[SeasonTicketsAvailable] [varchar] (3) DEFAULT 'No' NOT NULL
	) ON [PRIMARY]

	-- Primary Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		PK_CarParkingAdditionalData PRIMARY KEY CLUSTERED ( CarParkingId ) 
	
	-- CarParking Foreign Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParking FOREIGN KEY ( CarParkingId )
		REFERENCES dbo.CarParking ( Reference )

	END
GO

-------------------------------------------------
-- Updates to Properties Table
-------------------------------------------------

USE PermanentPortal
GO
DELETE FROM properties WHERE pName = 'CarParksDB'

DELETE FROM properties WHERE pName = 'datagateway.sqlimport.carparking.database'

DELETE FROM properties WHERE pName = 'datagateway.sqlimport.carparking.cleanupstoredprocedure'

INSERT INTO properties VALUES ('CarParksDB', 'Server=.;Initial Catalog=CarParks;Trusted_Connection=true;', '<DEFAULT>', '<DEFAULT>' ,0)

INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.database', 'CarParksDB', '', 'DataGateway' ,0)

INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.cleanupstoredprocedure', 'DeleteCarParkingData', '', 'DataGateway' ,0)



GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber =725
SET @ScriptDesc = 'Added/Updated tables for Car Parking in CarParks Database.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
