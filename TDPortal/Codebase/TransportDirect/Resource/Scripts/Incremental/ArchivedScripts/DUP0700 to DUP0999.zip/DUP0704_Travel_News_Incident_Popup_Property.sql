-- *************************************************************************************
-- NAME 		: DUP0704_Travel_News_Incident_Popup_Property.sql
-- DESCRIPTION 		: Adds properites in Property table for Home page Travel News incident Popup
-- *************************************************************************************
USE [PermanentPortal]
GO

----------------------------------------------------------------
-- New values for NewIncidentTypeDrop Dataset
----------------------------------------------------------------

DELETE FROM Properties WHERE pName = 'Web.TravelNewsHeadlineControl.ShowPopup';
INSERT INTO Properties
 VALUES('Web.TravelNewsHeadlineControl.ShowPopup','true','Web','UserPortal',0);

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 704
SET @ScriptDesc = 'Added new properties in Property table for the Travel News headline control Popup'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
