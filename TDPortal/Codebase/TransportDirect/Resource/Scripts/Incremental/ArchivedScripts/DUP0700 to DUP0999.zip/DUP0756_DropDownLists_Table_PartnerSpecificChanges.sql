-- ************************************************************
-- NAME 	: DUP0756_DropDownLists_Table_PartnerSpecificChanges.sql
-- DESCRIPTION 	: Updated DropDownLists Table to add ThemeId column
-- ************************************************************
--

USE [PermanentPortal]
GO


IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('DropDownLists')
						AND syscolumns.name = 'ThemeId')
BEGIN
	ALTER TABLE DropDownLists ADD [ThemeId] INT NOT NULL DEFAULT(1)
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
			WHERE CONSTRAINT_CATALOG = 'PermanentPortal'
			AND TABLE_NAME ='DropDownLists'
			AND CONSTRAINT_NAME = 'pk_DropDownLists')		

BEGIN
	ALTER TABLE DropDownLists DROP 
		CONSTRAINT [pk_DropDownLists]


	ALTER TABLE [dbo].[DropDownLists] ADD 
	CONSTRAINT [pk_DropDownLists] PRIMARY KEY  CLUSTERED 
	(
		[DataSet],
		[PartnerId],
		[ResourceID],
		[ThemeId]
	)  ON [PRIMARY] 

END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 756
SET @ScriptDesc = 'Updated DropDownLists Table to add ThemeId column'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
