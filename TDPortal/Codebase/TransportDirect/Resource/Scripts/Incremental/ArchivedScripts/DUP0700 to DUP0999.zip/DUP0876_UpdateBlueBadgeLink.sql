-- 
-- NAME 		 DUP0876_UpdateBlueBadgeLink.sql
-- DESCRIPTION 	 	 Script to update the link to the Blue Badge scheme on the DirectGov web site
-- AUTHOR		 Dan Gath
-- DATE			 3 Apr 2008 16:40:00
-- 

-----------------------------------------------------
-- CONTENT
-----------------------------------------------------

USE [Content]
GO

update tblContent set [Value-En]='<DIV class="Column3Header">  <DIV class="txtsevenbbl">Blue Badge map</DIV>  <DIV class="clearboth" ></DIV>  </DIV>  <DIV class="Column3Content">  <TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="VertAlignTop">  <IMG src="/Web2/app_themes/directgov/images/gifs/partner/bb.gif" alt="Blue Badge">  </TD>  <TD class="txtseven" vAlign="top">  The Blue Badge map shows Blue Badge parking bays, accessible toilets, council car parks, petrol stations, shopmobility centres, accessible   beaches and train stations and National Trust properties in over 100 locations across the UK - a great resource not just for drivers!  <br><br>  Discover the <A href="http://bluebadge.direct.gov.uk/index.php?br_wid=1280&br_hgt=768" >Blue Badge map here</A>  </TD></TR></TBODY></TABLE></DIV>  <DIV class="Column3Header">  <DIV class="txtsevenbbl">Find schools and childcare in your area</DIV>  <DIV class="clearboth" ></DIV>  </DIV>  <DIV class="Column3Content">  <TABLE id="Table2" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="VertAlignTop">  <IMG src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare">  </TD>  <TD class="txtseven" vAlign="top">  Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.  <br><br>  <A href="http://schoolsfinder.direct.gov.uk/" >  Search for schools and childcare</A>  </TD></TR></TBODY></TABLE></DIV>',
[Value-Cy]='<DIV class="Column3Header">  <DIV class="txtsevenbbl">Blue Badge map</DIV>  <DIV class="clearboth" ></DIV>  </DIV>  <DIV class="Column3Content">  <TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="VertAlignTop">  <IMG src="/Web2/app_themes/directgov/images/gifs/partner/bb.gif" alt="Blue Badge">  </TD>  <TD class="txtseven" vAlign="top">  The Blue Badge map shows Blue Badge parking bays, accessible toilets, council car parks, petrol stations, shopmobility centres, accessible   beaches and train stations and National Trust properties in over 100 locations across the UK - a great resource not just for drivers!  <br><br>  Discover the <A href="http://bluebadge.direct.gov.uk/index.php?br_wid=1280&br_hgt=768" >Blue Badge map here</A>  </TD></TR></TBODY></TABLE></DIV>  <DIV class="Column3Header">  <DIV class="txtsevenbbl">Find schools and childcare in your area</DIV>  <DIV class="clearboth" ></DIV>  </DIV>  <DIV class="Column3Content">  <TABLE id="Table2" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="VertAlignTop">  <IMG src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare">  </TD>  <TD class="txtseven" vAlign="top">  Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.  <br><br>  <A href="http://schoolsfinder.direct.gov.uk/" >  Search for schools and childcare</A>  </TD></TR></TBODY></TABLE></DIV>' 
where PropertyName like '%bluebadge.direct.gov.uk%'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 876
SET @ScriptDesc = 'Updates the link to the Blue Badge scheme on the DirectGov web site'

IF EXISTS (SELECT  FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO