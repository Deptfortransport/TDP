-- *************************************************************************************
-- NAME 		: DUP0763_Added_Property_To_Switch_On_Off_Left_Menu_Expandingl.sql
-- DESCRIPTION  : Added property to Configure Left Hand Menu Expandable
-- AUTHOR		: Amit Patel
-- *************************************************************************************

USE [PermanentPortal]
GO

-----------------------------------------------------------------
--  Property to set Door to Door Journey functionality on or off
-----------------------------------------------------------------
DECLARE @ThemeId INT 

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

IF EXISTS(SELECT * 
			FROM [PROPERTIES] 
			WHERE [PNAME]='LeftHandMenuExpandable' )
  BEGIN
    DELETE FROM [PROPERTIES] 
		WHERE [PNAME]= 'LeftHandMenuExpandable'
    
  END
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID,THEMEID) 
	VALUES ('LeftHandMenuExpandable','True','<DEFAULT>','<DEFAULT>','0',@ThemeId)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 763
SET @ScriptDesc = 'Added property to Configure Left Hand Menu Expandable'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
