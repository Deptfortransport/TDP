-- ***********************************************
-- NAME 		: DUP0957_Properties_FindNearestStation_JourneyResults.sql
-- DESCRIPTION 	: Script to add properties used by the Find nearest stations journey planner
-- AUTHOR		: Mitesh Modi
-- DATE			: 24 June 2008 17:00:00
-- ************************************************

USE [PermanentPortal]
GO

IF exists (select top 1 * from properties where pName like '%FindSummaryResultControl.%.TrunkStation%')
BEGIN
	delete from properties where pname like '%FindSummaryResultControl.%.TrunkStation%'
END


insert into properties values ('FindSummaryResultControl.Scrollpoint.TrunkStation', '10', 'Web', 'UserPortal', 0, 1)
insert into properties values ('FindSummaryResultControl.FixedHeight.TrunkStation', '200px', 'Web', 'UserPortal', 0, 1)


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 957
SET @ScriptDesc = 'Find nearest station journey results scroll and fixed point values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO