-- *************************************************************************************
-- NAME 		: DUP0767_Update_To_Menu_Tables_For_DepartureBoard_Second_Level_Menu.sql
-- DESCRIPTION  : Added DepartureBoard second level menu 
-- AUTHOR		: Amit Patel
-- *************************************************************************************
USE [TransientPortal]
GO

-- Updating DepartureBoards link url

--EXEC UpdateSuggestionLinkURL
--	 'LiveTravel/DepartureBoards.aspx', 
--	 NULL, 
--	 'Departure boards', 
--	 1
--GO

-- Updating NetworkMaps link url

--EXEC UpdateSuggestionLinkURL
--	 'Maps/NetworkMaps.aspx', 
--	 NULL, 
--	 'Traffic levels', 
--	 1
--GO

-- Adding Link Categories we want
DECLARE @LinkCategoryId INT
DECLARE @LinkPriority INT

-- Adding Link Category for Departure Boards

SELECT @LinkCategoryId = Max(LinkCategoryId)+1 FROM LinkCategory

SELECT @LinkPriority = Priority + 5 FROM LinkCategory WHERE [Name] = 'Live travel'

IF NOT EXISTS (SELECT TOP 1 * from LinkCategory WHERE [Name] = 'Departure boards')
BEGIN
	INSERT INTO LinkCategory VALUES(@LinkCategoryId, @LinkPriority, 'Departure boards', 'Departure boards menu')
END


GO



	 
------------------------------------------------------------
-- Add the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link for Train Departure Boards
SET @RelativeURL = 'LiveTravel/DepartureBoards.aspx#train'
SET @InternalLinkDescription = 'Train Departure Boards'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link for London Departure Boards
SET @RelativeURL = 'LiveTravel/DepartureBoards.aspx#london'
SET @InternalLinkDescription = 'London Departure Boards'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

-- Link for Airport Departure Boards
SET @RelativeURL = 'LiveTravel/DepartureBoards.aspx#airport'
SET @InternalLinkDescription = 'Airport Departure Boards'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link for Bus Departure Boards
SET @RelativeURL = 'LiveTravel/DepartureBoards.aspx#bus'
SET @InternalLinkDescription = 'Bus Departure Boards'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

GO


------------------------------------------------------------
-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT
-----------------------------
-- Departure board links resource names
------------------------------
-- Link to train
SET @LinkResourceName = 'DepartureBoards.Train'
SET @LinkResourceNameEN = 'Train'
SET @LinkResourceNameCY = 'cy Train'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-- Link  to London
SET @LinkResourceName = 'DepartureBoards.London'
SET @LinkResourceNameEN = 'London'
SET @LinkResourceNameCY = 'cy London'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-- Link to Airport
SET @LinkResourceName = 'DepartureBoards.Airport'
SET @LinkResourceNameEN = 'Airport'
SET @LinkResourceNameCY = 'cy Airport'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
	

-- Link to Bus
SET @LinkResourceName = 'DepartureBoards.Bus'
SET @LinkResourceNameEN = 'Bus'
SET @LinkResourceNameCY = 'cy Bus'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
GO	

----------------------------------------------
-- End for Departure board link resource names
----------------------------------------------

------------------------------------------------------------
-- update SuggestionLinks for Departure Boards and Network Maps link

DECLARE @LinkCategoryID INT,
		@ResourceNameID INT

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Live travel'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='DepartureBoards'

UPDATE SuggestionLink SET IsRoot = 1, IsSubRootLink=1
		WHERE LinkCategoryId = @LinkCategoryID AND ResourceNameId = @ResourceNameID


SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Find a place'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='NetworkMaps'

UPDATE SuggestionLink SET IsRoot = 1, IsSubRootLink=1
		WHERE LinkCategoryId = @LinkCategoryID AND ResourceNameId = @ResourceNameID		

GO		

------------------------------------------------------------
--insert into SuggestionLink table for Departure Boards in home page menu
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100),
	@SubRootLinkId INT

DECLARE @InternalLinkDescription varchar(500)

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Live travel'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='DepartureBoards'
	
SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = 'HomePageMenu' 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
		


-- Link for Departure Boards train 
SET @LinkResourceName = 'DepartureBoards.Train'
SET @InternalLinkDescription = 'Train Departure Boards'
SET @LinkCategoryID =9
SET @LinkPriority = 32
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link for Departure Boards London
SET @LinkResourceName = 'DepartureBoards.London'
SET @InternalLinkDescription = 'London Departure Boards'
SET @LinkCategoryID = 9
SET @LinkPriority = 34
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link for Departure Boards Airport
SET @LinkResourceName = 'DepartureBoards.Airport'
SET @InternalLinkDescription = 'Airport Departure Boards'
SET @LinkCategoryID = 9
SET @LinkPriority = 36
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link for Departure Boards Airport
SET @LinkResourceName = 'DepartureBoards.Bus'
SET @InternalLinkDescription = 'Bus Departure Boards'
SET @LinkCategoryID = 9
SET @LinkPriority = 38
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

GO

------------------------------------------------------------
--insert into SuggestionLink table for Departure Boards in Live Travel News menu
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100),
	@SubRootLinkId INT

DECLARE @InternalLinkDescription varchar(500)

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Live travel'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='DepartureBoards'
	
SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = 'HomePageMenuLiveTravel' 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
		


-- Link for Departure Boards train 
SET @LinkResourceName = 'DepartureBoards.Train'
SET @InternalLinkDescription = 'Train Departure Boards'
SET @LinkCategoryID =9
SET @LinkPriority = 4022
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link for Departure Boards London
SET @LinkResourceName = 'DepartureBoards.London'
SET @InternalLinkDescription = 'London Departure Boards'
SET @LinkCategoryID = 9
SET @LinkPriority = 4024
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link for Departure Boards Airport
SET @LinkResourceName = 'DepartureBoards.Airport'
SET @InternalLinkDescription = 'Airport Departure Boards'
SET @LinkCategoryID = 9
SET @LinkPriority = 4026
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link for Departure Boards Airport
SET @LinkResourceName = 'DepartureBoards.Bus'
SET @InternalLinkDescription = 'Bus Departure Boards'
SET @LinkCategoryID = 9
SET @LinkPriority = 4028
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

GO





-----------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages for homepage menu for Departure Boards
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'HomePageMenu'
SET @ContextDescription = 'Links for expandable menu on the Home Page/mini homepages.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@SubRootLinkId INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 
	
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Live travel'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='DepartureBoards'

SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = @ContextName 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
-------------------------------------------------------------------------------------------------------------
--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'DepartureBoards.Train'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'DepartureBoards.London'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
				
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'DepartureBoards.Airport'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'DepartureBoards.Bus'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId


GO

-----------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages for Live Travel news for Departure Boards
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'HomePageMenuLiveTravel'
SET @ContextDescription = 'Links for expandable menu on the Live Travel pages.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@SubRootLinkId INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 
	
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Live travel'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='DepartureBoards'

SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = @ContextName 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
-------------------------------------------------------------------------------------------------------------
--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'DepartureBoards.Train'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'DepartureBoards.London'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
				
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'DepartureBoards.Airport'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'DepartureBoards.Bus'
SET @LinkCategoryID = 9
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId


GO







----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 767
SET @ScriptDesc = 'Added DepartureBoard second level menu '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
