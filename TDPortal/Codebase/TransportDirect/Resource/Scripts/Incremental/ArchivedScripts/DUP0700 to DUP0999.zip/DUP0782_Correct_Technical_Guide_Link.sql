-- ***********************************************
-- NAME 		: DUP0782_Correct_Technical_Guide_Link.sql
-- DESCRIPTION 	: Correct the link that points to the technical guide on the business links page
-- AUTHOR		: apatel
-- ************************************************


USE PermanentPortal
GO

UPDATE
	properties
SET
	pValue = '/Web2/downloads/BusinessLinksTechnicalGuide.pdf'
WHERE
	pName = 'BusinessLinks.HyperlinkURL.PDFTechnicalGuide'

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 782
SET @ScriptDesc = 'Correct the link that points to the technical guide on the business links page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------