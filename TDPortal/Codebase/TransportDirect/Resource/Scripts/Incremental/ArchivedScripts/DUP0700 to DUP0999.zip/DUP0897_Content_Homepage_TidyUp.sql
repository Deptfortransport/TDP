-- ***********************************************
-- NAME 		: DUP0897_Content_Homepage_TidyUp.sql
-- DESCRIPTION 		: Script to clear up the homepage information panels
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 Apr 2008 15:00:00
-- ************************************************

USE [Content]
GO

-- This script performs a tidy up of the information rows added which are duplicates and are never used!
-- Note, subsequent scripts will add the relavant content rows again, 

DECLARE @GroupId int,
	@ThemeId int
SET @ThemeId = 1



------------------------------------------------------------------------------------
-- Mini homepage information panels. Remove entries never used and are duplicated
DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%PlanAJourneyInformationHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId in (1,2,3,5)



DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%FindAPlaceInformationHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId in (1,2,3,5)



DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%HomeTravelInformationHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId in (1,2,3,5)



DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%TipsToolsInformationHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId in (1,2,3,5)


------------------------------------------------------------------------------------
-- Right hand information panel on homepage. Remove entries never used and are duplicated
DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%TDAdditionalInformationHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId in (1,2,3,5)

DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%TDNewInformationHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId in (1,2,3,5)


------------------------------------------------------------------------------------
-- Tips and tools panel on homepage. Remove entries never used and are duplicated
DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%TDTipsHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId in (1,2,3,5)




------------------------------------------------------------------------------------
-- Latest news entries. No longer controlled by Content table. Remove entries never used and are duplicated
DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%TDInformationHtmlPlaceholderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId = @ThemeId

-- Re-add entries, to allow latest news entries to be shown
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')
EXEC AddtblContent
@ThemeId, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<h1>Latest... NOT POPULATED</h1>'
, '<h1>Latest... NOT POPULATED</h1>'

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'tools_home')
EXEC AddtblContent
@ThemeId, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home'
, '<h1>Latest... NOT POPULATED</h1>'
, '<h1>Latest... NOT POPULATED</h1>'

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'livetravel_home')
EXEC AddtblContent
@ThemeId, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/LiveTravel/Home'
, '<h1>Latest... NOT POPULATED</h1>'
, '<h1>Latest... NOT POPULATED</h1>'

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'maps_home')
EXEC AddtblContent
@ThemeId, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/Home'
, '<h1>Latest... NOT POPULATED</h1>'
, '<h1>Latest... NOT POPULATED</h1>'

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_home')
EXEC AddtblContent
@ThemeId, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/Home'
, '<h1>Latest... NOT POPULATED</h1>'
, '<h1>Latest... NOT POPULATED</h1>'


------------------------------------------------------------------------------------
-- Placeholder for Advanced options, not required on homepages so remove
DELETE tblContent
WHERE PropertyName LIKE '%%' 
AND ControlName LIKE '%TDPageInformationHtmlPlaceHolderDefinition%'
AND GroupId in (14,15,16,17,18)
AND ThemeId = @ThemeId


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 897
SET @ScriptDesc = 'Script to clear out the duplicate homepage panel values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO