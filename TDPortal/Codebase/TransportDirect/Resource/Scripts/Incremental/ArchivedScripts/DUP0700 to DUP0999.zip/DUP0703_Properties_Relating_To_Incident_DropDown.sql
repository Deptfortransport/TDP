-- *************************************************************************************
-- NAME 		: DUP0703_Properties_Relating_To_Incident_DropDown.sql
-- DESCRIPTION 		: Adds properites for Property table in the NewsIncidentTypeDrop data set
-- *************************************************************************************
USE [PermanentPortal]
GO

----------------------------------------------------------------
-- New values for NewIncidentTypeDrop Dataset
----------------------------------------------------------------

DELETE FROM Properties WHERE pName = 'TransportDirect.UserPortal.DataServices.NewsIncidentTypeDrop.type';
INSERT INTO Properties
 VALUES('TransportDirect.UserPortal.DataServices.NewsIncidentTypeDrop.type','3','DataServices','UserPortal',0);

GO

DELETE FROM Properties WHERE pName = 'TransportDirect.UserPortal.DataServices.NewsIncidentTypeDrop.db';
INSERT INTO Properties
 VALUES('TransportDirect.UserPortal.DataServices.NewsIncidentTypeDrop.db','DefaultDB','DataServices','UserPortal',0);

GO

DELETE FROM Properties WHERE pName = 'TransportDirect.UserPortal.DataServices.NewsIncidentTypeDrop.query';
INSERT INTO Properties
 VALUES('TransportDirect.UserPortal.DataServices.NewsIncidentTypeDrop.query','SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''NewsIncidentTypeDrop'' ORDER BY SortOrder','DataServices','UserPortal',0);

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 703
SET @ScriptDesc = 'Added new properties in Property table for the Travel News Incident Type data set'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
