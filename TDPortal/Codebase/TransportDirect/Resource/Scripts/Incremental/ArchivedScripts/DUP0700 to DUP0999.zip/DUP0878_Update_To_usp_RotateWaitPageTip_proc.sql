-- ************************************************************
-- NAME 		: DUP0878_Update_To_usp_RotateWaitPageTip_proc.sql
-- DESCRIPTION 	: usp_RotateWaitPageTip store procedure update
-- AUTHOR		: apatel
-- ************************************************************

-- this assumes that default transport direct theme id set to 1 

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[usp_RotateWaitPageTip]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[usp_RotateWaitPageTip]
END
GO

CREATE PROCEDURE usp_RotateWaitPageTip
AS
	DECLARE @CurrTipID INT,
		@MaxTipCount INT,
		@MaxTipID INT,
		@SelectionMethod INT,
		@NewDefaultTipID INT,
		@NewTipId INT,
		@DefaultThemeId INT,
		@ThemeId INT
	
	
	
	EXEC [Content].[dbo].[GetDefaultThemeId] @DefaultThemeId OUTPUT 

	-- Defining cursor to iterate through themes other than default theme
	DECLARE theme_cursor CURSOR FOR 
		SELECT themeId
		FROM [Content].[dbo].[tblTheme]Order by ThemeID ASC
		
	OPEN theme_cursor

	FETCH NEXT FROM theme_cursor 
		INTO @ThemeId

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @CurrTipID = pValue
		FROM Properties
		WHERE pName = 'CurrentWaitPageTipID' and ThemeId = @ThemeId		
		

  		SELECT @MaxTipID = MAX(WaitPageTipID) 
		FROM [TransientPortal].[dbo].[WaitPageMessageTips]
		WHERE ThemeId = @ThemeId
	

			

		IF (@SelectionMethod = 1)
		-- Method 1 is incremental method which gets next big tip id
		BEGIN
			IF (@CurrTipID < @MaxTipID) 
			BEGIN
				SELECT @NewTipID = WaitPageTipID
				FROM [TransientPortal].[dbo].[WaitPageMessageTips]
				WHERE ThemeId = @ThemeId AND WaitPageTipID > @CurrTipID AND WaitPageTipID <= @MaxTipID
			END
			ELSE 
			BEGIN
				SELECT TOP 1 @NewTipID =WaitPageTipID
				FROM [TransientPortal].[dbo].[WaitPageMessageTips]
				WHERE ThemeId = @ThemeId
				ORDER BY WaitPageTipID ASC
			END
		END
		ELSE
			SELECT TOP 1 @NewTipID =WaitPageTipID FROM [TransientPortal].[dbo].[WaitPageMessageTips]
			WHERE ThemeId = @ThemeId
			ORDER BY NEWID()
		
		SET @NewTipID = ISNULL(@NewTipID,0)

		 
		
		IF(@ThemeId = @DefaultThemeId)
			SET @NewDefaultTipID = @NewTipID	

		IF (@NewTipID = 0 AND @ThemeId <> @DefaultThemeId)
			SET @NewTipID = @NewDefaultTipID



		IF NOT EXISTS(SELECT * from Properties
				WHERE pName = 'CurrentWaitPageTipID' AND ThemeID = @ThemeId)
		BEGIN
			INSERT INTO properties VALUES ('CurrentWaitPageTipID',@NewTipID, 'Web','UserPortal', 0, @ThemeId)

		END
		ELSE
		BEGIN

			UPDATE Properties 
			SET pValue = @NewTipID
			WHERE pName = 'CurrentWaitPageTipID' AND ThemeID = @ThemeId AND AID = 'Web'
		END

		
   
   		-- Get the next theme.
   		FETCH NEXT FROM theme_cursor 
   		INTO @ThemeId
	END

	CLOSE theme_cursor
	DEALLOCATE theme_cursor



GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 878
SET @ScriptDesc = 'usp_RotateWaitPageTip store procedure update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------