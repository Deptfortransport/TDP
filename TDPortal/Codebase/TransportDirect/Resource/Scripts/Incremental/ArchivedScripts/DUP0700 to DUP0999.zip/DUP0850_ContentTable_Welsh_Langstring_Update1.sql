-- ***********************************************
-- NAME 		: DUP0850_ContentTable_Welsh_Langstring_Update1.sql
-- DESCRIPTION 		: inserts into the content database for welsh langstring 
-- AUTHOR		: darshan sawe
-- Date 		: 25	-March-2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [Content]
GO

EXEC dbo.[AddtblContent]
	1,
	1,
	'FaresAndTickets',
	'FareDetailsTableSegmentControl.upgradeInfo.Text',
	'i',
	'i'

EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareSelectedTicket.Route',
	'Route:',
	'Llwybr:'

EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareStepsControl.FindFareStep.Image.AlternateText',
	'Steps',
	'Camau'

EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareStepsControl.FindFareStep1.Image.AlternateText',
	'Step 1',
	'Cam 1'

EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareStepsControl.FindFareStep2.Image.AlternateText',
	'Step 2',
	'Cam 2'

EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareStepsControl.FindFareStep3.Image.AlternateText',
	'Step 3',
	'Cam 3'

EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareStepsControl.FindFareStep4.Image.AlternateText',
	'Step 4',
	'Cam 4'

EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareTicketSelection.instructionLabel.Text',
	'To find train journeys on which you can use a particular fare, select a fare. Then click ''Next''',
	'Er mwyn dod o hyd i siwrneiau tr�n y gallwch ddefnyddio tocyn penodol ar eu cyfer, dewiswch y tocyn. Yna cliciwch ''Nesaf'''


EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'SearchTypeControl.imageCost.AlternateText',
	'Plan a journey based on cost icon',
	'Eicon Cynllunio siwrnai ar sail cost'


EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'SearchTypeControl.imageTime.AlternateText',
	'Plan a journey based on time icon',
	'Eicon Cynllunio siwrnai ar sail amser'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarJourneyItemisedCostsControl.imageRunningCost.AlternateText',
	'Running cost icon',
	'Eicon cost rhedeg'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.AdvancedReservationsNoText',
	'Not known',
	'Ddim yn gwybod'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.AdvancedReservationsTitle',
	'Advanced Reservations:',
	'Bwcio ymlaen llaw:'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.carParkAdditionalNotesTitle',
	'Additional Notes:',
	'Nodiadau Ychwanegol:'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.carParkAddressTitle',
	'Address',
	'Cyfeiriad'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.carParkMinimumCostTitle',
	'Minimum Cost of Parking:',
	'Isafswm Cost Parcio:'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.carParkOpeningTimesTitle',
	'Opening Times:',
	'Amserau Agor:'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.CarParkTypeTitle',
	'Type of Car Park:',
	'Math o Faes Parcio:'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.NumberOfDisabledSpacesTitle',
	'Number of Disabled Spaces:',
	'Nifer y Lleoedd Anabl:'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.ParkingRestrictions',
	'Maximum Height : {0} &lt;br /&gt;Maximum Width : {1}',
	'Uchder Mwyaf : {0} &lt;br /&gt;Lled Mwyaf : {1}'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.ParkingRestrictions.Height',
	'Maximum Height : {0}',
	'Uchder Mwyaf : {0}'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.ParkingRestrictions.Width',
	'Maximum Width : {0}',
	'Lled Mwyaf : {1}'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.ParkingRestrictionsTitle',
	'Parking Restrictions:',
	'Cyfyngiadau Parcio:'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParkInformationControl.TotalSpacesTitle',
	'Total Number of Spaces:',
	'Cyfanswm Nifer y Lleoedd Gwag:'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CarParking.imageCarParkCosts.AlternateText',
	'Car Park Costs icon',
	'Eicon Costau Parcio Car'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'DataServices.NewsIncidentTypeDrop.Planned',
	'Engineering work',
	'Gwaith Peirianyddol'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FeedbackInitialPage.labelTitle.Text',
	'Send us your feedback',
	'Anfonwch eich adborth aton ni'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkInput.labelFindCarParkNote',
	'Enter a location to find a list of nearby car parks; you will then be able to plan a journey to or from one of the car parks',
	'Nodwch leoliad i gael rhestr o feysydd parcio gerllaw; wedyn byddwch yn gallu cynllunio siwrnai i neu o un o''r meysydd parcio'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkInput.labelNote.FindNearest',
	'Find nearest car parks to travel {0}',
	'Canfod y meysydd parcio agosaf i ble byddwch yn teithio {0}'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkMap.commandDriveFrom.Text',
	'Drive from this car park',
	'Gyrru o''r maes parcio hwn'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkMap.commandDriveFrom2.Text',
	'Drive from this car park',
	'Gyrru o''r maes parcio hwn'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkMap.commandDriveTo.Text',
	'Drive to this car park',
	'Gyrru i''r maes parcio hwn'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkMap.commandDriveTo2.Text',
	'Drive to this car park',
	'Gyrru i''r maes parcio hwn'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResult.commandDriveFrom.Text',
	'Drive from this car park',
	'Gyrru o''r maes parcio hwn'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResult.commandDriveFrom2.Text',
	'Drive from this car park',
	'Gyrru o''r maes parcio hwn'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResult.commandDriveTo.Text',
	'Drive to this car park',
	'Gyrru i''r maes parcio hwn'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResult.commandDriveTo2.Text',
	'Drive to this car park',
	'Gyrru i''r maes parcio hwn'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResults.labelNote',
	'Select the car park to travel <b>{0}</b>. Then click ''Next''.',
	'Dewiswch y maes parcio i deithio <b>{0}</b>.  Yna cliciwch ''Nesaf''.'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResultsTable.commandSortByHasDisabledSpaces.AlternateText',
	'Click to sort by disabled spaces',
	'Cliciwch i drefnu yn �l lleoedd i''r anabl'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResultsTable.commandSortByNumberOfSpaces.AlternateText',
	'Click to sort by total number of spaces',
	'Cliciwch i drefnu yn �l cyfanswm nifer y lleoedd'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindCarParkResultsTable.commandSortBySecureCarPark.AlternateText',
	'Click to sort by Park Mark approved',
	'Cliciwch i drefnu yn �l cymeradwyaeth Park Mark'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindFareTicketSelection.messages.Text',
	'Sorry, the {0} fare that you selected is not available on your date of travel.  Please try another fare.',
	'Mae''n ddrwg gennym, dydy''r tocyn {0} rydych chi wedi ei ddewis ddim ar gael ar eich dyddiad teithio.  Rhowch gynnig ar docyn arall.'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindStationResultsTable.commandInfo.Text',
	'i',
	'i'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindStationResultsTable.SecureCarParkCaption',
	'Park Mark Approved',
	'Wedi''i Gymeradwyo gan Park Mark'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'FindTrainCostInput.labelFindTrainCostTitle',
	'Find cheaper rail fares',
	'Canfod tocynnau tr�n rhatach'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HeaderControl.defaultActionButton.AlternateText',
	'Transport Direct',
	'Transport Direct'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HeaderControl.headerHomepageLink.AlternateText',
	'Transport Direct dot info Connecting people to places',
	'Transport Direct dot info Connecting people to places'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HomeDefault.imageFindTrainCost.AlternateText',
	'Find cheaper rail fares',
	'Canfod tocynnau tr�n rhatach'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HomePlanAJourney.imageFindTrainCostSkipLink.AlternateText',
	'Skip to Find cheaper rail fares',
	'Neidio i Ganfod tocynnau tr�n rhatach'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HomePlanAJourney.lblTrainCost',
	'Find cheaper rail fares',
	'Canfod tocynnau tr�n rhatach'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HomeTipsTools.imageDigiTv.AlternateText',
	'DigitalTv',
	'DigitalTv'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HomeTipsTools.imageDigiTvSkipLink.AlternateText',
	'Skip to DigitalTv',
	'Neidio i DigitalTv'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'IncidentMapping.PlannedRoadworks.Alt',
	'Rail Engineering',
	'Gwaith Peirianyddol ar y Rheilffyrdd'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'JourneyPlannerLocationMap.newSearchButton.Text',
	'New search',
	'Chwilio o''r Newydd'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'JourneyPlannerOutputTitle.FindFareSummaryOfOptionsText',
	'Step 3 of 4: Select from the journeys available for your chosen fare',
	'Cam 3 o 4: Dewiswch o''r siwrneiau sydd ar gael am y tocyn rydych chi wedi ei ddewis'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'JourneyReplanInputPage.errorDisplayControl.FirstLocationInvalid',
	'The first location you have selected cannot be used for replanning. Please select another location.',
	'Does dim modd defnyddio''r lleoliad cyntaf a ddewisoch chi ar gyfer ailgynllunio. Dewiswch leoliad arall, os gwelwch yn dda.'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'JourneyReplanInputPage.errorDisplayControl.SecondLocationInvalid',
	'The second location you have selected cannot be used for replanning. Please select another location.',
	'Does dim modd defnyddio''r ail leoliad a ddewisoch chi ar gyfer ailgynllunio.  Dewiswch leoliad arall, os gwelwch yn dda.'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'JourneySummary.labelInstructions2.FindAFare',
	'To find trains at other times return to step two and select another fare.',
	'I ddod o hyd i drenau ar amserau gwahanol, ewch ''n�l i gam dau a dewis tocyn arall.'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'MapRegionSelectControl.headingRegion',
	'View travel news for a region',
	'Gweld y newyddion i deithwyr ar gyfer rhanbarth'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'MapRegionSelectControl.selectAllUk.Text',
	'All UK (excl N Ireland)',
	'Y Deyrnas Unedig i gyd (ar wah�n i Ogledd Iwerddon)'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'MapToolsControl.labelMap.Text',
	'Map:',
	'Map:'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'OtherCostsControl.imageOtherCosts.AlternateText',
	'Other costs icon',
	'Eicon Costau eraill'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'OutputNavigationControl.buttonExtendThisJourney.AlternateText',
	'Refine journey',
	'Mireinio siwrnai'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'OutputNavigationControl.buttonRefineThisJourney.AlternateText',
	'Refine this journey',
	'Mireinio''r siwrnai yma'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'PrintableHeaderControl.connectingPeopleImg.AlternateText',
	'Connecting People to Places',
	'Connecting People to Places'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'PrintableHeaderControl.transportDirectLogoImg.AlternateText',
	'Transport Direct',
	'Transport Direct'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'ShowNewsControl.ErrorMessage.RegionSelectWithSearchPhraseEntered',
	'The search text finds incidents in All UK. To select a region remove the search text entered.',
	'Mae''r testun chwilio yn dod o hyd i ddigwyddiadau yn Y Deyrnas Unedig i Gyd. I ddewis rhanbarth dylech ddileu''r testun chwilio a nodwyd.'




EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'ShowNewsControl.ErrorMessage.SwitchToMapWithSearchPhraseEntered',
	'You need to remove the search text if you would like to view the details on a map.',
	'Mae angen i chi ddileu''r testun chwilio os ydych chi''n dymuno gweld y manylion ar fap.'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'ShowNewsControl.filterTravelNewsLabel',
	'Filter travel news by:',
	'Hidlo''r newyddion i deithwyr yn �l:'




EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'ShowNewsControl.headingRegion',
	'View travel news for a region',
	'Gweld y newyddion i deithwyr ar gyfer rhanbarth'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'ShowNewsControl.TravelNewsSearchExample',
	'e.g. M25, M6, northbound, M40 Oxford, Fanshawe Avenue',
	'e.e. M25, M6, i gyfeiriad y gogledd, M40 Rhydychen, Fanshawe Avenue'



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'ShowNewsControl.TravelNewsSearchTitle',
	'Search all regions travel news',
	'Chwilio am newyddion i deithwyr ym mhob rhanbarth'




EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'TrafficMap.labelTrafficMapHelp',
	'Select/type in a location to show on the map. Then click ''Next''',
	'Dewis/teipio lleoliad i''w ddangos ar y map.  Yna cliciwch ''Nesaf'''



EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'TrafficMap.SelectNewLocationButton.Text',
	'Select new location',
	'Dewis lleoliad newydd'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'TravelNewsHeadlineControl.labelHeadlineTextScreenReader.Text',
	'For further information on a travel news incident, select the link.',
	'Am fwy o wybodaeth ar ddigwyddiad newyddion i deithwyr, dewiswch y ddolen.'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'UserSurvey.PageTitle',
	'User Survey',
	'Arolwg Defnyddwyr'


EXEC dbo.[AddtblContent]
	1,
	1,
	'RefineJourney',
	'ExtendJourneyInput.labelShowAmbiguity.Text',
	'Options',
	'Dewisiadau'


EXEC dbo.[AddtblContent]
	1,
	1,
	'Tools',
	'BusinessLinks.BusinessLinksHeader.Text',
	'Link to our website',
	'Dolen i''n gwefan ni'


EXEC dbo.[AddtblContent]
	1,
	1,
	'Tools',
	'BusinessLinks.Template5Radio.AltText',
	'This template features several fields. There is a single text entry field for typing a location to search for car parks. There is a drop down list to select the type of location entered. The template also contains some instructions and a "Go" button.',
	'Mae''r templed hwn yn cynnwys nifer o feysydd. Mae un maes cofnodi testun yn unig i deipio lleoliad i''w chwilio ar gyfer meysydd parcio. Mae cwymplen i ddewis y math o leoliad a nodwyd. Hefyd, mae''r templed yn cynnwys rhai cyfarwyddiadau a botwm "Go".'


EXEC dbo.[AddtblContent]
	1,
	1,
	'VisitPlanner',
	'VisitPlannerResults.CompareEmissions.Text',
	'Check CO2',
	'Gwirio CO2'


EXEC dbo.[AddtblContent]
	1,
	1,
	'FindAFare',
	'FindFareTicketSelectionControl.NoneProbability',
	'No availability',
	'Ddim ar gael'


USE [TransientPortal]
GO

IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 49 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Cynllun i faes parcio'
     WHERE ResourceNameId = 49
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 50 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Dolenni cysylltiedig'
     WHERE ResourceNameId = 50
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 51 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Adborth'
     WHERE ResourceNameId = 51
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 52 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Manylion Cyswllt'
     WHERE ResourceNameId = 52
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 53 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Gwybodaeth deithio'
     WHERE ResourceNameId = 53
     AND Culture = 'cy-GB'
  END
GO

IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 53 AND Culture = 'en-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Travel information'
     WHERE ResourceNameId = 53
     AND Culture = 'en-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 54 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Gwybodaeth am dwristiaeth ym Mhrydain'
     WHERE ResourceNameId = 54
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 56 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Tr�n'
     WHERE ResourceNameId = 56
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 57 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Llundain'
     WHERE ResourceNameId = 57
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 58 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Maes Awyr'
     WHERE ResourceNameId = 58
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 59 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Bws'
     WHERE ResourceNameId = 59
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 60 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Rheilffordd'
     WHERE ResourceNameId = 60
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 61 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Coets'
     WHERE ResourceNameId = 61
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 62 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Tr�n Tanddaearol/Metro'
     WHERE ResourceNameId = 62
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 64 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Ffer�au a Gwasanaethau Afon'
     WHERE ResourceNameId = 64
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 65 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Seiclo'
     WHERE ResourceNameId = 65
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 67 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Logio i Mewn/Cofrestru'
     WHERE ResourceNameId = 67
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 68 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Defnyddiwr Presennol'
     WHERE ResourceNameId = 68
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 69 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Cofrestru'
     WHERE ResourceNameId = 69
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 70 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Pam dylwn i gofrestru'
     WHERE ResourceNameId = 70
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 103 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Dod o hyd i docynnau tr�n rhatach'
     WHERE ResourceNameId = 103
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 104 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Wedi logio i mewn'
     WHERE ResourceNameId = 104
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 105 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Diweddaru cyfeiriad e-bost'
     WHERE ResourceNameId = 105
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 106 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Dileu Cyfrif'
     WHERE ResourceNameId = 106
     AND Culture = 'cy-GB'
  END
GO


IF EXISTS (SELECT * FROM [dbo].Resource WHERE ResourceNameId = 107 AND Culture = 'cy-GB')
  BEGIN
     UPDATE [dbo].Resource
     SET Text = 'Logio allan'
     WHERE ResourceNameId = 107
     AND Culture = 'cy-GB'
  END
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 850
SET @ScriptDesc = 'inserts into the content database for welsh langstring '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------