-- ***********************************************
-- NAME 		: DUP0884_Update_To_FAQ_InternalLink.sql
-- DESCRIPTION 		: Update to FAQ Internal link
-- AUTHOR		: Amit Patel
-- DATE			: 09 Apr 2008
-- ************************************************

use [TransientPortal]
GO

IF EXISTS (SELECT * FROM InternalLink WHERE Description = 'FAQ')
BEGIN		

	UPDATE 	InternalLink
		SET 	RelativeURL = 'Help/NewHelp.aspx'
		WHERE 	Description = 'FAQ'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 884
SET @ScriptDesc = 'Update to FAQ Internal link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO