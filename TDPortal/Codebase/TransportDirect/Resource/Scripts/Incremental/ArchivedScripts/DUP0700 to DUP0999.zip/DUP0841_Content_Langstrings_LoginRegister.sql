-- ***********************************************
-- NAME 		: DUP0841_Content_Langstrings_LoginRegister.sql
-- DESCRIPTION 		: langstrings for login/Register error message
-- AUTHOR		: darshan sawe
-- Date 		: 26-March-2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [Content]
GO


-----------------------------------------------------------
-- updating PropertyName HomeDefault.lblFindCarPark
-----------------------------------------------------------

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'loginPanel.messageLabel.unregistered',
	'The email address you typed in is not registered.  Please register below.',
	'Nid yw enw''r defnyddiwr y bu i chi ei deipio i mewn wedi ei gofrestru. Cliciwch ar ''Dileu'' fel y gallwch gofrestru yn lle hynny.'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'LoginRegister.loginControlText.Text',
	'Existing user',
	'cy-Existing user'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'LoginRegister.registerControlText.Text',
	'Register',
	'cy- Register'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'LoginRegister.whyRegisterControlText.Text',
	'Why should I register with Transport Direct?',
	'cy - Why should I register with Transport Direct?'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'loginPanel.logoutLabel.Text',
	'Thank you for registering your details with Transport Direct. Now you are logged on you have access to the following functions: <br><ul><li type=disc>Save your favourite journeys so that you can access them in future without having to  re-enter any information<li type=disc>Save travel preferences when entering information for a journey so that you won''t have to enter them again - but you can change them if you wish<li type=disc>Email travel information to other people</ul><br><br> Using the buttons below you are able to change your registered email address, delete your account or simply log out of the site. <br><br>',
	'Thank you for registering your details with Transport Direct. Now you are logged on you have access to the following functions: <br><ul><li type=disc>Save your favourite journeys so that you can access them in future without having to  re-enter any information<li type=disc>Save travel preferences when entering information for a journey so that you won''t have to enter them again - but you can change them if you wish<li type=disc>Email travel information to other people</ul><br><br> Using the buttons below you are able to change your registered email address, delete your account or simply log out of the site. <br><br>'




-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 841
SET @ScriptDesc = 'langstrings for login/Register error message'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------