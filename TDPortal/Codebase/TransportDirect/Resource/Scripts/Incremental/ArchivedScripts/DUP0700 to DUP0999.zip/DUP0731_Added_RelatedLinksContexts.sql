-- ***********************************************
-- NAME 		: DUP0731_Added_RelatedLinksContexts.sql
-- DESCRIPTION 	: Add contexts in Context table for Related links
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

DECLARE @LinkCategoryId INT
DECLARE @LinkPriority INT

SELECT @LinkCategoryId = Max(LinkCategoryId)+1 FROM LinkCategory

SELECT @LinkPriority = Max(Priority) + 10 FROM LinkCategory

IF NOT EXISTS (SELECT TOP 1 * from LinkCategory WHERE [Name] = 'Related links')
BEGIN
	INSERT INTO LinkCategory VALUES(@LinkCategoryId, @LinkPriority, 'Related links', 'Related links')
END


-------------------------------------------------------------------------
-- Removing overview menu items from left menu
-- Removing Home page menu link
-------------------------------------------------------------------------
EXEC RemoveSuggestionLink
		'Overview',
		'Plan a journey',
		'HomePageMenu'

EXEC RemoveSuggestionLink
		'Overview',
		'Find a place',
		'HomePageMenu'
		
EXEC RemoveSuggestionLink
		'Overview',
		'Live travel',
		'HomePageMenu'

EXEC RemoveSuggestionLink
		'Overview',
		'Tips and tools',
		'HomePageMenu'
		
EXEC RemoveSuggestionLink
		'Home',
		'Home',
		'HomePageMenu'


	
-------------------------------------------------------------------------
-- Context for Find Coach Input page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindCoachInput', 'Related Link Context - Suggestions for Find Coach Input Page'
GO

-------------------------------------------------------------------------
-- Context for Adjust Full Itinerary Summary Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextAdjustFullItinerarySummary', 'Related Link Context - Suggestions for Adjust Full Itinerary Page'
GO

-------------------------------------------------------------------------
-- Context for Car Details Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextCarDetails', 'Related Link Context - Suggestions for Car Details Page'
GO

-------------------------------------------------------------------------
-- Context for CO2 Landing Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextCO2LandingPage', 'Related Link Context - Suggestions for CO2 Landing Page'
GO

-------------------------------------------------------------------------
-- Context for Compare Adjusted Journey Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextCompareAdjustedJourney', 'Related Link Context - Suggestions for Compare Adjusted Journey Page'
GO

-------------------------------------------------------------------------
-- Context for Extended Full Itinerary Summary Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextExtendedFullItinerarySummary', 'Related Link Context - Suggestions for Extended Full Itinerary Summary Page'
GO

-------------------------------------------------------------------------
-- Context for Extend Journey Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextExtendJourneyInput', 'Related Link Context - Suggestions for Extend Journey Input Page'
GO

-------------------------------------------------------------------------
-- Context for Extension Results Summary Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextExtensionResultsSummary', 'Related Link Context - Suggestions for Extenstion Results Summary Page'
GO

-------------------------------------------------------------------------
-- Context for Find Station Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindAStationInput', 'Related Link Context - Suggestions for Find A Station Input Page'
GO

-------------------------------------------------------------------------
-- Context for Find Bus Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindBusInput', 'Related Link Context - Suggestions for Find Bus Input Page'
GO

-------------------------------------------------------------------------
-- Context for Find Car Park Map Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindCarParkMap', 'Related Link Context - Suggestions for Find Car Park Map Page'
GO

-------------------------------------------------------------------------
-- Context for Find Car Park Results Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindCarParkResults', 'Related Link Context - Suggestions for Find Car Park Results Page'
GO

-------------------------------------------------------------------------
-- Context for Find Fare Date Selection Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindFareDateSelection', 'Related Link Context - Suggestions for Find Fare Date Selection Page'
GO

-------------------------------------------------------------------------
-- Context for Contect Us Details Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextContactUsDetails', 'Related Link Context - Suggestions for Contect Us Details Page'
GO


-------------------------------------------------------------------------
-- Context for Contect Us Feedback Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFeedbackPage', 'Related Link Context - Suggestions for Feedback Page'
GO

-------------------------------------------------------------------------
-- Context for Find Fare Ticket Selection Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindFareTicketSelection', 'Related Link Context - Suggestions for Find Fare Ticket Selection Page'
GO

-------------------------------------------------------------------------
-- Context for Find Fare Ticket Selection Return Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindFareTicketSelectionReturn', 'Related Link Context - Suggestions for Find Fare Ticket Selection Return Page'
GO

-------------------------------------------------------------------------
-- Context for Find Fare Ticket Selection Singles Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindFareTicketSelectionSingles', 'Related Link Context - Suggestions for Find Fare Ticket Selection Singles Page'
GO

-------------------------------------------------------------------------
-- Context for Find Flight Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindFlightInput', 'Related Link Context - Suggestions for Find Flight Input Page'
GO

-------------------------------------------------------------------------
-- Context for Find Trunk Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindTrunkInput', 'Related Link Context - Suggestions for Find Trunk Input Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Accessibility Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyAccessibility', 'Related Link Context - Suggestions for Journey Accessibility Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Adjust Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyAdjust', 'Related Link Context - Suggestions for Journey Adjust Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Details Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyDetails', 'Related Link Context - Suggestions for Journey Details Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Emissions Compare Journey  Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyEmissionsCompareJourney', 'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Fares  Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyFares', 'Related Link Context - Suggestions for Journey Fares Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Map Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyMap', 'Related Link Context - Suggestions for Journey Map Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Overview Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyOverview', 'Related Link Context - Suggestions for Journey Overview Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Planner Ambiguity Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyPlannerAmbiguity', 'Related Link Context - Suggestions for Journey Planner Ambiguity Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Planner Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyPlannerInput', 'Related Link Context - Suggestions for Journey Planner Input Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Replan Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyReplanInputPage', 'Related Link Context - Suggestions for Journey Replan Input Page'
GO

-------------------------------------------------------------------------
-- Context for Journey Summary Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneySummary', 'Related Link Context - Suggestions for Journey Summary Page'
GO

-------------------------------------------------------------------------
-- Context for Location Information Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextLocationInformation', 'Related Link Context - Suggestions for Location Information Page'
GO

-------------------------------------------------------------------------
-- Context for Refine Details Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextRefineDetails', 'Related Link Context - Suggestions for Refine Details Page'
GO

-------------------------------------------------------------------------
-- Context for Refine Journey Plan Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextRefineJourneyPlan', 'Related Link Context - Suggestions for Refine Journey Plan Page'
GO

-------------------------------------------------------------------------
-- Context for Refine Map Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextRefineMap', 'Related Link Context - Suggestions for Refine Map Page'
GO

-------------------------------------------------------------------------
-- Context for Refine Tickets Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextRefineTickets', 'Related Link Context - Suggestions for Refine Tickets Page'
GO

-------------------------------------------------------------------------
-- Context for Replan Full Itinerary Summary Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextReplanFullItinerarySummary', 'Related Link Context - Suggestions for Replan Full Itinerary Summary Page'
GO

-------------------------------------------------------------------------
-- Context for Retailer Information Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextRetailerInformation', 'Related Link Context - Suggestions for Retailer Information Page'
GO

-------------------------------------------------------------------------
-- Context for Service Details Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextServiceDetails', 'Related Link Context - Suggestions for Service Details Page'
GO

-------------------------------------------------------------------------
-- Context for Ticket Retailers Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextTicketRetailers', 'Related Link Context - Suggestions for Ticket Retailers Page'
GO

-------------------------------------------------------------------------
-- Context for Ticket Retailers Hand Off Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextTicketRetailersHandOff', 'Related Link Context - Suggestions for Ticket Retailers Hand Off Page'
GO

-------------------------------------------------------------------------
-- Context for Ticket Upgrade Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextTicketUpgrade', 'Related Link Context - Suggestions for Ticket Upgrade Page'
GO

-------------------------------------------------------------------------
-- Context for Visit Planner Input Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextVisitPlannerInput', 'Related Link Context - Suggestions for Visit Planner Input Page'
GO

-------------------------------------------------------------------------
-- Context for Visit Planner Results Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextVisitPlannerResults', 'Related Link Context - Suggestions for Visit Planner Results Page'
GO

-------------------------------------------------------------------------
-- Context for Departure Boards Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextDepartureBoards', 'Related Link Context - Suggestions for Departure Boards Page'
GO

-------------------------------------------------------------------------
-- Context for Travel News Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextTravelNews', 'Related Link Context - Suggestions for Travel News Page'
GO



-------------------------------------------------------------------------
-- Context for Journey Planner Location Map Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextJourneyPlannerLocationMap', 'Related Link Context - Suggestions for Journey Planner Location Map Page'
GO

-------------------------------------------------------------------------
-- Context for TD On The Move Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextTDOnTheMove', 'Related Link Context - Suggestions for TD On The Move Page'
GO

-------------------------------------------------------------------------
-- Context for Business Links Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextBusinessLinks', 'Related Link Context - Suggestions for Business Links Page'
GO

-------------------------------------------------------------------------
-- Context for Toolbar Download Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextToolbarDownload', 'Related Link Context - Suggestions for Toolbar Download Page'
GO

-------------------------------------------------------------------------
-- Context for Feedback Viewer Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFeedbackViewer', 'Related Link Context - Suggestions for Feedback Viewer Page'
GO

-------------------------------------------------------------------------
-- Context for Log Viewer Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextLogViewer', 'Related Link Context - Suggestions for Log Viewer Page'
GO

-------------------------------------------------------------------------
-- Context for Version Viewer Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextVersionViewer', 'Related Link Context - Suggestions for Version Viewer Page'
GO

-------------------------------------------------------------------------
-- Context for Find Station Map Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindStationMap', 'Related Link Context - Suggestions for Find Station Map Page'
GO

-------------------------------------------------------------------------
-- Context for Find Station Results Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextFindStationResults', 'Related Link Context - Suggestions for Find Station Results Page'
GO

-------------------------------------------------------------------------
-- Context for Home Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextHome', 'Related Link Context - Suggestions for Home Page'
GO

-------------------------------------------------------------------------
-- Context for Login Register Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextLoginRegister', 'Related Link Context - Suggestions for Login Register Page'
GO

-------------------------------------------------------------------------
-- Context for Seasonal Notice Board Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextSeasonalNoticeBoard', 'Related Link Context - Suggestions for Seasonal Notice Board Page'
GO

-------------------------------------------------------------------------
-- Context for Special Notice Board Page
-------------------------------------------------------------------------

EXEC AddContext 'RelatedLinksContextSpecialNoticeBoard', 'Related Link Context - Suggestions for Special Notice Board Page'
GO











-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 731
SET @ScriptDesc = 'Added contexts for Related links for pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------