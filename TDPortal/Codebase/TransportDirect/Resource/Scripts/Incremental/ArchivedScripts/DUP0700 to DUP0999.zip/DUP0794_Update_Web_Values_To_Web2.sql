-- ***********************************************
-- NAME 		: DUP0794_Update_Web_Values_To_Web2.sql
-- DESCRIPTION 		: Script to update three file references to point 
--			: at the White Label project rather than the web project
-- AUTHOR		: Dan Gath
-- ************************************************


USE [PermanentPortal]
GO

update properties set pValue='/Web2/downloads/BusinessLinksBrochure.pdf' where pName='BusinessLinks.HyperlinkURL.PDFBrochure';
update properties set pValue='/Web2/downloads/CarParkProviders.pdf' where pName='FindNearestCarParks.CarParkProviders.PDF.English';
update properties set pValue='/Web2/downloads/CarParkProviders_CY.pdf' where pName='FindNearestCarParks.CarParkProviders.PDF.Welsh';

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 794
SET @ScriptDesc = 'Script to update three file references to point at the White Label project rather than the web project'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
