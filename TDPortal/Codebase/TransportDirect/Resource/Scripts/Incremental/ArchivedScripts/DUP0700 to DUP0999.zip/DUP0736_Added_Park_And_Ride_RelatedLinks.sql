-- ***********************************************
-- NAME 		: DUP0736_Added_Park_And_Ride_RelatedLinks.sql
-- DESCRIPTION 	: Added Park and Ride page related links
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

-------------------------------------------------------------------------
-- Park and Ride Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextParkAndRide'
SET @ContextDescription = 'Related Links Context - Park and Ride Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO

-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindCarInput.aspx',
	'Find A Car Page',
	'FindCarInput',
	'Find a car route',
	'Canfyddwch lwybr car',
	'Related links',
	1050,
	0,
	'RelatedLinksContextParkAndRide',
	'Related Links Context - Park and Ride Page'
GO

EXEC AddInternalSuggestionLink 
	'LiveTravel/TravelNews.aspx',
	'Travel News Page',
	'LiveTravelNews',
	'Live Travel News',
	'Newyddion teithio byw',
	'Related links',
	1060,
	0,
	'RelatedLinksContextParkAndRide',
	'Related Links Context - Park and Ride Page'
GO

EXEC AddInternalSuggestionLink 
	'Help/NewHelp.aspx',
	'FAQ Page',
	'HELPFAQ',
	'Frequently Asked Questions',
	'Cwestiynau a Ofynnir yn Aml',
	'Related links',
	1070,
	0,
	'RelatedLinksContextParkAndRide',
	'Related Links Context - Park and Ride Page'
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 736
SET @ScriptDesc = 'Added Park and Ride page related links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------
