-- ***********************************************
-- NAME 		: DUP0858_ContentTable_Welsh_Langstring_Update.sql
-- DESCRIPTION 		: content database  update for input pages advanced options soft content
-- AUTHOR		: darshan sawe
-- Date 		: 28-March-2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [Content]
GO


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 58 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindBusInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey).</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to walk?)</li></ul><br/></div></div>'
     WHERE GroupId = 58
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindBusInput'

  END



IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 57 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/ParkAndRideInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></ul><br/></div></div>'
     WHERE GroupId = 57
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/ParkAndRideInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 56 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/VisitPlannerInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey).</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to walk?)</li></ul><br/></div></div>'
     WHERE GroupId = 56
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/VisitPlannerInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 54 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindCoachInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Number of changes (choose whether you are happy to change vehicle or would prefer a direct journey, and how quickly you think you would be able to make any changes)</li></ul><br/></div></div>'
     WHERE GroupId = 54
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindCoachInput'

  END



IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 53 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindCarInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></ul><br/></div></div>'
     WHERE GroupId = 53
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindCarInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 52 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindFlightInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Advanced flight options (choose flights by specific operators and amend your average check-in time)</li></ul><br/></div></div>'
     WHERE GroupId = 52
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindFlightInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 50 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindTrainInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Number of changes (choose whether you are happy to change vehicle or would prefer a direct journey, and how quickly you think you would be able to make any changes)</li></ul><br/></div></div>'
     WHERE GroupId = 50
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindTrainInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 51 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Number of changes (choose whether you are happy to change vehicle or would prefer a direct journey, and how quickly you think you would be able to make any changes)</li></ul><br/></div></div>'
     WHERE GroupId = 51
    AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
    AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 48 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/JourneyPlannerInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey.</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey).</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to walk?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></ul><br/></div></div>'
     WHERE GroupId = 48
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/JourneyPlannerInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 55 AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindTrunkInput')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>With the city-to-city planner you can compare train, plane, coach and car journeys between two cities or towns in Britain on a given day. Select your origin and destination from our dropdown lists of major locations within Britain and city-to-city will give you journey options broken down by transport type.</p><br/></div></div>'
     WHERE GroupId = 55
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/JourneyPlanning/FindTrunkInput'

  END


IF EXISTS (SELECT * FROM [dbo].[tblcontent] WHERE GroupId = 65  AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' AND PropertyName ='/Channels/TransportDirect/LoginRegister')
  BEGIN
     UPDATE [dbo].[tblcontent]
     SET [Value-En] = '<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Registering with Transport Direct is optional.  You can still access most of our features without registering but once registered you can:</p><br/><ul><li>Save your favourite journeys so you can access them again in the future without having to re-enter any information.</li><li>Save travel preferences when entering information for a journey so you don''t have to enter them again - but you still have the option to change them if you wish.</li><li>Email travel options to other people</li></ul><br/><p>It is easy to register, simply enter your email address in the box above, then choose a password between 4 and 12 characters, retype your password, click register and you''re done.</p><br/><p>If at any time you wish to change your registered email address simply enter your current address and password then click the ''change email address'' button and enter your new address.</p><br/></div></div>'
     WHERE GroupId = 65
     AND ControlName = 'TDPageInformationHtmlPlaceHolderDefinition' 
     AND PropertyName ='/Channels/TransportDirect/LoginRegister'

  END





-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 858
SET @ScriptDesc = 'content database  update for input pages advanced options soft content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------