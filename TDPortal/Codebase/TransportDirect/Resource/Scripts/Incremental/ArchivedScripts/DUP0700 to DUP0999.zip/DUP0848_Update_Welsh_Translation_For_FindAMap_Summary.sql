-- ************************************************************
-- NAME 		: DUP0848_Update_Welsh_Translation_For_FindAMap_Summary.sql
-- DESCRIPTION 	: Provides an updated Welsh translation for FindAMap Input Summary
-- AUTHOR		: S Johal
-- ************************************************************
USE Content
GO

update tblContent set [Value-Cy] ='Dewiswch/teipiwch leoliad i�w ddangos ar y map. Yna cliciwch �Nesa�.' where ContentId='73421'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 848
SET @ScriptDesc = 'Provides an updated Welsh translation for FindAMap Input Summary'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------