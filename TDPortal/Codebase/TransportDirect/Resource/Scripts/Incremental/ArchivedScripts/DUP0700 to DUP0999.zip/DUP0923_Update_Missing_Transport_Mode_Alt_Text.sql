-- ***********************************************
-- NAME 		: DUP0923_Update_Missing_Transport_Mode_Alt_Text.sql
-- DESCRIPTION 		: Updates missing alt text in database for transport mode images used in journey details
-- AUTHOR		: Dan Gath
-- DATE			: 07 May 2008
-- ************************************************

USE [Content]
GO

update tblContent set [Value-En]='Air',[Value-Cy]='Aer' where PropertyName='TransportMode.Air.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Bus',[Value-Cy]='Bws' where PropertyName='TransportMode.Bus.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Car',[Value-Cy]='Car' where PropertyName='TransportMode.Car.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Coach',[Value-Cy]='Coets' where PropertyName='TransportMode.Coach.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Cycle',[Value-Cy]='Seiclo' where PropertyName='TransportMode.Cycle.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Drt',[Value-Cy]='Cya' where PropertyName='TransportMode.Drt.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Ferry',[Value-Cy]='Fferi' where PropertyName='TransportMode.Ferry.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Metro',[Value-Cy]='Metro' where PropertyName='TransportMode.Metro.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Rail',[Value-Cy]='Tr�n' where PropertyName='TransportMode.Rail.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Rail Replacement Bus',[Value-Cy]='Bws yn lle rheilffordd' where PropertyName='TransportMode.RailReplacementBus.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Taxi',[Value-Cy]='Tacsi' where PropertyName='TransportMode.Taxi.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Tram',[Value-Cy]='Tram' where PropertyName='TransportMode.Tram.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Underground',[Value-Cy]='Tanddaearol' where PropertyName='TransportMode.Underground.ImageAlternateText' and ControlName='langStrings';
update tblContent set [Value-En]='Walk',[Value-Cy]='Cerddwch' where PropertyName='TransportMode.Walk.ImageAlternateText' and ControlName='langStrings';
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 923
SET @ScriptDesc = 'Updates missing alt text for transport mode images'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO