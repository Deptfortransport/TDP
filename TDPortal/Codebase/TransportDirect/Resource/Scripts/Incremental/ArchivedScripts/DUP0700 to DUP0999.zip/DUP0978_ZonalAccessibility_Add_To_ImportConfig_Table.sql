-- ***********************************************
-- NAME 		: DUP0978_ZonalAccessibility_Add_To_ImportConfig_Table.sql
-- DESCRIPTION 		: Add Zonal Accessibility data to IMPORT_CONFIG table
--			: 
-- AUTHOR		: Sanjeev Johal
-- ************************************************

Use PermanentPortal
go
--insert into IMPORT_CONFIG table
IF NOT EXISTS (SELECT * FROM IMPORT_CONFIGURATION WHERE [DATA_FEED] = 'ert444')
BEGIN
INSERT INTO [dbo].[IMPORT_CONFIGURATION] ([DATA_FEED], [IMPORT_CLASS], [CLASS_ARCHIVE], [IMPORT_UTILITY], [PARAMETERS1], [PARAMETERS2], [PROCESSING_DIR])
VALUES ('ert444', 'TransportDirect.UserPortal.ZonalServices.ZonalAccessibilityImportTask', 'td.userportal.zonalservices.dll', ' ', ' ', ' ', 'C:/Gateway/dat/Processing/ert444')
END
go


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 978
SET @ScriptDesc = 'Add Zonal Accessibility data to IMPORT_CONFIG table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------