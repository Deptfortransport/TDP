-- ************************************************************
-- NAME 		: DUP0842_Welsh_Translation_For_Find_Cheaper_Rail_Fares.sql
-- DESCRIPTION 	: Provides Welsh translation for Find Cheaper Rail Fares
-- AUTHOR		: S Johal
-- ************************************************************
USE TransientPortal
GO

update Resource set Text ='Canfod tocynnau tr�n rhatach' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'FindATrainCost')
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 842
SET @ScriptDesc = 'Provides Welsh translation for Find Cheaper Rail Fares'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------