-- *************************************************************************************
-- NAME 		: DUP0750_Properties_Update_For_White_Labelling.sql
-- DESCRIPTION 		: Properties updated for white labelling in Properties table
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- This sets PricingRetail.RetailXmlDocument.SchemaFilename and TransactionWebService.CJPConfigFilepath
-- properties. The value of this property should be modified depending on the environment its running.

USE [PermanentPortal]
GO

UPDATE Properties 
	SET pValue = 'C:\TDPortal\Codebase\wwwroot\Web2\030829 Journey_Interface v2.xsd'
	WHERE pName = 'PricingRetail.RetailXmlDocument.SchemaFilename'
GO
	
UPDATE Properties 
	SET pValue = 'C:\TDPortal\Codebase\wwwroot\TDPWebServices\TransactionWebService\cjp.client.config'
	WHERE pName = 'TransactionWebService.CJPConfigFilepath'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 750
SET @ScriptDesc = 'Properties updated for white labelling in Properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
