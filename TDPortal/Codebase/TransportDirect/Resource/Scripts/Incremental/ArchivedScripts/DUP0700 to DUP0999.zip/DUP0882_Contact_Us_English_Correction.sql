-- ***********************************************
-- NAME 		: DUP0882_Contact_Us_English_Correction.sql
-- DESCRIPTION 		: Changes "Contact Us" left hand menu link back to English when in English mode
-- AUTHOR		: Steve Barker
-- DATE			: 04 Apr 2008
-- ************************************************

use [TransientPortal]
GO

UPDATE Resource
SET [Text] = 'Contact Us'
WHERE ResourceNameId = (select ResourceNameId from [dbo].[ResourceName] where [ResourceName] = 'ContactDetails') AND
Culture = 'en-GB'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 882
SET @ScriptDesc = 'Changes "Contact Us" left hand menu link back to English when in English mode'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO