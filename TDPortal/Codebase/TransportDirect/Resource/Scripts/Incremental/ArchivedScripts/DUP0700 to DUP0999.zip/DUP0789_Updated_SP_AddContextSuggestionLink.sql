-- *************************************************************************************
-- NAME 		: DUP0789_Updated_SP_AddContextSuggestionLink.sql
-- DESCRIPTION  	: Updated AddContextSuggestionLink with ThemeId parameter
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Mar 2008 18:00:00
-- *************************************************************************************

USE [TransientPortal]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


-- =============================================  
-- Description: AddContextSuggestionLink 
-- =============================================  
ALTER  PROCEDURE [dbo].[AddContextSuggestionLink]    
		@StringLinkResourceName		varchar(100),
		@LinkCategoryName 		varchar(100),
		@StringContextName		varchar(100),
		@ThemeId			int

AS    
BEGIN
	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)   

	DECLARE @ResourceNameID INT,
		@SuggestionLinkID INT,
		@LinkCategoryID INT,
		@ContextId INT,
		@ContextSuggestionLinkID INT

	-- Get default ThemeId is not provided	
	IF @ThemeId IS NULL
	BEGIN
		EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 
	END
	
	-- only add to the table if context name provided
	IF (@StringContextName <> '')
	BEGIN

		-- set values needed for a new context suggestion link
		SET @LinkCategoryID = (select LinkCategoryID from [dbo].[LinkCategory] where [Name] = @LinkCategoryName)
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @StringContextName)

		SET @ResourceNameID = (select ResourceNameId from [dbo].[ResourceName] where [ResourceName] = @StringLinkResourceName)
		SET @SuggestionLinkID = (SELECT MAX(SuggestionLinkID) FROM [dbo].[SuggestionLink] WHERE [LinkCategoryId] = @LinkCategoryID
					AND [ResourceNameID] = @ResourceNameID)

		--insert into ContextSuggestionLink table
		IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId) AND ([ThemeId] = @ThemeId))
			BEGIN
				SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

				INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId], [ThemeId])
				SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId
			END
		ELSE
			BEGIN
				SET @localString_UnableToCarryOutAction = 'Unable to add context suggestion link, already exists for Context: ' + @LinkCategoryName 
					+ ', and Suggestion Link: ' + CAST(@SuggestionLinkID as varchar(10)) + ', and ThemeId: ' + CAST(@ThemeId as varchar(10))
				RAISERROR (@localString_UnableToCarryOutAction, 1,1)
			        RETURN -1
			END

		IF @@error <> 0
	   		BEGIN
				SET @localString_UnableToCarryOutAction = 'Unable to add context suggestion link ' + @StringLinkResourceName + ' in table'
			        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
		        	RETURN -1
			END
	
	END

END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 789
SET @ScriptDesc = 'Updated AddContextSuggestionLink with ThemeId parameter'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
