-- *************************************************************************************
-- NAME 		: DUP0945_user_agent_filter_update.sql
-- DESCRIPTION  	: Updates user_agent_filter for repeat visitor monitoring 
-- AUTHOR		: Steve Craddock
-- *************************************************************************************

use PermanentPortal
go

update properties
set pvalue = ''
where pname = 'Cookie.UserAgent.Robot.Pattern'

go
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 945
SET @ScriptDesc = 'Updates user_agent_filter for repeat visitor monitoring'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

