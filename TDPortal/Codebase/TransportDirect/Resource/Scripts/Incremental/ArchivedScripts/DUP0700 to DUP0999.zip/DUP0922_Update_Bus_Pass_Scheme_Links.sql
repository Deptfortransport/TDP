-- ***********************************************
-- NAME 		: DUP0922_Update_Bus_Pass_Scheme_Links.sql
-- DESCRIPTION 		: Script to update the bus pass scheme links so that they open in a new browser window
-- AUTHOR		: Dan Gath
-- DATE			: 06 May 2008
-- ************************************************

USE [Content]
GO

update tblContent set [Value-En]='<DIV id="primcontent">  <DIV id="contentarea">  <DIV id="hdtypethree"><A id="JourneyPlanning" name="JourneyPlanning"></A>8. Bus</DIV>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.1">8.1)&nbsp; How can I find out about buses that need to be booked in advance?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.2">8.2)&nbsp; Can I plan a bus journey?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.3">8.3)&nbsp; How accurate are bus times?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.4">8.4)&nbsp; What is the English Concessionary Travel Scheme?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.5">8.5)&nbsp; Which bus services on Transport Direct are included in the English Concessionary Travel Scheme?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.6">8.6)&nbsp; What is the Scottish Concessionary Travel Scheme?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.7">8.7)&nbsp; What bus services can I use in Scotland?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.8">8.8)&nbsp; What is the Welsh Concessionary Travel Scheme?</A></P>  <P>&nbsp;</P>  <DIV id="hdtypethree">  <H2>8. Bus</H2></DIV>  <P>  <H4><A class="QuestionLink" id="A8.1" name="A8.1">8.1) How can I find out about buses that need to be booked in advance?</A></H4>  <P>Some bus journeys require advance booking.&nbsp; These are usually more flexible than normal bus services, for example they may pick up or set down at a place you choose.&nbsp; </P>  <P>&nbsp;</P>  <P>If a bus that needs to be booked in advance is listed in your journey plan transport options, the telephone number for booking the bus will be shown on the &#8216;Details&#8217; page (or in the &#8216;Instructions&#8217; column in the table version of the page).</P>  <H4><A class="QuestionLink" id="A8.2" name="A8.2">8.2) Can I plan a bus journey?</A></H4>  <UL>  <LI>From the homepage click on &#8216;Find a bus&#8217; on the left hand navigation or   <LI>Click on the &#8216;Plan a journey&#8217; tab then click &#8216;Find a bus&#8217; or   <LI>Select &#8216;Door-to-door&#8217; then advanced options and deselect all modes of transport other than bus </LI></UL>  <H4><A class="QuestionLink" id="A8.3" name="A8.3">8.3) How accurate are bus times?</A></H4>  <P>Transport Direct aims to give you times for every bus stop on every route. Currently, we can find you times for most bus stops on most routes and our coverage is continually improving. Please note that when we do give you a time at a bus stop it may be an estimate based on the times given for the major stops along the route or estimated from the frequency of the bus service. Therefore it is important that you allow some flexibility in your schedule when travelling by bus.</P>  <H4><A class="QuestionLink" id="A8.4" name="A8.4">8.4) What is the English Concessionary Travel Scheme?</A></H4>  <P>From 1 April 2008 people in England who are 60 and over and/or ''eligible disabled'', who have passes, will be entitled to free off-peak local bus travel anywhere in England. (statutory minimum Mon-Fri from 9.30am to 11pm, any time at weekends)</P>  <P>&nbsp;</P>  <P>Local authorities may offer extra benefits to their residents as part of their concessionary scheme � for example, free or reduced off-peak tram or rail travel, or free bus travel before 9.30 am Monday to Friday, but details should be checked with the local authority.</P>  <P>&nbsp;</P>  <P>Further information can be found at:  <A href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640" target="blank">  http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640</A>  </P>  <H4><A class="QuestionLink" id="A8.5" name="A8.5">8.5) Which bus services on Transport Direct are included in the English Concessionary Travel Scheme?</A></H4>  <P>The scheme applies to off-peak journeys on almost all services described on this site as �bus�. We hope to indicate where this is not the case as more information about exclusions becomes available. For journeys shown as "coach", those which stop frequently will be included in the scheme � but if the service requires pre-booking, a booking fee may still be charged. Most long-distance coach services are not included in the scheme, although coach operators such as National Express already have special fares for the over-60''s so please check with the operator.</P>  <H4><A class="QuestionLink" id="A8.6" name="A8.6">8.6) What is the Scottish Concessionary Travel Scheme?</A></H4>  <P>Scotland-Wide Free Bus Travel started on 1st April 2006 and allows anyone aged over 60 and eligible disabled people, to travel free on both local registered services and long distance bus services within Scotland, without any peak-time restrictions.</P>  <P>&nbsp;</P>  <P>To take advantage of this free bus travel you need to have a National Entitlement Card.</P>  <P>&nbsp;</P>  <P>Further information can be found at: <A href="http://www.transportscotland.gov.uk/concessionarytravel" target="_blank">http://www.transportscotland.gov.uk/concessionarytravel</A></P>  <H4><A class="QuestionLink" id="A8.7" name="A8.7">8.7) What bus services can I use in Scotland?</A></H4>  <P>The National Entitlement Card gives you free bus travel throughout Scotland on virtually all scheduled local registered and long-distance bus services.  Only a small number of services will not be recognise the card, for example premium fare buses and City Sightseeing buses.</P>  <H4><A class="QuestionLink" id="A8.8" name="A8.8">8.8) What is the Welsh Concessionary Travel Scheme?</A></H4>  <P>The Welsh Assembly Government provides financial support to enable local authorities in Wales to provide free travel on registered local bus services for residents of Wales aged over 60 years and disabled of any age. It also provides free travel on local buses by companions to disabled persons.</P>  <P>&nbsp;</P>  <P>The scheme operates across Wales and concessionary pass holders can travel free at any time of day. </P>  <P>&nbsp;</P>  <P>Further information can be found at: <A href="http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en" target="_blank">  http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en</A></P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;</P></DIV></DIV>  <DIV></DIV>  <DIV></DIV>  <DIV></DIV>  <DIV></DIV>',[Value-Cy]='<DIV id="primcontent">  <DIV id="contentarea">  <DIV id="hdtypethree"><A id="JourneyPlanning" name="JourneyPlanning">8. Bws</A></DIV>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.1">8.1)&nbsp; Sut y gallaf ddarganfod am fysiau y mae angen archebu lle ymlaen llaw arnynt?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.2">8.2)&nbsp; A allaf i gynllunio siwrnai fws?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.3">8.3)&nbsp; Pa mor gywir yw''r amserau bws?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.4">8.4)&nbsp; cy What is the English Concessionary Travel Scheme?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.5">8.5)&nbsp; cy Which bus services on Transport Direct are included in the English Concessionary Travel Scheme?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.6">8.6)&nbsp; cy What is the Scottish Concessionary Travel Scheme?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.7">8.7)&nbsp; cy What bus services can I use in Scotland?</A></P>  <P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.8">8.8)&nbsp; cy What is the Welsh Concessionary Travel Scheme?</A></P>  <P>&nbsp;</P>  <DIV id="hdtypethree">  <H2>8. Bws</H2></DIV>  <P>  <H4><A class="QuestionLink" id="A8.1" name="A8.1">8.1) Sut y gallaf ddarganfod am fysiau y mae angen archebu lle ymlaen llaw arnynt?</A></H4>  <P>Mae rhai siwrneion ar fysiau yn gofyn am archebu lle ymlaen llaw.&nbsp; Mae&#8217;r rhain fel arfer yn fwy hyblyg na gwasanaethau bysiau arferol, er enghraifft gallant godi neu ollwng pobl mewn lle o''ch dewis.&nbsp; </P>  <P>&nbsp;</P>  <P>Os rhestrir bws sydd angen archebu lle arno ymlaen llaw yn eich dewisiadau cludiant ar gyfer cynllun eich siwrnai, dangosir y rhif ff&#244;n ar gyfer archebu lle ar y bws ar y dudalen &#8216;Manylion&#8217; (neu yn y golofn &#8216;Cyfarwyddiadau&#8217; yn fersiwn tabl y dudalen).</P>  <H4><A class="QuestionLink" id="A8.2" name="A8.2">8.2) A allaf i gynllunio siwrnai fws?</A></H4>  <UL>  <LI>O''r hafan cliciwch ar "Canfyddwch fws" ar ochr chwith y sgrin neu   <LI>Cliciwch ar y tab "Cynlluniwch siwrnai" yna clicio ar "Canfyddwch fws" neu   <LI>Dewiswch "Ddrws-i-ddrws" yna dewisiadau mwy cymhleth a dad-ddewiswch yr holl ddulliau teithio heblaw am fws</LI></UL>  <H4><A class="QuestionLink" id="A8.3" name="A8.3">8.3) Pa mor gywir yw''r amserau bws?</A></H4>  <P>Mae Transport Direct yn ceisio rhoi amserau ar gyfer pob arhosfan fysiau ar bob llwybr teithio i chi. Ar hyn o bryd, gallwch ffeindio amserau ar gyfer y mwyafrif o&#8217;r arosfannau ar y mwyafrif o&#8217;r llwybrau ac mae hyn yn gwella yn barhaus. Cofiwch, pan fyddwn yn rhoi amser wrth arhosfan i chi gallai fod yn amcangyfrif yn seiliedig ar y prif arosfannau ar hyd y llwybr teithio neu&#8217;n seiliedig ar amlder y gwasanaeth bysiau. Felly mae&#8217;n bwysig eich bod yn caniat&#225;u rhywfaint o hyblygrwydd yn eich rhaglen pan fyddwch yn teithio ar y bws.</P>  <H4><A class="QuestionLink" id="A8.4" name="A8.4">8.4) What is the English Concessionary Travel Scheme?</A></H4>  <P>From 1 April 2008 people in England who are 60 and over and/or ''eligible disabled'', who have passes, will be entitled to free off-peak local bus travel anywhere in England. (statutory minimum Mon-Fri from 9.30am to 11pm, any time at weekends)</P>  <P>&nbsp;</P>  <P>Local authorities may offer extra benefits to their residents as part of their concessionary scheme � for example, free or reduced off-peak tram or rail travel, or free bus travel before 9.30 am Monday to Friday, but details should be checked with the local authority.</P>  <P>&nbsp;</P>  <P>Further information can be found at:  <A href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640" target="_blank">  http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640</A>  </P>  <H4><A class="QuestionLink" id="A8.5" name="A8.5">8.5) Which bus services on Transport Direct are included in the English Concessionary Travel Scheme?</A></H4>  <P>The scheme applies to off-peak journeys on almost all services described on this site as �bus�. We hope to indicate where this is not the case as more information about exclusions becomes available. For journeys shown as "coach", those which stop frequently will be included in the scheme � but if the service requires pre-booking, a booking fee may still be charged. Most long-distance coach services are not included in the scheme, although coach operators such as National Express already have special fares for the over-60''s so please check with the operator.</P>  <H4><A class="QuestionLink" id="A8.6" name="A8.6">8.6) What is the Scottish Concessionary Travel Scheme?</A></H4>  <P>Scotland-Wide Free Bus Travel started on 1st April 2006 and allows anyone aged over 60 and eligible disabled people, to travel free on both local registered services and long distance bus services within Scotland, without any peak-time restrictions.</P>  <P>&nbsp;</P>  <P>To take advantage of this free bus travel you need to have a National Entitlement Card.</P>  <P>&nbsp;</P>  <P>Further information can be found at: <A href="http://www.transportscotland.gov.uk/concessionarytravel" target="_blank">http://www.transportscotland.gov.uk/concessionarytravel</A></P>  <H4><A class="QuestionLink" id="A8.7" name="A8.7">8.7) What bus services can I use in Scotland?</A></H4>  <P>The National Entitlement Card gives you free bus travel throughout Scotland on virtually all scheduled local registered and long-distance bus services.  Only a small number of services will not be recognise the card, for example premium fare buses and City Sightseeing buses.</P>  <H4><A class="QuestionLink" id="A8.8" name="A8.8">8.8) What is the Welsh Concessionary Travel Scheme?</A></H4>  <P>The Welsh Assembly Government provides financial support to enable local authorities in Wales to provide free travel on registered local bus services for residents of Wales aged over 60 years and disabled of any age. It also provides free travel on local buses by companions to disabled persons.</P>  <P>&nbsp;</P>  <P>The scheme operates across Wales and concessionary pass holders can travel free at any time of day. </P>  <P>&nbsp;</P>  <P>Further information can be found at: <A href="http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en" target="_blank">  http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en</A></P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;&nbsp;</P>  <P>&nbsp;</P></DIV></DIV>  <DIV></DIV>  <DIV></DIV>  <DIV></DIV>  <DIV></DIV>' where PropertyName='/Channels/TransportDirect/Help/HelpBus' and ControlName='Body Text' and ThemeId=1;
update tblContent set [Value-En]='<DIV id="primcontent">
<DIV id="contentarea">
<DIV id="hdtypethree"><A id="JourneyPlanning" name="JourneyPlanning"></A>8. Bus</DIV>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.1">8.1)&nbsp; How can I find out about buses that need to be booked in advance?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.2">8.2)&nbsp; Can I plan a bus journey?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.3">8.3)&nbsp; How accurate are bus times?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.4">8.4)&nbsp; What is the English Concessionary Travel Scheme?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.5">8.5)&nbsp; Which bus services on the Journey Planner are included in the English Concessionary Travel Scheme?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.6">8.6)&nbsp; What is the Scottish Concessionary Travel Scheme?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.7">8.7)&nbsp; What bus services can I use in Scotland?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.8">8.8)&nbsp; What is the Welsh Concessionary Travel Scheme?</A></P>
<P>&nbsp;</P>
<DIV id="hdtypethree">
<H2>8. Bus</H2></DIV>
<P>
<h3><A class="QuestionLink" id="A8.1" name="A8.1"></A>8.1) How can I find out about buses that need to be booked in advance?</h3>
<P>Some bus journeys require advance booking.&nbsp; These are usually more flexible than normal bus services, for example they may pick up or set down at a place you choose.&nbsp; </P>
<P>&nbsp;</P>
<P>If a bus that needs to be booked in advance is listed in your journey plan transport options, the telephone number for booking the bus will be shown on the &#8216;Details&#8217; page (or in the &#8216;Instructions&#8217; column in the table version of the page).</P>
<h3><A class="QuestionLink" id="A8.2" name="A8.2"></A>8.2) Can I plan a bus journey?</h3>
<UL>
<LI>From the homepage click on &#8216;Find a bus&#8217; on the left hand navigation or 
<LI>Click on the &#8216;Plan a journey&#8217; tab then click &#8216;Find a bus&#8217; or 
<LI>Select &#8216;Door-to-door&#8217; then advanced options and deselect all modes of transport other than bus </LI></UL>
<h3><A class="QuestionLink" id="A8.3" name="A8.3"></A>8.3) How accurate are bus times?</h3>
<P>The Journey Planner aims to give you times for every bus stop on every route. Currently, we can find you times for most bus stops on most routes and our coverage is continually improving. Please note that when we do give you a time at a bus stop it may be an estimate based on the times given for the major stops along the route or estimated from the frequency of the bus service. Therefore it is important that you allow some flexibility in your schedule when travelling by bus.</P>
<h3><A class="QuestionLink" id="A8.4" name="A8.4"></A>8.4) What is the English Concessionary Travel Scheme?</h3>
<P>From 1 April 2008 people in England who are 60 and over and/or ''eligible disabled'', who have passes, will be entitled to free off-peak local bus travel anywhere in England. (statutory minimum Mon-Fri from 9.30am to 11pm, any time at weekends)</P>
<P>&nbsp;</P>
<P>Local authorities may offer extra benefits to their residents as part of their concessionary scheme � for example, free or reduced off-peak tram or rail travel, or free bus travel before 9.30 am Monday to Friday, but details should be checked with the local authority.</P>
<P>&nbsp;</P>
<P>Further information can be found at:
<A href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640" target="_blank">
http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640</A>
</P>
<h3><A class="QuestionLink" id="A8.5" name="A8.5"></A>8.5) Which bus services on the Journey Planner are included in the English Concessionary Travel Scheme?</h3>
<P>The scheme applies to off-peak journeys on almost all services described on this site as �bus�. We hope to indicate where this is not the case as more information about exclusions becomes available. For journeys shown as "coach", those which stop frequently will be included in the scheme � but if the service requires pre-booking, a booking fee may still be charged. Most long-distance coach services are not included in the scheme, although coach operators such as National Express already have special fares for the over-60''s so please check with the operator.</P>
<h3><A class="QuestionLink" id="A8.6" name="A8.6"></A>8.6) What is the Scottish Concessionary Travel Scheme?</h3>
<P>Scotland-Wide Free Bus Travel started on 1st April 2006 and allows anyone aged over 60 and eligible disabled people, to travel free on both local registered services and long distance bus services within Scotland, without any peak-time restrictions.</P>
<P>&nbsp;</P>
<P>To take advantage of this free bus travel you need to have a National Entitlement Card.</P>
<P>&nbsp;</P>
<P>Further information can be found at: <A href="http://www.transportscotland.gov.uk/concessionarytravel" target="_blank">http://www.transportscotland.gov.uk/concessionarytravel</A></P>
<h3><A class="QuestionLink" id="A8.7" name="A8.7"></A>8.7) What bus services can I use in Scotland?</h3>
<P>The National Entitlement Card gives you free bus travel throughout Scotland on virtually all scheduled local registered and long-distance bus services.  Only a small number of services will not be recognise the card, for example premium fare buses and City Sightseeing buses.</P>
<h3><A class="QuestionLink" id="A8.8" name="A8.8"></A>8.8) What is the Welsh Concessionary Travel Scheme?</h3>
<P>The Welsh Assembly Government provides financial support to enable local authorities in Wales to provide free travel on registered local bus services for residents of Wales aged over 60 years and disabled of any age. It also provides free travel on local buses by companions to disabled persons.</P>
<P>&nbsp;</P>
<P>The scheme operates across Wales and concessionary pass holders can travel free at any time of day. </P>
<P>&nbsp;</P>
<P>Further information can be found at: <A href="http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en" target="_blank">
http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en</A></P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;</P></DIV></DIV>
<DIV></DIV>
<DIV></DIV>
<DIV></DIV>
<DIV></DIV>',[Value-Cy]='<DIV id="primcontent">
<DIV id="contentarea">
<DIV id="hdtypethree"><A id="JourneyPlanning" name="JourneyPlanning">8. Bws</A></DIV>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.1">8.1)&nbsp; Sut y gallaf ddarganfod am fysiau y mae angen archebu lle ymlaen llaw arnynt?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.2">8.2)&nbsp; A allaf i gynllunio siwrnai fws?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.3">8.3)&nbsp; Pa mor gywir yw''r amserau bws?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.4">8.4)&nbsp; cy What is the English Concessionary Travel Scheme?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.5">8.5)&nbsp; cy Which bus services on Journey Planner are included in the English Concessionary Travel Scheme?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.6">8.6)&nbsp; cy What is the Scottish Concessionary Travel Scheme?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.7">8.7)&nbsp; cy What bus services can I use in Scotland?</A></P>
<P class="rsviewcontentrow"><A href="/Web2/Help/HelpBus.aspx#A8.8">8.8)&nbsp; cy What is the Welsh Concessionary Travel Scheme?</A></P>
<P>&nbsp;</P>
<DIV id="hdtypethree">
<H2>8. Bws</H2></DIV>
<P>
<h3><A class="QuestionLink" id="A8.1" name="A8.1"></A>8.1) Sut y gallaf ddarganfod am fysiau y mae angen archebu lle ymlaen llaw arnynt?</h3>
<P>Mae rhai siwrneion ar fysiau yn gofyn am archebu lle ymlaen llaw.&nbsp; Mae&#8217;r rhain fel arfer yn fwy hyblyg na gwasanaethau bysiau arferol, er enghraifft gallant godi neu ollwng pobl mewn lle o''ch dewis.&nbsp; </P>
<P>&nbsp;</P>
<P>Os rhestrir bws sydd angen archebu lle arno ymlaen llaw yn eich dewisiadau cludiant ar gyfer cynllun eich siwrnai, dangosir y rhif ff&#244;n ar gyfer archebu lle ar y bws ar y dudalen &#8216;Manylion&#8217; (neu yn y golofn &#8216;Cyfarwyddiadau&#8217; yn fersiwn tabl y dudalen).</P>
<h3><A class="QuestionLink" id="A8.2" name="A8.2"></A>8.2) A allaf i gynllunio siwrnai fws?</h3>
<UL>
<LI>O''r hafan cliciwch ar "Canfyddwch fws" ar ochr chwith y sgrin neu 
<LI>Cliciwch ar y tab "Cynlluniwch siwrnai" yna clicio ar "Canfyddwch fws" neu 
<LI>Dewiswch "Ddrws-i-ddrws" yna dewisiadau mwy cymhleth a dad-ddewiswch yr holl ddulliau teithio heblaw am fws</LI></UL>
<h3><A class="QuestionLink" id="A8.3" name="A8.3"></A>8.3) Pa mor gywir yw''r amserau bws?</h3>
<P>Mae Journey Planner yn ceisio rhoi amserau ar gyfer pob arhosfan fysiau ar bob llwybr teithio i chi. Ar hyn o bryd, gallwch ffeindio amserau ar gyfer y mwyafrif o&#8217;r arosfannau ar y mwyafrif o&#8217;r llwybrau ac mae hyn yn gwella yn barhaus. Cofiwch, pan fyddwn yn rhoi amser wrth arhosfan i chi gallai fod yn amcangyfrif yn seiliedig ar y prif arosfannau ar hyd y llwybr teithio neu&#8217;n seiliedig ar amlder y gwasanaeth bysiau. Felly mae&#8217;n bwysig eich bod yn caniat&#225;u rhywfaint o hyblygrwydd yn eich rhaglen pan fyddwch yn teithio ar y bws.</P>
<h3><A class="QuestionLink" id="A8.4" name="A8.4"></A>8.4) What is the English Concessionary Travel Scheme?</h3>
<P>From 1 April 2008 people in England who are 60 and over and/or ''eligible disabled'', who have passes, will be entitled to free off-peak local bus travel anywhere in England. (statutory minimum Mon-Fri from 9.30am to 11pm, any time at weekends)</P>
<P>&nbsp;</P>
<P>Local authorities may offer extra benefits to their residents as part of their concessionary scheme � for example, free or reduced off-peak tram or rail travel, or free bus travel before 9.30 am Monday to Friday, but details should be checked with the local authority.</P>
<P>&nbsp;</P>
<P>Further information can be found at:
<A href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640" target="_blank">
http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640</A>
</P>
<h3><A class="QuestionLink" id="A8.5" name="A8.5"></A>8.5) Which bus services on the Journey Planner are included in the English Concessionary Travel Scheme?</h3>
<P>The scheme applies to off-peak journeys on almost all services described on this site as �bus�. We hope to indicate where this is not the case as more information about exclusions becomes available. For journeys shown as "coach", those which stop frequently will be included in the scheme � but if the service requires pre-booking, a booking fee may still be charged. Most long-distance coach services are not included in the scheme, although coach operators such as National Express already have special fares for the over-60''s so please check with the operator.</P>
<h3><A class="QuestionLink" id="A8.6" name="A8.6"></A>8.6) What is the Scottish Concessionary Travel Scheme?</h3>
<P>Scotland-Wide Free Bus Travel started on 1st April 2006 and allows anyone aged over 60 and eligible disabled people, to travel free on both local registered services and long distance bus services within Scotland, without any peak-time restrictions.</P>
<P>&nbsp;</P>
<P>To take advantage of this free bus travel you need to have a National Entitlement Card.</P>
<P>&nbsp;</P>
<P>Further information can be found at: <A href="http://www.transportscotland.gov.uk/concessionarytravel" target="_blank">http://www.transportscotland.gov.uk/concessionarytravel</A></P>
<h3><A class="QuestionLink" id="A8.7" name="A8.7"></A>8.7) What bus services can I use in Scotland?</h3>
<P>The National Entitlement Card gives you free bus travel throughout Scotland on virtually all scheduled local registered and long-distance bus services.  Only a small number of services will not be recognise the card, for example premium fare buses and City Sightseeing buses.</P>
<h3><A class="QuestionLink" id="A8.8" name="A8.8"></A>8.8) What is the Welsh Concessionary Travel Scheme?</h3>
<P>The Welsh Assembly Government provides financial support to enable local authorities in Wales to provide free travel on registered local bus services for residents of Wales aged over 60 years and disabled of any age. It also provides free travel on local buses by companions to disabled persons.</P>
<P>&nbsp;</P>
<P>The scheme operates across Wales and concessionary pass holders can travel free at any time of day. </P>
<P>&nbsp;</P>
<P>Further information can be found at: <A href="http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en" target="_blank">
http://new.wales.gov.uk/topics/transport/IntegratedTransport/concessionaryTravel/concessionFares1/?lang=en</A></P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;&nbsp;</P>
<P>&nbsp;</P></DIV></DIV>
<DIV></DIV>
<DIV></DIV>
<DIV></DIV>
<DIV></DIV>' where PropertyName='/Channels/TransportDirect/Help/HelpBus' and ControlName='Body Text' and ThemeId!=1;
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 922
SET @ScriptDesc = 'Update bus pass scheme links to open in new window'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO