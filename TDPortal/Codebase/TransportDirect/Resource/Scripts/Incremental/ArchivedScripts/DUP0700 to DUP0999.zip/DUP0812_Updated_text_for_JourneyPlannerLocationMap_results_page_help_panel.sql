-- ************************************************************
-- NAME 		: DUP0812_Updated_text_for_JourneyPlannerLocationMap_results_page_help_panel.sql
-- DESCRIPTION 		: Provides updated text for JourneyPlannerLocationMap results page help panel
-- AUTHOR		: Dan Gath
-- ************************************************************
USE Content
GO

update tblContent set [Value-EN]='Use the buttons above the map to:<br>  � Plan a journey to or from the current location shown on the map<br>  � Select a new location to show on the map.<br><br>  Use the buttons to the top-left of the map to:<br>  � Zoom into (magnify) and zoom out of (shrink) the map<br><br>    Use the buttons beneath the map to:<br>  � Show or hide various places of interest on the map<br><br>', [Value-CY]='cy- Use the buttons above the map to:<br>  � Plan a journey to or from the current location shown on the map<br>  � Select a new location to show on the map.<br><br>  Use the buttons to the top-left of the map to:<br>  � Zoom into (magnify) and zoom out of (shrink) the map<br><br>    Use the buttons beneath the map to:<br>  � Show or hide various places of interest on the map<br><br>' where ContentId='53892'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 812
SET @ScriptDesc = 'Updated text for JourneyPlannerLocationMap results page help panel'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------