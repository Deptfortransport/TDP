-- ************************************************************
-- NAME 		: DUP0824_Updates_for_new_table_view_in_fuel_costs.sql
-- DESCRIPTION 	: Adds text for new table view in fuel costs
-- AUTHOR		: STsang
-- ************************************************************

USE Content
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDashboardControl.FuelUsedTitle.Text',
'Fuel Used (for your journey)',
'cy-Fuel Used (for your journey)'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDashboardControl.CommandSwitchTable.Text',
'Click to switch to table view',
'cy-Click to switch to table view'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDashboardControl.CommandSwitchGraphic.Text',
'Click to switch to diagram view',
'cy-Click to switch to diagram view'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsCompareControl.Cost',
'Cost',
'cy-Gost'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 824
SET @ScriptDesc = 'Adds text for new table view in fuel costs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------