-- ***********************************************
-- NAME 		: DUP0867_Add_ResultsTableSortingImages.sql
-- DESCRIPTION 		: Script to add sort icons for Results table
-- AUTHOR		: Mitesh Modi
-- DATE			: 31 Mar 2008 18:00:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO

----------------------------------------------------------
-- Header text
----------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'SummaryResultTableControl.ImageSortIconDescending', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryDescending.gif', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryDescending.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'SummaryResultTableControl.ImageSortIconAscending', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryAscending.gif', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/FindSummaryAscending.gif'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 867
SET @ScriptDesc = 'Sort icons added for results table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO