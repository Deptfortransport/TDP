USE TransientPortal

UPDATE dbo.ExternalLinks SET
		URL = 'http://www.acis.uk.com/ACISLive/tabid/79/Default.aspx' , 
		TestURL = 'http://www.acis.uk.com/ACISLive/tabid/79/Default.aspx' 
		WHERE Description like '%Departure Board - Acis Live%'



UPDATE dbo.ChangeNotification SET
		Version = Version + 1
		Where [Table] like '%ExternalLinks%'