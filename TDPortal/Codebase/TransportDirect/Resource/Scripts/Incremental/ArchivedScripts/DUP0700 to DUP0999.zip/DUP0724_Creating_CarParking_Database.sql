-- ***********************************************
-- NAME 	: DUP0724_Creating_CarParking_Database.sql
-- DESCRIPTION 	: Creates the Car Parking database according IF064
-- ************************************************

--   Rev Devfactory Jan 15 2008 14:37:32 apatel
--Initial revision.

-- Please provide appropriate permissions

USE master
GO

IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'CarParks')
BEGIN
	DROP DATABASE [CarParks]
END
GO

CREATE DATABASE [CarParks] ON (NAME = N'CarParks', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL\Data\CarParks.mdf' , SIZE = 3, FILEGROWTH = 10%) LOG ON (NAME = N'CarParks_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL\Data\CarParks_log.ldf' , SIZE = 1, FILEGROWTH = 10%) COLLATE SQL_Latin1_General_CP1_CI_AS 
GO

exec sp_dboption N'CarParks', N'torn page detection', N'true'
GO

exec sp_dboption N'CarParks', N'autoshrink', N'false'
GO

exec sp_dboption N'CarParks', N'ANSI null default', N'true'
GO

exec sp_dboption N'CarParks', N'ANSI nulls', N'true'
GO

exec sp_dboption N'CarParks', N'ANSI warnings', N'true'
GO

exec sp_dboption N'CarParks', N'auto create statistics', N'true'
GO

exec sp_dboption N'CarParks', N'auto update statistics', N'true'
GO

if( ( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) ) or ( (@@microsoftversion / power(2, 24) = 7) and (@@microsoftversion & 0xffff >= 1082) ) )
	exec sp_dboption N'CarParks', N'db chaining', N'false'
GO


use [master]
ALTER DATABASE [CarParks] SET RECOVERY SIMPLE
GO

-- CREATE appropriate permissions

GRANT EXECUTE ON [CarParks] TO [???]
GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber =724
SET @ScriptDesc = 'Added new CarParks Database.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO