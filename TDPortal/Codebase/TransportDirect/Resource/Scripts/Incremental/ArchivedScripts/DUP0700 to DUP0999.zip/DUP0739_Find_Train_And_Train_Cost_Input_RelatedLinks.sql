-- ***********************************************
-- NAME 		: DUP0739_Find_Train_And_Train_Cost_Input_RelatedLinks.sql
-- DESCRIPTION 	: Added Find Train Input and Find Train Cost Input page related links
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

-------------------------------------------------------------------------
-- Find Train Input Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextFindTrainInput'
SET @ContextDescription = 'Related Link Context - Suggestions for Find Train Input Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO

-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'LiveTravel/TravelNews.aspx',
	'Travel News Page',
	'LiveTravelNews',
	'Live Travel News',
	'Newyddion teithio byw',
	'Related links',
	1240,
	0,
	'RelatedLinksContextFindTrainInput',
	'Related Link Context - Suggestions for Find Train Input Page'
GO

EXEC AddInternalSuggestionLink 
	'LiveTravel/DepartureBoards.aspx',
	'Departure boards',
	'DepartureBoards',
	'Departure boards',
	'Byrddau cyrraedd a chychwyn',
	'Related links',
	1250,
	0,
	'RelatedLinksContextFindTrainInput',
	'Related Link Context - Suggestions for Find Train Input Page'
GO


EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindAStationInput.aspx',
	'Find nearest station/airport',
	'FindNearestStation/Airport',
	'Find nearest station/airport',
	'Dod o hyd i''r orsaf/maes awyr agosaf',
	'Related links',
	1260,
	0,
	'RelatedLinksContextFindTrainInput',
	'Related Link Context - Suggestions for Find Train Input Page'
GO

EXEC AddInternalSuggestionLink 
	'Maps/JourneyPlannerLocationMap.aspx',
	'Find a map',
	'FindAMap',
	'Find a map',
	'Darganfyddwch fap',
	'Related links',
	1270,
	0,
	'RelatedLinksContextFindTrainInput',
	'Related Link Context - Suggestions for Find Train Input Page'
GO


EXEC AddInternalSuggestionLink 
	'Maps/NetworkMaps.aspx',
	'Traffic levels',
	'NetworkMaps',
	'Transport network maps',
	'Mapiau rhwydwaith',
	'Related links',
	1280,
	0,
	'RelatedLinksContextFindTrainInput',
	'Related Link Context - Suggestions for Find Train Input Page'
GO

EXEC AddInternalSuggestionLink 
	'TDOnTheMove/TDOnTheMove.aspx',
	'Mobile/PDA',
	'MobileDemonstrator',
	'Mobile demonstrator',
	'Symudol/PDA',
	'Related links',
	1290,
	0,
	'RelatedLinksContextFindTrainInput',
	'Related Link Context - Suggestions for Find Train Input Page'
GO


EXEC AddInternalSuggestionLink 
	'Help/NewHelp.aspx',
	'FAQ Page',
	'HELPFAQ',
	'Frequently Asked Questions',
	'Cwestiynau a Ofynnir yn Aml',
	'Related links',
	1300,
	0,
	'RelatedLinksContextFindTrainInput',
	'Related Link Context - Suggestions for Find Train Input Page'
GO

-------------------------------------------------------------------------
-- Find Train Cost Input Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT
	
SET @ContextName = 'RelatedLinksContextFindTrainCostInput'
SET @ContextDescription = 'Related Link Context - Suggestions for Find Train Cost Input Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

--insert into ContextSuggestionLink table
DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO


-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'LiveTravel/TravelNews.aspx',
	'Travel News Page',
	'LiveTravelNews',
	'Live Travel News',
	'Newyddion teithio byw',
	'Related links',
	1310,
	0,
	'RelatedLinksContextFindTrainCostInput',
	'Related Link Context - Suggestions for Find Train Cost Input Page'
GO

EXEC AddInternalSuggestionLink 
	'LiveTravel/DepartureBoards.aspx',
	'Departure boards',
	'DepartureBoards',
	'Departure boards',
	'Byrddau cyrraedd a chychwyn',
	'Related links',
	1320,
	0,
	'RelatedLinksContextFindTrainCostInput',
	'Related Link Context - Suggestions for Find Train Cost Input Page'
GO


EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindAStationInput.aspx',
	'Find nearest station/airport',
	'FindNearestStation/Airport',
	'Find nearest station/airport',
	'Dod o hyd i''r orsaf/maes awyr agosaf',
	'Related links',
	1330,
	0,
	'RelatedLinksContextFindTrainCostInput',
	'Related Link Context - Suggestions for Find Train Cost Input Page'
GO

EXEC AddInternalSuggestionLink 
	'Maps/JourneyPlannerLocationMap.aspx',
	'Find a map',
	'FindAMap',
	'Find a map',
	'Darganfyddwch fap',
	'Related links',
	1340,
	0,
	'RelatedLinksContextFindTrainCostInput',
	'Related Link Context - Suggestions for Find Train Cost Input Page'
GO


EXEC AddInternalSuggestionLink 
	'Maps/NetworkMaps.aspx',
	'Traffic levels',
	'NetworkMaps',
	'Transport network maps',
	'Mapiau rhwydwaith',
	'Related links',
	1350,
	0,
	'RelatedLinksContextFindTrainCostInput',
	'Related Link Context - Suggestions for Find Train Cost Input Page'
GO

EXEC AddInternalSuggestionLink 
	'TDOnTheMove/TDOnTheMove.aspx',
	'Mobile/PDA',
	'MobileDemonstrator',
	'Mobile demonstrator',
	'Symudol/PDA',
	'Related links',
	1360,
	0,
	'RelatedLinksContextFindTrainCostInput',
	'Related Link Context - Suggestions for Find Train Cost Input Page'
GO


EXEC AddInternalSuggestionLink 
	'Help/NewHelp.aspx',
	'FAQ Page',
	'HELPFAQ',
	'Frequently Asked Questions',
	'Cwestiynau a Ofynnir yn Aml',
	'Related links',
	1370,
	0,
	'RelatedLinksContextFindTrainCostInput',
	'Related Link Context - Suggestions for Find Train Cost Input Page'
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 739
SET @ScriptDesc = 'Added Find Train Input and Find Train Cost Input page related links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------
