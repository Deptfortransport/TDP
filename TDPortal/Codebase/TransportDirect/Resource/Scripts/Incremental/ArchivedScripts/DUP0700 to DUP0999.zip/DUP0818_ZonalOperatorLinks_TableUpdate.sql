-- *************************************************************************************
-- NAME 		: DUP0818_ZonalOperatorLinks_TableUpdate.sql
-- DESCRIPTION  	: Updates to ZonalOpertorLinks table to make RegionId part of the primary key
-- AUTHOR		: Mitesh Modi
-- *************************************************************************************


USE [TransientPortal]
GO

-------------------------------------------------------------
-- Update primary key
-------------------------------------------------------------

-- Drop existing key
ALTER TABLE [dbo].[ZonalOperatorLinks] DROP CONSTRAINT [PK_ZonalOperatorLinks]

GO

-- Add new key
ALTER TABLE [dbo].[ZonalOperatorLinks] ADD 
	CONSTRAINT [PK_ZonalOperatorLinks] PRIMARY KEY  CLUSTERED 
	(
		[RegionId],
		[OperatorCode],
		[ModeId]
	)  ON [PRIMARY] 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 818
SET @ScriptDesc = 'Updates to ZonalOpertorLinks table primary key'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
