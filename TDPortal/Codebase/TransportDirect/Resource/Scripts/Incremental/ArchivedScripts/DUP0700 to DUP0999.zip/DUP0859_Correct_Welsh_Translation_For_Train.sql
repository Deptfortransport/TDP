-- ************************************************************
-- NAME 		: DUP0859_Correct_Welsh_Translation_For_Train.sql
-- DESCRIPTION 	: Provides correct Welsh translation for Train 
-- AUTHOR		: S Johal
-- ************************************************************
USE TransientPortal
GO

update Resource set Text ='Tr�n' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'DepartureBoards.Train')
update Resource set Text ='Tr�n Tanddaearol/Metro' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'NetworkMaps.UndergroundMetro')
update Resource set Text ='Tr�n' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'FAQ.Train')
update Resource set Text ='Dod o hyd i docynnau tr�n rhatach' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'FindATrainCost')

update Resource set Text ='Canfyddwch dr�n' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'FindATrain')

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 859
SET @ScriptDesc = 'Provides correct Welsh translation for Train'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------