-- ************************************************************
-- NAME 		: DUP0819_Modify_text_for_Find_Nearest_Car_Park.sql
-- DESCRIPTION 	: Modifies text from 'car park' to 'car parks'
-- AUTHOR		: STsang
-- ************************************************************
USE RESOURCE
GO

UPDATE resource
SET text = '
Find nearest car parks'
WHERE ResourceNameId = 31 AND Culture = 'en-GB'
GO

USE CONTENT
GO

UPDATE tblContent
SET [Value-En] = '
Find nearest car parks'
WHERE ContentId = 53389
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 819
SET @ScriptDesc = 'Modifies text from ''car park'' to ''car parks'''

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------