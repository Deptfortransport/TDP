-- ************************************************************
-- NAME 		: DUP0874_Added_FindCarParkResult_DriveTo_Mode_Text.sql
-- DESCRIPTION 	: Added Content for FindCarParkResult DriveTo Mode
-- AUTHOR		: apatel
-- ************************************************************
USE Content
GO

EXEC AddtblContent
1, 1,'langStrings','FindCarParkResult.labelNote.CarParkDriveToMode.Valid','Select the Car park you wish to travel to below. Then click "Drive <b>to</b>."','cy Select the Car park you wish to travel to below. Then click "Drive <b>to</b>."'

GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 874
SET @ScriptDesc = 'Added Content for FindCarParkResult DriveTo Mode'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------