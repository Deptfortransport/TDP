-- ***********************************************
-- NAME 		: DUP0735_Added_Park_And_Ride_Input_RelatedLinks.sql
-- DESCRIPTION 	: Added Park and Ride Input page related links
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO


-------------------------------------------------------------------------
-- Adding Resource RelatedLinks
-------------------------------------------------------------------------

-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SET @LinkResourceNameEN = 'Related links'
SET @LinkResourceNameCY = 'cy Related links'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-------------------------------------------------------------------------
-- Add Internal link for related link
-------------------------------------------------------------------------
-- Add the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link 10 (INTERNAL)

SET @InternalLinkDescription = 'Related Links'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , NULL, @InternalLinkDescription


-------------------------------------------------------------------------
-- Park and Ride Input Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links

-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextParkAndRideInput'
SET @ContextDescription = 'Related Links Context - Park and Ride Input Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


--insert into SuggestionLink table
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@InternalExternalLinkID INT


-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @LinkPriority = 1000
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1

DECLARE @ContextSuggestionLinkID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
Go

-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindCarInput.aspx',
	'Find A Car Page',
	'FindCarInput',
	'Find a car route',
	'Canfyddwch lwybr car',
	'Related links',
	1010,
	0,
	'RelatedLinksContextParkAndRideInput',
	'Related Links Context - Park and Ride Input Page'
GO


EXEC AddInternalSuggestionLink 
	'JourneyPlanning/ParkAndRide.aspx',
	'Park And Ride Page',
	'ParkAndRide',
	'Park and ride schemes',
	'Cynlluniau Parcio a Theithio',
	'Related links',
	1020,
	0,
	'RelatedLinksContextParkAndRideInput',
	'Related Links Context - Park and Ride Input Page'
GO


-- Resource table has two "LiveTravel" resource

IF EXISTS (SELECT * FROM ResourceName WHERE ResourceNameId = 2 AND ResourceName = 'LiveTravel')
	UPDATE ResourceName SET ResourceName = 'LiveTravelNews'
		WHERE ResourceNameId = 2 AND ResourceName = 'LiveTravel'

EXEC AddInternalSuggestionLink 
	'LiveTravel/TravelNews.aspx',
	'Travel News Page',
	'LiveTravelNews',
	'Live Travel News',
	'Newyddion teithio byw',
	'Related links',
	1030,
	0,
	'RelatedLinksContextParkAndRideInput',
	'Related Links Context - Park and Ride Input Page'
GO

EXEC AddInternalSuggestionLink 
	'Help/NewHelp.aspx',
	'FAQ Page',
	'HELPFAQ',
	'Frequently Asked Questions',
	'Cwestiynau a Ofynnir yn Aml',
	'Related links',
	1040,
	0,
	'RelatedLinksContextParkAndRideInput',
	'Related Links Context - Park and Ride Input Page'
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 735
SET @ScriptDesc = 'Added Park and Ride Input page related links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------

