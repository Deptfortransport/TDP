-- ************************************************************
-- NAME 	: DUP0759_ExceptionalFares_Table_PartnerSpecificChanges.sql
-- DESCRIPTION 	: Updated ExceptionalFares Table to add ThemeId column
-- Author       : Darshan Sawe
-- Date         : 19-Feb-2008
-- ************************************************************
--

USE [PermanentPortal]
GO

--------------------------------------------------
-- 1. Add ThemeId column in ExceptionalFares Table
--------------------------------------------------

IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('ExceptionalFares ')
						AND syscolumns.name = 'ThemeId')
BEGIN
	ALTER TABLE ExceptionalFares ADD [ThemeId] INT NOT NULL DEFAULT(1)
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
			WHERE CONSTRAINT_CATALOG = 'PermanentPortal'
			AND TABLE_NAME ='ExceptionalFares'
			AND CONSTRAINT_NAME = 'PK_ExceptionalFares')		

BEGIN
	ALTER TABLE [ExceptionalFares]  DROP 
		CONSTRAINT [PK_ExceptionalFares]

	ALTER TABLE [dbo].[ExceptionalFares] ADD 
	CONSTRAINT [PK_ExceptionalFares] PRIMARY KEY  CLUSTERED 
	(
		[FareType],
		[ThemeId]
	)  ON [PRIMARY] 
END
GO

--------------------------------------------
-- 2. Alter GetExceptionalFares	 procedure
--------------------------------------------


--Create procedure if not present

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetExceptionalFares'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetExceptionalFares] AS BEGIN SET NOCOUNT ON END')
	END
GO


ALTER PROCEDURE GetExceptionalFares
(
	@ThemeName varchar(100)
)
AS
BEGIN

	DECLARE @ThemeId INT
	DECLARE @DefaultThemeId INT

	EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT

	IF @ThemeId IS NULL
		BEGIN
		RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
		END

	EXEC [Content].[dbo].[GetDefaultThemeId] @DefaultThemeId OUTPUT 
	
	SELECT FareType, [Action]
	FROM ExceptionalFares
	WHERE ThemeId = @ThemeId
	UNION ALL
	(	
	SELECT FareType, [Action]
	FROM ExceptionalFares
	WHERE
		FareType IN
		(
		SELECT DISTINCT FareType
		FROM ExceptionalFares
		WHERE [ThemeId] = @DefaultThemeId  
		AND FareType  NOT IN
		(
			SELECT DISTINCT FareType
			FROM ExceptionalFares
			WHERE ThemeId = @ThemeId
		)
		
		)
	AND ThemeId = @DefaultThemeId 
	
			
	)
			
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 759
SET @ScriptDesc = 'Added ThemeId column in ExceptionalFares Table & updated GetExceptionalFares Proc '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
