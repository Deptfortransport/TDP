-- *************************************************************************************
-- NAME 		: DUP0951_Updates_carpark_notes_column.sql
-- DESCRIPTION  	: Updated column width for carpark notes
-- AUTHOR		: Steve Craddock
-- *************************************************************************************

-- *******************************************
-- This section must be run on EACH mapping DB
-- *******************************************
use TDP_MAPS
go

alter table mapsadmin.CARPARKS
alter column [Notes] varchar(300) Null
go

update sde.SDE_column_registry
set column_size = 300
where database_name = 'TDP_MAPS' and
table_name = 'CARPARKS' and
owner = 'MAPSADMIN' and
column_name = 'NOTES'

go

-- **********************
-- end of maps db section
-- **********************

use carparks
go

alter table CarParking
alter column [Notes] varchar(300) Null
go

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

-- ALTER  new stored procedure
ALTER  PROCEDURE dbo.ImportCarParkingData (@XML text) AS

	SET NOCOUNT ON
	SET XACT_ABORT ON

	-- Start Transaction

	DECLARE @DocID int
	DECLARE @XMLPathData varchar(50)
			

	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/'


		----------------------------------------------------
		-- Reference Data Tables
		----------------------------------------------------

BEGIN TRANSACTION T2
		-- Car Park Access Points
		INSERT INTO CarParkingAccessPoints (GeocodeType, Easting, Northing, StreetName,  BarrierInOperation)
		SELECT DISTINCT * FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/AccessPoints', 2)
		WITH
		(
			GeocodeType varchar(10),
			Easting varchar(7),
			Northing varchar(7),
			StreetName varchar(100),
			BarrierInOperation varchar(3)
		) X 
		 	


		-- Car Park Operator
		INSERT INTO CarParkingOperator (OperatorCode, OperatorName, OperatorURL,  OperatorTsAndCs, OperatorEmail)
		SELECT DISTINCT * FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/CarParkOperator', 2)
		WITH
		(
			OperatorCode varchar(50),
			OperatorName varchar(100),
			OperatorURL varchar(2048),
			OperatorTsAndCs varchar(2048),
			OperatorEmail varchar(100)
		) X WHERE NOT EXISTS 
			(SELECT * FROM CarParkingOperator
				WHERE CarParkingOperator.OperatorCode = X.OperatorCode)
				


		-- Traffic News Region
		INSERT INTO CarParkingTrafficNewsRegion (RegionName)
		SELECT DISTINCT * FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/TrafficNewsRegion', 2)
		WITH
		(
			RegionName varchar (100)
		)	


		-- Car Park Attraction Type
		INSERT INTO CarParkingAttractionType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID,  '/CarParkDataImport/CarPark/CarParkAdditionalData/Attractions', 2)
		WITH	
		(
			AttractionTypeCode int,
			AttractionTypeDescription varchar(50)
		) X WHERE NOT EXISTS
			(SELECT * FROM CarParkingAttractionType
				WHERE CarParkingAttractionType.TypeCode = X.AttractionTypeCode)

		-- Car Park Facilties Type
		INSERT INTO CarParkingFacilitiesType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID,  '/CarParkDataImport/CarPark/CarParkAdditionalData/Facilities', 2)
		WITH
		(
			FacilityTypeCode varchar(100),
			FacilityTypeDescription varchar(100)
		) X WHERE NOT EXISTS
			(SELECT * FROM CarParkingFacilitiesType
				WHERE CarParkingFacilitiesType.TypeCode = X.FacilityTypeCode)

		-- Car Park Calendar Elements
		INSERT INTO CarParkingCalendar (
			Start,
			[End],
			Days,
			PublicHols)
		SELECT  X.CalendarStartDate,
			X.CalendarEndDate,
			X.Days,
			X.PublicHolidays
		FROM	
		OPENXML (@docId, '//Calendar', 2)
		WITH (	
			CalendarStartDate datetime,
			CalendarEndDate datetime,
			Days varchar(7),
			PublicHolidays varchar(8)
			) X

		
		-- Park and Ride Scheme
		INSERT INTO CarParkingParkAndRideScheme (Location, SchemeUrl, Comments,  LocationEasting, LocationNorthing, TransferFrequency, TransferFrom, TransferTo)
		SELECT DISTINCT * FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/ParkAndRideScheme' ,2)
		WITH
		(
			Location varchar(100),
			SchemeURL varchar(2048),
			Comments varchar(200),
			LocationEasting varchar(7),
			LocationNorthing varchar(7),
			TransferFrequency varchar(100),			TransferFrom  varchar(250),
			TransferTo varchar(250)
		)

		-- NPTG Admin District
		INSERT INTO CarParkingNPTGAdminDistrict (AdminAreaCode, DistrictCode)
		SELECT DISTINCT * FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/NPTGAdminDistrict' ,2)
		WITH
		(
			AdminAreaCode varchar(50),
			DistrictCode varchar(50)
		)

COMMIT TRANSACTION T2


BEGIN TRANSACTION T3
		-- Car Parking Table
		INSERT INTO CarParking (
			Reference,
			OperatorId,
			AccessPointsMapId,
			AccessPointsEntranceId,
			AccessPointsExitId,			
			TrafficNewsRegionId,
			ParkAndRideSchemeId,
			NPTGAdminDistrictId,
			Name,
			Location,
			Address,
			Postcode,
			Notes,
			Telephone,
			Url,
			MinCost,
			ParkAndRide,
			StayType,
			PlanningPoint,
			DateRecordLastUpdated,
			WEUDate,
			WEFDate)
		SELECT  X.CarParkRef,
			x.operatorcode,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing =  x.mapaccesspointnorthing AND easting = x.mapaccesspointeasting and geocodetype = 'Map') AS  AccessPointsMapId,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing =  x.entranceaccesspointnorthing AND easting = x.entranceaccesspointeasting and geocodetype =  'Entrance') AS AccessPointsEntranceId,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing =  x.exitaccesspointnorthing AND easting = x.exitaccesspointeasting and geocodetype = 'Exit') AS  AccessPointsExitId,
			(SELECT top 1 Id FROM CarParkingTrafficNewsRegion WHERE regionname =  x.trafficnewsregionname) AS RegionId,
			(SELECT top 1 Id FROM CarParkingParkAndRideScheme WHERE location =  x.ParkAndRideLocation) AS ParkAndRideId,
			(SELECT top 1 Id FROM CarParkingNPTGAdminDistrict WHERE adminareacode =  x.nptgareacode) as NPTGAdminDistrictId,
			X.CarParkName,
			X.Location,
			X.Address,
			X.PostCode,
			X.Notes,
			X.Telephone,
			X.Url,
			X.MinCostPence,
			CASE X.IsParkAndRide
			  WHEN 'true' THEN 1
			  ELSE 0
			END,
			X.StayType,
			CASE X.PlanningPoint
			  WHEN 'true' THEN 1
			  ELSE 0
			END,
			X.DateRecordLastUpdated,
			X.WEUDate,
			X.WEFDate	
		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark', 2)
		WITH (	
			CarParkRef varchar(50),
			CarParkName varchar(50),
			Location varchar(50),
			Address varchar(100),
			Postcode varchar(8),
			Notes varchar(300), 
			Telephone varchar(11),
			URL varchar(2048),	
			MinCostPence int,
			IsParkAndRide varchar(5),
			StayType varchar(20),
			PlanningPoint varchar(5),
			DateRecordLastUpdated datetime,
			WEUDate datetime,
			WEFDate datetime,
			OperatorCode varchar(100) 'CarParkOperator/OperatorCode',
			EntranceGeoCodeType varchar(10)  'AccessPoints[GeocodeType="Entrance"]/GeocodeType', 
			EntranceAccessPointNorthing varchar(7)  'AccessPoints[GeocodeType="Entrance"]/Northing', 
			EntranceAccessPointEasting varchar(7)  'AccessPoints[GeocodeType="Entrance"]/Easting', 
			MapGeoCodeType varchar(10)  'AccessPoints[GeocodeType="Map"]/GeocodeType', 
			MapAccessPointNorthing varchar(7)  'AccessPoints[GeocodeType="Map"]/Northing', 
			MapAccessPointEasting varchar(7)  'AccessPoints[GeocodeType="Map"]/Easting', 
			ExitGeoCodeType varchar(10)  'AccessPoints[GeocodeType="Exit"]/GeocodeType', 
			ExitAccessPointNorthing varchar(7)  'AccessPoints[GeocodeType="Exit"]/Northing', 
			ExitAccessPointEasting varchar(7)  'AccessPoints[GeocodeType="Exit"]/Easting', 
			TrafficNewsRegionName varchar(100) 'TrafficNewsRegion/RegionName',
			ParkAndRideLocation varchar(100) 'ParkAndRideScheme/Location',
			NPTGAreaCode varchar(5) 'NPTGAdminDistrict/AdminAreaCode'
			) X
			


			
		
COMMIT TRANSACTION T3

BEGIN TRANSACTION T4
		-- Car Park Type
		INSERT INTO CarParkingCarParkType (CarParkRef,TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID,  '/CarParkDataImport/CarPark', 2)
		WITH
		(
			CarParkRef varchar(50),
			TypeCode varchar(50) 'CarParkAdditionalData/CarParkType/TypeCode',
			TypeDescription varchar(100) 'CarParkAdditionalData/CarParkType/TypeDescription'
		) WHERE TypeCode IS NOT NULL

		-- Linked NaPTANs
		INSERT INTO CarParkingLinkedNaPTANs (
			CarParkRef,
			StopPointType,
			StopCode,
			InterchangeTime,
			InterchangeMode)
		SELECT
			X.CarParkRef,  
			X.StopPointType,
			X.StopCode,
			X.InterchangeTime,
			X.InterchangeMode
 		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark', 2)
		WITH (
			CarParkRef varchar(50),	
			StopPointType varchar(50) 'CarParkAdditionalData/LinkedNaPTANs/StopPointType',
			StopCode varchar(20) 'CarParkAdditionalData/LinkedNaPTANs/StopCode',
			InterchangeTime int 'CarParkAdditionalData/LinkedNaPTANs/InterchangeTime',
			InterchangeMode varchar(100) 'CarParkAdditionalData/LinkedNaPTANs/InterchangeMode'
			) X 
		WHERE (StopPointType IS NOT NULL OR StopCode IS NOT NULL 
			OR InterchangeTime IS NOT NULL OR InterChangeMode IS NOT NULL)

		
-- Car Park Facilties
		INSERT INTO CarParkingFacilities (FacilitiesTypeId, CarParkRef, [Name], Location)
		SELECT 
			X.FacilityTypeCode,
			X.CarParkRef,
			X.FacilityName,
			X.FacilityLocation
		 FROM OPENXML (@DocID, '/CarParkDataImport/CarPark', 2)
		WITH
		(
			FacilityTypeCode varchar(100) 'CarParkAdditionalData/Facilities/FacilityTypeCode',
			CarParkRef varchar(50),
			FacilityName varchar(100) 'CarParkAdditionalData/Facilities/FacilityName',
			FacilityLocation varchar(100) 'CarParkAdditionalData/Facilities/FacilityLocation'
			
		)X
		WHERE FacilityTypeCode IS NOT NULL
		
-- Car Park Attractions
		INSERT INTO CarParkingAttractions (TypeId, CarParkRef, [Name], WalkingDistance)
		SELECT 
			X.AttractionTypeCode,
			X.CarParkRef,
			X.AttractionName,
			X.WalkingDistance
		 FROM OPENXML (@DocID, '/CarParkDataImport/CarPark', 2)
		WITH	
		(
			AttractionTypeCode int 'CarParkAdditionalData/Attractions/AttractionTypeCode',
			CarParkRef varchar(50),
			AttractionName varchar(100) 'CarParkAdditionalData/Attractions/AttractionName',
			WalkingDistance varchar(6) 'CarParkAdditionalData/Attractions/WalkingDistance'
		)X
		WHERE AttractionTypeCode IS NOT NULL

-- Car Park Space Type
		INSERT INTO CarParkingSpaceType (TypeCode, Description)
		SELECT DISTINCT
			X.TypeCode,
			X.TypeDescription
		 FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace', 2)
		WITH	
		(
			TypeCode varchar(50),
			TypeDescription varchar(100)
		)X WHERE NOT EXISTS
			(SELECT TypeCode FROM CarParkingSpaceType
				WHERE CarParkingSpaceType.TypeCode = X.TypeCode)
		
 

-- Car Park Spaces
		INSERT INTO CarParkingCarParkSpace(SpaceTypeId, CarParkRef, NumberOfSpaces)
		SELECT DISTINCT
			X.TypeCode,
			X.CarParkRef,
			X.NumberOfSpaces
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace', 2)
		WITH
		(
			TypeCode varchar(50) ,
			CarParkRef varchar(50) '../../CarParkRef',
			NumberOfSpaces int 
		)X
		WHERE (X.TypeCode IS NOT NULL OR NumberOfSpaces IS NOT NULL)
		
-- Car Park Charge Type
		INSERT INTO CarParkingCarParkChargeType(ChargeType, ChargeDescription)
		SELECT DISTINCT
			X.ChargeType,
			X.ChargeDescription
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace/Charges', 2)
		WITH
		(
			ChargeType varchar(50),
			ChargeDescription varchar(100)
			
		)X	WHERE NOT EXISTS 
			(SELECT * FROM CarParkingCarParkChargeType
				WHERE CarParkingCarParkChargeType.ChargeType = X.ChargeType)
				
		--COMMIT TRANSACTION

COMMIT TRANSACTION T4


BEGIN TRANSACTION T5

-- Car Park Charges
		INSERT INTO CarParkingCarParkCharges (
			SpaceId, 
			CalendarId,
			ChargeTypeId,
			StartTime,
			EndTime,
			TimeRangeDays,
			TimeRangeMinutes,
			Comments,
			ChargeAmount,
			ChargeDayEndTime
		)
		SELECT 
			(SELECT top 1 Id FROM CarParkingCarParkSpace
				WHERE SpaceTypeId = X.TypeCode AND CarParkRef=X.CarParkRef) AS SpaceId,
			(SELECT top 1 Id FROM CarParkingCalendar
				WHERE CarParkingCalendar.Start = X.CalendarStartDate
					AND CarParkingCalendar.[End]= X.CalendarEndDate
					AND CarParkingCalendar.Days = X.Days
					AND CarParkingCalendar.PublicHols = X.PublicHolidays)  AS CalendarId,
			X.ChargeType,
			X.StartTime,
			X.EndTime,
			isNull(X.TimeRangeDays,-1),
			isNull(X.TimeRangeMinutes,-1),
			X.Comments,
			isNull(X.ChargeAmount,-1),
			X.ChargeDayEndTime
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace/Charges', 2)
		WITH
		(
			TypeCode varchar(50) '../TypeCode',
			CarParkRef varchar(50) '../../../CarParkRef',
			CalendarStartDate datetime 'Calendar/CalendarStartDate',
			CalendarEndDate datetime 'Calendar/CalendarEndDate',
			Days varchar(7) 'Calendar/Days',
			PublicHolidays varchar(8) 'Calendar/PublicHolidays',
			ChargeType varchar(50) ,
			StartTime varchar(8) ,
			EndTime varchar(8) ,
			TimeRangeDays int ,
			TimeRangeMinutes int ,
			Comments varchar(200) ,
			ChargeAmount int ,
			ChargeDayEndTime varchar(10) 
						
		)X	

-- Car Park Concessions
		INSERT INTO CarParkingCarParkConcessions(Code, Description, CarParkRef)
		SELECT DISTINCT
			X.ConcessionCode,
			X.ConcessionDescription,
			X.CarParkRef
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark', 2)
		WITH
		(
			ConcessionCode varchar(50) 'CarParkAdditionalData/Concessions/ConcessionCode',
			ConcessionDescription varchar(200) 'CarParkAdditionalData/Concessions/ConcessionDescription',
			CarParkRef varchar(50)
		)X WHERE ConcessionCode IS NOT NULL

-- Car Park Payment Type
		INSERT INTO CarParkingPaymentType(TypeCode,CarParkRef,TypeDescription)
		SELECT 
			X.TypeCode,
			X.CarParkRef,
			X.TypeDescription
		FROM OPENXML (@DocID, 'CarParkDataImport/CarPark', 2)
		WITH
		(
			TypeCode varchar(50) 'CarParkAdditionalData/PaymentType/TypeCode',
			CarParkRef varchar(50),
			TypeDescription varchar(50) 'CarParkAdditionalData/PaymentType/TypeDescription'
		)X WHERE TypeCode IS NOT NULL	

		
-- Car Park Payment Methods
		INSERT INTO CarParkingPaymentMethods(CarParkRef,Code, Description, ChangeAvailable)
		SELECT *
			FROM OPENXML (@DocID, '/CarParkDataImport/CarPark', 2)
		WITH
		(
			CarParkRef varchar(50),
			Code varchar(50) 'CarParkAdditionalData/PaymentMethods/Code',
			Description varchar(100) 'CarParkAdditionalData/PaymentMethods/Description',
			ChangeAvailable varchar(3) 'CarParkAdditionalData/PaymentMethods/ChangeAvailable'
		)X WHERE Code IS NOT NULL	
		
-- Car Park Opening Times
		INSERT INTO CarParkingOpeningTimes (
		    CarParkRef,
			CalendarId, 
			OpensAt,
			LastEntranceAt,
			ClosesAt,
			MaxStaysDays,
			MaxStayMinutes
		)
		SELECT 
			X.CarParkRef,
			(SELECT top 1 Id FROM CarParkingCalendar
				WHERE CarParkingCalendar.Start = X.CalendarStartDate
					AND CarParkingCalendar.[End] = X.CalendarEndDate
					AND CarParkingCalendar.Days = X.Days
					AND CarParkingCalendar.PublicHols = X.PublicHolidays)  AS CalendarId,
			X.OpensAt,
			X.LastEntranceAt,
			X.ClosesAt,
			X.MaxStayDays,
			X.MaxStayMinutes
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark', 2)
		WITH
		(
			CarParkRef varchar(50),
			CalendarStartDate datetime 'CarParkAdditionalData/OpeningTimes/Calendar/CalendarStartDate',
			CalendarEndDate datetime 'CarParkAdditionalData/OpeningTimes/Calendar/CalendarEndDate',
			Days varchar(7) 'CarParkAdditionalData/OpeningTimes/Calendar/Days',
			PublicHolidays varchar(8) 'CarParkAdditionalData/OpeningTimes/Calendar/PublicHolidays',
			OpensAt varchar(8) 'CarParkAdditionalData/OpeningTimes/OpensAt',
			LastEntranceAt varchar(8) 'CarParkAdditionalData/OpeningTimes/LastEntranceAt',
			ClosesAt varchar(8) 'CarParkAdditionalData/OpeningTimes/ClosesAt',
			MaxStayDays int 'CarParkAdditionalData/OpeningTimes/MaxStayDays',
			MaxStayMinutes int 'CarParkAdditionalData/OpeningTimes/MaxStayMinutes'
		)X
		
-- Car Park NPTG Locality
		INSERT INTO CarParkingNPTGLocality(CarParkRef,NationalGazeteerId, Easting, Northing)
		SELECT  
			X.CarParkRef,
			X.NationalGazeteerId,
			X.Easting,
			X.Northing
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark', 2)
		WITH
		(
			CarParkRef varchar(50),
			NationalGazeteerId varchar(100) 'CarParkAdditionalData/NPTGLocality/NationalGazeteerId',
			Easting varchar(7) 'CarParkAdditionalData/NPTGLocality/Easting',
			Northing varchar(7) 'CarParkAdditionalData/NPTGLocality/Northing'
		)X WHERE (NationalGazeteerId IS NOT NULL OR Easting IS NOT NULL OR Northing IS NOT NULL)



-- Car Park Space Type Availability
		INSERT INTO CarParkingSpaceAvailability (
			SpaceId,
			CalendarId,
			AvailabilityDayType,
			StartTime,
			EndTime,
			PercentageAvailability
		)
		SELECT
			(SELECT top 1 Id FROM CarParkingCarParkSpace 
				WHERE SpaceTypeId = X.TypeCode) AS SpaceId,
			(SELECT top 1 Id FROM CarParkingCalendar
				WHERE CarParkingCalendar.Start = X.CalendarStartDate
					AND CarParkingCalendar.[End] = X.CalendarEndDate
					AND CarParkingCalendar.Days = X.Days
					AND CarParkingCalendar.PublicHols = X.PublicHolidays)  AS CalendarId,
			X.AvailabilityDayType, 
			X.StartTime,
			X.EndTime,
			X.PercentageAvailability
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace/SpaceTypeAvailability', 2)
		WITH
		(
			TypeCode varchar(50) '../TypeCode',
			CalendarStartDate datetime 'Calendar/CalendarStartDate',
			CalendarEndDate datetime 'Calendar/CalendarEndDate',
			Days varchar(7) 'Calendar/Days',
			PublicHolidays varchar(8) 'Calendar/PublicHolidays',
			AvailabilityDayType varchar(50) ,
			StartTime varchar(8) ,
			EndTime varchar(8),
			PercentageAvailability int 			
		)X	
			

COMMIT TRANSACTION T5

BEGIN TRANSACTION T6

-- Car Parking Additional Data
	INSERT INTO CarParkingAdditionalData (
				CarParkingId,
				ClosingDate,
				ReopeningDate,
				MaximumHeight,
				MaximumWidth,
				PMSPA,
				EmergencyNumber,
				EmailAddressOfCarPark,
				CCTVAvailable,
				Staffed,
				Patrolled,
				VehicleRestrictions,
				LiftsAvailable,
				AdvancedReservationsAvailable,
				SeasonTicketsAvailable
		)
	   SELECT  
		X.CarParkRef,
		X.ClosingDate,
		X.ReOpeningDate,
		X.maxHeight,
		X.maxWidth,
		X.PMSPA,
		X.EmergencyNumber,
		X.CarParkEmail,
		X.CCTV,
		X.Staffed,
		X.Patrolled,
		X.VehicleRestrictions,
		X.LiftsAvailable,
		X.ReservationsAvailable,
		X.SeasonTicketsAvailable
	FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark/CarParkAdditionalData', 2)
		WITH (	
			CarParkRef varchar(50) '../CarParkRef',
			ClosingDate datetime,
			ReopeningDate datetime,
			maxHeight int ,
			maxWidth int ,
			PMSPA varchar(3) ,
			EmergencyNumber varchar(13) ,
			CarParkEmail varchar(100) ,
			CCTV varchar(3),
			Staffed varchar(3) ,
			Patrolled varchar(3) ,
			VehicleRestrictions varchar(150) ,
			LiftsAvailable varchar(3) ,
			ReservationsAvailable varchar(3) ,
			SeasonTicketsAvailable varchar(3) 
			
			
		)X WHERE (ClosingDate IS NOT NULL OR ReOpeningDate IS NOT NULL
				OR maxHeight IS NOT NULL OR maxWidth IS NOT NULL
				OR PMSPA IS NOT NULL OR EmergencyNumber IS NOT NULL
				OR CarParkEmail IS NOT NULL OR CCTV IS NOT NULL
				OR Staffed IS NOT NULL OR Patrolled IS NOT NULL
				OR VehicleRestrictions IS NOT NULL OR LiftsAvailable IS NOT NULL
				OR ReservationsAvailable IS NOT NULL OR SeasonTicketsAvailable IS NOT NULL)

		
		
		
			
COMMIT TRANSACTION T6


		-- release temp storage object
		EXEC sp_xml_removedocument @DocID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 951
SET @ScriptDesc = 'Updated column width for carpark notes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

