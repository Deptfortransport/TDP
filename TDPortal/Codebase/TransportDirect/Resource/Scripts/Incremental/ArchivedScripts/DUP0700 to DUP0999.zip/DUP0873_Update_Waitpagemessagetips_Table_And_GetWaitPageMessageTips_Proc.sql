-- ************************************************************
-- NAME 		: DUP0873_Update_Waitpagemessagetips_Table_And_GetWaitPageMessageTips_Proc.sql
-- DESCRIPTION 	: Partner customization for the Waitpagemessagetips table and GetWaitPageMessageTips Proc
-- AUTHOR		: apatel
-- ************************************************************
USE TransientPortal
GO

IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('WaitPageMessageTips')
						AND syscolumns.name = 'ThemeId')

ALTER TABLE WaitPageMessageTips ADD [ThemeId] INT  NOT NULL DEFAULT(1)
	
GO

ALTER PROCEDURE GetWaitPageMessageTips
	@ThemeId INT = 1
AS

IF NOT EXISTS (SELECT *
			 FROM WaitPageMessageTips 
			WHERE ThemeId = @ThemeId)
	SET @ThemeId = 1
			

SELECT
	WaitPageTipTextEn,
	WaitPageTipTextCy
FROM 
	WaitPageMessageTips
WHERE ThemeId = @ThemeId

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 873
SET @ScriptDesc = 'Partner customization for the Waitpagemessagetips table and GetWaitPageMessageTips Proc'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------