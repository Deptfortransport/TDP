-- ************************************************************
-- NAME 		: DUP0820_Tip_Of_The_Day_Procedure.sql
-- DESCRIPTION 	: Creates the procedure to allow tips of the day to be read
-- AUTHOR		: Steve Barker
-- ************************************************************
USE [TransientPortal]
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE 
	[id] = object_id(N'[dbo].[GetWaitPageMessageTips]') AND 
	OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GetWaitPageMessageTips]
GO

CREATE PROCEDURE GetWaitPageMessageTips AS

SELECT
	WaitPageTipTextEn,
	WaitPageTipTextCy
FROM 
	WaitPageMessageTips
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 820
SET @ScriptDesc = 'Creates the procedure to allow tips of the day to be read'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------