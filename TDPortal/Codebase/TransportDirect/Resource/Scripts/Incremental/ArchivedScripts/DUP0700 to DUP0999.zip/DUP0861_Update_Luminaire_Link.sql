-- ***********************************************
-- NAME 		: DUP0861_Update_Luminaire_Link.sql
-- DESCRIPTION 		: Updates the 'Directions to the Luminaire' URL to point to Web2
-- AUTHOR		: Dan Gath
-- Date 		: 28 March 2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [Content]
GO

update tblContent
Set [value-en] = '<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>',
[value-cy]='<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'
WHERE [value-en] like '%Directions to the Luminaire%'

GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 861
SET @ScriptDesc = 'Updates the ''Directions to the Luminaire'' URL to point to Web2'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------
