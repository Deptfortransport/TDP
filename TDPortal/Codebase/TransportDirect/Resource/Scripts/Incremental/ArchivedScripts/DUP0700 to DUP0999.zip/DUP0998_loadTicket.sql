-- ***********************************************
-- NAME 		: DUP0998_loadTicket.sql
-- DESCRIPTION 		: Script to add loadticket stored proc
-- AUTHOR		: James Chapman
-- DATE			: 26 June 2008 18:00:00
-- ************************************************

USE [TransientPortal]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'LoadTicket')
	BEGIN
		DROP  Procedure  LoadTicket
	END

GO

CREATE Procedure LoadTicket
	(
		@TicketTypeCode VarChar(10)
	)
AS

Select * From TicketTypeDescription Where TicketTypeCode =  @TicketTypeCode

Select * From ValidityCodes Where TicketTypeCode = @TicketTypeCode
 
Select * From ApplicableTocs Where TicketTypeCode = @TicketTypeCode

Select * From ExcludedTocs Where ApplicableTocs_Id in (Select ApplicableTocs_Id From ApplicableTocs Where TicketTypeCode = @TicketTypeCode)

Select * From IncludedTocs Where ApplicableTocs_Id in (Select ApplicableTocs_Id From ApplicableTocs Where TicketTypeCode = @TicketTypeCode)


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 998
SET @ScriptDesc = 'Script to add loadticket stored proc'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO



