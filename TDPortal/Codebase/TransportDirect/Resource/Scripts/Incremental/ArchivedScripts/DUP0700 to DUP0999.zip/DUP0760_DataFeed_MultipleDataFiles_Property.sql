-- ***********************************************
-- NAME 		: DUP0760_DataFeed_MultipleDataFiles_Property.sql
-- DESCRIPTION 		: Add property for datafeeds with multiplefilenames
-- AUTHOR		: mmodi
-- ************************************************
USE PermanentPortal
GO

IF not exists (select top 1 * from properties where pName = 'datagateway.zipprocessor.multiplefilesinfeedcheck')
BEGIN
	insert into properties values ('datagateway.zipprocessor.multiplefilesinfeedcheck', 'etd565', '', 'DataGateway', 0)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'etd565'
	where pname = 'datagateway.zipprocessor.multiplefilesinfeedcheck'
END

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 760
SET @ScriptDesc = 'Added Datafeed multiple filenames check property'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------