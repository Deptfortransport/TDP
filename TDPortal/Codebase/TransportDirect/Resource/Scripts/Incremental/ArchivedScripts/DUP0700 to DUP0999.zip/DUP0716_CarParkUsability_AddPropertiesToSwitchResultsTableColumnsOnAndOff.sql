-- ***********************************************
-- NAME 		: DUP0716_CarParkUsability_AddPropertiesToSwitchResultsTableColumnsOnAndOff.sql
-- DESCRIPTION 	: Add property table entries for the new columns on the
--				: Car Park results table
-- ************************************************
Use PermanentPortal
GO

if not exists (select top 1 * from properties where pName = 'FindCarParkResults.ShowIsSecure')
begin
	insert into properties values ('FindCarParkResults.ShowIsSecure', 'False', '<DEFAULT>', '<DEFAULT>', 0)
end

if not exists (select top 1 * from properties where pName = 'FindCarParkResults.ShowNumberOfSpaces')
begin
	insert into properties values ('FindCarParkResults.ShowNumberOfSpaces', 'False', '<DEFAULT>', '<DEFAULT>', 0)
end

if not exists (select top 1 * from properties where pName = 'FindCarParkResults.ShowDisabledSpaces')
begin
	insert into properties values ('FindCarParkResults.ShowDisabledSpaces', 'False', '<DEFAULT>', '<DEFAULT>', 0)
end
GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 716
SET @ScriptDesc = 'Add property table entries for new columns on Car Park results table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------