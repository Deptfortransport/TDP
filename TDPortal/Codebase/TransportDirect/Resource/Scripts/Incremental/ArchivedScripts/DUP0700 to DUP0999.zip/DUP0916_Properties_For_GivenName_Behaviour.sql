-- *************************************************************************************
-- NAME 		: DUP0916_Properties_For_GivenName_Behaviour.sql
-- DESCRIPTION 		: Adds properites to control GivenName tag inclusion in cjp requests
-- *************************************************************************************
USE [PermanentPortal]
GO

----------------------------------------------------------------
-- New values to control GivenName tag inclusion in cjp requests
----------------------------------------------------------------

DELETE FROM Properties WHERE pName = 'LocationService.FilterGivenNameTag';
GO
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID, THEMEID) 
 VALUES('LocationService.FilterGivenNameTag','True','LocationService','UserPortal',0,1);
GO
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID, THEMEID) 
 VALUES('LocationService.FilterGivenNameTag','True','TDRemotingHost','TDRemotingHost',0,1);
GO


DELETE FROM Properties WHERE pName = 'LocationService.GivenNameTagFilterValues';
GO
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID, THEMEID) 
 VALUES('LocationService.GivenNameTagFilterValues','Main Coach Stops|Main Rail / Coach|Main Rail Stations','LocationService','UserPortal',0,1);
GO
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID, THEMEID) 
 VALUES('LocationService.GivenNameTagFilterValues','Main Coach Stops|Main Rail / Coach|Main Rail Stations','TDRemotingHost','TDRemotingHost',0,1);
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 916
SET @ScriptDesc = 'Added new properites to control GivenName tag inclusion in cjp requests'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
