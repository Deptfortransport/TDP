-- ***********************************************
-- NAME 		: DUP0806_ContentTable_Langstring_Update.sql
-- DESCRIPTION 		: Bespoke inserts into the content database for langstring in web2
-- AUTHOR		: darshan sawe
-- Date 		: 13-March-2008
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE [Content]
GO


-----------------------------------------------------------
-- updating PropertyName HomeDefault.lblFindCarPark
-----------------------------------------------------------

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'HomeDefault.lblFindCarPark',
	'Find a<br />car park',
	'Darganfod <br/>maes parcio'


EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'CostPageTitle.labelCostPageTitle',	
	'Costs: Outward journey',
	'Costau: Siwrnai allan'

EXEC dbo.[AddtblContent]
	1,
	1,
	'langStrings',
	'DateControl.labelPlanningTip',
	'You can plan journeys for the current calendar month and the next two months.',
	'cy - You can plan journeys for the current calendar month and the next two months.'

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 806
SET @ScriptDesc = 'Bespoke inserts into the content database for langstring in web2'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------