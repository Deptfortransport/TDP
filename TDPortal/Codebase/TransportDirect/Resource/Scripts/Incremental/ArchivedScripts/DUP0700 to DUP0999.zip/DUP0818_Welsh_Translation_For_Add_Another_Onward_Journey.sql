-- ************************************************************
-- NAME 		: DUP0818_Welsh_Translation_For_Add_Another_Onward_Journey.sql
-- DESCRIPTION 	: Provides a Welsh translation for Add Another Onward Journey Button on ExtendedFullItinerarySummary.aspx
-- AUTHOR		: S Johal
-- ************************************************************
USE Content
GO

update tblContent set [Value-CY]='Ychwanegwch siwrnai allanol arall' where ContentId='73425'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 818
SET @ScriptDesc = 'Provides a Welsh translation for the OK Button on VisitPlannerResults.aspx'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------