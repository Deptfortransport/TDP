-- ***********************************************
-- NAME 		: DUP0864_Map_Legend_Properties_Update.sql
-- DESCRIPTION 		: Map Legend Link Properties Update
-- AUTHOR		: Amit Patel
-- DATE			: 30 Mar 2008 16:24:00
-- ************************************************

-----------------------------------------------------------------------
-- Properties 
-----------------------------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ThemeId INT
SET @ThemeId = 1



IF not exists (select top 1 * from properties where pName = 'Web.MapLegend.Url.10000' and ThemeId = @ThemeId)
BEGIN
	insert into properties values ('Web.MapLegend.Url.10000', '/Web2/OSLegend/StreetViewLegend.pdf', 'Web', 'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/OSLegend/StreetViewLegend.pdf'
	where pname = 'Web.MapLegend.Url.10000' and ThemeId = @ThemeId
END


IF not exists (select top 1 * from properties where pName = 'Web.MapLegend.Url.10000' and ThemeId = @ThemeId)
BEGIN
	insert into properties values ('Web.MapLegend.Url.1000000', '/Web2/OSLegend/MiniScaleLegend.pdf', 'Web', 'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/OSLegend/MiniScaleLegend.pdf'
	where pname = 'Web.MapLegend.Url.1000000' and ThemeId = @ThemeId
END

IF not exists (select top 1 * from properties where pName = 'Web.MapLegend.Url.10000' and ThemeId = @ThemeId)
BEGIN
	insert into properties values ('Web.MapLegend.Url.250000', '/Web2/OSLegend/250kRasterLegend.pdf', 'Web', 'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/OSLegend/250kRasterLegend.pdf'
	where pname = 'Web.MapLegend.Url.250000' and ThemeId = @ThemeId
END

IF not exists (select top 1 * from properties where pName = 'Web.MapLegend.Url.10000' and ThemeId = @ThemeId)
BEGIN
	insert into properties values ('Web.MapLegend.Url.50000', '/Web2/OSLegend/50kRasterLegend.pdf', 'Web', 'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = '/Web2/OSLegend/50kRasterLegend.pdf'
	where pname = 'Web.MapLegend.Url.50000' and ThemeId = @ThemeId
END




GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 864
SET @ScriptDesc = 'Map Legend Link Properties Update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO