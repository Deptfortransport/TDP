-- ***********************************************
-- NAME 		: DUP0832_VisitBritain_4_Content.sql
-- DESCRIPTION 		: Script to add specific content for a Theme - VisitBritain
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Mar 2008 18:00:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT
SET @ThemeId = 2

----------------------------------------------------------
-- Header text
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.headerHomepageLink.AlternateText', 'Visit Britain', 'Visit Britain'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.TDSmallBannerImage.AlternateText', 'Visit Britain', 'Visit Britain'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.defaultActionButton.AlternateText', 'Visit Britain', 'Visit Britain'


----------------------------------------------------------
-- Footer links
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FooterControl1.ContactUsLinkButton', 'Contact Transport Direct', 'cy Contact Transport Direct'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FooterControl1.AboutLinkButton', 'About Transport Direct', 'cy About Transport Direct'


----------------------------------------------------------
-- Contact us page
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FeedbackInitialPage.ContactUsLabel', 'Contact Transport Direct', 'cy Contact Transport Direct'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FeedbackInitialPage.labelTitle.Text', 'Send Transport Direct your feedback', 'cy Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.imageFeedback.AlternateText', 'Send Transport Direct your feedback', 'cy Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.imageFeedbackSkipLink.AlternateText', 'Skip to Send Transport Direct your feedback', 'cy Skip to Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.lblFeedback', 'Send Transport Direct <br /> your feedback', 'cy Send Transport Direct <br />your feedback'

----------------------------------------------------------
-- About us page
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 19, 'TitleText', '/Channels/TransportDirect/About/AboutUs', 'About Transport Direct', 'cy About Transport Direct'


----------------------------------------------------------
-- HomePage - Tips and Tools panel
----------------------------------------------------------

-- TODO


------------------------------------------------------------------------
-- Tips and tools Home page information panel
------------------------------------------------------------------------

-- TODO


---------------------------------------------------------------
-- Home Page - Right hand info panel
---------------------------------------------------------------

-- TODO


----------------------------------------------------------------
-- Sitemap
----------------------------------------------------------------

-- TODO



----------------------------------------------------------------
-- Ambiguity page
----------------------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT
SET @ThemeId = 2

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FindCarParkInput.labelNote.Ambiguous', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FindStationInput.labelNote.StationMode.NoValid', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'ValidateAndRun.SelectFromList', 'Select an option from each list below.', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'VisitPlannerInput.Instructional.Ambiguity', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

GO


----------------------------------------------------------------
-- Amend tab images
----------------------------------------------------------------


-- TODO

----------------------------------------------------------------
-- Powered by Transport Direct content
----------------------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT
SET @ThemeId = 2

EXEC AddtblContent
@ThemeId, 1, 'langstrings', 'PoweredByControl.HTMLContent',
'<div class="Column3PoweredBy">
<div class="Column3Header Column3HeaderPoweredBy">
<div class="txtsevenbbl">
Provided by
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</div>
</div>
<div class="Column3Content Column3ContentPoweredBy">
<table>
<tr>
<td>
<a href="http://www.transportdirect.info">
<img src="/Web2/App_Themes/TransportDirect/images/gifs/td_logo_4whbg.gif" alt="Provided by Transport Direct" />
</a>
</td>
</tr>
</table>
</div>
</div>',

'<div class="Column3PoweredBy">
<div class="Column3Header Column3HeaderPoweredBy">
<div class="txtsevenbbl">
Provided by
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</div>
</div>
<div class="Column3Content Column3ContentPoweredBy">
<table>
<tr>
<td>
<a href="http://www.transportdirect.info">
<img src="/Web2/App_Themes/TransportDirect/images/gifs/td_logo_4whbg.gif" alt="Provided by Transport Direct" />
</a>
</td>
</tr>
</table>
</div>
</div>'

EXEC AddtblContent
@ThemeId, 1, 'langstrings', 'PoweredByControl.HTMLContent.LogoOnly',
'<div class="PoweredByLogo">
<a href="http://www.transportdirect.info">
<img src="/Web2/App_Themes/TransportDirect/images/gifs/ProvidedBy1a.gif" alt="Provided by Transport Direct" />
</a>
</div>',

'<div class="PoweredByLogo">
<a href="http://www.transportdirect.info">
<img src="/Web2/App_Themes/TransportDirect/images/gifs/ProvidedBy1a.gif" alt="Provided by Transport Direct" />
</a>
</div>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 832
SET @ScriptDesc = 'Content added for theme VisitBritain'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO