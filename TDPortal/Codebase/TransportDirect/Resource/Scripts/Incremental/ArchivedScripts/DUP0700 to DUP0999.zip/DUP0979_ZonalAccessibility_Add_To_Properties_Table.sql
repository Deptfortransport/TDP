-- ***********************************************
-- NAME 		: DUP0979_ZonalAccessibility_Add_To_Properties_Table.sql
-- DESCRIPTION 		: Add Zonal Accessibility data to properties table
--			: 
-- AUTHOR		: Sanjeev Johal
-- ************************************************

Use PermanentPortal
go
--insert into properties table
IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.database')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.database', 'TransientPortalDB', ' ', 'DataGateway', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.feedname')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.feedname', 'ert444', ' ', 'DataGateway', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.Name')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.Name', 'zonalaccessibility', ' ', 'DataGateway', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.schemea')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.schemea', 'c:\Gateway\xml\ZonalAccessibility.xsd', ' ', 'DataGateway', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.storedprocedure')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.storedprocedure', 'dbo.ZonalAccessibilityImportTask', ' ', 'DataGateway', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.xmlnamespace')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.xmlnamespace', 'http://www.transportdirect.info/ZonalAccessibility', ' ', 'DataGateway', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.xmlnamespacexsi')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.xmlnamespacexsi', 'http://www.w3.org/2001/XMLSchema-instance', ' ', 'DataGateway', 0, 1)
END
go

IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'datagateway.sqlimport.zonalaccessibility.xmlschemalocation')
BEGIN
INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
VALUES ('datagateway.sqlimport.zonalaccessibility.xmlschemalocation', 'http://www.transportdirect.info/ZonalAccessibility.xsd', ' ', 'DataGateway', 0, 1)
END
go


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 979
SET @ScriptDesc = 'Add Zonal Accessibility data to properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------