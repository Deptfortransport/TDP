-- ************************************************************
-- NAME 	: DUP0757_DiscountCards_Table_PartnerSpecificChanges.sql
-- DESCRIPTION 	: Updated DiscountCards Table to add ThemeId column
-- ************************************************************
--

USE [PermanentPortal]
GO

--------------------------------------------------
-- 1. Add ThemeId column in DiscountCards Table
--------------------------------------------------

IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('DiscountCards')
						AND syscolumns.name = 'ThemeId')
BEGIN
	ALTER TABLE DiscountCards ADD [ThemeId] INT NOT NULL DEFAULT(1)
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
			WHERE CONSTRAINT_CATALOG = 'PermanentPortal'
			AND TABLE_NAME ='DiscountCards '
			AND CONSTRAINT_NAME = 'UK_DiscountCards1')		

BEGIN
	ALTER TABLE DiscountCards  DROP 
		CONSTRAINT [UK_DiscountCards1]

	ALTER TABLE [dbo].[DiscountCards] ADD 
		CONSTRAINT [UK_DiscountCards1] UNIQUE  NONCLUSTERED 
		(
			[Mode],
			[ItemValue],
			[ThemeId]
		)  ON [PRIMARY] 
END
GO

--------------------------------------------
-- 2. Alter GetDiscountCards procedure
--------------------------------------------


--Create procedure if not present

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetDiscountCards'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetDiscountCards] AS BEGIN SET NOCOUNT ON END')
	END
GO


ALTER PROCEDURE GetDiscountCards
(
	@ThemeName varchar(100)
)
AS
BEGIN

	DECLARE @ThemeId INT
	DECLARE @DefaultThemeId INT

	EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT

	IF @ThemeId IS NULL
		BEGIN
		RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
		END

	EXEC [Content].[dbo].[GetDefaultThemeId] @DefaultThemeId OUTPUT 
	
	SELECT [Id], ItemValue, Mode, MaxAdults, MaxChildren
		FROM DiscountCards
		WHERE NOT Mode = 'All'
		AND ThemeId = @ThemeId
	UNION ALL
	(	
	SELECT [Id], ItemValue, Mode, MaxAdults, MaxChildren
	FROM DiscountCards
	WHERE
		ItemValue + '|' + Mode IN
		(
		SELECT DISTINCT ItemValue + '|' + Mode
		FROM DiscountCards
		WHERE NOT Mode = 'All'
		AND ThemeId = @DefaultThemeId  
		AND ItemValue + '|' + Mode  NOT IN
		(
			SELECT DISTINCT ItemValue + '|' + Mode
			FROM DiscountCards
			WHERE NOT Mode = 'All'
			AND ThemeId = @ThemeId
		)
		
		)
	AND NOT Mode = 'All'
	AND ThemeId = @DefaultThemeId 
	
			
	)
			
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 757
SET @ScriptDesc = 'Updated DiscountCards Table to add ThemeId column'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
