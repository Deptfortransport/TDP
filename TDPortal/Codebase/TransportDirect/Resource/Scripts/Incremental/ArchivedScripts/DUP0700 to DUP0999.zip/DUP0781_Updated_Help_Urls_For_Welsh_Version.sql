-- ***********************************************
-- NAME 		: DUP0781_Updated_Help_Urls_For_Welsh_Version.sql
-- DESCRIPTION 	: Content table updated to update help urls for Welsh version
-- AUTHOR		: apatel
-- ************************************************


USE Content
GO

UPDATE 
	tblContent 
SET
	[value-cy] = [value-en]
WHERE
	propertyname LIKE '%help%url%' 
		AND 
	[value-en] LIKE '%aspx%'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 781
SET @ScriptDesc = 'Content table updated to update help urls for Welsh version'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------