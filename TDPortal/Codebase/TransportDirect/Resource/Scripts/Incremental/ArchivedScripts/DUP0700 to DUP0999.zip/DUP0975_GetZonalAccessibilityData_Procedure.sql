-- ************************************************************
-- NAME 	: DUP0975_GetZonalAccessibilityData_Procedure.sql
-- AUTHOR	: Sanjeev Johal
-- DESCRIPTION 	: GetZonalAccessibilityData Procedures
-- ************************************************************
--

USE [TransientPortal]
GO

---------------------------------------------------
-- 1. GetZonalAccessibilityData Procedure change
----------------------------------------------------


--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetZonalAccessibilityData'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetZonalAccessibilityData] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
ALTER PROCEDURE GetZonalAccessibilityData
AS
DECLARE @date SMALLDATETIME

SET @date = CONVERT(char(8), GetDate(), 112)

SELECT Naptan, ZonalAccessibilityLinks.ExternalLinkId FROM ZonalAccessibilityLinks
INNER JOIN ExternalLinks ON ZonalAccessibilityLinks.ExternalLinkId = ExternalLinks.[Id]
WHERE 
(
	(ExternalLinks.EndDate >= @date AND ExternalLinks.StartDate IS NULL)
OR 
	(ExternalLinks.StartDate IS NULL AND ExternalLinks.EndDate IS NULL) 
OR 
	(ExternalLinks.StartDate <= @date AND ExternalLinks.EndDate IS NULL)
OR
	(ExternalLinks.StartDate <= @date AND ExternalLinks.EndDate >= @date)
)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 975
SET @ScriptDesc = 'GetZonalAccessibilityData Procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO