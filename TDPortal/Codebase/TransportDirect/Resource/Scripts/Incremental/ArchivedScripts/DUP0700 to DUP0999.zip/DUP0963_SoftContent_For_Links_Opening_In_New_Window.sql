-- ***********************************************
-- NAME 		: DUP0963_SoftContent_For_Links_Opening_In_New_Window.sql
-- DESCRIPTION 	: Soft Content update for links opening in new window
-- AUTHOR		: Amit Patel
-- DATE			: 23 Jun 2008 10:38:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO




------------------------------------------------------------------------
-- Menu Links tooltip
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 1 -- for transport direct


EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'ExternalLinks.Tooltip',
'Click to view information in a new browser window',
'cy Click to view information in a new browser window'

GO

------------------------------------------------------------------------
-- Map legend tooltip
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 1 -- for transport direct


EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'JourneyMapControl.hyperLinkMapKey.AlternateText',
'Map legend opens in new window',
'cy Map legend opens in new window'

GO


------------------------------------------------------------------------
-- Home Page new Information place holder links
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 1 -- for transport direct


EXEC AddtblContent
@ThemeId, 15, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home',
'<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" title="Click to view information in a new browser window" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" title="Click to view information in a new browser window" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>',
'<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" title="Click to view information in a new browser window" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" title="Click to view information in a new browser window" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

GO


------------------------------------------------------------------------
-- Printer friendly button tooltip
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 1 -- for transport direct


EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrinterFriendlyButton.Tooltip',
'Click to view printer friendly page in a new browser window',
'cy Click to view printer friendly page in a new browser window'

GO

------------------------------------------------------------------------
-- Ticket Retailers handoff page continue button tooltip
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 1 -- for transport direct


EXEC AddtblContent
@ThemeId, 1, 'FaresAndTickets', 'TicketRetailersHandOff.ContinueButton.Tooltip',
'Click to view information in a new browser window',
'cy Click to view information in a new browser window'

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 963
SET @ScriptDesc = 'Soft Content update for links opening in new window'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
