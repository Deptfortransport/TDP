-- ***********************************************
-- NAME 		: DUP0956_Content_FindaStationInput_InformationText.sql
-- DESCRIPTION 	: Script to add input page information text for Find a station input page 
--              : (FindTrunkInput.aspx when in station mode)
-- AUTHOR		: Mitesh Modi
-- DATE			: 23 Jun 2008 14:00:00
-- ************************************************


USE [Content]
GO

DECLARE @GroupID INT
SET @GroupID = (SELECT [GroupId] FROM tblGroup WHERE [Name] = 'General')

EXEC AddtblContent
1, @GroupID, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrunkStationInput', 
'', ''  -- intentionally blank as no text is required to be displayed

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 956
SET @ScriptDesc = 'Find a station (Trunk) input page information text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO