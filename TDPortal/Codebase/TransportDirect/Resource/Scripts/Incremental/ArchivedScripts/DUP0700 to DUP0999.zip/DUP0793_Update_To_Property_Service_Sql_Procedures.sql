-- *************************************************************************************
-- NAME 		: DUP0793_Update_To_Property_Service_Sql_Procedures.sql
-- DESCRIPTION  	: Updated Property Service Sql Procedures
-- AUTHOR		: Mitesh Modi
-- DATE			: 09 Mar 2008 06:36:00
-- *************************************************************************************

USE [PermanentPortal]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


---------------------------------------------------------------------
-- Update to SelectApplicationPropertiesWithPartnerId Proc
---------------------------------------------------------------------
ALTER PROCEDURE SelectApplicationPropertiesWithPartnerId
(
	@AID char(50)
	
)	 
AS
BEGIN

	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE, ThemeId
	FROM PROPERTIES P
	WHERE P.AID = @AID
END
GO

---------------------------------------------------------------------
-- Update to SelectGlobalPropertiesWithPartnerId Proc
---------------------------------------------------------------------
ALTER PROCEDURE SelectGlobalPropertiesWithPartnerId

AS
BEGIN

	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE, ThemeId
	FROM PROPERTIES P
	WHERE P.AID = '<DEFAULT>'
	AND P.GID = '<DEFAULT>'

END
GO

---------------------------------------------------------------------
-- Update to SelectGroupPropertiesWithPartnerId Proc
---------------------------------------------------------------------
ALTER PROCEDURE SelectGroupPropertiesWithPartnerId
(
	@GID char(50)
)
AS
BEGIN
	SELECT (CAST(PartnerId AS varchar(10)) + '.' + PNAME) AS PNAME, PVALUE, ThemeId
	FROM PROPERTIES P
	WHERE P.GID = @GID

END
GO




SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 793
SET @ScriptDesc = 'Updated Property Service Sql Procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
