-- ***********************************************
-- NAME 		: DUP0860_Get_Latest_News_Stored_Proc.sql
-- DESCRIPTION 	: Stored procs to return latest news, seasonal notice board, and special notice board 
-- AUTHOR		: amit Patel
-- Date 		: 28	-March-2008
-- ************************************************

USE [PermanentPortal]
GO


--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetLatestNews'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetLatestNews] AS BEGIN SET NOCOUNT ON END')
	END
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetSeasonalNotice'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetSeasonalNotice] AS BEGIN SET NOCOUNT ON END')
	END
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetSpecialNotice'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetSpecialNotice] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------

ALTER PROCEDURE [dbo].GetLatestNews
	@Language VARCHAR(5)
AS
BEGIN
	DECLARE @Content VARCHAR(8000)
	
	
	IF LOWER(@Language) = 'cy-gb'
	BEGIN
		
		
		SELECT @content = COALESCE(@Content, '') + ValueCy FROM HomePageMessage where Display = 1 order by seqno
	END
	ELSE
	BEGIN
		SELECT @content = COALESCE(@Content, '') + ValueEn FROM HomePageMessage where Display = 1 order by seqno
	END
	
	SELECT  @Content 
	
END

GO

ALTER PROCEDURE [dbo].GetSeasonalNotice
	@Language VARCHAR(5)
AS
BEGIN
	DECLARE @Content VARCHAR(8000)
	
	
	IF LOWER(@Language) = 'cy-gb'
	BEGIN
		
		
		SELECT @content = COALESCE(@Content, '') + ValueCy FROM HomePageMessage where Description IN ('Header','Footer','Seasonal') order by seqno
	END
	ELSE
	BEGIN
		SELECT @content = COALESCE(@Content, '') + ValueEn FROM HomePageMessage where Description IN ('Header','Footer','Seasonal') order by seqno
	END
	
	SELECT @Content
	
END

GO

ALTER PROCEDURE [dbo].GetSpecialNotice
	@Language VARCHAR(5)
AS
BEGIN
	DECLARE @Content VARCHAR(8000)
	
	
	IF LOWER(@Language) = 'cy-gb'
	BEGIN
		
		
		SELECT @content = COALESCE(@Content, '') + ValueCy FROM HomePageMessage where Description ='Special Notice Page'
	END
	ELSE
	BEGIN
		SELECT @content = COALESCE(@Content, '') + ValueEn FROM HomePageMessage where Description ='Special Notice Page'
	END
	
	SELECT @Content
	
END

GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 860
SET @ScriptDesc = 'Stored procs to return latest news, seasonal notice board, and special notice board '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------