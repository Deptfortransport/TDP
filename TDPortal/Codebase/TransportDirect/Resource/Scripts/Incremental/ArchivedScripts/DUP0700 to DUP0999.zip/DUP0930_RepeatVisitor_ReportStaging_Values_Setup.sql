-- ***********************************************
-- NAME 		: DUP0930_RepeatVisitor_ReportStaging_Values_Setup.sql
-- DESCRIPTION 		: Script to add the audit values for the repeat visitor stored proc
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 May 2008 18:00:00
-- ************************************************

-- Add the audit setup values for the TransferRepeatVisitorEvents stored proc 
USE [ReportStagingDB]
GO

DECLARE @ReportStagingDataTypeId int
SET @ReportStagingDataTypeId = 1 -- Default to ensure we only add the new entry once

IF not exists (select top 1 * from ReportStagingDataType where RSDTName = 'TransferRepeatVisitorEvents')
BEGIN
	SET @ReportStagingDataTypeId = (SELECT Max(RSDTID) from ReportStagingDataType) + 1 
	
	insert into ReportStagingDataType values (@ReportStagingDataTypeId, 'TransferRepeatVisitorEvents')
END


IF not exists (select top 1 * from ReportStagingDataAudit where RSDTID = @ReportStagingDataTypeId)
BEGIN
	insert into ReportStagingDataAudit values (@ReportStagingDataTypeId, 1, '2008-01-01')
	insert into ReportStagingDataAudit values (@ReportStagingDataTypeId, 2, '2008-01-01')
	insert into ReportStagingDataAudit values (@ReportStagingDataTypeId, 3, '2008-01-01')
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 930
SET @ScriptDesc = 'Repeat Visitor - audit setup'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO