USE Content

UPDATE dbo.tblContent
[Value-EN] = 'Maximum Height (cms) : {0} &lt;br /&gt;Maximum Width : {1}';
[Value-Cy] = 'Uchder Mwyaf (cms) : {0} &lt;br /&gt;Lled Mwyaf : {1}'
WHERE (PropertyName = 'CarParkInformationControl.ParkingRestrictions')

UPDATE dbo.tblContent
[Value-EN] = 'Maximum Height (cms) : {0}
[Value-Cy] = 'Uchder Mwyaf (cms) : {0}
WHERE (PropertyName = 'CarParkInformationControl.ParkingRestrictions.Height')

UPDATE dbo.tblContent
[Value-EN] = 'Maximum Width (cms) : {0}
[Value-Cy] = 'Lled Mwyaf (cms) : {1}
WHERE (PropertyName = 'CarParkInformationControl.ParkingRestrictions.Width')