-- ***********************************************
-- NAME 		: DUP0931_RepeatVisitor_Reporting_Values_Setup.sql
-- DESCRIPTION 		: Script to add Repeat Visitor type values
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 May 2008 18:00:00
-- ************************************************

USE [Reporting]
GO


-- Repeat Visitor types
IF not exists (select top 1 * from RepeatVisitorType where RVTID = 1 and RVTCode = 'VisitorUnknown')
BEGIN
	insert into RepeatVisitorType values ('1', 'VisitorUnknown', 'Unknown visitor')
END

IF not exists (select top 1 * from RepeatVisitorType where RVTID = 2 and RVTCode = 'VisitorNew')
BEGIN
	insert into RepeatVisitorType values ('2', 'VisitorNew', 'New visitor')
END

IF not exists (select top 1 * from RepeatVisitorType where RVTID = 3 and RVTCode = 'VisitorRepeat')
BEGIN
	insert into RepeatVisitorType values ('3', 'VisitorRepeat', 'Repeat visitor')
END

IF not exists (select top 1 * from RepeatVisitorType where RVTID = 4 and RVTCode = 'VisitorRobot')
BEGIN
	insert into RepeatVisitorType values ('4', 'VisitorRobot', 'Robot visitor')
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 931
SET @ScriptDesc = 'Repeat Visitor - type values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO