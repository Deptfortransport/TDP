-- ***********************************************
-- NAME 		: DUP0954_Content_Update_for_DepartureBoard_Visibility_Changes.sql
-- DESCRIPTION 		: Script to add URLs and Text for Departure board visibility changes
-- AUTHOR		: Phil Scott
-- DATE			: 18 Jun 2008 15:00:00
-- ************************************************

USE [Content]
GO


EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsTableControl.HeaderItemText10','Map','Map'


EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.ArrivalBoardButton.Text','Click to view arrival board in a new browser window','Bwrdd'


EXEC AddtblContent 1,1,'LangStrings','ArrivalsBoardHyperlink.labelArrivalsBoardNavigation','Click to view arrival board in a new browser window','Bwrdd'



EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.DepartureBoardButton.Text','Click to view departure board in a new browser window','Bwrdd ymadael'


EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.imageDepartureBoardUrl',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/Departures2.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/Departures2.gif'



USE [PermanentPortal]
GO

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pname like 'locationinformation.arrivalboardurl')
  BEGIN
    INSERT INTO [dbo].[properties] (pName, pValue, AID, Gid,PartnerId,ThemeId)
    VALUES ('locationinformation.arrivalboardurl','http://www.livedepartureboards.co.uk/ldb/sumarr.aspx?T={0}','Web','UserPortal',0,1)
  END
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 954
SET @ScriptDesc = 'Content_Update_for_DepartureBoard_Visibility_Changes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO