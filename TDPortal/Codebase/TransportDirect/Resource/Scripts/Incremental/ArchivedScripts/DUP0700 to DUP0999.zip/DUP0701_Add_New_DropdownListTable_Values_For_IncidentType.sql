-- *************************************************************************************
-- NAME 		: DUP0701_Add_New_DropdownListTable_Values_For_IncidentType.sql
-- DESCRIPTION 		: Adds the NewsIncidentTypeDrop data set
-- *************************************************************************************


USE PermanentPortal
GO

----------------------------------------------------------------
-- New values for DropDownList Table
-- Creat the items for DataSet NewsIncidentTypeDrop 
----------------------------------------------------------------
DELETE FROM DropDownLists WHERE DataSet = 'NewsIncidentTypeDrop'
GO

INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('NewsIncidentTypeDrop', 'All', '0', 1, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('NewsIncidentTypeDrop', 'Unplanned', '1', 0, 2, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('NewsIncidentTypeDrop', 'Planned', '2', 0, 3, 0)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 701
SET @ScriptDesc = 'Added the Travel News Incident Type data set'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
