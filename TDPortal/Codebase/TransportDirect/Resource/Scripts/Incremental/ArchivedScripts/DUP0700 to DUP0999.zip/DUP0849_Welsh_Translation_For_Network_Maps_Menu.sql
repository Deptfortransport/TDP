-- ************************************************************
-- NAME 		: DUP0849_Welsh_Translation_For_Network_Maps_Menu.sql
-- DESCRIPTION 	: Provides Welsh Translations for Network Maps Menu
-- AUTHOR		: S Johal
-- ************************************************************
USE TransientPortal
GO

update Resource set Text ='Rheilffordd' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'NetworkMaps.Train')
update Resource set Text ='Coets' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'NetworkMaps.Coach')
update Resource set Text ='Tr�n Tanddaearol/Metro' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'NetworkMaps.UndergroundMetro')
update Resource set Text ='Ffer�au a Gwasanaethau Afon' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'NetworkMaps.Ferries')
update Resource set Text ='Seiclo' where ResourceId=(select ResourceNameID from [Resourcename] where [ResourceName] = 'NetworkMaps.Cycling')
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 849
SET @ScriptDesc = 'Provides Welsh Translations for Network Maps Menu'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------