-- ***********************************************
-- NAME 		: DUP0921_Update_Retailer_Name.sql
-- DESCRIPTION 		: Script to update the name of retailer 'one' to 'National Express East Anglia'
-- AUTHOR		: Dan Gath
-- DATE			: 06 May 2008
-- ************************************************

USE [PermanentPortal]
GO

update Retailers set [Name]='National Express East Anglia' where [Name]='one';
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 921
SET @ScriptDesc = 'Script to update the name of retailer ''one'' to ''National Express East Anglia'''

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO