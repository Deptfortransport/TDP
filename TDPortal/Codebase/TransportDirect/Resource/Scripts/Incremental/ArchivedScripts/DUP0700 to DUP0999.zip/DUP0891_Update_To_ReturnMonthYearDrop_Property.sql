-- ***********************************************
-- NAME 		: DUP0891_Update_To_ReturnMonthYearDrop_Property.sql
-- DESCRIPTION 		: Update to ReturnMonthYearDrop query property
-- AUTHOR		: Amit Patel
-- DATE			: 10 Apr 2008
-- ************************************************

USE [PermanentPortal]
GO

-- TransportDirect.UserPortal.DataServices.ReturnMonthYearDrop.query

IF EXISTS ( SELECT * FROM [dbo].[properties] WHERE pName = 'TransportDirect.UserPortal.DataServices.ReturnMonthYearDrop.query' AND PartnerId = 0)
BEGIN
	UPDATE [dbo].[properties]
	SET pValue = 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''ReturnMonthYearDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder'
	WHERE PName = 'TransportDirect.UserPortal.DataServices.ReturnMonthYearDrop.query'
	AND PartnerId = 0

END
ELSE
BEGIN
	INSERT INTO [dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
	VALUES ('TransportDirect.UserPortal.DataServices.ReturnMonthYearDrop.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''ReturnMonthYearDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0, 1)
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 891
SET @ScriptDesc = 'Update to ReturnMonthYearDrop query property'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO