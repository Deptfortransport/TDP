-- ***********************************************
-- NAME 		: DUP0719_ImportantPlaceLocationRelationship_Table.sql
-- DESCRIPTION 		: sql to setup the car location (ImportantPlaceLocationRelationship) table for use in City to City
--			: and add to Change notification table
-- AUTHOR		: Dan Gath
-- ************************************************

USE [PermanentPortal]
GO
-------------------------------------------------------------------------
-- CREATE TABLE
-------------------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportantPlaceLocationRelationship]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ImportantPlaceLocationRelationship]
GO

CREATE TABLE [dbo].[ImportantPlaceLocationRelationship] (
	[TDNPGID] [int] NOT NULL ,
	[Mode] [varchar] (10) NOT NULL ,
	[OSGREasting] [int] NOT NULL ,
	[OSGRNorthing] [int] NOT NULL ,
	[StartTime] [int] NOT NULL ,
	[EndTime] [int] NOT NULL ,
	[DaysValid] [varchar] (7) NOT NULL,
	[Comments] [varchar] (100) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ImportantPlaceLocationRelationship] ADD 
	CONSTRAINT [PK_ImportantPlaceLocationRelationship] PRIMARY KEY  CLUSTERED 
	(
		[TDNPGID],
		[Mode],
		[OSGREasting],
		[OSGRNorthing],
		[StartTime],
		[EndTime]
	)  ON [PRIMARY] 
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 719
SET @ScriptDesc = 'Create ImportantPlaceLocationRelationship table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------