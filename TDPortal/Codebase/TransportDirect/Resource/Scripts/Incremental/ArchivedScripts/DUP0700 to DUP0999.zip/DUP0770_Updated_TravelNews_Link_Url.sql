-- *************************************************************************************
-- NAME 		: DUP0770_Updated_TravelNews_Link_Url.sql
-- DESCRIPTION  : Travel News Menu link Changed
-- AUTHOR		: Amit Patel
-- *************************************************************************************
USE [TransientPortal]
GO

-- Updating provide feeback link url

EXEC UpdateSuggestionLinkURL
	 'LiveTravel/TravelNews', 
	 'LiveTravel/TravelNews.aspx', 
	 'Live Travel News Page', 
	 1
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 770
SET @ScriptDesc = 'Travel News Menu link Changed'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
