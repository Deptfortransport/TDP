-- ***********************************************
-- NAME 		: DUP0918_SessionTimeout_Errors.sql
-- DESCRIPTION 		: Script to add Session timeout error messages
-- AUTHOR		: Mitesh Modi
-- DATE			: 24 Apr 2008 18:00:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'InputSessionError.TimeoutSorry'
, 'Sorry, your session has expired.'
, 'Sorry, your session has expired.'

EXEC AddtblContent
1, 1, 'langStrings', 'InputSessionError.TimeoutExpires'
, 'Your time (session) on Transport Direct expires after 20 minutes of inactivity. The session may also expire following a system error.'
, 'Your time (session) on Transport Direct expires after 20 minutes of inactivity. The session may also expire following a system error.'



EXEC AddtblContent
1, 1, 'langStrings', 'TimeOut.GetInstructionPrefix.Redirect'
, 'You will be redirected to the homepage after {0} seconds, alternatively '
, 'cy You will be redirected to the homepage after {0} seconds, alternatively '

EXEC AddtblContent
1, 1, 'langStrings', 'TimeOut.GetInstructionSuffix.Redirect'
, '.'
, '.'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 918
SET @ScriptDesc = 'Session timeout error message'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO