-- ***********************************************
-- NAME 		: DUP0741_Added_Menu_Links_For_Plan_A_Journey_Pages.sql
-- DESCRIPTION 	: Menu links for Plan a Journey pages
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

-------------------------------------------------------------------------
-- Context for Login Register Page Menu
-------------------------------------------------------------------------

EXEC AddContext 'HomePageMenuLoginRegister', 'Links for expandable menu on the Login And Register pages.'
GO


EXEC AddInternalSuggestionLink 
	NULL,
   'Plan a journey', 
   'PlanAJourney', 
   'Plan a journey', 
   'Cynlluniwch siwrnai', 
   'Plan a journey', 
   2000, 
   1, 
   'HomePageMenuPlanAJourney', 
   'Links for expandable menu on the Plan a Journey pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/JourneyPlannerInput.aspx', 
	'Door to door journey planner', 
	'DoorToDoor', 
	'Door-to-door journey planner', 
	'Cynlluniwr siwrnai o ddrws-i-ddrws', 
	'Plan a journey', 
	2010,
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindTrainInput.aspx', 
	'Find a train', 
	'FindATrain', 
	'Find a train', 
	'Canfyddwch dr�n', 
	'Plan a journey', 
	2020, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO
	
EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindFlightInput.aspx', 
	'Find a flight', 
	'FindAUKFlight', 
	'Find a flight', 
	'Canfyddwch ehediad', 
	'Plan a journey', 
	2030, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindCarInput.aspx', 
	'Find A Car Page', 
	'FindCarInput', 
	'Find a car route', 
	'Canfyddwch lwybr car', 
	'Plan a journey', 
	2040, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO


EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindCoachInput.aspx', 
	'Find a coach', 
	'FindACoach', 
	'Find a coach', 
	'Canfyddwch fws moethus', 
	'Plan a journey', 
	2050, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindTrunkInput.aspx', 
	'Compare city-to-city search', 
	'CompareCityToCity', 
	'Compare city-to-city journeys', 
	'Cymharu siwrneion dinas-i-ddinas', 
	'Plan a journey', 
	2060, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/VisitPlannerInput.aspx', 
	'Day trip planner', 
	'DayTripPlanner', 
	'Day trip planner', 
	'Cynllunydd teithiau dydd', 
	'Plan a journey', 
	2070, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/ParkAndRideInput.aspx', 
	'Park and Ride Input Page', 
	'ParkAndRideInput', 
	'Plan to park and ride', 
	'Cynlluniwch i barcio a theithio', 
	'Plan a journey', 
	2080, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindBusInput.aspx', 
	'Find a Bus Input Page', 
	'FindBusInput', 
	'Find a bus', 
	'Canfyddwch fws', 
	'Plan a journey', 
	2090, 
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'

GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindCarParkInput.aspx?DriveFromTo=true', 
	'link to find nearest carpark with drivefromto', 
	'FindNearestCarParkDriveTo', 
	'Drive to a car park', 
	'cy-Drive to a car park', 
	'Plan a journey', 
	2100,
	0, 
	'HomePageMenuPlanAJourney', 
	'Links for expandable menu on the Plan a Journey pages.'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 741
SET @ScriptDesc = 'Menu links for Plan a Journey pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------