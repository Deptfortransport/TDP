-- ***********************************************
-- NAME 		: DUP0705_CarParkUsability_AddPlanToACarParkLink.sql
-- DESCRIPTION 	: Add the left hand menu link Plan to a car park to the =
--				: FindCarInput context
--
-- ************************************************

Use TransientPortal
GO

exec AddInternalSuggestionLink 
'JourneyPlanning/FindCarParkInput.aspx?DriveFromTo=true',
				'link to plan to nearest carpark with drivefromto',
				'FindNearestCarParkPlanTo',
				'Plan to a car park',
				'cy-Plan to a car park',
				'General',
				93,
				1,
				'FindCarInput',
				''
GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 715
SET @ScriptDesc = 'Add left hand menu link Plan to a car park'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------