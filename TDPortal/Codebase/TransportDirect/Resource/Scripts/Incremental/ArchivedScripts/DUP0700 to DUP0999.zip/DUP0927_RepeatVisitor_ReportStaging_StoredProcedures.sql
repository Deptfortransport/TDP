-- ***********************************************
-- NAME 		: DUP0927_RepeatVisitor_ReportStaging_StoredProcedures.sql
-- DESCRIPTION 		: Script to add stored procedures to create Repeat Visitor events
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 May 2008 18:00:00
-- ************************************************


-- ****IMPORTANT****
-- If running this script in the dev environment, please remove the value "ReportServer." 
-- where it occurs, (4 instances) in this script

USE [ReportStagingDB]
GO

-- Delete existing procedures, done for completeness
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddRepeatVisitorEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AddRepeatVisitorEvent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferRepeatVisitorEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[TransferRepeatVisitorEvents]
GO



-- ADD NEW STORED PROCEDURES

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-----------------------------------------------------------------------------------------------
-- AddRepeatVisitorEvent
-----------------------------------------------------------------------------------------------
CREATE PROCEDURE AddRepeatVisitorEvent 
(
@RepeatVistorType varchar(20), 
@LastVisited datetime, 
@SessionIdOld varchar(50), 
@SessionIdNew varchar(50),
@DomainName varchar(100),
@UserAgent varchar(200),
@ThemeId int,
@TimeLogged datetime
)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into RepeatVisitorEvent Table'

    Insert into RepeatVisitorEvent (RepeatVistorType, LastVisited, SessionIdOld, SessionIdNew, DomainName, UserAgent, ThemeId, TimeLogged)
    Values (@RepeatVistorType, @LastVisited, @SessionIdOld, @SessionIdNew, @DomainName, @UserAgent, @ThemeId, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



-- ---------------------------------------------------------------------------------------------




SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-----------------------------------------------------------------------------------------------
-- TransferRepeatVisitorEvents
-----------------------------------------------------------------------------------------------

CREATE PROCEDURE dbo.TransferRepeatVisitorEvents
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

DELETE FROM ReportServer.Reporting.dbo.RepeatVisitorEvents
WHERE CONVERT(varchar(10), RVEDate, 121) = @Date

INSERT INTO ReportServer.Reporting.dbo.RepeatVisitorEvents
(
	RVEDate,
	RVEHour,
	RVEHourQuarter,
	RVEWeekDay,
	RVERVTID,
	RVEPartnerID,
	RVECount
)
SELECT 
	CAST(CONVERT(varchar(10), RVE.TimeLogged, 121) AS datetime) AS RVEDate,
	DATEPART(hour, RVE.TimeLogged) AS RVEHour,
	CAST(DATEPART(minute, RVE.TimeLogged) / 15 AS smallint) AS RVEHourQuarter,
	DATEPART(weekday, RVE.TimeLogged) AS RVEWeekDay,
	RVT.RVTID AS RVERVTID,
	P.PartnerId,
	COUNT(*) AS RVECount
FROM RepeatVisitorEvent RVE
LEFT OUTER JOIN ReportServer.Reporting.dbo.RepeatVisitorType RVT 
	ON RVE.RepeatVistorType = RVT.RVTCode
INNER JOIN ReportServer.Reporting.dbo.themepartner P
        ON RVE.ThemeId = P.ThemeId
WHERE CONVERT(varchar(10), RVE.TimeLogged, 121) = @Date
GROUP BY
	CAST(CONVERT(varchar(10), RVE.TimeLogged, 121) AS datetime),
	DATEPART(hour, RVE.TimeLogged),
	CAST(DATEPART(minute, RVE.TimeLogged) / 15 AS smallint),
	DATEPART(weekday, RVE.TimeLogged),
	RVT.RVTID,
        P.PartnerId

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 927
SET @ScriptDesc = 'Repeat Visitor - Report Staging stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO