-- ***********************************************
-- NAME 		: DUP0890_LatestNews_And_SpecialNotice_Changes.sql
-- DESCRIPTION 		: This script updates the Latest news mechanism used for Del 10.
-- AUTHOR		: Mitesh Modi
-- Date 		: 07 April 2008
-- ************************************************

-------------------------------------------
-- Remove redundant stored procedures
-------------------------------------------
USE [PermanentPortal]
GO

IF EXISTS (SELECT 1 FROM sysobjects 
                WHERE [Name] = N'GetLatestNews'
                  AND xtype = 'P') 
	BEGIN
		DROP PROCEDURE GetLatestNews
	END
GO

IF EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetSeasonalNotice'
                  AND xtype = 'P') 
	BEGIN
		DROP PROCEDURE GetSeasonalNotice
	END
GO

IF EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetSpecialNotice'
                  AND xtype = 'P') 
	BEGIN
		DROP PROCEDURE GetSpecialNotice
	END
GO



USE [TransientPortal]
GO

IF EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetCmsEntries'
                  AND xtype = 'P') 
	BEGIN
		DROP PROCEDURE GetCmsEntries
	END
GO

-------------------------------------------
-- Remove redundant items from HomePageMessage
-------------------------------------------
USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [HomePageMessage] WHERE [description] like '%Special Notice Page%')
	BEGIN
		DELETE FROM [HomePageMessage]
		WHERE [description] like '%Special Notice Page%'
	END

GO

-------------------------------------------
-- Drop CmsTextEntries table, no longer needed
-------------------------------------------
USE [TransientPortal]
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[CmsTextEntries]') 
		and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [dbo].[CmsTextEntries]
	END
GO


-------------------------------------------
-- Create new table for the special content, to hold latest news and special notice
-------------------------------------------
USE [TransientPortal]
GO

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[SpecialContent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[SpecialContent] (
		[Posting] [varchar] (100) NOT NULL ,
		[Placeholder] [varchar] (100) NOT NULL ,
		[Culture] [varchar] (10) NOT NULL ,
		[Text] [text] NULL 
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF NOT EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS pk 
               WHERE TABLE_NAME = 'SpecialContent' 
                 AND CONSTRAINT_TYPE = 'PRIMARY KEY') 
BEGIN
	ALTER TABLE [dbo].[SpecialContent] WITH NOCHECK ADD 
	CONSTRAINT [PK_SpecialContent] PRIMARY KEY  CLUSTERED 
	(
		[Posting],
		[Placeholder],
		[Culture]
	)  ON [PRIMARY] 
END
GO


-------------------------------------------------------------------------
-- Add data notification properties
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

UPDATE 	[PROPERTIES]
SET 	pValue = 'Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LatestNewsService,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare,ZonalServiceCatalogue'
WHERE	(pName = 'DataServices.DataNotification.Groups') AND 
	(AID = '<DEFAULT>')AND
	(GID = '<DEFAULT>')


UPDATE 	[PROPERTIES]
SET 	pValue = 'Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LatestNewsService,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare, PartnerCatalogue,ZonalServiceCatalogue'
WHERE	(pName = 'DataServices.DataNotification.Groups') AND 
	(AID = 'EnhancedExposedServices')AND
	(GID = 'UserPortal')


IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    ('DataServices.DataNotification.LatestNewsService.Database',
     'DataServices.DataNotification.LatestNewsService.Tables'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    ('DataServices.DataNotification.LatestNewsService.Database',
     'DataServices.DataNotification.LatestNewsService.Tables')
  END

INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('DataServices.DataNotification.LatestNewsService.Database','TransientPortalDB','<DEFAULT>','<DEFAULT>','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('DataServices.DataNotification.LatestNewsService.Tables','SpecialContent','<DEFAULT>','<DEFAULT>','0')


GO

-------------------------------------------------------------------------
-- Add to ChangeNotification table
-------------------------------------------------------------------------
USE [TransientPortal]
GO


IF EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'SpecialContent')
	BEGIN
		UPDATE ChangeNotification 
		SET [version] = 0
		WHERE [Table] = 'SpecialContent'
	END
ELSE
	BEGIN
		INSERT INTO [ChangeNotification] ([version], [Table])
		VALUES (0, 'SpecialContent')
	END

GO


-------------------------------------------------------------------------
-- Correct the special notice board URL to use the Del 10 web2 location
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [HomePageMessage] 
		WHERE [Description] = 'Special Notice Board' 
		AND [ValueEN] LIKE '%/transportdirect/en/%')
	BEGIN
		UPDATE [HomePageMessage]
		SET 
		[ValueEN] = '<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/Web2/specialnoticeboard.aspx">Special Notice Board</a></td></tr>',
		[ValueCY] = '<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/Web2/specialnoticeboard.aspx">Special Notice Board</a></td></tr>',
		[ValueFR] = '<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/Web2/specialnoticeboard.aspx">Special Notice Board</a></td></tr>'
		WHERE [Description] = 'Special Notice Board' 
	END

GO

-------------------------------------------
-- Update storedprocedure which moves latest news from HomePageMessage to SpecialContent
-------------------------------------------
USE [PermanentPortal]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


ALTER   PROCEDURE usp_SetHomePageMessage AS


declare @messageEN VARCHAR(8000)
declare @messageCY VARCHAR(8000)
declare @messageFR VARCHAR(8000)
declare @loopcounter int 

-- check if any new items need to be displayed (and raise the reqd changed flag)
-- add new messages
update dbo.HomePageMessage 
	set Display = 1, Changed = 1 
	where DisplayFrom <= getdate() and 	-- check display from has been passed 
		DisplayUntil >= getdate() and 	-- check display until has not exceeded
		Display = 0			-- check is not already being displayed

-- remove old messages
update dbo.HomePageMessage 
	set Display = 0, Changed = 1 
	where DisplayUntil <= getdate() and	-- check that display until has been passed
		Display = 1			-- check that item is already being displayed

-- ok lets see if any changed flags have raised....

if (select count(*) from dbo.HomePageMessage where Changed = 1) > 0
begin 

	-- print 'Changed item detected'

	-- Begin CR Del 8 change
	-- now need to establish if any items except header and footer are set to display
	
	if (SELECT count(*) FROM dbo.HomePageMessage WHERE Display = 1 AND Description NOT IN ('Header','Footer')) >0
		begin
			UPDATE dbo.HomePageMessage
				SET Display =1, Changed = 1, DisplayFrom = NULL, DisplayUntil = NULL
				WHERE Description IN ('Header','Footer')
		end
	else
		begin
			
			UPDATE dbo.HomePageMessage
				SET Display = 0, Changed = 1, DisplayFrom = NULL, DisplayUntil = NULL
				WHERE Description IN ('Header','Footer')
		end

	-- end CR Del 8 Change

	-- ok lets build the message string up

	set @messageEN = '' 
	set @messageCY = ''
	set @messageFR = ''
	set @loopcounter = 0

	while @loopcounter <= (select max(seqno) from dbo.HomePageMessage)
	Begin
		
		-- get English message text
		select @messageEN = @messageEN + valueEN from dbo.HomePageMessage  where display = 1 and seqno = @loopcounter 
		-- get Welsh message text
		select @messageCY = @messageCY + valueCY from dbo.HomePageMessage  where display = 1 and seqno = @loopcounter 
		-- get French message text
		select @messageFR = @messageFR + valueFR from dbo.HomePageMessage  where display = 1 and seqno = @loopcounter 
		
		select @loopcounter = @loopcounter + 1 

		-- check message length has not exceed maximum permitted
		if len(@messageEN) >= 7300
		Begin	
			raiserror ('Message Exceeded Maximum Length (English)', 16,1) with LOG
			Return 1
		End
		
		if len(@messageCY) >= 7300
		Begin	
			raiserror ('Message Exceeded Maximum Length (Welsh)', 16,1) with LOG
			Return 1
		End

		if len(@messageFR) >= 7300
		Begin	
			raiserror ('Message Exceeded Maximum Length (French)', 16,1) with LOG
			Return 1
		End

	End
	
	-- we need to write the message to the CMS entries table
	-- Print @message

	-- EN 'Home' postings on transportdirect/en channel 
	IF EXISTS (select * from [TransientPortal].[dbo].[SpecialContent] where Culture ='en-GB' and Posting ='LatestNews' and PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
  		BEGIN
			Update [TransientPortal].[dbo].[SpecialContent]	
			set Text = @messageEN
			where (Culture ='en-GB' and
				Posting ='LatestNews' and
				PlaceHolder ='TDInformationHtmlPlaceholderDefinition')
		END
	ELSE
		BEGIN
			INSERT INTO [TransientPortal].[dbo].[SpecialContent] 
			VALUES ('LatestNews', 'TDInformationHtmlPlaceholderDefinition', 'en-GB', @messageEN)
		END
		


	-- CY 'Home' postings on transportdirect/en channel 
	IF EXISTS (select * from [TransientPortal].[dbo].[SpecialContent] where Culture ='cy-GB' and Posting ='LatestNews' and PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
		BEGIN			
			Update [TransientPortal].[dbo].[SpecialContent]	
			set Text = @messageCY
			where (Culture ='cy-GB' and
				Posting ='LatestNews' and
				PlaceHolder ='TDInformationHtmlPlaceholderDefinition')
		END
	ELSE
		BEGIN
			INSERT INTO [TransientPortal].[dbo].[SpecialContent]
			VALUES ('LatestNews', 'TDInformationHtmlPlaceholderDefinition', 'cy-GB', @messageCY)
		END


	-- built messages up now lets remove the changed flags
	update dbo.HomePageMessage 
		set Changed = 0


	-- update change notification to tell webserver to reload data
	Update  [TransientPortal].[dbo].[ChangeNotification]
	set [Version] = Version + 1
	where [Table] = 'SpecialContent'
End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




--------------------------------------------
-- Create stored procedure to get the speical content
-------------------------------------------
USE [TransientPortal]
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetSpecialContent'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetSpecialContent] AS BEGIN SET NOCOUNT ON END')
	END
GO


ALTER PROCEDURE [dbo].[GetSpecialContent]
AS
BEGIN
	
	SELECT [Culture], [Posting], [PlaceHolder], [Text] FROM [SpecialContent]
END

GO


--------------------------------------------
-- Add special notice board entry to SpecialContent
-------------------------------------------
USE [TransientPortal]
GO

DECLARE @Culture VARCHAR(5),
	@Posting VARCHAR(100),
	@Placeholder VARCHAR(100),
	@Message VARCHAR(8000)

-- English text
SET @Culture = 'en-GB'
SET @Posting = 'SpecialNoticeBoard'
SET @Placeholder = 'SpecialNoticeBoardHtmlPlaceHolder'
SET @Message = '<h1>There are no special notices at the moment</h1>'

IF NOT EXISTS (SELECT * FROM [SpecialContent] 
		WHERE 	[Culture] = @Culture
		AND	[Posting] = @Posting
		AND 	[PlaceHolder] = @Placeholder)
	BEGIN
		INSERT INTO [SpecialContent]
		VALUES (@Posting, @Placeholder, @Culture, @Message)
	END
ELSE
	BEGIN
		UPDATE [SpecialContent]	
		SET [Text] = @Message
		WHERE 	[Culture] = @Culture
		AND	[Posting] = @Posting
		AND 	[PlaceHolder] = @Placeholder
	END

-- Welsh text
SET @Culture = 'cy-GB'

IF NOT EXISTS (SELECT * FROM [SpecialContent] 
		WHERE 	[Culture] = @Culture
		AND	[Posting] = @Posting
		AND 	[PlaceHolder] = @Placeholder)
	BEGIN
		INSERT INTO [SpecialContent]
		VALUES (@Posting, @Placeholder, @Culture, @Message)
	END
ELSE
	BEGIN
		UPDATE [SpecialContent]	
		SET [Text] = @Message
		WHERE 	[Culture] = @Culture
		AND	[Posting] = @Posting
		AND 	[PlaceHolder] = @Placeholder
	END

GO


-------------------------------------------------------------------------
-- Add LatestNewsService properties
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

IF NOT EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] = 'LatestNewsProvider.LatestNewsPosting' )
  BEGIN
	INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
	VALUES ('LatestNewsProvider.LatestNewsPosting','LatestNews','<DEFAULT>','<DEFAULT>','0')
  END
ELSE
  BEGIN
	UPDATE 	[PROPERTIES]
	SET 	pValue = 'LatestNews'
	WHERE	(pName = 'LatestNewsProvider.LatestNewsPosting')
  END


IF NOT EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] = 'LatestNewsProvider.LatestNewsPlaceHolder' )
  BEGIN
	INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
	VALUES ('LatestNewsProvider.LatestNewsPlaceHolder','TDInformationHtmlPlaceholderDefinition','<DEFAULT>','<DEFAULT>','0')
  END
ELSE
  BEGIN
	UPDATE 	[PROPERTIES]
	SET 	pValue = 'TDInformationHtmlPlaceholderDefinition'
	WHERE	(pName = 'LatestNewsProvider.LatestNewsPlaceHolder')
  END

IF NOT EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] = 'LatestNewsProvider.SpecialNoticeBoardPosting' )
  BEGIN
	INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
	VALUES ('LatestNewsProvider.SpecialNoticeBoardPosting','SpecialNoticeBoard','<DEFAULT>','<DEFAULT>','0')
  END
ELSE
  BEGIN
	UPDATE 	[PROPERTIES]
	SET 	pValue = 'SpecialNoticeBoard'
	WHERE	(pName = 'LatestNewsProvider.SpecialNoticeBoardPosting')
  END

IF NOT EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] = 'LatestNewsProvider.SpecialNoticeBoardPlaceHolder' )
  BEGIN
	INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
	VALUES ('LatestNewsProvider.SpecialNoticeBoardPlaceHolder','SpecialNoticeBoardHtmlPlaceHolder','<DEFAULT>','<DEFAULT>','0')
  END
ELSE
  BEGIN
	UPDATE 	[PROPERTIES]
	SET 	pValue = 'SpecialNoticeBoardHtmlPlaceHolder'
	WHERE	(pName = 'LatestNewsProvider.SpecialNoticeBoardPlaceHolder')
  END

IF NOT EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] = 'LatestNewsProvider.MaxTextLengthCharacters' )
  BEGIN
	INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
	VALUES ('LatestNewsProvider.MaxTextLengthCharacters','2000000','<DEFAULT>','<DEFAULT>','0')
  END
ELSE
  BEGIN
	UPDATE 	[PROPERTIES]
	SET 	pValue = '2000000'
	WHERE	(pName = 'LatestNewsProvider.MaxTextLengthCharacters')
  END

GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 890
SET @ScriptDesc = 'Updates to the Latest news mechanism used for Del 10.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------