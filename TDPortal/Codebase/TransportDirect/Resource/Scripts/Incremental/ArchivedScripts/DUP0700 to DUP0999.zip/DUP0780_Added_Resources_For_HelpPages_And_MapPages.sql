-- ***********************************************
-- NAME 		: DUP0780_Added_Resources_For_HelpPages_And_MapPages.sql
-- DESCRIPTION 	: Resources added for map pages and help pages
-- AUTHOR		: apatel
-- ************************************************

USE Content
GO

EXEC AddtblContent
1,1,'langStrings','MapRegionSelectControl.headingRegion','View travel news for a region','cy View travel news for a region'

EXEC AddtblContent
1,1,'langStrings','ShowNewsControl.headingRegion','View travel news for a region','cy View travel news for a region'

EXEC AddtblContent
1,1,'langStrings','ShowNewsControl.filterTravelNewsLabel','Filter travel news by: ','cy Filter travel news by:'

EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanNorthWestButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanNorthWest.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanNorthWest.gif'

EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanNorthButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanNorth.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanNorth.gif'


EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanNorthEastButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanNorthEast.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanNorthEast.gif'

EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanWestButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanWest.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanWest.gif'


EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanEastButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanEast.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanEast.gif'

EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanSouthWestButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanSouthWest.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanSouthWest.gif'


EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanSouthButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanSouth.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanSouth.gif'


EXEC AddtblContent
1,1,'langStrings','MapToolsControl.PanSouthEastButton','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanSouthEast.gif','/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/PanSouthEast.gif'

EXEC AddtblContent
1,1,'langStrings','TrafficMap.labelMapDescription','Maps of projected traffic levels based on historic traffic information (for location, day and time).','Mapiau o lefelau traffig arfaethedig yn seiliedig ar wybodaeth hanesyddol am drafnidiaeth (ar gyfer lleoliad, diwrnod ac amser)'

EXEC AddtblContent
1,1,'langStrings','TrafficMap.labelTrafficMapDescription','Maps of projected traffic levels based on historic traffic information (for location, day and time).','Mapiau o lefelau traffig arfaethedig yn seiliedig ar wybodaeth hanesyddol am drafnidiaeth (ar gyfer lleoliad, diwrnod ac amser)'

EXEC AddtblContent
1,1,'langStrings','TrafficMap.labelTrafficMapHelp','Select/type in a location to show on the map. Then click ''Next''','cy Select/type in a location to show on the map. Then click ''Next'''

EXEC AddtblContent
1,1,'langStrings','TrafficMap.SelectNewLocationButton.Text','Select new location','cy Select new location'

EXEC AddtblContent
1,1,'langStrings','JourneyPlannerLocationMap.newSearchButton.Text','New search','cy New search'

EXEC AddtblContent
1,1,'langStrings','MapToolsControl.labelMap.Text','Map:','cy Map:'

EXEC AddtblContent
1,1,'langStrings','MapControl.hyperLinkMapKey.Text','Overview Map','Map gorolwg'

EXEC AddtblContent
1,1,'langStrings','JourneyMapControl.labelOverviewMap','Overview map','Map gorolwg'

EXEC AddtblContent
1,1,'langStrings','JourneyFaresControl.buttonRetailers.Text','Buy tickets','Prynwch tocynnau'


EXEC AddtblContent
1,1,'langStrings','JourneyChangeSearchControl.genericBackButton.Text','Back','Yn �l'

EXEC AddtblContent
1,1,'langStrings','MapLocationIconsSelectControl.lblSelectedCategory','Selected Category','cy Selected Category'


EXEC AddtblContent
1,1,'langStrings','ParkAndRide.UrlHelpParkAndRide','Help/HelpParkAndRide.aspx','Help/HelpParkAndRide.aspx'

EXEC AddtblContent
1,1,'langStrings','ParkAndRide.UrlHelpPlanToParkAndRide','Help/HelpPlanToParkAndRide.aspx','Help/HelpPlanToParkAndRide.aspx'

EXEC AddtblContent
1,1,'langStrings','helpLabelDestinationTools.moreURL','Help/HelpMapToolsDestination.aspx','Help/HelpMapToolsDestination.aspx'


EXEC AddtblContent
1,1,'langStrings','helpLabelMapTools.moreURL','Help/HelpMapTools.aspx','Help/HelpMapTools.aspx'


EXEC AddtblContent
1,1,'langStrings','helpLabelMapToolsDestination.moreURL','Help/HelpMapToolsDestination.aspx','Help/HelpMapToolsDestination.aspx'


EXEC AddtblContent
1,1,'langStrings','helpLabelMapToolsStart.moreURL','Help/HelpMapToolsStart.aspx','Help/HelpMapToolsStart.aspx'


EXEC AddtblContent
1,1,'langStrings','helpLabelMapToolsVia.moreURL','Help/HelpMapToolsVia.aspx','Help/HelpMapToolsVia.aspx'


EXEC AddtblContent
1,1,'langStrings','helpLabelMapZoom.moreURL','Help/HelpMapToolsTraffic.aspx','Help/HelpMapToolsTraffic.aspx'


EXEC AddtblContent
1,1,'langStrings','helpLabelStartTools.moreURL','Help/HelpMapToolsStart.aspx','Help/HelpMapToolsStart.aspx'


EXEC AddtblContent
1,1,'langStrings','helpLabelViaTools.moreURL','Help/HelpMapToolsVia.aspx','Help/HelpMapToolsVia.aspx'


EXEC AddtblContent
1,1,'langStrings','journeyMapControlHelpLabel.moreURL','Help/HelpMapTools.aspx','Help/HelpMapTools.aspx'


EXEC AddtblContent
1,1,'langStrings','extendInputHelpLabelControl.moreURL','Help/HelpExtendInput.aspx','Help/HelpExtendInput.aspx'


EXEC AddtblContent
1,1,'RefineJourney','ExtendJourneyInput.helpButton.HelpUrl','Help/HelpExtendInput.aspx','Help/HelpExtendInput.aspx'

EXEC AddtblContent
1,1,'langStrings','ExtendJourneyInput.helpButton.HelpUrl','Help/HelpExtendInput.aspx','Help/HelpExtendInput.aspx'


 
EXEC AddtblContent
1,1,'FaresAndTickets','JourneyFaresControl.helpJourneyFaresLabelControl.moreURL','Help/HelpTickets.aspx','Help/HelpTickets.aspx'	   

EXEC AddtblContent
1,1,'FindAFare','FindFareTicketSelectionHelpLabel.moreURL','Help/HelpFindFareTicketSelection.aspx','Help/HelpFindFareTicketSelection.aspx'	   

EXEC AddtblContent
1,1,'langStrings','alternativeJourneyMapControlHelpLabel.moreURL','Help/HelpTools.aspx','Help/HelpTools.aspx'	   

EXEC AddtblContent
1,1,'langStrings','AmbiguityHelpLabelDateAlt.moreURL','Help/HelpTimesDatesAmbig.aspx','Help/HelpTimesDatesAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','AmbiguityHelpLabelDestination.moreURL','Help/HelpSettingLocationsAmbigTo.aspx','Help/HelpSettingLocationsAmbigTo.aspx'	   

EXEC AddtblContent
1,1,'langStrings','AmbiguityHelpLabelOrigin.moreURL','Help/HelpSettingLocationsAmbigFrom.aspx','Help/HelpSettingLocationsAmbigFrom.aspx'	   

EXEC AddtblContent
1,1,'langStrings','carDateHelpLabelControl.confirmDateError.moreUrl','Help/HelpFindACarTimesDatesAmbig.aspx','Help/HelpFindACarTimesDatesAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','carOutwardDateHelpLabel.moreURL','Help/HelpFindACarDatesOutward.aspx','Help/HelpFindACarDatesOutward.aspx'	   

EXEC AddtblContent
1,1,'langStrings','carPreferencesHelpLabel.moreURL','Help/HelpFindCarDetails.aspx','Help/HelpFindCarDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','carReturnDateHelpLabel.moreURL','Help/HelpFindACarDatesReturn.aspx','Help/HelpFindACarDatesReturn.aspx'	   

EXEC AddtblContent
1,1,'langStrings','coachOutwardDateHelpLabel.moreURL','Help/HelpFindADatesOutward.aspx','Help/HelpFindADatesOutward.aspx'	   

EXEC AddtblContent
1,1,'langStrings','coachReturnDateHelpLabel.moreURL','Help/HelpFindADatesReturn.aspx','Help/HelpFindADatesReturn.aspx'	   

EXEC AddtblContent
1,1,'langStrings','dateErrorHelpLabel.moreURL','Help/HelpFindATimesDatesAmbig.aspx','Help/HelpFindATimesDatesAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','dateHelpLabelControl.confirmDateError.moreUrl','Help/HelpFindATimesDatesAmbig.aspx','Help/HelpFindATimesDatesAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','extendInputHelpLabelControl.moreURL','Help/HelpExtendInput.aspx','Help/HelpExtendInput.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindCoachTrainPreferencesControl.ChangesHelp.FindCoachInput.moreUrl','Help/HelpFindACoachChanges.aspx','Help/HelpFindACoachChanges.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindCoachTrainPreferencesControl.ChangesHelp.FindTrainInput.moreUrl','Help/HelpFindATrainChanges.aspx','Help/HelpFindATrainChanges.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelCheckInTime.moreURL','Help/HelpFindAAirTravelDetails.aspx','Help/HelpFindAAirTravelDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelDate.moreURL','Help/HelpFindADatesOutward.aspx','Help/HelpFindADatesOutward.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelDateAmbiguous.moreURL','Help/HelpFindATimesDatesAmbig.aspx','Help/HelpFindATimesDatesAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelLocationFrom.moreURL','Help/HelpFindALocationFrom.aspx','Help/HelpFindALocationFrom.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelLocationTo.moreURL','Help/HelpFindALocationTo.aspx','Help/HelpFindALocationTo.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelOperatorSelection.moreURL','Help/HelpFindAAirTravelDetails.aspx','Help/HelpFindAAirTravelDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelReturn.moreURL','Help/HelpFindADatesReturn.aspx','Help/HelpFindADatesReturn.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindFlightInputHelpLabelViaLocation.moreURL','Help/HelpFindAAirTravelDetails.aspx','Help/HelpFindAAirTravelDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationFromCarHelpLabelAmbiguousMoreUrl','Help/HelpFindCarFromAmbiguous.aspx','Help/HelpFindCarFromAmbiguous.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationFromCarHelpLabelMoreUrl','Help/HelpFindCarFrom.aspx','Help/HelpFindCarFrom.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationFromCoachAmbiguousMoreUrl','Help/HelpFindCoachFromAmbiguous.aspx','Help/HelpFindCoachFromAmbiguous.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationFromCoachHelpLabelMoreUrl','Help/HelpFindCoachFrom.aspx','Help/HelpFindCoachFrom.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationFromTrainAmbiguousMoreUrl','Help/HelpFindTrainFromAmbiguous.aspx','Help/HelpFindTrainFromAmbiguous.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationFromTrainHelpLabelMoreUrl','Help/HelpFindTrainFrom.aspx','Help/HelpFindTrainFrom.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationFromVarietyAmbiguousMoreUrl','Help/HelpFindVarietyFromAmbiguous.aspx','Help/HelpFindVarietyFromAmbiguous.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationToCarHelpLabelAmbiguousMoreUrl','Help/HelpFindCarToAmbiguous.aspx','Help/HelpFindCarToAmbiguous.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationToCarHelpLabelMoreUrl','Help/HelpFindCarTo.aspx','Help/HelpFindCarTo.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationToCoachAmbiguousMoreUrl','Help/HelpFindCoachToAmbiguous.aspx','Help/HelpFindCoachToAmbiguous.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationToCoachHelpLabelMoreUrl','Help/HelpFindCoachTo.aspx','Help/HelpFindCoachTo.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationToTrainAmbiguousMoreUrl','Help/HelpFindTrainToAmbiguous.aspx','Help/HelpFindTrainToAmbiguous.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationToTrainHelpLabelMoreUrl','Help/HelpFindTrainTo.aspx','Help/HelpFindTrainTo.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationViaCarHelpLabelMoreUrl','Help/HelpFindCarDetails.aspx','Help/HelpFindCarDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationViaCoachHelpLabelMoreUrl','Help/HelpViaCoach.aspx','Help/HelpViaCoach.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationViaStationHelpLabelMoreUrl','Help/HelpViaStation.aspx','Help/HelpViaStation.aspx'	   

EXEC AddtblContent
1,1,'langStrings','FindLocationViaTrainHelpLabelMoreUrl','Help/HelpViaTrain.aspx','Help/HelpViaTrain.aspx'	   

EXEC AddtblContent
1,1,'langStrings','HelpControl.DefaultLabel','Sorry we weren"t able to tell what help you require. Please check our <html><body><a href="/Del3/pr01/en/Help/Help/" target="_blank">main help page</a></body></html>.aspx','Sorry we weren"t able to tell what help you require. Please check our <html><body><a href="/Del3/pr01/en/Help/Help/" target="_blank">main help page</a></body></html>.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelCarRouteOption.moreURL','help/HelpCarOptions.aspx','help/HelpCarOptions.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelCarRouteOptionAmbig.moreURL','help/HelpCarRouteAmbig.aspx','help/HelpCarRouteAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelDestination.moreURL','Help/HelpEnteringLocationsDestination.aspx','Help/HelpEnteringLocationsDestination.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelDestinationAmbiguity.moreURL','Help/HelpEnteringLocationsAmbigDestination.aspx','Help/HelpEnteringLocationsAmbigDestination.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelLocations.moreURL','Help/HelpEnteringLocations.aspx','Help/HelpEnteringLocations.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelLocationsAmbig.moreURL','Help/HelpEnteringLocationsAmbig.aspx','Help/HelpEnteringLocationsAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelLocationSelect.moreURL','Help/HelpEnteringLocationsTraffic.aspx','Help/HelpEnteringLocationsTraffic.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelLocationSelectAmbig.moreURL','help/HelpEnteringLocationsAmbigTraffic.aspx','help/HelpEnteringLocationsAmbigTraffic.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelMapToolsFindCarPark.moreURL','Help/helpFindAMapTools.aspx','Help/helpFindAMapTools.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelMapToolsFindStation.moreURL','Help/helpFindAMapTools.aspx','Help/helpFindAMapTools.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelMapToolsOutward.moreURL','Help/HelpFindAMapTools.aspx','Help/HelpFindAMapTools.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelMapToolsReturn.moreURL','Help/HelpoutputMapTools.aspx','Help/HelpoutputMapTools.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelPublicRouteOption.moreURL','help/HelpPublicOptions.aspx','help/HelpPublicOptions.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelPublicRouteOptionAmbig.moreURL','help/HelpPublicRouteAmbig.aspx','help/HelpPublicRouteAmbig.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelStartAmbiguity.moreURL','Help/HelpEnteringLocationsAmbigStart.aspx','Help/HelpEnteringLocationsAmbigStart.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelStartLocation.moreURL','Help/HelpEnteringLocationsStart.aspx','Help/HelpEnteringLocationsStart.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelToolsSecond.moreURL','Help/HelpToolsSecond.aspx','Help/HelpToolsSecond.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelVia.moreURL','Help/HelpEnteringLocationsViaCar.aspx','Help/HelpEnteringLocationsViaCar.aspx'	   

EXEC AddtblContent
1,1,'langStrings','helpLabelViaAmbiguity.moreURL','Help/HelpEnteringLocationsAmbigViaCar.aspx','Help/HelpEnteringLocationsAmbigViaCar.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyInputHelpLabelCarOptions.moreURL','Help/HelpAdvancedOptions.aspx','Help/HelpAdvancedOptions.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyInputHelpLabelDate.moreURL','Help/HelpTimesDates.aspx','Help/HelpTimesDates.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyInputHelpLabelLocation.moreURL','Help/HelpSettingLocations.aspx','Help/HelpSettingLocations.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyInputHelpLabelLocationFrom.moreURL','Help/HelpSettingLocations.aspx','Help/HelpSettingLocations.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyInputHelpLabelLocationTo.moreURL','Help/HelpSettingLocationsDestination.aspx','Help/HelpSettingLocationsDestination.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyInputHelpLabelPublicModes.moreURL','Help/HelpPreferences.aspx','Help/HelpPreferences.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyInputHelpLabelReturn.moreURL','Help/HelpTimesDatesReturn.aspx','Help/HelpTimesDatesReturn.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeyMapControlItineraryHelpLabel.moreURL','Help/HelpMapItinerary.aspx','Help/HelpMapItinerary.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeyMapControlPrivateHelpLabel.moreURL','Help/HelpMapCar.aspx','Help/HelpMapCar.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeyMapControlPublicHelpLabel.moreURL','Help/HelpMapPublic.aspx','Help/HelpMapPublic.aspx'	   

EXEC AddtblContent
1,1,'langStrings','JourneyReplanInputPage.HelpPageUrl','Help/HelpJourneyReplanInputPage.aspx','Help/HelpJourneyReplanInputPage.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySegmentHelpLabelCar.moreURL','Help/HelpoutputMapTools.aspx','Help/HelpoutputMapTools.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabel.moreURL','Help/HelpDetails.aspx','Help/HelpDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelBus.moreURL','Help/HelpBusDetails.aspx','Help/HelpBusDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelCar.moreURL','Help/HelpCarDetails.aspx','Help/HelpCarDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelCoach.moreURL','Help/HelpCoachDetails.aspx','Help/HelpCoachDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelFindFare.moreURL','Help/HelpDetailsFindAFare.aspx','Help/HelpDetailsFindAFare.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelFindFareSingles.moreURL','Help/HelpDetailsFindAFare.aspx','Help/HelpDetailsFindAFare.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelFlight.moreURL','Help/HelpFlightDetails.aspx','Help/HelpFlightDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelTrain.moreURL','Help/HelpTrainDetails.aspx','Help/HelpTrainDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','journeySummaryHelpLabelVariety.moreURL','Help/HelpVarietyDetails.aspx','Help/HelpVarietyDetails.aspx'	   

EXEC AddtblContent
1,1,'langStrings','publicPreferencesHelpLabel.moreURL','Help/HelpPreferences.aspx','Help/HelpPreferences.aspx'	   

EXEC AddtblContent
1,1,'langStrings','TicketRetailersHelpLabel.moreURL','Help/HelpTicketRetailers.aspx','Help/HelpTicketRetailers.aspx'	   

EXEC AddtblContent
1,1,'langStrings','trainOutwardDateHelpLabel.moreURL','Help/HelpFindADatesOutward.aspx','Help/HelpFindADatesOutward.aspx'	   

EXEC AddtblContent
1,1,'langStrings','trainReturnDateHelpLabel.moreURL','Help/HelpFindADatesReturn.aspx','Help/HelpFindADatesReturn.aspx'	   

EXEC AddtblContent
1,1,'langStrings','transportTypesHelpLabel.moreURL','Help/HelpSettingModes.aspx','Help/HelpSettingModes.aspx'	   

EXEC AddtblContent
1,1,'langStrings','trunkOutwardDateHelpLabel.moreURL','Help/HelpFindADatesOutward.aspx','Help/HelpFindADatesOutward.aspx'	   

EXEC AddtblContent
1,1,'langStrings','trunkReturnDateHelpLabel.moreURL','Help/HelpFindADatesReturn.aspx','Help/HelpFindADatesReturn.aspx'	   

EXEC AddtblContent
1,1,'RefineJourney','ExtendJourneyInput.helpButton.HelpUrl','Help/HelpExtendInput.aspx','Help/HelpExtendInput.aspx'	 

Exec addtblContent
1,27,'TitleText','/Channels/TransportDirect/Help/NewHelp','Frequently Asked Questions (FAQ)','Cwestiynau a Ofynnir yn Aml (COA)'


EXEC AddtblContent
 1, 2, '_Web2_Help_HelpToolBar', 'Channel', '/Channels/TransportDirect/Help/HelpToolBar', '/Channels/TransportDirect/Help/HelpToolbar'


EXEC AddtblContent
1, 2, '_Web2_Help_HelpToolBar', 'Page', '/Web2/helpfulljp.aspx', '/Web2/helpfulljp.aspx'


EXEC AddtblContent
1, 2, '_Web2_Help_HelpToolBar', 'QueryString', 'helpfulljp', 'helpfulljp'

EXEC AddtblContent
1,1,'langStrings','JourneyPlannerLocationMap.labelFindMapMessage','Select/type in a location to show on the map. Then click "Next".','Dewiswch/teipiwch leoliad i�w ddangos ar y map.  Yna cliciwch �Nesa�.'	   

EXEC AddtblContent
1,1,'langStrings','HelpFullJP.HelpLabelTitle.Text','Help','Help'	

EXEC AddtblContent
1,1,'VisitPlanner','VisitPlannerJourneyOptionsControl.commandOK.Text','Ok','cy Ok'	    

EXEC AddtblContent
1,1,'langStrings','HomeDefault.lblFindCarPark','Find a<br />car park','cy Find a<br />car park'	

EXEC AddtblContent
1,1,'RefineJourney','ExtendedFullItinerarySummary.AddOnwardJourney.Text','Add another onward journey','cy Add another onward journey'	


EXEC AddtblContent
1,14,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,14,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/JourneyPlanning/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,14,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/LiveTravel/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,14,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Maps/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,14,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Tools/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

--

EXEC AddtblContent
1,15,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,15,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/JourneyPlanning/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,15,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/LiveTravel/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,15,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Maps/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,15,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Tools/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

--

EXEC AddtblContent
1,16,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,16,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/JourneyPlanning/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,16,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/LiveTravel/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,16,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Maps/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,16,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Tools/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

--

EXEC AddtblContent
1,17,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,17,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/JourneyPlanning/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,17,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/LiveTravel/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,17,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Maps/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,17,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Tools/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'


--

EXEC AddtblContent
1,18,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,18,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/JourneyPlanning/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,18,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/LiveTravel/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,18,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Maps/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,18,'TDNewInformationHtmlPlaceholderDefinition','/Channels/TransportDirect/Tools/Home','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td>	<td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/TransportDirect/en/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'

EXEC AddtblContent
1,1,'UserSurveyStrings','UserSurvey.ImageButtonShowPrinterFriendly.ImageUrl','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/ShowPrinterFriendlyPage.gif','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/ShowPrinterFriendlyPage.gif'


EXEC AddtblContent
1,1,'UserSurveyStrings','UserSurvey.ImageSection1Arrow1.ImageUrl','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/step1.gif','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/step1.gif'


EXEC AddtblContent
1,1,'UserSurveyStrings','UserSurvey.ImageSection1Arrow1Grey.ImageUrl','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/step1_gry.gif','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/step1_gry.gif'


EXEC AddtblContent
1,1,'UserSurveyStrings','UserSurvey.ImageSection1Arrow2.ImageUrl','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/step2.gif','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/step2.gif'


EXEC AddtblContent
1,1,'UserSurveyStrings','UserSurvey.ImageSection1Arrow2Grey.ImageUrl','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/step2_gry.gif','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/step2_gry.gif'


EXEC AddtblContent
1,1,'UserSurveyStrings','UserSurvey.ImageSection1Arrow3.ImageUrl','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/step3.gif','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/step3.gif'

EXEC AddtblContent
1,1,'UserSurveyStrings','UserSurvey.ImageSection1Arrow3Grey.ImageUrl','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/step3_gry.gif','/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/step3_gry.gif'

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 780
SET @ScriptDesc = 'Resources added for map pages and help pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------