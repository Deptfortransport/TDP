-- ************************************************************
-- NAME 	: DUP0758_RetailerLookup_Table_PartnerSpecificChanges.sql
-- DESCRIPTION 	: Updated RetailerLookup Table to add ThemeId column
-- Author       : Darshan Sawe
-- Date         : 19-Feb-2008
-- ************************************************************
--

USE [PermanentPortal]
GO

--------------------------------------------------
-- 1. Add ThemeId column in RetailerLookup Table
--------------------------------------------------

IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('RetailerLookup')
						AND syscolumns.name = 'ThemeId')
BEGIN
	ALTER TABLE RetailerLookup ADD [ThemeId] INT NOT NULL DEFAULT(1)
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS 
			WHERE CONSTRAINT_CATALOG = 'PermanentPortal'
			AND TABLE_NAME ='RetailerLookup'
			AND CONSTRAINT_NAME = 'PK_RetailerLookup')		

BEGIN
	ALTER TABLE [RetailerLookup]  DROP 
		CONSTRAINT [PK_RetailerLookup]

	ALTER TABLE [dbo].[RetailerLookup] ADD 
		CONSTRAINT [PK_RetailerLookup] PRIMARY KEY  CLUSTERED 
	(
		[OperatorCode],
		[Mode],
		[RetailerId],
		[PartnerId],
		[ThemeId]
	)  ON [PRIMARY] 
END
GO

--------------------------------------------
-- 2. Alter GetRetailerLookup procedure
--------------------------------------------


--Create procedure if not present

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetRetailerLookup'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetRetailerLookup] AS BEGIN SET NOCOUNT ON END')
	END
GO


ALTER PROCEDURE GetRetailerLookup
(
	@ThemeName varchar(100)
)
AS
BEGIN

	DECLARE @ThemeId INT
	DECLARE @DefaultThemeId INT

	EXEC [Content].[dbo].[GetThemeIdByName] @ThemeName, @ThemeId OUTPUT

	IF @ThemeId IS NULL
		BEGIN
		RAISERROR ('%s is an invalid theme', 16, 1, @ThemeName)
		END

	EXEC [Content].[dbo].[GetDefaultThemeId] @DefaultThemeId OUTPUT 
	
	SELECT 	[OperatorCode], [Mode], [RetailerId]
	FROM	RetailerLookup
	WHERE ThemeId = @ThemeId
	UNION ALL
	(	
	SELECT 	[OperatorCode], [Mode], [RetailerId]
	FROM	RetailerLookup
	WHERE
		[OperatorCode] + '|' + [Mode] + '|' + [RetailerId] IN
		(
		SELECT DISTINCT [OperatorCode] + '|' + [Mode] + '|' + [RetailerId]
		FROM RetailerLookup
		WHERE [ThemeId] = @DefaultThemeId  
		AND [OperatorCode] + '|' + [Mode] + '|' + [RetailerId]  NOT IN
		(
			SELECT DISTINCT [OperatorCode] + '|' + [Mode] + '|' + [RetailerId]
			FROM RetailerLookup
			WHERE ThemeId = @ThemeId
		)
		
		)
	AND ThemeId = @DefaultThemeId 
	
			
	)
			
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 758
SET @ScriptDesc = 'Added ThemeId column in RetailerLookup Table & updated GetRetailerLookup Proc '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
