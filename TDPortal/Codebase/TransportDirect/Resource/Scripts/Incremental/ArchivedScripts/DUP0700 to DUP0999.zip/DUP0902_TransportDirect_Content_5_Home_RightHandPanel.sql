-- ***********************************************
-- NAME 		: DUP0902_TransportDirect_Content_5_Home_RightHandPanel.sql
-- DESCRIPTION 		: Script to add the Right Hand Information panel text
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 Apr 2008 15:00:00
-- ************************************************

USE [Content]
GO


DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')


-- Right hand items 1 and 2
EXEC AddtblContent
1, @GroupId, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<DIV class="Column3Header">  <DIV class="txtsevenbbl">Find a Car Park</DIV><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="Column3Content">  <TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="txtseven" vAlign="top" align="middle" width="26"><IMG title="" alt="Car Park" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_carpark.gif" border="0"></TD>  <TD class="txtseven">We can provide a list of car parks near to your chosen location and then plan a journey to the one you select. <A href="/Web2/JourneyPlanning/FindCarParkInput.aspx">Click here to find the nearest car park</A> or enter your chosen location in the Find a Place section on the left of this page. </TD></TR></TBODY></TABLE></DIV>  <DIV class="Column3Header">  <DIV class="txtsevenbbl">CO2 Emissions</DIV><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="Column3Content">  <TABLE id="Table2" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="txtseven" vAlign="top"><IMG title="" height="26" alt="C02" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_c02.gif" width="26" border="0"></TD>  <TD class="txtseven">Transport Direct now provides details of the CO2 your journey will produce. <A href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">Go to the Journey Planner</A> and enter your journey details as normal. When you get your journey options click on the "Check CO2" button. </TD></TR></TBODY></TABLE></DIV>'
, '<DIV class="Column3Header">  <DIV class="txtsevenbbl">Find a Car Park</DIV><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="Column3Content">  <TABLE id="Table1" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="txtseven" vAlign="top" align="middle" width="26"><IMG title="" alt="Car Park" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/trspt_carpark.gif" border="0"></TD>  <TD class="txtseven">We can provide a list of car parks near to your chosen location and then plan a journey to the one you select. <A href="/Web2/JourneyPlanning/FindCarParkInput.aspx">Click here to find the nearest car park</A> or enter your chosen location in the Find a Place section on the left of this page. </TD></TR></TBODY></TABLE></DIV>  <DIV class="Column3Header">  <DIV class="txtsevenbbl">CO2 Emissions</DIV><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>  <DIV class="Column3Content">  <TABLE id="Table2" cellSpacing="0" cellPadding="2" width="100%" border="0">  <TBODY>  <TR>  <TD class="txtseven" vAlign="top"><IMG title="" height="26" alt="C02" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/trspt_c02.gif" width="26" border="0"></TD>  <TD class="txtseven">Transport Direct now provides details of the CO2 your journey will produce. <A href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">Go to the Journey Planner</A> and enter your journey details as normal. When you get your journey options click on the "Check CO2" button. </TD></TR></TBODY></TABLE></DIV>' 


-- Right hand item 3
EXEC AddtblContent
1, @GroupId, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'
, '<div class="Column3Header"><div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div><div class="Column3Content"><table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody><tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free"></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br><br>Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink">Excel link generator</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page</a> for more details.</td></tr></tbody></table></div>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 902
SET @ScriptDesc = 'Script to add Homepage Right hand information text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO