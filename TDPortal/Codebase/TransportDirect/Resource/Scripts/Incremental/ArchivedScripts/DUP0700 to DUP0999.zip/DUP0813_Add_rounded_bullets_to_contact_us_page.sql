-- ************************************************************
-- NAME 		: DUP0813_Add_rounded_bullets_to_contact_us_page.sql
-- DESCRIPTION 		: Adds rounded bullets to contact us page
-- AUTHOR		: Dan Gath
-- ************************************************************
USE Content
GO

update tblContent set [Value-EN]='<p>We welcome comments that will help us to improve the service that we offer.  Please fill in the form below to tell us about:</p> <br> <ul class="listround">
<li>Errors that you find with the information that we provide</li><li>Technical problems that you experience with the site.</li><li>Your suggestions for future developments</li></ul>  <br>  <p>Please give us plenty of detail to support your comments.  For journey planning problems tell us the date and time of the journey; the exact start and finish points; the nature of the error, etc.  For technical problems please tell us what Operating System and browser you are using and so forth.</p><p> </p> <br> <p>All comments are taken forward but we regret that we are unable to offer individual replies.</p><p> </p> <br> <p><b>NOTE - If you want to know how to do something on this site, try clicking FAQ, or see the overview information on the first page under each part of the site.  Please do not use this form to ask us to search the site on your behalf, as unfortunately we are unable to do so.</b></p>
', [Value-CY]='<p>Rydym yn croesawu sylwadau a fydd yn gymorth i ni wella''r gwasanaeth a gynigiwn. Llenwch y ffurflen isod i ddweud wrthym ynglyn �:</p> <br> <ul class="listround"><li>Gwallau a welsoch gyda''r wybodaeth a ddarparwn</li><li>Problemau technegol a gawsoch gyda''r safle</li><li>Eich awgrymiadau am ddatblygiadau yn y dyfodol</li></ul> <br> <p>Rhowch ddigon o fanylion i ni er mwyn cefnogi eich sylwadau. Am broblemau wrth gynllunio siwrneion dywedwch wrthym beth yw dyddiad ac amser y siwrnai; yr union fannau cychwyn a gorffen; natur y gwall ayb. Ar gyfer problemau technegol, dywedwch wrthym ba System Weithredu a phorwr rydych chi''n eu defnyddio ac ati.</p><p> </p> <br> <p>Mae pob sylw yn cael ystyriaeth ond ni allwn gynnig atebion unigol yn anffodus. </p><p> </p> <br> <p><b>SYLWER - Os hoffech wybod sut i wneud rhywbeth ar y safle hwn, beth am glicio Cwestiynau a Ofynnir yn Aml (COA), neu ewch i''r tudalennau "Gorolwg" o dan bob rhan o''r safle. Peidiwch � defnyddio''r ffurflen hon i ofyn i ni chwilio''r safle ar eich rhan, oherwydd ni allwn wneud hynny yn anffodus.</b></p>' where PropertyName='FeedbackInitialPage.labelIntroduction.Text'
GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 813
SET @ScriptDesc = 'Added rounded bullets to contact us page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------