-- ***********************************************
-- NAME 		: DUP0796_CarParkUsability_SwitchesForAdditionalData.sql
-- DESCRIPTION 		: Switches for car park additional data
-- AUTHOR		: mmodi
-- ************************************************
USE PermanentPortal
GO

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.Information.ShowOpeningClosingTimes')
BEGIN
	insert into properties values ('FindCarParkResults.Information.ShowOpeningClosingTimes', 'True', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.Information.ShowIsSecureLogo')
BEGIN
	insert into properties values ('FindCarParkResults.Information.ShowIsSecureLogo', 'False', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.Information.ShowRestrictions')
BEGIN
	insert into properties values ('FindCarParkResults.Information.ShowRestrictions', 'True', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.Information.ShowAdvancedReservations')
BEGIN
	insert into properties values ('FindCarParkResults.Information.ShowAdvancedReservations', 'True', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.Information.ShowTotalSpaces')
BEGIN
	insert into properties values ('FindCarParkResults.Information.ShowTotalSpaces', 'True', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.Information.ShowDisabledSpaces')
BEGIN
	insert into properties values ('FindCarParkResults.Information.ShowDisabledSpaces', 'True', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'FindCarParkResults.Information.ShowCarParkType')
BEGIN
	insert into properties values ('FindCarParkResults.Information.ShowCarParkType', 'True', '<DEFAULT>', '<DEFAULT>', 0, 1)
END


GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 796
SET @ScriptDesc = 'Switches for car park additional data'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------