-- ***********************************************
-- NAME 		: DUP0940_Content_Updates_TravelNews.sql
-- DESCRIPTION 	: Script to update Travel news content 
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 May 2008
-- ************************************************

USE [Content]
GO


EXEC AddtblContent 1, 1, 'langStrings', 'TravelNews.KeyOfSymbols', 'Key', 'Allwedd'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 940
SET @ScriptDesc = 'Script to update Travel news content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO