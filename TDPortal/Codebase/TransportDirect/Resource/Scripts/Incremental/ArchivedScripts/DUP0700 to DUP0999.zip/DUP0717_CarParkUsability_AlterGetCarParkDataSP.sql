-- ***********************************************
-- NAME 		: DUP0717_CarParkUsability_AlterGetCarParkDataSP.sql
-- DESCRIPTION 		: Alter the GetCarParkData sp
--
-- ************************************************

Use TransientPortal
GO

-- alter SP
/*
alters the GetCarParkingData sp to also return the additional data id =
from the relevant carparking data row
*/

ALTER PROCEDURE dbo.GetCarParkingData
 @CarParkKey varchar(50)
AS
	BEGIN
    SELECT
	CarParking.AdditionalDataId,
	CarParking.Reference,
	CarParking.OperatorId,
	CarParking.AccessPointsMapId,
	CarParking.AccessPointsEntranceId,
	CarParking.AccessPointsExitId,
	CarParking.TrafficNewsRegionId,
	CarParking.ParkAndRideSchemeId,
	CarParking.NPTGAdminDistrictId,
	CarParking.Name,
	CarParking.Location,
	CarParking.Address,
	CarParking.Postcode,
	CarParking.Notes,
	CarParking.Telephone,
	CarParking.Url,
	CarParking.MinCost,
	CarParking.ParkAndRide,
	CarParking.StayType,
	CarParking.PlanningPoint,
	CarParking.DateRecordLastUpdated,
	CarParking.WEUDate,
	CarParking.WEFDate

FROM
	CarParking
WHERE
	CarParking.Reference = @CarParkKey
END
GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 717
SET @ScriptDesc = 'Alter GetCarParkingData sp to also return additional data id'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------