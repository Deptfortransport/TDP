-- *************************************************************************************
-- NAME 		: DUP0754_Added_Menu_For_Provide_Feedback_Second_Level_Menu.sql
-- DESCRIPTION  : Added Provide Feedback second level menu in tips and tools menu
-- AUTHOR		: Amit Patel
-- *************************************************************************************
USE [TransientPortal]
GO

-- Updating provide feeback link url

EXEC UpdateSuggestionLinkURL
	 'ContactUs/FeedbackPage.aspx', 
	 NULL, 
	 'Provide feedback', 
	 1
GO


DECLARE @LinkCategoryId INT
DECLARE @LinkPriority INT

SELECT @LinkCategoryId = Max(LinkCategoryId)+1 FROM LinkCategory

SELECT @LinkPriority = Priority + 5 FROM LinkCategory WHERE [Name] = 'Tips and tools'

IF NOT EXISTS (SELECT TOP 1 * from LinkCategory WHERE [Name] = 'Provide Feedback')
BEGIN
	INSERT INTO LinkCategory VALUES(@LinkCategoryId, @LinkPriority, 'Provide Feedback', 'Provide Feedback menu')
END


------------------------------------------------------------
-- Add the External links we want
DECLARE @ExternalLinkID varchar(100)

SET @ExternalLinkID = 'ProvideFeedback.TourismInformation'

IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = @ExternalLinkID)
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = @ExternalLinkID
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES (@ExternalLinkID, 'http://www.visitbritain.co.uk', 'http://www.visitbritain.co.uk', '1', 'Information on tourism in Britain', NULL, NULL, NULL)



IF NOT EXISTS(SELECT * FROM [ExternalSuggestionLink] WHERE [ExternalLinkID] = @ExternalLinkID)
	INSERT INTO [ExternalSuggestionLink] ([ExternalLinkID])
	VALUES (@ExternalLinkID)
GO
	 
------------------------------------------------------------
-- Add the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link for Feedback page
SET @RelativeURL = 'ContactUs/FeedbackPage.aspx'
SET @InternalLinkDescription = 'FeedBack Page'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
	
-- Link for Contact Details page
SET @RelativeURL = 'ContactUs/Details.aspx'
SET @InternalLinkDescription = 'Contact Details'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

-- Link for Contact Details page
SET @RelativeURL = 'Help/HelpInfo.aspx#A1.1'
SET @InternalLinkDescription = 'FAQ - Travel Information'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

GO


------------------------------------------------------------
-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT

-- Link 1
SET @LinkResourceName = 'Feedback'
SET @LinkResourceNameEN = 'Feedback'
SET @LinkResourceNameCY = 'cy Feedback'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-- Link 2
SET @LinkResourceName = 'ContactDetails'
SET @LinkResourceNameEN = 'Contact Details'
SET @LinkResourceNameCY = 'cy Contact Details'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-- Link 3
SET @LinkResourceName = 'TravelInformation'
SET @LinkResourceNameEN = 'Travel information on Transport Direct'
SET @LinkResourceNameCY = 'cy Travel information on Transport Direct'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
	

-- Link 4
SET @LinkResourceName = 'ProvideFeedback.TourismInformation'
SET @LinkResourceNameEN = 'Information on tourism in Britain'
SET @LinkResourceNameCY = 'cy Information on tourism in Britain'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY
GO	

------------------------------------------------------------
-- update SuggestionLinks for Provide Feedback link

DECLARE @LinkCategoryID INT,
		@ResourceNameID INT

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Tips and tools'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='ProvideFeedback'

UPDATE SuggestionLink SET IsRoot = 1, IsSubRootLink=1
		WHERE LinkCategoryId = @LinkCategoryID AND ResourceNameId = @ResourceNameID
GO		

------------------------------------------------------------
--insert into SuggestionLink table for homepage menu
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100),
	@SubRootLinkId INT

DECLARE @InternalLinkDescription varchar(500)

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Tips and tools'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='ProvideFeedback'
	
SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = 'HomePageMenu' 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
		


-- Link 1
SET @LinkResourceName = 'Feedback'
SET @InternalLinkDescription = 'FeedBack Page'
SET @LinkCategoryID =8
SET @LinkPriority = 52
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link 2
SET @LinkResourceName = 'ContactDetails'
SET @InternalLinkDescription = 'Contact Details'
SET @LinkCategoryID = 8
SET @LinkPriority = 54
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link 3
SET @LinkResourceName = 'TravelInformation'
SET @InternalLinkDescription = 'FAQ - Travel Information'
SET @LinkCategoryID = 8
SET @LinkPriority = 56
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link 4
SET @LinkResourceName = 'ProvideFeedback.TourismInformation'
SET @LinkCategoryID = 8
SET @LinkPriority = 58
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select ExternalSuggestionLinkID from [dbo].[ExternalSuggestionLink] where ExternalLinkID = @LinkResourceName)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'External', 0,1,@SubRootLinkId
GO


------------------------------------------------------------
--insert into SuggestionLink table for TipsAndTools Pages menu
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100),
	@SubRootLinkId INT

DECLARE @InternalLinkDescription varchar(500)

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Tips and tools'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='ProvideFeedback'
	
SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = 'HomePageMenuTipsAndTools' 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
		


-- Link 1
SET @LinkResourceName = 'Feedback'
SET @InternalLinkDescription = 'FeedBack Page'
SET @LinkCategoryID =8
SET @LinkPriority = 5052
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link 2
SET @LinkResourceName = 'ContactDetails'
SET @InternalLinkDescription = 'Contact Details'
SET @LinkCategoryID = 8
SET @LinkPriority = 5054
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link 3
SET @LinkResourceName = 'TravelInformation'
SET @InternalLinkDescription = 'FAQ - Travel Information'
SET @LinkCategoryID = 8
SET @LinkPriority = 5056
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 0,1,@SubRootLinkId

-- Link 4
SET @LinkResourceName = 'ProvideFeedback.TourismInformation'
SET @LinkCategoryID = 8
SET @LinkPriority = 5058
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select ExternalSuggestionLinkID from [dbo].[ExternalSuggestionLink] where ExternalLinkID = @LinkResourceName)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'External', 0,1,@SubRootLinkId
GO


-----------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages for homepage menu
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'HomePageMenu'
SET @ContextDescription = 'Links for expandable menu on the Home Page/mini homepages.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@SubRootLinkId INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 
	
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Tips and tools'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='ProvideFeedback'

SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = @ContextName 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
-------------------------------------------------------------------------------------------------------------
--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'Feedback'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'ContactDetails'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
				
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'TravelInformation'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'ProvideFeedback.TourismInformation'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
				
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

GO

-----------------------------------------------------------------
------------------------------------------------------------
-- Add to the context - so it displays on the pages for homepage menu
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'HomePageMenuTipsAndTools'
SET @ContextDescription = 'Links for expandable menu on the Tips and Tools pages.'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@SubRootLinkId INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 
	
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Tips and tools'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='ProvideFeedback'

SELECT @SubRootLinkId = SuggestionLink.SuggestionLinkId
	FROM SuggestionLink
		INNER JOIN ContextSuggestionLink
			ON ContextSuggestionLink.SuggestionLinkId = SuggestionLink.SuggestionLinkId
		INNER JOIN Context 
			ON Context.ContextId = ContextSuggestionLink.ContextId
		WHERE Context.[Name] = @ContextName 
			AND SuggestionLink.LinkCategoryID = @LinkCategoryID
			AND SuggestionLink.ResourceNameID = @ResourceNameID
-------------------------------------------------------------------------------------------------------------
--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'Feedback'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
				
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId


-- Link 2
SET @LinkResourceName = 'ContactDetails'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
				
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 3
SET @LinkResourceName = 'TravelInformation'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

-- Link 4
SET @LinkResourceName = 'ProvideFeedback.TourismInformation'
SET @LinkCategoryID = 8
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID
				AND SubRootLinkId = @SubRootLinkId )
				
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 754
SET @ScriptDesc = 'Added Provide Feedback second level menu in tips and tools menu'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
