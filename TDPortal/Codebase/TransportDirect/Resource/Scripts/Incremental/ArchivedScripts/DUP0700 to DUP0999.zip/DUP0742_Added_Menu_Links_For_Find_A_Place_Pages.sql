-- ***********************************************
-- NAME 		: DUP0742_Added_Menu_Links_For_Find_A_Place_Pages.sql
-- DESCRIPTION 	: Menu links for Find A Place pages
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

EXEC AddInternalSuggestionLink 
	NULL,
	'Find a place', 
	'FindAPlace', 
	'Find a place', 
	'Canfyddwch le', 
	'Find a place', 
	3000, 
	1, 
	'HomePageMenuFindAPlace', 
	'Links for expandable menu on the Find A Place pages.'
GO

EXEC AddInternalSuggestionLink 
	'Maps/JourneyPlannerLocationMap.aspx', 
	'Find a map', 
	'FindAMap', 
	'Find a map', 
	'Darganfyddwch fap', 
	'Find a place', 
	3010, 
	0, 
	'HomePageMenuFindAPlace', 
	'Links for expandable menu on the Find A Place pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindAStationInput.aspx', 
	'Find nearest station/airport', 
	'FindNearestStation/Airport', 
	'Find nearest station/airport', 
	'Dod o hyd i''r orsaf/maes awyr agosaf', 
	'Find a place', 
	3020, 
	0, 
	'HomePageMenuFindAPlace',
	'Links for expandable menu on the Find A Place pages.'
GO

EXEC AddInternalSuggestionLink 
	'JourneyPlanning/FindCarParkInput.aspx', 
	'Find Nearest Car Park Input Page', 
	'FindNearestCarPark', 
	'Find nearest car park', 
	'Darganfyddwch y maes parcio agosaf', 
	'Find a place', 
	3030, 
	0, 
	'HomePageMenuFindAPlace', 
	'Links for expandable menu on the Find A Place pages.'
GO

EXEC AddInternalSuggestionLink 
	'Maps/NetworkMaps.aspx', 
	'Traffic levels', 
	'NetworkMaps', 
	'Transport network maps', 
	'Mapiau rhwydwaith', 
	'Find a place', 
	3040, 
	0, 
	'HomePageMenuFindAPlace', 
	'Links for expandable menu on the Find A Place pages.'
GO

EXEC AddInternalSuggestionLink 
	'Maps/TrafficMaps.aspx', 
	'Network maps', 
	'TrafficLevels', 
	'Traffic levels', 
	'Lefelau traffig', 
	'Find a place', 
	3050, 
	0, 
	'HomePageMenuFindAPlace', 
	'Links for expandable menu on the Find A Place pages.'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 742
SET @ScriptDesc = 'Menu links for Find A Place pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------