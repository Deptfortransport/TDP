-- *************************************************************************************
-- NAME 		: DUP0808_Add_dummy_soft_content_for_co2_emissions_page.sql
-- DESCRIPTION  	: Adds dummy soft content to CO2 emissions page
-- AUTHOR		: Dan Gath
-- *************************************************************************************


USE [Content]
GO


-- Add dummy soft content to CO2 emissions page
update tblGroup set Name='journeyplanning_journeyemissionscompare' where GroupId='30'
update tblContent set [Value-EN]='<DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>', [Value-CY]='cy- <DIV class="PageSoftContentContainer">  <DIV class="PageSoftContent"><H1>[Dummy Content]</H1><P>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Type of Transport (choose which mode(s) of transport you would like to use for your journey)</li><li>Public Transport journey details (choose your options for interchanging between modes of transport - would you prefer direct journeys only, how fast do you want to want?)</li><li>Car journey details (choose the type of journey you want to see - such as quickest or cheapest - as well as the roads you would like to use or avoid)</li></DIV></DIV>' where ContentId='66161'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 808
SET @ScriptDesc = 'Adds dummy soft content to CO2 emissions page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
