-- ************************************************************
-- NAME 	: DUP0732_Create_Content_Database.sql
-- DESCRIPTION 	: Creates Content database
-- ************************************************************
--

/* Create the content system database */
IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'Content')
	DROP DATABASE [Content]
GO

CREATE DATABASE [Content]  ON (NAME = N'Content_Data', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL\Data\content_Data.MDF' , SIZE = 24, FILEGROWTH = 10%) LOG ON (NAME = N'Content_Log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL\Data\content_Log.LDF' , SIZE = 26, FILEGROWTH = 10%)
 COLLATE SQL_Latin1_General_CP1_CI_AS
GO

exec sp_dboption N'Content', N'autoclose', N'false'
GO

exec sp_dboption N'Content', N'bulkcopy', N'false'
GO

exec sp_dboption N'Content', N'trunc. log', N'false'
GO

exec sp_dboption N'Content', N'torn page detection', N'true'
GO

exec sp_dboption N'Content', N'read only', N'false'
GO

exec sp_dboption N'Content', N'dbo use', N'false'
GO

exec sp_dboption N'Content', N'single', N'false'
GO

exec sp_dboption N'Content', N'autoshrink', N'false'
GO

exec sp_dboption N'Content', N'ANSI null default', N'false'
GO

exec sp_dboption N'Content', N'recursive triggers', N'false'
GO

exec sp_dboption N'Content', N'ANSI nulls', N'false'
GO

exec sp_dboption N'Content', N'concat null yields null', N'false'
GO

exec sp_dboption N'Content', N'cursor close on commit', N'false'
GO

exec sp_dboption N'Content', N'default to local cursor', N'false'
GO

exec sp_dboption N'Content', N'quoted identifier', N'false'
GO

exec sp_dboption N'Content', N'ANSI warnings', N'false'
GO

exec sp_dboption N'Content', N'auto create statistics', N'true'
GO

exec sp_dboption N'Content', N'auto update statistics', N'true'
GO

if( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) )
	exec sp_dboption N'Content', N'db chaining', N'false'
GO

use [Content]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sprGetContent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sprGetContent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblContent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblContent]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblGroup]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblGroup]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tblTheme]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tblTheme]
GO

CREATE TABLE [dbo].[tblContent] (
	[ContentId] [int] IDENTITY (1, 1) NOT NULL ,
	[ThemeId] [int] NOT NULL ,
	[GroupId] [int] NOT NULL ,
	[ControlName] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PropertyName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Value-En] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Value-Cy] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblGroup] (
	[GroupId] [int] NOT NULL ,
	[Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[tblTheme] (
	[ThemeId] [int] NOT NULL ,
	[Name] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Domain] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO

-------------------------------------------------
-- Insert the default transport direct theme
-------------------------------------------------

INSERT INTO
	tblTheme
	(
		ThemeId,
		[Name],
		[Domain]
	)
VALUES
(	
	1,
	'TransportDirect',
	'www.TransportDirect'
)

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



-- =============================================
-- Author:		Steve Barker
-- ALTER  date: 29 Nov 2007
-- Description:	Gets a set of content for a group and language
-- =============================================

CREATE  PROCEDURE [dbo].[sprGetContent] 
	-- Add the parameters for the stored procedure here
	@Theme varchar(100),
	@Group varchar(100),
	@Language char(5)

AS

BEGIN

--First look up the LanguageId, GroupId and ThemeId
--for the data passed. It is better to do two look 
--ups than perform lots of joins later on...
DECLARE 
@GroupId int,
@ThemeId int
	
--Check the language:
IF @Language NOT IN ('en-GB', 'cy-GB')
	BEGIN
	RAISERROR ('%s is an invalid language', 16, 1, @Language)
	END

--Look up the group:
SELECT 
	@GroupId = GroupId 
FROM 
	tblGroup
WHERE 
	[Name] = @Group

--Check the group:
--IF @GroupId IS NULL
--	BEGIN
--	RAISERROR ('%s is an invalid group', 16, 1, @Group)
--	END

--Look up the theme:
SELECT 
	@ThemeId = ThemeId 
FROM 
	tblTheme
WHERE 
	[Name] = @Theme

--Check the theme:
IF @ThemeId IS NULL
	BEGIN
	RAISERROR ('%s is an invalid theme', 16, 1, @Theme)
	END

--Now select the correct content.
--The first part of the query gets all content for the theme, group and language
SELECT 
	ControlName,
	PropertyName,
	CASE @Language
		WHEN 'en-GB' THEN [Value-en]
		WHEN 'cy-GB' THEN [Value-cy]
	END	AS [Value]
FROM 
	tblContent
WHERE 
	ThemeId = @ThemeId 
		AND
	GroupId = @GroupId
--The second part of the query adds items that exist in the transport direct 
--theme that are missing from the theme specified, to ensure there is a full
--set of data.
UNION ALL
(
	SELECT 
		ControlName,
		PropertyName,
		CASE @Language
			WHEN 'en-GB' THEN [Value-en]
			WHEN 'cy-GB' THEN [Value-cy]
		END AS [Value]
	FROM 
		tblContent
	WHERE 
		[ControlName] + '|' + [PropertyName] IN
		(
			SELECT DISTINCT 
				[ControlName] + '|' + [PropertyName]
			FROM 
				tblContent 
			WHERE 
				--1 is the TransportDirect ThemeId
				ThemeId = 1 
					AND 
				GroupId = @GroupId						
					AND
				[ControlName] + '|' + [PropertyName] NOT IN
				(
					SELECT 
						[ControlName] + '|' + [PropertyName]
					FROM 
						tblContent
					WHERE 
						ThemeId = @ThemeId
							AND
						GroupId = @GroupId
				)
		)
			AND 
		ThemeId = 1 
			AND 
		GroupId = @GroupId
)		

END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

/* insert connection string */

use permanentportal
go
DELETE FROM [PROPERTIES] WHERE [PNAME]= 'ContentDB'
GO
INSERT INTO Properties (PNAME, PVALUE, AID, GID, PARTNERID) VALUES ('ContentDB','Server=.;Database=Content;Trusted_Connection=Yes;','<DEFAULT>','<DEFAULT>',0)
GO

USE [Content]
GO

--------------------------------------------
--Create indices
-------------------------------------------

ALTER TABLE [dbo].[tblGroup] WITH NOCHECK ADD 
	CONSTRAINT [IX_tblGroup_Name] UNIQUE  CLUSTERED 
	(
		[Name]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblTheme] WITH NOCHECK ADD 
	CONSTRAINT [IX_tblTheme_Name] UNIQUE  CLUSTERED 
	(
		[Name]
	)  ON [PRIMARY] 
GO

CREATE  UNIQUE  CLUSTERED  INDEX [IX_tblContent_ThemeId_GroupId_ControlName_PropertyName] ON [dbo].[tblContent]([ThemeId], [GroupId], [ControlName], [PropertyName]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[tblGroup] ADD 
	CONSTRAINT [PK_tblGroup] PRIMARY KEY  NONCLUSTERED 
	(
		[GroupId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblTheme] ADD 
	CONSTRAINT [PK_tblTheme] PRIMARY KEY  NONCLUSTERED 
	(
		[ThemeId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblContent] ADD 
	CONSTRAINT [PK_tblContent] PRIMARY KEY  NONCLUSTERED 
	(
		[ContentId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[tblContent] ADD 
	CONSTRAINT [FK_tblContent_tblGroup] FOREIGN KEY 
	(
		[GroupId]
	) REFERENCES [dbo].[tblGroup] (
		[GroupId]
	) ON DELETE CASCADE  ON UPDATE CASCADE ,
	CONSTRAINT [FK_tblContent_tblTheme] FOREIGN KEY 
	(
		[ThemeId]
	) REFERENCES [dbo].[tblTheme] (
		[ThemeId]
	) ON DELETE CASCADE  ON UPDATE CASCADE 
GO

--------------------------------------------
--Delete Existing procedure if any
-------------------------------------------
IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'Content' 
              AND ROUTINE_NAME = 'AddtblContent' )
BEGIN
    DROP PROCEDURE [AddtblContent]
END
GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'Content' 
              AND ROUTINE_NAME = 'sprGetThemeDomains' )
BEGIN
    DROP PROCEDURE [sprGetThemeDomains]
END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
CREATE PROCEDURE dbo.[AddtblContent]
(
	@themeId int,
	@groupId int,
	@controlName varchar(500),
	@propertyName varchar(100),
	@valueEn text,
	@valueCy text
)
AS
BEGIN
	If Exists (Select * from [dbo].tblContent where tblContent.PropertyName = @propertyName And 					tblContent.ControlName = @controlName And tblContent.ThemeId = @themeId And 					tblContent.GroupId = @groupId )
    	   Begin
	 	Delete From [dbo].tblContent where tblContent.PropertyName =  @propertyName And 					tblContent.ControlName = @controlName And tblContent.ThemeId = @themeId And 					tblContent.GroupId = @groupId
    	   End
    	Insert into [dbo].tblContent (ThemeId, GroupId, ControlName, PropertyName, [Value-En], [Value-Cy])
        Values (@themeId, @groupId, @controlName, @propertyName, @valueEn, @valueCy)


END
GO

-- =============================================
-- Author:		Steve Barker
-- ALTER  date: 18 Feb 2008
-- Description:	Gets a list of themes and domain names
-- =============================================

CREATE PROCEDURE sprGetThemeDomains AS

SELECT
	[ThemeId],
	[Name],
	[Domain]	
FROM
	tblTheme
ORDER BY
	[Name]
GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 732
SET @ScriptDesc = 'Creates Content database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO