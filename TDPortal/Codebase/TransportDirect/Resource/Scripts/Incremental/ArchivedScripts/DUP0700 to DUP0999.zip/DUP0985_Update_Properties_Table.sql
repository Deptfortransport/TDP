-- ************************************************************
-- NAME 		: DUP0985_Update_Properties_Table.sql
-- DESCRIPTION 		: Updates pValue within properties table
-- AUTHOR		: S Johal
-- ************************************************************
USE PermanentPortal
GO

IF EXISTS (SELECT * FROM [dbo].[Properties] WHERE pName='DataServices.DataNotification.Groups')
  BEGIN
    UPDATE [dbo].[Properties]
    set [PValue]='Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LatestNewsService,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare,ZonalServiceCatalogue,ZonalAccessibilityCatalogue' where (pName='DataServices.DataNotification.Groups') AND ((AID='<DEFAULT>') OR (AID='EnhancedExposedServices'))
  END
  GO

IF EXISTS (SELECT * FROM [dbo].[Properties] WHERE pName='DataServices.DataNotification.ExternalLinks.Tables')
  BEGIN
    UPDATE [dbo].[Properties]
    set [PValue]='ExternalLinks,ZonalStop,ZonalAccessibility' where pName='DataServices.DataNotification.ExternalLinks.Tables'
  END
  GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 985
SET @ScriptDesc = 'Updates pValue within properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-----------------------------------------------------------------