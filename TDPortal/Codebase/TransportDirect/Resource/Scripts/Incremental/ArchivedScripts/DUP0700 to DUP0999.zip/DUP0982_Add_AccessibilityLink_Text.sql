-- ***********************************************
-- NAME 		: DUP0982_Add_AccessibilityLink_Text.sql
-- DESCRIPTION 		: Add text for Accessibility Link			: 
-- AUTHOR		: Sanjeev Johal
-- ************************************************

Use Content
go

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyDetails.accessibilityLink.Text', 'Accessibility information relating to this service', 'CY Accessibility information relating to this service'


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 982
SET @ScriptDesc = 'Add text for Accessibility Link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------