-- ***********************************************
-- NAME 		: DUP0863_Toolbar_Download_Location_Update.sql
-- DESCRIPTION 		: Toolbar Download file location update
-- AUTHOR		: Amit Patel
-- DATE			: 29 Mar 2008 10:24:00
-- ************************************************

-----------------------------------------------------------------------
-- Properties 
-----------------------------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ThemeId INT
SET @ThemeId = 1



IF not exists (select top 1 * from properties where pName = 'Web.ToolbarDownloadFileName.English' and ThemeId = @ThemeId)
BEGIN
	insert into properties values ('Web.ToolbarDownloadFileName.English', '\web2\downloads\TDToolbarEnglish.exe', 'Web', 'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = '\web2\downloads\TDToolbarEnglish.exe'
	where pname = 'Web.ToolbarDownloadFileName.English' and ThemeId = @ThemeId
END


IF not exists (select top 1 * from properties where pName = 'Web.ToolbarDownloadFileName.Welsh' and ThemeId = @ThemeId)
BEGIN
	insert into properties values ('Web.ToolbarDownloadFileName.Welsh', '\web2\downloads\TDToolbarWelsh.exe', 'Web', 'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = '\web2\downloads\TDToolbarWelsh.exe'
	where pname = 'Web.ToolbarDownloadFileName.Welsh' and ThemeId = @ThemeId
END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 863
SET @ScriptDesc = 'Toolbar Download file location update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO