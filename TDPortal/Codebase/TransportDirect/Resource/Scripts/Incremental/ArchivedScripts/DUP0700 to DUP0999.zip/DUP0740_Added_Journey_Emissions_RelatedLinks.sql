-- ***********************************************
-- NAME 		: DUP0740_Added_Journey_Emissions_RelatedLinks.sql
-- DESCRIPTION 	: Added Journey Emissions and Journey Emissions Compare page related links
-- AUTHOR		: apatel
-- ************************************************
USE TransientPortal
GO

-------------------------------------------------------------------------
-- Journey Emissions Compare Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextJourneyEmissionsCompare'
SET @ContextDescription = 'Related Link Context - Suggestions for Journey Emissions Compare Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO

-- Related links for specific pages/contexts
EXEC AddExternalSuggestionLink
	'JourneyEmissions.OffsetCarbonEmissions',
	'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm',
	'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm',
	'Offset Carbon Emissions',
	'JourneyEmissions.OffsetCarbonEmissions',
	'How can I offset my car''s carbon emissions?',
	'Sut y gallaf wneud rhywfaint o iawn am allyriadau carbon fy nghar?',
	'Related links',
	1380,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.CompareFuelEfficiency',
	'http://www.vcacarfueldata.org.uk/search/search.asp',
	'http://www.vcacarfueldata.org.uk/search/search.asp',
	'Compare Fuel Efficiency',
	'JourneyEmissions.CompareFuelEfficiency',
	'Compare fuel efficiency of different models of car',
	'Cymharwch effeithlonrwydd tanwydd gwahanol fodelau ceir',
	'Related links',
	1390,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.FuelSavingTips',
	'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption',
	'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption',
	'Fuel Saving Tips',
	'JourneyEmissions.FuelSavingTips',
	'RAC''s fuel saving tips',
	'Awgrymiadau arbed tanwydd RAC',
	'Related links',
	1400,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'
	
EXEC AddExternalSuggestionLink
	'JourneyEmissions.MotoringAndEnvironment',
	'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R',
	'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R',
	'Motoring and Environment',
	'JourneyEmissions.MotoringAndEnvironment',
	'Motoring and the environment',
	'Moduro a''r amgylchedd',
	'Related links',
	1410,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.Flying',
	'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429',
	'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429',
	'Flying',
	'JourneyEmissions.Flying',
	'What about the CO2 from flying?',
	'Beth am y CO2 wrth hedfan?',
	'Related links',
	1420,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.PT.AirPollutants',
	'http://www.naei.org.uk/index.php',
	'http://www.naei.org.uk/index.php',
	'Emissions of Air Pollutants in the UK',
	'JourneyEmissions.PT.AirPollutants',
	'Emissions of Air Pollutants in the UK',
	'Allyriadau Llygryddion Aer yn y DU',
	'Related links',
	1430,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.ActOnCo2',
	'http://www.dft.gov.uk/ActOnCO2/',
	'http://www.dft.gov.uk/ActOnCO2/',
	'Act On CO2',
	'JourneyEmissions.ActOnCo2',
	'Act on CO2',
	'Gweithredu ynghylch CO2',
	'Related links',
	1440,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'


EXEC AddExternalSuggestionLink
	'JourneyEmissions.Co2Railway',
	'http://www.atoc-comms.org/dynamic/publication.php?publication=15',
	'http://www.atoc-comms.org/dynamic/publication.php?publication=15',
	'CO2 on Railways',
	'JourneyEmissions.Co2Railway',
	'CO2 emissions on the railway',
	'Allyriadau CO2 ar y rheilffordd',
	'Related links',
	1450,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'

EXEC AddInternalSuggestionLink 
	'About/RelatedSites.aspx#CarSharing',
	'Related Sites - Car sharing',
	'JourneyEmissions.RelatedSitesCarSharing',
	'How can I find information on car sharing?',
	'Sut allaf i gael gafael ar wybodaeth ar rannu ceir?',
	'Related links',
	1460,
	0,
	'RelatedLinksContextJourneyEmissionsCompare',
	'Related Link Context - Suggestions for Journey Emissions Compare Page'
GO

-------------------------------------------------------------------------
-- Journey Emissions Compare Journey Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextJourneyEmissionsCompareJourney'
SET @ContextDescription = 'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO

-- Related links for specific pages/contexts
EXEC AddExternalSuggestionLink
	'JourneyEmissions.OffsetCarbonEmissions',
	'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm',
	'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm',
	'Offset Carbon Emissions',
	'JourneyEmissions.OffsetCarbonEmissions',
	'How can I offset my car''s carbon emissions?',
	'Sut y gallaf wneud rhywfaint o iawn am allyriadau carbon fy nghar?',
	'Related links',
	1550,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.CompareFuelEfficiency',
	'http://www.vcacarfueldata.org.uk/search/search.asp',
	'http://www.vcacarfueldata.org.uk/search/search.asp',
	'Compare Fuel Efficiency',
	'JourneyEmissions.CompareFuelEfficiency',
	'Compare fuel efficiency of different models of car',
	'Cymharwch effeithlonrwydd tanwydd gwahanol fodelau ceir',
	'Related links',
	1560,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.FuelSavingTips',
	'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption',
	'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption',
	'Fuel Saving Tips',
	'JourneyEmissions.FuelSavingTips',
	'RAC''s fuel saving tips',
	'Awgrymiadau arbed tanwydd RAC',
	'Related links',
	1570,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'
	
EXEC AddExternalSuggestionLink
	'JourneyEmissions.MotoringAndEnvironment',
	'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R',
	'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R',
	'Motoring and Environment',
	'JourneyEmissions.MotoringAndEnvironment',
	'Motoring and the environment',
	'Moduro a''r amgylchedd',
	'Related links',
	1580,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.Flying',
	'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429',
	'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429',
	'Flying',
	'JourneyEmissions.Flying',
	'What about the CO2 from flying?',
	'Beth am y CO2 wrth hedfan?',
	'Related links',
	1590,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.PT.AirPollutants',
	'http://www.naei.org.uk/index.php',
	'http://www.naei.org.uk/index.php',
	'Emissions of Air Pollutants in the UK',
	'JourneyEmissions.PT.AirPollutants',
	'Emissions of Air Pollutants in the UK',
	'Allyriadau Llygryddion Aer yn y DU',
	'Related links',
	1600,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.ActOnCo2',
	'http://www.dft.gov.uk/ActOnCO2/',
	'http://www.dft.gov.uk/ActOnCO2/',
	'Act On CO2',
	'JourneyEmissions.ActOnCo2',
	'Act on CO2',
	'Gweithredu ynghylch CO2',
	'Related links',
	1610,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'


EXEC AddExternalSuggestionLink
	'JourneyEmissions.Co2Railway',
	'http://www.atoc-comms.org/dynamic/publication.php?publication=15',
	'http://www.atoc-comms.org/dynamic/publication.php?publication=15',
	'CO2 on Railways',
	'JourneyEmissions.Co2Railway',
	'CO2 emissions on the railway',
	'Allyriadau CO2 ar y rheilffordd',
	'Related links',
	1620,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'

EXEC AddInternalSuggestionLink 
	'About/RelatedSites.aspx#CarSharing',
	'Related Sites - Car sharing',
	'JourneyEmissions.RelatedSitesCarSharing',
	'How can I find information on car sharing?',
	'Sut allaf i gael gafael ar wybodaeth ar rannu ceir?',
	'Related links',
	1630,
	0,
	'RelatedLinksContextJourneyEmissionsCompareJourney',
	'Related Link Context - Suggestions for Journey Emissions Compare Journey Page'
GO


-------------------------------------------------------------------------
-- Journey Emissions Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT
	
SET @ContextName = 'RelatedLinksContextJourneyEmissions'
SET @ContextDescription = 'Related Link Context - Suggestions for Journey Emissions Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

--insert into ContextSuggestionLink table

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT
	
-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
GO

-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'Help/HelpCarbon.aspx#A12.1',
	'FAQ - Estimate car CO2 emissions',
	'JourneyEmissions.EstimateCarCO2Emissions',
	'How do you estimate my car''s CO2 emissions?',
	'Sut ydych chi''n amcangyfrif allyriadau CO2 fy nghar?',
	'Related links',
	1470,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'
GO

EXEC AddExternalSuggestionLink
	'JourneyEmissions.OffsetCarbonEmissions',
	'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm',
	'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm',
	'Offset Carbon Emissions',
	'JourneyEmissions.OffsetCarbonEmissions',
	'How can I offset my car''s carbon emissions?',
	'Sut y gallaf wneud rhywfaint o iawn am allyriadau carbon fy nghar?',
	'Related links',
	1480,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.CompareFuelEfficiency',
	'http://www.vcacarfueldata.org.uk/search/search.asp',
	'http://www.vcacarfueldata.org.uk/search/search.asp',
	'Compare Fuel Efficiency',
	'JourneyEmissions.CompareFuelEfficiency',
	'Compare fuel efficiency of different models of car',
	'Cymharwch effeithlonrwydd tanwydd gwahanol fodelau ceir',
	'Related links',
	1490,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.FuelSavingTips',
	'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption',
	'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption',
	'Fuel Saving Tips',
	'JourneyEmissions.FuelSavingTips',
	'RAC''s fuel saving tips',
	'Awgrymiadau arbed tanwydd RAC',
	'Related links',
	1500,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'
	
EXEC AddExternalSuggestionLink
	'JourneyEmissions.MotoringAndEnvironment',
	'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R',
	'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R',
	'Motoring and Environment',
	'JourneyEmissions.MotoringAndEnvironment',
	'Motoring and the environment',
	'Moduro a''r amgylchedd',
	'Related links',
	1510,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'

EXEC AddExternalSuggestionLink
	'JourneyEmissions.Flying',
	'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429',
	'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429',
	'Flying',
	'JourneyEmissions.Flying',
	'What about the CO2 from flying?',
	'Beth am y CO2 wrth hedfan?',
	'Related links',
	1520,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'


EXEC AddExternalSuggestionLink
	'JourneyEmissions.ActOnCo2',
	'http://www.dft.gov.uk/ActOnCO2/',
	'http://www.dft.gov.uk/ActOnCO2/',
	'Act On CO2',
	'JourneyEmissions.ActOnCo2',
	'Act on CO2',
	'Gweithredu ynghylch CO2',
	'Related links',
	1530,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'


EXEC AddInternalSuggestionLink 
	'About/RelatedSites.aspx#CarSharing',
	'Related Sites - Car sharing',
	'JourneyEmissions.RelatedSitesCarSharing',
	'How can I find information on car sharing?',
	'Sut allaf i gael gafael ar wybodaeth ar rannu ceir?',
	'Related links',
	1540,
	0,
	'RelatedLinksContextJourneyEmissions',
	'Related Link Context - Suggestions for Journey Emissions Page'
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 740
SET @ScriptDesc = 'Added Journey Emissions and Journey Emissions Compare page related links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------