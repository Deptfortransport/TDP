-- ************************************************************
-- NAME 		: DUP0835_Misc_updates_and_additions_to_text.sql
-- DESCRIPTION 	: Misc_updates_and_additions_to_text
-- AUTHOR		: STsang
-- ************************************************************

USE Content
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyAdjust.newJourneyButton.Text',
'New Search',
'Ymchwil newydd'
GO

UPDATE tblContent
SET [Value-En] = 'Replace journey leg',
[Value-cy] = 'cy-Replace journey leg'
where ContentID = 56220
GO

INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
VALUES (67, 'journeyplanning_refinejourneyplan')
GO

EXEC AddtblContent
 1, 67, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/RefineJourneyPlan', '<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>','<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellSpacing="0" cellPadding="2" width="100%" border="0"><tbody><tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/app_themes/transportdirect/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">Transport Direct cannot currently display correct information about GNER, Hull Trains and Virgin Trains services passing directly between Doncaster and York. Please <A HREF="http://nationalrail.co.uk/service_bulletins/2d7b5d060a040002001e7002b4793dbd.html" Target="_Child">click here</A> for further information.</td></tr></tbody></table></div>'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'FindFlightInput.CommandBack.Text',
'Back',
'Yn �l'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarInput.CommandBack.Text',
'Back',
'Yn �l'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'FindCoachInput.CommandBack.Text',
'Back',
'Yn �l'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'FindBusInput.CommandBack.Text',
'Back',
'Yn �l'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'ParkAndRideInput.CommandBack.Text',
'Back',
'Yn �l'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'VisitPlannerInput.CommandBack.Text',
'Back',
'Yn �l'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainInput.CommandBack.Text',
'Back',
'Yn �l'
GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 835
SET @ScriptDesc = 'Misc_updates_and_additions_to_text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------