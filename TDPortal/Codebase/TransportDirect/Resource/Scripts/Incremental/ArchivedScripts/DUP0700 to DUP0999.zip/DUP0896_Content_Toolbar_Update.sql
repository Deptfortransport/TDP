-- ***********************************************
-- NAME 		: DUP0896_Content_Toolbar_Update.sql
-- DESCRIPTION 		: Script to update the content - Toolbar page
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Apr 2008 15:00:00
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 46, 'TDToolbarComingUpHtmlPlaceholderControl', '/Channels/TransportDirect/Tools/ToolbarDownload'
,'<P><STRONG>Installing the toolbar:</STRONG></P>  <P>Once you have clicked the "Download toolbar now" link:</P><BR>  <P>(1) Select "Open" or "Run" when prompted.<BR>(2) If you are prompted again, confirm that you want to run the software.<BR>(3) Restart your browser once the installation has completed and the toolbar is ready to use.</P><BR>  <P>If you experience problems during the installation, it may be because you do not have the necessary administrator rights, which are needed to install new software. In this case, please contact your IT department or vendor in order to install the toolbar.</P><BR>  <P><STRONG>Hiding the toolbar:</STRONG><BR>Once you have installed the toolbar, you can hide it at any time by selecting the following options on the main menu bar in Internet Explorer:<BR><BR>(1) select "View"<BR>(2) select "Toolbars"<BR>(3) untick "Transport Direct" toolbar<BR><STRONG><BR>Uninstalling the toolbar: </STRONG><BR>You can uninstall the toolbar from your PC in the same way as other programmes <BR><BR>'
,'<P><STRONG>Gosod y bar offer:</STRONG></P>  <P>Ar �l i chi glicio''r cyswllt ''Llawrlwythwch y bar offer yn awr'':</P><BR>  <P>(1) Dewiswch ''Agorwch'' neu ''Rhedeg'' pan gewch eich procio.<BR>(2) Os rhoddir proc i chi eto, cadarnhewch eich bod yn dymuno rhedeg y meddalwedd.<BR>(3) Ail-ddechreuwch eich porwr wedi i''r gosodiad gael ei gwblhau a bod y bar offer yn barod i''w ddefnyddio.</P><BR>  <P>Os cewch broblemau yn ystod y gosod, efallai fod hyn oherwydd nad oes gennych yr hawliau gweinyddu angenrheidiol, y mae''n rhaid eu cael i osod meddalwedd newydd. Os felly, cysylltwch �''ch adran TG neu''r gwerthwr i osod y bar offer.</P><BR>  <P><STRONG>Cuddio''r bar offer:</STRONG><BR>Wedi i chi roi''r bar offer ar eich system, gallwch ei guddio unrhyw bryd drwy ddewis y dewisiadau canlynol ar far y prif ddewislen yn Internet Explorer:<BR><BR>(1) dewiswch ""Edrychwch ar"<BR>(2) dewiswch "Bariau Offer"<BR>(3) dad-diciwch bar offer "Transport Direct"<BR><STRONG><BR>Tynnu''r bar offer oddi ar y system: </STRONG><BR>Gallwch dynnu''r bar offer oddi ar eich PC yn yr un modd � rhaglenni eraill <BR><BR>'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 896
SET @ScriptDesc = 'Script to clear out the duplicate homepage panel values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO