-- ***********************************************
-- NAME 		: DUP0929_RepeatVisitor_Properties.sql
-- DESCRIPTION 		: Script to add Repeat Visitor event property values
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 May 2008 18:00:00
-- ************************************************

USE [PermanentPortal]
GO


-- ****** IMPORTANT ******
-- 1) Where indicated, please change the value 'FILE1' value below to 'QUEUE1' for the Production environments
-- 2) There are 5 property values with an AID=InjectorEventReceiver commented out, I believe these are required 
--    for the Production environments. Please check and confirm before inserting
-- ***********************


------------------------------------------------------
-- Copy all the EventReceiver properties to an AID of EventReceiverJP. This is to allow the journey planners 
-- which are on .NET 1.1 to not use the new Repeat Visitor event.
-- THIS SECTION MUST ONLY BE RUN ONCE AS WE WILL HAVE CHANGED THE PROPERTY 'Logging.Event.Custom' TO INCLUDE THE NEW EVENT TYPE

IF not exists (select top 1 * from properties where AID = 'EventReceiverJP')
BEGIN

INSERT INTO [PermanentPortal].[dbo].[properties]
(
    [pName], 
    [pValue], 
    [AID], 
    [GID], 
    [PartnerId], 
    [ThemeId]
)
SELECT pName, 
       pValue, 
       'EventReceiverJP', 
       GID, 
       PartnerId, 
       ThemeId
  FROM properties
 WHERE (AID LIKE 'EventReceiver')

END



------------------------------------------------------
-- Update existing custom event properties to include the new REPEATVISITOR
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)
BEGIN
	update properties 
	set pvalue = 'LOC GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE JOURNEYWEBREQUEST GATE REFERENCETRANSACTION WORKLOAD ROE INTERNALREQUEST RTTI EXP STOPEVENT MOBILEPAGE LANDING EnhancedExposedServiceStartEvent EnhancedExposedServiceFinishEvent RTTIInternal'
	where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)
BEGIN
	update properties 
	set pvalue = 'LOC GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE JOURNEYWEBREQUEST GATE REFERENCETRANSACTION WORKLOAD ROE USERFEEDBACK INTERNALREQUEST RTTI EXP STOPEVENT MOBILEPAGE'
	where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
BEGIN
	update properties 
	set pvalue = 'EMAIL GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE GATE USERFEEDBACK LANDING'
	where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1
END


--IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'InjectorEventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)
--BEGIN
--	update properties 
--	set pvalue = 'LOC GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE JOURNEYWEBREQUEST GATE REFERENCETRANSACTION WORKLOAD ROE'
--	where pName = 'Logging.Event.Custom' and AID = 'InjectorEventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1
--END




------------------------------------------------------
-- Repeat Visitor setup
delete from properties where pname like 'Logging.Event.Custom.REPEATVISITOR.%'

-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Assembly', 'td.reportdataprovider.tdpcustomevents', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Name', 'RepeatVisitorEvent', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Trace', 'On', 'Web', 'UserPortal', 0, 1)

insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiver', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Name', 'RepeatVisitorEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)

insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Name', 'RepeatVisitorEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)

--insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Assembly', 'td.reportdataprovider.tdpcustomevents', 'InjectorEventReceiver', 'ReportDataProvider', 0, 1)
--insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Name', 'RepeatVisitorEvent', 'InjectorEventReceiver', 'ReportDataProvider', 0, 1)
--insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Publishers', 'TDPDB', 'InjectorEventReceiver', 'ReportDataProvider', 0, 1)
--insert into properties values ('Logging.Event.Custom.REPEATVISITOR.Trace', 'On', 'InjectorEventReceiver', 'ReportDataProvider', 0, 1)





------------------------------------------------------
-- Add Cookie expiry date property
IF not exists (select top 1 * from properties where pName = 'Cookie.ExpiryTimeSpan.Seconds')
BEGIN
	insert into properties values ('Cookie.ExpiryTimeSpan.Seconds', '15778463', 'Web', 'UserPortal', 0, 1)
END


------------------------------------------------------
-- Add User Agent properties
IF not exists (select top 1 * from properties where pName = 'Cookie.UserAgent.HeaderKey')
BEGIN
	insert into properties values ('Cookie.UserAgent.HeaderKey', 'User-Agent', 'Web', 'UserPortal', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'Cookie.UserAgent.Robot.Pattern')
BEGIN
	insert into properties values ('Cookie.UserAgent.Robot.Pattern', 'bot spider', 'Web', 'UserPortal', 0, 1)
END

IF not exists (select top 1 * from properties where pName = 'Cookie.UserAgent.Robot.RegularExpression')
BEGIN
	insert into properties values ('Cookie.UserAgent.Robot.RegularExpression', '', 'Web', 'UserPortal', 0, 1)
END


------------------------------------------------------
-- Repeat visitor switch
IF not exists (select top 1 * from properties where pName = 'Cookie.RepeatVisitor.Switch')
BEGIN
	insert into properties values ('Cookie.RepeatVisitor.Switch', 'True', 'Web', 'UserPortal', 0, 1)
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 929
SET @ScriptDesc = 'Repeat Visitor event properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO