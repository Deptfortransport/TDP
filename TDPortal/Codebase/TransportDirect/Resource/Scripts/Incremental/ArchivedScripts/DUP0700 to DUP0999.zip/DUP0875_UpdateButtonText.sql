-- 
-- NAME 		 DUP0875_UpdateButtonText.sql
-- DESCRIPTION 	 Script to update the text on the 'New Search' button on JourneyAdjust.aspx
-- AUTHOR		 Dan Gath
-- DATE			 3 Apr 2008 132000
-- 

-----------------------------------------------------
-- CONTENT
-----------------------------------------------------

USE [Content]
GO

update tblContent set [Value-En]='New Search',[Value-Cy]='Ymchwil newydd' where PropertyName='JourneyAdjust.newJourneyButton.Text'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 875
SET @ScriptDesc = 'Script to update the text on the ''New Search'' button on JourneyAdjust.aspx'

IF EXISTS (SELECT  FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO