-- *************************************************************************************
-- NAME 		: DUP0705_Add_Road_Type_Column_In_TravelNews_Table.sql
-- DESCRIPTION 		: Adds new column RoadType in TravelNews Table of Transient Portal
-- *************************************************************************************
USE [TransientPortal]
GO

----------------------------------------------------------------
-- New values for NewIncidentTypeDrop Dataset
----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('TravelNews')
						AND syscolumns.name = 'RoadType')

ALTER TABLE TravelNews ADD RoadType NVARCHAR(10) NULL
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 705
SET @ScriptDesc = 'Adds new column RoadType in TravelNews Table of Transient Portal'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
