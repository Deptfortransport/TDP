-- ***********************************************
-- NAME 		: DUP0825_DirectGov_1_Theme.sql
-- DESCRIPTION 		: Script to add a new Theme for a Partner - DirectGov
-- AUTHOR		: Mitesh Modi
-- DATE			: 10 Mar 2008 18:00:00
-- ************************************************

-- ************************************************
-- WARNING: PLEASE UPDATE THE @Domain value to be that for SITEST/BBP/ACP
-- ************************************************

-----------------------------------------------------------------------
-- Theme 
-----------------------------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT,
	@ThemeName varchar(100),
	@Domain varchar (1000)

SET @ThemeId = 5
SET @ThemeName = 'DirectGov'
SET @Domain = 'directgov.sitest.transportdirect.info'

-- Add the theme

IF NOT EXISTS (SELECT TOP 1 * FROM tblTheme WHERE ThemeId = @ThemeId)
BEGIN
	INSERT INTO tblTheme VALUES (@ThemeId, @ThemeName, @Domain)
END
ELSE
BEGIN
	UPDATE tblTheme 
	SET [Name] = @ThemeName, [Domain] = @Domain
	WHERE ThemeId = @ThemeId
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 825
SET @ScriptDesc = 'New theme added for DirectGov'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO