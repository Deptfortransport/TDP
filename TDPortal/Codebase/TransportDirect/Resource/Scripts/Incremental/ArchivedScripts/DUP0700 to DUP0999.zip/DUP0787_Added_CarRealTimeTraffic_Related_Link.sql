-- *************************************************************************************
-- NAME 		: DUP0787_Added_CarRealTimeTraffic_Related_Link.sql
-- DESCRIPTION  	: Added real time traffic related links 
-- AUTHOR		: Mitesh Modi
-- DATE			: 06 Mar 2008 18:00:00
-- *************************************************************************************


USE TransientPortal
GO

------------------------------------------------------------
-- Add the External links we want
------------------------------------------------------------
DECLARE @ExternalLinkID varchar(500),
	@URL varchar(500),
	@TestURL varchar(500),
	@Valid bit,
	@Description varchar(200),
	@StartDate datetime,
	@EndDate datetime,
	@LinkText varchar(200)

SET @ExternalLinkID = 'RealTimeTraffic'
SET @URL = 'http://www.realtime-traffic.info/'
SET @TestURL = 'http://www.realtime-traffic.info/'
SET @Valid = '1'
SET @Description = 'Realtime traffic'
SET @StartDate = NULL
SET @EndDate = NULL
SET @LinkText = 'www.realtime-traffic.info'

IF NOT EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = @ExternalLinkID)
BEGIN
	INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
	VALUES (@ExternalLinkID, @URL, @TestURL, @Valid, @Description, @StartDate, @EndDate, @LinkText)
END
ELSE
BEGIN
	UPDATE [dbo].[ExternalLinks]
	SET URL = @URL, TestURL = @TestURL, Valid = @Valid, [Description] = @Description, StartDate = @StartDate, EndDate = @EndDate, [LinkText] = @LinkText
	WHERE [Id] = @ExternalLinkID
END

-- Insert in to the externalsuggestion link table
IF NOT EXISTS(SELECT * FROM [ExternalSuggestionLink] WHERE [ExternalLinkID] = @ExternalLinkID)
	INSERT INTO [ExternalSuggestionLink] ([ExternalLinkID])
	VALUES (@ExternalLinkID)
GO

-------------------------------------------------------------------------
-- Adding Resource for Real time traffic Link
-------------------------------------------------------------------------

-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT

-- Link for Disablity Link
SET @LinkResourceName = 'RealTimeTraffic'
SET @LinkResourceNameEN = 'Real time traffic'
SET @LinkResourceNameCY = 'cy Real time traffic'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

GO
	
--insert into SuggestionLink table
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100),
	@ResourceNameID INT


-------------------------------------------------------------------------
-- Add Internal link for the related link, should already be there but to ensure script is rerunable,independent
-------------------------------------------------------------------------
-- Add the internal links for related link
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link 10 (INTERNAL)

SET @InternalLinkDescription = 'Related Links'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , NULL, @InternalLinkDescription

-------------------------------------------------------------------------
-- Add suggestion links
-------------------------------------------------------------------------
-- Link 1 for Related Links link
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @LinkPriority = 1000
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1,0,0


-- Link 2 for Real time traffic link
SET @LinkResourceName = 'RealTimeTraffic'
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @LinkPriority = 1640
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select ExternalSuggestionLinkID from [dbo].[ExternalSuggestionLink] where ExternalLinkID = @LinkResourceName)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot],[IsSubRootLink],[SubRootLinkId])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'External', 0,0,0
GO


 
-----------------------------------------------------------------------------------------------------
-- Real time link for Find Car Park Results page - Journey Summary
-----------------------------------------------------------------------------------------------------
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextJourneySummaryFindCarRoute'
SET @ContextDescription = 'Related Link Context - Suggestions for Find a car Journey Summary page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

-- Link 1 Related Link
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId
	
-- Link 2 for Real time traffic context suggestion link

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Related links'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='RealTimeTraffic'

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

GO
-----------------------------------------------------------------------------------------------------
-- End Real time link for Find Car Park Results page - Journey Summary
-----------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------
-- Real time link for Find Car Park Results page - Journey Details
-----------------------------------------------------------------------------------------------------
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextJourneyDetailsFindCarRoute'
SET @ContextDescription = 'Related Link Context - Suggestions for Find a car Journey Details page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId
	
-- Link 2 for Disability context suggestion link

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Related links'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='RealTimeTraffic'

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

GO
-----------------------------------------------------------------------------------------------------
-- End Real time link for Find Car Park Results page - Journey Details
-----------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------
-- Real time link for Traffic Maps page
-----------------------------------------------------------------------------------------------------
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextTrafficMaps'
SET @ContextDescription = 'Related Link Context - Suggestions for Traffic Maps page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END

DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT,
	@ThemeId INT

EXEC [Content].[dbo].[GetDefaultThemeId] @ThemeId OUTPUT 

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId
	
-- Link 2 for Disability context suggestion link

SELECT @LinkCategoryID = LinkCategoryId FROM LinkCategory WHERE [Name] = 'Related links'

SELECT @ResourceNameID = ResourceNameId FROM ResourceName WHERE ResourceName='RealTimeTraffic'

SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId],[ThemeId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID, @ThemeId

GO
-----------------------------------------------------------------------------------------------------
-- End Real time link for Traffic Maps page
-----------------------------------------------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 787
SET @ScriptDesc = 'Added Rwealtime traffic link to related links on the pages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
