-- ***********************************************
-- NAME 		: DUP0997_DoesTicketExist.sql
-- DESCRIPTION 		: Script to add doesticketexist stored proc
-- AUTHOR		: James Chapman
-- DATE			: 26 June 2008 18:00:00
-- ************************************************

USE [TransientPortal]
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'DoesTicketExist')
	BEGIN
		DROP  Procedure  DoesTicketExist
	END

GO

CREATE Procedure DoesTicketExist
	(
		@TicketTypeCode VarChar(10)
	)
AS

if exists(Select * From TicketTypeDescription Where TicketTypeCode =  @TicketTypeCode)
	SELECT 1 AS 'RecordFound'
ELSE
	SELECT 0 AS 'RecordFound'
		
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 997
SET @ScriptDesc = 'Script to add doesticketexist stored proc'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO




 