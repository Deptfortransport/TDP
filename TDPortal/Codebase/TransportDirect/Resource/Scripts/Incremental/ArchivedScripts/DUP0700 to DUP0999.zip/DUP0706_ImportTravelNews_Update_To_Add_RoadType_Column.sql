-- ************************************************************
-- NAME 	: DUP0706_ImportTravelNews_Update_To_Add_RoadType_Column
-- DESCRIPTION 	: Updated ImportTravelNews stored procedure to include new RoadType column
-- ************************************************************

USE [TransientPortal]
GO

---------------------------------------------------------------------
-- Update TravelNewsAll
----------------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE dbo.ImportTravelNews
	@XML text
AS
SET NOCOUNT ON
SET XACT_ABORT ON

BEGIN TRANSACTION

DECLARE @DocID int
DECLARE @Version varchar(20)
DECLARE @RowCount int

EXEC sp_xml_preparedocument @DocID OUTPUT, @XML

SET @Version = NULL

SELECT TOP 1
	@Version = Version
FROM
OPENXML (@DocID, '/TrafficAndTravelNewsData', 2)
WITH
(
	Version varchar(50) '@version'
)

IF @Version IS NULL OR @Version <> 'IF00905'
BEGIN
	EXEC sp_xml_removedocument @DocID
	RAISERROR('The stored procedure ImportTravelNews did not recognise the given XML file version.', 11, 1)
END
ELSE
BEGIN
	SET @RowCount = 0

	DELETE FROM TravelNewsDataSource
	DELETE FROM TravelNewsRegion
	DELETE FROM TravelNews

	INSERT INTO TravelNews
	(
		UID,
		SeverityLevel,
		PublicTransportOperator,
		ModeOfTransport,
		Location,
		IncidentType,
		HeadlineText,
		DetailText,
		IncidentStatus,
		Easting,
		Northing,
		ReportedDateTime,
		StartDateTime,
		LastModifiedDateTime,
		ClearedDateTime,
		ExpiryDateTime,
		PlannedIncident,
		RoadType
	)
	SELECT DISTINCT
		X.UID,
		TNS.SeverityID,
		X.PublicTransportOperator,
		X.ModeOfTransport,
		X.Location,
		X.IncidentType,
		X.HeadlineText,
		X.DetailText,
		X.IncidentStatus,
		X.Easting,
		X.Northing,
		X.ReportedDateTime,
		X.StartDateTime,
		X.LastModifiedDateTime,
		X.ClearedDateTime,
		X.ExpiryDateTime,
		CASE PlannedIncident WHEN 'true' THEN 1 ELSE 0 END,
		X.RoadType
	FROM
	OPENXML (@DocID, '/TrafficAndTravelNewsData/Incident', 2)
	WITH
	(
		UID varchar(25) '@uid',
		SeverityLevel varchar(15) '@severity',
		PublicTransportOperator varchar(100) '@publicTransportOperator',
		ModeOfTransport varchar(50) '@modeOfTransport',
		Location varchar(100) '@location',
		IncidentType varchar(60) '@incidentType',
		HeadlineText varchar(150) '@headlineText',
		DetailText varchar(350) '@detailText',
		IncidentStatus varchar(1) '@incidentStatus',
		Easting decimal(18, 6) '@easting',
		Northing decimal(18, 6) '@northing',
		ReportedDateTime datetime '@reportedDatetime',
		StartDateTime datetime '@startDatetime',
		LastModifiedDateTime datetime '@lastModifiedDatetime',
		ClearedDateTime datetime '@clearedDatetime',
		ExpiryDateTime datetime '@expiryDatetime',
		PlannedIncident varchar(5) '@plannedIncident',
		RoadType varchar(10) '@roadType'
	) X
	INNER JOIN TravelNewsSeverity TNS ON X.SeverityLevel = TNS.SeverityDescription

	SET @RowCount = @@ROWCOUNT

	-- Regions for Incident
	INSERT INTO TravelNewsRegion
	(
		UID,
		RegionName
	)
	SELECT DISTINCT
		UID,
		CASE RegionName WHEN 'East' THEN 'East Anglia' ELSE RegionName END
	FROM
	OPENXML (@DocID, '/TrafficAndTravelNewsData/Incident/Region', 2)
	WITH
	(
		UID varchar(25) '@uid',
		RegionName varchar(50) '@regionName'
	)

	IF @@ROWCOUNT = 0
		SET @RowCount = 0

	UPDATE TravelNews
	SET Regions = ISNULL(TNR.Regions, '-')
	FROM TravelNews TN
	LEFT OUTER JOIN fn_TravelNewsRegion() TNR ON TN.UID = TNR.UID COLLATE database_default

	IF @@ROWCOUNT = 0
		SET @RowCount = 0


	-- Data Sources for Incident
	INSERT INTO TravelNewsDataSource
	(
		UID,
		DataSourceId
	)
	SELECT DISTINCT
		UID,
		DataSourceId
	FROM
		OPENXML (@DocID, '/TrafficAndTravelNewsData/Incident/IncidentDataSource', 2)
		WITH
		(
			UID varchar(25) '../@uid',
			DataSourceId varchar(50) 'text()'
		)


	EXEC sp_xml_removedocument @DocID
	

	IF @@ERROR<>0
	ROLLBACK TRANSACTION
	ELSE
	BEGIN
		COMMIT TRANSACTION		
		
		UPDATE ChangeNotification
		SET Version = Version + 1
		WHERE [Table] = 'TravelNewsImport'
	END
END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber =706
SET @ScriptDesc = 'Updated ImportTravelNews stored procedure to include new RoadType column'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
