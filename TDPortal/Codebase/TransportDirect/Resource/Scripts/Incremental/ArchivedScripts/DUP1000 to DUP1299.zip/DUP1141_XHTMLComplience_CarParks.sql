-- ***********************************************
-- NAME 		: DUP1141_XHTMLComplience_CarParks.sql
-- DESCRIPTION 		: Script to change entries in the Content DB for CCN474
-- AUTHOR		: Phil Scott
-- DATE			: 16 Oct 2008 
-- ************************************************

USE [Content]
GO




EXEC AddtblContent
1,
1,
'langStrings',
'HomeDefault.imageFindCarPark.AlternateText',
'Car parks',
'Maes parcio'


EXEC AddtblContent
1,
1,
'langStrings',
'FindCarParkResult.ErrorMessage.CarParkMode',
'Sorry we are currently unable to obtain any car parks using the details you have
entered. <a href="{0}" target="_blank"><b>Please click here to see a comprehensive
list of our sources of car park information (PDF)</b></a>.
<br><br>
If, having checked this list,�you believe there are public car parks that should have been
found by this search please help us to investigate this further by completing a feedback
form (do this by clicking "Contact us" at the bottom of the page).',
'Sorry we are currently unable to obtain any car parks using the details you have
entered. <a href="{0}" target="_blank"><b>Please click here to see a comprehensive
list of our sources of car park information (PDF)</b></a>.
<br><br>
If, having checked this list,�you believe there are public car parks that should have been
found by this search please help us to investigate this further by completing a feedback
form (do this by clicking "Contact us" at the bottom of the page).'



EXEC AddtblContent
1, 
33,
'carParksPlaceholderDefinition',
'/Channels/TransportDirect/JourneyPlanning/FindCarParkInput',
'<div class="Column3Header">
<div class="txtsevenbbl">Car Parks in Transport Direct</div>
</div>
<div class="Column3Content">
<table id="table1" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="txtseven">We can provide&nbsp; a comprehensive&nbsp;list of car parks near to your chosen location and then plan your car journey to the one you select. You can also use this function to find out details for each car park and to see on a map the location of the car park.</td></tr></tbody></table></div></div></div>',
''


EXEC AddtblContent
1, 
59,
'carParksPlaceholderDefinition',
'/Channels/TransportDirect/JourneyPlanning/FindCarParkInput',
'<div class="Column3Header">
<div class="txtsevenbbl">Car Parks in Transport Direct</div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>
<div class="Column3Content">
<table id="table1" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="txtseven">We can provide&nbsp; a comprehensive&nbsp;list of car parks near to your chosen 
location and then plan your car journey to the one you select. You can also use this function to find 
out details for each car park and to see on a map the location of the car park.</td></tr></tbody></table>
</div>',
'<div class="Column3Header">
<div class="txtsevenbbl">Car Parks in Transport Direct&nbsp;</div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>
<div class="Column3Content">
<table id="table1" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="txtseven">cy We can provide&nbsp; a comprehensive&nbsp;list of car parks near to your chosen 
location and then plan your car journey to the one you select. You can also use this function to find 
out details for each car park and to see on a map the location of the car park.</td></tr></tbody></table>
</div>'


----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1141
SET @ScriptDesc = 'Script to change entries in the Content DB for CCN474'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO