-- ***********************************************
-- NAME 		: DUP1098_RemoveRowFromTnC.sql
-- DESCRIPTION 		: Add Terms and Conditions content
-- AUTHOR		: D. Scott Angle
-- DATE			: 21 July 2008 13:00:00
-- ************************************************

USE [Content]

Delete
FROM         tblContent
WHERE     (PropertyName LIKE '%/Channels/TransportDirect/About/TermsConditions%') AND (ContentId = 74266) AND (ThemeId = 1) AND (GroupId = 20) AND 
                      (ControlName LIKE '%BodyText%')

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1098
SET @ScriptDesc = 'Remove unneeded row for T n Cs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO