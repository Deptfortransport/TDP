-- ***********************************************
-- NAME 		: DUP1182_CyclePlanner_Properties_4.sql
-- DESCRIPTION 		: Script to add properties required for Cycle Planning
-- AUTHOR		: Mark Turner
-- DATE			: 17 Nov 2008
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.InteractiveMapping.Map.MapTilesDefaultScale')
BEGIN
	insert into properties values ('CyclePlanner.InteractiveMapping.Map.MapTilesDefaultScale', '4000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '4000'
	where pname = 'CyclePlanner.InteractiveMapping.Map.MapTilesDefaultScale'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Location')
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Location', 'C:\CyclePlanner\Services\RoadInterfaceHostingService\td.cp.CyclePenaltyFunctions.v1.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'C:\CyclePlanner\Services\RoadInterfaceHostingService\td.cp.CyclePenaltyFunctions.v1.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Location'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Prefix')
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Prefix'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1182
SET @ScriptDesc = 'Script to add properties for Cycle Planning'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO