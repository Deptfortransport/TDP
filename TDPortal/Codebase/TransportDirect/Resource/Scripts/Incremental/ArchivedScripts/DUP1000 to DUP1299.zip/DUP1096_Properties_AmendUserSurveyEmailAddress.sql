-- ***********************************************
-- NAME 		: DUP1096_Properties_AmendUserSurveyEmailAddress.sql
-- DESCRIPTION 		: Script to amend email address for UserSurvey
-- AUTHOR		: Neil Rankin
-- DATE			: 12 August 2008 12:00
-- ************************************************

-----------------------------------------------------
-- Properties --
-----------------------------------------------------

USE [PermanentPortal]
Go

UPDATE dbo.properties SET
		pValue = 'TDPortal.Operations@dft.gsi.gov.uk' 
		WHERE pName = 'UserSurvey.EmailAddressTo'
Go


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1096
SET @ScriptDesc = 'Script to amend email address for UserSurvey'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO