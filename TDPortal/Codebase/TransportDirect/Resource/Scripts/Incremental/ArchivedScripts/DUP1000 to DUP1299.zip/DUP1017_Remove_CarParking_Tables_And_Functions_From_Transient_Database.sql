-- ***********************************************
-- NAME 	    : DUP1017_Remove_CarParking_Tables_And_Functions_From_Transient_Database.sql
-- DESCRIPTION 	: This will delete car Parking tables from Transient Portal if there are any tables in it
-- also remove the functions associated with it as they been created in CarParks Database.
--
--              : This script has been reintroduced as a copy of DUP0729_Remove_CarParking_Tables_And_Functions_From_Transient_Database.sql
--              : to ensure it is run on all environments
-- ************************************************


USE [TransientPortal]
GO


-----------------------------------------------
-- Remove CarParking table
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParking') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParking]
END
GO



-----------------------------------------------
-- Remove GetCarParkAccessPointData Stored Proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkAccessPointData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkAccessPointData]
END
GO

-----------------------------------------------
-- Remove ImportCarParkingData Stored Proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ImportCarParkingData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[ImportCarParkingData]
END
GO


-----------------------------------------------
-- Remove CarParkingOperator table
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOperator') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingOperator]
END
GO


-----------------------------------------------
-- Remove CarParkingTrafficNewsRegion
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingTrafficNewsRegion') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingTrafficNewsRegion]
END
GO

-----------------------------------------------
-- Remove CarParkingAccessPoints table
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAccessPoints') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE [dbo].[CarParkingAccessPoints]
GO

-----------------------------------------------
-- Remove CarParkingParkAndRideScheme
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingParkAndRideScheme') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE [dbo].[CarParkingParkAndRideScheme]
GO

-----------------------------------------------
-- Remove CarParkingNPTGAdminDistrict
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGAdminDistrict') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingNPTGAdminDistrict]
END
GO



-----------------------------------------------
-- Remove CarParkingCarParkCharges
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkCharges') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkCharges]
END
GO

-----------------------------------------------
--Remove CarParkingCarParkChargeType
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkChargeType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkChargeType]
END
GO

-----------------------------------------------
-- Remove CarParkingCarParkConcessions
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkConcessions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkConcessions]
END
GO



-----------------------------------------------
-- Remove CarParkingSpaceAvailability
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceAvailability') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingSpaceAvailability]
END
GO



-----------------------------------------------
-- Remove CarParkingAdditionalData table
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAdditionalData') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingAdditionalData]
END
GO

		
	
-----------------------------------------------
-- Remove CarParkingPaymentMethods
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentMethods') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingPaymentMethods]
END
GO


-----------------------------------------------
-- Remove CarParkingPaymentType
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingPaymentType]
END
GO

-----------------------------------------------
-- Remove CarParkingLinkedNaptans
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingLinkedNaPTANS') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingLinkedNaptans]
END
GO

-----------------------------------------------
-- Remove CarParkingAttractions
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingAttractions]
END
GO

		
-----------------------------------------------
-- Remove CarParkingOpeningTimes table
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOpeningTimes') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingOpeningTimes]
END
GO

-----------------------------------------------
-- Remove CarParkingFacilities
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilities') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingFacilities]
END
GO

----------------------------------------------
-- Remove CarParkAttractionType
----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractionType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingAttractionType]
END
GO



-----------------------------------------------
-- Remove CarParkingFacilitiesType
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilitiesType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingFacilitiesType]
END
GO



-----------------------------------------------
-- Remove CarParkingCarParkSpace
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkSpace') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkSpace]
END
GO



-----------------------------------------------
-- Remove CarParkingCalendar table
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCalendar') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCalendar]
END
GO


-----------------------------------------------
-- Remove CarParkingCarParkType
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingCarParkType]
END
GO



-----------------------------------------------
-- Remove CarParkingSpaceType
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingSpaceType]
END
GO


-----------------------------------------------
-- Remove CarParkingNPTGLocality
-----------------------------------------------	

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGLocality') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CarParkingNPTGLocality]
END
GO




-----------------------------------------------
-- Remove GetCarParkingData Stored Proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingData]
END
GO


-----------------------------------------------
-- Remove GetCarParkOperatorData Store proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkOperatorData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkOperatorData]
END
GO

--------------------------------------------------
-- Remove GetCarParkingParkAndRideData Stored Proc
--------------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingParkAndRideData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingParkAndRideData]
END
GO

-----------------------------------------------
-- Remove GetCarParkingRegionData Stored Proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingRegionData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingRegionData]
END
GO

-----------------------------------------------
-- Remove GetCarParkingAdminData Stored Proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkingAdminData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkingAdminData]
END
GO

-----------------------------------------------
-- Remove GetCarParkAccessPointData Stored Proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkAccessPointData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkAccessPointData]
END
GO

-----------------------------------------------
-- Remove GetCarParkAdditionalData Stored Proc
-----------------------------------------------

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[GetCarParkAdditionalData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
	DROP PROCEDURE [dbo].[GetCarParkAdditionalData]
END
GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1017
SET @ScriptDesc = 'Removal of CarParking tables and stored proc from TransientPortal Database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO