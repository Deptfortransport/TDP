-- ***********************************************
-- NAME 		: DUP1266_Search_Engine_Optimisation_Changes.sql
-- DESCRIPTION 		: Update content for Search Engine Optimisation
-- AUTHOR		: Amit Patel
-- DATE			: 29 January 2008
-- ************************************************

USE [Content]
GO

-- headings for mini home pages
EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.literalPageHeading',
'Journey Planners',
'Journey Planners'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTravelInfo.literalPageHeading',
'Live travel news &amp; departures',
'Live travel news &amp; departures'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.literalPageHeading',
'Tips and tools for travel planning',
'Tips and tools for travel planning'

GO

-- plan a journey  home page titles
EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.PageTitle',
'Route planners for public transport, car travel &amp; flights',
'Route planners for public transport, car travel &amp; flights'

EXEC AddtblContent
2, 1, 'langStrings', 'HomePlanAJourney.PageTitle',
'Visit Britain | Route planners for public transport, car travel &amp; flights',
'Visit Britain | Route planners for public transport, car travel &amp; flights'

EXEC AddtblContent
3, 1, 'langStrings', 'HomePlanAJourney.PageTitle',
'BBC | Route planners for public transport, car travel &amp; flights',
'BBC | Route planners for public transport, car travel &amp; flights'

EXEC AddtblContent
5, 1, 'langStrings', 'HomePlanAJourney.PageTitle',
'Directgov | Route planners for public transport, car travel &amp; flights',
'Directgov | Route planners for public transport, car travel &amp; flights'

GO

-- find a place home page titles
EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.PageTitle',
'Street Maps - Find local transport, car parks &amp; airports with Transport Direct',
'Street Maps - Find local transport, car parks &amp; airports with Transport Direct'

EXEC AddtblContent
2, 1, 'langStrings', 'HomeFindAPlace.PageTitle',
'Visit Britain | Street Maps - Find local transport, car parks &amp; airports with Transport Direct',
'Visit Britain | Street Maps - Find local transport, car parks &amp; airports with Transport Direct'

EXEC AddtblContent
3, 1, 'langStrings', 'HomeFindAPlace.PageTitle',
'BBC | Street Maps - Find local transport, car parks &amp; airports with Transport Direct',
'BBC | Street Maps - Find local transport, car parks &amp; airports with Transport Direct'

EXEC AddtblContent
5, 1, 'langStrings', 'HomeFindAPlace.PageTitle',
'Directgov | Street Maps - Find local transport, car parks &amp; airports with Transport Direct',
'Directgov | Street Maps - Find local transport, car parks &amp; airports with Transport Direct'

GO

-- live travel home page titles
EXEC AddtblContent
1, 1, 'langStrings', 'HomeTravelInfo.PageTitle',
'Live travel news &amp; traffic updates from Transport Direct',
'Live travel news &amp; traffic updates from Transport Direct'

EXEC AddtblContent
2, 1, 'langStrings', 'HomeTravelInfo.PageTitle',
'Visit Britain | Live travel news &amp; traffic updates from Transport Direct',
'Visit Britain | Live travel news &amp; traffic updates from Transport Direct'

EXEC AddtblContent
3, 1, 'langStrings', 'HomeTravelInfo.PageTitle',
'BBC | Live travel news &amp; traffic updates from Transport Direct',
'BBC | Live travel news &amp; traffic updates from Transport Direct'

EXEC AddtblContent
5, 1, 'langStrings', 'HomeTravelInfo.PageTitle',
'Directgov | Live travel news &amp; traffic updates from Transport Direct',
'Directgov | Live travel news &amp; traffic updates from Transport Direct'

GO

-- tools home page titles
EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.PageTitle',
'Travel tools and resources from Transport Direct',
'Travel tools and resources from Transport Direct'

EXEC AddtblContent
2, 1, 'langStrings', 'HomeTipsTools.PageTitle',
'Visit Britain | Travel tools and resources from Transport Direct',
'Visit Britain | Travel tools and resources from Transport Direct'

EXEC AddtblContent
3, 1, 'langStrings', 'HomeTipsTools.PageTitle',
'BBC | Travel tools and resources from Transport Direct',
'BBC | Travel tools and resources from Transport Direct'

EXEC AddtblContent
5, 1, 'langStrings', 'HomeTipsTools.PageTitle',
'Directgov | Travel tools and resources from Transport Direct',
'Directgov | Travel tools and resources from Transport Direct'

GO



-- help content for travel news page
EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.imageFindCarParkSkipLink.AlternateText',
'Skip to Find nearest car parks',
'cy Skip to Find nearest car parks'

GO


-- find a train input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainInput.labelFindTrainTitle',
'Train routes &amp; timetables',
'Train routes &amp; timetables'

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainInput.AppendPageTitle',
'Train timetables - rail travel planner | ',
'Train timetables - rail travel planner | '

GO

-- find a flight input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindFlightInput.AppendPageTitle',
'Find flight departures and arrivals | ',
'Find flight departures and arrivals | '

GO

-- find a car input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindCarInput.labelFindCarTitle',
'Car route finder',
'Car route finder'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarInput.AppendPageTitle',
'Car directions - Find a car route | ',
'Car directions - Find a car route | '

GO

-- find a coach input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindCoachInput.labelFindCoachTitle',
'Coach routes &amp; timetables',
'Coach routes &amp; timetables'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCoachInput.AppendPageTitle',
'Coach times & travel - Find a coach | ',
'Coach times & travel - Find a coach | '

GO

-- find trunk input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindTrunkInput.labelFindPageTitle',
'City to city journey comparison',
'City to city journey comparison'

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrunkInput.AppendPageTitle',
'City to city journeys - Compare trains, plane, coach & car | ',
'City to city journeys - Compare trains, plane, coach & car | '

GO

-- visit planner input page seo changes
EXEC AddtblContent
1, 1, 'VisitPlanner', 'VisitPlanner.AppendPageTitle',
'Day trip planner - Plan a journey to two locations in a day | ',
'Day trip planner - Plan a journey to two locations in a day | '

GO

-- park and ride input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'ParkAndRideInput.AppendPageTitle',
'Park &amp; Ride locator | ',
'Park &amp; Ride locator | '

GO

-- find bus input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindBusInput.labelFindBusTitle',
'Bus routes',
'Bus routes'

EXEC AddtblContent
1, 1, 'langStrings', 'FindBusInput.AppendPageTitle',
'Bus travel routes &amp; timetables - Find a bus | ',
'Bus travel routes &amp; timetables - Find a bus | '

GO

-- find car park input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkInput.labelFindCarParkTitle',
'Car park locator',
'Car park locator'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkInput.AppendPageTitle',
'Find a car park | ',
'Find a car park | '

GO

-- journey planner location map page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.lblFindAPlace',
'Maps for Great Britain',
'Maps for Great Britain'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlannerLocationMap.AppendPageTitle',
'Find a map - GB street maps | ',
'Find a map - GB street maps | '

GO

-- find a station input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindStationInput.labelTitle',
'Station and airport locator',
'Station and airport locator'

EXEC AddtblContent
1, 1, 'langStrings', 'FindAStationInput.AppendPageTitle',
'Find a station or airport - Station &amp; Airport Locator | ',
'Find a station or airport - Station &amp; Airport Locator | '

GO

-- traffic map page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'panelLocation.labelJourneys',
'Traffic maps for Great Britain',
'Traffic maps for Great Britain'

EXEC AddtblContent
1, 1, 'langStrings', 'TrafficMaps.AppendPageTitle',
'Traffic Map - Traffic level data | ',
'Traffic Map - Traffic level data | '

GO

-- toolbar download page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'ToolbarDownload.labelPageTitle.Text',
'Transport information toolbar',
'Transport information toolbar'

EXEC AddtblContent
1, 1, 'langStrings', 'ToolbarDownload.AppendPageTitle',
'Transport information toolbar - Travel tools | ',
'Transport information toolbar - Travel tools | '

GO

-- toolbar download page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'TDOnTheMove.AppendPageTitle',
'Mobile travel information - Mobile phone travel times | ',
'Mobile travel information - Mobile phone travel times | '

GO

-- journey emissions compare page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsCompare.Title',
'Co2 emmissions calculator',
'Co2 emmissions calculator'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsCompare.AppendPageTitle',
'CO2 emissions calculator - Check the CO2 from your journey | ',
'CO2 emissions calculator - Check the CO2 from your journey | '

GO

-- find train cost input page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainCostInput.labelFindTrainCostTitle',
'Cheaper rail travel',
'Cheaper rail travel'

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainCostInput.AppendPageTitle',
'Cheap rail travel - Find cheaper train fares | ',
'Cheap rail travel - Find cheaper train fares | '

GO

-- journey planner input page seo changes

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlannerInput.AppendPageTitle',
'Route planner - public transport and car journeys | ',
'Route planner - public transport and car journeys | '

GO

-- Home page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'Homepage.literalPageHeading',
'Live travel news, journey planning, train times and more',
'Live travel news, journey planning, train times and more'

EXEC AddtblContent
1, 1, 'langStrings', 'Homepage.PageTitle',
'Transport Direct - Britain''s free online route planner &amp; journey planner',
'Transport Direct - Britain''s free online route planner &amp; journey planner'

EXEC AddtblContent
2, 1, 'langStrings', 'Homepage.PageTitle',
'Visit Britain - Britain''s free online route planner &amp; journey planner',
'Visit Britain - Britain''s free online route planner &amp; journey planner'

EXEC AddtblContent
3, 1, 'langStrings', 'Homepage.PageTitle',
'BBC - Britain''s free online route planner &amp; journey planner',
'BBC - Britain''s free online route planner &amp; journey planner'

EXEC AddtblContent
5, 1, 'langStrings', 'Homepage.PageTitle',
'Directgov - Britain''s free online route planner &amp; journey planner',
'Directgov - Britain''s free online route planner &amp; journey planner'

GO








----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1266
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO