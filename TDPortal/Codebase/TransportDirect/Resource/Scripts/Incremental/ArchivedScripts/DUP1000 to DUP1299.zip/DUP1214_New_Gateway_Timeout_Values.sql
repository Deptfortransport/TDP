-- ***********************************************
-- NAME 		: DUP1214_New_Gateway_Timeout_Values.sql
-- DESCRIPTION 		: New property for the timeout value (seconds) when running in
--			  travel news, zonal services & train taxi feeds, also
--			  a default property to be used by all other feeds.	
-- ************************************************

USE PermanentPortal

--Insert a default timeout
IF EXISTS (SELECT * FROM properties 
 WHERE pname = 'datagateway.default.sqlimport.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1)
  BEGIN
    UPDATE properties SET pvalue = '60' 
    WHERE pName = 'datagateway.default.sqlimport.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1
  END
ELSE
  BEGIN
    INSERT INTO properties (pname, pvalue, AID, GID, PartnerId, ThemeID)
    VALUES ('datagateway.default.sqlimport.sqlcommandtimeout','60','','DataGateway',0,1)
  END
GO

--Insert a timeout for traintaxi feed
IF EXISTS (SELECT * FROM properties 
 WHERE pname = 'datagateway.sqlimport.traintaxi.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1)
  BEGIN
    UPDATE properties SET pvalue = '120' 
    WHERE pName = 'datagateway.sqlimport.traintaxi.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1
  END
ELSE
  BEGIN
    INSERT INTO properties (pname, pvalue, AID, GID, PartnerId, ThemeID)
    VALUES ('datagateway.sqlimport.traintaxi.sqlcommandtimeout','120','','DataGateway',0,1)
  END
GO

--Insert a timeout for travelnews feed
IF EXISTS (SELECT * FROM properties 
 WHERE pname = 'datagateway.sqlimport.travelnews.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1)
  BEGIN
    UPDATE properties SET pvalue = '90' 
    WHERE pName = 'datagateway.sqlimport.travelnews.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1
  END
ELSE
  BEGIN
    INSERT INTO properties (pname, pvalue, AID, GID, PartnerId, ThemeID)
    VALUES ('datagateway.sqlimport.travelnews.sqlcommandtimeout','90','','DataGateway',0,1)
  END
GO

--Insert a timeout for zonal services feed
IF EXISTS (SELECT * FROM properties 
 WHERE pname = 'datagateway.sqlimport.zonalservices.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1)
  BEGIN
    UPDATE properties SET pvalue = '120' 
    WHERE pName = 'datagateway.sqlimport.zonalservices.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0 AND ThemeID = 1
  END
ELSE
  BEGIN
    INSERT INTO properties (pname, pvalue, AID, GID, PartnerId, ThemeID)
    VALUES ('datagateway.sqlimport.zonalservices.sqlcommandtimeout','120','','DataGateway',0,1)
  END
GO

-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1214
SET @ScriptDesc = 'New property for the timeout value when running in gateway feeds'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO