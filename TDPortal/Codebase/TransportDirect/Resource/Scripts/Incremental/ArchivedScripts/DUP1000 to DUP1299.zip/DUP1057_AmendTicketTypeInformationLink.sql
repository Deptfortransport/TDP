-- ***********************************************
-- NAME 		: DUP1057_AmendTicketTypeInformationLink.sql
-- DESCRIPTION 		: Script to amend the controlname of the tooltip information for the ticket type information link
-- AUTHOR		: Mark Turner
-- DATE			: 14 July 2008
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT
SET @ThemeId = 1

----------------------------------------------------------
-- Header text
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'FindAFare', 'FindFareTicketSelectionControl.ticketTypeLinkToolTip', 'Opens a new window to view information about the {0} ticket type', 'cy-Opens a new window to view information about the {0} ticket type'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1057
SET @ScriptDesc = 'Amended ControlName of FindFareTicketSelectionControl.ticketTypeLinkToolTip to be FindAFare'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO