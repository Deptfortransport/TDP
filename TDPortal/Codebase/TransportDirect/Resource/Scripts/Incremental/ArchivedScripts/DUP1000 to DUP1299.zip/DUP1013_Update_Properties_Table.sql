-- ************************************************************
-- NAME 		: DUP1013_Update_Properties_Table.sql
-- DESCRIPTION 		: Updates pValue within properties table
-- AUTHOR		: S Johal
-- ************************************************************
USE PermanentPortal
GO

IF EXISTS (SELECT * FROM [dbo].[Properties] WHERE pName='DataServices.DataNotification.Groups')
  BEGIN
    UPDATE [dbo].[Properties]
    set [PValue]='Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LatestNewsService,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare,ZonalServiceCatalogue,ZonalAccessibilityCatalogue' where (pName='DataServices.DataNotification.Groups') AND (AID='<DEFAULT>')
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[Properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
    VALUES ('DataServices.DataNotification.Groups', 'Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LatestNewsService,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare,ZonalServiceCatalogue,ZonalAccessibilityCatalogue', '<DEFAULT>', '<DEFAULT>', 0, 1)
  END
  GO

IF EXISTS (SELECT * FROM [dbo].[Properties] WHERE pName='DataServices.DataNotification.Groups')
  BEGIN
    UPDATE [dbo].[Properties]
    set [PValue]='Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LatestNewsService,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare,ZonalServiceCatalogue,ZonalAccessibilityCatalogue' where (pName='DataServices.DataNotification.Groups') AND (AID='EnhancedExposedServices')
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[Properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
    VALUES ('DataServices.DataNotification.Groups', 'Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LatestNewsService,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare,ZonalServiceCatalogue,ZonalAccessibilityCatalogue', 'EnhancedExposedServices', 'UserPortal', 0, 1)
  END
  GO

IF EXISTS (SELECT * FROM [dbo].[Properties] WHERE pName='DataServices.DataNotification.ExternalLinks.Tables')
  BEGIN
    UPDATE [dbo].[Properties]
    set [PValue]='ExternalLinks,ZonalStop,ZonalAccessibility' where pName='DataServices.DataNotification.ExternalLinks.Tables'
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[Properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
    VALUES ('DataServices.DataNotification.ExternalLinks.Tables', 'ExternalLinks,ZonalStop,ZonalAccessibility', '<DEFAULT>', '<DEFAULT>', 0, 1)
  END
  GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1013
SET @ScriptDesc = 'Updates pValue within properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-----------------------------------------------------------------