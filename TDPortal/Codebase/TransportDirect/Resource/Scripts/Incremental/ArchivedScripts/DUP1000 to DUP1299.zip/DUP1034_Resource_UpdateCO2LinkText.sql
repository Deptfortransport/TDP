-- ***********************************************
-- NAME 		: DUP1034_Resource_UpdateCO2LinkText.sql
-- DESCRIPTION  : Update resource text for CO2 infomation link on Check Journey CO2 page
-- AUTHOR		: Mitesh Modi
-- DATE			: 08 Jul 2008 15:00:00
-- ************************************************

USE [TransientPortal]
GO

DECLARE @ResourceNameId INT

SET @ResourceNameId = (SELECT ResourceNameId FROM [ResourceName] WHERE [ResourceName] = 'JourneyEmissions.EstimatingPublicTransportCO2')

UPDATE [Resource] SET [Text] ='Estimating public transport and air journey CO2' 
WHERE [ResourceNameId] = @ResourceNameId
AND [Culture] = 'en-GB'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1034
SET @ScriptDesc = 'Resource update to CO2 information link text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO