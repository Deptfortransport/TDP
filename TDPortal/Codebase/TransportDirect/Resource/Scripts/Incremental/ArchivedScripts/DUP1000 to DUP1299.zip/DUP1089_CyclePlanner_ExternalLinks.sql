-- ***********************************************
-- NAME 		: DUP1089_CyclePlanner_ExternalLinks.sql
-- DESCRIPTION 		: Script to add External links for cycle planner
-- AUTHOR		: Mitesh Modi
-- DATE			: 10 Jul 2008 18:00:00
-- ************************************************


USE [TransientPortal]
GO

-- Cycle england
EXEC AddExternalLink
'CycleEngland', 
'http://www.cyclingengland.co.uk/', 
'http://www.cyclingengland.co.uk/', 
'Cycle England homepage url'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1089
SET @ScriptDesc = 'External links for cycle planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO