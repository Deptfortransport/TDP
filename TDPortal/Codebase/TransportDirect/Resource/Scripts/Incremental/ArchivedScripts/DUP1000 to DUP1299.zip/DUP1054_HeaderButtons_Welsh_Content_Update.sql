-- ***********************************************
-- NAME 		: DUP1054_HeaderButtons_Welsh_Content_Update.sql
-- DESCRIPTION 		: Script to amend Welsh Header Buttons
-- AUTHOR		: Neil Rankin
-- DATE			: 11 July 2008 12:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE Content
Go

EXEC AddtblContent
1, 1, 'langStrings','HeaderControl.homeImageButton.AlternateText','Homepage','Cartref' 
EXEC AddtblContent
1, 1, 'langStrings','HeaderControl.loginAndRegisterImageButton.AlternateText','Login / Register','Logio i Mewn/Cofrestru'
EXEC AddtblContent
1, 1, 'langStrings','HeaderControl.logoutAndUpdateImageButton.AlternateText','Logout / Update','Allgofnodi/Diweddaru' 




EXEC AddtblContent
1, 1, 'langStrings','LocationInformation.localInformation.Text','Locality Information','Gwybodaeth am yr ardal'


EXEC AddtblContent 1, 1, 'langStrings','LocationInformation.stationFacilities.Text','Station facilities','Cyfleusterau''r orsaf'
 

EXEC AddtblContent 1, 1, 'langStrings','LocationInformation.realTimeInfo.Text','Real time information','Gwybodaeth amser real'


EXEC AddtblContent 1, 1, 'langStrings','LocationInformation.airportFacilities.Text','Airport facilities','Cyfleusterau''r maes awyr'


EXEC AddtblContent 1, 1, 'langStrings','JourneyDetails.accessibilityLink.Text','Accessibility information relating to this service','Gwybodaeth hygyrchedd cysylltiedig �''r gwasanaeth hwn'


EXEC AddtblContent 1, 1, 'langStrings','ExternalLinks.Tooltip','Click to view information in a new browser window','Cliciwch i weld gwybodaeth mewn ffenestr bori newydd'


EXEC AddtblContent 1, 1, 'langStrings','JourneyMapControl.hyperLinkMapKey.AlternateText','Map legend opens in new window','Eglurhad map yn agor mewn ffenestr newydd'


EXEC AddtblContent 1, 1, 'langStrings','PrinterFriendlyButton.Tooltip','Click to view printer friendly page in a new browser window','Cliciwch i weld tudalen hwylus i''w hargraffu mewn ffenestr bori newydd'



EXEC AddtblContent 1, 1, 'langStrings','JourneyEmissionsCompareControl.JourneyDistance','For comparision if you travelled {0} {1} by: ','Er mwyn cymharu, pe byddech yn gwneud {0} {1} mewn: '

EXEC AddtblContent 1, 1, 'langStrings','JourneyEmissionsCompareControl.JourneyDistance.PrinterFriendly','For comparision if you travelled {0} {1} by: ','Er mwyn cymharu, pe byddech yn gwneud {0} {1} mewn: '

EXEC AddtblContent 1, 1, 'langStrings','JourneyEmissionsCompareControl.JourneyDistanceTableView','For comparision if you travelled {0} {1} by another mode of transport the CO2 emission per traveller would be as shown in the table below.','Er cymhariaeth, pe bai chi''n gwneud y siwrnai {0} {1} drwy ddull trafnidaeth arall byddai''r allyriadau CO2 fesul teithiwr yr un peth �"r hyn a ddangosir yn y tabl isod.'

EXEC AddtblContent 1, 1, 'langStrings','JourneyEmissionsCompareControl.JourneyDistanceTableView.PrinterFriendly','For comparision if you travelled {0} {1} by another mode of transport the CO2 emission per traveller would be as shown in the table below.','Er cymhariaeth, pe bai chi''n gwneud y siwrnai {0} {1} drwy ddull trafnidaeth arall byddai''r allyriadau CO2 fesul teithiwr yr un peth �"r hyn a ddangosir yn y tabl isod.'



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1054
SET @ScriptDesc = 'Amend Welsh Header Buttons'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO