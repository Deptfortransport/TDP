-- ***********************************************
-- NAME 		: DUP1065_Content_Update_for_DepartureBoard_Visibility_Changes.sql
-- DESCRIPTION 		: Script to add URLs and Text for Departure board visibility changes
-- AUTHOR		: Phil Scott
-- DATE			: 18 Jul 2008 09:00:00
-- ************************************************

USE [Content]
GO



EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.ArrivalBoardButton.Text','Click to view arrival board in a new browser window','Cliciwch i weld Bwrdd cyrraedd mewn ffenestr bori newydd'




EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.DepartureBoardButton.Text','Click to view departure board in a new browser window','Cliciwch i weld bwrdd ymadael mewn ffenestr bori newydd'



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1065
SET @ScriptDesc = 'Content_Update_for_DepartureBoard_Visibility_Changes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO