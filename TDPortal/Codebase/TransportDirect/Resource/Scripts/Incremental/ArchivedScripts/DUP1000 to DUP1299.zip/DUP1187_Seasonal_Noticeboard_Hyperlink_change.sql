-- ***********************************************
-- NAME 		: DUP1187_Seasonal_Noticeboard_Hyperlink_change.sql
-- DESCRIPTION 		: Script to update Seasonal Noticeboard content to make more prominent
-- AUTHOR		: Rich Broddle
-- DATE			: 26 Sept 2008 
-- ************************************************

USE [Content]
GO


-- Update the text for the new hyperlink
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlanner.hyperlinkBankHolidayInfo', '<STRONG>Click here for information about changes to public transport services.</STRONG>', '<STRONG>cy Click here for information about changes to public transport services.</STRONG>'

-- 

GO
----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1187
SET @ScriptDesc = 'Updated Seasonal Noticeboard hyperlink content - CCN460'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO