-- ***********************************************
-- NAME 		: DUP1243_XHTML_Compliance_Changes_HelpContent.sql
-- DESCRIPTION 		: Update help content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 20 January 2008
-- ************************************************

USE [Content]
GO


--  help page content for Journey Map page
EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelJourneyMap'
,'<p>You can view specific stages of the journey in more detail:<br/>     1.    Select the journey stage from the drop-down list<br/>     2.    Click ''Show route''<br/><br/>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.<br/><br/>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow).  They include transport symbols (shown automatically) and a range of attraction and facility symbols.<br/><br/>To show or hide any of these symbols, you must:<br/>1. Click on a category radio button e.g. ''Accommodation''<br/>2. Tick or untick the boxes next to the symbols<br/>3. Click ''Show selected symbols''</p><br/><br/><p>The colour coding used on the map may show traffic levels as:</p><ul><li>Low traffic</li><li>Medium traffic</li><li>High traffic</li><li>Traffic unknown</li></ul><p>�</p><p>Low, medium and high traffic levels are based upon past traffic measurements provided by the Highways Agency, the Welsh Assembly and the Scottish Executive. These take into consideration the road, the direction, and the day and time of travel. Where "Traffic unknown" is shown, no traffic measurements are available for the specific roads, so estimated traffic speeds for the time, day and type of road are used in planning the journey (based on the National Traffic Model).</p><br/><br/><strong>Amend date and time</strong><br/><p>To amend the dates and times of your journey:<br/>1. Select the new date(s) and time(s) in the drop-down lists<br/>2. Click ''Search with new dates/times''<br/><br/>  To amend the entire journey, you can click ''Amend journey'' at the top of the page</p><br/><strong>Save as a favourite journey</strong><br/><p>To save the journey:<br/>1.   Make sure you are logged in<br/>2.   Enter a meaningful name for the journey (e.g. �Journey to work�) <br/>3. Click ''OK''<br/><br/>You can save up to five journeys and you can overwrite existing journeys.</p><br/><strong>Send to a friend</strong><p>To send this page to a friend:<br/>1. Make sure you are logged in.<br/>  2. If you are not logged in, you will need to enter your username and password.<br/>3. Type in the email address of the person you would like to send the page to in the box<br/>4. Click ''Send''<br/><br/>A text-based email with a summary of the journey and the details/directions will be sent to that email address.  Maps (if applicable) will be attached as an image file (Avg. email size 150k).  Your email address will be shown in the email.</p><br/>'
,'<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>     1.    Dewiswch gam y siwrnai fel rhestr a ollyngir i lawr<br/>     2.    Cliciwch ar ''Dangoswch y Llwybr''<br/><br/>Cliciwch ar ''Hawdd ei argraffu'' i agor tudalen briodol y gallwch ei hargraffu fel arfer<br/><br/>Gallwch weld symbolau ar y map pan fo wedi ei chwyddo''n fawr (o fewn y pump lefel chwyddo mwyaf a amlinellir mewn melyn).  Maent yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac amrywiaeth o symbolau atyniadau a chyfleusterau <br/><br/>I ddangos neu guddio unrhyw rai o''r symbolau hyn, rhaid i chi:<br/>1. Glicio ar fotwm radio a dewis categori e.e. ''Llety''<br/>2. Dicio neu ddad-dicio''r blychau ger y symbolau<br/>3. Glicio ar ''Dewiswch symbolau detholedig''</p><br/><br/><p>Mae''n bosibl y bydd y c�d lliw ar y map yn dangos lefelau trafnidiaeth fel:</p><ul><li>Traffig isel</li><li>Traffig canolig</li><li>Traffig uchel</li><li>Traffig anhysbys</li></ul><p>�</p><p>Mae lefelau trafnidiaeth isel, canolig ac uchel yn seiliedig ar fesurau traffig y gorffennol a ddarparwyd gan Awdurdod y Priffyrdd, Cynulliad Cenedlaethol Cymru a Gweithrediaeth yr Alban. Mae''r rhain yn cymryd y ffordd, y cyfeiriad a diwrnod ac amser teithio i ystyriaeth. Lle dangosir "Traffig anhysbys", nid oes mesuriadau traffig ar gael ar gyfer y ffyrdd penodol, felly defnyddir amcangyfrif o gyflymderau traffig ar gyfer yr amser, y diwrnod a''r math o ffordd wrth gynllunio''r siwrnai (yn seiliedig ar Model Traffig Cenedlaethol).</p><br/><br/><strong>Newidiwch y dyddiad a''r amser</strong><br/><p>I ddiwygio dyddiadau ac amserau eich siwrnai:<br/>1. Dewiswch y dyddiad(au) a''r amser(au) newydd yn y rhestrau a ollyngir i lawr<br/>2. Cliciwch ar ''Chwiliwch gyda dyddiadau/amserau newydd''<br/><br/>  I ddiwygio''r siwrnai gyfan, gallwch glicio ''Diwygiwch y siwrnai'' ar frig y dudalen.</p><br/><strong>Cadwch fel hoff siwrnai</strong><br/><p>I gadw''r siwrnai:<br/>1.   Gofalwch eich bod wedi logio i mewn<br/>2.   Rhowch enw ystyrlon i''r siwrnai (e.e. ''Siwrnai i''r gwaith'')<br/>3. Cliciwch ar ''Iawn''.<br/><br/>Gallwch gadw hyd at bump siwrnai a gallwch ysgrifennu dros siwrneion presennol.</p><br/><strong>Anfonwch y dudalen hon at ffrind drwy ebost</strong><br/><p>I anfon y dudalen hon at ffrind:<br/>1. Gofalwch eich bod wedi logio i mewn.<br/>  2. Os nad ydych wedi logio i mewn, bydd yn rhaid i chi roi eich enw defnyddiwr a''ch cyfrinair.<br/>3. Teipiwch gyfeiriad ebost y sawl yr hoffech anfon y dudalen atynt yn y blwch<br/>4. Cliciwch ''Anfon''<br/><br/>Anfonir ebost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau at y cyfeiriad ebost hwnnw.  Atodir mapiau (os yn berthnasol) fel ffeil ddelwedd (maint ebost cyfartalog 150k). Dangosir eich cyfeiriad ebost yn yr e-bost.</p><br/>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpMapPublic'
,'<h1><strong>Map of selected public transport journey</strong></h1>
<p><strong></strong>&nbsp;</p>
<p>This page shows the selected public transport journey route.</p>
<p>&nbsp;</p>
<p>The various coloured and patterned route sections show different types of transport (and walking). There is a key next to the map to show you which section is what type of transport.</p>
<p>&nbsp;</p>
<p>The initial map shows the full route, including all stages of the journey and all types of transport.</p>
<p>&nbsp;</p>
<p>You can view specific stages of the journey in more detail:<br/>1. Select the journey stage from the dropdown list e.g. ''Train 1''<br/>2. Click ''Show route''</p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<h1><strong>Map o''r siwrnai ddetholedig ar gludiant cyhoeddus </strong></h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos y siwrnai ddetholedig ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<p>Dengys yr adrannau o''r llwybr sydd wedi eu lliwio a''r rhai patrymog wahanaol fathau o gludiant (a cherdded).&nbsp; Mae allwedd ger y map i ddangos i chi pa adran yw pa fath o gludiant</p>
<p>&nbsp;</p>
<p>Mae''r map dechreuol yn dangos y llwybr llawn, gan gynnwys pob cam o''r siwrnai a phob math o gludiant.</p>
<p>&nbsp;</p>
<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>1. Dewiswch gam y siwrnai o''r rhestr a ollyngir i lawr e.e. ''Tr�n 1''<br/>2. Cliciwch ar ''Dangoswch lwybr''</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawdd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpMapPublic'
,'<h1><strong>Map of selected public transport journey</strong></h1>
<p><strong></strong>&nbsp;</p>
<p>This page shows the selected public transport journey route.</p>
<p>&nbsp;</p>
<p>The various coloured and patterned route sections show different types of transport (and walking). There is a key next to the map to show you which section is what type of transport.</p>
<p>&nbsp;</p>
<p>The initial map shows the full route, including all stages of the journey and all types of transport.</p>
<p>&nbsp;</p>
<p>You can view specific stages of the journey in more detail:<br/>1. Select the journey stage from the dropdown list e.g. ''Train 1''<br/>2. Click ''Show route''</p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<h1><strong>Map o''r siwrnai ddetholedig ar gludiant cyhoeddus </strong></h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos y siwrnai ddetholedig ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<p>Dengys yr adrannau o''r llwybr sydd wedi eu lliwio a''r rhai patrymog wahanaol fathau o gludiant (a cherdded).&nbsp; Mae allwedd ger y map i ddangos i chi pa adran yw pa fath o gludiant</p>
<p>&nbsp;</p>
<p>Mae''r map dechreuol yn dangos y llwybr llawn, gan gynnwys pob cam o''r siwrnai a phob math o gludiant.</p>
<p>&nbsp;</p>
<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>1. Dewiswch gam y siwrnai o''r rhestr a ollyngir i lawr e.e. ''Tr�n 1''<br/>2. Cliciwch ar ''Dangoswch lwybr''</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawdd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpMapPublic'
,'<h1><strong>Map of selected public transport journey</strong></h1>
<p><strong></strong>&nbsp;</p>
<p>This page shows the selected public transport journey route.</p>
<p>&nbsp;</p>
<p>The various coloured and patterned route sections show different types of transport (and walking). There is a key next to the map to show you which section is what type of transport.</p>
<p>&nbsp;</p>
<p>The initial map shows the full route, including all stages of the journey and all types of transport.</p>
<p>&nbsp;</p>
<p>You can view specific stages of the journey in more detail:<br/>1. Select the journey stage from the dropdown list e.g. ''Train 1''<br/>2. Click ''Show route''</p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<h1><strong>Map o''r siwrnai ddetholedig ar gludiant cyhoeddus </strong></h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos y siwrnai ddetholedig ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<p>Dengys yr adrannau o''r llwybr sydd wedi eu lliwio a''r rhai patrymog wahanaol fathau o gludiant (a cherdded).&nbsp; Mae allwedd ger y map i ddangos i chi pa adran yw pa fath o gludiant</p>
<p>&nbsp;</p>
<p>Mae''r map dechreuol yn dangos y llwybr llawn, gan gynnwys pob cam o''r siwrnai a phob math o gludiant.</p>
<p>&nbsp;</p>
<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>1. Dewiswch gam y siwrnai o''r rhestr a ollyngir i lawr e.e. ''Tr�n 1''<br/>2. Cliciwch ar ''Dangoswch lwybr''</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawdd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'


GO

--  help content for Journey Fares page
EXEC AddtblContent
1, 1, 'langStrings', 'helpJourneyFaresLabelControl'
,'<p>This page shows the fares for the selected journey. A diagram of your journey is on the left hand side of the 
page and the fares are listed in tables next to it. If you would like to see fares for this journey, 
without the diagram, click "Show in table". </p><br/><br/> 
<p><strong>Public Transport costs</strong></p>
<p>The fares are listed for each leg of the journey if Transport Direct has the fare information.<br/><br/> 
To view the Ticket Retailers for these fares:<br/> 
1. Select the fare(s) you are interested in buying. You do not need to buy a ticket for all parts of the 
journey<br/>
2. Click "Buy tickets"<br/><br/></p>
<p><strong>Car Journey costs:</strong></p><br/><ul><li>The costs below are related to your journey.<br/></li></ul>
<p> If the journey involves ferries or tolls, the costs for these will be indicated if they are available.  
For more information on the ferries or tolls you can click on the name to be taken to their websites.</p>
<br/>
<p><strong>Amend fare details</strong></p>
<p>To amend fare details: <br/><br/></p>
<p><strong>Discount cards</strong></p>
<ul> <li>Select the discount rail card you have from the drop-down list</li>
<li>Select the discount coach card you have from the drop-down list</li></ul><br/>
<p><strong>Type of fare </strong></p>
<ul> <li>Select whether you''d like to see Adult or Child fares</li>
<li>Select whether you''d like to see Single or Return fares.</li>
<li>Then click "Ok"</li></ul><br/>
<p>These details will then be applied to the fares listed in the results.</p> 
<br/><p><strong>Amend date and time</strong><br/>To amend the dates and times of your journey:
<br/>1. Select the new date(s) and time(s) in the drop-down lists
<br/>2. Click ''Search with new dates/times''<br/><br/>
To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br/><p><strong>Save as a favourite journey</strong><br/>To save the journey:
<br/>1.   Make sure you are logged in<br/>2.   Enter a meaningful name for the journey (e.g. �Journey to work�)
<br/>3. Click ''OK''<br/><br/>You can save up to five journeys and you can overwrite existing journeys.</p>
<br/><p><strong>Send to a friend</strong>To send this page to a friend:<br/>1. Make sure you are logged in.
<br/>  2. If you are not logged in, you will need to enter your username and password.
<br/>3. Type in the email address of the person you would like to send the page to in the box<br/>4. Click ''Send''
<br/><br/>A text-based email with a summary of the journey and the details/directions will be sent to that 
email address.  Maps (if applicable) will be attached as an image file (Avg. email size 150k).
Your email address will be shown in the email.</p><br/>'
,'<p>Mae''r dudalen hon yn dangos y tocynnau am y siwrnai a ddewisisyd. Ceir diagram o''ch siwrnai ar ochr 
llaw chwith y dudalen a rhestrir y tocynnau teitho yn y tablau yn ei ymyl. Os hoffech weld 
tocynnau teithio am y siwrnai hon yn unig, heb y diagram, cliciwch ar "Dangos mewn tabl".</p><br/><br/>
<p><strong>Public Transport</strong></p>
<p>Rhestrir y tocynnau teithio ar gyfer pob adran o''r daith os oes gan Transport Direct yr wybodaeth am
 y tocyn teithio.<br/><br/>    I weld yr Adwerthwyr tocynnau am y tocynnau hyn:<br/>
1. Dewiswch y tocyn(nau) teithio y mae gennych yn ey prynu. Nid oes raid i chi brynu tocyn am bob
 rhan o''r siwrnai
<br/>�2. Cliciwch ar "Prynu tocynnau"<br/><br/></p>
<p><strong>Costau siwrneion:</strong> <br/></p><ul><li>Mae''r costau isod yn gysylltiedig �''ch siwrnai<br/></li></ul><p>
Os yw''r siwrnai yn ymwneud � ffer�au neu dollau, nodir costau''r rhain os ydynt ar gael. 
I gael mwy o wybodaeth ynglyn �''r ffer�au neu''r tollau gallwch glicio ar yr enw i gael eich cymryd i''w gwefannau.
</p>
<br/>
<p><strong>Diwygiwch fanylion y tocyn</strong></p>
<p> I ddiwygio manylion am docynnau:<br/><br/> <strong>Cardiau disgownt</strong></p>
<ul> <li>Dewiswch y cerdyn rheilffordd disgownt sydd gennych o''r rhestr a ollyngir i lawr</li>
<li>Dewiswch y cerdyn bws disgownt sydd gennych o''r rhestr a ollyngir i lawr</li></ul><br/>
<p><strong>Math o docyn</strong></p>
<ul> <li>Dewiswch p''run ai a hoffech weld tocynnau Oedolion neu Blant</li>
<li>Dewiswch p''run ai a hoffech weld tocynnau Sengl neu Fynd a Dod</li>
<li>Yna cliciwch ''Iawn''</li></ul><br/>
<p>Cymhwysir y manylion hyn wedyn at y tocynnau a restrwyd yn y canlyniadau.</p><br/>
<p><strong>Newidiwch y dyddiad a''r amser</strong><br/>I ddiwygio dyddiadau ac amserau eich siwrnai:
<br/>1. Dewiswch y dyddiad(au) a''r amser(au) newydd yn y rhestrau a ollyngir i lawr
<br/>2. Cliciwch ar ''Chwiliwch gyda dyddiadau/amserau newydd''<br/><br/>
I ddiwygio''r siwrnai gyfan, gallwch glicio ''Diwygiwch y siwrnai'' ar frig y dudalen.</p>
<br/><p><strong>Cadwch fel hoff siwrnai</strong><br/>I gadw''r siwrnai:
<br/>1.   Gofalwch eich bod wedi logio i mewn
<br/>2.   Rhowch enw ystyrlon i''r siwrnai (e.e. ''Siwrnai i''r gwaith'')
<br/>3. Cliciwch ar ''Iawn''.<br/><br/>Gallwch gadw hyd at bump siwrnai a gallwch ysgrifennu dros 
siwrneion presennol.</p><br/><p><strong>Anfonwch y dudalen hon at ffrind drwy ebost</strong>
<br/>I anfon y dudalen hon at ffrind:<br/>1. Gofalwch eich bod wedi logio i mewn.
<br/>  2. Os nad ydych wedi logio i mewn, bydd yn rhaid i chi roi eich enw defnyddiwr a''ch cyfrinair.
<br/>3. Teipiwch gyfeiriad ebost y sawl yr hoffech anfon y dudalen atynt yn y blwch
<br/>4. Cliciwch ''Anfon''<br/><br/>Anfonir ebost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau 
at y cyfeiriad ebost hwnnw.  Atodir mapiau (os yn berthnasol) fel ffeil ddelwedd (maint ebost cyfartalog 150k). 
Dangosir eich cyfeiriad ebost yn yr e-bost.</p><br/>'

GO

--  help page content for Journey Fares page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpTickets'
,'<h1>Fares</h1>
<p><strong></strong>&nbsp;</p>
<p>The fares table lists:</p>
<p>&nbsp;</p>
<p>"Ticket type" which lists the names&nbsp;of the tickets.You can see more information about the tickey type by clicking on the name&nbsp;of the ticket. Tickets are listed as&nbsp;either&nbsp;"No", "Part" or "Full".</p>
<p>&nbsp;</p>
<p><strong>� No Flexibility</strong> </p>
<p>You can buy these types of tickets in advance for specified journeys.&nbsp; They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</p>
<p>&nbsp;</p>
<p><strong>� Part Flexibility</strong></p>
<p>You can buy these tickets anytime, but travel is restricted to avoid certain times.</p>
<p>&nbsp;</p>
<p></p>
<p><strong>� Full Flexibility</strong> </p>
<p>You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</p>
<p>&nbsp;</p>
<p>''Adult fare'' which you can apply discounts to. You can view Child fares if you select that option in the tool at the bottom of the page.<br/></p>
<p>&nbsp;</p>
<p>''Child fare'' which you can apply discounts to. You can view Adult fares if you select that option in the tool at the bottom of the page.<br/></p>
<p>&nbsp;</p>
<p>''Upgrades'' which indicate whether or not a ticket has upgrades. Click ''I'' to find out more about the upgrade.<br/></p>
<p>&nbsp;</p>
<p>In some cases several legs of the journey can be included under one fare. The legs of the journey these fares cover are indicated at the top of the table (e.g. Fares: Brighton to Manchester Piccadilly). A blue outline around the details indicates which legs of the journey are included in this fare.<br/></p>
<p>&nbsp;</p>
<p>Transport Direct may not have all fare information for all parts of the journey or all modes of the journey. You will need to buy tickets for this part of your journey elsewhere.<br/></p>
<p>&nbsp;</p>
<p><strong>If you want to print out the fares information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.<br/></strong></p>'
,'<h1>Prisiau</h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r tabl tocynnau yn rhestru:</p>
<p>''Math o docyn'' sy''n rhestru enwau''r tocynnau.&nbsp; Gallwch weld mwy o wybodaeth am y math o docyn drwy glicio ar enw''r tocyn.&nbsp; Rhestrir tocynnau fel naill ai ''Dim'', ''Rhannol'' neu ''Llawn''.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><strong>� Dim Hyblygrwydd</strong> </p>
<p>Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer&nbsp;gwasanaethau dynodedig. Mae eu niferoedd yn gyfyngedig fel arfer, ar adegau arbennig, ac ar wasanaethau penodol.&nbsp; Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf ddiwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, sawl diwrnod ymlaen llaw) mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</p>
<p>&nbsp;</p>
<p><strong>� Hyblygrwydd Rhannol</strong></p>
<p>Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi amserau arbennig.</p>
<p>&nbsp;</p>
<p></p>
<p><strong>� Hyblygrwydd Llawn</strong>&nbsp; </p>
<p>Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod maent yn ddilys.&nbsp; Mae''r rhain yn cynnwys tocynnau Agored a rhai tocynnau Dydd.&nbsp; Maent yn aml yn rhai da i deithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft yr oriau brig.</p>
<p>&nbsp;</p>
<p>''Tocyn Oedolyn'' y gallwch gymhwyso disgownt ato.&nbsp; Gallwch weld Tocynnau Plant os dewiswch y dewis hwnnw ar waelod y dudalen. </p>
<p>&nbsp;</p>
<p>''Tocyn Plentyn'' y gallwch gymhwyso disgownt ato.&nbsp; Gallwch weld Tocynnau Oedolion os dewiswch y dewis hwnnw ar waelod y dudalen. </p>
<p>&nbsp;</p>
<p>''Diweddariadau'' sy''n nodi a oes gan docyn uwchraddiadau ai peidio.&nbsp; Cliciwch ar ''Gwybodaeth'' i ddarganfod mwy am y diweddariad.</p>
<p>&nbsp;</p>
<p>Mewn rhai achosion gellir cynnwys nifer o adrannau''r daith o dan un tocyn.&nbsp; Nodir yr adrannau o''r siwrnai y mae''r tocynnau hyn yn ymwneud � hwy ar frig y tabl (e.e. Tocynnau:&nbsp; Brighton i Manchester Piccadilly).&nbsp; Noda amlinelliad glas o amgylch y manylion pa rannau o''r siwrnai a gynhwysir yn y tocyn hwn.</p>
<p>&nbsp;</p>
<p>Mae''n bosibl na fydd gan Transport Direct yr holl wybodaeth am docynnau am holl rannau''r siwrnai neu bob dull o deithio''r siwrnai.&nbsp; Bydd angen i chi brynu tocynnau ar gyfer y rhan hon o''ch siwrnai yn rhywle arall.</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ar ''Hawwd ei argraffu''. Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpTickets'
,'<h1>Fares</h1>
<p><strong></strong>&nbsp;</p>
<p>The fares table lists:</p>
<p>&nbsp;</p>
<p>"Ticket type" which lists the names&nbsp;of the tickets.You can see more information about the tickey type by clicking on the name&nbsp;of the ticket. Tickets are listed as&nbsp;either&nbsp;"No", "Part" or "Full".</p>
<p>&nbsp;</p>
<p><strong>� No Flexibility</strong> </p>
<p>You can buy these types of tickets in advance for specified journeys.&nbsp; They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</p>
<p>&nbsp;</p>
<p><strong>� Part Flexibility</strong></p>
<p>You can buy these tickets anytime, but travel is restricted to avoid certain times.</p>
<p>&nbsp;</p>
<p></p>
<p><strong>� Full Flexibility</strong> </p>
<p>You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</p>
<p>&nbsp;</p>
<p>''Adult fare'' which you can apply discounts to. You can view Child fares if you select that option in the tool at the bottom of the page.<br/></p>
<p>&nbsp;</p>
<p>''Child fare'' which you can apply discounts to. You can view Adult fares if you select that option in the tool at the bottom of the page.<br/></p>
<p>&nbsp;</p>
<p>''Upgrades'' which indicate whether or not a ticket has upgrades. Click ''I'' to find out more about the upgrade.<br/></p>
<p>&nbsp;</p>
<p>In some cases several legs of the journey can be included under one fare. The legs of the journey these fares cover are indicated at the top of the table (e.g. Fares: Brighton to Manchester Piccadilly). A blue outline around the details indicates which legs of the journey are included in this fare.<br/></p>
<p>&nbsp;</p>
<p>Transport Direct may not have all fare information for all parts of the journey or all modes of the journey. You will need to buy tickets for this part of your journey elsewhere.<br/></p>
<p>&nbsp;</p>
<p><strong>If you want to print out the fares information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.<br/></strong></p>'
,'<h1>Prisiau</h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r tabl tocynnau yn rhestru:</p>
<p>''Math o docyn'' sy''n rhestru enwau''r tocynnau.&nbsp; Gallwch weld mwy o wybodaeth am y math o docyn drwy glicio ar enw''r tocyn.&nbsp; Rhestrir tocynnau fel naill ai ''Dim'', ''Rhannol'' neu ''Llawn''.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><strong>� Dim Hyblygrwydd</strong> </p>
<p>Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer&nbsp;gwasanaethau dynodedig. Mae eu niferoedd yn gyfyngedig fel arfer, ar adegau arbennig, ac ar wasanaethau penodol.&nbsp; Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf ddiwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, sawl diwrnod ymlaen llaw) mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</p>
<p>&nbsp;</p>
<p><strong>� Hyblygrwydd Rhannol</strong></p>
<p>Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi amserau arbennig.</p>
<p>&nbsp;</p>
<p></p>
<p><strong>� Hyblygrwydd Llawn</strong>&nbsp; </p>
<p>Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod maent yn ddilys.&nbsp; Mae''r rhain yn cynnwys tocynnau Agored a rhai tocynnau Dydd.&nbsp; Maent yn aml yn rhai da i deithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft yr oriau brig.</p>
<p>&nbsp;</p>
<p>''Tocyn Oedolyn'' y gallwch gymhwyso disgownt ato.&nbsp; Gallwch weld Tocynnau Plant os dewiswch y dewis hwnnw ar waelod y dudalen. </p>
<p>&nbsp;</p>
<p>''Tocyn Plentyn'' y gallwch gymhwyso disgownt ato.&nbsp; Gallwch weld Tocynnau Oedolion os dewiswch y dewis hwnnw ar waelod y dudalen. </p>
<p>&nbsp;</p>
<p>''Diweddariadau'' sy''n nodi a oes gan docyn uwchraddiadau ai peidio.&nbsp; Cliciwch ar ''Gwybodaeth'' i ddarganfod mwy am y diweddariad.</p>
<p>&nbsp;</p>
<p>Mewn rhai achosion gellir cynnwys nifer o adrannau''r daith o dan un tocyn.&nbsp; Nodir yr adrannau o''r siwrnai y mae''r tocynnau hyn yn ymwneud � hwy ar frig y tabl (e.e. Tocynnau:&nbsp; Brighton i Manchester Piccadilly).&nbsp; Noda amlinelliad glas o amgylch y manylion pa rannau o''r siwrnai a gynhwysir yn y tocyn hwn.</p>
<p>&nbsp;</p>
<p>Mae''n bosibl na fydd gan Transport Direct yr holl wybodaeth am docynnau am holl rannau''r siwrnai neu bob dull o deithio''r siwrnai.&nbsp; Bydd angen i chi brynu tocynnau ar gyfer y rhan hon o''ch siwrnai yn rhywle arall.</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ar ''Hawwd ei argraffu''. Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpTickets'
,'<h1>Fares</h1>
<p><strong></strong>&nbsp;</p>
<p>The fares table lists:</p>
<p>&nbsp;</p>
<p>"Ticket type" which lists the names&nbsp;of the tickets.You can see more information about the tickey type by clicking on the name&nbsp;of the ticket. Tickets are listed as&nbsp;either&nbsp;"No", "Part" or "Full".</p>
<p>&nbsp;</p>
<p><strong>� No Flexibility</strong> </p>
<p>You can buy these types of tickets in advance for specified journeys.&nbsp; They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</p>
<p>&nbsp;</p>
<p><strong>� Part Flexibility</strong></p>
<p>You can buy these tickets anytime, but travel is restricted to avoid certain times.</p>
<p>&nbsp;</p>
<p></p>
<p><strong>� Full Flexibility</strong> </p>
<p>You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</p>
<p>&nbsp;</p>
<p>''Adult fare'' which you can apply discounts to. You can view Child fares if you select that option in the tool at the bottom of the page.<br/></p>
<p>&nbsp;</p>
<p>''Child fare'' which you can apply discounts to. You can view Adult fares if you select that option in the tool at the bottom of the page.<br/></p>
<p>&nbsp;</p>
<p>''Upgrades'' which indicate whether or not a ticket has upgrades. Click ''I'' to find out more about the upgrade.<br/></p>
<p>&nbsp;</p>
<p>In some cases several legs of the journey can be included under one fare. The legs of the journey these fares cover are indicated at the top of the table (e.g. Fares: Brighton to Manchester Piccadilly). A blue outline around the details indicates which legs of the journey are included in this fare.<br/></p>
<p>&nbsp;</p>
<p>Transport Direct may not have all fare information for all parts of the journey or all modes of the journey. You will need to buy tickets for this part of your journey elsewhere.<br/></p>
<p>&nbsp;</p>
<p><strong>If you want to print out the fares information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.<br/></strong></p>'
,'<h1>Prisiau</h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r tabl tocynnau yn rhestru:</p>
<p>''Math o docyn'' sy''n rhestru enwau''r tocynnau.&nbsp; Gallwch weld mwy o wybodaeth am y math o docyn drwy glicio ar enw''r tocyn.&nbsp; Rhestrir tocynnau fel naill ai ''Dim'', ''Rhannol'' neu ''Llawn''.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><strong>� Dim Hyblygrwydd</strong> </p>
<p>Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer&nbsp;gwasanaethau dynodedig. Mae eu niferoedd yn gyfyngedig fel arfer, ar adegau arbennig, ac ar wasanaethau penodol.&nbsp; Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf ddiwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, sawl diwrnod ymlaen llaw) mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</p>
<p>&nbsp;</p>
<p><strong>� Hyblygrwydd Rhannol</strong></p>
<p>Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi amserau arbennig.</p>
<p>&nbsp;</p>
<p></p>
<p><strong>� Hyblygrwydd Llawn</strong>&nbsp; </p>
<p>Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod maent yn ddilys.&nbsp; Mae''r rhain yn cynnwys tocynnau Agored a rhai tocynnau Dydd.&nbsp; Maent yn aml yn rhai da i deithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft yr oriau brig.</p>
<p>&nbsp;</p>
<p>''Tocyn Oedolyn'' y gallwch gymhwyso disgownt ato.&nbsp; Gallwch weld Tocynnau Plant os dewiswch y dewis hwnnw ar waelod y dudalen. </p>
<p>&nbsp;</p>
<p>''Tocyn Plentyn'' y gallwch gymhwyso disgownt ato.&nbsp; Gallwch weld Tocynnau Oedolion os dewiswch y dewis hwnnw ar waelod y dudalen. </p>
<p>&nbsp;</p>
<p>''Diweddariadau'' sy''n nodi a oes gan docyn uwchraddiadau ai peidio.&nbsp; Cliciwch ar ''Gwybodaeth'' i ddarganfod mwy am y diweddariad.</p>
<p>&nbsp;</p>
<p>Mewn rhai achosion gellir cynnwys nifer o adrannau''r daith o dan un tocyn.&nbsp; Nodir yr adrannau o''r siwrnai y mae''r tocynnau hyn yn ymwneud � hwy ar frig y tabl (e.e. Tocynnau:&nbsp; Brighton i Manchester Piccadilly).&nbsp; Noda amlinelliad glas o amgylch y manylion pa rannau o''r siwrnai a gynhwysir yn y tocyn hwn.</p>
<p>&nbsp;</p>
<p>Mae''n bosibl na fydd gan Transport Direct yr holl wybodaeth am docynnau am holl rannau''r siwrnai neu bob dull o deithio''r siwrnai.&nbsp; Bydd angen i chi brynu tocynnau ar gyfer y rhan hon o''ch siwrnai yn rhywle arall.</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ar ''Hawwd ei argraffu''. Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'


GO

--  help page content for Journey Emissions Compare Journey page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpJourneyEmissionsCompareJourney'
,'<h3>CO2 emissions Journey Screen </h3>
<p>&nbsp;</p>
<p>1.&nbsp;Click on the ''Next'' button to compare CO2 emissions from your journey with alternative modes of transport.</p><br/>
<p>2.&nbsp;To change from miles to kilometres or visa versa click on the drop down list next to ''Distance Units'', select the required unit and click ''Next''.</p><br/>
<p>3.&nbsp;To change the number of occupants for a car journey click on the drop down list at the end of the car detail row, select the number of occupants required and click ''Next''.</p><br/>'
,'<h3>Sgrin Siwrnai allyriadau CO2</h3>
<p>&nbsp;</p>
<p>1. Cliciwch ar fotwm "Nesaf" i gymharu allyriadau CO2 o''ch siwrnai � mathau eraill o drafnidiaeth.</p><br/>
<p>2. I newid o filltiroedd i gilometrau neu i''r gwrthwyneb, cliciwch ar y gwymplen wrth ymyl "Unedau Pellter", dewiswch yr uned ofynnol a chlicio "Nesaf". </p><br/>
<p>3. I newid nifer y teithwyr ar gyfer siwrnai car, cliciwch ar y gwymplen ar ddiwedd y rhes manylion car, dewiswch nifer y teithwyr gofynnol a chlicio "Nesaf".</p><br/>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyEmissionsCompareJourney'
,'<h3>CO2 emissions Journey Screen </h3>
<p>&nbsp;</p>
<p>1.&nbsp;Click on the ''Next'' button to compare CO2 emissions from your journey with alternative modes of transport.</p><br/>
<p>2.&nbsp;To change from miles to kilometres or visa versa click on the drop down list next to ''Distance Units'', select the required unit and click ''Next''.</p><br/>
<p>3.&nbsp;To change the number of occupants for a car journey click on the drop down list at the end of the car detail row, select the number of occupants required and click ''Next''.</p><br/>'
,'<h3>Sgrin Siwrnai allyriadau CO2</h3>
<p>&nbsp;</p>
<p>1. Cliciwch ar fotwm "Nesaf" i gymharu allyriadau CO2 o''ch siwrnai � mathau eraill o drafnidiaeth.</p><br/>
<p>2. I newid o filltiroedd i gilometrau neu i''r gwrthwyneb, cliciwch ar y gwymplen wrth ymyl "Unedau Pellter", dewiswch yr uned ofynnol a chlicio "Nesaf". </p><br/>
<p>3. I newid nifer y teithwyr ar gyfer siwrnai car, cliciwch ar y gwymplen ar ddiwedd y rhes manylion car, dewiswch nifer y teithwyr gofynnol a chlicio "Nesaf".</p><br/>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyEmissionsCompareJourney'
,'<h3>CO2 emissions Journey Screen </h3>
<p>&nbsp;</p>
<p>1.&nbsp;Click on the ''Next'' button to compare CO2 emissions from your journey with alternative modes of transport.</p><br/>
<p>2.&nbsp;To change from miles to kilometres or visa versa click on the drop down list next to ''Distance Units'', select the required unit and click ''Next''.</p><br/>
<p>3.&nbsp;To change the number of occupants for a car journey click on the drop down list at the end of the car detail row, select the number of occupants required and click ''Next''.</p><br/>'
,'<h3>Sgrin Siwrnai allyriadau CO2</h3>
<p>&nbsp;</p>
<p>1. Cliciwch ar fotwm "Nesaf" i gymharu allyriadau CO2 o''ch siwrnai � mathau eraill o drafnidiaeth.</p><br/>
<p>2. I newid o filltiroedd i gilometrau neu i''r gwrthwyneb, cliciwch ar y gwymplen wrth ymyl "Unedau Pellter", dewiswch yr uned ofynnol a chlicio "Nesaf". </p><br/>
<p>3. I newid nifer y teithwyr ar gyfer siwrnai car, cliciwch ar y gwymplen ar ddiwedd y rhes manylion car, dewiswch nifer y teithwyr gofynnol a chlicio "Nesaf".</p><br/>'

GO

--  help content for Ticket Retailers page
EXEC AddtblContent
1, 1, 'langStrings', 'TicketRetailersHelpLabel'
,'<p>This page shows the ticket(s) and fare(s) for the selected journey. Select the number of people travelling on this journey at the top of the page.<br /><br />
The tickets for the journey are listed in the table. To see Ticket retailers for these tickets, click "Select" under the ticket(s) you would like to buy.<br /><br />
Ticket retailers will appear in a table below the tickets. Then you will need to:<br />
1. Decide which ticket retailer you would like to buy the tickets from<br />
2. Click "Buy" across from the ticket retailer.<br /><br /></p>'
,'<p>Mae''r dudalen hon yn dangos y tocyn(nau) a''r pris(iau) am y siwrnai a ddewisiwyd.  Dewiswch nifer y bobl sy''n teithio ar y siwrnai hon ar  ben y dudalen.<br /><br />
Rhestrir y tocynnau ar gyfer y siwrnai yn y tabl.  I weld Adwerthwyr tocynnau ar gyfer y tocynnau hyn, cliciwch ''Dewis'' o dan y tocyn(nau) yr hoffech eu prynu.<br /><br />
Bydd adwerthwyr tocynnau yn ymddangos mewn tabl islaw''r tocynnau.  Yna bydd angen i chi:<br />
1. Benderfynu pa adwerthwr tocynnau yr hoffech brynu''r tocynnau oddi wrtho<br />
2. Clicio ar ''Prynu'' ar draws oddi wrth yr adwerthwr tocynnau.<br /><br /></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpTicketRetailers'
,'<h1>Ticket Retailers</h1>
<p>&nbsp;</p>
<h3>Number of people travelling</h3>
<p>Please enter the number of people travelling. The total number of travellers cannot be more than 8.&nbsp; If you need to buy more than 8 tickets you will need to return to this page after you have bought the first set of tickets.</p>
<p><br/>&nbsp;</p>
<h3>Ticket retailer section</h3>
<p>Online ticket retailers are retailers that sell tickets on their websites and which Transport Direct can link to directly.&nbsp;&nbsp; If you choose to buy from an online ticket retailer you will be taken to their webpage(s).&nbsp; Offline ticket retailers are retailers that allow you to buy tickets over the phone, opposed to online.&nbsp; If you choose an offline ticket retailer, you will be taken to a page that gives you their contact details.&nbsp; To find out more information on a retailer, click on the retailer name.</p>
<p>&nbsp;</p>'
,'<h1>Adwerthwyr tocynnau</h1>
<p>&nbsp;</p>
<h3>Nifer y bobl sy''n teithio</h3>
<p>Rhowch nifer y bobl yn teithio.&nbsp; Ni all cyfanswm nifer y teithwyr fod yn fwy nag 8.&nbsp; Os oes angen i chi brynu mwy nag 8 tocyn bydd yn rhaid i chi ddychwelyd i''r dudalen hon ar �l i chi brynu''r set gyntaf o docynnau.</p>
<p>&nbsp;</p>
<h3>Adran adwerthwyr tocynnau </h3>
<p>Mae adwerthwyr tocynnau ar-lein yn adwerthwyr sy''n gwerthu tocynnau ar eu gwefannau y gall Transport Direct gysylltu � hwy yn uniongyrchol.&nbsp; Os dewiswch brynu oddi wrth adwerthwyr tocynnau ar-lein fe''ch cymerir i''w tudalennau gwe.&nbsp; Mae adwerthwyr tocynnau oddi ar-lein yn adwerthwyr sy''n caniat�u i chi brynu tocynnau dros y ff�n, o''i gymharu ag ar-lein.&nbsp; Os dewiswch adwerthwr tocyn oddi ar-lein, fe''ch cymerir i dudalen sy''n rhoi''r manylion cyswllt i chi.&nbsp; I ddarganfod mwy o wybodaeth am adwerthwr, cliciwch ar enw''r adwerthwr.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpTicketRetailers'
,'<h1>Ticket Retailers</h1>
<p>&nbsp;</p>
<h3>Number of people travelling</h3>
<p>Please enter the number of people travelling. The total number of travellers cannot be more than 8.&nbsp; If you need to buy more than 8 tickets you will need to return to this page after you have bought the first set of tickets.</p>
<p><br/>&nbsp;</p>
<h3>Ticket retailer section</h3>
<p>Online ticket retailers are retailers that sell tickets on their websites and which Transport Direct can link to directly.&nbsp;&nbsp; If you choose to buy from an online ticket retailer you will be taken to their webpage(s).&nbsp; Offline ticket retailers are retailers that allow you to buy tickets over the phone, opposed to online.&nbsp; If you choose an offline ticket retailer, you will be taken to a page that gives you their contact details.&nbsp; To find out more information on a retailer, click on the retailer name.</p>
<p>&nbsp;</p>'
,'<h1>Adwerthwyr tocynnau</h1>
<p>&nbsp;</p>
<h3>Nifer y bobl sy''n teithio</h3>
<p>Rhowch nifer y bobl yn teithio.&nbsp; Ni all cyfanswm nifer y teithwyr fod yn fwy nag 8.&nbsp; Os oes angen i chi brynu mwy nag 8 tocyn bydd yn rhaid i chi ddychwelyd i''r dudalen hon ar �l i chi brynu''r set gyntaf o docynnau.</p>
<p>&nbsp;</p>
<h3>Adran adwerthwyr tocynnau </h3>
<p>Mae adwerthwyr tocynnau ar-lein yn adwerthwyr sy''n gwerthu tocynnau ar eu gwefannau y gall Transport Direct gysylltu � hwy yn uniongyrchol.&nbsp; Os dewiswch brynu oddi wrth adwerthwyr tocynnau ar-lein fe''ch cymerir i''w tudalennau gwe.&nbsp; Mae adwerthwyr tocynnau oddi ar-lein yn adwerthwyr sy''n caniat�u i chi brynu tocynnau dros y ff�n, o''i gymharu ag ar-lein.&nbsp; Os dewiswch adwerthwr tocyn oddi ar-lein, fe''ch cymerir i dudalen sy''n rhoi''r manylion cyswllt i chi.&nbsp; I ddarganfod mwy o wybodaeth am adwerthwr, cliciwch ar enw''r adwerthwr.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpTicketRetailers'
,'<h1>Ticket Retailers</h1>
<p>&nbsp;</p>
<h3>Number of people travelling</h3>
<p>Please enter the number of people travelling. The total number of travellers cannot be more than 8.&nbsp; If you need to buy more than 8 tickets you will need to return to this page after you have bought the first set of tickets.</p>
<p><br/>&nbsp;</p>
<h3>Ticket retailer section</h3>
<p>Online ticket retailers are retailers that sell tickets on their websites and which Transport Direct can link to directly.&nbsp;&nbsp; If you choose to buy from an online ticket retailer you will be taken to their webpage(s).&nbsp; Offline ticket retailers are retailers that allow you to buy tickets over the phone, opposed to online.&nbsp; If you choose an offline ticket retailer, you will be taken to a page that gives you their contact details.&nbsp; To find out more information on a retailer, click on the retailer name.</p>
<p>&nbsp;</p>'
,'<h1>Adwerthwyr tocynnau</h1>
<p>&nbsp;</p>
<h3>Nifer y bobl sy''n teithio</h3>
<p>Rhowch nifer y bobl yn teithio.&nbsp; Ni all cyfanswm nifer y teithwyr fod yn fwy nag 8.&nbsp; Os oes angen i chi brynu mwy nag 8 tocyn bydd yn rhaid i chi ddychwelyd i''r dudalen hon ar �l i chi brynu''r set gyntaf o docynnau.</p>
<p>&nbsp;</p>
<h3>Adran adwerthwyr tocynnau </h3>
<p>Mae adwerthwyr tocynnau ar-lein yn adwerthwyr sy''n gwerthu tocynnau ar eu gwefannau y gall Transport Direct gysylltu � hwy yn uniongyrchol.&nbsp; Os dewiswch brynu oddi wrth adwerthwyr tocynnau ar-lein fe''ch cymerir i''w tudalennau gwe.&nbsp; Mae adwerthwyr tocynnau oddi ar-lein yn adwerthwyr sy''n caniat�u i chi brynu tocynnau dros y ff�n, o''i gymharu ag ar-lein.&nbsp; Os dewiswch adwerthwr tocyn oddi ar-lein, fe''ch cymerir i dudalen sy''n rhoi''r manylion cyswllt i chi.&nbsp; I ddarganfod mwy o wybodaeth am adwerthwr, cliciwch ar enw''r adwerthwr.</p>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1243
SET @ScriptDesc = 'Update help content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO