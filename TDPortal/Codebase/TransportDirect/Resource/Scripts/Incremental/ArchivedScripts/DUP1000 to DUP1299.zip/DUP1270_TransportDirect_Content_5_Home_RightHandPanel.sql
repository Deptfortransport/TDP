-- ***********************************************
-- NAME 		: DUP1270_TransportDirect_Content_5_Home_RightHandPanel.sql
-- DESCRIPTION 	: Script to add the Right Hand Information panel text
-- AUTHOR		: Amit Patel
-- DATE			: 2 Feb 2009 12:00:00
-- ************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Content]
GO


DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')


-- Right hand items 1 and 2
EXEC AddtblContent
1, @GroupId, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/FindTrainInput.aspx">Bookmark your train times</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table1" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top" align="center" width="26"><img title="" alt="Train Image" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" border="0" /></td>  
<td class="txtseven">Got a rail route you use regularly?  You can now add train journeys to your Internet Explorer ''favourites''.  Plan a journey with <a href="/Web2/JourneyPlanning/FindTrainInput.aspx">Find a train</a>, then click the bookmark link in the left-hand column.</td></tr></tbody></table></div>  
<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="JourneyPlanning/JourneyEmissionsCompare.aspx">Act on CO2</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Co2" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Co2_30x30.gif" border="0" /></td>  
<td class="txtseven">Compare your CO2 and choose the route with the lowest emissions for your journey.  On the journey results page click the "Check CO2" button.</td></tr></tbody></table></div>'
, 
'<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/FindTrainInput.aspx">Bookmark your train times</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table1" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top" align="center" width="26"><img title="" alt="Train Image" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" border="0" /></td>  
<td class="txtseven">Got a rail route you use regularly?  You can now add train journeys to your Internet Explorer ''favourites''.  Plan a journey with <a href="/Web2/JourneyPlanning/FindTrainInput.aspx">Find a train</a>, then click the bookmark link in the left-hand column.</td></tr></tbody></table></div>  
<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="JourneyPlanning/JourneyEmissionsCompare.aspx">Act on CO2</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Co2" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Co2_30x30.gif" border="0" /></td>  
<td class="txtseven">Compare your CO2 and choose the route with the lowest emissions for your journey.  On the journey results page click the "Check CO2" button.</td></tr></tbody></table></div>'


-- Right hand item 3
EXEC AddtblContent
1, @GroupId, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home',
'<div class="Column3Header">
<div class="txtsevenbbl">Sending an invitation?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">It''s easy to create links that open Transport Direct with your own choice of destination, date and time.  For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&id=invitation&d=258785,665494&dn=Steph''s%20sales%20meeting%20at%20150%20St%20Vincent%20St,%20Glasgow&da=a&dt=28082008&t=0945">Directions to my meeting</a><br /><br />See our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page(opens new window)</a> for more details.</td></tr></tbody></table></div>'
,
'<div class="Column3Header">
<div class="txtsevenbbl">Sending an invitation?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">It''s easy to create links that open Transport Direct with your own choice of destination, date and time.  For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&id=invitation&d=258785,665494&dn=Steph''s%20sales%20meeting%20at%20150%20St%20Vincent%20St,%20Glasgow&da=a&dt=28082008&t=0945">Directions to my meeting</a><br /><br />See our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page(opens new window)</a> for more details.</td></tr></tbody></table></div>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1270
SET @ScriptDesc = 'Script to add Homepage Right hand information text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO