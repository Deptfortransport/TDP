-- ***********************************************
-- NAME 		: DUP1241_XHTML_Compliance_Changes_HelpContent.sql
-- DESCRIPTION 		: Update help content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 19 January 2008
-- ************************************************

USE [Content]
GO

-- generic help page content for ambiguity pages
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpAmbiguityGeneral'
,'<h2>Help</h2><br/><br/>
<h3>Confirming a location to travel from or to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Depending on the information entered, you will need to do one of the following:</p>
<ul>
<li>Choose a location option from the drop-down lists.<br/></li>
<li>Search for the location as a different kind of location<br/></li>
<li>Enter a new location</li></ul>
<h4>Choose locations from the lists highlighted on the page</h4>
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list </li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words �More options for�� written in front of them </li>
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location </li></ul>
<p>&nbsp;</p></blockquote>
<h3>Changing the kind of location</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If the journey planner didn''t find any matches for the location you typed in, it may be because the journey planner didn''t match the type of location with the location you typed in.</p><br/>
<p>Select another kind of location (e.g. ''Address/postcode'') and select the button next it.&nbsp; The journey planner will then show you a list of possible locations for this kind of location. </p><br/>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the journey planner will not be able to find it. </p></blockquote>
<h3>Correcting journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Select the dates you would like to leave/return on</strong></p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list </li></ul><br/>
<p><strong>2. Choose how you want to specify the times</strong></p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''<strong>Leaving at</strong>'' to select the earliest time you want to leave the location </li>
<li>Choose ''<strong>Arriving by</strong>'' to select the latest time you want to arrive at the destination</li></ul><br/>
<p><strong>3. Select the times you would like to travel</strong></p>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the journey planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/></blockquote>
<h3>Confirming locations to travel via</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Confirming a location to travel from or to</h4>
<p>Depending on the information entered, you will need to do one of the following:<br/></p>
<ul>
<li>Choose a location option from the drop-down lists </li>
<li>Search for the location as a different kind of location </li>
<li>Enter a new location</li></ul><br/>
<p>Choose locations from the lists highlighted on the page.</p><br/>
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list</li></ul><br/>
<p>Some locations have further locations within them:&nbsp; </p>
<ul>
<li>Some have the words �More options for�� written in front of them: </li>
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<h3>Changing the kind of location</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If the journey planner didn''t find any matches for the location you typed in, it may be because the journey planner didn''t match the type of location with the location you typed in.</p>
<p>&nbsp;</p>
<p>Select another kind of location (e.g. "Address/postcode") and select the button next to it. The journey planner will then show you a list of possible locations for this kind of location.</p>
<p>&nbsp;</p>
<p>It is important that you select the appropriate type of location. For example, if you are looking for a railway station, but you select the "Address/postcode" category, the journey planner will not be able to find it.</p></blockquote>
<h4>Once you have confirmed all the highlighted sections in this page, click ''Next''.&nbsp; </h4>'
,'<h2>Help</h2><br/><br/>
<h3>Cadarnhau lleoliad i deithio ohono neu iddo</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud un o''r canlynol:</p>
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr </li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad </li>
<li>Rhoi lleoliad newydd</li></ul>
<h4>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen</h4>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr. </li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:</p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau </li>
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi </li></ul><br/></blockquote>
<h3>Newid y math o leoliad</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p><br/>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad. </p><br/>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p><br/></blockquote>
<blockquote></blockquote>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</strong></p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/> </li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewisch "Tocyn dychwel agored" yn y rhestro o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul><br/>
<p><strong>2. Dewiswch sut y dymunwch nodi''r amserau</strong></p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Dewis ''<strong>Gadael am</strong>'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li>
<li>Dewis''<strong>Cyrraedd erbyn</strong>'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/>
<p><strong>3. Dewiswch yr amserau yr hoffech deithio </strong></p>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul><br/></blockquote>
<h3>Cadarnhau lleoliadau i deithio drwyddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Cadarnhau lleoliad i deithio ohono neu iddo</h4>
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud un o''r canlynol:<br/></p>
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr </li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad </li>
<li>Rhoi lleoliad newydd</li></ul><br/>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p><br/>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr. Cliciwch ar ''Nesa'' ar waelod y dudalen</li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:&nbsp; </p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau </li>
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li></ul><br/></blockquote>
<h3>Newid y math o leoliad</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p><br/>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad. </p><br/>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p><br/></blockquote>
<h4>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.&nbsp; </h4>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpAmbiguityGeneral'
,'<h2>Help</h2><br/><br/>
<h3>Confirming a location to travel from or to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Depending on the information entered, you will need to do one of the following:</p>
<ul>
<li>Choose a location option from the drop-down lists.<br/></li>
<li>Search for the location as a different kind of location<br/></li>
<li>Enter a new location</li></ul>
<h4>Choose locations from the lists highlighted on the page</h4>
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list </li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words �More options for�� written in front of them </li>
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location </li></ul>
<p>&nbsp;</p></blockquote>
<h3>Changing the kind of location</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If the journey planner didn''t find any matches for the location you typed in, it may be because the journey planner didn''t match the type of location with the location you typed in.</p><br/>
<p>Select another kind of location (e.g. ''Address/postcode'') and select the button next it.&nbsp; The journey planner will then show you a list of possible locations for this kind of location. </p><br/>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the journey planner will not be able to find it. </p></blockquote>
<h3>Correcting journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Select the dates you would like to leave/return on</strong></p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list </li></ul><br/>
<p><strong>2. Choose how you want to specify the times</strong></p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''<strong>Leaving at</strong>'' to select the earliest time you want to leave the location </li>
<li>Choose ''<strong>Arriving by</strong>'' to select the latest time you want to arrive at the destination</li></ul><br/>
<p><strong>3. Select the times you would like to travel</strong></p>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the journey planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/></blockquote>
<h3>Confirming locations to travel via</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Confirming a location to travel from or to</h4>
<p>Depending on the information entered, you will need to do one of the following:<br/></p>
<ul>
<li>Choose a location option from the drop-down lists </li>
<li>Search for the location as a different kind of location </li>
<li>Enter a new location</li></ul><br/>
<p>Choose locations from the lists highlighted on the page.</p><br/>
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list</li></ul><br/>
<p>Some locations have further locations within them:&nbsp; </p>
<ul>
<li>Some have the words �More options for�� written in front of them: </li>
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<h3>Changing the kind of location</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If the journey planner didn''t find any matches for the location you typed in, it may be because the journey planner didn''t match the type of location with the location you typed in.</p>
<p>&nbsp;</p>
<p>Select another kind of location (e.g. "Address/postcode") and select the button next to it. The journey planner will then show you a list of possible locations for this kind of location.</p>
<p>&nbsp;</p>
<p>It is important that you select the appropriate type of location. For example, if you are looking for a railway station, but you select the "Address/postcode" category, the journey planner will not be able to find it.</p></blockquote>
<h4>Once you have confirmed all the highlighted sections in this page, click ''Next''.&nbsp; </h4>'
,'<h2>Help</h2><br/><br/>
<h3>Cadarnhau lleoliad i deithio ohono neu iddo</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud un o''r canlynol:</p>
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr </li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad </li>
<li>Rhoi lleoliad newydd</li></ul>
<h4>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen</h4>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr. </li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:</p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau </li>
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi </li></ul><br/></blockquote>
<h3>Newid y math o leoliad</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p><br/>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad. </p><br/>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p><br/></blockquote>
<blockquote></blockquote>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</strong></p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/> </li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewisch "Tocyn dychwel agored" yn y rhestro o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul><br/>
<p><strong>2. Dewiswch sut y dymunwch nodi''r amserau</strong></p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Dewis ''<strong>Gadael am</strong>'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li>
<li>Dewis''<strong>Cyrraedd erbyn</strong>'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/>
<p><strong>3. Dewiswch yr amserau yr hoffech deithio </strong></p>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul><br/></blockquote>
<h3>Cadarnhau lleoliadau i deithio drwyddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Cadarnhau lleoliad i deithio ohono neu iddo</h4>
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud un o''r canlynol:<br/></p>
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr </li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad </li>
<li>Rhoi lleoliad newydd</li></ul><br/>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p><br/>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr. Cliciwch ar ''Nesa'' ar waelod y dudalen</li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:&nbsp; </p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau </li>
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li></ul><br/></blockquote>
<h3>Newid y math o leoliad</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p><br/>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad. </p><br/>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p><br/></blockquote>
<h4>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.&nbsp; </h4>'


EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpAmbiguityGeneral'
,'<h2>Help</h2><br/><br/>
<h3>Confirming a location to travel from or to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Depending on the information entered, you will need to do one of the following:</p>
<ul>
<li>Choose a location option from the drop-down lists.<br/></li>
<li>Search for the location as a different kind of location<br/></li>
<li>Enter a new location</li></ul>
<h4>Choose locations from the lists highlighted on the page</h4>
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list </li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words �More options for�� written in front of them </li>
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location </li></ul>
<p>&nbsp;</p></blockquote>
<h3>Changing the kind of location</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If the journey planner didn''t find any matches for the location you typed in, it may be because the journey planner didn''t match the type of location with the location you typed in.</p><br/>
<p>Select another kind of location (e.g. ''Address/postcode'') and select the button next it.&nbsp; The journey planner will then show you a list of possible locations for this kind of location. </p><br/>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the journey planner will not be able to find it. </p></blockquote>
<h3>Correcting journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Select the dates you would like to leave/return on</strong></p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list </li></ul><br/>
<p><strong>2. Choose how you want to specify the times</strong></p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''<strong>Leaving at</strong>'' to select the earliest time you want to leave the location </li>
<li>Choose ''<strong>Arriving by</strong>'' to select the latest time you want to arrive at the destination</li></ul><br/>
<p><strong>3. Select the times you would like to travel</strong></p>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the journey planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/></blockquote>
<h3>Confirming locations to travel via</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Confirming a location to travel from or to</h4>
<p>Depending on the information entered, you will need to do one of the following:<br/></p>
<ul>
<li>Choose a location option from the drop-down lists </li>
<li>Search for the location as a different kind of location </li>
<li>Enter a new location</li></ul><br/>
<p>Choose locations from the lists highlighted on the page.</p><br/>
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list</li></ul><br/>
<p>Some locations have further locations within them:&nbsp; </p>
<ul>
<li>Some have the words �More options for�� written in front of them: </li>
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<h3>Changing the kind of location</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If the journey planner didn''t find any matches for the location you typed in, it may be because the journey planner didn''t match the type of location with the location you typed in.</p>
<p>&nbsp;</p>
<p>Select another kind of location (e.g. "Address/postcode") and select the button next to it. The journey planner will then show you a list of possible locations for this kind of location.</p>
<p>&nbsp;</p>
<p>It is important that you select the appropriate type of location. For example, if you are looking for a railway station, but you select the "Address/postcode" category, the journey planner will not be able to find it.</p></blockquote>
<h4>Once you have confirmed all the highlighted sections in this page, click ''Next''.&nbsp; </h4>'
,'<h2>Help</h2><br/><br/>
<h3>Cadarnhau lleoliad i deithio ohono neu iddo</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud un o''r canlynol:</p>
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr </li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad </li>
<li>Rhoi lleoliad newydd</li></ul>
<h4>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen</h4>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr. </li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:</p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau </li>
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi </li></ul><br/></blockquote>
<h3>Newid y math o leoliad</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p><br/>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad. </p><br/>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p><br/></blockquote>
<blockquote></blockquote>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</strong></p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/> </li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewisch "Tocyn dychwel agored" yn y rhestro o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul><br/>
<p><strong>2. Dewiswch sut y dymunwch nodi''r amserau</strong></p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Dewis ''<strong>Gadael am</strong>'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li>
<li>Dewis''<strong>Cyrraedd erbyn</strong>'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/>
<p><strong>3. Dewiswch yr amserau yr hoffech deithio </strong></p>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul><br/></blockquote>
<h3>Cadarnhau lleoliadau i deithio drwyddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Cadarnhau lleoliad i deithio ohono neu iddo</h4>
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud un o''r canlynol:<br/></p>
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr </li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad </li>
<li>Rhoi lleoliad newydd</li></ul><br/>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p><br/>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr. Cliciwch ar ''Nesa'' ar waelod y dudalen</li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:&nbsp; </p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau </li>
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li></ul><br/></blockquote>
<h3>Newid y math o leoliad</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p><br/>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad. </p><br/>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p><br/></blockquote>
<h4>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.&nbsp; </h4>'

GO

-- help page content for find a bus input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindABusInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, an underground station, a light rail station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �London�, Derby�, �Newcastle�, �Gatwick�.</div></li>
<li>
<div><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, a tram stop, or a railway station, e.g. �Trafalgar Square�, �Whitley Bay�, �Piccadilly Circus�.</div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting outward and return journey dates</h4>
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul>
<p>&nbsp;</p></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting types of transport</h4>
<ul>
<li>
<div><strong>Choose the types of transport you would like to use</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Untick the types of transport that you are not interested in using. However, at least one type must remain ticked<br/>The Journey Planner will search for journeys that involve the <strong>ticked</strong> types of public transport.&nbsp; However, it may not necessarily find journeys that use all the types that are selected.&nbsp; This is because the Journey Planner uses <strong>all</strong> the criteria you enter and searches for the most suitable journeys only.</p></blockquote></blockquote>
<h3>Public Transport journey details</h3>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required </li>
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes </li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly </li>
<li>''Average'' if you can make the changes at an average pace </li>
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Walking</h3>
<p>Some journeys will require you to walk in order to get from a location to a stop (or vice versa), or from one stop to another stop.&nbsp; </p>
<p>&nbsp;</p>
<p><strong>Speed (of walking)</strong></p>
<p>Choose your walking speed.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you tend to walk quickly </li>
<li>''Average'' if you walk at an average pace </li>
<li>''Slow''&nbsp; if you think you will be walking at a slower than average pace</li></ul>
<p>&nbsp;</p>
<p>For example you should choose ''Slow'' if you are travelling with heavy luggage or if you have a mobility problem.</p>
<p>&nbsp;</p>
<p><strong>Time (max.)</strong></p>
<p>Choose the maximum length of time you are prepared to spend walking between points in your journey from the ''drop-down'' list:</p>
<ul>
<li>''5'' minutes&nbsp;</li> 
<li>''10'' minutes </li>
<li>''15'' minutes </li>
<li>''20'' minutes&nbsp; </li>
<li>''25'' minutes </li>
<li>''30'' minutes </li></ul>
<p>Please note that setting a low maximum walking speed may limit the number of journeys that can be found.&nbsp; If possible, it is recommended you choose 30 minutes.</p></blockquote>
<h3>Journey options</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Travelling via a location</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<blockquote></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>At this point the Journey Planner will search for the locations you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p></blockquote>
<blockquote></blockquote>'
,'<h3>newDewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.</p></blockquote>
<p></p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref</strong><strong>'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� </div></li>
<li>
<div><strong>''Gorsaf/Maes awyr'':</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi. Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick".</div></li>
<li>
<div><strong>''Pob arhosfan":</strong> Os dewiswch hwn, gallwch deipio enw arhosfan bws, stop tanddaearol, stop metro neu stop tram neu orsaf rheilffordd e.e. Trafalgar Square, Whitley Bay, Piccadilly Circus. </div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>Gallwch glicio ar y botwm ''Canfyddwch ar y map'' i ganfod lleoliad ar fap.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno). Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis mathau o gludiant</h4>
<ul>
<li>
<div><strong>Dewiswch y mathau o gludiant y dymunwch eu defnyddio</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dadgliciwch y mathau o gludiant nad oes gennych ddiddordeb yn eu defnyddio. Ond rhaid sicrhau bod un math o leiaf yn dal wedi ei glicio <br/>Bydd y Cynlluniwr Siwrnai yn chwilio am siwrneion sy''n ymwneud �''r mathau o gludiant cyhoeddus a diciwyd. Ond mae''n bosibl na fydd o anghenraid yn darganfod siwrneion sy''n defnyddio''r holl fathau sy''n cael eu dewis. Mae hyn oherwydd bod y Cynlluniwr Siwrnai yn defnyddio''r holl feini prawf yr ydych wedi eu nodi ac yn chwilio am y siwrneion mwyaf addas yn unig.</p></blockquote>
<h3>Manylion siwrnai cludiant cyhoeddus</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</h4>
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol </li>
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</li> 
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau) </strong></p>
<p>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym </li>
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p>&nbsp;</p></blockquote>
<h3>Cerdded</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Bydd rhai siwrneion yn ei gwneud yn ofynnol i chi gerdded er mwyn mynd o leoliad i arhosfan (neu i''r gwrthwyneb), neu o un arhosfan i arhosfan arall. </p>
<p>&nbsp;</p>
<p><strong>Cyflymder (cerdded) </strong></p>
<p>Dewiswch eich cyflymder cerdded. Dewiswch:</p>
<ul>
<li>''Cyflym'' os tueddwch i gerdded yn gyflym </li>
<li>''Cyfartaledd'' os ydych yn cerdded ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn cerdded ar gyflymder arafach na''r cyffredin</li></ul>
<p>&nbsp;</p>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn teithio gyda bagiau trymion neu os oes gennych broblem gyda symud.</p>
<p>&nbsp;</p>
<p><strong>Amser (uchafswm) </strong></p>
<p>Dewiswch uchafswm hyd yr amser yr ydych yn barod i''w dreulio yn cerdded rhwng pwyntiau yn eich siwrnai o''r rhestr a ollyngir i lawr:</p>
<ul>
<li>''5'' munud</li> 
<li>''10'' munud </li>
<li>''15'' munud </li>
<li>''20'' munud </li>
<li>''25'' munud </li>
<li>''30'' munud</li></ul>
<p>Nodwch y gall gosod uchafswm cyflymder cerdded isel gyfyngu ar nifer y siwrneion y gellir dod o hyd iddynt. Os yn bosibl, argymhellir eich bod yn dewis 30 munud.</p></blockquote>
<h3>Dewisiadau ar ran siwrneion</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Teithio drwy leoliad</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote>
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch: </p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru) </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr. Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol: </p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl. </p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km. </p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion</h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�. </p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help. Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yma bydd y Cynlluniwr Siwrnai yn chwilio am y lleoliad yr ydych wedi ei deipio. Os oes mwy nag un lleoliad yn debyg i''r lleoliad y bu i chi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p></blockquote>'

GO

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindABusInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, an underground station, a light rail station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �London�, Derby�, �Newcastle�, �Gatwick�.</div></li>
<li>
<div><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, a tram stop, or a railway station, e.g. �Trafalgar Square�, �Whitley Bay�, �Piccadilly Circus�.</div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting outward and return journey dates</h4>
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul>
<p>&nbsp;</p></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting types of transport</h4>
<ul>
<li>
<div><strong>Choose the types of transport you would like to use</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Untick the types of transport that you are not interested in using. However, at least one type must remain ticked<br/>The Journey Planner will search for journeys that involve the <strong>ticked</strong> types of public transport.&nbsp; However, it may not necessarily find journeys that use all the types that are selected.&nbsp; This is because the Journey Planner uses <strong>all</strong> the criteria you enter and searches for the most suitable journeys only.</p></blockquote></blockquote>
<h3>Public Transport journey details</h3>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required </li>
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes </li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly </li>
<li>''Average'' if you can make the changes at an average pace </li>
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Walking</h3>
<p>Some journeys will require you to walk in order to get from a location to a stop (or vice versa), or from one stop to another stop.&nbsp; </p>
<p>&nbsp;</p>
<p><strong>Speed (of walking)</strong></p>
<p>Choose your walking speed.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you tend to walk quickly </li>
<li>''Average'' if you walk at an average pace </li>
<li>''Slow''&nbsp; if you think you will be walking at a slower than average pace</li></ul>
<p>&nbsp;</p>
<p>For example you should choose ''Slow'' if you are travelling with heavy luggage or if you have a mobility problem.</p>
<p>&nbsp;</p>
<p><strong>Time (max.)</strong></p>
<p>Choose the maximum length of time you are prepared to spend walking between points in your journey from the ''drop-down'' list:</p>
<ul>
<li>''5'' minutes&nbsp;</li> 
<li>''10'' minutes </li>
<li>''15'' minutes </li>
<li>''20'' minutes&nbsp; </li>
<li>''25'' minutes </li>
<li>''30'' minutes </li></ul>
<p>Please note that setting a low maximum walking speed may limit the number of journeys that can be found.&nbsp; If possible, it is recommended you choose 30 minutes.</p></blockquote>
<h3>Journey options</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Travelling via a location</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<blockquote></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>At this point the Journey Planner will search for the locations you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p></blockquote>
<blockquote></blockquote>'
,'<h3>newDewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.</p></blockquote>
<p></p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref</strong><strong>'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� </div></li>
<li>
<div><strong>''Gorsaf/Maes awyr'':</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi. Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick".</div></li>
<li>
<div><strong>''Pob arhosfan":</strong> Os dewiswch hwn, gallwch deipio enw arhosfan bws, stop tanddaearol, stop metro neu stop tram neu orsaf rheilffordd e.e. Trafalgar Square, Whitley Bay, Piccadilly Circus. </div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>Gallwch glicio ar y botwm ''Canfyddwch ar y map'' i ganfod lleoliad ar fap.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno). Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis mathau o gludiant</h4>
<ul>
<li>
<div><strong>Dewiswch y mathau o gludiant y dymunwch eu defnyddio</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dadgliciwch y mathau o gludiant nad oes gennych ddiddordeb yn eu defnyddio. Ond rhaid sicrhau bod un math o leiaf yn dal wedi ei glicio <br/>Bydd y Cynlluniwr Siwrnai yn chwilio am siwrneion sy''n ymwneud �''r mathau o gludiant cyhoeddus a diciwyd. Ond mae''n bosibl na fydd o anghenraid yn darganfod siwrneion sy''n defnyddio''r holl fathau sy''n cael eu dewis. Mae hyn oherwydd bod y Cynlluniwr Siwrnai yn defnyddio''r holl feini prawf yr ydych wedi eu nodi ac yn chwilio am y siwrneion mwyaf addas yn unig.</p></blockquote>
<h3>Manylion siwrnai cludiant cyhoeddus</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</h4>
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol </li>
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</li> 
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau) </strong></p>
<p>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym </li>
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p>&nbsp;</p></blockquote>
<h3>Cerdded</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Bydd rhai siwrneion yn ei gwneud yn ofynnol i chi gerdded er mwyn mynd o leoliad i arhosfan (neu i''r gwrthwyneb), neu o un arhosfan i arhosfan arall. </p>
<p>&nbsp;</p>
<p><strong>Cyflymder (cerdded) </strong></p>
<p>Dewiswch eich cyflymder cerdded. Dewiswch:</p>
<ul>
<li>''Cyflym'' os tueddwch i gerdded yn gyflym </li>
<li>''Cyfartaledd'' os ydych yn cerdded ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn cerdded ar gyflymder arafach na''r cyffredin</li></ul>
<p>&nbsp;</p>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn teithio gyda bagiau trymion neu os oes gennych broblem gyda symud.</p>
<p>&nbsp;</p>
<p><strong>Amser (uchafswm) </strong></p>
<p>Dewiswch uchafswm hyd yr amser yr ydych yn barod i''w dreulio yn cerdded rhwng pwyntiau yn eich siwrnai o''r rhestr a ollyngir i lawr:</p>
<ul>
<li>''5'' munud</li> 
<li>''10'' munud </li>
<li>''15'' munud </li>
<li>''20'' munud </li>
<li>''25'' munud </li>
<li>''30'' munud</li></ul>
<p>Nodwch y gall gosod uchafswm cyflymder cerdded isel gyfyngu ar nifer y siwrneion y gellir dod o hyd iddynt. Os yn bosibl, argymhellir eich bod yn dewis 30 munud.</p></blockquote>
<h3>Dewisiadau ar ran siwrneion</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Teithio drwy leoliad</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote>
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch: </p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru) </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr. Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol: </p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl. </p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km. </p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion</h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�. </p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help. Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yma bydd y Cynlluniwr Siwrnai yn chwilio am y lleoliad yr ydych wedi ei deipio. Os oes mwy nag un lleoliad yn debyg i''r lleoliad y bu i chi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p></blockquote>'

GO

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindABusInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, an underground station, a light rail station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �London�, Derby�, �Newcastle�, �Gatwick�.</div></li>
<li>
<div><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, a tram stop, or a railway station, e.g. �Trafalgar Square�, �Whitley Bay�, �Piccadilly Circus�.</div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting outward and return journey dates</h4>
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul>
<p>&nbsp;</p></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting types of transport</h4>
<ul>
<li>
<div><strong>Choose the types of transport you would like to use</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Untick the types of transport that you are not interested in using. However, at least one type must remain ticked<br/>The Journey Planner will search for journeys that involve the <strong>ticked</strong> types of public transport.&nbsp; However, it may not necessarily find journeys that use all the types that are selected.&nbsp; This is because the Journey Planner uses <strong>all</strong> the criteria you enter and searches for the most suitable journeys only.</p></blockquote></blockquote>
<h3>Public Transport journey details</h3>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required </li>
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes </li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly </li>
<li>''Average'' if you can make the changes at an average pace </li>
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Walking</h3>
<p>Some journeys will require you to walk in order to get from a location to a stop (or vice versa), or from one stop to another stop.&nbsp; </p>
<p>&nbsp;</p>
<p><strong>Speed (of walking)</strong></p>
<p>Choose your walking speed.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you tend to walk quickly </li>
<li>''Average'' if you walk at an average pace </li>
<li>''Slow''&nbsp; if you think you will be walking at a slower than average pace</li></ul>
<p>&nbsp;</p>
<p>For example you should choose ''Slow'' if you are travelling with heavy luggage or if you have a mobility problem.</p>
<p>&nbsp;</p>
<p><strong>Time (max.)</strong></p>
<p>Choose the maximum length of time you are prepared to spend walking between points in your journey from the ''drop-down'' list:</p>
<ul>
<li>''5'' minutes&nbsp;</li> 
<li>''10'' minutes </li>
<li>''15'' minutes </li>
<li>''20'' minutes&nbsp; </li>
<li>''25'' minutes </li>
<li>''30'' minutes </li></ul>
<p>Please note that setting a low maximum walking speed may limit the number of journeys that can be found.&nbsp; If possible, it is recommended you choose 30 minutes.</p></blockquote>
<h3>Journey options</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Travelling via a location</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<blockquote></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>At this point the Journey Planner will search for the locations you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p></blockquote>
<blockquote></blockquote>'
,'<h3>newDewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.</p></blockquote>
<p></p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref</strong><strong>'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� </div></li>
<li>
<div><strong>''Gorsaf/Maes awyr'':</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi. Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick".</div></li>
<li>
<div><strong>''Pob arhosfan":</strong> Os dewiswch hwn, gallwch deipio enw arhosfan bws, stop tanddaearol, stop metro neu stop tram neu orsaf rheilffordd e.e. Trafalgar Square, Whitley Bay, Piccadilly Circus. </div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>Gallwch glicio ar y botwm ''Canfyddwch ar y map'' i ganfod lleoliad ar fap.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno). Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis mathau o gludiant</h4>
<ul>
<li>
<div><strong>Dewiswch y mathau o gludiant y dymunwch eu defnyddio</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dadgliciwch y mathau o gludiant nad oes gennych ddiddordeb yn eu defnyddio. Ond rhaid sicrhau bod un math o leiaf yn dal wedi ei glicio <br/>Bydd y Cynlluniwr Siwrnai yn chwilio am siwrneion sy''n ymwneud �''r mathau o gludiant cyhoeddus a diciwyd. Ond mae''n bosibl na fydd o anghenraid yn darganfod siwrneion sy''n defnyddio''r holl fathau sy''n cael eu dewis. Mae hyn oherwydd bod y Cynlluniwr Siwrnai yn defnyddio''r holl feini prawf yr ydych wedi eu nodi ac yn chwilio am y siwrneion mwyaf addas yn unig.</p></blockquote>
<h3>Manylion siwrnai cludiant cyhoeddus</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</h4>
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol </li>
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</li> 
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau) </strong></p>
<p>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym </li>
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p>&nbsp;</p></blockquote>
<h3>Cerdded</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Bydd rhai siwrneion yn ei gwneud yn ofynnol i chi gerdded er mwyn mynd o leoliad i arhosfan (neu i''r gwrthwyneb), neu o un arhosfan i arhosfan arall. </p>
<p>&nbsp;</p>
<p><strong>Cyflymder (cerdded) </strong></p>
<p>Dewiswch eich cyflymder cerdded. Dewiswch:</p>
<ul>
<li>''Cyflym'' os tueddwch i gerdded yn gyflym </li>
<li>''Cyfartaledd'' os ydych yn cerdded ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn cerdded ar gyflymder arafach na''r cyffredin</li></ul>
<p>&nbsp;</p>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn teithio gyda bagiau trymion neu os oes gennych broblem gyda symud.</p>
<p>&nbsp;</p>
<p><strong>Amser (uchafswm) </strong></p>
<p>Dewiswch uchafswm hyd yr amser yr ydych yn barod i''w dreulio yn cerdded rhwng pwyntiau yn eich siwrnai o''r rhestr a ollyngir i lawr:</p>
<ul>
<li>''5'' munud</li> 
<li>''10'' munud </li>
<li>''15'' munud </li>
<li>''20'' munud </li>
<li>''25'' munud </li>
<li>''30'' munud</li></ul>
<p>Nodwch y gall gosod uchafswm cyflymder cerdded isel gyfyngu ar nifer y siwrneion y gellir dod o hyd iddynt. Os yn bosibl, argymhellir eich bod yn dewis 30 munud.</p></blockquote>
<h3>Dewisiadau ar ran siwrneion</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Teithio drwy leoliad</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote>
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch: </p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru) </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr. Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol: </p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl. </p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km. </p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion</h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�. </p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help. Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yma bydd y Cynlluniwr Siwrnai yn chwilio am y lleoliad yr ydych wedi ei deipio. Os oes mwy nag un lleoliad yn debyg i''r lleoliad y bu i chi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p></blockquote>'

GO

-- help page content for find a car input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindACarInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�</div></li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year<br/>or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the locationor<br/>� Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Car journey details</h4>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the Journey Planner will select the best driving route. Select:</p>
<ul>
<li>
<div>''Quickest'' if you would like a route with the shortest driving time</div></li>
<li>
<div>''Shortest'' if you would like a route with the shortest distance</div></li>
<li>
<div>''Most fuel economic'' if you would like a route with the lowest fuel consumption</div></li>
<li>
<div>''Cheapest overall'' if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau </h5>
<p>&nbsp;</p>
<p><span class="HtmlPlaceholderControl1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch</span>.&nbsp; <span class="HtmlPlaceholderControl1">Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</span></p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.</p>
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau </h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>"Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�.&nbsp; Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Gorsaf/Maes awyr":</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick"</div></li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno).&nbsp; Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt </h5></blockquote>
<blockquote>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu </li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau </h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad<br/>� Ddewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio </h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Manylion siwrnai car </h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch:</p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr.&nbsp; Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol:</p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car </h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl.</p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km.</p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion &nbsp; </h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai.&nbsp;&nbsp; Teipiwch 1 ffordd ym mhob blwch &nbsp; e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.&nbsp; Teipiwch 1 ffordd ym mhob blwch. e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''. </h3>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindACarInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�</div></li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year<br/>or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the locationor<br/>� Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Car journey details</h4>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the Journey Planner will select the best driving route. Select:</p>
<ul>
<li>
<div>''Quickest'' if you would like a route with the shortest driving time</div></li>
<li>
<div>''Shortest'' if you would like a route with the shortest distance</div></li>
<li>
<div>''Most fuel economic'' if you would like a route with the lowest fuel consumption</div></li>
<li>
<div>''Cheapest overall'' if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau </h5>
<p>&nbsp;</p>
<p><span class="HtmlPlaceholderControl1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch</span>.&nbsp; <span class="HtmlPlaceholderControl1">Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</span></p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.</p>
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau </h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>"Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�.&nbsp; Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Gorsaf/Maes awyr":</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick"</div></li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno).&nbsp; Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt </h5></blockquote>
<blockquote>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu </li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau </h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad<br/>� Ddewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio </h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Manylion siwrnai car </h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch:</p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr.&nbsp; Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol:</p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car </h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl.</p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km.</p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion &nbsp; </h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai.&nbsp;&nbsp; Teipiwch 1 ffordd ym mhob blwch &nbsp; e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.&nbsp; Teipiwch 1 ffordd ym mhob blwch. e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''. </h3>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindACarInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�</div></li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year<br/>or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the locationor<br/>� Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Car journey details</h4>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the Journey Planner will select the best driving route. Select:</p>
<ul>
<li>
<div>''Quickest'' if you would like a route with the shortest driving time</div></li>
<li>
<div>''Shortest'' if you would like a route with the shortest distance</div></li>
<li>
<div>''Most fuel economic'' if you would like a route with the lowest fuel consumption</div></li>
<li>
<div>''Cheapest overall'' if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau </h5>
<p>&nbsp;</p>
<p><span class="HtmlPlaceholderControl1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch</span>.&nbsp; <span class="HtmlPlaceholderControl1">Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</span></p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.</p>
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau </h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>"Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�.&nbsp; Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Gorsaf/Maes awyr":</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick"</div></li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno).&nbsp; Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt </h5></blockquote>
<blockquote>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu </li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau </h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad<br/>� Ddewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio </h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Manylion siwrnai car </h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch:</p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr.&nbsp; Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol:</p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car </h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl.</p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km.</p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion &nbsp; </h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai.&nbsp;&nbsp; Teipiwch 1 ffordd ym mhob blwch &nbsp; e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.&nbsp; Teipiwch 1 ffordd ym mhob blwch. e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''. </h3>'

GO

-- help page content for find car park input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindCarParkInput'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black;"><b style="mso-bidi-font-weight: normal">To find nearest car park:</b></span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; ">&nbsp;</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; ">1. Select the type of location you would like to find car parks near by clicking ''Town/distict/village'', ''Address/postcode'', ''Facility/attraction'', or ''Station/airport''</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><br/>2. Enter the location that you would like to find car parks near and click ''Next''</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">3. Confirm the location (if prompted), and click "Next"</p>'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><b style="mso-bidi-font-weight: normal"><span style="color: black; mso-fareast-language: EN-GB">I ddarganfod y maes parcio agosaf:</span></b></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; mso-fareast-language: EN-GB">&nbsp;</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; mso-fareast-language: EN-GB">1. Dewiswch y math o leoliad yr hoffech ddarganfod meysydd parcio yn ei ymyl drwy glicio ar ''Tref/rhanbarth/pentref'', ''Cyfeiriad/c�d post'', ''Cyfleuster/atyniad'', neu ''Gorsaf/maes awyr''</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><br/>2. Rhowch y lleoliad yr hoffech ddarganfod meysydd parcio yn ei ymyl a chliciwch ar ''Nesaf''</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">3. Cadarnhewch y lleoliad (os gofynnir i chi), a chliciwch ''Nesaf''</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindCarParkInput'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black;"><b style="mso-bidi-font-weight: normal">To find nearest car park:</b></span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; ">&nbsp;</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; ">1. Select the type of location you would like to find car parks near by clicking ''Town/distict/village'', ''Address/postcode'', ''Facility/attraction'', or ''Station/airport''</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><br/>2. Enter the location that you would like to find car parks near and click ''Next''</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">3. Confirm the location (if prompted), and click "Next"</p>'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><b style="mso-bidi-font-weight: normal"><span style="color: black; mso-fareast-language: EN-GB">I ddarganfod y maes parcio agosaf:</span></b></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; mso-fareast-language: EN-GB">&nbsp;</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; mso-fareast-language: EN-GB">1. Dewiswch y math o leoliad yr hoffech ddarganfod meysydd parcio yn ei ymyl drwy glicio ar ''Tref/rhanbarth/pentref'', ''Cyfeiriad/c�d post'', ''Cyfleuster/atyniad'', neu ''Gorsaf/maes awyr''</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><br/>2. Rhowch y lleoliad yr hoffech ddarganfod meysydd parcio yn ei ymyl a chliciwch ar ''Nesaf''</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">3. Cadarnhewch y lleoliad (os gofynnir i chi), a chliciwch ''Nesaf''</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindCarParkInput'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black;"><b style="mso-bidi-font-weight: normal">To find nearest car park:</b></span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; ">&nbsp;</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; ">1. Select the type of location you would like to find car parks near by clicking ''Town/distict/village'', ''Address/postcode'', ''Facility/attraction'', or ''Station/airport''</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><br/>2. Enter the location that you would like to find car parks near and click ''Next''</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">3. Confirm the location (if prompted), and click "Next"</p>'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><b style="mso-bidi-font-weight: normal"><span style="color: black; mso-fareast-language: EN-GB">I ddarganfod y maes parcio agosaf:</span></b></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; mso-fareast-language: EN-GB">&nbsp;</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><span style="color: black; mso-fareast-language: EN-GB">1. Dewiswch y math o leoliad yr hoffech ddarganfod meysydd parcio yn ei ymyl drwy glicio ar ''Tref/rhanbarth/pentref'', ''Cyfeiriad/c�d post'', ''Cyfleuster/atyniad'', neu ''Gorsaf/maes awyr''</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;"><br/>2. Rhowch y lleoliad yr hoffech ddarganfod meysydd parcio yn ei ymyl a chliciwch ar ''Nesaf''</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt;">3. Cadarnhewch y lleoliad (os gofynnir i chi), a chliciwch ''Nesaf''</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindCarParkAmbiguity'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Choose a location from the yellow drop-down list.<br/>If you cannot find the location you want in the list, you can either: </span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l23 level1 lfo12; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Search for a different kind of location (e.g. by selecting "Address/postcode")</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l20 level1 lfo13; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Enter a new location (by clicking "New location")</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB"></span>&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Then click "Next"&nbsp;</span></p><span style="FONT-SIZE: 11pt; COLOR: black; FONT-FAMILY: Arial; mso-fareast-language: EN-GB; mso-bidi-font-size: 10.0pt; mso-fareast-font-family: ''Times New Roman''; mso-bidi-font-family: ''Times New Roman''; mso-ansi-language: EN-GB; mso-bidi-language: AR-SA"></span>'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br/>Os na fedrwch ddod o hyd i''r lleoliad a ddymunwch yn y rhestr, gallwch naill ai:</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l23 level1 lfo12; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l20 level1 lfo13; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Roi lleoliad newydd (drwy glicio ''Lleoliad newydd'')</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB"></span>&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Yna chliciwch ''Nesaf''</span></p><span style="FONT-SIZE: 11pt; COLOR: black; FONT-FAMILY: Arial; mso-fareast-language: EN-GB; mso-bidi-font-size: 10.0pt; mso-fareast-font-family: ''Times New Roman''; mso-bidi-font-family: ''Times New Roman''; mso-ansi-language: EN-GB; mso-bidi-language: AR-SA"></span>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindCarParkAmbiguity'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Choose a location from the yellow drop-down list.<br/>If you cannot find the location you want in the list, you can either: </span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l23 level1 lfo12; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Search for a different kind of location (e.g. by selecting "Address/postcode")</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l20 level1 lfo13; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Enter a new location (by clicking "New location")</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB"></span>&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Then click "Next"&nbsp;</span></p><span style="FONT-SIZE: 11pt; COLOR: black; FONT-FAMILY: Arial; mso-fareast-language: EN-GB; mso-bidi-font-size: 10.0pt; mso-fareast-font-family: ''Times New Roman''; mso-bidi-font-family: ''Times New Roman''; mso-ansi-language: EN-GB; mso-bidi-language: AR-SA"></span>'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br/>Os na fedrwch ddod o hyd i''r lleoliad a ddymunwch yn y rhestr, gallwch naill ai:</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l23 level1 lfo12; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l20 level1 lfo13; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Roi lleoliad newydd (drwy glicio ''Lleoliad newydd'')</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB"></span>&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Yna chliciwch ''Nesaf''</span></p><span style="FONT-SIZE: 11pt; COLOR: black; FONT-FAMILY: Arial; mso-fareast-language: EN-GB; mso-bidi-font-size: 10.0pt; mso-fareast-font-family: ''Times New Roman''; mso-bidi-font-family: ''Times New Roman''; mso-ansi-language: EN-GB; mso-bidi-language: AR-SA"></span>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindCarParkAmbiguity'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Choose a location from the yellow drop-down list.<br/>If you cannot find the location you want in the list, you can either: </span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l23 level1 lfo12; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Search for a different kind of location (e.g. by selecting "Address/postcode")</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l20 level1 lfo13; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Enter a new location (by clicking "New location")</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB"></span>&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Then click "Next"&nbsp;</span></p><span style="FONT-SIZE: 11pt; COLOR: black; FONT-FAMILY: Arial; mso-fareast-language: EN-GB; mso-bidi-font-size: 10.0pt; mso-fareast-font-family: ''Times New Roman''; mso-bidi-font-family: ''Times New Roman''; mso-ansi-language: EN-GB; mso-bidi-language: AR-SA"></span>'
,'<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br/>Os na fedrwch ddod o hyd i''r lleoliad a ddymunwch yn y rhestr, gallwch naill ai:</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l23 level1 lfo12; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</span></p>
<p class="MsoNormal" style="background: white; margin: 5pt 0cm 5pt 40.2pt; text-indent: -18pt; mso-pagination: widow-orphan; mso-list: l20 level1 lfo13; tab-stops: list 36.0pt"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Symbol; mso-fareast-language: EN-GB">�<span style="FONT: 7pt ''Times New Roman''">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span style="COLOR: black; mso-fareast-language: EN-GB">Roi lleoliad newydd (drwy glicio ''Lleoliad newydd'')</span></p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB"></span>&nbsp;</p>
<p class="MsoNormal" style="background: white; margin: 0cm 0cm 2.4pt; mso-pagination: widow-orphan"><span style="COLOR: black; mso-fareast-language: EN-GB">Yna chliciwch ''Nesaf''</span></p><span style="FONT-SIZE: 11pt; COLOR: black; FONT-FAMILY: Arial; mso-fareast-language: EN-GB; mso-bidi-font-size: 10.0pt; mso-fareast-font-family: ''Times New Roman''; mso-bidi-font-family: ''Times New Roman''; mso-ansi-language: EN-GB; mso-bidi-language: AR-SA"></span>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1241
SET @ScriptDesc = 'Update help content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO