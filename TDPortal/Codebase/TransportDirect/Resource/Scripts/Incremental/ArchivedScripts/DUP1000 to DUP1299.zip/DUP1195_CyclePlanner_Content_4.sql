-- ***********************************************
-- NAME 		: DUP1195_CyclePlanner_Content_4.sql
-- DESCRIPTION 		: Script to add Cycle planner content
--			: (Overrides content in DUP1165_CyclePlanner_Content_3.sql which has now been locked)
-- AUTHOR		: Mitesh Modi
-- DATE			: 24 Nov 2008
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Home page and Cycle input page
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelFindPageTitle.Text', 'Find a cycle route', 'Canfod llwybr beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelFromToTitle', 'Enter two locations to find cycle directions', 'Nodwch ddau leoliad i ganfod cyfarwyddiadau beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.AppendPageTitle', 'Find a cycle route | ', 'Canfod llwybr beicio | '

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CommandBack.Text', 'Back', 'Yn'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.imageFindCycle.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleJourney.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleJourney.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.imageFindCycle.AlternateText', 'Cycle route', 'Llwybr beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblCycle', 'Find a <br />cycle route', 'Canfod llwybr <br />beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.lblFindCycle', 'Find a cycle <br />route', 'Canfod llwybr <br />beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.imageFindCycleSkipLink.AlternateText', 'Skip to Find a cycle route', 'Symud ymlaen i Ganfod llwybr beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'WaitPageMessage.FindACycle', 'Thank you for waiting while Transport Direct calculates your cycle route.', 'Diolch am aros tra bo Transport Direct yn cyfrifo eich llwybr beicio.'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCycleInput.clientLink.BookmarkTitle', 'Transport Direct Find a Cycle route', 'Canfod llwybr beicio Transport Direct'

--------------------------------------------------------------------------------------------------------------------------------
-- Gazzatteer options
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'


EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'


--------------------------------------------------------------------------------------------------------------------------------
-- Preferences control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelCycleJourneyOptions', 'Cycle route options', 'Opsiynau llwybr beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelSpeedMax', 'Speed (max)', 'Cyflymder (mwyaf)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelIPrefer', 'I prefer, where possible, to <b> avoid:</b>', 'Os oes modd, mae''n well gennyf <b> osgoi:</b>'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelTravelVia', 'I want to travel via', 'Rwyf eisiau teithio drwy'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidSteepClimbs', 'Steep climbs', 'Dringfeydd serth'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidUnlitRoads', 'Unlit roads', 'Ffyrdd heb eu goleuo'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidWalkingYourBike', 'Walking your bike', 'Cerdded eich beic'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidTimeBased', 'Time based restrictions', 'Cyfyngiadau seiliedig ar amser'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.SpeedError', 
'The speed entered must be a number greater than {0} and less than {1}. Please enter a new value.', 
'Mae''n rhaid i''r cyflymder a nodwyd fod yn rhif uwch na {0} a llai na {1}. Nodwch werth newydd os gwelwch yn dda.'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelPenaltyFunctionOverride', 'Penalty Function override', 'Penalty Function override'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelPenaltyFunctionOverrideHelp', '', ''

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelPenaltyFunctionOverrideCall', '', ''

--------------------------------------------------------------------------------------------------------------------------------
-- Journey type control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCycleJourneyTypeControl.labelTypeOfJourney', 'Type of journey', 'Math o siwrnai'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCycleJourneyTypeControl.labelFind', 'Find', 'Canfod'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCycleJourneyTypeControl.labelJourneys', 'journey(s)', 'siwrneiau'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleJourneyType.Quickest', 'Quickest', 'Cyflymaf'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleJourneyType.Quietest', 'Quietest', 'cy Quietest'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleJourneyType.Recreational', 'Most recreational', 'cy Most recreational'

--------------------------------------------------------------------------------------------------------------------------------
-- Units speed dropdown
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UnitsSpeedDrop.mph', 'mph', 'mya'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UnitsSpeedDrop.kph', 'kph', 'cya'

--------------------------------------------------------------------------------------------------------------------------------
-- Validation
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.CyclePlannerUnavailableKey', 'Find a cycle journey is currently unavailable.', 
'Nid oes modd canfod siwrnai feicio ar hyn o bryd.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.CycleSpeedErrorKey', 'The cycle speed must be a number greater than zero. Please enter a new value.', 
'Mae''n rhaid bod y cyflymder beicio yn rhif uwch na dim. Nodwch werth newydd os gwelwch yn dda.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationHasNoPoint', 
'Cycle planning is not available within the area you have selected. Please choose a different start location and/or destination.', 
'Nid yw''r gwasanaeth cynllunio beicio ar gael yn yr ardal a ddewisoch. Dewiswch wahanol man cychwyn a/neu gyrchfan os gwelwch yn dda.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.DistanceBetweenLocationsTooGreat', 
'Transport Direct will only plan a cycle journey which has a maximum distance between the origin and destination of {0}km; the journey you requested was further than this.', 
'Dim ond siwrnai feicio sydd � phellter mwyaf o {0} cilometr rhwng y man cychwyn a''r cyrchfan y bydd Transport Direct yn ei chynllunio; roedd y siwrnai y gofynasoch amdani yn bellach na hyn.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.DistanceBetweenLocationsAndViaTooGreat', 
'Transport Direct will only plan a cycle journey which has a maximum distance between the origin, via and destination of {0}km; the journey you requested was further than this.',
'Dim ond siwrnai feicio sydd � phellter mwyaf o {0} cilometr rhwng y man cychwyn, y mannau canol a''r cyrchfan y bydd Transport Direct yn ei chynllunio; roedd y siwrnai y gofynasoch amdani yn bellach na hyn.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationInInvalidCycleArea', 
'At the moment we are able to plan cycle journeys in Merseyside.  Please click the ''clear page'' button below to enter new journey details.  To find out more please <a href="/Web2/Help/HelpInfo.aspx#A1.7">go to the FAQ on cycle data areas</a>.', 
'Ar hyn o bryd gallwn gynllunio siwrneiau beicio ym Glannau Mersi. Cliciwch y botwm ''clirio tudalen" isod i nodi manylion siwrnai newydd.  I ganfod mwy ewch i''r Cwestiynau Cyffredin ar ardaloedd data beicio <a href="/Web2/Help/HelpInfo.aspx#A1.7">os gwelwch yn dda</a>.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationPointsNotInSameCycleArea', 
'To plan a cycle journey on Transport Direct the journey origin, destination and via points must all be in the same area. The journey you requested contained points that were in different areas with no direct connection between them. To find out more please <a href="/Web2/Help/HelpInfo.aspx#A1.7">go to the FAQ on cycle data areas</a>.',
'I gynllunio siwrnai feicio ar Transport Direct mae''n rhaid bod man cychwyn, cyrchfan a mannau canol y siwrnai i gyd yn yr un ardal. Roedd y siwrnai y gofynasoch amdani yn cynnwys pwyntiau a oedd mewn gwahanol ardaloedd heb unrhyw gysylltiad uniongyrchol rhyngddynt. I ganfod mwy ewch i''r Cwestiynau Cyffredin ar ardaloedd data beicio <a href="/Web2/Help/HelpInfo.aspx#A1.7">os gwelwch yn dda</a>.'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle Planner service
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPInternalError', 
'Sorry we are currently unable to obtain a cycle journey using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'Mae''n ddrwg gennym nid ydym yn gallu cael siwrnai feicio gan ddefnyddio''r manylion a roesoch ar hyn o bryd. Helpwch ni i ymchwilio ymhellach i hyn drwy lenwi ffurflen adborth (gwnewch hyn drwy glicio "Cysylltwch � ni" ar waelod y dudalen)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPPartialReturn', 
'Sorry we are currently unable to obtain cycle journeys using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain cycle journeys using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPNoResults', 
'Sorry we are currently unable to obtain journeys using the details you have entered. Please try changing the dates/times of travel or changing some of the details entered. Click ''Amend'' to revise your journey request.<br> <br> If you still encounter problems please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'Mae''n flin gennym nid ydym yn gallu cael siwrneiau gan ddefnyddio''r manylion a roesoch ar hyn o bryd. Ceisiwch newid y dyddiadau/amseroedd teithio neu newid rhai o''r manylion a nodwyd. Cliciwch ''Newid'' i adolygu eich cais siwrnai.<br> <br> Os byddwch yn cael problemau o hyd helpwch ni i ymchwilio ymhellach i hyn drwy lenwi ffurflen adborth (gwnewch hyn drwy glicio "Cysylltwch � ni" ar waelod y dudalen)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPExternalMessage', 
'Message returned by Cycle Planner.',
'Dychwelwyd y neges gan y Cynlluniwr Beicio.'

EXEC AddtblContent
1, 1, 'langStrings', 'GradientProfiler.Results.GPInternalError', 
'Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'Mae''n ddrwg gennym nid ydym yn gallu cael y proffil graddiant ar gyfer eich siwrnai feicio ar hyn o bryd. Helpwch ni i ymchwilio ymhellach i hyn drwy lenwi ffurflen adborth (gwnewch hyn drwy glicio "Cysylltwch � ni" ar waelod y dudalen)'

EXEC AddtblContent
1, 1, 'langStrings', 'GradientProfiler.Results.GPPartialReturn', 
'Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

EXEC AddtblContent
1, 1, 'langStrings', 'GradientProfiler.Results.GPNoResults', 
'Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle Journey Results page
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.JourneyDetails.AppendPageTitle', 'Cycle Route Details | ', 'Manylion Llwybr Beicio | '

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelCycleAllDetailsControlTitle.Text.OutwardJourney', 'Details: Outward journey', 'Manylion: Siwrnai allanol'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelCycleAllDetailsControlTitle.Text.ReturnJourney', 'Details: Return journey', 'Manylion: Siwrnai ddychwel'


--------------------------------------------------------------------------------------------------------------------------------
-- Controls - All details holder
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.imageCycleEngland.URL', '/Web2/App_Themes/TransportDirect/images/gifs/softcontent/logo_cyclingengland_small.gif', '/Web2/App_Themes/TransportDirect/images/gifs/softcontent/logo_cyclingengland_small.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.imageCycleEngland.AltText', 'Cycling England logo', 'Logo Cycling England'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.hyperlinkCycleEngland.Text', 
'To find Cycling England Bikeability training near you select this link (opens new window)',
'I ddod o hyd i hyfforddiant Bikeability Cycling England yn agos i chi dewiswch y ddolen hon (mae''n agor ffenestr newydd)'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - GPX
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelTitle.Text', 'GPS Tracking', 'Olrhain GPS'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelDownloadDescription.Text', 
'Click on the link below to save a GPX file of your route for use on a GPS device', 
'Cliciwch ar y ddolen isod i gadw ffeil GPX o''ch llwybr i''w defnyddio ar ddyfais GPS'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.hyperlinkDownload.Text', 
'Download a GPX file of your route (opens new window)', 
'Llwythwch ffeil GPX o''ch llwybr i lawr (mae''n agor ffenestr newydd)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelError.Text', 
'There was a problem generating the GPX file for your journey. Please close your browser and try again or contact us if the problem continues to occur.', 
'Roedd problem yn cynhyrchu''r ffeil GPX ar gyfer eich siwrnai. Caewch eich porwr a rhowch gynnig arall arni neu cysylltwch � ni os bydd y broblem yn parhau.'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Graph
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTitle.Text', 'Gradient Profile', 'Proffil Graddiant'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelWait.Text', 'Please wait while the gradient profile of the journey is loaded', 'Arhoswch tra bo proffil graddiant y siwrnai''n cael ei lwytho'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.imageWait.AltText', 'Please wait', 'Arhoswch os gwelwch yn dda'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.imageWait.URL', '/Web2/App_Themes/TransportDirect/images/gifs/journeyPlanning/WaitIndicator.gif', '/Web2/App_Themes/TransportDirect/images/gifs/journeyPlanning/WaitIndicator.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelDistanceInMiles.Text', 'Distance in miles', 'Pellter mewn milltiroedd'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelDistanceInKms.Text', 'Distance in km', 'Pellter mewn cilometrau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelHighestPoint.Text', 'Highest point', 'Pwynt uchaf'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelLowestPoint.Text', 'Lowest point', 'Pwynt isaf'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTotalClimb.Text', 'Total climb', 'Cyfanswm yr esgyn'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTotalDescent.Text', 'Total descent', 'Cyfanswm y disgyn'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelNoScript.Text', 
'Please enable javascript to view the gradient profile', 
'Galluogwch javascript i weld y proffil graddiant hwn'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelError.Text', 
'We are currently unable to generate a gradient profile for this journey',
'Ar hyn o bryd, ni allwn gynhyrchu proffil graddiant ar gyfer y siwrnai hon'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.buttonShowTable.Text', 'Show table view', 'Dangos golwg tabl'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.buttonShowGraph.Text', 'Show graph view', 'Dangos golwg graff'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTableHeaderDistanceInMiles.Text', 'Distance in miles', 'Pellter mewn milltiroedd'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTableHeaderDistanceInKms.Text', 'Distance in kms', 'Pellter mewn cilometrau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTableHeaderHeight.Text', 'Height in metres', 'Uchder mewn metrau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelSRGradientProfile.Text', 
'Below is a chart showing a gradient profile of the cycle journey. Select the Show table view button to display a table of the journey distances and heights. ', 
'cy Below is a chart showing a gradient profile of the cycle journey. Select the Show table view button to display a table of the journey distances and heights. '

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Summary
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelSummaryOfDirections.Text', 'Summary of directions', 'Crynodeb o gyfarwyddiadau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelTotalDistance.Text', 'Total distance', 'Pellter cyfan'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelTotalDuration.Text', 'Total duration', 'Hyd cyfan'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelDistanceUnits.Text', 'Distance units', 'Unedau pellter'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.Avoid', 'Avoid', 'Osgoi'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.AndLowerCase', 'and', 'a'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.Journey', 'journey', 'siwrnai'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.Speed', 'Average cycling speed is', 'Y cyflymder beicio cyfartalog yw'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyAdvancedOptions.PenaltyFunction', 'Penalty function used:', 'Penalty function used:'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Details table
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.labelCycleJourneyDetailsTableControlTitle.Text', 
'Directions', 'Cyfarwyddiadau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerAccumulatedDistance.Miles', 'Trip miles', 'Milltiroedd taith'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerAccumulatedDistance.Kms', 'Trip kms', 'Cilometrau taith'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerDirections', 'Directions', 'Cyfarwyddiadau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerArrivalTime', 'Time', 'Amser'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.buttonShowMore', 'More details', 'cy More details'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.buttonShowLess', 'Fewer details', 'cy Fewer details'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CyclePathImage', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CyclePath.gif', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CyclePath.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CyclePathImage.AltText', 'Journey follows cycle specific infrastructure', 'Mae''r siwrnai''n dilyn seilwaith penodol i feiciau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CycleRouteImage', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleRoute.gif', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleRoute.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CycleRouteImage.AltText', 'Journey follows recommended cycle route', 'Mae''r siwrnai''n dilyn llwybr beicio a argymhellir'

        -- correct the road exclamation image 
EXEC AddtblContent
1, 1, 'langStrings', 'CarCostingDetails.highTrafficSymbol', 
'<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif" align="middle" alt="Road exclamation sign" />',
'<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif" align="middle" alt="Road exclamation sign" />'

--------------------------------------------------------------------------------------------------------------------------------
-- CO2 emissions control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDistanceInputControl.ImageCycle.URL', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CompareCO2_Cycle.gif', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CompareCO2_Cycle.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDistanceInputControl.ImageCycle.AlternateText', 
'Cycle icon with emissions', 
'Eicon beic ag allyriadau'

--------------------------------------------------------------------------------------------------------------------------------
-- Maps
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.Cycle', 
'StartLocation,EndLocation,ViaLocation,Tollbooth,FerryIcon',
'StartLocation,EndLocation,ViaLocation,Tollbooth,FerryIcon'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.ImageViaLocation', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CycleViaLocationKey.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CycleViaLocationKey.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.ImageViaLocation.AlternateText', 
'Key for Via',
'Cy Key for Via'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.ImageViaLocation.Print', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CycleViaLocationKeyPrint.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CycleViaLocationKeyPrint.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.LabelViaLocation', 
'Via location',
'Cy Via location'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.LabelViaLocation.Print', 
'Via',
'Cy Via'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyMapControl.ButtonDirectionsShow.Text', 
'Show directions',
'cy Show directions'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Printable map
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageHeaderTitle.DirectionsForJourney.Text', 'Directions', 'Cyfarwyddiadau'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageHeaderTitle.MapOfEntireJourney.Text', 'Map of entire journey', 'Map o''r siwrnai gyfan'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageItemTitle.Directions.Text', 'Detailed Directions: Page {0}', 'Cyfarwyddiadau Manwl: Tudalen {0}'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageItemTitle.Maps.Text', 'Detailed Maps: Page {0}', 'Mapiau Manwl: Tudalen {0}'

--------------------------------------------------------------------------------------------------------------------------------
-- Feedback page
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'PlanAJourneyControl.checkboxCycle.Text', 'Cycle', 'Beic'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Find a cycle journey', 'Find a cycle route', 'Canfod llwybr beicio'

EXEC AddtblContent
1, 1, 'langStrings', 'FeedbackViewer.VantiveId.Text', 'Support Ref', 'Support Ref'


--------------------------------------------------------------------------------------------------------------------------------
-- Skip links
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCycleInput.imageInputFormSkipLink.AlternateText', 'Skip to input form', 'Neidiwch i ffurf mewnbynnu'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.JourneyDetails.imageMainContentSkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.JourneyDetails.imageOutwardJourneySkipLink.AlternateText', 'Skip to outward journey details', 'Neidiwch i fanylion y siwrnai allanol'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.JourneyDetails.imageReturnJourneySkipLink.AlternateText', 'Skip to return journey details', 'Neidiwch i fanylion y siwrnai ddychwel'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle page Group 
--------------------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM tblGroup WHERE [Name] like 'journeyplanning_findcycleinput') 
	INSERT INTO tblGroup (GroupId, [Name])
	SELECT MAX(GroupId)+1, 'journeyplanning_findcycleinput' FROM tblGroup

DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findcycleinput')

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Information below input panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput', 
'<div class="PageSoftContentContainer">  <div class="PageSoftContent">
<p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p>
<ul>
<li>Amend the maximum speed at which you would like to travel</li>
<li>Choose to avoid unlit roads, walking with your bike, or steep climbs</li>
<li>Select a location you would like your journey to go via</li>
</ul><br/></div></div>'
,
'<div class="PageSoftContentContainer">  <div class="PageSoftContent">
<p>Cliciwch y botwm Opsiynau Manwl uchod i newid rhai o''r opsiynau canlynol ar gyfer eich siwrnai. Mae opsiynau''n cynnwys:</p>
<ul>
<li>Newid y cyflymder mwyaf yr hoffech deithio</li>
<li>Dewis osgoi ffyrdd heb eu goleuo, cerdded gyda''ch beic, neu ddringo serth</li>
<li>Dewis lleoliad yr hoffech i''ch siwrnai fynd drwyddo</li>
</ul><br/></div></div>'


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Latest news information - placeholder required to enable page to populate latest news
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput', 
'<h1>Latest... NOT POPULATED</h1>',
'<h1>Latest... NOT POPULATED</h1>'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Right hand information panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput',
'<div class="Column3Header"><div class="txtsevenbbl">
Cycle Planning</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
This is the first version of Transport Direct�s new cycle planner. We have worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure that there is good quality information on cycling in the following areas:
<ul>
<li> Merseyside</li>
</ul>
<br />
We would really appreciate your feedback on this initial version of the planner. Please click on �Contact us� at the bottom of the page to let us know what you think or report any problems.
<br /><br />
We will consider all feedback and will be improving the planner over the coming weeks. Work is also ongoing to provide cycle planning information in more areas - please check again soon if your local area is not yet available.
<br /><br />
Our aim is to provide national coverage for cycle planning soon. Once data is available in more areas and we have considered initial feedback, this page will be linked to from the main Transport Direct site.
<br /><br />
</td></tr>
</tbody></table></div>'
,
'<div class="Column3Header"><div class="txtsevenbbl">
Cycle Planning</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
This is the first version of Transport Direct�s new cycle planner. We have worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure that there is good quality information on cycling in the following areas:
<ul>
<li> Merseyside</li>
</ul>
<br />
We would really appreciate your feedback on this initial version of the planner. Please click on �Contact us� at the bottom of the page to let us know what you think or report any problems.
<br /><br />
We will consider all feedback and will be improving the planner over the coming weeks. Work is also ongoing to provide cycle planning information in more areas - please check again soon if your local area is not yet available.
<br /><br />
Our aim is to provide national coverage for cycle planning soon. Once data is available in more areas and we have considered initial feedback, this page will be linked to from the main Transport Direct site.
<br /><br />
</td></tr>
</tbody></table></div>'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle pages - Help urls
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'FindCycleInput.HelpPageUrl', 'Help/HelpFindACycleInput.aspx', 'Help/HelpFindACycleInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCycleInput.HelpAmbiguityUrl', 'Help/HelpFindACycleInput.aspx', 'Help/HelpFindACycleInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'CycleJourneyDetails.HelpPageUrl', 'Help/HelpCycleJourneyDetails.aspx', 'Help/HelpCycleJourneyDetails.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneySummary.HelpPageUrl.Cycle', 'Help/HelpCycleJourneySummary.aspx', 'Help/HelpCycleJourneySummary.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyMap.HelpPageUrl.Cycle', 'Help/HelpCycleJourneyMap.aspx', 'Help/HelpCycleJourneyMap.aspx'

--------------------------------------------------------------------------------------------------------------------------------
-- add the urls to ensure help pages are displayed
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- Find cycle input - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindACycleInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindACycleInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindACycleInput', 'Channel',
'/Channels/TransportDirect/Help/HelpFindACycleInput',
'/Channels/TransportDirect/Help/HelpFindACycleInput'

-- Find cycle input - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindACycleInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindACycleInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindACycleInput', 'Channel',
'/Channels/TransportDirect/Printer/HelpFindACycleInput',
'/Channels/TransportDirect/Printer/HelpFindACycleInput'

-- Cycle journey details - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyDetails', 'Channel',
'/Channels/TransportDirect/Help/HelpCycleJourneyDetails',
'/Channels/TransportDirect/Help/HelpCycleJourneyDetails'

-- Cycle journey details - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyDetails', 'Channel',
'/Channels/TransportDirect/Printer/HelpCycleJourneyDetails',
'/Channels/TransportDirect/Printer/HelpCycleJourneyDetails'


-- Cycle journey summary - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneySummary', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneySummary', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneySummary', 'Channel',
'/Channels/TransportDirect/Help/HelpCycleJourneySummary',
'/Channels/TransportDirect/Help/HelpCycleJourneySummary'

-- Cycle journey summary - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneySummary', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneySummary', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneySummary', 'Channel',
'/Channels/TransportDirect/Printer/HelpCycleJourneySummary',
'/Channels/TransportDirect/Printer/HelpCycleJourneySummary'

-- Cycle journey map - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyMap', 'Channel',
'/Channels/TransportDirect/Help/HelpCycleJourneyMap',
'/Channels/TransportDirect/Help/HelpCycleJourneyMap'

-- Cycle journey map - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyMap', 'Channel',
'/Channels/TransportDirect/Printer/HelpCycleJourneyMap',
'/Channels/TransportDirect/Printer/HelpCycleJourneyMap'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Help text
--------------------------------------------------------------------------------------------------------------------------------
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'helpfulljp')

EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindACycleInput',
'
<h3>Selecting locations to travel from and to</h3>
<blockquote>
<h5>Type the location names in the boxes</h5>
<br />
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.  Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p>
<br />
<h5>Select the type of locations</h5>
<br />
<p>Your choice will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.  For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it.</p>
<p>The categories are described below:</p>
<ul class="listerdisc">
<li><strong>''Address/postcode'':</strong> If you select this option, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".  If you don''t know the postcode include as much of the address as possible.<br /></li>
<li><strong>''Facility/attraction'':</strong> If you select this option, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations  For example �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�<br /></li>
<li><strong>''Station/airport'':</strong> If you select this option, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.  You may also type in the name of a town and choose to travel from any of the stations in this town, e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�<br /></li>
</ul>
<br />
<h5>Find the location on a map (optional)</h5>
<br />
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).  This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
<h5>Select the dates you would like to leave/return on</h5>
<br />
<ul class="listerdisc">
<li>Select a day from the ''drop-down'' list, then select a month/year<br />or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li>
</ul>
<br />
<h5>Choose how you want to specify the times</h5>
<br />
<ul class="listerdisc">
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location or</li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li>
</ul>
<br />
<h5>Select the times you would like to travel</h5>
<br />
<ul class="listerdisc">
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Type of journey</h5>
<br />
<p>Choose how the Journey Planner will plan your cycling route. Select:</p>
<ul class="listerdisc">
<li>�Safest� if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling. This is the default option.</li>
<li>�Quickest� if you would like a route with the shortest cycling time.</li>
<li>�Easiest to navigate� if you would like a route with the fewest number of junctions.</li>
<li>�Greenest� if you would like a route that prioritises cycling through parks and green spaces in addition to the features listed above under �Safest�.</li>
</ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Speed (maximum cycling speed)</strong><br />
	Choose the maximum speed you are willing to cycle. Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.
</li>
</ul>
<br />
<h5>Journey options</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Avoid unlit roads, walking with your bike, steep climbs</strong><br />
	If you would prefer your journey to avoid unlit roads, walking with your bike, or steep climbs, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Avoid time-based access restrictions</strong><br />
	Some roads and paths have time-based access restrictions such as �Closed on market day� or �Park closes at dusk�. If you would like the planner to plan a journey that avoids all such potential restrictions then select this option.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Travelling via a location by bicycle</strong><br />
	Choose where to travel via by typing in the location and selecting a location type. For example selecting �Address / Postcode� and adding a friends address  For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.  You may also use a map to find the location.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
'
,
'
<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote>
<h5>Teipiwch enwau''r lleoliad yn y blychau</h5>
<br />
<p>Mae''n ddoeth teipio enw llawn y lleoliad er mwyn dychwelyd y "canlyniadau tebyg" lleiaf i chi. Nid yw''n bwysig atalnodi na defnyddio priflythrennau.</p>
<p>Os ydych yn ansicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr sut i''w sillafu'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un a deipioch i mewn.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag y gwyddoch a rhoi seren * ar �l y llythrennau.</p>
<br />
<h5>Dewiswch y math o leoliad</h5>
<br />
<p>Bydd eich dewis yn rhoi gwybod i''r Cynlluniwr Siwrnai a ydych chi''n chwilio am gyfeiriad, cod post, gorsaf neu atyniad ... etc.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych chi''n chwilio am orsaf drenau, ond eich bod yn dewis y categori ''Cyfeiriad/cod post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi.</p>
<p>Caiff y categor�au eu disgrifio isod:</p>
<ul class="listerdisc">
<li><strong>''Cyfeiriad/cod post'':</strong> Os dewiswch yr opsiwn hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manceinion", "3 Burleigh Road, M32 0PF", "M32 0PF". Os nad ydych yn gwybod y cod post, dylech gynnwys cymaint o''r cyfeiriad � phosibl.<br /></li>
<li><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch yr opsiwn hwn, gallwch deipio enw atyniad neu gyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, caeau chwaraeon, theatrau, sinem�u, atyniadau i dwristiaid, amgueddfeydd, adeiladau llywodraeth a gorsafoedd heddlu. Er enghraifft "Castell Caeredin", "Gwesty Queen''s Head�, �Amgueddfa Prydain", �Clwb P�l-droed Arsenal�<br /></li>
<li><strong>''Gorsaf/maes awyr'':</strong> Os dewiswch yr opsiwn hwn, gallwch deipio enw gorsaf drenau, gorsaf fysiau, maes awyr neu derminws fferi. Gallech hefyd deipio enw tref a dewis teithio o unrhyw un o''r gorsafoedd yn y dref hon, e.e. �Kings Cross�, �Llundain�, Derby�, �Newcastle�, �Gatwick�, �Gorsaf Fysiau Victoria�<br /></li>
</ul>
<br />
<h5>Canfod y lleoliad ar fap (dewisol)</h5>
<br />
<p>Gallech glicio ar y botwm ''Canfod ar fap'' i ddod o hyd i''r lleoliad ar fap. </p>
<p>Ar �l ichi ganfod y lleoliad ar y map, byddwch chi''n gallu dewis parhau i gynllunio''r siwrnai (drwy glicio ''Nesaf'' ar y dudalen honno). Bydd hyn yn eich dychwelyd i''r dudalen gyfredol.</p>
</blockquote>
<h3>Dewis dyddiadau ac amseroedd siwrnai allan a dychwelyd</h3>
<blockquote>
<h5>Dewiswch y dyddiadau yr hoffech adael/dychwelyd</h5>
<br />
<ul class="listerdisc">
<li>Dewiswch ddiwrnod o''r rhestr "gwympo", wedyn dewis mis/blwyddyn<br />neu</li>
<li>Cliciwch y calendr a dewis dyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai un ffordd yn unig, dewiswch ''Dim dychweliad'' yn y rhestr "gwympo" mis/blwyddyn.</li>
</ul>
<br />
<h5>Dewiswch sut yr hoffech nodi''r amseroedd</h5>
<br />
<ul class="listerdisc">
<li>Gallwch ddewis yr amser yr hoffech adael y lleoliad neu''r amser yr hoffech gyrraedd yn y cyrchfan</li>
<li>Dewiswch ''Gadael am'' i ddewis yr amser cynharaf yr hoffech adael y lleoliad neu</li>
<li>Dewiswch ''Cyrraedd erbyn'' i ddewis yr amser hwyraf yr hoffech gyrraedd yn y cyrchfan</li>
</ul>
<br />
<h5>Dewiswch yr amseroedd yr hoffech deithio</h5>
<br />
<ul class="listerdisc">
<li>Dewiswch ar ba amser yr hoffech adael neu erbyn pa amser yr hoffech gyrraedd</li>
<li>Dewiswch yr oriau o''r rhestr "gwympo"</li>
<li>Dewiswch y munudau o''r rhestr "gwympo" (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Math o siwrnai</h5>
<br />
<p>Dewiswch sut bydd eich Cynlluniwr Siwrnai yn cynllunio eich llwybr beicio. Dewiswch:</p>
<ul class="listerdisc">
<li>�Mwyaf Diogel� os hoffech lwybr sy''n rhoi blaenoriaeth i ddefnyddio llwybrau beicio, lonydd beicio, strydoedd tawel a llwybrau a argymhellir ar gyfer beiciau. Dyma''r opsiwn diofyn.</li>
<li>�Cyflymaf" os hoffech lwybr �''r amser beicio byrraf. </li>
<li>�Rhwyddaf i ddod o hyd i ffordd" os hoffech lwybr �''r nifer leiaf o gyffyrdd.</li>
<li>�Gwyrddaf� os hoffech lwybr sy''n rhoi blaenoriaeth i feicio drwy barciau a mannau gwyrdd yn ogystal �''r nodweddion a restrir uchod o dan �Mwyaf Diogel�.</li>
</ul>
</blockquote>
<h3>Manwl</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Cyflymder (cyflymder beicio mwyaf) </strong><br />
Dewiswch y cyflymder mwyaf rydych yn fodlon ei feicio. Bydd amseroedd siwrnai yn seiliedig ar y cyflymder hwn, ond hefyd yn ystyried y terfynau cyflymder cyfreithlon ar y ffyrdd amrywiol yn y llwybr a gynigir. 
</li>
</ul>
<br />
<h5>Opsiynau siwrnai</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Osgoi ffyrdd heb eu goleuo, cerdded gyda''ch beic, dringo serth</strong><br />
Pe byddai''n well gennych i''ch siwrnai osgoi ffyrdd heb eu goleuo, cerdded gyda''ch beic, neu ddringo serth, ticiwch y blychau ac, os oes modd, bydd y cynlluniwr siwrnai yn eu hosgoi er mwyn peidio �''u cynnwys yn eich cynllun siwrnai. </li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Osgoi cyfyngiadau mynediad seiliedig ar amser</strong><br />
Mae gan rai ffyrdd a llwybrau gyfyngiadau mynediad seiliedig ar amser fel ''Ar gau ar ddiwrnod marchnad� neu �Parc yn cau pan fydd yn nosi�. Os hoffech i''r cynlluniwr gynllunio siwrnai sy''n osgoi pob cyfyngiad posibl felly dewiswch yr opsiwn hwn.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Teithio drwy leoliad ar feic</strong><br />
Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. Er enghraifft dewis �Cyfeiriad / Cod Post� ac ychwanegu cyfeiriad ffrind. Am fwy o fanylion ar sut i wneud hyn, gweler "Dewis lleoliadau i deithio iddynt ac ohonynt" ar ddechrau''r dudalen Cymorth. Gallech hefyd ddefnyddio map i ddod o hyd i''r lleoliad.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Ar �l ichi gwblhau''r dudalen, cliciwch "Nesaf".</h3>
'


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindACycleInput',
'
<h3>Selecting locations to travel from and to</h3>
<blockquote>
<h5>Type the location names in the boxes</h5>
<br />
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.  Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p>
<br />
<h5>Select the type of locations</h5>
<br />
<p>Your choice will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.  For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it.</p>
<p>The categories are described below:</p>
<ul class="listerdisc">
<li><strong>''Address/postcode'':</strong> If you select this option, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".  If you don''t know the postcode include as much of the address as possible.<br /></li>
<li><strong>''Facility/attraction'':</strong> If you select this option, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations  For example �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�<br /></li>
<li><strong>''Station/airport'':</strong> If you select this option, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.  You may also type in the name of a town and choose to travel from any of the stations in this town, e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�<br /></li>
</ul>
<br />
<h5>Find the location on a map (optional)</h5>
<br />
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).  This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
<h5>Select the dates you would like to leave/return on</h5>
<br />
<ul class="listerdisc">
<li>Select a day from the ''drop-down'' list, then select a month/year<br />or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li>
</ul>
<br />
<h5>Choose how you want to specify the times</h5>
<br />
<ul class="listerdisc">
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location or</li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li>
</ul>
<br />
<h5>Select the times you would like to travel</h5>
<br />
<ul class="listerdisc">
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Type of journey</h5>
<br />
<p>Choose how the Journey Planner will plan your cycling route. Select:</p>
<ul class="listerdisc">
<li>�Safest� if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling. This is the default option.</li>
<li>�Quickest� if you would like a route with the shortest cycling time.</li>
<li>�Easiest to navigate� if you would like a route with the fewest number of junctions.</li>
<li>�Greenest� if you would like a route that prioritises cycling through parks and green spaces in addition to the features listed above under �Safest�.</li>
</ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Speed (maximum cycling speed)</strong><br />
	Choose the maximum speed you are willing to cycle. Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.
</li>
</ul>
<br />
<h5>Journey options</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Avoid unlit roads, walking with your bike, steep climbs</strong><br />
	If you would prefer your journey to avoid unlit roads, walking with your bike, or steep climbs, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Avoid time-based access restrictions</strong><br />
	Some roads and paths have time-based access restrictions such as �Closed on market day� or �Park closes at dusk�. If you would like the planner to plan a journey that avoids all such potential restrictions then select this option.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Travelling via a location by bicycle</strong><br />
	Choose where to travel via by typing in the location and selecting a location type. For example selecting �Address / Postcode� and adding a friends address  For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.  You may also use a map to find the location.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
'
,
'
<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote>
<h5>Teipiwch enwau''r lleoliad yn y blychau</h5>
<br />
<p>Mae''n ddoeth teipio enw llawn y lleoliad er mwyn dychwelyd y "canlyniadau tebyg" lleiaf i chi. Nid yw''n bwysig atalnodi na defnyddio priflythrennau.</p>
<p>Os ydych yn ansicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr sut i''w sillafu'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un a deipioch i mewn.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag y gwyddoch a rhoi seren * ar �l y llythrennau.</p>
<br />
<h5>Dewiswch y math o leoliad</h5>
<br />
<p>Bydd eich dewis yn rhoi gwybod i''r Cynlluniwr Siwrnai a ydych chi''n chwilio am gyfeiriad, cod post, gorsaf neu atyniad ... etc.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych chi''n chwilio am orsaf drenau, ond eich bod yn dewis y categori ''Cyfeiriad/cod post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi.</p>
<p>Caiff y categor�au eu disgrifio isod:</p>
<ul class="listerdisc">
<li><strong>''Cyfeiriad/cod post'':</strong> Os dewiswch yr opsiwn hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manceinion", "3 Burleigh Road, M32 0PF", "M32 0PF". Os nad ydych yn gwybod y cod post, dylech gynnwys cymaint o''r cyfeiriad � phosibl.<br /></li>
<li><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch yr opsiwn hwn, gallwch deipio enw atyniad neu gyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, caeau chwaraeon, theatrau, sinem�u, atyniadau i dwristiaid, amgueddfeydd, adeiladau llywodraeth a gorsafoedd heddlu. Er enghraifft "Castell Caeredin", "Gwesty Queen''s Head�, �Amgueddfa Prydain", �Clwb P�l-droed Arsenal�<br /></li>
<li><strong>''Gorsaf/maes awyr'':</strong> Os dewiswch yr opsiwn hwn, gallwch deipio enw gorsaf drenau, gorsaf fysiau, maes awyr neu derminws fferi. Gallech hefyd deipio enw tref a dewis teithio o unrhyw un o''r gorsafoedd yn y dref hon, e.e. �Kings Cross�, �Llundain�, Derby�, �Newcastle�, �Gatwick�, �Gorsaf Fysiau Victoria�<br /></li>
</ul>
<br />
<h5>Canfod y lleoliad ar fap (dewisol)</h5>
<br />
<p>Gallech glicio ar y botwm ''Canfod ar fap'' i ddod o hyd i''r lleoliad ar fap. </p>
<p>Ar �l ichi ganfod y lleoliad ar y map, byddwch chi''n gallu dewis parhau i gynllunio''r siwrnai (drwy glicio ''Nesaf'' ar y dudalen honno). Bydd hyn yn eich dychwelyd i''r dudalen gyfredol.</p>
</blockquote>
<h3>Dewis dyddiadau ac amseroedd siwrnai allan a dychwelyd</h3>
<blockquote>
<h5>Dewiswch y dyddiadau yr hoffech adael/dychwelyd</h5>
<br />
<ul class="listerdisc">
<li>Dewiswch ddiwrnod o''r rhestr "gwympo", wedyn dewis mis/blwyddyn<br />neu</li>
<li>Cliciwch y calendr a dewis dyddiad ohono </li>
<li>Os ydych yn cynllunio siwrnai un ffordd yn unig, dewiswch ''Dim dychweliad'' yn y rhestr "gwympo" mis/blwyddyn.</li>
</ul>
<br />
<h5>Dewiswch sut yr hoffech nodi''r amseroedd</h5>
<br />
<ul class="listerdisc">
<li>Gallwch ddewis yr amser yr hoffech adael y lleoliad neu''r amser yr hoffech gyrraedd yn y cyrchfan</li>
<li>Dewiswch ''Gadael am'' i ddewis yr amser cynharaf yr hoffech adael y lleoliad neu</li>
<li>Dewiswch ''Cyrraedd erbyn'' i ddewis yr amser hwyraf yr hoffech gyrraedd yn y cyrchfan</li>
</ul>
<br />
<h5>Dewiswch yr amseroedd yr hoffech deithio</h5>
<br />
<ul class="listerdisc">
<li>Dewiswch ar ba amser yr hoffech adael neu erbyn pa amser yr hoffech gyrraedd</li>
<li>Dewiswch yr oriau o''r rhestr "gwympo"</li>
<li>Dewiswch y munudau o''r rhestr "gwympo" (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Math o siwrnai</h5>
<br />
<p>Dewiswch sut bydd eich Cynlluniwr Siwrnai yn cynllunio eich llwybr beicio. Dewiswch:</p>
<ul class="listerdisc">
<li>�Mwyaf Diogel� os hoffech lwybr sy''n rhoi blaenoriaeth i ddefnyddio llwybrau beicio, lonydd beicio, strydoedd tawel a llwybrau a argymhellir ar gyfer beiciau. Dyma''r opsiwn diofyn.</li>
<li>�Cyflymaf" os hoffech lwybr �''r amser beicio byrraf. </li>
<li>�Rhwyddaf i ddod o hyd i ffordd" os hoffech lwybr �''r nifer leiaf o gyffyrdd.</li>
<li>�Gwyrddaf� os hoffech lwybr sy''n rhoi blaenoriaeth i feicio drwy barciau a mannau gwyrdd yn ogystal �''r nodweddion a restrir uchod o dan �Mwyaf Diogel�.</li>
</ul>
</blockquote>
<h3>Manwl</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Cyflymder (cyflymder beicio mwyaf) </strong><br />
Dewiswch y cyflymder mwyaf rydych yn fodlon ei feicio. Bydd amseroedd siwrnai yn seiliedig ar y cyflymder hwn, ond hefyd yn ystyried y terfynau cyflymder cyfreithlon ar y ffyrdd amrywiol yn y llwybr a gynigir. 
</li>
</ul>
<br />
<h5>Opsiynau siwrnai</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Osgoi ffyrdd heb eu goleuo, cerdded gyda''ch beic, dringo serth</strong><br />
Pe byddai''n well gennych i''ch siwrnai osgoi ffyrdd heb eu goleuo, cerdded gyda''ch beic, neu ddringo serth, ticiwch y blychau ac, os oes modd, bydd y cynlluniwr siwrnai yn eu hosgoi er mwyn peidio �''u cynnwys yn eich cynllun siwrnai. </li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Osgoi cyfyngiadau mynediad seiliedig ar amser</strong><br />
Mae gan rai ffyrdd a llwybrau gyfyngiadau mynediad seiliedig ar amser fel ''Ar gau ar ddiwrnod marchnad� neu �Parc yn cau pan fydd yn nosi�. Os hoffech i''r cynlluniwr gynllunio siwrnai sy''n osgoi pob cyfyngiad posibl felly dewiswch yr opsiwn hwn.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Teithio drwy leoliad ar feic</strong><br />
Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. Er enghraifft dewis �Cyfeiriad / Cod Post� ac ychwanegu cyfeiriad ffrind. Am fwy o fanylion ar sut i wneud hyn, gweler "Dewis lleoliadau i deithio iddynt ac ohonynt" ar ddechrau''r dudalen Cymorth. Gallech hefyd ddefnyddio map i ddod o hyd i''r lleoliad.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Ar �l ichi gwblhau''r dudalen, cliciwch "Nesaf".</h3>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey details - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneyDetails',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>The directions for your cycle journey are shown in a list. If you prefer, you can view them on a map by clicking "Show on map". The map will appear with the directions listed below it.</p>
<br />
<p>Journey directions:</p>
<br />
<p>If the journey involves ferries, tolls, etc. you can click on the name in the instruction to be taken to a website that will give you more information about the ferry or toll etc..</p>
<p>The gradient profile graph shows a cross section of your cycle route so you are able to judge how flat or steep your route is. The X-axis shows the journey distance in miles or km, the Y-axis will show the height above sea level for your journey in metres. The highest and lowest point on the journey will also be shown along with the total climb and descent in metres. </p>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Manylion siwrnai</h5>
<br />
<p>Dangosir y cyfarwyddiadau ar gyfer eich siwrnai feicio mewn rhestr. Os yw''n well gennych, gallwch eu gweld ar fap drwy glicio "Dangos ar fap". Bydd y map yn ymddangos gyda''r cyfarwyddiadau wedi''u rhestru islaw.</p>
<br />
<p>Cyfarwyddiadau siwrnai:</p>
<br />
<p>Os yw''r siwrnai''n cynnwys fferi, tollau, etc, gallwch glicio ar yr enw yn y cyfarwyddyd er mwyn mynd i wefan a fydd yn rhoi mwy o wybodaeth i chi am y fferi neu''r doll etc..</p>
<p>Mae''r graff proffil graddiant yn dangos croestoriad o''ch llwybr beicio er mwyn ichi farnu pa mor wastad neu serth yw eich llwybr. Mae echel X yn dangos pellter y siwrnai mewn milltiroedd neu gilometrau, bydd echel Y yn dangos yr uchder uwchlaw lefel y m�r ar gyfer eich siwrnai mewn metrau. Dangosir hefyd y man uchaf ac isaf ar y siwrnai ynghyd � chyfanswm yr esgyn a''r disgyn mewn metrau. </p>
<br />
<p>I weld gwybodaeth am siwrnai:</p>
<ol>
<li> Cliciwch y botymau uwchlaw''r siwrneiau i weld crynodeb byr o''ch opsiynau siwrnai ("Crynodeb"), mapiau manwl o''ch siwrnai ("Mapiau"), y CO2 y bydd eich siwrnai yn eich gynhyrchu � a''r gallu i gymharu hyn � dulliau eraill o gludiant (''Cyfrifo CO2'') ar gyfer y siwrnai a ddewiswyd </li>
</ol>
<p>I argraffu unrhyw un o''r tudalennau, cliciwch ''Addas i''w hargraffu''. Bydd hyn yn agor tudalen addas i''w hargraffu y gallwch ei hargraffu fel arfer.</p>
<br />
<h5>Newid dyddiad ac amser</h5>
<br />
<p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri cwympo</li>
<li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
</ol>
<p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar frig y dudalen</p>
<br />
<h5>Cadw fel hoff siwrnai</h5>
<br />
<p>I gadw''r siwrnai:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi</li>
<li>Nodwch enw ystyrlon ar gyfer y siwrnai (e.e. �Siwrnai i''r gwaith�) </li>
<li>Cliciwch ''OK''</li>
</ol>
<p>Gallwch gadw hyd at bum siwrnai a gallwch drosysgrifo siwrneiau presennol.</p>
<br />
<h5>Anfon at ffrind</h5>
<br />
<p>I anfon y dudalen hon at ffrind:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi i Transport Direct.</li>
<li>Os nad ydych wedi mewngofnodi, bydd angen ichi nodi eich enw defnyddiwr a''ch cyfrinair.</li>
<li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen ato yn y blwch</li>
<li>Cliciwch ''Anfon''</li>
</ol>
<p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost hwnnw. Bydd mapiau (os yw''n berthnasol) yn cael eu hatodi fel ffeil ddelwedd (mae e-bost tua 150k ar gyfartaledd). Dangosir eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>
'


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey details - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneyDetails',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>The directions for your cycle journey are shown in a list. If you prefer, you can view them on a map by clicking "Show on map". The map will appear with the directions listed below it.</p>
<br />
<p>Journey directions:</p>
<br />
<p>If the journey involves ferries, tolls, etc. you can click on the name in the instruction to be taken to a website that will give you more information about the ferry or toll etc..</p>
<p>The gradient profile graph shows a cross section of your cycle route so you are able to judge how flat or steep your route is. The X-axis shows the journey distance in miles or km, the Y-axis will show the height above sea level for your journey in metres. The highest and lowest point on the journey will also be shown along with the total climb and descent in metres. </p>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Manylion siwrnai</h5>
<br />
<p>Dangosir y cyfarwyddiadau ar gyfer eich siwrnai feicio mewn rhestr. Os yw''n well gennych, gallwch eu gweld ar fap drwy glicio "Dangos ar fap". Bydd y map yn ymddangos gyda''r cyfarwyddiadau wedi''u rhestru islaw.</p>
<br />
<p>Cyfarwyddiadau siwrnai:</p>
<br />
<p>Os yw''r siwrnai''n cynnwys fferi, tollau, etc, gallwch glicio ar yr enw yn y cyfarwyddyd er mwyn mynd i wefan a fydd yn rhoi mwy o wybodaeth i chi am y fferi neu''r doll etc..</p>
<p>Mae''r graff proffil graddiant yn dangos croestoriad o''ch llwybr beicio er mwyn ichi farnu pa mor wastad neu serth yw eich llwybr. Mae echel X yn dangos pellter y siwrnai mewn milltiroedd neu gilometrau, bydd echel Y yn dangos yr uchder uwchlaw lefel y m�r ar gyfer eich siwrnai mewn metrau. Dangosir hefyd y man uchaf ac isaf ar y siwrnai ynghyd � chyfanswm yr esgyn a''r disgyn mewn metrau. </p>
<br />
<p>I weld gwybodaeth am siwrnai:</p>
<ol>
<li> Cliciwch y botymau uwchlaw''r siwrneiau i weld crynodeb byr o''ch opsiynau siwrnai ("Crynodeb"), mapiau manwl o''ch siwrnai ("Mapiau"), y CO2 y bydd eich siwrnai yn eich gynhyrchu � a''r gallu i gymharu hyn � dulliau eraill o gludiant (''Cyfrifo CO2'') ar gyfer y siwrnai a ddewiswyd </li>
</ol>
<p>I argraffu unrhyw un o''r tudalennau, cliciwch ''Addas i''w hargraffu''. Bydd hyn yn agor tudalen addas i''w hargraffu y gallwch ei hargraffu fel arfer.</p>
<br />
<h5>Newid dyddiad ac amser</h5>
<br />
<p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri cwympo</li>
<li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
</ol>
<p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar frig y dudalen</p>
<br />
<h5>Cadw fel hoff siwrnai</h5>
<br />
<p>I gadw''r siwrnai:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi</li>
<li>Nodwch enw ystyrlon ar gyfer y siwrnai (e.e. �Siwrnai i''r gwaith�) </li>
<li>Cliciwch ''OK''</li>
</ol>
<p>Gallwch gadw hyd at bum siwrnai a gallwch drosysgrifo siwrneiau presennol.</p>
<br />
<h5>Anfon at ffrind</h5>
<br />
<p>I anfon y dudalen hon at ffrind:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi i Transport Direct.</li>
<li>Os nad ydych wedi mewngofnodi, bydd angen ichi nodi eich enw defnyddiwr a''ch cyfrinair.</li>
<li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen ato yn y blwch</li>
<li>Cliciwch ''Anfon''</li>
</ol>
<p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost hwnnw. Bydd mapiau (os yw''n berthnasol) yn cael eu hatodi fel ffeil ddelwedd (mae e-bost tua 150k ar gyfartaledd). Dangosir eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey summary - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneySummary',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Manylion siwrnai</h5>
<br />
<p>I weld gwybodaeth am siwrnai:</p>
<ol>
<li> Cliciwch y botymau uwchlaw''r siwrneiau i weld crynodeb byr o''ch opsiynau siwrnai (''Crynodeb''), mapiau manwl o''ch siwrnai (''Mapiau''), y CO2 y bydd eich siwrnai yn ei gynhyrchu � a''r gallu i gymharu hyn � dulliau eraill o gludiant (''Cyfrif CO2'') ar gyfer y siwrnai a ddewiswyd </li>
</ol>
<p>I argraffu unrhyw un o''r tudalennau, cliciwch ''Addas i''w hargraffu''. Bydd hyn yn agor tudalen addas i''w hargraffu y gallwch ei hargraffu fel arfer.</p>
<br />
<h5>Newid dyddiad ac amser</h5>
<br />
<p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri cwympo</li>
<li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
</ol>
<p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar frig y dudalen</p>
<br />
<h5>Cadw fel hoff siwrnai</h5>
<br />
<p>I gadw''r siwrnai:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi</li>
<li>Nodwch enw ystyrlon i''r siwrnai (e.e. "Siwrnai i''r gwaith�) </li>
<li>Cliciwch ''OK''</li>
</ol>
<p>Gallwch gadw hyd at bum siwrnai a gallwch drosysgrifo siwrneiau presennol.</p>
<br />
<h5>Anfon at ffrind</h5>
<br />
<p>I anfon y dudalen hon at ffrind:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi i Transport Direct.</li>
<li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich enw defnyddiwr a''ch cyfrinair.</li>
<li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen ato yn y blwch</li>
<li>Cliciwch ''Anfon''</li>
</ol>
<p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost hwnnw. Bydd mapiau (os ydynt yn berthnasol) yn cael eu hatodi fel ffeil ddelwedd (mae e-byst tua 150k ar gyfartaledd). Dangosir eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey summary - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneySummary',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Manylion siwrnai</h5>
<br />
<p>I weld gwybodaeth am siwrnai:</p>
<ol>
<li> Cliciwch y botymau uwchlaw''r siwrneiau i weld crynodeb byr o''ch opsiynau siwrnai (''Crynodeb''), mapiau manwl o''ch siwrnai (''Mapiau''), y CO2 y bydd eich siwrnai yn ei gynhyrchu � a''r gallu i gymharu hyn � dulliau eraill o gludiant (''Cyfrif CO2'') ar gyfer y siwrnai a ddewiswyd </li>
</ol>
<p>I argraffu unrhyw un o''r tudalennau, cliciwch ''Addas i''w hargraffu''. Bydd hyn yn agor tudalen addas i''w hargraffu y gallwch ei hargraffu fel arfer.</p>
<br />
<h5>Newid dyddiad ac amser</h5>
<br />
<p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri cwympo</li>
<li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
</ol>
<p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar frig y dudalen</p>
<br />
<h5>Cadw fel hoff siwrnai</h5>
<br />
<p>I gadw''r siwrnai:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi</li>
<li>Nodwch enw ystyrlon i''r siwrnai (e.e. "Siwrnai i''r gwaith�) </li>
<li>Cliciwch ''OK''</li>
</ol>
<p>Gallwch gadw hyd at bum siwrnai a gallwch drosysgrifo siwrneiau presennol.</p>
<br />
<h5>Anfon at ffrind</h5>
<br />
<p>I anfon y dudalen hon at ffrind:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi i Transport Direct.</li>
<li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich enw defnyddiwr a''ch cyfrinair.</li>
<li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen ato yn y blwch</li>
<li>Cliciwch ''Anfon''</li>
</ol>
<p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost hwnnw. Bydd mapiau (os ydynt yn berthnasol) yn cael eu hatodi fel ffeil ddelwedd (mae e-byst tua 150k ar gyfartaledd). Dangosir eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey map - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneyMap',
'
<blockquote>
<h5>Journey maps</h5>
<br />
<p>You can view specific stages of the journey in more detail:</p>
<ol>
<li>Select the journey stage from the drop-down list</li>
<li>Click ''Show route''</li>
</ol>
<p>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.</p>
<br />
<p>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow). They include transport symbols (shown automatically) and a range of attraction and facility symbols.</p>
<p>To show or hide any of these symbols, you must:</p>
<ol>
<li>Click on a category radio button e.g. ''Accommodation''</li>
<li>Tick or untick the boxes next to the symbols</li>
<li>Click ''Show selected symbols''</li>
</ol>
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Mapiau siwrnai</h5>
<br />
<p>Gallwch weld cyfnodau penodol o''r siwrnai yn fanylach:</p>
<ol>
<li>Dewiswch y cyfnod o''r siwrnai o''r rhestr gwympo</li>
<li>Cliciwch ''Dangos llwybr''</li>
</ol>
<p>Cliciwch ''Addas i''w hargraffu'' i agor tudalen addas i''w hargraffu y gallwch ei hargraffu fel arfer.</p>
<br />
<p>Gallwch weld symbolau ar y map pan gaiff ei chwyddo''n fawr (yn y pum lefel chwyddo brig, wedi''u hamlinellu''n felyn). Maent yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac ystod o symbolau atyniad a chyfleuster.</p>
<p>I ddangos neu guddio unrhyw un o''r symbolau hyn, mae''n rhaid i chi:</p>
<ol>
<li>Glicio ar fotwm radio categori e.e. ''Llety''</li>
<li>Ticio neu ddileu tic yn y blychau wrth ymyl y symbolau</li>
<li>Clicio ''Dangos symbolau a ddewiswyd''</li>
</ol>
<h5>Newid dyddiad ac amser</h5>
<br />
<p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri cwympo</li>
<li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
</ol>
<p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar frig y dudalen</p>
<br />
<h5>Cadw fel hoff siwrnai</h5>
<br />
<p>I gadw''r siwrnai:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi</li>
<li>Nodwch enw ystyrlon ar gyfer y siwrnai (e.e. �Siwrnai i''r gwaith�) </li>
<li>Cliciwch ''OK''</li>
</ol>
<p>Gallwch gadw hyd at bum siwrnai a gallwch drosysgrifo siwrneiau presennol.</p>
<br />
<h5>Anfon at ffrind</h5>
<br />
<p>I anfon y dudalen hon at ffrind:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi i Transport Direct.</li>
<li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich enw defnyddiwr a''ch cyfrinair.</li>
<li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen hon ato yn y blwch</li>
<li>Cliciwch ''Anfon''</li>
</ol>
<p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost hwnnw. Bydd mapiau (os yw''n berthnasol) yn cael eu hatodi fel ffeil ddelwedd (mae e-bost tua 150k ar gyfartaledd). Dangosir eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey map - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneyMap',
'
<blockquote>
<h5>Journey maps</h5>
<br />
<p>You can view specific stages of the journey in more detail:</p>
<ol>
<li>Select the journey stage from the drop-down list</li>
<li>Click ''Show route''</li>
</ol>
<p>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.</p>
<br />
<p>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow). They include transport symbols (shown automatically) and a range of attraction and facility symbols.</p>
<p>To show or hide any of these symbols, you must:</p>
<ol>
<li>Click on a category radio button e.g. ''Accommodation''</li>
<li>Tick or untick the boxes next to the symbols</li>
<li>Click ''Show selected symbols''</li>
</ol>
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Mapiau siwrnai</h5>
<br />
<p>Gallwch weld cyfnodau penodol o''r siwrnai yn fanylach:</p>
<ol>
<li>Dewiswch y cyfnod o''r siwrnai o''r rhestr gwympo</li>
<li>Cliciwch ''Dangos llwybr''</li>
</ol>
<p>Cliciwch ''Addas i''w hargraffu'' i agor tudalen addas i''w hargraffu y gallwch ei hargraffu fel arfer.</p>
<br />
<p>Gallwch weld symbolau ar y map pan gaiff ei chwyddo''n fawr (yn y pum lefel chwyddo brig, wedi''u hamlinellu''n felyn). Maent yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac ystod o symbolau atyniad a chyfleuster.</p>
<p>I ddangos neu guddio unrhyw un o''r symbolau hyn, mae''n rhaid i chi:</p>
<ol>
<li>Glicio ar fotwm radio categori e.e. ''Llety''</li>
<li>Ticio neu ddileu tic yn y blychau wrth ymyl y symbolau</li>
<li>Clicio ''Dangos symbolau a ddewiswyd''</li>
</ol>
<h5>Newid dyddiad ac amser</h5>
<br />
<p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri cwympo</li>
<li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
</ol>
<p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar frig y dudalen</p>
<br />
<h5>Cadw fel hoff siwrnai</h5>
<br />
<p>I gadw''r siwrnai:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi</li>
<li>Nodwch enw ystyrlon ar gyfer y siwrnai (e.e. �Siwrnai i''r gwaith�) </li>
<li>Cliciwch ''OK''</li>
</ol>
<p>Gallwch gadw hyd at bum siwrnai a gallwch drosysgrifo siwrneiau presennol.</p>
<br />
<h5>Anfon at ffrind</h5>
<br />
<p>I anfon y dudalen hon at ffrind:</p>
<ol>
<li>Sicrhewch eich bod wedi mewngofnodi i Transport Direct.</li>
<li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich enw defnyddiwr a''ch cyfrinair.</li>
<li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen hon ato yn y blwch</li>
<li>Cliciwch ''Anfon''</li>
</ol>
<p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost hwnnw. Bydd mapiau (os yw''n berthnasol) yn cael eu hatodi fel ffeil ddelwedd (mae e-bost tua 150k ar gyfartaledd). Dangosir eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>
'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------------------------------------
-- Add Cycle journey details - Cycling Instructions text
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int
SET @GroupId = 1

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.RouteJoins',
'Route joins {0}', 'Llwybr yn ymuno {0}'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.RouteLeavesCycleInfrastructure',
'Route leaves cycle specific infrastructure',  'Llwybr yn gadael seilwaith penodol i feiciau'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.RouteUses',
'Route uses',  'Mae''r llwybr yn defnyddio'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.PleaseNote',
'Please note the route goes',  'Sylwch fod y llwybr yn mynd'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.PleaseCross',
'Please cross at',  'Croeswch yn'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.TheStreetIs',
'The {0}', 'Mae''r {0}'

EXEC AddtblContent 1, @GroupId, 'langStrings', 'CycleRouteText.And', 
'and', 'a'

EXEC AddtblContent 1, @GroupId, 'langStrings', 'CycleRouteText.TimeBasedAccessRestriction', 
'Time based access restriction: ', 'cy Time based access restriction: '

EXEC AddtblContent 1, @GroupId, 'langStrings', 'CycleRouteText.ForThisManoeuvre', 
'For this manoeuvre we recommend that you',  'Ar gyfer y symudiad hwn, rydym yn argymell eich bod yn'

EXEC AddtblContent 1, @GroupId, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.ManoeuvreImage', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif'

EXEC AddtblContent 1, @GroupId, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.ManoeuvreImage.AltText', 
'Take care complex manoeuvre', 
'cy Take care complex manoeuvre'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftOne2',
'Take first available left ', 'Cymerwch y troad cyntaf i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftTwo2',
'Take second available left ', 'Cymerwch yr ail droad i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftThree2',
'Take third available left ', 'Cymerwch y trydydd troad i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftFour2',
'Take fourth available left ', 'Cymerwch y pedwerydd troad i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightOne2',
'Take first available right ', 'Cymerwch y troad cyntaf sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightTwo2',
'Take second available right ', 'Cymerwch yr ail droad sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightThree2',
'Take third available right ', 'Cymerwch y trydydd troad sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightFour2',
'Take fourth available right ', 'Cymerwch y pedwerydd troad sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.AtMiniRoundabout2',
'at mini-roundabout ', 'wrth y gylchfan fach '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.LocalPath',
'unnamed path ',  'llwybr heb ei enwi'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.Street',
'street ',  'stryd '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.Path',
'path ',  'llwybr'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.ChargeAdultAndCycle',
'Charge for adult and cycle:', 'cy Charge for adult and cycle:'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.UTurn',
'Make a U-Turn on', 'cy Make a U-Turn on'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------
-- Add Cycle journey details - Cycle Attributes list
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int
SET @GroupId = 1

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NoCycleAttributes',         'NoCycleAttributes', 'NoCycleAttributes'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Motorway',                  'motorway',  'traffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ARoad',                     'A road',  'ffordd A'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BRoad',                     'B road',  'ffordd B'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MinorRoad',                 'minor road',  'is-ffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LocalStreet',               'local street',  'stryd lleol'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Alley',                     'alley',  'ale'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PrivateRoad',               'private road', 'ffordd breifat' 
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PedestrianisedStreet',      'a pedestrianised street',  'stryd wedi''i bedestreiddio'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TollRoad',                  'toll road',  'tollffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SingleCarriageway',         'single carriageway',  'ffordd unffrwd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.DualCarriageway',           'dual carriageway',  'ffordd ddeuol'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SlipRoad',                  'slip road',  'ffordd ymuno ac ymadael'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Roundabout',                'roundabout',  'cylchfan'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.EnclosedTrafficAreaLink',   'EnclosedTrafficAreaLink', 'EnclosedTrafficAreaLink'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrafficIslandLinkAtJunction', 'TrafficIslandLinkAtJunction', 'TrafficIslandLinkAtJunction'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrafficIslandLink',         'TrafficIslandLink', 'TrafficIslandLink'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Ferry',                     'ferry',  'fferi'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LimitedAccess',             'limited access', 'mynediad cyfyngedig' 
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ProhibitedAccess',          'prohibited access',  'mynediad gwaharddedig'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Footpath',                  'footpath',  'llwybr troed'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Cyclepath',                 'cyclepath',  'llwybr beicio'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Bridlepath',                'bridlepath',  'llwybr ceffylau'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CandriveAtoB',              'CandriveAtoB', 'CandriveAtoB'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CandriveBtoA',              'CandriveBtoA', 'CandriveBtoA'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CanenteratAi.e.noentryatB', 'CanenteratAi.e.noentryatB', 'CanenteratAi.e.noentryatB'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CanenteratBi.e.noentryatA', 'CanenteratBi.e.noentryatA', 'CanenteratBi.e.noentryatA'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Superlink',                 'Superlink', 'Superlink'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrunkRoad',                 'trunk road',  'cefnffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TurnSuperlink',             'TurnSuperlink', 'TurnSuperlink'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ConnectingLink',            'ConnectingLink', 'ConnectingLink'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Towpath',                   'towpath', ' llwybr tynnu'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient2-AtoBuphill',      'Gradient2-AtoBuphill', 'Gradient2-AtoBuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient2-BtoAuphill',      'Gradient2-BtoAuphill', 'Gradient2-BtoAuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient3-AtoBuphill',      'Gradient3-AtoBuphill', 'Gradient3-AtoBuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient3-BtoAuphill',      'Gradient3-BtoAuphill', 'Gradient3-BtoAuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient4-AtoBuphill',      'Gradient4-AtoBuphill', 'Gradient4-AtoBuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient4-BtoAuphill',      'Gradient4-BtoAuphill', 'Gradient4-BtoAuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient5-AtoBuphill',      'Gradient5-AtoBuphill', 'Gradient5-AtoBuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient5-BtoAuphill',      'Gradient5-BtoAuphill', 'Gradient5-BtoAuphill'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Ford',                      'through a ford', 'trwy ryd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gate',                      'through a gate',  'trwy glwyd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LevelCrossing',             'across a level crossing',  'dros groesfan wastad'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Bridge',                    'over a bridge',  'dros bont'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Tunnel',                    'through a tunnel',  'trwy dwnnel'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CalmingUnavoidablebyBike',  'CalmingUnavoidablebyBike', 'CalmingUnavoidablebyBike'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Footbridge',                'over a footbridge',  'dros bont droed'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',             		'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SharedUseFootpath',         'a shared use footpath',  'llwybr troed defnydd a rennir'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FootpathOnly',              'a footpath - please walk your bike',  'llwybr troed - cerddwch eich beic os gwelwch yn dda'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CyclesOnly',                'a cycle only path',  'llwybr i feiciau yn unig'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PrivateAccess',             'is private access',  'yn mynediad preifat'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Parkland',                  'through a park',  'trwy barc'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'unused', 'unused'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Subway',                    'through a subway',  'trwy danlwybr'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RaisableBarrier',           'past a raisable barrier',  'heibio rhwystr y gellir ei godi'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.HoopLiftBarrier',           'over a hoop barrier',  'dros rwystr cylch'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CattleGrid',                'across a cattle grid',  'dros grid gwartheg'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Stile',                     'over a stile',  'dros gamfa'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.HoopThroughBarrier',        'over a hoop barrier',  'dros rwystr cylch'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Humps',                     'over traffic calming humps',  'dros grybiau lleddfu traffig'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Cushions',                  'over traffic calming cushions',  'dros glustogau lleddfu traffig'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Chicane',                   'through a chicane',  'drwy chicane'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PinchPoint',                'through a pinch point', 'drwy wasgle'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Pelican',                   'pelican crossing', 'croesfan pelican'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Toucan',                    'toucan crossing', 'croesfan twcan'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Zebra',                     'zebra crossing', 'croesfan sebra'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WalkaboutManoeuvre',        'At this point you may need to walk your bike', 'cy At this point you may need to walk your bike'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.AdvancedManoeuvre',         'Extra care should be taken with the road junctions at this point', 'cy Extra care should be taken with the road junctions at this point'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ProhibitedManoeuvre',       'ProhibitedManoeuvre', 'ProhibitedManoeuvre'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CycleLaneAtoB',             'an on road cycle lane', 'l�n feicio ar y ffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CycleLaneBtoA',             'an on road cycle lane', 'l�n feicio ar y ffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BusLaneAtoB',               'a shared use bus lane', 'l�n fysiau defnydd a rennir'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BusLaneBtoA',               'a shared use bus lane', 'l�n fysiau defnydd a rennir'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NarrowAtoB',                'a narrow on road cycle lane', 'l�n feicio gul ar y ffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NarrowBtoA',                'a narrow on road cycle lane', 'l�n feicio gul ar y ffordd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.DedicatedAtoB',             'a dedicated cycle track', 'llwybr beicio pwrpasol'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.DedicatedBtoA',             'a dedicated cycle track', 'llwybr beicio pwrpasol'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.UnpavedAtoB',               'is unpaved',  'heb eu palmantu'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.UnpavedBtoA',               'is unpaved',  'heb eu palmantu'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WhenDryAtoB',               'may be wet in winter', 'Mae posibilrwydd bydd y ... yn gwlyb yn y gaeaf'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WhenDryBtoA',               'may be wet in winter', 'Mae posibilrwydd bydd y ... yn gwlyb yn y gaeaf'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FirmAtoB',                  'is firm', 'is firm'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FirmBtoA',                  'is firm', 'is firm'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PavedAtoB',                 'is paved', 'wedi''u palmantu'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PavedBtoA',                 'is paved', 'wedi''u palmantu'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LooseAtoB',                 'has a loose surface', 'mae gan y �.yma arwyneb rhydd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LooseBtoA',                 'has a loose surface', 'mae gan y �.yma arwyneb rhydd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CobblesAtoB',               'is cobbled', 'wedi''u coblo'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CobblesBtoA',               'is cobbled', 'wedi''u coblo'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MixedAtoB',                 'MixedAtoB', 'MixedAtoB'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MixedBtoA',                 'MixedBtoA', 'MixedBtoA'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RoughAtoB',                 'has a rough surface',  'mae gan y � yma arwyneb garw'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RoughBtoA',                 'has a rough surface',  'mae gan y � yma arwyneb garw'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BlocksAtoB',                'BlocksAtoB', 'BlocksAtoB'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BlocksBtoA',                'BlocksBtoA', 'BlocksBtoA'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.IndividualRecommendation',  'IndividualRecommendation', 'IndividualRecommendation'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LARecommended',             'LARecommended', 'LARecommended'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RecommendedForSchools',     'RecommendedForSchools', 'RecommendedForSchools'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.OtherRecommendation',       'OtherRecommendation', 'OtherRecommendation'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WellLit',                   'is well lit',  'wedi''u goleuo''n dda'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LightingPresent',           'has street lighting',  'mae gan y � yma golau stryd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PartialLighting',           'is partially lit',  'wedi''u goleuo''n rhannol'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Nolighting',                'has no lighting',  'does dim golau gan y � yma'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Busy',                      'is generally busy',  'is generally busy'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Very',                      'is very',  'yn �iawn'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Quiet',                     'is generally quiet', 'is genarally quiet'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrafficFree',               'is traffic free', 'yn rhydd o draffig'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SeldomPolicedUrbanArea',    'SeldomPolicedUrbanArea', 'SeldomPolicedUrbanArea'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.IsolatedArea',              'is in an isolated area', 'mewn ardal arunig'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NeighbourhoodWatch',        'has a neighbourhood watch scheme',  'mae cynllun gwarchod cymdogaeth yn y � yma'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Cctv MonitoredArea',        'is a monitored area',  'mae''r � yma''n ardal wedi''u monitro'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NormallySafeInDaylight',    'normally safe in daylight', 'fel arfer yn ddiogel mewn golau dydd'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NormallySafeAtNight',       'normally safe at night', 'fel arfer yn ddiogel gyda''r nos'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.IncidentsHaveOccuredInArea', 'incidents have occured in area', 'cafwyd digwyddiadau yn yr ardal'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FrequentlyPolicedUrbanArea', 'frequently policed urban area', 'ardal drefol sy''n cael ei phlismona''n aml' 
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Steps',                     'steps - cycle should be carried', 'grisiau - dylid cario''r beic'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Channelalongsidesteps',     'steps with a channel', 'grisiau � sianel'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'Test'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TurnRestriction',           'TurnRestriction', 'TurnRestriction'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MiniRoundabout',            'mini roundabout', 'cylchfan bach'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1195
SET @ScriptDesc = 'Cycle planner content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO