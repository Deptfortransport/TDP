-- ***********************************************
-- NAME 		: DUP1295_Updated_Car_Parking_Data_Importer.sql
-- DESCRIPTION 		: Updated stored proc to introduce versioning to carparks database
-- AUTHOR		: Amit Patel
-- ************************************************

-- *****
-- ***** EXECUTE permissions below MUST be checked for each environment prior to implementation
-- *****

USE CarParks
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ImportCarParkingData]')  AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[ImportCarParkingData]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- Create new stored procedure
CREATE PROCEDURE dbo.ImportCarParkingData (@XML text, @LastFeed bit, @FirstFeed bit) AS

	SET NOCOUNT ON
	SET XACT_ABORT ON

	-- Start Transaction

	DECLARE @DocID int
	DECLARE @XMLPathData varchar(50)
	DECLARE @Version int
	DECLARE @CurrentVersion int
	DECLARE @MaxVersion int		
	DECLARE @VersionToDelete int
	DECLARE @VersionToDeleteFromlast int

	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/'

	SELECT @CurrentVersion = ISNULL(MAX(Id),0) FROM DataVersion WHERE Active = 1

	SELECT @Version = @CurrentVersion + 1

	SELECT @MaxVersion = ISNULL(MAX(Id),0) FROM DataVersion

	SELECT @VersionToDeleteFromlast = ISNULL(Cast(pValue as int),3) FROM [PermanentPortal].[dbo].[properties]
			WHERE pName = 'datagateway.sqlimport.carparking.versiontodeletefromlast'

	-- deleting unsuccessful data load versions since the last successful version
	IF(@FirstFeed = 1)
	BEGIN
		IF (@MaxVersion <> @CurrentVersion)
		BEGIN
			SET @CurrentVersion = @CurrentVersion + 1
	
			WHILE(@CurrentVersion <= @MaxVersion)
			BEGIN
				EXEC DeleteCarParkingData @CurrentVersion
				SET @CurrentVersion = @CurrentVersion + 1
			END
		END
	END

	IF NOT EXISTS(SELECT [Id] FROM DataVersion WHERE [Id] = @Version)
		INSERT INTO DataVersion([Id],Active) VALUES (@Version,0)
	
	
	
		----------------------------------------------------
		-- Reference Data Tables
		----------------------------------------------------

BEGIN TRANSACTION T2
		-- Car Park Access Points
		INSERT INTO CarParkingAccessPoints (GeocodeType, Easting, Northing, StreetName,  BarrierInOperation, VersionId)
		SELECT DISTINCT X.GeocodeType, X.Easting, X.Northing, X.StreetName, X.BarrierInOperation, @Version
		FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/AccessPoints', 2)
		WITH
		(
			GeocodeType varchar(10),
			Easting varchar(7),
			Northing varchar(7),
			StreetName varchar(100),
			BarrierInOperation varchar(3)
		) X 
		 	


		-- Car Park Operator
		INSERT INTO CarParkingOperator (OperatorCode, OperatorName, OperatorURL,  OperatorTsAndCs, OperatorEmail, VersionId)
		SELECT DISTINCT X.OperatorCode, X.OperatorName, X.OperatorURL, X.OperatorTsAndCs, X.OperatorEmail, @Version
		FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/CarParkOperator', 2)
		WITH
		(
			OperatorCode varchar(50),
			OperatorName varchar(100),
			OperatorURL varchar(2048),
			OperatorTsAndCs varchar(2048),
			OperatorEmail varchar(100)
		) X WHERE NOT EXISTS 
			(SELECT * FROM CarParkingOperator
				WHERE CarParkingOperator.OperatorCode = X.OperatorCode AND CarParkingOperator.VersionId = @Version)
				


		-- Traffic News Region
		INSERT INTO CarParkingTrafficNewsRegion (RegionName, VersionId)
		SELECT DISTINCT X.RegionName, @Version FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/TrafficNewsRegion', 2)
		WITH
		(
			RegionName varchar (100)
		) X


		-- Car Park Calendar Elements
		INSERT INTO CarParkingCalendar (
			Start,
			[End],
			Days,
			PublicHols,
			VersionId)
		SELECT  X.CalendarStartDate,
			X.CalendarEndDate,
			X.Days,
			X.PublicHolidays,
			@Version
		FROM	
		OPENXML (@docId, '//Calendar', 2)
		WITH (	
			CalendarStartDate datetime,
			CalendarEndDate datetime,
			Days varchar(7),
			PublicHolidays varchar(8)
			) X

		
		-- Park and Ride Scheme
		INSERT INTO CarParkingParkAndRideScheme (Location, SchemeUrl, Comments,  LocationEasting, LocationNorthing, TransferFrequency, TransferFrom, TransferTo, VersionId)
		SELECT DISTINCT X.Location, X.SchemeURL, X.Comments, X.LocationEasting, X.LocationNorthing,
				X.TransferFrequency, X.TransferFrom, X.TransferTo, @Version
		FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/ParkAndRideScheme' ,2)
		WITH
		(
			Location varchar(100),
			SchemeURL varchar(2048),
			Comments varchar(200),
			LocationEasting varchar(7),
			LocationNorthing varchar(7),
			TransferFrequency varchar(100),			TransferFrom  varchar(250),
			TransferTo varchar(250)
		) X

		-- NPTG Admin District
		INSERT INTO CarParkingNPTGAdminDistrict (AdminAreaCode, DistrictCode, VersionId)
		SELECT DISTINCT X.AdminAreaCode, X.DistrictCode, @Version FROM OPENXML (@DocId,  '/CarParkDataImport/CarPark/NPTGAdminDistrict' ,2)
		WITH
		(
			AdminAreaCode varchar(50),
			DistrictCode varchar(50)
		) X

COMMIT TRANSACTION T2


BEGIN TRANSACTION T3
		-- Car Parking Table
		INSERT INTO CarParking (
			Reference,
			OperatorId,
			AccessPointsMapId,
			AccessPointsEntranceId,
			AccessPointsExitId,			
			TrafficNewsRegionId,
			ParkAndRideSchemeId,
			NPTGAdminDistrictId,
			Name,
			Location,
			Address,
			Postcode,
			Notes,
			Telephone,
			Url,
			MinCost,
			ParkAndRide,
			StayType,
			PlanningPoint,
			DateRecordLastUpdated,
			WEUDate,
			WEFDate,
			VersionId)
		SELECT  X.CarParkRef,
			x.operatorcode,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing =  x.mapaccesspointnorthing AND easting = x.mapaccesspointeasting and geocodetype = 'Map' and VersionId = @Version) AS  AccessPointsMapId,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing =  x.entranceaccesspointnorthing AND easting = x.entranceaccesspointeasting and geocodetype =  'Entrance' and VersionId = @Version) AS AccessPointsEntranceId,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing =  x.exitaccesspointnorthing AND easting = x.exitaccesspointeasting and geocodetype = 'Exit' and VersionId = @Version) AS  AccessPointsExitId,
			(SELECT top 1 Id FROM CarParkingTrafficNewsRegion WHERE regionname =  x.trafficnewsregionname and VersionId = @Version) AS RegionId,
			(SELECT top 1 Id FROM CarParkingParkAndRideScheme WHERE location =  x.ParkAndRideLocation and VersionId = @Version) AS ParkAndRideId,
			(SELECT top 1 Id FROM CarParkingNPTGAdminDistrict WHERE adminareacode =  x.nptgareacode and VersionId = @Version) as NPTGAdminDistrictId,
			X.CarParkName,
			X.Location,
			X.Address,
			X.PostCode,
			X.Notes,
			X.Telephone,
			X.Url,
			X.MinCostPence,
			CASE X.IsParkAndRide
			  WHEN 'true' THEN 1
			  ELSE 0
			END,
			X.StayType,
			CASE X.PlanningPoint
			  WHEN 'true' THEN 1
			  ELSE 0
			END,
			X.DateRecordLastUpdated,
			X.WEUDate,
			X.WEFDate,
			@Version	
		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark', 2)
		WITH (	
			CarParkRef varchar(50),
			CarParkName varchar(50),
			Location varchar(50),
			Address varchar(100),
			Postcode varchar(8),
			Notes varchar(250), 
			Telephone varchar(11),
			URL varchar(2048),	
			MinCostPence int,
			IsParkAndRide varchar(5),
			StayType varchar(20),
			PlanningPoint varchar(5),
			DateRecordLastUpdated datetime,
			WEUDate datetime,
			WEFDate datetime,
			OperatorCode varchar(100) 'CarParkOperator/OperatorCode',
			EntranceGeoCodeType varchar(10)  'AccessPoints[GeocodeType="Entrance"]/GeocodeType', 
			EntranceAccessPointNorthing varchar(7)  'AccessPoints[GeocodeType="Entrance"]/Northing', 
			EntranceAccessPointEasting varchar(7)  'AccessPoints[GeocodeType="Entrance"]/Easting', 
			MapGeoCodeType varchar(10)  'AccessPoints[GeocodeType="Map"]/GeocodeType', 
			MapAccessPointNorthing varchar(7)  'AccessPoints[GeocodeType="Map"]/Northing', 
			MapAccessPointEasting varchar(7)  'AccessPoints[GeocodeType="Map"]/Easting', 
			ExitGeoCodeType varchar(10)  'AccessPoints[GeocodeType="Exit"]/GeocodeType', 
			ExitAccessPointNorthing varchar(7)  'AccessPoints[GeocodeType="Exit"]/Northing', 
			ExitAccessPointEasting varchar(7)  'AccessPoints[GeocodeType="Exit"]/Easting', 
			TrafficNewsRegionName varchar(100) 'TrafficNewsRegion/RegionName',
			ParkAndRideLocation varchar(100) 'ParkAndRideScheme/Location',
			NPTGAreaCode varchar(5) 'NPTGAdminDistrict/AdminAreaCode'
			) X
			


			
		
COMMIT TRANSACTION T3

BEGIN TRANSACTION T4
		-- Car Park Type
		INSERT INTO CarParkingCarParkType (CarParkRef,TypeCode, Description, VersionId)
		SELECT DISTINCT X.CarParkRef, X.TypeCode, X.TypeDescription, @Version FROM OPENXML (@DocID,  '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkType', 2)
		WITH
		(
			CarParkRef varchar(50) '../../CarParkRef',
			TypeCode varchar(50),
			TypeDescription varchar(100)
		) X WHERE TypeCode IS NOT NULL

		-- Linked NaPTANs
		INSERT INTO CarParkingLinkedNaPTANs (
			CarParkRef,
			StopPointType,
			StopCode,
			InterchangeTime,
			InterchangeMode,
			VersionId)
		SELECT
			X.CarParkRef,  
			X.StopPointType,
			X.StopCode,
			X.InterchangeTime,
			X.InterchangeMode,
			@Version
 		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark/CarParkAdditionalData/LinkedNaPTANs', 2)
		WITH (
			CarParkRef varchar(50) '../../CarParkRef',	
			StopPointType varchar(50),
			StopCode varchar(20),
			InterchangeTime int,
			InterchangeMode varchar(100)
			) X 
		WHERE (StopPointType IS NOT NULL OR StopCode IS NOT NULL 
			OR InterchangeTime IS NOT NULL OR InterChangeMode IS NOT NULL)

		
-- Car Park Facilties
		INSERT INTO CarParkingFacilities (FacilitiesTypeId, [Description], CarParkRef, [Name], Location, VersionId)
		SELECT DISTINCT
			X.FacilityTypeCode,
			X.FacilityTypeDescription,
			X.CarParkRef,
			X.FacilityName,
			X.FacilityLocation,
			@Version
		 FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/Facilities', 2)
		WITH
		(
			FacilityTypeCode varchar(100),
			FacilityTypeDescription varchar(100),
			CarParkRef varchar(50) '../../CarParkRef',
			FacilityName varchar(100),
			FacilityLocation varchar(100)
			
		)X
		WHERE FacilityTypeCode IS NOT NULL
		
-- Car Park Attractions
		INSERT INTO CarParkingAttractions (TypeId, [Description], CarParkRef, [Name], WalkingDistance, VersionId)
		SELECT 
			X.AttractionTypeCode,
			X.AttractionTypeDescription,
			X.CarParkRef,
			X.AttractionName,
			X.WalkingDistance,
			@Version
		 FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/Attractions', 2)
		WITH	
		(
			AttractionTypeCode int ,
			AttractionTypeDescription varchar(50),
			CarParkRef varchar(50) '../../CarParkRef',
			AttractionName varchar(100),
			WalkingDistance varchar(6)
		)X
		WHERE AttractionTypeCode IS NOT NULL
		
 

-- Car Park Spaces
		INSERT INTO CarParkingCarParkSpace(SpaceTypeId, [Description], CarParkRef, NumberOfSpaces, VersionId)
		SELECT DISTINCT
			X.TypeCode,
			X.TypeDescription,
			X.CarParkRef,
			X.NumberOfSpaces,
			@Version
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace', 2)
		WITH
		(
			TypeCode varchar(50),
			TypeDescription varchar(50),
			CarParkRef varchar(50) '../../CarParkRef',
			NumberOfSpaces int
		)X
		WHERE (X.TypeCode IS NOT NULL OR NumberOfSpaces IS NOT NULL)
		

		--COMMIT TRANSACTION

COMMIT TRANSACTION T4


BEGIN TRANSACTION T5

-- Car Park Charges
		INSERT INTO CarParkingCarParkCharges (
			SpaceId, 
			CalendarId,
			ChargeTypeId,
			ChargeDescription,
			StartTime,
			EndTime,
			TimeRangeDays,
			TimeRangeMinutes,
			Comments,
			ChargeAmount,
			ChargeDayEndTime
		)
		SELECT 
			(SELECT top 1 Id FROM CarParkingCarParkSpace
				WHERE SpaceTypeId = X.TypeCode AND CarParkRef = X.CarParkRef AND VersionId = @Version) AS SpaceId,
			(SELECT top 1 Id FROM CarParkingCalendar
				WHERE CarParkingCalendar.Start = X.CalendarStartDate
					AND CarParkingCalendar.[End]= X.CalendarEndDate
					AND CarParkingCalendar.Days = X.Days
					AND CarParkingCalendar.PublicHols = X.PublicHolidays
					AND VersionId = @Version)  AS CalendarId,
			X.ChargeType,
			X.ChargeDescription,
			X.StartTime,
			X.EndTime,
			isNull(X.TimeRangeDays,-1),
			isNull(X.TimeRangeMinutes,-1),
			X.Comments,
			isNull(X.ChargeAmount,-1),
			X.ChargeDayEndTime
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace/Charges', 2)
		WITH
		(
			CarParkRef varchar(50) '../../../CarParkRef',
			TypeCode varchar(50) '../TypeCode',
			TypeDescription varchar(50) '../TypeDescription',
			NumberOfSpaces int '../NumberOfSpaces',
			CalendarStartDate datetime 'Calendar/CalendarStartDate',
			CalendarEndDate datetime 'Calendar/CalendarEndDate',
			Days varchar(7) 'Calendar/Days',
			PublicHolidays varchar(8) 'Calendar/PublicHolidays',
			ChargeType varchar(50) ,
			ChargeDescription varchar(100) ,
			StartTime varchar(8) ,
			EndTime varchar(8) ,
			TimeRangeDays int ,
			TimeRangeMinutes int ,
			Comments varchar(200) ,
			ChargeAmount int ,
			ChargeDayEndTime varchar(10) 
						
		)X	

-- Car Park Concessions
		INSERT INTO CarParkingCarParkConcessions(Code, Description, CarParkRef, VersionId)
		SELECT X.ConcessionCode,
			X.ConcessionDescription,
			X.CarParkRef,
			@Version
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/Concessions', 2)
		WITH
		(
			ConcessionCode varchar(50),
			ConcessionDescription varchar(200),
			CarParkRef varchar(50) '../../CarParkRef'
		)X WHERE ConcessionCode IS NOT NULL

-- Car Park Payment Type
		INSERT INTO CarParkingPaymentType(TypeCode,CarParkRef,TypeDescription, VersionId)
		SELECT DISTINCT
			X.TypeCode,
			X.CarParkRef,
			X.TypeDescription,
			@Version
		FROM OPENXML (@DocID, 'CarParkDataImport/CarPark/CarParkAdditionalData/PaymentType', 2)
		WITH
		(
			TypeCode varchar(50),
			CarParkRef varchar(50) '../../CarParkRef',
			TypeDescription varchar(50)
		)X WHERE TypeCode IS NOT NULL	

		
-- Car Park Payment Methods
		INSERT INTO CarParkingPaymentMethods(CarParkRef,Code, Description, ChangeAvailable, VersionId)
		SELECT 	DISTINCT X.CarParkRef,
	       		X.Code,
		       	X.Description,
		       	X.ChangeAvailable,
		        @Version
			FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/PaymentMethods', 2)
		WITH
		(
			CarParkRef varchar(50) '../../CarParkRef',
			Code varchar(50),
			Description varchar(100),
			ChangeAvailable varchar(3)
		)X WHERE Code IS NOT NULL	
		
-- Car Park Opening Times
		INSERT INTO CarParkingOpeningTimes (
		    CarParkRef,
			CalendarId, 
			OpensAt,
			LastEntranceAt,
			ClosesAt,
			MaxStaysDays,
			MaxStayMinutes,
			VersionId
		)
		SELECT 
			X.CarParkRef,
			(SELECT top 1 Id FROM CarParkingCalendar
				WHERE CarParkingCalendar.Start = X.CalendarStartDate
					AND CarParkingCalendar.[End] = X.CalendarEndDate
					AND CarParkingCalendar.Days = X.Days
					AND CarParkingCalendar.PublicHols = X.PublicHolidays
					AND VersionId = @Version)  AS CalendarId,
			X.OpensAt,
			X.LastEntranceAt,
			X.ClosesAt,
			X.MaxStayDays,
			X.MaxStayMinutes,
			@Version
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/OpeningTimes', 2)
		WITH
		(
			CarParkRef varchar(50) '../../CarParkRef',
			CalendarStartDate datetime 'Calendar/CalendarStartDate',
			CalendarEndDate datetime 'Calendar/CalendarEndDate',
			Days varchar(7) 'Calendar/Days',
			PublicHolidays varchar(8) 'Calendar/PublicHolidays',
			OpensAt varchar(8),
			LastEntranceAt varchar(8),
			ClosesAt varchar(8),
			MaxStayDays int,
			MaxStayMinutes int
		)X
		
-- Car Park NPTG Locality
		INSERT INTO CarParkingNPTGLocality(CarParkRef,NationalGazeteerId, Easting, Northing, VersionId)
		SELECT  
			X.CarParkRef,
			X.NationalGazeteerId,
			X.Easting,
			X.Northing,
			@Version
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/NPTGLocality', 2)
		WITH
		(
			CarParkRef varchar(50) '../../CarParkRef',
			NationalGazeteerId varchar(100),
			Easting varchar(7),
			Northing varchar(7)
		)X WHERE (NationalGazeteerId IS NOT NULL OR Easting IS NOT NULL OR Northing IS NOT NULL)



-- Car Park Space Type Availability
		INSERT INTO CarParkingSpaceAvailability (
			SpaceId,
			CalendarId,
			AvailabilityDayType,
			StartTime,
			EndTime,
			PercentageAvailability
		)
		SELECT
			(SELECT top 1 Id FROM CarParkingCarParkSpace
				WHERE SpaceTypeId = X.TypeCode AND CarParkRef = X.CarParkRef AND VersionId = @Version) AS SpaceId,
			(SELECT top 1 Id FROM CarParkingCalendar
				WHERE CarParkingCalendar.Start = X.CalendarStartDate
					AND CarParkingCalendar.[End] = X.CalendarEndDate
					AND CarParkingCalendar.Days = X.Days
					AND CarParkingCalendar.PublicHols = X.PublicHolidays
					AND VersionId = @Version)  AS CalendarId,
			X.AvailabilityDayType, 
			X.StartTime,
			X.EndTime,
			X.PercentageAvailability
		FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkSpace/SpaceTypeAvailability', 2)
		WITH
		(
			CarParkRef varchar(50) '../../../CarParkRef',
			TypeCode varchar(50) '../TypeCode',
			CalendarStartDate datetime 'Calendar/CalendarStartDate',
			CalendarEndDate datetime 'Calendar/CalendarEndDate',
			Days varchar(7) 'Calendar/Days',
			PublicHolidays varchar(8) 'Calendar/PublicHolidays',
			AvailabilityDayType varchar(50) ,
			StartTime varchar(8) ,
			EndTime varchar(8),
			PercentageAvailability int 			
		)X	
			

COMMIT TRANSACTION T5

BEGIN TRANSACTION T6

-- Car Parking Additional Data
	INSERT INTO CarParkingAdditionalData (
				CarParkingId,
				ClosingDate,
				ReopeningDate,
				MaximumHeight,
				MaximumWidth,
				PMSPA,
				EmergencyNumber,
				EmailAddressOfCarPark,
				CCTVAvailable,
				Staffed,
				Patrolled,
				VehicleRestrictions,
				LiftsAvailable,
				AdvancedReservationsAvailable,
				SeasonTicketsAvailable,
				VersionId
		)
	   SELECT  
		X.CarParkRef,
		X.ClosingDate,
		X.ReOpeningDate,
		X.MaxHeight,
		X.MaxWidth,
		X.PMSPA,
		X.EmergencyNumber,
		X.CarParkEmail,
		X.CCTV,
		X.Staffed,
		X.Patrolled,
		X.VehicleRestrictions,
		X.LiftsAvailable,
		X.ReservationsAvailable,
		X.SeasonTicketsAvailable,
		@Version
	FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark/CarParkAdditionalData', 2)
		WITH (	
			CarParkRef varchar(50) '../CarParkRef',
			ClosingDate datetime,
			ReopeningDate datetime,
			MaxHeight int ,
			MaxWidth int ,
			PMSPA varchar(3) ,
			EmergencyNumber varchar(13) ,
			CarParkEmail varchar(100) ,
			CCTV varchar(3),
			Staffed varchar(3) ,
			Patrolled varchar(3) ,
			VehicleRestrictions varchar(150) ,
			LiftsAvailable varchar(3) ,
			ReservationsAvailable varchar(3) ,
			SeasonTicketsAvailable varchar(3) 
			
			
		)X WHERE (ClosingDate IS NOT NULL OR ReOpeningDate IS NOT NULL
				OR MaxHeight IS NOT NULL OR MaxWidth IS NOT NULL
				OR PMSPA IS NOT NULL OR EmergencyNumber IS NOT NULL
				OR CarParkEmail IS NOT NULL OR CCTV IS NOT NULL
				OR Staffed IS NOT NULL OR Patrolled IS NOT NULL
				OR VehicleRestrictions IS NOT NULL OR LiftsAvailable IS NOT NULL
				OR ReservationsAvailable IS NOT NULL OR SeasonTicketsAvailable IS NOT NULL)

		
		
		
			
COMMIT TRANSACTION T6

		IF(@LastFeed = 1)
		BEGIN
			SET @VersionToDelete = @Version - @VersionToDeleteFromlast
			EXEC DeleteCarParkingData @VersionToDelete

			UPDATE DataVersion SET Active = 0 WHERE [Id] = @Version -1
			UPDATE DataVersion SET Active = 1 WHERE [Id] = @Version
			
		END
		-- release temp storage object
		EXEC sp_xml_removedocument @DocID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

---------------------------------------------------------
-- Provide appropriate permission to ImportCarParkingData
---------------------------------------------------------
GRANT  EXECUTE  ON [dbo].[ImportCarParkingData]  TO [???]
GO




------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1295
SET @ScriptDesc = 'Updated stored proc to introduce versioning to carparks database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------