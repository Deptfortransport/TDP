-- ***********************************************
-- NAME 		: DUP1215_ATOC_RTTI_EnquiryPort_Amend.sql
-- DESCRIPTION 		: Script to update the RTTI Enquiry Port IP Address C1388933
-- AUTHOR		: Neil Rankin
-- DATE			: 05 Jan 2009
-- ************************************************

USE [PermanentPortal]
GO

UPDATE [PermanentPortal].[dbo].[properties]
SET  [pValue]='141.196.28.219'
WHERE [pName]='DepartureBoardService.RTTIManager.SocketServer'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = DUP1215
SET @ScriptDesc = 'Script to update the RTTI Enquiry Port IP Address C1388933'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO