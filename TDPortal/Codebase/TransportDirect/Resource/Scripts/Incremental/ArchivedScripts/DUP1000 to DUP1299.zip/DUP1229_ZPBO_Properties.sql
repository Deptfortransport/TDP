-- ***********************************************
-- NAME 			: DUP1229_ZPBO_Properties.sql
-- DESCRIPTION 		: Script to set up the ZPBO properties
-- AUTHOR			: Mitesh Modi
-- DATE				: 22 Dec 2008
-- ************************************************

USE [PermanentPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- PROPERTIES
--------------------------------------------------------------------------------------------------------------------------------

-- TIDY UP (As this is the first script which sets up the ZPBO properties, we can do a global delete)

-- Delete all existing ZPBO properties
IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName LIKE 'RetailBusinessObjects.ZPBO%')
BEGIN
	DELETE FROM properties WHERE pname LIKE 'RetailBusinessObjects.ZPBO%'
END

-- Insert
INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.InterfaceVersion', '0100', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.MinimumPoolSize', '5', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.ObjectId', 'JC', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.PoolSize', '5', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.TimeoutCheckFrequency', '1000', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.TimeoutChecking', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.TimeoutDuration', '5000', 'TDRemotingHost', 'TDRemotingHost', 0, 1)


-- Switch
INSERT INTO properties VALUES ('RetailBusinessObjects.ZPBO.Switch', 'true', 'TDRemotingHost', 'TDRemotingHost', 0, 1)


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1229
SET @ScriptDesc = 'ZPBO Properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO