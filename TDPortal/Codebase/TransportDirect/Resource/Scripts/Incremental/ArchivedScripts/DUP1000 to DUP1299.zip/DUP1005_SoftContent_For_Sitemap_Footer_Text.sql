-- ***********************************************
-- NAME 		: DUP1005_SoftContent_For_Sitemap_Footer_Text.sql
-- DESCRIPTION 	: Soft Content update for sitemap footer note
-- AUTHOR		: Amit Patel
-- DATE		: 30 Jun 2008 12:56:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO




------------------------------------------------------------------------
-- Menu Links tooltip
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 1 -- for transport direct


EXEC AddtblContent
@ThemeId, 43, 'sitemapFooterNote', '/Channels/TransportDirect/SiteMap/SiteMap',
'NOTE Items in black are secondary options of the preceding blue action  <br />  <br />',
'cy NOTE Items in black are secondary options of the preceding blue action  <br />  <br />'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1005
SET @ScriptDesc = 'Soft Content update for sitemap footer note'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
