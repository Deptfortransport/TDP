-- ***********************************************
-- NAME 		: DUP1180_CyclePlanner_Properties_3.sql
-- DESCRIPTION 		: Script to add properties required for Cycle PLanning
-- AUTHOR		: Mark Turner
-- DATE			: 11 Nov 2008
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.CycleJourneyDetailsControl.ImmediateTurnDistance')
BEGIN
	insert into properties values ('CyclePlanner.CycleJourneyDetailsControl.ImmediateTurnDistance', '161', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '161'
	where pname = 'CyclePlanner.CycleJourneyDetailsControl.ImmediateTurnDistance'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1180
SET @ScriptDesc = 'Script to add properties for Cycle PLanning'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO