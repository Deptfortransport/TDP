-- ***********************************************
-- NAME 		: DUP1145_XHTML_contentDB_change.sql
-- DESCRIPTION 		: Script to change entries in the Content DB for XHTML compliance
-- AUTHOR		: John Frank
-- DATE			: 20 Oct 2008 
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'CarCostingDetails.thinkLogo', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/think.gif" alt ="Government Think! campaign logo" />', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/think.gif" alt ="Logo ymgyrch Meddyliwch! y Llywodraeth" />'
GO



----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1145
SET @ScriptDesc = 'Script to change entries in the Content DB for XHTML compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO