-- ***********************************************
-- NAME 		: DUP1222_XHTML_Compliance_Changes.sql
-- DESCRIPTION 		: Update content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 19 December 2008
-- ************************************************

USE [Content]
GO

-- help page for Journey planner input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpJourneyPlannerInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the journey planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the journey planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the journey planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, an underground station, a light rail station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �London�, Derby�, �Newcastle�, �Gatwick�.</div></li>
<li>
<div><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, a tram stop, or a railway station, e.g. �Trafalgar Square�, �Whitley Bay�, �Piccadilly Circus�.</div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting outward and return journey dates</h4>
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the journey planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul>
<p>&nbsp;</p></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting types of transport</h4>
<ul>
<li>
<div><strong>Choose the types of transport you would like to use</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Untick the types of transport that you are not interested in using. However, at least one type must remain ticked<br/>The journey planner will search for journeys that involve the <strong>ticked</strong> types of public transport.&nbsp; However, it may not necessarily find journeys that use all the types that are selected.&nbsp; This is because the journey planner uses <strong>all</strong> the criteria you enter and searches for the most suitable journeys only.</p></blockquote></blockquote>
<h3>Public Transport journey details</h3>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the journey planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</li>
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes</li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly</li> 
<li>''Average'' if you can make the changes at an average pace</li> 
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Walking</h3>
<p>Some journeys will require you to walk in order to get from a location to a stop (or vice versa), or from one stop to another stop.&nbsp; </p>
<p>&nbsp;</p>
<p><strong>Speed (of walking)</strong></p>
<p>Choose your walking speed.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you tend to walk quickly</li> 
<li>''Average'' if you walk at an average pace</li> 
<li>''Slow''&nbsp; if you think you will be walking at a slower than average pace</li></ul>
<p>&nbsp;</p>
<p>For example you should choose ''Slow'' if you are travelling with heavy luggage or if you have a mobility problem.</p>
<p>&nbsp;</p>
<p><strong>Time (max.)</strong></p>
<p>Choose the maximum length of time you are prepared to spend walking between points in your journey from the ''drop-down'' list:</p>
<ul>
<li>''5'' minutes&nbsp;</li> 
<li>''10'' minutes</li> 
<li>''15'' minutes</li> 
<li>''20'' minutes&nbsp;</li> 
<li>''25'' minutes</li> 
<li>''30'' minutes </li></ul>
<p>Please note that setting a low maximum walking speed may limit the number of journeys that can be found.&nbsp; If possible, it is recommended you choose 30 minutes.</p></blockquote>
<h3>Journey options</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Travelling via a location</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Car journey details</h3></blockquote>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the journey planner will select the best driving route. Select:</p></blockquote>
<ul>
<li>
<div><strong>''Quickest''</strong> if you would like a route with the shortest driving time</div></li>
<li>
<div><strong>''Shortest''</strong> if you would like a route with the shortest distance</div></li>
<li>
<div><strong>''Most fuel economic''</strong> if you would like a route with the lowest fuel consumption</div></li>
<li>
<div><strong>''Cheapest overall''</strong> if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul>
<blockquote></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do <strong>not</strong> want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the journey planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the journey planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>At this point the journey planner will search for the locations you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p></blockquote>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.</p></blockquote>
<p></p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>''Cyfeiriad/cod post'':</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� </div></li>
<li>
<div><strong>''Gorsaf/Maes awyr'':</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi. Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick".</div></li>
<li>
<div><strong>''Pob arhosfan'':</strong> Os dewiswch hwn, gallwch deipio enw arhosfan bws, stop tanddaearol, stop metro neu stop tram neu orsaf rheilffordd e.e. Trafalgar Square, Whitley Bay, Piccadilly Circus. </div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>Gallwch glicio ar y botwm ''Canfyddwch ar y map'' i ganfod lleoliad ar fap.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno). Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis mathau o gludiant</h4>
<ul>
<li>
<div><strong>Dewiswch y mathau o gludiant y dymunwch eu defnyddio</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dadgliciwch y mathau o gludiant nad oes gennych ddiddordeb yn eu defnyddio. Ond rhaid sicrhau bod un math o leiaf yn dal wedi ei glicio <br/>Bydd y Cynlluniwr Siwrnai yn chwilio am siwrneion sy''n ymwneud �''r mathau o gludiant cyhoeddus a diciwyd. Ond mae''n bosibl na fydd o anghenraid yn darganfod siwrneion sy''n defnyddio''r holl fathau sy''n cael eu dewis. Mae hyn oherwydd bod y Cynlluniwr Siwrnai yn defnyddio''r holl feini prawf yr ydych wedi eu nodi ac yn chwilio am y siwrneion mwyaf addas yn unig.</p></blockquote>
<h3>Manylion siwrnai cludiant cyhoeddus</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</h4>
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</li> 
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</li> 
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau) </strong></p>
<p><strong>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </strong></p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym</li> 
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin</li> 
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p>&nbsp;</p></blockquote>
<h3>Cerdded</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Bydd rhai siwrneion yn ei gwneud yn ofynnol i chi gerdded er mwyn mynd o leoliad i arhosfan (neu i''r gwrthwyneb), neu o un arhosfan i arhosfan arall. </p>
<p>&nbsp;</p>
<p><strong>Cyflymder (cerdded) </strong></p>
<p>Dewiswch eich cyflymder cerdded. Dewiswch:</p>
<ul>
<li>''Cyflym'' os tueddwch i gerdded yn gyflym</li> 
<li>''Cyfartaledd'' os ydych yn cerdded ar gyflymder cyffredin</li> 
<li>''Araf'' os credwch y byddwch yn cerdded ar gyflymder arafach na''r cyffredin</li></ul>
<p>&nbsp;</p>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn teithio gyda bagiau trymion neu os oes gennych broblem gyda symud.</p>
<p>&nbsp;</p>
<p><strong>Amser (uchafswm) </strong></p>
<p>Dewiswch uchafswm hyd yr amser yr ydych yn barod i''w dreulio yn cerdded rhwng pwyntiau yn eich siwrnai o''r rhestr a ollyngir i lawr:</p>
<ul>
<li>''5'' munud</li> 
<li>''10'' munud</li> 
<li>''15'' munud</li> 
<li>''20'' munud</li> 
<li>''25'' munud</li> 
<li>''30'' munud</li></ul>
<p>Nodwch y gall gosod uchafswm cyflymder cerdded isel gyfyngu ar nifer y siwrneion y gellir dod o hyd iddynt. Os yn bosibl, argymhellir eich bod yn dewis 30 munud.</p></blockquote>
<h3>Dewisiadau ar ran siwrneion</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Teithio drwy leoliad</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote>
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch: </p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru) </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr. Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol: </p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl. </p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km. </p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion</h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�. </p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help. Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yma bydd y Cynlluniwr Siwrnai yn chwilio am y lleoliad yr ydych wedi ei deipio. Os oes mwy nag un lleoliad yn debyg i''r lleoliad y bu i chi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p></blockquote>'


-- printer friendly help page for Journey planner input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyPlannerInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the journey planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the journey planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the journey planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, an underground station, a light rail station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �London�, Derby�, �Newcastle�, �Gatwick�.</div></li>
<li>
<div><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, a tram stop, or a railway station, e.g. �Trafalgar Square�, �Whitley Bay�, �Piccadilly Circus�.</div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting outward and return journey dates</h4>
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the journey planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul>
<p>&nbsp;</p></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting types of transport</h4>
<ul>
<li>
<div><strong>Choose the types of transport you would like to use</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Untick the types of transport that you are not interested in using. However, at least one type must remain ticked<br/>The journey planner will search for journeys that involve the <strong>ticked</strong> types of public transport.&nbsp; However, it may not necessarily find journeys that use all the types that are selected.&nbsp; This is because the journey planner uses <strong>all</strong> the criteria you enter and searches for the most suitable journeys only.</p></blockquote></blockquote>
<h3>Public Transport journey details</h3>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the journey planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</li>
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes</li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly</li> 
<li>''Average'' if you can make the changes at an average pace</li> 
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Walking</h3>
<p>Some journeys will require you to walk in order to get from a location to a stop (or vice versa), or from one stop to another stop.&nbsp; </p>
<p>&nbsp;</p>
<p><strong>Speed (of walking)</strong></p>
<p>Choose your walking speed.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you tend to walk quickly</li> 
<li>''Average'' if you walk at an average pace</li> 
<li>''Slow''&nbsp; if you think you will be walking at a slower than average pace</li></ul>
<p>&nbsp;</p>
<p>For example you should choose ''Slow'' if you are travelling with heavy luggage or if you have a mobility problem.</p>
<p>&nbsp;</p>
<p><strong>Time (max.)</strong></p>
<p>Choose the maximum length of time you are prepared to spend walking between points in your journey from the ''drop-down'' list:</p>
<ul>
<li>''5'' minutes&nbsp;</li> 
<li>''10'' minutes</li> 
<li>''15'' minutes</li> 
<li>''20'' minutes&nbsp;</li> 
<li>''25'' minutes</li> 
<li>''30'' minutes </li></ul>
<p>Please note that setting a low maximum walking speed may limit the number of journeys that can be found.&nbsp; If possible, it is recommended you choose 30 minutes.</p></blockquote>
<h3>Journey options</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Travelling via a location</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Car journey details</h3></blockquote>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the journey planner will select the best driving route. Select:</p></blockquote>
<ul>
<li>
<div><strong>''Quickest''</strong> if you would like a route with the shortest driving time</div></li>
<li>
<div><strong>''Shortest''</strong> if you would like a route with the shortest distance</div></li>
<li>
<div><strong>''Most fuel economic''</strong> if you would like a route with the lowest fuel consumption</div></li>
<li>
<div><strong>''Cheapest overall''</strong> if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul>
<blockquote></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do <strong>not</strong> want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the journey planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the journey planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>At this point the journey planner will search for the locations you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p></blockquote>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.</p></blockquote>
<p></p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>''Cyfeiriad/cod post'':</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� </div></li>
<li>
<div><strong>''Gorsaf/Maes awyr'':</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi. Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick".</div></li>
<li>
<div><strong>''Pob arhosfan'':</strong> Os dewiswch hwn, gallwch deipio enw arhosfan bws, stop tanddaearol, stop metro neu stop tram neu orsaf rheilffordd e.e. Trafalgar Square, Whitley Bay, Piccadilly Circus. </div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>Gallwch glicio ar y botwm ''Canfyddwch ar y map'' i ganfod lleoliad ar fap.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno). Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis mathau o gludiant</h4>
<ul>
<li>
<div><strong>Dewiswch y mathau o gludiant y dymunwch eu defnyddio</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dadgliciwch y mathau o gludiant nad oes gennych ddiddordeb yn eu defnyddio. Ond rhaid sicrhau bod un math o leiaf yn dal wedi ei glicio <br/>Bydd y Cynlluniwr Siwrnai yn chwilio am siwrneion sy''n ymwneud �''r mathau o gludiant cyhoeddus a diciwyd. Ond mae''n bosibl na fydd o anghenraid yn darganfod siwrneion sy''n defnyddio''r holl fathau sy''n cael eu dewis. Mae hyn oherwydd bod y Cynlluniwr Siwrnai yn defnyddio''r holl feini prawf yr ydych wedi eu nodi ac yn chwilio am y siwrneion mwyaf addas yn unig.</p></blockquote>
<h3>Manylion siwrnai cludiant cyhoeddus</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</h4>
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</li> 
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</li> 
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau) </strong></p>
<p><strong>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </strong></p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym</li> 
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin</li> 
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p>&nbsp;</p></blockquote>
<h3>Cerdded</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Bydd rhai siwrneion yn ei gwneud yn ofynnol i chi gerdded er mwyn mynd o leoliad i arhosfan (neu i''r gwrthwyneb), neu o un arhosfan i arhosfan arall. </p>
<p>&nbsp;</p>
<p><strong>Cyflymder (cerdded) </strong></p>
<p>Dewiswch eich cyflymder cerdded. Dewiswch:</p>
<ul>
<li>''Cyflym'' os tueddwch i gerdded yn gyflym</li> 
<li>''Cyfartaledd'' os ydych yn cerdded ar gyflymder cyffredin</li> 
<li>''Araf'' os credwch y byddwch yn cerdded ar gyflymder arafach na''r cyffredin</li></ul>
<p>&nbsp;</p>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn teithio gyda bagiau trymion neu os oes gennych broblem gyda symud.</p>
<p>&nbsp;</p>
<p><strong>Amser (uchafswm) </strong></p>
<p>Dewiswch uchafswm hyd yr amser yr ydych yn barod i''w dreulio yn cerdded rhwng pwyntiau yn eich siwrnai o''r rhestr a ollyngir i lawr:</p>
<ul>
<li>''5'' munud</li> 
<li>''10'' munud</li> 
<li>''15'' munud</li> 
<li>''20'' munud</li> 
<li>''25'' munud</li> 
<li>''30'' munud</li></ul>
<p>Nodwch y gall gosod uchafswm cyflymder cerdded isel gyfyngu ar nifer y siwrneion y gellir dod o hyd iddynt. Os yn bosibl, argymhellir eich bod yn dewis 30 munud.</p></blockquote>
<h3>Dewisiadau ar ran siwrneion</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Teithio drwy leoliad</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote>
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch: </p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru) </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr. Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol: </p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl. </p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km. </p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion</h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�. </p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help. Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yma bydd y Cynlluniwr Siwrnai yn chwilio am y lleoliad yr ydych wedi ei deipio. Os oes mwy nag un lleoliad yn debyg i''r lleoliad y bu i chi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p></blockquote>'

-- printer friendly help page for Journey planner input page
EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyPlannerInput'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the journey planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>&nbsp;</p>
<h5>2. Select the type of locations</h5>
<p>&nbsp;</p>
<p>This will inform the journey planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the journey planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li>
<li>
<div><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations, e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�</div></li>
<li>
<div><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, an underground station, a light rail station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,e.g. �London�, Derby�, �Newcastle�, �Gatwick�.</div></li>
<li>
<div><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, a tram stop, or a railway station, e.g. �Trafalgar Square�, �Whitley Bay�, �Piccadilly Circus�.</div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Find the location on a map (optional)</h5>
<p>&nbsp;</p>
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting outward and return journey dates</h4>
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the journey planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul>
<p>&nbsp;</p></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting types of transport</h4>
<ul>
<li>
<div><strong>Choose the types of transport you would like to use</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Untick the types of transport that you are not interested in using. However, at least one type must remain ticked<br/>The journey planner will search for journeys that involve the <strong>ticked</strong> types of public transport.&nbsp; However, it may not necessarily find journeys that use all the types that are selected.&nbsp; This is because the journey planner uses <strong>all</strong> the criteria you enter and searches for the most suitable journeys only.</p></blockquote></blockquote>
<h3>Public Transport journey details</h3>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the journey planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</li>
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes</li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly</li> 
<li>''Average'' if you can make the changes at an average pace</li> 
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Walking</h3>
<p>Some journeys will require you to walk in order to get from a location to a stop (or vice versa), or from one stop to another stop.&nbsp; </p>
<p>&nbsp;</p>
<p><strong>Speed (of walking)</strong></p>
<p>Choose your walking speed.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you tend to walk quickly</li> 
<li>''Average'' if you walk at an average pace</li> 
<li>''Slow''&nbsp; if you think you will be walking at a slower than average pace</li></ul>
<p>&nbsp;</p>
<p>For example you should choose ''Slow'' if you are travelling with heavy luggage or if you have a mobility problem.</p>
<p>&nbsp;</p>
<p><strong>Time (max.)</strong></p>
<p>Choose the maximum length of time you are prepared to spend walking between points in your journey from the ''drop-down'' list:</p>
<ul>
<li>''5'' minutes&nbsp;</li> 
<li>''10'' minutes</li> 
<li>''15'' minutes</li> 
<li>''20'' minutes&nbsp;</li> 
<li>''25'' minutes</li> 
<li>''30'' minutes </li></ul>
<p>Please note that setting a low maximum walking speed may limit the number of journeys that can be found.&nbsp; If possible, it is recommended you choose 30 minutes.</p></blockquote>
<h3>Journey options</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Travelling via a location</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h3>Car journey details</h3></blockquote>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the journey planner will select the best driving route. Select:</p></blockquote>
<ul>
<li>
<div><strong>''Quickest''</strong> if you would like a route with the shortest driving time</div></li>
<li>
<div><strong>''Shortest''</strong> if you would like a route with the shortest distance</div></li>
<li>
<div><strong>''Most fuel economic''</strong> if you would like a route with the lowest fuel consumption</div></li>
<li>
<div><strong>''Cheapest overall''</strong> if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul>
<blockquote></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do <strong>not</strong> want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the journey planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the journey planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote>
<blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>At this point the journey planner will search for the locations you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p></blockquote>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati.</p></blockquote>
<p></p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliadau</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>''Cyfeiriad/cod post'':</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan, e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </div></li>
<li>
<div><strong>''Cyfleuster/atyniad'':</strong> Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys: gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu, e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� </div></li>
<li>
<div><strong>''Gorsaf/Maes awyr'':</strong>&nbsp; Os dewiswch hyn, gallwch deipio enw gorsaf rheilffordd, gorsaf tanddaearol, gorsaf rheilffordd ysgafn, gorsaf bysiau moethus, maes awyr neu derfynnell fferi. Gallwch hefyd deipio enw tref a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon, e.e. "Llundain", "Derby", "Newcastle", "Gatwick".</div></li>
<li>
<div><strong>''Pob arhosfan'':</strong> Os dewiswch hwn, gallwch deipio enw arhosfan bws, stop tanddaearol, stop metro neu stop tram neu orsaf rheilffordd e.e. Trafalgar Square, Whitley Bay, Piccadilly Circus. </div></li></ul>
<p>&nbsp;</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Canfyddwch y lleoliad ar fap (dewisol)</h5>
<p>&nbsp;</p>
<p>Gallwch glicio ar y botwm ''Canfyddwch ar y map'' i ganfod lleoliad ar fap.</p>
<p>Wedi i chi ddod o hyd i''r lleoliad ar y map, bydd gennych y dewis o barhau i gynllunio''r siwrnai (drwy glicio ar ''Nesa'' ar y dudalen honno). Bydd hyn yn dod � chi yn �l i''r dudalen gyfredol.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis mathau o gludiant</h4>
<ul>
<li>
<div><strong>Dewiswch y mathau o gludiant y dymunwch eu defnyddio</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dadgliciwch y mathau o gludiant nad oes gennych ddiddordeb yn eu defnyddio. Ond rhaid sicrhau bod un math o leiaf yn dal wedi ei glicio <br/>Bydd y Cynlluniwr Siwrnai yn chwilio am siwrneion sy''n ymwneud �''r mathau o gludiant cyhoeddus a diciwyd. Ond mae''n bosibl na fydd o anghenraid yn darganfod siwrneion sy''n defnyddio''r holl fathau sy''n cael eu dewis. Mae hyn oherwydd bod y Cynlluniwr Siwrnai yn defnyddio''r holl feini prawf yr ydych wedi eu nodi ac yn chwilio am y siwrneion mwyaf addas yn unig.</p></blockquote>
<h3>Manylion siwrnai cludiant cyhoeddus</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</h4>
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</li> 
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</li> 
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau) </strong></p>
<p><strong>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </strong></p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym</li> 
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin</li> 
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p>&nbsp;</p></blockquote>
<h3>Cerdded</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Bydd rhai siwrneion yn ei gwneud yn ofynnol i chi gerdded er mwyn mynd o leoliad i arhosfan (neu i''r gwrthwyneb), neu o un arhosfan i arhosfan arall. </p>
<p>&nbsp;</p>
<p><strong>Cyflymder (cerdded) </strong></p>
<p>Dewiswch eich cyflymder cerdded. Dewiswch:</p>
<ul>
<li>''Cyflym'' os tueddwch i gerdded yn gyflym</li> 
<li>''Cyfartaledd'' os ydych yn cerdded ar gyflymder cyffredin</li> 
<li>''Araf'' os credwch y byddwch yn cerdded ar gyflymder arafach na''r cyffredin</li></ul>
<p>&nbsp;</p>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn teithio gyda bagiau trymion neu os oes gennych broblem gyda symud.</p>
<p>&nbsp;</p>
<p><strong>Amser (uchafswm) </strong></p>
<p>Dewiswch uchafswm hyd yr amser yr ydych yn barod i''w dreulio yn cerdded rhwng pwyntiau yn eich siwrnai o''r rhestr a ollyngir i lawr:</p>
<ul>
<li>''5'' munud</li> 
<li>''10'' munud</li> 
<li>''15'' munud</li> 
<li>''20'' munud</li> 
<li>''25'' munud</li> 
<li>''30'' munud</li></ul>
<p>Nodwch y gall gosod uchafswm cyflymder cerdded isel gyfyngu ar nifer y siwrneion y gellir dod o hyd iddynt. Os yn bosibl, argymhellir eich bod yn dewis 30 munud.</p></blockquote>
<h3>Dewisiadau ar ran siwrneion</h3>
<p>&nbsp;</p>
<ul>
<li>
<div><strong>Teithio drwy leoliad</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote>
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch: </p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf</div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf</div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol'' os hoffech gael y llwybr rhataf sy''n cymryd holl agweddau''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru) </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr. Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig. Gallwch ddewis o blith y canlynol: </p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd'' <br/></div></li>
<li>
<div>''60 mya''&nbsp;<br/></div></li>
<li>
<div>''50 mya''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mya''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl. </p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartaledd ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km. </p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau o ran siwrneion</h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>Osgoi ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�. </p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai.Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad. I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help. Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Yma bydd y Cynlluniwr Siwrnai yn chwilio am y lleoliad yr ydych wedi ei deipio. Os oes mwy nag un lleoliad yn debyg i''r lleoliad y bu i chi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p></blockquote>'

GO

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.imageDoorToDoor.AlternateText'
,'Plan a door-to-door journey'
,'cy Plan a door-to-door journey'

GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDashboardControl.Spacer.AlternateText'
,'Spacer'
,'cy Spacer'

GO

-- TravelNews Map alternate text
EXEC AddtblContent
1, 1, 'langStrings', 'PrintableTravelNews.imageMap.AlternateText'
,'Travel news map'
,'cy Travel news map'

GO

-- Printable Journey Emissions soft content
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissions.labelSaveFuel.Text'
,'Drive off peak to avoid congestion
<ul><li>Congestion costs fuel and CO2. Use Transport Direct to find out the least congested time to drive.</li></ul>
<br/><br/>Drive smoothly
<ul><li>You save 30% on fuel and CO2 when you drive at a steady 50 mph instead of 70 mph.</li></ul>
<br/><br/>Drive at 70 mph on the motorway
<ul><li>Sticking to the speed limit could save you up to �5 on a 100 mile motorway journey.</li></ul>
<br/><br/>Check your tyres
<ul><li>Soft tyres will increase your fuel bill by around �2 on a 100 mile round trip.</li></ul>
<br/><br/>Service your car
<ul><li>Dirty petrol and oil filters reduce your cars fuel efficiency.</li></ul>'
,'Gyrrwch yn ystod oriau allfrig i osgoi tagfeydd
<ul><li>Mae tagfeydd yn costio tanwydd a CO2. Defnyddiwch Transport Direct i gael gwybod yr amser lleiaf prysur i yrru.</li></ul>
<br/><br/>Gyrrwch yn esmwyth
<ul><li>Rydych chi''n arbed 30% ar danwydd a CO2 pan fyddwch chi''n gyrru 50 m.y.a. yn gyson yn lle 70 m.y.a.</li></ul>
<br/><br/>Gyrrwch 70 m.y.a. ar y draffordd
<ul><li>Drwy gadw at y cyfyngiad cyflymdra, fe allech arbed hyd at �5 ar siwrnai 100 milltir ar y draffordd.</li></ul>
<br/><br/>Edrychwch dros eich teiars
<ul><li>Bydd teiars meddal yn cynyddu eich bil tanwydd rhyw �2 ar daith ddydd 100 milltir.</li></ul>
<br/><br/>Cofiwch drin eich car
<ul><li>Mae hidlwyr petrol ac olew brwnt yn lleihau effeithlonrwydd tanwydd eich car.</li></ul>'

GO

-- help content for travel news page
EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelTravelNewsNonMap',
'To tailor the Live travel news (e.g. to your region, types of transport, date, etc.):<br/><br/>    1.    Select a region from the drop-down lists or the map and select other options from the drop-down lists.<br/>    2.    Click "OK"<br/><br/>The information is automatically sorted by "Severity" so that the most severe incidents appear at the top of the page.<br/><br/>You can also view these details on a map by clicking "Show on map".  In order to do this however, you need to select a region from the drop-down list before clicking the button.<br/><br/>',
'I deilwrio''r newyddion teithio Byw (e.e. i''ch rhanbarth, mathau o gludiant, dyddiad, ac ati):<br/><br/>    1.    Dewiswch ranbarth o''r rhestrau a ollyngir i lawr neu''r map a dewiswch opsiynau eraill o''r rhestrau a ollyngir i lawr.<br/>    2.    Cliciwch ''Iawn''.<br/><br/>Mae''r wybodaeth yn cael ei didoli yn awtomatig yn �l ''Difrifoldeb'' fel bod y digwyddiadau mwyaf difrifol yn ymddangos ar frig y dudalen.Gellir hefyd weld y manylion hyn ar fap drwy glicio ''Dangoswch ar y map''.  Ond er mwyn gwneud hyn mae angen i chi ddewis rhanbarth o''r rhestr a ollyngir i lawr cyn clicio ar y botwm.<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelTravelNews',
'To tailor the Live travel news (e.g. to your region, types of transport, date, etc.):<br/><br/>   1.    Select a region from the drop-down lists or the map and select other options from the drop-down lists.<br/>    2.    Click "OK"<br/><br/>If there are incidents in the regions you view, they will be indicated by symbols on the map.  If you mouse over these symbols, a box containing details of the incident will appear on the page.<br/><br/>',
'I deilwrio''r newyddion teithio Byw (e.e. i''ch rhanbarth, mathau o gludiant, dyddiad, ac ati):<br/>    1.    Dewiswch ranbarth o''r rhestrau a ollyngir i lawr neu''r map a dewiswch opsiynau eraill o''r rhestrau a ollyngir i lawr.<br/>    2.    Cliciwch ''Iawn''. <br/><br/>Os oes unrhyw ddigwyddiadau yn y rhanbarthau yr edrychwch arnynt, fe''u nodir � symbolau ar y map.  Os ewch � llygoden dros y symbolau hyn, bydd blwch yn cynnwys manylion y digwyddiad yn ymddangos ar y dudalen.<br/>'

GO

-- help page for CarDetails page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCarDetails',
'<h3>View car directions</h3><br/><br/>
<p>This page shows the detailed car directions of your route. </p><br/>
<p>The directions for your car journey are initially shown in a list. This page allows you to change which measure of distance the instructions are shown in i.e. kilometers or miles. </p><br/>
<p>Where the overall journey is for both an outward and a return, two sets of instructions will appear on this page.</p><br/>
<p>When you have finished viewing the directions, press "Back" to continue.</p>',
'<h3>Edrychwch ar gyfeiriadau ceir</h3><br/><br/>
<p>Mae''r dudalen hon yn dangos y cyfeiriadau car manwl ar gyfer eich llwybr. </p><br/>
<p>Dangosir y cyfeiriadau ar gyfer eich siwrnai car i ddechrau mewn rhestr.  Mae''r dudalen hon yn caniatau i chi newid pa fesur o bellter y dangosir y cyfeiriadau ynddynt h.y. kilometrau neu filltiroedd. </p><br/>
<p>Lle bo''r siwrnai gyffredinol ar gyfer siwrnai allan a siwrnai ddychwel, bydd dwy set o gyfeiriadau yn ymddangos ar y dudalen hon.</p><br/>
<p>Pan ydych wedi gorffen edrych ar y cyfeiriadau, gwasgwch ''Yn �l'' i barhau.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCarDetails',
'<h3>View car directions</h3><br/><br/>
<p>This page shows the detailed car directions of your route. </p><br/>
<p>The directions for your car journey are initially shown in a list. This page allows you to change which measure of distance the instructions are shown in i.e. kilometers or miles. </p><br/>
<p>Where the overall journey is for both an outward and a return, two sets of instructions will appear on this page.</p><br/>
<p>When you have finished viewing the directions, press "Back" to continue.</p>',
'<h3>Edrychwch ar gyfeiriadau ceir</h3><br/><br/>
<p>Mae''r dudalen hon yn dangos y cyfeiriadau car manwl ar gyfer eich llwybr. </p><br/>
<p>Dangosir y cyfeiriadau ar gyfer eich siwrnai car i ddechrau mewn rhestr.  Mae''r dudalen hon yn caniatau i chi newid pa fesur o bellter y dangosir y cyfeiriadau ynddynt h.y. kilometrau neu filltiroedd. </p><br/>
<p>Lle bo''r siwrnai gyffredinol ar gyfer siwrnai allan a siwrnai ddychwel, bydd dwy set o gyfeiriadau yn ymddangos ar y dudalen hon.</p><br/>
<p>Pan ydych wedi gorffen edrych ar y cyfeiriadau, gwasgwch ''Yn �l'' i barhau.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCarDetails',
'<h3>View car directions</h3><br/><br/>
<p>This page shows the detailed car directions of your route. </p><br/>
<p>The directions for your car journey are initially shown in a list. This page allows you to change which measure of distance the instructions are shown in i.e. kilometers or miles. </p><br/>
<p>Where the overall journey is for both an outward and a return, two sets of instructions will appear on this page.</p><br/>
<p>When you have finished viewing the directions, press "Back" to continue.</p>',
'<h3>Edrychwch ar gyfeiriadau ceir</h3><br/><br/>
<p>Mae''r dudalen hon yn dangos y cyfeiriadau car manwl ar gyfer eich llwybr. </p><br/>
<p>Dangosir y cyfeiriadau ar gyfer eich siwrnai car i ddechrau mewn rhestr.  Mae''r dudalen hon yn caniatau i chi newid pa fesur o bellter y dangosir y cyfeiriadau ynddynt h.y. kilometrau neu filltiroedd. </p><br/>
<p>Lle bo''r siwrnai gyffredinol ar gyfer siwrnai allan a siwrnai ddychwel, bydd dwy set o gyfeiriadau yn ymddangos ar y dudalen hon.</p><br/>
<p>Pan ydych wedi gorffen edrych ar y cyfeiriadau, gwasgwch ''Yn �l'' i barhau.</p>'

GO

-- help page for RefineDetails page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpRefineDetails'
,'<h3>View details of the journey</h3><br/><br/>
<p>This page shows the detailed journey breakdown including places where you need to change transport.</p><br/>
<p>This breakdown is available either as a diagram or as text only.</p><br/>
<p>By clicking on place names in the breakdown, you can view additional location information, for example, taxi information for stations.</p><br/>
<p>To see more detail about a certain leg of your journey, click on the icon or hyperlink which represents the type of transport being used (only currently available on car and train elements).</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>To see car directions for a journey, click on the image/link for the car.</li> 
<li>For a list of all the stations at which a train service will call, click on the image/link for the train.</li></ul></div></div><br/>
<p>Where your journey involves a very short walk, Transport Direct will show this with two places next to one another.</p><br/>
<p>If you have finished viewing all the details of this journey, press "Back to summary" to continue.</p>'
,'<h3>Edrychwch ar fanylion y siwrnai</h3><br/><br/>
<p>Mae''r dudalen hon yn dangos manylion am y siwrnai fanwl gan gynnwys lleoedd y mae angen i chi newid cludiant.</p><br/>
<p>Mae''r manylion hyn ar gael naill ai fel diagram neu fel testun yn unig.</p><br/>
<p>Drwy glicio ar enwau lleoedd yn y manylion am y siwrnai fanwl, gallwch weld gwybodaeth ychwanegol am leoliad, er enghraifft gwybodaeth am dacsis i orsafoedd.</p><br/>
<p>I gael mwy o fanylion am adran arbennig o''ch siwrnai, cliciwch ar yr eicon neu''r hyper-ddolen sy''n cynrychioli''r math o gludiant a ddefnyddir (sydd ar gael ar hyn o bryd gydag elfennau sy''n ymwneud � char a thr�n yn unig).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>I weld cyfarwyddiadau car ar gyfer siwrnai, cliciwch ar y ddelwedd/dolen ar gyfer y car.</li> 
<li>I gael rhestr o''r holl orsafoedd y bydd gwasanaeth tr�n yn galw ynddynt, cliciwch ar y ddelwedd/dolen ar gyfer y tr�n.</li></ul></div></div><br/>
<p>Pan fo eich siwrnai yn golygu cerdded ychydig o bellter, bydd Transport Direct yn dangos hyn gyda dau le agosaf at ei gilydd.</p><br/>
<p>Os ydych wedi gorffen edrych ar holl fanylion y siwrnai hon, gwasgwch ''Yn �l i''r crynodeb'' i barhau.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpRefineDetails'
,'<h3>View details of the journey</h3><br/><br/>
<p>This page shows the detailed journey breakdown including places where you need to change transport.</p><br/>
<p>This breakdown is available either as a diagram or as text only.</p><br/>
<p>By clicking on place names in the breakdown, you can view additional location information, for example, taxi information for stations.</p><br/>
<p>To see more detail about a certain leg of your journey, click on the icon or hyperlink which represents the type of transport being used (only currently available on car and train elements).</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>To see car directions for a journey, click on the image/link for the car.</li> 
<li>For a list of all the stations at which a train service will call, click on the image/link for the train.</li></ul></div></div><br/>
<p>Where your journey involves a very short walk, Transport Direct will show this with two places next to one another.</p><br/>
<p>If you have finished viewing all the details of this journey, press "Back to summary" to continue.</p>'
,'<h3>Edrychwch ar fanylion y siwrnai</h3><br/><br/>
<p>Mae''r dudalen hon yn dangos manylion am y siwrnai fanwl gan gynnwys lleoedd y mae angen i chi newid cludiant.</p><br/>
<p>Mae''r manylion hyn ar gael naill ai fel diagram neu fel testun yn unig.</p><br/>
<p>Drwy glicio ar enwau lleoedd yn y manylion am y siwrnai fanwl, gallwch weld gwybodaeth ychwanegol am leoliad, er enghraifft gwybodaeth am dacsis i orsafoedd.</p><br/>
<p>I gael mwy o fanylion am adran arbennig o''ch siwrnai, cliciwch ar yr eicon neu''r hyper-ddolen sy''n cynrychioli''r math o gludiant a ddefnyddir (sydd ar gael ar hyn o bryd gydag elfennau sy''n ymwneud � char a thr�n yn unig).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>I weld cyfarwyddiadau car ar gyfer siwrnai, cliciwch ar y ddelwedd/dolen ar gyfer y car.</li> 
<li>I gael rhestr o''r holl orsafoedd y bydd gwasanaeth tr�n yn galw ynddynt, cliciwch ar y ddelwedd/dolen ar gyfer y tr�n.</li></ul></div></div><br/>
<p>Pan fo eich siwrnai yn golygu cerdded ychydig o bellter, bydd Transport Direct yn dangos hyn gyda dau le agosaf at ei gilydd.</p><br/>
<p>Os ydych wedi gorffen edrych ar holl fanylion y siwrnai hon, gwasgwch ''Yn �l i''r crynodeb'' i barhau.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpRefineDetails'
,'<h3>View details of the journey</h3><br/><br/>
<p>This page shows the detailed journey breakdown including places where you need to change transport.</p><br/>
<p>This breakdown is available either as a diagram or as text only.</p><br/>
<p>By clicking on place names in the breakdown, you can view additional location information, for example, taxi information for stations.</p><br/>
<p>To see more detail about a certain leg of your journey, click on the icon or hyperlink which represents the type of transport being used (only currently available on car and train elements).</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>To see car directions for a journey, click on the image/link for the car.</li> 
<li>For a list of all the stations at which a train service will call, click on the image/link for the train.</li></ul></div></div><br/>
<p>Where your journey involves a very short walk, Transport Direct will show this with two places next to one another.</p><br/>
<p>If you have finished viewing all the details of this journey, press "Back to summary" to continue.</p>'
,'<h3>Edrychwch ar fanylion y siwrnai</h3><br/><br/>
<p>Mae''r dudalen hon yn dangos manylion am y siwrnai fanwl gan gynnwys lleoedd y mae angen i chi newid cludiant.</p><br/>
<p>Mae''r manylion hyn ar gael naill ai fel diagram neu fel testun yn unig.</p><br/>
<p>Drwy glicio ar enwau lleoedd yn y manylion am y siwrnai fanwl, gallwch weld gwybodaeth ychwanegol am leoliad, er enghraifft gwybodaeth am dacsis i orsafoedd.</p><br/>
<p>I gael mwy o fanylion am adran arbennig o''ch siwrnai, cliciwch ar yr eicon neu''r hyper-ddolen sy''n cynrychioli''r math o gludiant a ddefnyddir (sydd ar gael ar hyn o bryd gydag elfennau sy''n ymwneud � char a thr�n yn unig).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>I weld cyfarwyddiadau car ar gyfer siwrnai, cliciwch ar y ddelwedd/dolen ar gyfer y car.</li> 
<li>I gael rhestr o''r holl orsafoedd y bydd gwasanaeth tr�n yn galw ynddynt, cliciwch ar y ddelwedd/dolen ar gyfer y tr�n.</li></ul></div></div><br/>
<p>Pan fo eich siwrnai yn golygu cerdded ychydig o bellter, bydd Transport Direct yn dangos hyn gyda dau le agosaf at ei gilydd.</p><br/>
<p>Os ydych wedi gorffen edrych ar holl fanylion y siwrnai hon, gwasgwch ''Yn �l i''r crynodeb'' i barhau.</p>'

GO

-- Alternate text for image imageExtensionResultSummary on ExtensionResultSummary page
EXEC AddtblContent
1, 1, 'RefineJourney', 'ExtensionResultsSummary.imageExtensionResultSummary.AlternateText',
'Extension Result Summary'
,'cy Extension Results Summary'

GO

-- help page for Extension Results Summary page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpExtensionResultsSummary',
'<p>If you are not interested in any of the extension options, you can go back and enter different details by clicking ''Amend". </p><br/>
<p>If you are happy with the options, select one and click ''Add this to your journey''. </p>'
,'<p>Os nad oes gennych chi ddiddordeb mewn unrhyw un o''r opsiynau ymestyn, gallwch fynd yn cl a rhoi gwahanol fanylion drwy glicio ''Newid''. </p><br/>
<p>Os ydych chi''n hapus gyda''r opsiynau, dewiswch un a chliciwch ''Ychwanegwch estyniad i''ch siwrnai''. </p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpExtensionResultsSummary',
'<p>If you are not interested in any of the extension options, you can go back and enter different details by clicking ''Amend". </p><br/>
<p>If you are happy with the options, select one and click ''Add this to your journey''. </p>'
,'<p>Os nad oes gennych chi ddiddordeb mewn unrhyw un o''r opsiynau ymestyn, gallwch fynd yn cl a rhoi gwahanol fanylion drwy glicio ''Newid''. </p><br/>
<p>Os ydych chi''n hapus gyda''r opsiynau, dewiswch un a chliciwch ''Ychwanegwch estyniad i''ch siwrnai''. </p>'


EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpExtensionResultsSummary',
'<p>If you are not interested in any of the extension options, you can go back and enter different details by clicking ''Amend". </p><br/>
<p>If you are happy with the options, select one and click ''Add this to your journey''. </p>'
,'<p>Os nad oes gennych chi ddiddordeb mewn unrhyw un o''r opsiynau ymestyn, gallwch fynd yn cl a rhoi gwahanol fanylion drwy glicio ''Newid''. </p><br/>
<p>Os ydych chi''n hapus gyda''r opsiynau, dewiswch un a chliciwch ''Ychwanegwch estyniad i''ch siwrnai''. </p>'

GO

-- help page for Replan Full Itinarary Summary page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpReplanFullItinerarySummary',
'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by replacing part or all of your original journey with an alternative type of transport i.e. public transport changed instead of car, or vice versa.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey plan was by public transport for a journey from your nearest station to a friend''s house. It appears that your friend lives in a village where there are only two buses a day. You chose to replan the last part of your journey from the main station which is local to your friend, to their house, thinking you will probably get a taxi or a lift.</li> 
<li>This page shows the new combined journey of public transport. To see the detailed car directions, click on the car image/link.</li></ul></div></div>
<br/><p>This page gives a summarised view of the full journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the full journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p><br/>
<h3>Would you like to modify further?</h3><br/><br/>
<p>If your main journey was for an outward and a return, you will have the option to modify the remaining journey direction.</p><br/>
<p>Choose from the drop down menu if you wish to replan the other journey direction.</p><br/>
<p>If your original journey was one-way, this option will not appear in the drop down menu.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy amnewid rhan neu''r cyfan o''ch siwrnai wreiddiol gyda math arall o gludiant (h.y. newid cludiant cyhoeddus yn lle car, neu fel arall).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd cynllun eich siwrnai wreiddiol ar gludiant cyhoeddus ar gyfer siwrnai o''ch gorsaf agosaf i dy ffrind. Mae''n ymddangos fod eich ffrind yn byw mewn pentref lle nad oes ond dau fws y dydd. Roeddech chi wedi dewis ailgynllunio rhan olaf eich siwrnai o''r brif orsaf sy''n lleol i''ch ffrind, at ei dy, gan feddwl y byddwch mae''n debyg yn cael tacsi neu lifft.</li> 
<li>Mae''r dudalen hon yn dangos y siwrnai gyfun newydd i chi ar gludiant cyhoeddus. I weld y cyfarwyddiadau manwl mewn car, cliciwch ar y ddelwedd/dolen car.</li></ul></div></div>
<br/>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai lawn. Mae''n dangos yr holl fathau o gludiant y bydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai lawn ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p><br/>
<h3>Hoffech chi newid hyn ymhellach?</h3><br/><br/>
<p>Os oedd eich prif siwrnai am siwrnai allan a siwrnai ddychwel, bydd gennych y dewis i ddiwygio cyfeiriad y siwrnai sydd ar �l.</p><br/>
<p>Dewiswch o''r ddewislen a ollyngir i lawr os dymunwch ailgynllunio cyfeiriad y siwrnai arall.</p><br/>
<p>Os oedd eich siwrnai wreiddiol yn un ffordd, ni fydd y dewis hwn yn ymddangos yn y ddewislen a ollyngir i lawr.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpReplanFullItinerarySummary',
'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by replacing part or all of your original journey with an alternative type of transport i.e. public transport changed instead of car, or vice versa.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey plan was by public transport for a journey from your nearest station to a friend''s house. It appears that your friend lives in a village where there are only two buses a day. You chose to replan the last part of your journey from the main station which is local to your friend, to their house, thinking you will probably get a taxi or a lift.</li> 
<li>This page shows the new combined journey of public transport. To see the detailed car directions, click on the car image/link.</li></ul></div></div>
<br/><p>This page gives a summarised view of the full journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the full journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p><br/>
<h3>Would you like to modify further?</h3><br/><br/>
<p>If your main journey was for an outward and a return, you will have the option to modify the remaining journey direction.</p><br/>
<p>Choose from the drop down menu if you wish to replan the other journey direction.</p><br/>
<p>If your original journey was one-way, this option will not appear in the drop down menu.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy amnewid rhan neu''r cyfan o''ch siwrnai wreiddiol gyda math arall o gludiant (h.y. newid cludiant cyhoeddus yn lle car, neu fel arall).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd cynllun eich siwrnai wreiddiol ar gludiant cyhoeddus ar gyfer siwrnai o''ch gorsaf agosaf i dy ffrind. Mae''n ymddangos fod eich ffrind yn byw mewn pentref lle nad oes ond dau fws y dydd. Roeddech chi wedi dewis ailgynllunio rhan olaf eich siwrnai o''r brif orsaf sy''n lleol i''ch ffrind, at ei dy, gan feddwl y byddwch mae''n debyg yn cael tacsi neu lifft.</li> 
<li>Mae''r dudalen hon yn dangos y siwrnai gyfun newydd i chi ar gludiant cyhoeddus. I weld y cyfarwyddiadau manwl mewn car, cliciwch ar y ddelwedd/dolen car.</li></ul></div></div>
<br/>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai lawn. Mae''n dangos yr holl fathau o gludiant y bydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai lawn ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p><br/>
<h3>Hoffech chi newid hyn ymhellach?</h3><br/><br/>
<p>Os oedd eich prif siwrnai am siwrnai allan a siwrnai ddychwel, bydd gennych y dewis i ddiwygio cyfeiriad y siwrnai sydd ar �l.</p><br/>
<p>Dewiswch o''r ddewislen a ollyngir i lawr os dymunwch ailgynllunio cyfeiriad y siwrnai arall.</p><br/>
<p>Os oedd eich siwrnai wreiddiol yn un ffordd, ni fydd y dewis hwn yn ymddangos yn y ddewislen a ollyngir i lawr.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpReplanFullItinerarySummary',
'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by replacing part or all of your original journey with an alternative type of transport i.e. public transport changed instead of car, or vice versa.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey plan was by public transport for a journey from your nearest station to a friend''s house. It appears that your friend lives in a village where there are only two buses a day. You chose to replan the last part of your journey from the main station which is local to your friend, to their house, thinking you will probably get a taxi or a lift.</li> 
<li>This page shows the new combined journey of public transport. To see the detailed car directions, click on the car image/link.</li></ul></div></div>
<br/><p>This page gives a summarised view of the full journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the full journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p><br/>
<h3>Would you like to modify further?</h3><br/><br/>
<p>If your main journey was for an outward and a return, you will have the option to modify the remaining journey direction.</p><br/>
<p>Choose from the drop down menu if you wish to replan the other journey direction.</p><br/>
<p>If your original journey was one-way, this option will not appear in the drop down menu.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy amnewid rhan neu''r cyfan o''ch siwrnai wreiddiol gyda math arall o gludiant (h.y. newid cludiant cyhoeddus yn lle car, neu fel arall).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd cynllun eich siwrnai wreiddiol ar gludiant cyhoeddus ar gyfer siwrnai o''ch gorsaf agosaf i dy ffrind. Mae''n ymddangos fod eich ffrind yn byw mewn pentref lle nad oes ond dau fws y dydd. Roeddech chi wedi dewis ailgynllunio rhan olaf eich siwrnai o''r brif orsaf sy''n lleol i''ch ffrind, at ei dy, gan feddwl y byddwch mae''n debyg yn cael tacsi neu lifft.</li> 
<li>Mae''r dudalen hon yn dangos y siwrnai gyfun newydd i chi ar gludiant cyhoeddus. I weld y cyfarwyddiadau manwl mewn car, cliciwch ar y ddelwedd/dolen car.</li></ul></div></div>
<br/>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai lawn. Mae''n dangos yr holl fathau o gludiant y bydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai lawn ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p><br/>
<h3>Hoffech chi newid hyn ymhellach?</h3><br/><br/>
<p>Os oedd eich prif siwrnai am siwrnai allan a siwrnai ddychwel, bydd gennych y dewis i ddiwygio cyfeiriad y siwrnai sydd ar �l.</p><br/>
<p>Dewiswch o''r ddewislen a ollyngir i lawr os dymunwch ailgynllunio cyfeiriad y siwrnai arall.</p><br/>
<p>Os oedd eich siwrnai wreiddiol yn un ffordd, ni fydd y dewis hwn yn ymddangos yn y ddewislen a ollyngir i lawr.</p>'

GO

-- help page for Replan Full Itinarary Summary page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpRefineJourney',
'<h3>Ways to modify your journey</h3><br/><br/>
<p>You have planned an initial journey between two places and chosen to modify this journey. This is the only journey you can now modify. If this is not the journey you want to customise, then use the "Back" button to return to the list of initial journey options. </p>
<h4>Is this journey now complete?</h4>
<p>You can add another journey to your main journey with <strong>Add a connecting journey</strong>. For example, you may choose to get local transport to the start of your main journey. Or perhaps choose to add a car or taxi journey to get to your final destination. </p>
<p>Please note: If your initial journey was a return journey, each additional journey will also be a return. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>Plan a flight from London to Glasgow, add a connecting journey to see how to get to Heathrow by public transport.</li> 
<li>Find a train from Brighton to Eastbourne, plan an additional journey to get from Eastbourne station to your friend''s house test test. Decide if this journey can be made with public transport or if you will need a taxi or a lift from Eastbourne station. </li></ul></div></div>
<p></p>
<h4>Which is better for you? Public transport or car?</h4>
<p>If your initial journey is by public transport, you may decide to drive part or all the way instead. Using the most appropriate times from your original journey, <strong>Combine car and public transport</strong> will replan the parts of the journey which you select.<br/><br/>Please note: If your initial journey is a return, you must, at this stage, choose which journey you would like to replan (i.e. the outward journey or the return journey). It is possible to replan both, but you must replan each one in turn. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>You have planned a public transport journey plan from your home to a job interview. The main part of the journey is on a train which departs early, so you decide to drive to your nearest railway station instead of taking the bus.</li></ul></div></div><br/>
<h4>What if I miss the connecting service?</h4>
<p>Transport Direct uses recommended interchange times for each station, airport and bus stop in your original journey, to allow you time to get from one form of transport to another.<br/><br/>If your initial journey plan has a least one stage where it is necessary to change transport, you can vary the initial journey by allowing more time at those stages. Adjust the timings within your journey can be used to replan your journey based on your own interchange preferences.<br/><br/>Please note: This feature is only available for journeys which have at least one place where you change transport. <br/>Also, if your initial journey is a return, you must, at this stage, choose which journey you would like to adjust (i.e. the outward journey or the return journey). It is possible to replan both, but you must replan each one in turn. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>You are travelling from Bath Spa to Leamington Spa by train. You need to change trains in Reading, and the train to Leamington leaves 16 minutes after you arrive from Bath. You may want to allow more time in Reading, or want to see what is the next service in case you are delayed and miss your connection.</li></ul></div></div>'
,'<h3>Ffyrdd o newid eich siwrnai</h3><br/><br/>
<p>Rydych wedi cynllunio siwrnai ddechreuol rhwng dau le ac wedi dewis newid y siwrnai hon. Dyma''r unig siwrnai y gallwch ei newid yn awr. Os mai nid dyma''r siwrnai y dymunwch ei newid, yna defnyddiwch y botwm ''Yn �l'' i ddychwelyd i''r rhestr o ddewisiadau siwrnai dechreuol. </p>
<h4>A yw''r siwrnai hon bellach yn gyflawn?</h4>
<p>Gallwch ychwanegu siwrnai arall at eich prif siwrnai gyda <strong>"Ychwanegwch siwrnai gysylltiol"</strong>. Er enghraifft gallwch ddewis cael cludiant lleol i ddechrau eich prif siwrnai. Neu efallai ddewis ychwanegu siwrnai car neu dacsi i fynd i''ch cyrchfan derfynol. </p>
<p>Noder: Os oedd eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, bydd pob siwrnai ychwanegol hefyd yn siwrnai yn �l ac ymlaen. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau:</p>
<div>
<ul>
<li>Cynlluniwch hedfaniad o Lundain i Glasgow, ychwanegwch siwrnai gysylltiol i weld sut i fynd i Heathrow ar gludiant cyhoeddus. </li>
<li>Darganfyddwch dr�n o Brighton i Eastbourne, cynlluniwch siwrnai ychwanegol i fynd o orsaf Eastbourne i dy eich ffrind. Penderfynwch a all y siwrnai hon gael ei gwneud gyda chludiant cyhoeddus neu a fydd arnoch angen tacsi neu lifft o orsaf Eastbourne. </li></ul></div></div>
<p></p>
<h4>Pa un sydd orau i chi? Cludiant cyhoeddus neu gar?</h4>
<p>Os yw eich siwrnai ddechreuol drwy gludiant cyhoeddus, gallwch benderfynu gyrru rhan neu''r holl ffordd yn lle hynny. Gan ddefnyddio''r amserau mwyaf priodol o''ch siwrnai wreiddiol, bydd <strong>Cyfuno car a chludiant cyhoeddus</strong> yn ailgynllunio rhannau o''r siwrnai a ddewiswch.<br/><br/>Noder: Os yw eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, rhaid i chi ddewis pa siwrnai yr hoffech ei hailgynllunio (e.e. y siwrnai allan neu''r siwrnai ddychwel). Mae''n bosib ailgynllunio''r ddwy, ond rhaid i chi ailgynllunio pob un yn ei dro. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau: </p>
<div>
<ul>
<li>Rydych wedi cynllunio cynllun siwrnai cludiant cyhoeddus o''ch cartref i gyfweliad am swydd. Mae prif ran y siwrnai ar dr�n sy''n ymadael yn gynnar, felly rydych yn penderfynu gyrru i''ch gorsaf rheilffordd agosaf yn hytrach na chymryd y bws.</li></ul></div></div><br/>
<h4>Beth os collaf y gwasanaeth cysylltiol?</h4>
<p>Mae Transport Direct yn defnyddio amserau rhyng-newid a argymhellir ar gyfer pob gorsaf, maes awyr ac arosfan bws yn eich siwrnai wreiddiol, i roi amser i chi fynd o un math o gludiant i un arall.<br/><br/>Os oes gan eich cynllun siwrnai ddechreuol o leiaf un cam lle mae angen newid cludiant, gallwch amrywio''r siwrnai ddechreuol drwy roi mwy o amser yn ystod y camau hynny. Gellir defnyddio Addaswch yr amseriadau o fewn eich siwrnai i ailgynllunio eich siwrnai yn seiliedig ar eich hoffterau rhyng-newid eich hun.<br/><br/>Noder: Mae''r nodwedd hon ar gael ar gyfer siwrneion sydd ag o leiaf un lle lle rydych yn newid cludiant yn unig.<br/>Hefyd, os yw eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, rhaid i chi, ar y cyfnod hwn, ddewis pa siwrnai yr hoffech ei haddasu (h.y. y siwrnai allan neu''r siwrnai ddychwel). Mae''n bosib ailgynllunio''r ddwy, ond rhaid i chi ailgynllunio pob un yn ei thro. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau:</p>
<div>
<ul>
<li>Rydych yn teithio o Bath Spa i Leamington Spa mewn tr�n. Mae angen i chi newid trenau yn Reading, ac mae''r tr�n i Leamington yn gadael 16 munud ar �l i chi gyrraedd o Bath. Efallai y bydd angen i chi ganiat�u mwy o amser yn Reading, neu efallai y dymunwch weld beth yw''r gwasanaeth nesaf rhag ofn y byddwch yn cael eich dal yn �l ac yn colli eich cysylltiad.</li></ul></div></div>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpRefineJourney',
'<h3>Ways to modify your journey</h3><br/><br/>
<p>You have planned an initial journey between two places and chosen to modify this journey. This is the only journey you can now modify. If this is not the journey you want to customise, then use the "Back" button to return to the list of initial journey options. </p>
<h4>Is this journey now complete?</h4>
<p>You can add another journey to your main journey with <strong>Add a connecting journey</strong>. For example, you may choose to get local transport to the start of your main journey. Or perhaps choose to add a car or taxi journey to get to your final destination. </p>
<p>Please note: If your initial journey was a return journey, each additional journey will also be a return. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>Plan a flight from London to Glasgow, add a connecting journey to see how to get to Heathrow by public transport.</li> 
<li>Find a train from Brighton to Eastbourne, plan an additional journey to get from Eastbourne station to your friend''s house test test. Decide if this journey can be made with public transport or if you will need a taxi or a lift from Eastbourne station. </li></ul></div></div>
<p></p>
<h4>Which is better for you? Public transport or car?</h4>
<p>If your initial journey is by public transport, you may decide to drive part or all the way instead. Using the most appropriate times from your original journey, <strong>Combine car and public transport</strong> will replan the parts of the journey which you select.<br/><br/>Please note: If your initial journey is a return, you must, at this stage, choose which journey you would like to replan (i.e. the outward journey or the return journey). It is possible to replan both, but you must replan each one in turn. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>You have planned a public transport journey plan from your home to a job interview. The main part of the journey is on a train which departs early, so you decide to drive to your nearest railway station instead of taking the bus.</li></ul></div></div><br/>
<h4>What if I miss the connecting service?</h4>
<p>Transport Direct uses recommended interchange times for each station, airport and bus stop in your original journey, to allow you time to get from one form of transport to another.<br/><br/>If your initial journey plan has a least one stage where it is necessary to change transport, you can vary the initial journey by allowing more time at those stages. Adjust the timings within your journey can be used to replan your journey based on your own interchange preferences.<br/><br/>Please note: This feature is only available for journeys which have at least one place where you change transport. <br/>Also, if your initial journey is a return, you must, at this stage, choose which journey you would like to adjust (i.e. the outward journey or the return journey). It is possible to replan both, but you must replan each one in turn. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>You are travelling from Bath Spa to Leamington Spa by train. You need to change trains in Reading, and the train to Leamington leaves 16 minutes after you arrive from Bath. You may want to allow more time in Reading, or want to see what is the next service in case you are delayed and miss your connection.</li></ul></div></div>'
,'<h3>Ffyrdd o newid eich siwrnai</h3><br/><br/>
<p>Rydych wedi cynllunio siwrnai ddechreuol rhwng dau le ac wedi dewis newid y siwrnai hon. Dyma''r unig siwrnai y gallwch ei newid yn awr. Os mai nid dyma''r siwrnai y dymunwch ei newid, yna defnyddiwch y botwm ''Yn �l'' i ddychwelyd i''r rhestr o ddewisiadau siwrnai dechreuol. </p>
<h4>A yw''r siwrnai hon bellach yn gyflawn?</h4>
<p>Gallwch ychwanegu siwrnai arall at eich prif siwrnai gyda <strong>"Ychwanegwch siwrnai gysylltiol"</strong>. Er enghraifft gallwch ddewis cael cludiant lleol i ddechrau eich prif siwrnai. Neu efallai ddewis ychwanegu siwrnai car neu dacsi i fynd i''ch cyrchfan derfynol. </p>
<p>Noder: Os oedd eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, bydd pob siwrnai ychwanegol hefyd yn siwrnai yn �l ac ymlaen. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau:</p>
<div>
<ul>
<li>Cynlluniwch hedfaniad o Lundain i Glasgow, ychwanegwch siwrnai gysylltiol i weld sut i fynd i Heathrow ar gludiant cyhoeddus. </li>
<li>Darganfyddwch dr�n o Brighton i Eastbourne, cynlluniwch siwrnai ychwanegol i fynd o orsaf Eastbourne i dy eich ffrind. Penderfynwch a all y siwrnai hon gael ei gwneud gyda chludiant cyhoeddus neu a fydd arnoch angen tacsi neu lifft o orsaf Eastbourne. </li></ul></div></div>
<p></p>
<h4>Pa un sydd orau i chi? Cludiant cyhoeddus neu gar?</h4>
<p>Os yw eich siwrnai ddechreuol drwy gludiant cyhoeddus, gallwch benderfynu gyrru rhan neu''r holl ffordd yn lle hynny. Gan ddefnyddio''r amserau mwyaf priodol o''ch siwrnai wreiddiol, bydd <strong>Cyfuno car a chludiant cyhoeddus</strong> yn ailgynllunio rhannau o''r siwrnai a ddewiswch.<br/><br/>Noder: Os yw eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, rhaid i chi ddewis pa siwrnai yr hoffech ei hailgynllunio (e.e. y siwrnai allan neu''r siwrnai ddychwel). Mae''n bosib ailgynllunio''r ddwy, ond rhaid i chi ailgynllunio pob un yn ei dro. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau: </p>
<div>
<ul>
<li>Rydych wedi cynllunio cynllun siwrnai cludiant cyhoeddus o''ch cartref i gyfweliad am swydd. Mae prif ran y siwrnai ar dr�n sy''n ymadael yn gynnar, felly rydych yn penderfynu gyrru i''ch gorsaf rheilffordd agosaf yn hytrach na chymryd y bws.</li></ul></div></div><br/>
<h4>Beth os collaf y gwasanaeth cysylltiol?</h4>
<p>Mae Transport Direct yn defnyddio amserau rhyng-newid a argymhellir ar gyfer pob gorsaf, maes awyr ac arosfan bws yn eich siwrnai wreiddiol, i roi amser i chi fynd o un math o gludiant i un arall.<br/><br/>Os oes gan eich cynllun siwrnai ddechreuol o leiaf un cam lle mae angen newid cludiant, gallwch amrywio''r siwrnai ddechreuol drwy roi mwy o amser yn ystod y camau hynny. Gellir defnyddio Addaswch yr amseriadau o fewn eich siwrnai i ailgynllunio eich siwrnai yn seiliedig ar eich hoffterau rhyng-newid eich hun.<br/><br/>Noder: Mae''r nodwedd hon ar gael ar gyfer siwrneion sydd ag o leiaf un lle lle rydych yn newid cludiant yn unig.<br/>Hefyd, os yw eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, rhaid i chi, ar y cyfnod hwn, ddewis pa siwrnai yr hoffech ei haddasu (h.y. y siwrnai allan neu''r siwrnai ddychwel). Mae''n bosib ailgynllunio''r ddwy, ond rhaid i chi ailgynllunio pob un yn ei thro. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau:</p>
<div>
<ul>
<li>Rydych yn teithio o Bath Spa i Leamington Spa mewn tr�n. Mae angen i chi newid trenau yn Reading, ac mae''r tr�n i Leamington yn gadael 16 munud ar �l i chi gyrraedd o Bath. Efallai y bydd angen i chi ganiat�u mwy o amser yn Reading, neu efallai y dymunwch weld beth yw''r gwasanaeth nesaf rhag ofn y byddwch yn cael eich dal yn �l ac yn colli eich cysylltiad.</li></ul></div></div>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpRefineJourney',
'<h3>Ways to modify your journey</h3><br/><br/>
<p>You have planned an initial journey between two places and chosen to modify this journey. This is the only journey you can now modify. If this is not the journey you want to customise, then use the "Back" button to return to the list of initial journey options. </p>
<h4>Is this journey now complete?</h4>
<p>You can add another journey to your main journey with <strong>Add a connecting journey</strong>. For example, you may choose to get local transport to the start of your main journey. Or perhaps choose to add a car or taxi journey to get to your final destination. </p>
<p>Please note: If your initial journey was a return journey, each additional journey will also be a return. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>Plan a flight from London to Glasgow, add a connecting journey to see how to get to Heathrow by public transport.</li> 
<li>Find a train from Brighton to Eastbourne, plan an additional journey to get from Eastbourne station to your friend''s house test test. Decide if this journey can be made with public transport or if you will need a taxi or a lift from Eastbourne station. </li></ul></div></div>
<p></p>
<h4>Which is better for you? Public transport or car?</h4>
<p>If your initial journey is by public transport, you may decide to drive part or all the way instead. Using the most appropriate times from your original journey, <strong>Combine car and public transport</strong> will replan the parts of the journey which you select.<br/><br/>Please note: If your initial journey is a return, you must, at this stage, choose which journey you would like to replan (i.e. the outward journey or the return journey). It is possible to replan both, but you must replan each one in turn. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>You have planned a public transport journey plan from your home to a job interview. The main part of the journey is on a train which departs early, so you decide to drive to your nearest railway station instead of taking the bus.</li></ul></div></div><br/>
<h4>What if I miss the connecting service?</h4>
<p>Transport Direct uses recommended interchange times for each station, airport and bus stop in your original journey, to allow you time to get from one form of transport to another.<br/><br/>If your initial journey plan has a least one stage where it is necessary to change transport, you can vary the initial journey by allowing more time at those stages. Adjust the timings within your journey can be used to replan your journey based on your own interchange preferences.<br/><br/>Please note: This feature is only available for journeys which have at least one place where you change transport. <br/>Also, if your initial journey is a return, you must, at this stage, choose which journey you would like to adjust (i.e. the outward journey or the return journey). It is possible to replan both, but you must replan each one in turn. </p><br/>
<div class="boxtypenineinner">
<p>Examples:</p>
<div>
<ul>
<li>You are travelling from Bath Spa to Leamington Spa by train. You need to change trains in Reading, and the train to Leamington leaves 16 minutes after you arrive from Bath. You may want to allow more time in Reading, or want to see what is the next service in case you are delayed and miss your connection.</li></ul></div></div>'
,'<h3>Ffyrdd o newid eich siwrnai</h3><br/><br/>
<p>Rydych wedi cynllunio siwrnai ddechreuol rhwng dau le ac wedi dewis newid y siwrnai hon. Dyma''r unig siwrnai y gallwch ei newid yn awr. Os mai nid dyma''r siwrnai y dymunwch ei newid, yna defnyddiwch y botwm ''Yn �l'' i ddychwelyd i''r rhestr o ddewisiadau siwrnai dechreuol. </p>
<h4>A yw''r siwrnai hon bellach yn gyflawn?</h4>
<p>Gallwch ychwanegu siwrnai arall at eich prif siwrnai gyda <strong>"Ychwanegwch siwrnai gysylltiol"</strong>. Er enghraifft gallwch ddewis cael cludiant lleol i ddechrau eich prif siwrnai. Neu efallai ddewis ychwanegu siwrnai car neu dacsi i fynd i''ch cyrchfan derfynol. </p>
<p>Noder: Os oedd eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, bydd pob siwrnai ychwanegol hefyd yn siwrnai yn �l ac ymlaen. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau:</p>
<div>
<ul>
<li>Cynlluniwch hedfaniad o Lundain i Glasgow, ychwanegwch siwrnai gysylltiol i weld sut i fynd i Heathrow ar gludiant cyhoeddus. </li>
<li>Darganfyddwch dr�n o Brighton i Eastbourne, cynlluniwch siwrnai ychwanegol i fynd o orsaf Eastbourne i dy eich ffrind. Penderfynwch a all y siwrnai hon gael ei gwneud gyda chludiant cyhoeddus neu a fydd arnoch angen tacsi neu lifft o orsaf Eastbourne. </li></ul></div></div>
<p></p>
<h4>Pa un sydd orau i chi? Cludiant cyhoeddus neu gar?</h4>
<p>Os yw eich siwrnai ddechreuol drwy gludiant cyhoeddus, gallwch benderfynu gyrru rhan neu''r holl ffordd yn lle hynny. Gan ddefnyddio''r amserau mwyaf priodol o''ch siwrnai wreiddiol, bydd <strong>Cyfuno car a chludiant cyhoeddus</strong> yn ailgynllunio rhannau o''r siwrnai a ddewiswch.<br/><br/>Noder: Os yw eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, rhaid i chi ddewis pa siwrnai yr hoffech ei hailgynllunio (e.e. y siwrnai allan neu''r siwrnai ddychwel). Mae''n bosib ailgynllunio''r ddwy, ond rhaid i chi ailgynllunio pob un yn ei dro. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau: </p>
<div>
<ul>
<li>Rydych wedi cynllunio cynllun siwrnai cludiant cyhoeddus o''ch cartref i gyfweliad am swydd. Mae prif ran y siwrnai ar dr�n sy''n ymadael yn gynnar, felly rydych yn penderfynu gyrru i''ch gorsaf rheilffordd agosaf yn hytrach na chymryd y bws.</li></ul></div></div><br/>
<h4>Beth os collaf y gwasanaeth cysylltiol?</h4>
<p>Mae Transport Direct yn defnyddio amserau rhyng-newid a argymhellir ar gyfer pob gorsaf, maes awyr ac arosfan bws yn eich siwrnai wreiddiol, i roi amser i chi fynd o un math o gludiant i un arall.<br/><br/>Os oes gan eich cynllun siwrnai ddechreuol o leiaf un cam lle mae angen newid cludiant, gallwch amrywio''r siwrnai ddechreuol drwy roi mwy o amser yn ystod y camau hynny. Gellir defnyddio Addaswch yr amseriadau o fewn eich siwrnai i ailgynllunio eich siwrnai yn seiliedig ar eich hoffterau rhyng-newid eich hun.<br/><br/>Noder: Mae''r nodwedd hon ar gael ar gyfer siwrneion sydd ag o leiaf un lle lle rydych yn newid cludiant yn unig.<br/>Hefyd, os yw eich siwrnai ddechreuol yn siwrnai yn �l ac ymlaen, rhaid i chi, ar y cyfnod hwn, ddewis pa siwrnai yr hoffech ei haddasu (h.y. y siwrnai allan neu''r siwrnai ddychwel). Mae''n bosib ailgynllunio''r ddwy, ond rhaid i chi ailgynllunio pob un yn ei thro. </p><br/>
<div class="boxtypenineinner">
<p>Enghreifftiau:</p>
<div>
<ul>
<li>Rydych yn teithio o Bath Spa i Leamington Spa mewn tr�n. Mae angen i chi newid trenau yn Reading, ac mae''r tr�n i Leamington yn gadael 16 munud ar �l i chi gyrraedd o Bath. Efallai y bydd angen i chi ganiat�u mwy o amser yn Reading, neu efallai y dymunwch weld beth yw''r gwasanaeth nesaf rhag ofn y byddwch yn cael eich dal yn �l ac yn colli eich cysylltiad.</li></ul></div></div>'

GO

-- BusinessLinks page soft content
EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.BusinessLinksSubheading.Text'
,'You can feature your own customised journey planner on your website for free. Your customers will be able to find out how to get to your location without having to leave your site (the journey directions and maps are shown in a new window).<br/><br/>Follow the three easy steps to create a customised journey planner for your website for free.'
,'Gallwch roi eich cynlluniwr siwrnai eich hun ar eich gwefan am ddim. Bydd eich cwsmeriaid yn gallu darganfod sut i gyrraedd eich lleoliad heb orfod gadael eich safle (dangosir cyfarwyddiadau''r siwrnai a''r mapiau mewn ffenestr newydd). <br/><br/>Dilynwch y tri cham hawdd i greu cynlluniwr siwrnai arbennig ar gyfer eich gwefan am ddim.'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.TermsConditionsSubheading.Text'
,'Terms &amp; conditions'
,'Amodau a thelerau'

EXEC AddtblContent
1, 1, 'Tools', 'BusinesLinks.AgreeTermsNote.Text'
,'Note: By clicking "Next" you are agreeing to the above Terms &amp; conditions'
,'Noder: Drwy glicio ar "Nesaf" rydych yn cytuno i''r Amodau a''r Telerau uchod.'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.labelStep2Note1.Text'
,'Notes:<br/>If you choose the "Starting postcode only" template, your customers" journeys will be based on the current date and time.<br/>If you pick the "Starting postcode plus date and time" one, you will need to add code to automatically set the dropdowns to the current date/time with a look-ahead not exceeding the end of the month after next.<br/>The "Starting postcode plus from/to selection" template allows journeys to be planned from or to the destination specified above, using the current date and time. Please note that this template includes Javascript.<br/>The "Starting postcode, from/to selection plus date and time" template also includes Javascript. If you choose this template, you will need to add the following to the opening  &lt;body&gt;  tag of your web page:<br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; onload="SetDateTimeDropDown()"<br/><br/>An example of this is in Section 3.2 of our '
,'Nodiadau:<br/>Os dewiswch y templad "C�d post y cychwyn yn unig", seilir siwrneion eich cwsmeriaid ar y dyddiad a''r amser cyfredol.<br/>Os dewiswch yr un "C�d post y cychwyn plws dyddiad ac amser", bydd angen i chi adio c�d i osod y dewislenni a ollyngir i lawr yn awtomatig i''r dyddiad/amser cyfredol gan edrych ymlaen at gyfnod nad yw''n fwy na diwedd y mis ar �l y nesaf.<br/>Mae''r templad "C�d post cychwyn plws y detholiad o/i" yn caniatau i siwrneion gael eu cynllunio o neu i''r cyrchfan a nodwyd uchod, gan ddefnyddio''r dyddiad a''r amser cyfredol. Nodwch fod y templad hwn yn cynnwys Javascript.<br/>Mae''r templad "C�d post cychwyn, y detholiad o/i plws y dyddiad a''r amser" hefyd yn cynnwys Javascript.  Os dewiswch y templad hwn, bydd angen i chi ychwanegu''r canlynol at dag  &lt;corff&gt;  agoriadol eich tudalen gwe:<br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; onload="SetDateTimeDropDown()"<br/><br/>Ceir enghraifft o hyn yn Adran 3.2 ein '

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.labelStep2Note2.Text'
,'<br/><br/>If you choose the "Find nearest car park" template, the car parks nearest to the location entered in the template will be found.<br/><br/>You can also change how the templates work and how they look. See our '
,'<br/><br/>cy If you choose the "Find nearest car park" template, the car parks nearest to the location entered in the template will be found.<br/><br/>Gallwch hefyd newid sut mae''r templadau yn gweithio a sut maent yn edrych. Gweler ein '

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.TermsConditions.Text'
,'<table class="businesslinktermsdivtable" cellspacing="0" summary="Business Link Conditions">
<tr>
	<td width="30px">�</td>
	<td width="45px">�</td>
	<td>�</td>
</tr>
<tr>
	<td class="businesslinkboldcenter" colspan="3">LINKING
		YOUR WEBSITE TO TRANSPORT DIRECT</td></tr>
<tr>
	<td class="businesslinkpadtop" colspan="3">These terms
		and conditions ("Terms and Conditions") set out the basis upon which you
		("you") are authorised by the Secretary of State for Transport ("we",
		"us", "our") to include a hypertext link ("link") from your company or
		organisation''s website ("your site") to the Transport Direct website at www.transportdirect.info ("our site"). </td></tr>
<tr>
	<td class="businesslinkpadtop" colspan="3">Use of our
		site in this way is also subject to our site <a href="../About/TermsConditions.aspx" target="_blank">
			terms and conditions</a> and by
		accepting these Terms and Conditions you agree to abide by our site terms
		and conditions.</td></tr>
<tr>
	<td class="businesslinkpadtop" colspan="3">You are not
		permitted to include a link from your site to our site unless you have
		agreed to and accepted these Terms and Conditions.</td></tr>
<tr>
	<td class="businesslinktablebold">1</td>
	<td colspan="2" class="businesslinktablebold">Ownership of Transport Direct</td></tr>
<tr class="businesslinktable">
	<td>1.1</td>
	<td colspan="2">The Secretary of State for Transport
		either owns or is licensed to use the intellectual property rights in the
		data and software (�data�, �software�) used in our site. </td></tr>
<tr class="businesslinktable">
	<td>1.2</td>
	<td colspan="2">The data remains our property, or our
		suppliers'' property, as the case may be.</td></tr>
<tr>
	<td class="businesslinktablebold">2</td>
	<td class="businesslinktablebold" colspan="2">Licence to
		link to Transport Direct</td></tr>
<tr class="businesslinktable">
	<td>2.1</td>
	<td colspan="2">Provided you accept these terms and
		conditions in full, we grant you a non-exclusive, revocable,
		non-transferable licence to link to our site. </td></tr>
<tr>
	<td class="businesslinktablebold">3</td>
	<td class="businesslinktablebold" colspan="2">Your
		obligations </td></tr>
<tr class="businesslinktable">
	<td>3.1</td>
	<td colspan="2">You shall ensure that: </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.1</td>
	<td>your site complies with all applicable law,
		regulations and legislation;</td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td class="businesslinktable">3.1.2</td>
	<td>your site maintains the highest standards of good
		taste and decency, does not offer products or services that encourage
		lawlessness or infringe public health or safety and does not disparage or
		bring into disrepute the concepts of public transport and environmental
		best practice; </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.3</td>
	<td>you do not charge anyone who makes use of the
		link to our site; </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.4</td>
	<td>users of your site use the link and our site for
		non-commercial purposes only; </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.5</td>
	<td>you protect and do not interfere with the
		Secretary of State''s rights in respect of Transport Direct''s trade names,
		trade marks and logos and do not distribute or re-use those names, marks
		and logos without prior permission; </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.6</td>
	<td>you do not infringe the intellectual property
		rights of any other person;</td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.7</td>
	<td>you do not pass to anyone your rights or
		obligations under these Terms and Conditions; </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.8</td>
	<td>you represent fairly and lawfully the data, the
		software and Transport Direct''s good name;</td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.9</td>
	<td>you do not do anything or include anything on
		your site that implies any endorsement, sponsorship or approval of your
		site by us, and you acknowledge that the inclusion of the link on your
		site does not in any way represent any such endorsement, sponsorship or
		approval of your site by us; and </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>3.1.10</td>
	<td>your site is not defamatory of any person,
		business or undertaking. </td></tr>
<tr class="businesslinktable">
	<td>3.2</td>
	<td colspan="2">You accept that we may keep records of
		your links and hold such records for periodic inspection and tracking
		purposes.</td></tr>
<tr>
	<td class="businesslinktablebold">4</td>
	<td class="businesslinktablebold" colspan="2">Your rights
	</td></tr>
<tr class="businesslinktable">
	<td>4.1</td>
	<td colspan="2">You may remove the link from your site
		at any time. To enable us to keep our records up to date, please notify us
		by email at <a href="mailto:transport_direct_pso@dft.gsi.gov.uk">transport_direct_pso@dft.gsi.gov.uk</a>
		in the event that you remove the link from your site. </td></tr>
<tr>
	<td class="businesslinktablebold">5</td>
	<td class="businesslinktablebold" colspan="2">Our
		rights</td></tr>
<tr class="businesslinktable">
	<td>5.1</td>
	<td colspan="2">We reserve the right to terminate or
		modify your right to include the link on your site at any time by notice
		in writing to you at the email address that you have provided us with. We
		may disable/terminate your link to our site if: </td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>5.1.1</td>
	<td>you breach any part of these terms and
		conditions; or</td></tr>
<tr class="businesslinktable">
	<td>�</td>
	<td>5.1.2</td>
	<td>any legislation, order or regulation, or any
		other matter prevents us from granting or continuing your licence.</td></tr>
<tr class="businesslinktable">
	<td>5.2</td>
	<td colspan="2">We reserve the right to revise these
		Terms and Conditions at any time. We will post updated Terms and
		Conditions on our site. It is your responsibility to review these Terms
		and Conditions regularly so that you are aware of any revisions. If you
		continue to include a link on your site after a change to these Terms and
		Conditions has been made, you will be deemed to accept the revised Terms
		and Conditions. If you do not accept any revised Terms and Conditions,
		please remove the link from your site.</td></tr>
<tr class="businesslinktable">
	<td>5.3</td>
	<td colspan="2">If we disable your link to our site for
		any reason, you will have no claim against us and you will remove from
		your website all references and links to our site. </td></tr>
<tr>
	<td class="businesslinktablebold">6</td>
	<td class="businesslinktablebold" colspan="2">Responsibilities</td></tr>
<tr class="businesslinktable">
	<td>6.1</td>
	<td colspan="2">We make no promise or any other
		statement or representation regarding the accuracy, fitness for purpose,
		performance, satisfactory quality, or use of our site and exclude to the
		fullest extent permissible by law all warranties, obligations, conditions
		or terms which may be implied by common law, statute or otherwise in
		relation to the link or our site. Accordingly, it is your responsibility
		to ensure that the Transport Direct Portal is fit for your intended use.
	</td></tr>
<tr class="businesslinktable">
	<td>6.2</td>
	<td colspan="2">In no event shall we be liable to you
		for any losses (whether direct, indirect, special or consequential)
		suffered by you as a result of including a link on your site. </td></tr>
<tr class="businesslinktable">
	<td>6.3</td>
	<td colspan="2">We have no responsibility for any
		technical problem or failure of any kind relating to the installation of
		your link to our site.</td></tr></table>'
,'<table width="98%" align="center">
<tr>
  <td colspan="3" class="businesslinkboldcenter">CYSYLLTU EICH GWEFAN � TRANSPORT DIRECT</td></tr>
<tr>
  <td colspan="3" class="businesslinkpadtop">Mae''r amodau a''r telerau hyn (''Amodau a Thelerau'') yn cyflwyno''r sail yr awdurdodir chi (''chi'') arni gan yr Ysgrifennydd Gwladol dros Gludiant (''ni'', ''ein'') i gynnwys dolen hyper-destun (''dolen'') o wefan eich cwmni neu sefydliad (''eich safle'') i wefan Transport Direct yn www.transportdirect.info (''ein safle''). </td></tr>
<tr>
  <td colspan="3" class="businesslinkpadtop">Mae defnyddio''r safle fel hyn yn ddarostyngedig hefyd i amodau a thelerau ein safle <a 
    href="http://www.transportdirect.info/Web2/About/TermsConditions.aspx" 
    target="_blank">rhowch ddolen i amodau a thelerau porth td</a> a thrwy dderbyn yr Amodau a''r Telerau hyn rydych yn cytuno i gadw at delerau ac amodau ein safle.</td></tr>
<tr>
  <td colspan="3" class="businesslinkpadtop">Ni chaniateir i chi gynnwys dolen o''ch safle i''n safle ni oni bai eich bod wedi cytuno i ac wedi derbyn yr Amodau a''r Telerau hyn. </td></tr>
<tr>
  <td class="businesslinktablebold">1</td>
  <td colspan="2" class="businesslinktablebold">Perchnogaeth Transport Direct </td></tr>
<tr class="businesslinktable">
  <td>1.1</td>
  <td colspan="2">Mae''r Ysgrifennydd Gwladol dros Gludiant naill ai yn berchen ar neu wedi ei drwyddedu i ddefnyddio hawliau eiddo deallusol yn y data a''r meddalwedd (''data'', ''meddalwedd'') a ddefnyddir yn ein safle. </td></tr>
<tr class="businesslinktable">
  <td>1.2</td>
  <td colspan="2">Mae''r data yn parhau i fod yn eiddo i ni, neu yn eiddo i''n cyflenwyr, fel y bo''r sefyllfa.</td></tr>
<tr>
  <td class="businesslinktablebold">2</td>
  <td colspan="2" class="businesslinktablebold">Trwydded i gysylltu � Transport Direct</td></tr>
<tr class="businesslinktable">
  <td>2.1</td>
  <td colspan="2">Cyn belled ag y b�ch yn derbyn yr amodau a''r telerau hyn yn llawn, rydym yn rhoi trwydded heb fod yn unigryw, y gellir ei diddymu, na ellir ei throsglwyddo i gysylltu �''n safle. </td></tr>
<tr>
  <td class="businesslinktablebold">3</td>
  <td colspan="2" class="businesslinktablebold">Eich Cyfrifoldebau </td></tr>
<tr class="businesslinktable">
  <td>3.1</td>
  <td colspan="2">Byddwch yn sicrhau: </td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.1</td>
  <td>bod eich safle yn cydymffurfio �''r holl ddeddfau, rheoliadau a deddfwriaeth gymwys;</td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td class="businesslinktable">3.1.2</td>
  <td>bod eich safle yn cynnal y safonau uchaf o ran chwaeth a gwedduster, nad yw''n cynnig cynhyrchion na gwasanaethau sy''n annog torri''r gyfraith nac yn tarfu ar iechyd neu ddiogelwch cyhoeddus ac nad yw''n amharchu nac yn dod ag enw drwg i gysyniadau cludiant cyhoeddus ac arfer gorau amgylcheddol; </td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.3</td>
  <td>nad ydych yn codi t�l ar unrhyw un sy''n gwneud defnydd o''r ddolen i''n safle; 
  </td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.4</td>
  <td>bod defnyddwyr eich safle yn defnyddio''r ddolen a''n safle i bwrpasau anfasnachol yn unig; </td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.5</td>
  <td>eich bod yn gwarchod ac nad ydych yn ymyrryd ar hawliau''r Ysgrifennydd Gwladol mewn perthynas ag enwau masnach, nodau masnach a logos Transport Direct ac nad ydych yn dosbarthu nac yn ail-ddefnyddio''r enwau, marciau a''r logos hynny heb ganiat�d ymlaen llaw; </td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.6</td>
  <td>nad ydych yn torri hawliau eiddo deallusol unrhyw unigolyn arall;</td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.7</td>
  <td>nad ydych yn trosglwyddo eich hawliau na''ch cyfrifoldebau i unrhyw un o dan y Telerau a''r Amodau hyn; </td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.8</td>
  <td>eich bod yn cynrychioli''r data, y meddalwedd ac enw da Transport Direct yn deg ac yn gyfreithiol;</td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.9</td>
  <td>nad ydych yn gwneud unrhyw beth nac yn cynnwys unrhyw beth ar eich safle sy''n awgrymu ein bod ni yn cefnogi, yn noddi nac yn cymeradwyo eich safle, a''ch bod yn cydnabod nad yw cynnwys y ddolen ar eich safle yn nodi cefnogaeth, nawdd na chymeradwyaeth o''ch safle gennym ni mewn unrhyw fodd; ac </td></tr>
<tr class="businesslinktable">
  <td>�</td>
  <td>3.1.10</td>
  <td>nad yw eich safle yn ddifr�ol o unrhyw unigolyn, busnes nac ymgymeriad. </td></tr>
<tr class="businesslinktable">
  <td>3.2</td>
  <td colspan="2">Rydych yn derbyn y gallwn gadw cofnodion o''ch dolennau a chadw cofnodion o''r fath ar gyfer archwiliad bob yn hyn a hyn ac i bwrpas olrhain.</td></tr>
<tr>
  <td class="businesslinktablebold">4</td>
  <td colspan="2" class="businesslinktablebold">Eich hawliau </td></tr>
<tr class="businesslinktable">
  <td>4.1</td>
  <td colspan="2">Gallwch ddileu''r ddolen o''ch safle unrhyw bryd.  I''n galluogi ni i gadw ein cofnodion yn gyfoes, a fyddech gystal �''n hysbysu drwy ebost yn  <a 
    href="mailto:transport_direct_pso@dft.gsi.gov.uk">transport_direct_pso@dft.gsi.gov.uk</a> 
    pe baech yn symud y ddolen o''ch safle. </td></tr>
<tr>
  <td class="businesslinktablebold">5</td>
  <td colspan="2" class="businesslinktablebold">Ein hawliau</td></tr>
<tr>
  <td>5.1</td>
  <td colspan="2">Rydym yn cadw''r hawl i ddirwyn i ben neu i ddiwygio eich hawl i gynnwys y ddolen ar eich safle unrhyw bryd drwy roi hysbysiad yn ysgrifenedig i chi yn y cyfeiriad ebost yr ydych wedi ei roi i ni.  Gallwn ddirymu/terfynu eich dolen i''n safle os: </td></tr>
<tr class="businesslinktable">
  <td>5.1.1</td>
  <td colspan="2">torrwch unrhyw ran o''r amodau a''r telerau hyn; neu 
  or</td></tr>
<tr class="businesslinktable">
  <td>5.1.2</td>
  <td colspan="2">unrhyw ddeddfwriaeth, gorchymyn neu reoliad, neu fod unrhyw fater arall yn ein hatal rhag rhoi neu barhau �''ch trwydded.</td></tr>
<tr class="businesslinktable">
  <td>5.2</td>
  <td colspan="2">Rydym yn cadw''r hawl i ddiwygio''r Amodau a''r Telerau hyn unrhyw bryd.  Byddwn yn postio Amodau a Thelerau wedi eu diweddaru ar ein safle.  Eich cyfrifoldeb chi yw adolygu''r Amodau a''r Telerau hyn yn rheolaidd fel eich bod yn ymwybodol o unrhyw ddiwygiadau.  Os parhewch i gynnwys dolen ar eich safle ar �l i newid i''r Amodau a''r Telerau hyn gael ei wneud, tybir eich bod wedi derbyn yr Amodau a''r Telerau diwygiedig.  Os nad ydych yn derbyn unrhyw Amodau a Thelerau diwygiedig, a fyddech gystal � dileu''r ddolen o''ch safle.</td></tr>
<tr class="businesslinktable">
  <td>5.3</td>
  <td colspan="2">Os ydym yn dirymu eich dolen i''n safle am unrhyw reswm, ni fydd gennych unrhyw hawliad yn ein herbyn a byddwch yn dileu o''ch gwefan bob cyfeiriad a dolen i''n safle. </td></tr>
<tr>
  <td class="businesslinktablebold">6</td>
  <td colspan="2" class="businesslinktablebold">Cyfrifoldebau</td></tr>
<tr class="businesslinktable">
  <td>6.1</td>
  <td colspan="2">Nid ydym yn gwneud unrhyw addewid nac unrhyw ddatganiad na sylw arall ynglyn � chywirdeb, ffitrwydd ar gyfer pwrpas, perfformiad, ansawdd boddhaol, na defnydd ein safle ac yr ydym yn allgau i''r graddau llawnaf y gellir eu caniat�u gan y ddeddf bob gwarant, rhwymedigaeth, amod neu delerau y gellir eu hawgrymu trwy ddeddf gyffredin, statud neu fel arall mewn perthynas �''r ddolen neu ein safle.  Felly eich cyfrifoldeb chi yw sicrhau bod Porth Transport Direct yn addas ar gyfer y defnydd a fwriedir. </td></tr>
<tr class="businesslinktable">
  <td>6.2</td>
  <td colspan="2">Ni fyddwn mewn unrhyw fodd yn gyfrifol i chi am unrhyw golledion (uniongyrchol, anuniongyrchol, arbennig neu ganlyniadol) a ddioddefir gennych chi o ganlyniad i gynnwys dolen ar eich safle. </td></tr>
<tr class="businesslinktable">
  <td>6.3</td>
  <td colspan="2">Nid ydym yn gyfrifol mewn unrhyw fodd am unrhyw broblem dechnegol neu fethiant o unrhyw fath sy''n ymwneud � gosod eich dolen chi ar ein safle.</td></tr></table>'



GO



-- login register printer friendly help page soft content
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpLoginRegister',
'<br/>   <blockquote style="MARGIN-RIGHT: 0px"> <h3>To log in:</h3><br/><br/>     <p>1. Type in the email address that you registered as your username<br/>     2. Type in your 

password<br/>     3. Click ''Next''<br/>     <br/>     If you have forgotten your password:<br/>     1. Type in the email 

address that you registered as your username<br/>     2. Click ''Forgotten Password''<br/>     <br/>     The password will be 

emailed to you.<br/>     <br/>     To change your Email address:<br/>     1. Type in your current email address and 

password<br/>     2. Click ''Change email address''<br/>     3. Type in and confirm the new email address. <br/>     <br/>     

your account will be changed to the new email address with your current password.     <br/>     <br/>     To delete your 

login account:<br/>     1. Type in your current email address and password<br/>     2. Click ''Delete account''<br/>     <br/>  

   Your account will be deleted from the system.   </p> </blockquote>
<br/>
<blockquote style="MARGIN-RIGHT: 0px"> <h3>To register:</h3><br/><p>1. Type in an email address (your username)<br/>2. Type in a password (passwords must be a minimum of 4 

characters and consist of letters or numbers, lower or upper case)<br/>3. Re-type the password<br/>4. Click ''Next'' 
<br/>
If the email address is recognised as a valid email address and the password is accepted, you will be asked to confirm 

the<br/>email address.<br/><br/>Click Confirm if it is the correct email address, and you will then be registered<br/>Click 

Cancel if it is not the correct email address, and you can start the process again</p> </blockquote>',
'<br/>    <blockquote dir="ltr" style="MARGIN-RIGHT: 0px"> <h3>I logio i mewn:</h3><br/><br/>    <p> 1. Teipiwch y cyfeiriad ebost y bu i chi ei gofrestru fel eich enw defnyddiwr<br/>     2. 

Teipiwch eich cyfrinair<br/>     3. Cliciwch ''Nesa''<br/>     <br/>     Os ydych wedi anghofio eich cyfrinair:<br/>     1. 

Teipiwch y cyfeiriad ebost y bu i chi ei gofrestru fel eich enw defnyddiwr<br/>     2. Cliciwch ar ''Wedi anghofio 

Cyfrinair''<br/>     <br/>     Bydd y cyfrinair yn cael ei ebostio atoch.     <br/>     <br/>     To change your Email 

address:<br/>     1. Type in your current email address and password<br/>     2. Click ''Change email address''<br/>     3. 

Type in and confirm the new email address. <br/>     <br/>     your account will be changed to the new email address with 

your current password.     <br/>     <br/>     To delete your login account:<br/>     1. Type in your current email address 

and password<br/>     2. Click ''Delete account''<br/>     <br/>     Your account will be deleted from the system.    
</p> </blockquote>
<br/>
<blockquote dir="ltr" style="MARGIN-RIGHT: 0px"> <h3>I gofrestru:</h3><br/><p>1. Teipiwch gyfeiriad ebost (eich enw defnyddiwr)<br/>2. Teipiwch gyfrinair (rhaid i gyfrineiriau fod yn 

isafswm o 4 symbol a bod yn llythrennau neu yn rhifau, prif lythrennau neu<br/>   lythrennau bach)<br/>3. Ail-deipiwch y 

cyfrinair<br/>4. Cliciwch ar ''Nesa''
<br/>
Os yw''r cyfeiriad ebost yn cael ei adnabod fel cyfeiriad ebost dilys a bod y cyfrinair yn cael ei dderbyn, gofynnir i 

chi<br/>gadarnhau''r cyfeiriad ebost.<br/><br/> � Cliciwch ar ''Cadarnhau'' os mai dyma"r cyfeiriad ebost cywir, ac yna byddwch 

yn cael eich cofrestru<br/>  � Cliciwch ar ''Dileu'' os mai nid dyma"r cyfeiriad ebost cywir, a gallwch ddechrau"r broses eto</p></blockquote>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpLoginRegister',
'<br/>   <blockquote style="MARGIN-RIGHT: 0px"> <h3>To log in:</h3><br/><br/>     <p>1. Type in the email address that you registered as your username<br/>     2. Type in your 

password<br/>     3. Click ''Next''<br/>     <br/>     If you have forgotten your password:<br/>     1. Type in the email 

address that you registered as your username<br/>     2. Click ''Forgotten Password''<br/>     <br/>     The password will be 

emailed to you.<br/>     <br/>     To change your Email address:<br/>     1. Type in your current email address and 

password<br/>     2. Click ''Change email address''<br/>     3. Type in and confirm the new email address. <br/>     <br/>     

your account will be changed to the new email address with your current password.     <br/>     <br/>     To delete your 

login account:<br/>     1. Type in your current email address and password<br/>     2. Click ''Delete account''<br/>     <br/>  

   Your account will be deleted from the system.   </p> </blockquote>
<br/>
<blockquote style="MARGIN-RIGHT: 0px"> <h3>To register:</h3><br/><p>1. Type in an email address (your username)<br/>2. Type in a password (passwords must be a minimum of 4 

characters and consist of letters or numbers, lower or upper case)<br/>3. Re-type the password<br/>4. Click ''Next'' 
<br/>
If the email address is recognised as a valid email address and the password is accepted, you will be asked to confirm 

the<br/>email address.<br/><br/>Click Confirm if it is the correct email address, and you will then be registered<br/>Click 

Cancel if it is not the correct email address, and you can start the process again</p> </blockquote>',
'<br/>    <blockquote dir="ltr" style="MARGIN-RIGHT: 0px"> <h3>I logio i mewn:</h3><br/><br/>    <p> 1. Teipiwch y cyfeiriad ebost y bu i chi ei gofrestru fel eich enw defnyddiwr<br/>     2. 

Teipiwch eich cyfrinair<br/>     3. Cliciwch ''Nesa''<br/>     <br/>     Os ydych wedi anghofio eich cyfrinair:<br/>     1. 

Teipiwch y cyfeiriad ebost y bu i chi ei gofrestru fel eich enw defnyddiwr<br/>     2. Cliciwch ar ''Wedi anghofio 

Cyfrinair''<br/>     <br/>     Bydd y cyfrinair yn cael ei ebostio atoch.     <br/>     <br/>     To change your Email 

address:<br/>     1. Type in your current email address and password<br/>     2. Click ''Change email address''<br/>     3. 

Type in and confirm the new email address. <br/>     <br/>     your account will be changed to the new email address with 

your current password.     <br/>     <br/>     To delete your login account:<br/>     1. Type in your current email address 

and password<br/>     2. Click ''Delete account''<br/>     <br/>     Your account will be deleted from the system.    
</p> </blockquote>
<br/>
<blockquote dir="ltr" style="MARGIN-RIGHT: 0px"> <h3>I gofrestru:</h3><br/><p>1. Teipiwch gyfeiriad ebost (eich enw defnyddiwr)<br/>2. Teipiwch gyfrinair (rhaid i gyfrineiriau fod yn 

isafswm o 4 symbol a bod yn llythrennau neu yn rhifau, prif lythrennau neu<br/>   lythrennau bach)<br/>3. Ail-deipiwch y 

cyfrinair<br/>4. Cliciwch ar ''Nesa''
<br/>
Os yw''r cyfeiriad ebost yn cael ei adnabod fel cyfeiriad ebost dilys a bod y cyfrinair yn cael ei dderbyn, gofynnir i 

chi<br/>gadarnhau''r cyfeiriad ebost.<br/><br/> � Cliciwch ar ''Cadarnhau'' os mai dyma"r cyfeiriad ebost cywir, ac yna byddwch 

yn cael eich cofrestru<br/>  � Cliciwch ar ''Dileu'' os mai nid dyma"r cyfeiriad ebost cywir, a gallwch ddechrau"r broses eto</p></blockquote>'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1222
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO