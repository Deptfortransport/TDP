-- *************************************************************************************
-- NAME 		: DUP1099_Update_UpdateTL_Homepage_Messages.sql
-- DESCRIPTION  	: Enhancements to traveline monitoring in line with fact that
--			  5 of the AIM regions are now a "super region"; and addition 
--			  of new "all regions down" message
-- AUTHOR		: Rich Broddle
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [PermanentPortal]
GO

-------------------------------------------------------------------------------------
-- Replace "SouthWest" message with generic MRMD message or update if already there
-------------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [PermanentPortal].[dbo].[HomePageMessage] WHERE [Description]='MRMD')
	BEGIN
	UPDATE [PermanentPortal].[dbo].[HomePageMessage]
	SET [valueEN]=
	'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br>  &bull;  West Midlands<br>  &bull;  Yorkshire<br>   &bull;  Wales<br>  &bull;  North West of England including Liverpool and Manchester<br> We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
	WHERE [Description]='MRMD'
	END
ELSE
	IF EXISTS (SELECT * FROM [PermanentPortal].[dbo].[HomePageMessage] WHERE [Description]='SouthWest')
		BEGIN
		UPDATE [PermanentPortal].[dbo].[HomePageMessage]
		SET [Description]='MRMD',
		[valueEN]=
		'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br>  &bull;  West Midlands<br>  &bull;  Yorkshire<br>   &bull;  Wales<br>  &bull;  North West of England including Liverpool and Manchester<br> We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
		WHERE [Description]='SouthWest'
		END
GO

UPDATE [PermanentPortal].[dbo].[HomePageMessage] SET [valueCY]=[valueEN] WHERE [Description] = 'MRMD'
GO

DELETE [PermanentPortal].[dbo].[HomePageMessage] WHERE [Description] IN ('SouthWest')
GO

-----------------------------------------------------------------------------------------------
-- Replace "WestMidlands" message with a generic all regions message or update if already there
-----------------------------------------------------------------------------------------------
IF EXISTS (SELECT * FROM [PermanentPortal].[dbo].[HomePageMessage] WHERE [Description]='AllRegion')
	BEGIN
	UPDATE [PermanentPortal].[dbo].[HomePageMessage]
	SET [valueEN]=
	'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are working to fix a problem affecting local public transport information in our Door to Door planner.  If you require train times, driving directions or domestic flight schedules, please use the appropriate �Find a�� planner</font></td></tr>'
	WHERE [Description]='AllRegion'
	END
ELSE
	IF EXISTS (SELECT * FROM [PermanentPortal].[dbo].[HomePageMessage] WHERE [Description]='WestMidlands')
		BEGIN
		UPDATE [PermanentPortal].[dbo].[HomePageMessage]
		SET [Description]='AllRegion',
		[valueEN]='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are working to fix a problem affecting local public transport information in our Door to Door planner.  If you require train times, driving directions or domestic flight schedules, please use the appropriate �Find a�� planner</font></td></tr>'
		WHERE [Description]='WestMidlands'
		END	
GO

UPDATE [PermanentPortal].[dbo].[HomePageMessage] SET [valueCY]=[valueEN] WHERE [Description]='AllRegion'
GO

DELETE [PermanentPortal].[dbo].[HomePageMessage] WHERE [Description] IN ('WestMidlands')
GO

----------------------------------------------------------------
-- Remove remaining MRMD region messages -  Y, W, NW
----------------------------------------------------------------
DELETE [PermanentPortal].[dbo].[HomePageMessage]
WHERE [Description] IN ('Yorkshire', 'Wales', 'NorthWest')
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1099
SET @ScriptDesc = 'Update_UpdateTL_Homepage_Messages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO


