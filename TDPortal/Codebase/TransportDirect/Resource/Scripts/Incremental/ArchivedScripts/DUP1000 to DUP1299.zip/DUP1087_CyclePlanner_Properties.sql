-- ***********************************************
-- NAME 		: DUP1087_CyclePlanner_Properties.sql
-- DESCRIPTION 		: Script to add Cycle Planner properties
-- AUTHOR		: Mitesh Modi
-- DATE			: 05 June 2008 18:00:00
-- ************************************************

USE [PermanentPortal]
GO

-- ***************************************************
-- The following amendments are required when running the script in SITest, BBP, ACP
-- 
-- 1. Amend the CyclePlanner.WebService.URL to the appropriate environment
-- 2. Amend the CyclePlanner.PlannerControl.PenaltyFunction.Location path (the atkins cycle planner dll location)
-- 3. Amend the CyclePlanner.GPXDownload.File.Path path (this is where gpx files are temporarily saved to before user can download)
-- 4. Amend the GradientProfiler.WebService.URL to the appropriate environment
-- ***************************************************


------------------------------------------------------
-- As this is the first script which sets up the Cycle properties, we can do a global delete

-- Delete all existing CyclePlanner properties
IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName LIKE 'CyclePlanner%')
BEGIN
	DELETE FROM properties WHERE pname LIKE 'CyclePlanner%'
END

-- Delete all existing GradientProfiler properties
IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName LIKE 'GradientProfiler%')
BEGIN
	DELETE FROM properties WHERE pname LIKE 'GradientProfiler%'
END
------------------------------------------------------


------------------------------------------------------
-- Cycle planner

INSERT INTO properties VALUES ('CyclePlanner.Available', 'true', 'Web', 'UserPortal', 0, 1) -- Switch to turn off cycle planning

INSERT INTO properties VALUES ('CyclePlanner.FindACycleAvailable', 'true', 'Web', 'UserPortal', 0, 1) -- Used to allow partners to turn off cycle planning

INSERT INTO properties VALUES ('CyclePlanner.WaitPageRefreshSeconds.FindACycle', '5', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.Planner.CyclingMaxSpeed.MetresPerHour', '28968', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.Planner.CyclingMinSpeed.MetresPerHour', '9656', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.Planner.CyclingDefaultSpeed.MetresPerHour', '19312', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.Planner.MaxJourneyDistance.Metres', '100000', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.Planner.PointValidation.Switch', 'false', 'Web', 'UserPortal', 0, 1) -- Switch to turn on/off point validation

INSERT INTO properties VALUES ('CyclePlanner.Planner.PointValidation.PlanSameAreaOnly', 'true', 'Web', 'UserPortal', 0, 1)


-- Cycle Planner web service
INSERT INTO properties VALUES ('CyclePlanner.WebService.URL', 'http://uk005744/cycleplannerservice/service.asmx', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.WebService.TimeoutMillisecs', '30000', 'Web', 'UserPortal', 0, 1)


-- Cycle Planner control and service properties
INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.MinUserTypeLogging', '1', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.LogAllRequests', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.LogAllResponses', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.LogNoJourneyResponses', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.LogCyclePlannerFailures', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.TimeoutMillisecs', '60000', 'Web', 'UserPortal', 0, 1)


-- Cycle Planner call properties
INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Location', 'C:\CyclePlanner\Services\RoadInterfaceHostingService\atk.cp.PenaltyFunctions.dll', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Prefix', 'AtkinsGlobal.JourneyPlanning.PenaltyFunctions', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.JourneyRequest.IncludeToids', 'false', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeToids', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeGeometry', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeText', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.PointSeperator', ' ', 'Web', 'UserPortal', 0, 1) -- value is a space

INSERT INTO properties VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.EastingNorthingSeperator', ',', 'Web', 'UserPortal', 0, 1) -- value is a comma


-- Cycle Planner journey display settings
INSERT INTO properties VALUES ('CyclePlanner.Display.AdditionalInstructionText', 'true ', 'Web', 'UserPortal', 0, 1)


-- Cycle Planner Map specific properties
INSERT INTO properties VALUES ('CyclePlanner.InteractiveMapping.Map.CycleScaleCutOff', '4000', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.InteractiveMapping.Map.CycleJourney.Xslt', '/Web2/Xslt/PolylinesTransform.xslt', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.InteractiveMapping.Map.ServiceName', 'tdp_cycle_prints', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.InteractiveMapping.Map.ServerName', 'SIGIS', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.InteractiveMapping.Map.NumberOfMapTilesTarget', '10', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.InteractiveMapping.Map.MapTilesDefaultScale', '8000', 'Web', 'UserPortal', 0, 1)


-- GPX file download *********** CHANGE THE PATH THIS POINTS TO ******************
INSERT INTO properties VALUES ('CyclePlanner.GPXDownload.File.Path', '/Web2/Downloads/', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('CyclePlanner.GPXDownload.File.Xslt', '/Web2/Xslt/GPXTransform.xslt', 'Web', 'UserPortal', 0, 1)

------------------------------------------------------




------------------------------------------------------
-- Gradient Profiler control and service properties
INSERT INTO properties VALUES ('GradientProfiler.Available', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.PlannerControl.MinUserTypeLogging', '1', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.PlannerControl.LogAllRequests', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.PlannerControl.LogAllResponses', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.PlannerControl.LogFailures', 'true', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.PlannerControl.TimeoutMillisecs', '30000', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.PlannerControl.Resolution.Metres', '100', 'Web', 'UserPortal', 0, 1)



-- Gradient Profiler web service
INSERT INTO properties VALUES ('GradientProfiler.WebService.URL', 'http://jp/gradientprofilerservice/service.asmx', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.WebService.TimeoutMillisecs', '30000', 'Web', 'UserPortal', 0, 1)


-- Gradient Profiler - chart properties
INSERT INTO properties VALUES ('GradientProfiler.Chart.ScaleValue.Metres.Max', '1500', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.Chart.ScaleValue.Metres.Min', '-100', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.Chart.ScaleValue.Metres.Max.Default', '400', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.Chart.ScaleValue.Metres.Min.Default', '0', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.Chart.ShowLegend', 'false', 'Web', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('GradientProfiler.Chart.Data.SeriesName', 'Gradient', 'Web', 'UserPortal', 0, 1)

------------------------------------------------------



GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1087
SET @ScriptDesc = 'Cycle planner properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO