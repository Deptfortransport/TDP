-- ***********************************************
-- NAME 		: DUP1114_LinkToFindNearest_contentDB_change.sql
-- DESCRIPTION 		: Script to change entries in the Content DB for CCN471
-- AUTHOR		: Phil Scott
-- DATE			: 07 Oct 2008 
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlannerOutput.CJPPartialReturnAmendFindNearest', '<br><br>Alternatively, your intended origin or destination may have limited or no public transport services. <A href="targetUrl">Click here</A> for the Find nearest link to identify the closest public transport stations and airport to construct a composite Drive and Ride journey.', '<br><br>Alternatively, your intended origin or destination may have limited or no public transport services. <A href="targetUrl">Click here</A> for the Find nearest link to identify the closest public transport stations and airport to construct a composite Drive and Ride journey.'
GO



----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1114
SET @ScriptDesc = 'Script to change entries in the Content DB for CCN471'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO