-- ***********************************************
-- NAME 		: DUP1064_HeaderButtons_Welsh_Content_Update.sql
-- DESCRIPTION 		: Script to amend Welsh Header Buttons
-- DESCRIPTION 		: Long Welsh text appears on 2 lines mainly for BBC partner site
-- AUTHOR		: Neil Rankin
-- DATE			: 17 July 2008 12:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE Content
Go

update dbo.tblContent set 
[Value-Cy] = 'Logio i Mewn /'+ CHAR(13) +'Cofrestru'
where PropertyName = 'HeaderControl.loginAndRegisterImageButton.AlternateText'

update dbo.tblContent set 
[Value-Cy] = 'Awgrymiadau a'+ CHAR(13) +'theclynnau'
where PropertyName = 'HeaderControl.tipsAndToolsImageButton.AlternateText'

update dbo.tblContent set 
[Value-Cy] = 'Allgofnodi /'+ CHAR(13) +'Diweddaru'
where PropertyName = 'HeaderControl.logoutAndUpdateImageButton.AlternateText'

update dbo.tblContent set 
[Value-Cy] = 'Cynlluniwch'+ CHAR(13) +'siwrnai'
where PropertyName = 'HeaderControl.planAJourneyImageButton.AlternateText'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1064
SET @ScriptDesc = 'Amend Welsh header buttons so long Welsh text appears on 2 lines'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO