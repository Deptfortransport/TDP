-- ************************************************************
-- NAME 		: DUP1174_TransportDirect_Content_9_NetworkMaps.sql
-- DESCRIPTION 	: Updates content to the Networks Map page
-- AUTHOR		: mmodi 
-- ************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Content]
GO

DECLARE @MaxGroupId INT

SELECT @MaxGroupId = MAX(GroupId)+1 FROM tblGroup

IF NOT EXISTS(Select * from tblGroup WHERE [Name] = 'mapsdefault')
	INSERT INTO [dbo].[tblGroup] ([GroupId], [Name])
			VALUES (@MaxGroupId, 'mapsdefault')
GO


DECLARE @GroupId INT
SELECT @GroupId = GroupId FROM tblGroup WHERE [Name] = 'mapsdefault'


EXEC AddtblContent
1, @GroupId,'Body Text','/Channels/TransportDirect/Maps/NetworkMaps'
,'
<div id="primcontent">  <div id="contentarea">  <div class="hdtypetwo">
    <h2><a id="Rail" name="Rail">Rail</a></h2></div>  <p><a title="Open a new window displaying the Scotland Rail Website" href="http://www.firstgroup.com/scotrail/content/travelinfo/mapsandroutes.php" target="_blank" name="Rail">First ScotRail</a></p>  <p><a title="Open a new window displaying the National Rail website" href="http://www.nationalrail.co.uk/tocs_maps/maps/network_rail_maps.htm" target="_blank">National&nbsp;Rail</a>&nbsp;</p>  <p><a title="Open a new window displaying the maps of rail stations with access for people with reduced mobililty on the National Rail website" href="http://www.nationalrail.co.uk/tocs_maps/maps/accessibility_maps.htm" target="_blank">Maps of rail stations with access for people with reduced mobility</a>&nbsp;</p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Return to top ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Coach" name="Coach">Coach</a></h2></div>  <p><a title="Open a new window displaying the Cooks website" href="http://www.cookscoaches.f9.co.uk/map.htm" target="_blank">Cooks Coaches</a></p>  <p><a title="Open a new window displaying the Megabus website" href="http://www.megabus.co.uk/uk/stops/" target="_blank">Megabus</a></p>  <p><a title="Open a new window displaying the Scottish City Link website" href="http://www.citylink.co.uk/routes.html" target="_blank">Scottish Citylink</a> </p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Return to top ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="UndergroundMetro" name="UndergroundMetro">Underground/Metro</a></h2></div>  <p><a title="Open a new window displaying the Transport for London website (Croydon Tramlink)" href="http://www.tfl.gov.uk/gettingaround/1110.aspx" target="_blank">Croydon Tramlink</a></p>  <p><a title="Open a new window displaying the Transport for London website (Docklands Light Railway)" href="http://www.tfl.gov.uk/gettingaround/1108.aspx" target="_blank">Docklands Light Railway</a></p>  <p><a title="Open a new window displaying the Glasgow Underground website" href="http://www.spt.co.uk/subway/images/route_map.jpg" target="_blank">Glasgow Underground</a></p>  <p><a title="Open a new window displaying the London Underground website" href="http://www.tfl.gov.uk/gettingaround/1108.aspx" target="_blank">London Underground</a> </p>  <p><a title="Open a new window displaying the Manchester Metrolink website (Route Map)" href="http://www.metrolink.co.uk/pdf/route_map.pdf" target="_blank">Manchester Metrolink</a></p>  <p><a title="Open a new window displaying the Nottingham Express Transit website" href="http://www.thetram.net/maps/route.asp" target="_blank">Nottingham Express Transit</a></p>  <p><a title="Open a new window displaying the Sheffield Supertram website (Route Map)" href="http://www.supertram.net/uploads/RouteMap.pdf" target="_blank">Sheffield Supertram</a></p>  <p><a title="Open a new window displaying the Tyne &amp; Wear Metro website" href="http://www.nexus.org.uk/wps/wcm/connect/Nexus/Metro?srv=cmpnt&amp;source=library&amp;cmpntname=IMG%20-%20MetroMap%20(Large)" target="_blank">Tyne &amp; Wear Metro</a></p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Return to top ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Bus" name="Bus">Bus</a></h2></div>  <p><a title="Open a new window displaying the Angus Council website" href="http://www.angus.gov.uk/transport/maps/AngusMapGuide2007.pdf" target="_blank">Angus Council</a></p>  <p><a title="Open a new window displaying the Cambridgeshire website" href="http://www.cambridgeshire.gov.uk/transport/bus_timetables/county_bus_maps.htm" target="_blank">Cambridgeshire</a></p>  <p><a title="Open a new window displaying the Dorset Poole and Bournmouth website" href="http://www.yellowbuses.co.uk/maps/default.asp" target="_blank">Dorset, Poole and Bournemouth</a></p>  <p><a title="Open a new window displaying the London Bus website" href="http://www.tfl.gov.uk/gettingaround/1110.aspx" target="_blank">London Bus</a>&nbsp; </p>  <p><a title="Open a new window displaying the (Greater) Manchester PTE website" href="http://www.gmpte.com/content.cfm?subcategory_id=1248780" target="_blank">(Greater) Manchester PTE</a></p>  <p><a title="Open a new window displaying the Stagecoach Devon website" href="http://www.devon.gov.uk/index/transport/public_transport/buses/bus_maps.htm" target="_blank">Stagecoach Devon</a></p>  <p><a title="Open a new window displaying the Trent Barton website" href="http://www.trentbuses.co.uk/timetables/mapindex.html" target="_blank">Trent Barton</a></p>  <p><a title="Open a new window displaying the West Yorkshire Metro website" href="http://www.wymetro.com/BusTravel/MapsAndGuides.htm" target="_blank">West Yorkshire Metro</a></p>  <p><a title="Open a new window displaying the Wilts and Dorset website" href="http://www.wdbus.co.uk/htm/maps/index.asp" target="_blank">Wilts and Dorset</a></p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Return to top ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Ferries" name="Ferries">Ferries and River Services</a></h2></div>  <p><a title="Open a new window displaying the Transport for London website (London River Services)" href="http://www.tfl.gov.uk/gettingaround/1114.aspx" target="_blank">London River Services</a>&nbsp; </p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Return to top ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Cycling" name="Cycling">Cycling</a></h2></div>  <p><a title="Open a new window displaying the Transport for London website (London Underground Bicycle Map)" href="http://www.tfl.gov.uk/assets/downloads/bicycle-tube-map-0108.pdf" target="_blank">London Underground Bicycle Map</a>&nbsp; </p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Return to top ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="AllPublicTransport" name="AllPublicTransport">All Public Transport</a></h2></div>  <p><a title="Open a new window displaying the Bath and area website" href="http://www.bathnes.gov.uk/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/BusmapBathNorthEastSomersetNetwork.pdf" target="_blank">Bath &amp; North East Somerset</a></p>  <p><a title="Open a new window displaying the Blackpool website" href="http://www.blackpooltransport.com/" target="_blank">Blackpool</a></p>  <p><a title="Open a new window displaying the Hampshire website" href="http://www3.hants.gov.uk/environment-passengertransport-publictransportmap.htm" target="_blank">Hampshire</a></p>  <p>&nbsp;</p></div></div>'
,
'
<div id="primcontent">  <div id="contentarea">  <div class="hdtypetwo">
    <h2><a id="Rail" name="Rail">Rheilffordd</h2></a></div>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Scotland Rail" href="http://www.firstgroup.com/scotrail/content/travelinfo/mapsandroutes.php" target="_blank">First ScotRail</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan National Rail" href="http://www.nationalrail.co.uk/tocs_maps/maps/network_rail_maps.htm" target="_blank">National&nbsp;Rail</a>&nbsp;</p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan maps of rail stations with access for people with reduced mobililty on the National Rail" href="http://www.nationalrail.co.uk/tocs_maps/maps/accessibility_maps.htm" target="_blank">Maps of rail stations with access for people with reduced mobility</a>&nbsp;</p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Yn &#244;l i&#8217;r brig ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Coach" name="Coach">Coets</h2></a></div>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Cooks" href="http://www.cookscoaches.f9.co.uk/map.htm" target="_blank">Cooks Coaches</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Megabus" href="http://www.megabus.co.uk/uk/stops" target="_blank">Megabus</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Scottish City Link" href="http://www.citylink.co.uk/routes.html" target="_blank">Scottish Citylink</a> </p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Yn &#244;l i&#8217;r brig ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="UndergroundMetro" name="UndergroundMetro">Rheilffordd danddaearol/Metro</a></h2></div>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Transport for London website (Croydon Tramlink)" href="http://www.tfl.gov.uk/gettingaround/1110.aspx" target="_blank">Croydon Tramlink</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Transport for London website (Docklands Light Railway)" href="http://www.tfl.gov.uk/gettingaround/1108.aspx" target="_blank">Docklands Light Railway</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Glasgow Underground" href="http://www.spt.co.uk/subway/images/route_map.jpg" target="_blank">Glasgow Underground</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan London Underground" href="http://www.tfl.gov.uk/gettingaround/1108.aspx" target="_blank">London Underground</a> </p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Manchester Metrolink website (Route Map)" href="http://www.metrolink.co.uk/pdf/route_map.pdf" target="_blank">Manchester Metrolink</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Nottingham Express Transit" href="http://www.thetram.net/maps/route.asp" target="_blank">Nottingham Express Transit</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Sheffield Supertram website (Route Map)" href="http://www.supertram.net/uploads/RouteMap.pdf" target="_blank">Sheffield Supertram</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Tyne &amp; Wear Metro" href="http://www.nexus.org.uk/wps/wcm/connect/Nexus/Metro?srv=cmpnt&amp;source=library&amp;cmpntname=IMG%20-%20MetroMap%20(Large)" target="_blank">Tyne &amp; Wear Metro</a></p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Yn &#244;l i&#8217;r brig ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Bus" name="Bus">Bws</a></h2></div>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Angus Council" href="http://www.angus.gov.uk/transport/maps/AngusMapGuide2007.pdf" target="_blank">Angus Council</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Cambridgeshire" href="http://www.cambridgeshire.gov.uk/transport/bus_timetables/county_bus_maps.htm" target="_blank">Cambridgeshire</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Dorset Poole and Bournmouth" href="http://www.yellowbuses.co.uk/maps/default.asp" target="_blank">Dorset, Poole and Bournemouth</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan London Bus" href="http://www.tfl.gov.uk/gettingaround/1110.aspx" target="_blank">London Bus</a>&nbsp; </p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan (Greater) Manchester PTE" href="http://www.gmpte.com/content.cfm?subcategory_id=1248780" target="_blank">(Greater) Manchester PTE</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Stagecoach Devon" href="http://www.devon.gov.uk/index/public_transport/buses/bus_maps.htm" target="_blank">Stagecoach Devon</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Trent Barton" href="http://www.trentbuses.co.uk/timetables/mapindex.html" target="_blank">Trent Barton</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan West Yorkshire Metro" href="http://www.wymetro.com/bustravel/mapsandguides.htm" target="_blank">West Yorkshire Metro</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Wilts and Dorset" href="http://www.wdbus.co.uk/htm/maps/index.asp" target="_blank">Wilts and Dorset</a></p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Yn &#244;l i&#8217;r brig ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Ferries" name="Ferries">Ffer�au a Gwasanaethau Afon</a></h2></div>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Transport for London website (London River Services)" href="http://www.tfl.gov.uk/gettingaround/1114.aspx" target="_blank">London River Services</a>&nbsp; </p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Yn &#244;l i&#8217;r brig ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="Cycling" name="Cycling">Beicio</a></h2></div>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Transport for London (London Underground Bicycle Map)" href="http://www.tfl.gov.uk/assets/downloads/tube-map-bicycles1c.pdf" target="_blank">London Underground Bicycle Map</a>&nbsp; </p>  <div align="right"><a class="jpt" href="/Web2/Maps/NetworkMaps.aspx#logoTop">Yn &#244;l i&#8217;r brig ^</a></div>  
<div class="hdtypetwo">
    <h2><a id="AllPublicTransport" name="AllPublicTransport">All Public Transport</a></h2></div>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Bath and area" href="http://www.bathnes.gov.uk/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/BusmapBathNorthEastSomersetNetwork.pdf" target="_blank">Bath &amp; North East Somerset</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Blackpool" href="http://www.blackpooltransport.com/" target="_blank">Blackpool</a></p>  <p><a title="Agorwch ffenestr newydd yn arddangos gwefan Hampshire" href="http://www3.hants.gov.uk/environment-passengertransport-publictransportmap.htm" target="_blank">Hampshire</a></p>  <p>&nbsp;</p></div></div>'


EXEC AddtblContent
1, @GroupId,'Title Text','/Channels/TransportDirect/Maps/NetworkMaps',
'<div>
    <h1>
        Network maps
    </h1>
</div>'
,
'<div>
     <h1>
        Mapiau rhwydwaith
     </h1>
</div>'

GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1174
SET @ScriptDesc = 'Updated content to the Networks Map page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------