-- ***********************************************
-- NAME 		: DUP1161_CycleGPXDownload_Properties.sql
-- DESCRIPTION 		: Script to add properties required for the GPX download of cycle journeys
-- AUTHOR		: Mark Turner
-- DATE			: 31 Oct 2008
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.GPXDownload.Download.Path' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.GPXDownload.Download.Path', 'http:\\localhost\Web2\Downloads\', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http:\\localhost\Web2\Downloads\'
	where pname = 'CyclePlanner.GPXDownload.Download.Path' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.GPXDownload.File.Path' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.GPXDownload.File.Path', 'C:\Inetpub\wwwroot\Web2\Downloads\', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'C:\Inetpub\wwwroot\Web2\Downloads\'
	where pname = 'CyclePlanner.GPXDownload.File.Path' AND aid = 'Web' AND gid = 'UserPortal'
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1161
SET @ScriptDesc = 'Script to add properties required for the GPX download of cycle journeys'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO