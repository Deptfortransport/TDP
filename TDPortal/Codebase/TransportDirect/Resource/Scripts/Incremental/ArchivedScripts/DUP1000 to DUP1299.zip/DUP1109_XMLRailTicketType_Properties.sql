-- ***********************************************
-- NAME 		: DUP1109_XMLRailTicketType_Properties.sql
-- DESCRIPTION 		: Script to add properties required for XML Rail Ticket Type feed
-- AUTHOR		: Mitesh Modi
-- DATE			: 19 Sep 2008
-- ************************************************

USE [PermanentPortal]
GO

DECLARE @aid as varchar(20)
DECLARE @gid as varchar(20)

SET @aid = 'TicketTypeFeed'
SET @gid = 'TicketTypeFeed'

-- Delete all existing properties for this AID and GID
IF EXISTS (SELECT TOP 1 * FROM properties WHERE aid = @aid AND gid = @gid)
BEGIN
	DELETE FROM properties WHERE aid = @aid AND gid = @gid
END

-- TIDY UP Delete existing xmlfeed location
IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'XMLFeedSource')
BEGIN
	DELETE FROM properties WHERE pName = 'XMLFeedSource'
END



-- Ticket feed 
INSERT INTO properties VALUES ('TicketTypeFeed.FeedName', 'yfk550', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('TicketTypeFeed.XMLFeedSource', 'C:\TDPortal\Codebase\TransportDirect\XMLRailTicketTypeFeed\TransportDirectXmlTicketFeed\bin\Debug\TicketTypeDescriptions.xml', @aid, @gid, 0, 1)


-- Ticket feed properties needed for logging
INSERT INTO properties VALUES ('Logging.Publisher.Queue', '', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.Email', '', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.File', 'File1', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.EventLog', '', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.Custom', '', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.Console', '', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.Default', 'File1', @aid, @gid, 0, 1)

INSERT INTO properties VALUES ('Logging.Publisher.File.File1.Directory', 'C:\TDPortal', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.File.File1.Rotation', '1000', @aid, @gid, 0, 1)

INSERT INTO properties VALUES ('Logging.Event.Operational.TraceLevel', 'Verbose', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Custom.Trace', 'On', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Operational.Verbose.Publishers', 'File1', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Operational.Info.Publishers', 'File1', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Operational.Error.Publishers', 'File1', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Operational.Warning.Publishers', 'File1', @aid, @gid, 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Custom', '', @aid, @gid, 0, 1)

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1109
SET @ScriptDesc = 'Properties required for XML Rail Ticket Type feed'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO