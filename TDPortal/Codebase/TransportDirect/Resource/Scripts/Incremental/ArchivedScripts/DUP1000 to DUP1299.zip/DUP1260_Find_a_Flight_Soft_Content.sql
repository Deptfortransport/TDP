-- ***********************************************
-- NAME 		: DUP1260_Find_a_Flight_Soft_Content.sql
-- DESCRIPTION 		: Script to update Find a Train input page soft content
-- AUTHOR		: John Frank
-- DATE			: 28 Jan 2009
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'FindFlightInput.labelFromToTitle',
'Select two regions or airports to find a range of journey plans.<br/>
<span class="bold">Please note:</span> Only airports providing domestic flights within Great Britain are available in the <span class="italic">Find a Flight</span> journey planner.',
'Dewiswch ddau ranbarth neu feysydd awyr i ganfod amrediad o gynlluniau siwrnai.<br/>
<span class="bold">Please note:</span> Only airports providing domestic flights within Great Britain are available in the <span class="italic">Find a Flight</span> journey planner.'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1260
SET @ScriptDesc = 'Find A Train Input Page Soft Content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO