-- ***********************************************
-- NAME 		: DUP1088_CyclePlanner_Content.sql
-- DESCRIPTION 		: Script to add Cycle planner content
-- AUTHOR		: Mitesh Modi
-- DATE			: 05 Jun 2008 18:00:00
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Home page and Cycle input page
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelFindPageTitle.Text', 'Find a cycle route', 'cy Find a cycle route'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelFromToTitle', 'Enter two locations to find cycle directions', 'cy Enter two locations to find cycle directions'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.AppendPageTitle', 'Find a cycle route | ', 'cy Find a cycle route | '

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CommandBack.Text', 'Back', 'Yn'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.imageFindCycle.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleJourney.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleJourney.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.imageFindCycle.AlternateText', 'Cycle route', 'cy Cycle route'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblCycle', 'Find a <br />cycle route', 'cy Find a <br />cycle route'

EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.lblFindCycle', 'Find a cycle <br />route', 'cy Find a cycle <br />route'

EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.imageFindCycleSkipLink.AlternateText', 'Skip to Find a cycle route', 'cy Skip to Find a cycle route'

EXEC AddtblContent
1, 1, 'langStrings', 'WaitPageMessage.FindACycle', 'Thank you for waiting while Transport Direct calculates your cycle route.', 'cy Thank you for waiting while Transport Direct calculates your cycle route.'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCycleInput.clientLink.BookmarkTitle', 'Transport Direct Find a Cycle route', 'cy Transport Direct Find a Cycle route'

--------------------------------------------------------------------------------------------------------------------------------
-- Gazzatteer options
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindCycleLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'


EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleViaLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'


--------------------------------------------------------------------------------------------------------------------------------
-- Preferences control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelCycleJourneyOptions', 'Cycle route options', 'cy Cycle route options'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelSpeedMax', 'Speed (max)', 'cy Speed (max)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelIPrefer', 'I prefer, where possible, to <b> avoid:</b>', 'cy I prefer, where possible, to <b> avoid:</b>'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelTravelVia', 'I want to travel via', 'cy I want to travel via'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidSteepClimbs', 'Steep climbs', 'cy Steep climbs'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidUnlitRoads', 'Unlit roads', 'cy Unlit roads'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidWalkingYourBike', 'Walking your bike', 'cy Walking your bike'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.checkboxAvoidTimeBased', 'Time based restrictions', 'cy Time based restrictions'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.SpeedError', 
'The speed entered must be a number greater than {0} and less than {1}. Please enter a new value.', 
'cy The speed entered must be a number greater than {0} and less than {1}. Please enter a new value.'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelPenaltyFunctionOverride', 'Penalty Function override', 'cy Penalty Function override'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelPenaltyFunctionOverrideHelp', '', ''

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCyclePreferencesControl.labelPenaltyFunctionOverrideCall', '', ''

--------------------------------------------------------------------------------------------------------------------------------
-- Journey type control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCycleJourneyTypeControl.labelTypeOfJourney', 'Type of journey', 'cy Type of journey'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCycleJourneyTypeControl.labelFind', 'Find', 'cy Find'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.FindCycleJourneyTypeControl.labelJourneys', 'journey(s)', 'cy journey(s)'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleJourneyType.Quickest', 'Quickest', 'cy Quickest'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleJourneyType.Easiest', 'Easiest to navigate', 'cy Easiest to navigate'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleJourneyType.Safest', 'Safest / quietest', 'cy Safest / quietest'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.CycleJourneyType.Recreational', 'Recreational / greenest', 'cy Recreational / greenest'

--------------------------------------------------------------------------------------------------------------------------------
-- Units speed dropdown
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UnitsSpeedDrop.mph', 'mph', 'mph'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UnitsSpeedDrop.kph', 'kph', 'kph'

--------------------------------------------------------------------------------------------------------------------------------
-- Validation
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.CyclePlannerUnavailableKey', 'Find a cycle journey is currently unavailable.', 
'cy Find a cycle journey is currently unavailable.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.CycleSpeedErrorKey', 'The cycle speed must be a number greater than zero. Please enter a new value.', 
'cy The cycle speed must be a number greater than zero. Please enter a new value.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationHasNoPoint', 
'Cycle planning is not available within the area you have selected. Please choose a different start location and/or destination.', 
'cy Cycle planning is not available within the area you have selected. Please choose a different start location and/or destination.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.DistanceBetweenLocationsTooGreat', 
'Transport Direct will only plan a cycle journey which has a maximum distance between the origin and destination of {0}km; the journey you requested was further than this.', 
'cy Transport Direct will only plan a cycle journey which has a maximum distance between the origin and destination of {0}km; the journey you requested was further than this.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.DistanceBetweenLocationsAndViaTooGreat', 
'Transport Direct will only plan a cycle journey which has a maximum distance between the origin, via and destination of {0}km; the journey you requested was further than this.',
'cy Transport Direct will only plan a cycle journey which has a maximum distance between the origin, via and destination of {0}km; the journey you requested was further than this.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationInInvalidCycleArea', 
'At the moment we are able to plan cycle journeys in Manchester and Merseyside.  Please click the ''clear page'' button below to enter new journey details.  To find out more please <a href="/Web2/Help/NewHelp.aspx">go to the FAQ on cycle data areas</a>.', 
'cy At the moment we are able to plan cycle journeys in Manchester and Merseyside.  Please click the ''clear page'' button below to enter new journey details.  To find out more please <a href="/Web2/Help/NewHelp.aspx">go to the FAQ on cycle data areas</a>.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationPointsNotInSameCycleArea', 
'To plan a cycle journey on Transport Direct the journey origin, destination and via points must all be in the same area. The journey you requested contained points that were in different areas with no direct connection between them. To find out more please <a href="/Web2/Help/NewHelp.aspx">go to the FAQ on cycle data areas</a>.',
'cy To plan a cycle journey on Transport Direct the journey origin, destination and via points must all be in the same area. The journey you requested contained points that were in different areas with no direct connection between them. To find out more please <a href="/Web2/Help/NewHelp.aspx">go to the FAQ on cycle data areas</a>.'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle Planner service
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPInternalError', 
'Sorry we are currently unable to obtain a cycle journey using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain a cycle journey using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPPartialReturn', 
'Sorry we are currently unable to obtain cycle journeys using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain cycle journeys using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPNoResults', 
'Sorry we are currently unable to obtain journeys using the details you have entered. Please try changing the dates/times of travel or changing some of the details entered. Click ''Amend'' to revise your journey request.<br> <br> If you still encounter problems please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain journeys using the details you have entered. Please try changing the dates/times of travel or changing some of the details entered. Click ''Amend'' to revise your journey request.<br> <br> If you still encounter problems please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.Results.CPExternalMessage', 
'Message returned by Cycle Planner.',
'Message returned by Cycle Planner.'

EXEC AddtblContent
1, 1, 'langStrings', 'GradientProfiler.Results.GPInternalError', 
'Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain  the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

EXEC AddtblContent
1, 1, 'langStrings', 'GradientProfiler.Results.GPPartialReturn', 
'Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

EXEC AddtblContent
1, 1, 'langStrings', 'GradientProfiler.Results.GPNoResults', 
'Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 
'cy Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle Journey Results page
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.JourneyDetails.AppendPageTitle', 'Cycle Route Details | ', 'cy Cycle Route Details | '

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelCycleAllDetailsControlTitle.Text.OutwardJourney', 'Details: Outward journey', 'Manylion: Siwrnai allanol'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelCycleAllDetailsControlTitle.Text.ReturnJourney', 'Details: Return journey', 'Manylion: Siwrnai ddychwel'


--------------------------------------------------------------------------------------------------------------------------------
-- Controls - All details holder
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.imageCycleEngland.URL', '/Web2/App_Themes/TransportDirect/images/gifs/softcontent/logo_cyclingengland_small.gif', '/Web2/App_Themes/TransportDirect/images/gifs/softcontent/logo_cyclingengland_small.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.imageCycleEngland.AltText', 'Cycling England logo', 'cy Cycling England logo'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.hyperlinkCycleEngland.Text', 
'To find Cycling England Bikeability training near you select this link (opens new window)',
'cy To find Cycling England Bikeability training near you select this link (opens new window)'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - GPX
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelTitle.Text', 'GPS Tracking', 'cy GPS Tracking'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelDownloadDescription.Text', 
'Click on the link below to save a GPX file of your route for use on a GPS device', 
'cy Click on the link below to save a GPX file of your route for use on a GPS device'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.hyperlinkDownload.Text', 
'Download a GPX file of your route (opens new window)', 
'cy Download a GPX file of your route (opens new window)'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelError.Text', 
'There was a problem generating the GPX file for your journey. Please close your browser and try again or contact us if the problem continues to occur.', 
'cy There was a problem generating the GPX file for your journey. Please close your browser and try again or contact us if the problem continues to occur.'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Graph
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTitle.Text', 'Gradient Profile', 'cy Gradient Portal'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelWait.Text', 'Please wait while the gradient profile of the journey is loaded', 'cy Please wait while the gradient profile of the journey is loaded'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.imageWait.AltText', 'Please wait', 'cy Please wait'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.imageWait.URL', '/Web2/App_Themes/TransportDirect/images/gifs/journeyPlanning/WaitIndicator.gif', '/Web2/App_Themes/TransportDirect/images/gifs/journeyPlanning/WaitIndicator.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelDistanceInMiles.Text', 'Distance in miles', 'cy Distance in miles'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelDistanceInKms.Text', 'Distance in km', 'cy Distance in kms'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelHighestPoint.Text', 'Highest point', 'cy Highest point'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelLowestPoint.Text', 'Lowest point', 'cy Lowest point'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTotalClimb.Text', 'Total climb', 'cy Total climb'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTotalDescent.Text', 'Total descent', 'cy Total descent'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelNoScript.Text', 
'Please enable javascript to view the gradient profile', 
'cy Please enable javascript to view the gradient profile'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelError.Text', 
'We are currently unable to generate a gradient profile for this journey',
'cy We are currently unable to generate a gradient profile for this journey'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.buttonShowTable.Text', 'Show table view', 'cy Show table view'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.buttonShowGraph.Text', 'Show graph view', 'cy Show graph view'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTableHeaderDistanceInMiles.Text', 'Distance in miles', 'cy Distance in miles'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTableHeaderDistanceInKms.Text', 'Distance in kms', 'cy Distance in kms'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGraphControl.labelTableHeaderHeight.Text', 'Height in metres', 'cy Height in metres'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Summary
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelSummaryOfDirections.Text', 'Summary of directions', 'cy Summary of directions'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelTotalDistance.Text', 'Total distance', 'cy Total distance'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelTotalDuration.Text', 'Total duration', 'cy Total duration'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelDistanceUnits.Text', 'Distance units', 'cy Distance units'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.Avoid', 'Avoid', 'cy Avoid'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.AndLowerCase', 'and', 'a'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.Journey', 'journey', 'cy journey'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyOptions.Speed', 'Average cycling speed is', 'cy Average cycling speed is'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleSummaryControl.labelJourneyAdvancedOptions.PenaltyFunction', 'Penalty function used:', 'cy Penalty function used:'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Details table
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.labelCycleJourneyDetailsTableControlTitle.Text', 
'Directions', 'cy Directions'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerAccumulatedDistance.Miles', 'Trip miles', 'cy Trip miles'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerAccumulatedDistance.Kms', 'Trip kms', 'cy Trip kms'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerDirections', 'Directions', 'cy Directions'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.headerArrivalTime', 'Time', 'cy Time'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.buttonShowMore', 'Show more', 'cy Show more'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.buttonShowLess', 'Show less', 'cy Show less'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CyclePathImage', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CyclePath.gif', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CyclePath.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CyclePathImage.AltText', 'Journey follows cycle specific infrastructure', 'cy Journey follows cycle specific infrastructure'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CycleRouteImage', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleRoute.gif', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleRoute.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.CycleRouteImage.AltText', 'Journey follows recommended cycle route', 'cy Journey follows recommended cycle route'

        -- correct the road exclamation image 
EXEC AddtblContent
1, 1, 'langStrings', 'CarCostingDetails.highTrafficSymbol', 
'<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif" align="middle" alt="Road exclamation sign" />',
'<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif" align="middle" alt="Road exclamation sign" />'

--------------------------------------------------------------------------------------------------------------------------------
-- CO2 emissions control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDistanceInputControl.ImageCycle.URL', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CompareCO2_Cycle.gif', 
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/CompareCO2_Cycle.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsDistanceInputControl.ImageCycle.AlternateText', 
'Cycle icon with emissions', 
'cy Cycle icon with emissions'

--------------------------------------------------------------------------------------------------------------------------------
-- Maps
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.Cycle', 
'StartLocation,EndLocation,Tollbooth,FerryIcon',
'StartLocation,EndLocation,Tollbooth,FerryIcon'

--------------------------------------------------------------------------------------------------------------------------------
-- Controls - Printable map
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageHeaderTitle.DirectionsForJourney.Text', 'Directions', 'cy Directions'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageHeaderTitle.MapOfEntireJourney.Text', 'Map of entire journey', 'cy Map of entire journey'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageItemTitle.Directions.Text', 'Detailed Directions: Page {0}', 'cy Detailed Directions: Page {0}'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.PrintableMapTileControl.labelMapPageItemTitle.Maps.Text', 'Detailed Maps: Page {0}', 'cy Detailed Maps: Page {0}'

--------------------------------------------------------------------------------------------------------------------------------
-- Feedback page
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'PlanAJourneyControl.checkboxCycle.Text', 'Cycle', 'cy Cycle'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackSearchType.Find a cycle journey', 'Find a cycle route', 'cy Find a cycle route'

EXEC AddtblContent
1, 1, 'langStrings', 'FeedbackViewer.VantiveId.Text', 'Support Ref', 'Support Ref'


GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle page Group 
--------------------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM tblGroup WHERE [Name] like 'journeyplanning_findcycleinput') 
	INSERT INTO tblGroup (GroupId, [Name])
	SELECT MAX(GroupId)+1, 'journeyplanning_findcycleinput' FROM tblGroup

DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findcycleinput')

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Information below input panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput', 
'<div class="PageSoftContentContainer">  <div class="PageSoftContent">
<p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p>
<ul>
<li>Amend the maximum speed at which you would like to travel</li>
<li>Choose to avoid unlit roads, walking with your bike, or steep climbs</li>
<li>Select a location you would like your journey to go via</li>
</ul><br/></div></div>'
,
'<div class="PageSoftContentContainer">  <div class="PageSoftContent">
<p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p>
<ul>
<li>Amend the maximum speed at which you would like to travel</li>
<li>Choose to avoid unlit roads, walking with your bike, or steep climbs</li>
<li>Select a location you would like your journey to go via</li>
</ul><br/></div></div>'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Latest news information - placeholder required to enable page to populate latest news
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput', 
'<h1>Latest... NOT POPULATED</h1>',
'<h1>Latest... NOT POPULATED</h1>'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Right hand information panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput',
'<div class="Column3Header"><div class="txtsevenbbl">
Cycle data areas:</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
Transport Direct has worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure 
that there is good quality information on cycling in the following areas:
<ul>
<li> Greater Manchester</li>
<li> Merseyside</li>
</ul>
<br />
Work is ongoing to provide cycle planning information in more areas - please check again soon 
if your local area is not yet available. Our aim is to provide national coverage for cycling over the coming 
months. <a href="/Web2/Help/NewHelp.aspx">For more information on the areas of good quality cycling information 
please follow this link to our FAQs.</a>
</td></tr>
</tbody></table></div>'
,
'<div class="Column3Header"><div class="txtsevenbbl">
Cycle data areas:</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
Transport Direct has worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure 
that there is good quality information on cycling in the following areas:
<ul>
<li> Greater Manchester</li>
<li> Merseyside</li>
</ul>
<br />
Work is ongoing to provide cycle planning information in more areas - please check again soon 
if your local area is not yet available. Our aim is to provide national coverage for cycling over the coming 
months. <a href="/Web2/Help/NewHelp.aspx">For more information on the areas of good quality cycling information 
please follow this link to our FAQs.</a>
</td></tr>
</tbody></table></div>'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle pages - Help urls
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'FindCycleInput.HelpPageUrl', 'Help/HelpFindACycleInput.aspx', 'Help/HelpFindACycleInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCycleInput.HelpAmbiguityUrl', 'Help/HelpFindACycleInput.aspx', 'Help/HelpFindACycleInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'CycleJourneyDetails.HelpPageUrl', 'Help/HelpCycleJourneyDetails.aspx', 'Help/HelpCycleJourneyDetails.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneySummary.HelpPageUrl.Cycle', 'Help/HelpCycleJourneySummary.aspx', 'Help/HelpCycleJourneySummary.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyMap.HelpPageUrl.Cycle', 'Help/HelpCycleJourneyMap.aspx', 'Help/HelpCycleJourneyMap.aspx'

--------------------------------------------------------------------------------------------------------------------------------
-- add the urls to ensure help pages are displayed
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- Find cycle input - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindACycleInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindACycleInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindACycleInput', 'Channel',
'/Channels/TransportDirect/Help/HelpFindACycleInput',
'/Channels/TransportDirect/Help/HelpFindACycleInput'

-- Find cycle input - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindACycleInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindACycleInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindACycleInput', 'Channel',
'/Channels/TransportDirect/Printer/HelpFindACycleInput',
'/Channels/TransportDirect/Printer/HelpFindACycleInput'

-- Cycle journey details - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyDetails', 'Channel',
'/Channels/TransportDirect/Help/HelpCycleJourneyDetails',
'/Channels/TransportDirect/Help/HelpCycleJourneyDetails'

-- Cycle journey details - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyDetails', 'Channel',
'/Channels/TransportDirect/Printer/HelpCycleJourneyDetails',
'/Channels/TransportDirect/Printer/HelpCycleJourneyDetails'


-- Cycle journey summary - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneySummary', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneySummary', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneySummary', 'Channel',
'/Channels/TransportDirect/Help/HelpCycleJourneySummary',
'/Channels/TransportDirect/Help/HelpCycleJourneySummary'

-- Cycle journey summary - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneySummary', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneySummary', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneySummary', 'Channel',
'/Channels/TransportDirect/Printer/HelpCycleJourneySummary',
'/Channels/TransportDirect/Printer/HelpCycleJourneySummary'

-- Cycle journey map - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycleJourneyMap', 'Channel',
'/Channels/TransportDirect/Help/HelpCycleJourneyMap',
'/Channels/TransportDirect/Help/HelpCycleJourneyMap'

-- Cycle journey map - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycleJourneyMap', 'Channel',
'/Channels/TransportDirect/Printer/HelpCycleJourneyMap',
'/Channels/TransportDirect/Printer/HelpCycleJourneyMap'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Help text
--------------------------------------------------------------------------------------------------------------------------------
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'helpfulljp')

EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindACycleInput',
'
<h3>Selecting locations to travel from and to</h3>
<blockquote>
<h5>Type the location names in the boxes</h5>
<br />
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.  Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p>
<br />
<h5>Select the type of locations</h5>
<br />
<p>Your choice will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.  For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it.</p>
<p>The categories are described below:</p>
<ul class="listerdisc">
<li><strong>''Address/postcode'':</strong> If you select this option, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".  If you don''t know the postcode include as much of the address as possible.<br /></li>
<li><strong>''Facility/attraction'':</strong> If you select this option, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations  For example �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�<br /></li>
<li><strong>''Station/airport'':</strong> If you select this option, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.  You may also type in the name of a town and choose to travel from any of the stations in this town, e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�<br /></li>
</ul>
<br />
<h5>Find the location on a map (optional)</h5>
<br />
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).  This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
<h5>Select the dates you would like to leave/return on</h5>
<br />
<ul class="listerdisc">
<li>Select a day from the ''drop-down'' list, then select a month/year<br />or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li>
</ul>
<br />
<h5>Choose how you want to specify the times</h5>
<br />
<ul class="listerdisc">
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location or</li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li>
</ul>
<br />
<h5>Select the times you would like to travel</h5>
<br />
<ul class="listerdisc">
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Type of journey</h5>
<br />
<p>Choose how the Journey Planner will plan your cycling route. Select:</p>
<ul class="listerdisc">
<li>�Safest� if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling. This is the default option.</li>
<li>�Quickest� if you would like a route with the shortest cycling time.</li>
<li>�Easiest to navigate� if you would like a route with the fewest number of junctions.</li>
<li>�Greenest� if you would like a route that prioritises cycling through parks and green spaces in addition to the features listed above under �Safest�.</li>
</ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Speed (maximum cycling speed)</strong><br />
	Choose the maximum speed you are willing to cycle. Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.
</li>
</ul>
<br />
<h5>Journey options</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Avoid unlit roads, walking with your bike, steep climbs</strong><br />
	If you would prefer your journey to avoid unlit roads, walking with your bike, or steep climbs, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Avoid time-based access restrictions</strong><br />
	Some roads and paths have time-based access restrictions such as �Closed on market day� or �Park closes at dusk�. If you would like the planner to plan a journey that avoids all such potential restrictions then select this option.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Travelling via a location by bicycle</strong><br />
	Choose where to travel via by typing in the location and selecting a location type. For example selecting �Address / Postcode� and adding a friends address  For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.  You may also use a map to find the location.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
'
,
'
<h3>Selecting locations to travel from and to</h3>
<blockquote>
<h5>Type the location names in the boxes</h5>
<br />
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.  Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p>
<br />
<h5>Select the type of locations</h5>
<br />
<p>Your choice will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.  For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it.</p>
<p>The categories are described below:</p>
<ul class="listerdisc">
<li><strong>''Address/postcode'':</strong> If you select this option, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".  If you don''t know the postcode include as much of the address as possible.<br /></li>
<li><strong>''Facility/attraction'':</strong> If you select this option, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations  For example �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�<br /></li>
<li><strong>''Station/airport'':</strong> If you select this option, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.  You may also type in the name of a town and choose to travel from any of the stations in this town, e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�<br /></li>
</ul>
<br />
<h5>Find the location on a map (optional)</h5>
<br />
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).  This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
<h5>Select the dates you would like to leave/return on</h5>
<br />
<ul class="listerdisc">
<li>Select a day from the ''drop-down'' list, then select a month/year<br />or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li>
</ul>
<br />
<h5>Choose how you want to specify the times</h5>
<br />
<ul class="listerdisc">
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location or</li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li>
</ul>
<br />
<h5>Select the times you would like to travel</h5>
<br />
<ul class="listerdisc">
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Type of journey</h5>
<br />
<p>Choose how the Journey Planner will plan your cycling route. Select:</p>
<ul class="listerdisc">
<li>�Safest� if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling. This is the default option.</li>
<li>�Quickest� if you would like a route with the shortest cycling time.</li>
<li>�Easiest to navigate� if you would like a route with the fewest number of junctions.</li>
<li>�Greenest� if you would like a route that prioritises cycling through parks and green spaces in addition to the features listed above under �Safest�.</li>
</ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Speed (maximum cycling speed)</strong><br />
	Choose the maximum speed you are willing to cycle. Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.
</li>
</ul>
<br />
<h5>Journey options</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Avoid unlit roads, walking with your bike, steep climbs</strong><br />
	If you would prefer your journey to avoid unlit roads, walking with your bike, or steep climbs, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Avoid time-based access restrictions</strong><br />
	Some roads and paths have time-based access restrictions such as �Closed on market day� or �Park closes at dusk�. If you would like the planner to plan a journey that avoids all such potential restrictions then select this option.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Travelling via a location by bicycle</strong><br />
	Choose where to travel via by typing in the location and selecting a location type. For example selecting �Address / Postcode� and adding a friends address  For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.  You may also use a map to find the location.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindACycleInput',
'
<h3>Selecting locations to travel from and to</h3>
<blockquote>
<h5>Type the location names in the boxes</h5>
<br />
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.  Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p>
<br />
<h5>Select the type of locations</h5>
<br />
<p>Your choice will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.  For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it.</p>
<p>The categories are described below:</p>
<ul class="listerdisc">
<li><strong>''Address/postcode'':</strong> If you select this option, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".  If you don''t know the postcode include as much of the address as possible.<br /></li>
<li><strong>''Facility/attraction'':</strong> If you select this option, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations  For example �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�<br /></li>
<li><strong>''Station/airport'':</strong> If you select this option, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.  You may also type in the name of a town and choose to travel from any of the stations in this town, e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�<br /></li>
</ul>
<br />
<h5>Find the location on a map (optional)</h5>
<br />
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).  This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
<h5>Select the dates you would like to leave/return on</h5>
<br />
<ul class="listerdisc">
<li>Select a day from the ''drop-down'' list, then select a month/year<br />or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li>
</ul>
<br />
<h5>Choose how you want to specify the times</h5>
<br />
<ul class="listerdisc">
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location or</li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li>
</ul>
<br />
<h5>Select the times you would like to travel</h5>
<br />
<ul class="listerdisc">
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Type of journey</h5>
<br />
<p>Choose how the Journey Planner will plan your cycling route. Select:</p>
<ul class="listerdisc">
<li>�Safest� if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling. This is the default option.</li>
<li>�Quickest� if you would like a route with the shortest cycling time.</li>
<li>�Easiest to navigate� if you would like a route with the fewest number of junctions.</li>
<li>�Greenest� if you would like a route that prioritises cycling through parks and green spaces in addition to the features listed above under �Safest�.</li>
</ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Speed (maximum cycling speed)</strong><br />
	Choose the maximum speed you are willing to cycle. Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.
</li>
</ul>
<br />
<h5>Journey options</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Avoid unlit roads, walking with your bike, steep climbs</strong><br />
	If you would prefer your journey to avoid unlit roads, walking with your bike, or steep climbs, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Avoid time-based access restrictions</strong><br />
	Some roads and paths have time-based access restrictions such as �Closed on market day� or �Park closes at dusk�. If you would like the planner to plan a journey that avoids all such potential restrictions then select this option.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Travelling via a location by bicycle</strong><br />
	Choose where to travel via by typing in the location and selecting a location type. For example selecting �Address / Postcode� and adding a friends address  For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.  You may also use a map to find the location.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
'
,
'
<h3>Selecting locations to travel from and to</h3>
<blockquote>
<h5>Type the location names in the boxes</h5>
<br />
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.  Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p>
<br />
<h5>Select the type of locations</h5>
<br />
<p>Your choice will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.  For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it.</p>
<p>The categories are described below:</p>
<ul class="listerdisc">
<li><strong>''Address/postcode'':</strong> If you select this option, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".  If you don''t know the postcode include as much of the address as possible.<br /></li>
<li><strong>''Facility/attraction'':</strong> If you select this option, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations  For example �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�<br /></li>
<li><strong>''Station/airport'':</strong> If you select this option, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.  You may also type in the name of a town and choose to travel from any of the stations in this town, e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�<br /></li>
</ul>
<br />
<h5>Find the location on a map (optional)</h5>
<br />
<p>You may click on the ''Find on map'' button to find the location on a map.</p>
<p>Once you have found the location on the map, you will have the option to continue planning the journey (by clicking ''Next'' on that page).  This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
<h5>Select the dates you would like to leave/return on</h5>
<br />
<ul class="listerdisc">
<li>Select a day from the ''drop-down'' list, then select a month/year<br />or </li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li>
</ul>
<br />
<h5>Choose how you want to specify the times</h5>
<br />
<ul class="listerdisc">
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location or</li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li>
</ul>
<br />
<h5>Select the times you would like to travel</h5>
<br />
<ul class="listerdisc">
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
</ul>
<br />
<h5>Type of journey</h5>
<br />
<p>Choose how the Journey Planner will plan your cycling route. Select:</p>
<ul class="listerdisc">
<li>�Safest� if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling. This is the default option.</li>
<li>�Quickest� if you would like a route with the shortest cycling time.</li>
<li>�Easiest to navigate� if you would like a route with the fewest number of junctions.</li>
<li>�Greenest� if you would like a route that prioritises cycling through parks and green spaces in addition to the features listed above under �Safest�.</li>
</ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
<ul class="listerdisc">
<li><strong>Speed (maximum cycling speed)</strong><br />
	Choose the maximum speed you are willing to cycle. Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.
</li>
</ul>
<br />
<h5>Journey options</h5>
<blockquote>
<ul class="listerdisc">
<li><strong>Avoid unlit roads, walking with your bike, steep climbs</strong><br />
	If you would prefer your journey to avoid unlit roads, walking with your bike, or steep climbs, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Avoid time-based access restrictions</strong><br />
	Some roads and paths have time-based access restrictions such as �Closed on market day� or �Park closes at dusk�. If you would like the planner to plan a journey that avoids all such potential restrictions then select this option.
</li>
</ul>
<br />
<ul class="listerdisc">
<li><strong>Travelling via a location by bicycle</strong><br />
	Choose where to travel via by typing in the location and selecting a location type. For example selecting �Address / Postcode� and adding a friends address  For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.  You may also use a map to find the location.
</li>
</ul>
</blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>
'


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey details - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneyDetails',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>The directions for your cycle journey are shown in a list. If you prefer, you can view them on a map by clicking "Show on map". The map will appear with the directions listed below it.</p>
<br />
<p>Journey directions:</p>
<br />
<p>If the journey involves ferries, tolls, etc. you can click on the name in the instruction to be taken to a website that will give you more information about the ferry or toll etc..</p>
<p>The gradient profile graph shows a cross section of your cycle route so you are able to judge how flat or steep your route is. The X-axis shows the journey distance in miles or km, the Y-axis will show the height above sea level for your journey in metres. The highest and lowest point on the journey will also be shown along with the total climb and descent in metres. </p>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>The directions for your cycle journey are shown in a list. If you prefer, you can view them on a map by clicking "Show on map". The map will appear with the directions listed below it.</p>
<br />
<p>Journey directions:</p>
<br />
<p>If the journey involves ferries, tolls, etc. you can click on the name in the instruction to be taken to a website that will give you more information about the ferry or toll etc..</p>
<p>The gradient profile graph shows a cross section of your cycle route so you are able to judge how flat or steep your route is. The X-axis shows the journey distance in miles or km, the Y-axis will show the height above sea level for your journey in metres. The highest and lowest point on the journey will also be shown along with the total climb and descent in metres. </p>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey details - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneyDetails',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>The directions for your cycle journey are shown in a list. If you prefer, you can view them on a map by clicking "Show on map". The map will appear with the directions listed below it.</p>
<br />
<p>Journey directions:</p>
<br />
<p>If the journey involves ferries, tolls, etc. you can click on the name in the instruction to be taken to a website that will give you more information about the ferry or toll etc..</p>
<p>The gradient profile graph shows a cross section of your cycle route so you are able to judge how flat or steep your route is. The X-axis shows the journey distance in miles or km, the Y-axis will show the height above sea level for your journey in metres. The highest and lowest point on the journey will also be shown along with the total climb and descent in metres. </p>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>The directions for your cycle journey are shown in a list. If you prefer, you can view them on a map by clicking "Show on map". The map will appear with the directions listed below it.</p>
<br />
<p>Journey directions:</p>
<br />
<p>If the journey involves ferries, tolls, etc. you can click on the name in the instruction to be taken to a website that will give you more information about the ferry or toll etc..</p>
<p>The gradient profile graph shows a cross section of your cycle route so you are able to judge how flat or steep your route is. The X-axis shows the journey distance in miles or km, the Y-axis will show the height above sea level for your journey in metres. The highest and lowest point on the journey will also be shown along with the total climb and descent in metres. </p>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey summary - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneySummary',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey summary - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneySummary',
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Journey details</h5>
<br />
<p>To view information about a journey:</p>
<ol>
<li> Click the buttons above the journeys to view a brief summary of your journey options (''Summary''), detailed maps of your journey (''Maps''), the CO2 your journey will produce � and the ability to compare this with other modes of transport (''Check CO2'') for the selected journey </li>
</ol>
<p>To print any of the pages, click ''Printer friendly''. This will open a printer-friendly page that you can print as usual.</p>
<br />
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey map - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneyMap',
'
<blockquote>
<h5>Journey maps</h5>
<br />
<p>You can view specific stages of the journey in more detail:</p>
<ol>
<li>Select the journey stage from the drop-down list</li>
<li>Click ''Show route''</li>
</ol>
<p>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.</p>
<br />
<p>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow). They include transport symbols (shown automatically) and a range of attraction and facility symbols.</p>
<p>To show or hide any of these symbols, you must:</p>
<ol>
<li>Click on a category radio button e.g. ''Accommodation''</li>
<li>Tick or untick the boxes next to the symbols</li>
<li>Click ''Show selected symbols''</li>
</ol>
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Journey maps</h5>
<br />
<p>You can view specific stages of the journey in more detail:</p>
<ol>
<li>Select the journey stage from the drop-down list</li>
<li>Click ''Show route''</li>
</ol>
<p>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.</p>
<br />
<p>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow). They include transport symbols (shown automatically) and a range of attraction and facility symbols.</p>
<p>To show or hide any of these symbols, you must:</p>
<ol>
<li>Click on a category radio button e.g. ''Accommodation''</li>
<li>Tick or untick the boxes next to the symbols</li>
<li>Click ''Show selected symbols''</li>
</ol>
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey map - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneyMap',
'
<blockquote>
<h5>Journey maps</h5>
<br />
<p>You can view specific stages of the journey in more detail:</p>
<ol>
<li>Select the journey stage from the drop-down list</li>
<li>Click ''Show route''</li>
</ol>
<p>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.</p>
<br />
<p>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow). They include transport symbols (shown automatically) and a range of attraction and facility symbols.</p>
<p>To show or hide any of these symbols, you must:</p>
<ol>
<li>Click on a category radio button e.g. ''Accommodation''</li>
<li>Tick or untick the boxes next to the symbols</li>
<li>Click ''Show selected symbols''</li>
</ol>
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'
,
'
<blockquote>
<h5>Journey maps</h5>
<br />
<p>You can view specific stages of the journey in more detail:</p>
<ol>
<li>Select the journey stage from the drop-down list</li>
<li>Click ''Show route''</li>
</ol>
<p>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.</p>
<br />
<p>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow). They include transport symbols (shown automatically) and a range of attraction and facility symbols.</p>
<p>To show or hide any of these symbols, you must:</p>
<ol>
<li>Click on a category radio button e.g. ''Accommodation''</li>
<li>Tick or untick the boxes next to the symbols</li>
<li>Click ''Show selected symbols''</li>
</ol>
<h5>Amend date and time</h5>
<br />
<p>To amend the dates and times of your journey:</p>
<ol>
<li>Select the new date(s) and time(s) in the drop-down lists</li>
<li>Click ''Search with new dates/times''</li>
</ol>
<p>To amend the entire journey, you can click ''Amend journey'' at the top of the page</p>
<br />
<h5>Save as a favourite journey</h5>
<br />
<p>To save the journey:</p>
<ol>
<li>Make sure you are logged in</li>
<li>Enter a meaningful name for the journey (e.g. �Journey to work�) </li>
<li>Click ''OK''</li>
</ol>
<p>You can save up to five journeys and you can overwrite existing journeys.</p>
<br />
<h5>Send to a friend</h5>
<br />
<p>To send this page to a friend:</p>
<ol>
<li>Make sure you are logged in to Transport Direct.</li>
<li>If you are not logged in, you will need to enter your username and password.</li>
<li>Type in the email address of the person you would like to send the page to in the box</li>
<li>Click ''Send''</li>
</ol>
<p>A text-based email with a summary of the journey and the details/directions will be sent to that email address. Maps (if applicable) will be attached as an image file (the average email size is around 150k). Your email address will be shown in the email.</p>
</blockquote>
'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------------------------------------
-- Add Cycle journey details - Cycling Instructions text
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int
SET @GroupId = 1

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.RouteJoins',
'Route joins {0} {1}', 'cy Route joins {0} {1}'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.RouteLeavesCycleInfrastructure',
'Route leaves cycle specific infrastructure', 'cy Route leaves cycle specific infrastructure'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.RouteUses',
'Route uses', 'cy Route uses'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.PleaseNote',
'Please note the route goes', 'cy Please note the route goes'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.PleaseCross',
'Please cross at', 'cy Please cross at'

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleRouteText.TheStreetIs',
'The {0}', 'cy The {0}'

EXEC AddtblContent 1, @GroupId, 'langStrings', 'CycleRouteText.And', 
'and', 'a'

EXEC AddtblContent 1, @GroupId, 'langStrings', 'CycleRouteText.ForThisManoeuvre', 
'For this manoeuvre we recommend that you', 'cy For this manoeuvre we recommend that you'



EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftOne2',
'Take first available left ', 'Cymerwch y troad cyntaf i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftTwo2',
'Take second available left ', 'Cymerwch yr ail droad i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftThree2',
'Take third available left ', 'Cymerwch y trydydd troad i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnLeftFour2',
'Take fourth available left ', 'Cymerwch y pedwerydd troad i''r chwith sydd ar gael '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightOne2',
'Take first available right ', 'Cymerwch y troad cyntaf sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightTwo2',
'Take second available right ', 'Cymerwch yr ail droad sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightThree2',
'Take third available right ', 'Cymerwch y trydydd troad sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.TurnRightFour2',
'Take fourth available right ', 'Cymerwch y pedwerydd troad sydd ar gael i''r dde '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.AtMiniRoundabout2',
'at mini-roundabout ', 'wrth y gylchfan fach '


EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.LocalPath',
'unnamed path ', 'cy unnamed path '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.Street',
'street ', 'cy street '

EXEC AddtblContent 1, @GroupId, 'langstrings', 'RouteText.Path',
'path ', 'cy path '

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------
-- Add Cycle journey details - Cycle Attributes list
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int
SET @GroupId = 1

EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NoCycleAttributes',         'NoCycleAttributes', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Motorway',                  'motorway', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ARoad',                     'A road', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BRoad',                     'B road', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MinorRoad',                 'minor road', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LocalStreet',               'local street', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Alley',                     'alley', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PrivateRoad',               'private road', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PedestrianisedStreet',      'a pedestrianised street', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TollRoad',                  'toll road', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SingleCarriageway',         'single carriageway', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.DualCarriageway',           'dual carriageway', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SlipRoad',                  'slip road', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Roundabout',                'roundabout', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.EnclosedTrafficAreaLink',   'EnclosedTrafficAreaLink', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrafficIslandLinkAtJunction', 'TrafficIslandLinkAtJunction', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrafficIslandLink',         'TrafficIslandLink', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Ferry',                     'ferry', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LimitedAccess',             'limited access', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ProhibitedAccess',          'prohibited access', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Footpath',                  'footpath', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Cyclepath',                 'cyclepath', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Bridlepath',                'bridlepath', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CandriveAtoB',              'CandriveAtoB', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CandriveBtoA',              'CandriveBtoA', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CanenteratAi.e.noentryatB', 'CanenteratAi.e.noentryatB', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CanenteratBi.e.noentryatA', 'CanenteratBi.e.noentryatA', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Superlink',                 'Superlink', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrunkRoad',                 'trunk road', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TurnSuperlink',             'TurnSuperlink', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ConnectingLink',            'ConnectingLink', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Towpath',                   'a towpath', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient2-AtoBuphill',      'Gradient2-AtoBuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient2-BtoAuphill',      'Gradient2-BtoAuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient3-AtoBuphill',      'Gradient3-AtoBuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient3-BtoAuphill',      'Gradient3-BtoAuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient4-AtoBuphill',      'Gradient4-AtoBuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient4-BtoAuphill',      'Gradient4-BtoAuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient5-AtoBuphill',      'Gradient5-AtoBuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gradient5-BtoAuphill',      'Gradient5-BtoAuphill', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Ford',                      'through a ford', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Gate',                      'through a gate', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LevelCrossing',             'across a level crossing', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Bridge',                    'over a bridge', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Tunnel',                    'through a tunnel', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CalmingUnavoidablebyBike',  'CalmingUnavoidablebyBike', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Footbridge',                'over a footbridge', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',             		'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SharedUseFootpath',         'a shared use footpath', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FootpathOnly',              'a footpath - please walk your bike', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CyclesOnly',                'a cycle only path', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PrivateAccess',             'is private access', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Parkland',                  'through a park', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'unused', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Subway',                    'through a subway', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RaisableBarrier',           'past a raisable barrier', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.HoopLiftBarrier',           'over a hoop barrier', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CattleGrid',                'across a cattle grid', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Stile',                     'over a stile', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.HoopThroughBarrier',        'over a hoop barrier', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Humps',                     'over traffic calming humps', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Cushions',                  'over traffic calming cushions', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Chicane',                   'through a chicane', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PinchPoint',                'through a pinch point', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Pelican',                   'pelican crossing', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Toucan',                    'toucan crossing', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Zebra',                     'zebra crossing', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WalkaboutManoeuvre',        'WalkaboutManoeuvre', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.AdvancedManoeuvre',         'AdvancedManoeuvre', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.ProhibitedManoeuvre',       'ProhibitedManoeuvre', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CycleLaneAtoB',             'an on road cycle lane', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CycleLaneBtoA',             'an on road cycle lane', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BusLaneAtoB',               'a shared use bus lane', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BusLaneBtoA',               'a shared use bus lane', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NarrowAtoB',                'a narrow on road cycle lane', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NarrowBtoA',                'a narrow on road cycle lane', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.DedicatedAtoB',             'a dedicated cycle track', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.DedicatedBtoA',             'a dedicated cycle track', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.UnpavedAtoB',               'is unpaved', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.UnpavedBtoA',               'is unpaved', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WhenDryAtoB',               'may be wet in winter', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WhenDryBtoA',               'may be wet in winter', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FirmAtoB',                  'is unpaved', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FirmBtoA',                  'is unpaved', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PavedAtoB',                 'is paved', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PavedBtoA',                 'is paved', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LooseAtoB',                 'has a loose surface', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LooseBtoA',                 'has a loose surface', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CobblesAtoB',               'is cobbled', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.CobblesBtoA',               'is cobbled', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MixedAtoB',                 'MixedAtoB', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MixedBtoA',                 'MixedBtoA', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RoughAtoB',                 'has a rough surface', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RoughBtoA',                 'has a rough surface', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BlocksAtoB',                'BlocksAtoB', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.BlocksBtoA',                'BlocksBtoA', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.IndividualRecommendation',  'IndividualRecommendation', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LARecommended',             'LARecommended', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.RecommendedForSchools',     'RecommendedForSchools', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.OtherRecommendation',       'OtherRecommendation', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.WellLit',                   'is well lit', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.LightingPresent',           'has street lighting', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.PartialLighting',           'is partially lit', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Nolighting',                'has no lighting', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Busy',                      'is busy', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Very',                      'is very', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Quiet',                     'is quiet', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TrafficFree',               'is traffic free', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.SeldomPolicedUrbanArea',    'SeldomPolicedUrbanArea', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.IsolatedArea',              'is in an isolated area', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NeighbourhoodWatch',        'has a neighbourhood watch scheme', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Cctv MonitoredArea',        'is a monitored area', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NormallySafeInDaylight',    'normally safe in daylight', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.NormallySafeAtNight',       'normally safe at night', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.IncidentsHaveOccuredInArea', 'incidents have occured in area', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.FrequentlyPolicedUrbanArea', 'frequently policed urban area', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Steps',                     'steps - cycle should be carried', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Channelalongsidesteps',     'steps with a channel', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.Unused',                    'Test', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.TurnRestriction',           'TurnRestriction', 'cyTest'
EXEC AddtblContent 1, @GroupId, 'langstrings', 'CycleAttribute.MiniRoundabout',            'mini roundabout', 'cyTest'

GO
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1088
SET @ScriptDesc = 'Cycle planner content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO