-- ***********************************************
-- NAME 		: DUP1035_TransportDirect_Content_14_ContactUs.sql
-- DESCRIPTION 		: Add Contact Us content
-- AUTHOR		: D. Scott Angle
-- DATE			: 09 July 2008 13:00:00
-- ************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Content]
GO

EXEC AddtblContent
1, 23, 'BodyText', '/Channels/TransportDirect/ContactUs/Details'
,'<DIV id="primcontent">
<DIV id="contentarea">
<P><STRONG>Address</STRONG></P>
<P>Programme Support Office&nbsp;</P>
<P>Transport Direct</P>
<P>Department for Transport</P>
<P>2nd Floor</P>
<P>55 Victoria Street</P>
<P>LONDON</P>
<P>SW1H 0EU</P><BR><BR>
<P><STRONG>Email</STRONG></P>
<P>TDPortal.Feedback@dft.gsi.gov.uk</P>
<P>&nbsp;</P>
<P>&nbsp;</P>
<P>&nbsp;</P></DIV></DIV>'
,'<DIV id="primcontent">
<DIV id="contentarea">
<P><STRONG>Cyfeiriad</STRONG></P>
<P>Programme Support Office&nbsp;</P>
<P>Transport Direct</P>
<P>Department for Transport</P>
<P>2nd Floor</P>
<P>55 Victoria Street</P>
<P>LONDON</P>
<P>SW1H 0EU</P><BR><BR>
<P><STRONG>Cyfeiriad ebost</STRONG></P>
<P>TDPortal.Feedback@dft.gsi.gov.uk</P>
<P>&nbsp;</P>
<P>&nbsp;</P>
<P>&nbsp;</P></DIV></DIV>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1035
SET @ScriptDesc = 'Add About Us content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO