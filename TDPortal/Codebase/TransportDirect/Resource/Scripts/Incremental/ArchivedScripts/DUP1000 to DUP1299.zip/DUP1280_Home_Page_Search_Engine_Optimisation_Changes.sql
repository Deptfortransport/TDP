-- ***********************************************
-- NAME 		: DUP1280_Home_Page_Search_Engine_Optimisation_Changes.sql
-- DESCRIPTION 		: Update content for Search Engine Optimisation
-- AUTHOR		: Amit Patel
-- DATE			:06 February 2009
-- ************************************************

USE [Content]
GO



-- Home page seo changes
EXEC AddtblContent
1, 1, 'langStrings', 'Homepage.literalPageHeading',
'Live travel news, journey planning, train times and more...',
'Live travel news, journey planning, train times and more...'


GO








----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1280
SET @ScriptDesc = 'Update content for Search Engine Optimisation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO