-- ***********************************************
-- NAME 		: DUP1008_ZonalAccessibilityImportTask.sql
-- DESCRIPTION 		: Zonal Accessibility Import Task
--			: 
-- AUTHOR		: Sanjeev Johal
-- ************************************************

USE [TransientPortal]
GO

---------------------------------------------------
-- 1. ZonalAccessibilityImportTask Procedure change
----------------------------------------------------


--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'ZonalAccessibilityImportTask'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[ZonalAccessibilityImportTask] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
ALTER    PROCEDURE dbo.ZonalAccessibilityImportTask
(
	@XML text
)
AS

SET NOCOUNT ON
SET XACT_ABORT ON

DECLARE @DocID int, @RowCount int, @XMLPathData varchar(50), @DefaultSortNumber int 
DECLARE @NaPTANCode varchar(12), @AccessibilityURL varchar(500), @LinkTextDesc varchar(200)
DECLARE @WithEffectFromDate varchar(10), @WithEffectToDate varchar(10), @ExternalLinksID varchar(500)

DECLARE @RegionId varchar(20), @OperatorCode varchar(20), @ModeId varchar(20)
DECLARE	@AdminAreaId INT, @DistrictId INT


DECLARE @ProcError int

 
-- Loading xml document 
EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
-- set the node 
SET @XMLPathData =  '/zonalaccessibility/Accessibility'

BEGIN TRANSACTION

	--delete all zonal accessibility links data
	if EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'dbo.ZonalAccessibilityLinks') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		--delete zonal services operator data
		DELETE FROM ZonalAccessibilityLinks	
		
	END


	


	--use a cursor to insert data because we are inserting into more than one table
	--Insert into tables
	DECLARE cursorZonal CURSOR FOR
		SELECT 
			X.URL, 		
			X.HyperlinkDescription,		
			X.WithEffectFromDate, 
			X.WithEffectToDate,
			X.NaPTAN,
			X.RegionId,
			X.OperatorCode,
			X.ModeId,
			X.AdminAreaId,
			X.DistrictId
		FROM
		OPENXML (@DocID, @XMLPathData, 2)
		WITH
		(	
			URL varchar(500) ,				
			HyperlinkDescription varchar(200),
			WithEffectFromDate varchar(10),
			WithEffectToDate varchar(10),
			NaPTAN varchar(12) ,
			RegionId varchar(20),
			OperatorCode varchar(20),
			ModeId varchar(20),
			AdminAreaId INT,
			DistrictId INT				
		) X 
	
	IF @@Error <> 0
		SELECT @ProcError = @@Error	

	OPEN cursorZonal

	FETCH NEXT FROM cursorZonal INTO 
		@AccessibilityURL, @LinkTextDesc, @WithEffectFromDate, @WithEffectToDate, @NaPTANCode, @RegionId, @OperatorCode, @ModeId, @AdminAreaId, @DistrictId

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @ExternalLinksID = NEWID()

		INSERT INTO ExternalLinks ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
		VALUES(@ExternalLinksID, 
				@AccessibilityURL, 
				@AccessibilityURL, 
				CONVERT(datetime, @WithEffectFromDate, 103),
				CONVERT(datetime, @WithEffectToDate, 103),
				@LinkTextDesc, 
				'Added by Zonal Acessibility - Accessibility')
		
		IF @@Error <> 0
			SELECT @ProcError = @@Error	

		

		INSERT INTO ZonalAccessibilityLinks (ExternalLinkID,Naptan,RegionId,ModeId, OperatorCode, AdminAreaId, DistrictId)
		VALUES(@ExternalLinksID, @NaPTANCode, @RegionId, @ModeId, @OperatorCode, @AdminAreaId, @DistrictId)	

		IF @@Error <> 0
			SELECT @ProcError = @@Error	


		-- This is executed as long as the previous fetch succeeds.
		FETCH NEXT FROM cursorZonal INTO 
			@AccessibilityURL, @LinkTextDesc, @WithEffectFromDate, @WithEffectToDate, @NaPTANCode, @RegionId, @OperatorCode, @ModeId, @AdminAreaId, @DistrictId
	END
	
	CLOSE cursorZonal
	DEALLOCATE cursorZonal 



	-- Remove xml doc from memorry
	EXEC sp_xml_removedocument @DocID

	IF @@Error <> 0
		SELECT @ProcError = @@Error	


	IF @ProcError<>0
		ROLLBACK TRANSACTION
	ELSE
	BEGIN
		COMMIT TRANSACTION	
		UPDATE ChangeNotification
		SET Version = Version + 1
		WHERE [Table] = 'ZonalAccessibility'	
		
	END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1008
SET @ScriptDesc = 'Zonal Accessibility Import Task'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
