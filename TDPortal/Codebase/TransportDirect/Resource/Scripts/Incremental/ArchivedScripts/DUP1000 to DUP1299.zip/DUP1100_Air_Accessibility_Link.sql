-- ***********************************************
-- NAME 		: DUP1100_Air_Accessibility_Link.sql
-- DESCRIPTION 		: Add rows to content DB and external link for Air Accessibility Rights Link
-- AUTHOR		: John Frank
-- DATE			: 29th Auggust 2008
-- ************************************************

USE [TransientPortal]
GO

-- Cycle england
EXEC AddExternalLink
'Accessibility.Rights', 
'http://www.equalityhumanrights.com/en/yourrights/rightsindifferentsettings/transport/Pages/Stepbystepguide.aspx', 
'http://www.equalityhumanrights.com/en/yourrights/rightsindifferentsettings/transport/Pages/Stepbystepguide.aspx', 
'Accessibility Rights web page'

GO

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelAccessibilityFootnoteLine2.Text'
,'More information about ', 'More information about '
GO

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelAccessibilityFootnoteLine2.LinkText'
,'your accessibility rights when you fly (opens new window).', 'your accessibility rights when you fly (opens new window).'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1100
SET @ScriptDesc = 'Add rows to content DB and external link for Air Accessibility Rights Link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO