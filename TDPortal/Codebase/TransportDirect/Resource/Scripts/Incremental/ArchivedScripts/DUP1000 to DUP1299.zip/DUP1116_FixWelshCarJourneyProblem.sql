-- ***********************************************
-- NAME 		: DUP1116_FixWelshCarJourneyProblem.sql
-- DESCRIPTION 		: Script to change welsh Content DB in to fix car journey problem
-- AUTHOR		: Phil Scott
-- DATE			: 08 Oct 2008 
-- ************************************************

USE [Content]
GO

update tblContent
set [Value-Cy] = left(cast([Value-Cy] as varchar),charindex('{0]',[Value-Cy])-1)+'{0}'
WHERE     ([Value-Cy] like 'Darganfod meysydd parcio ger {0]')

go
GO



----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1116
SET @ScriptDesc = 'Script to change welsh Content DB in to fix car journey problem'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO