-- ***********************************************
-- NAME 		: DUP1108_XHTML_Content_corrections.sql
-- DESCRIPTION 		: Script to make corrections to Content for XHTML compliance
-- AUTHOR		: Mitesh Modi
-- DATE			: 18 Sep 2008
-- ************************************************

USE [Content]
GO


-- Map pages Key control
EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.labelSportTitle', 
'Sport, entertainment &amp; retail', 
'Chwaraeon, hamdden ac adwerthu'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.labelAccommodationTitle', 
'Accommodation, eating &amp; drinking', 
'Llety, bwyta ac yfed'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarPreferencesControl.PetrolPerLitre', 
'pence/litre for unleaded petrol,<br />', 
'ceiniog y litr ar gyfer petrol di-blwm, '

GO


---------------------------------------------------------------
USE [TransientPortal]
GO

-- Correct the Terms and Conditions link display text to use &amp; instead of &
UPDATE [Resource]
SET [Text] = 'Terms &amp; conditions'
WHERE [Text]= 'Terms & conditions'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1108
SET @ScriptDesc = 'XHTML corrections to Content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO