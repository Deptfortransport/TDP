-- ***********************************************
-- NAME 		: DUP1080_Content_Update_for_DepartureBoard_Visibility_Changes.sql
-- DESCRIPTION 		: Script to add URLs and Text for Departure board visibility changes
-- AUTHOR		: Phil Scott
-- DATE			: 29 Jul 2008 09:00:00
-- ************************************************

USE [Content]
GO



EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.imageMapUKUrl','/Web2/App_Themes/TransportDirect/images/gifs/journeyplanning/en/MapUK.gif','/Web2/App_Themes/TransportDirect/images/gifs/journeyplanning/cy/MapUK.gif'



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1080
SET @ScriptDesc = 'Content_Update_for_DepartureBoard_Visibility_Changes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO