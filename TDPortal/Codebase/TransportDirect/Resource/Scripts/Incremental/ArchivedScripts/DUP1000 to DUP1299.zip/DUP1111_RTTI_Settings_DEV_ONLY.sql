-- ***********************************************
-- NAME 		: DUP1111_RTTI_Settings_DEV_ONLY.sql
-- DESCRIPTION 		: Script for the DEVELOPMENT ENVIRONMENT ONLY
--			: Adds RTTI settings for dev
-- AUTHOR		: John Frank
-- DATE			: 22 Sep 2008
-- ************************************************

USE [PermanentPortal]
GO

Update properties
SET pValue = 'data source=SID01; initial catalog=AdditionalData; user id=steve; password=password; persist security info=False'
Where pname = 'AdditionalDataDB'
and AID = 'EnhancedExposedServices'
and GID = 'UserPortal'

--previous setting 'localhost'
Update properties
SET pValue = '212.188.138.216'
Where pname = 'DepartureBoardService.RTTIManager.SocketServer'
and AID = 'ExposedServices'
and GID = 'UserPortal'

--previous setting '1234'
Update properties
SET pValue = '9125'
Where pname = 'DepartureBoardService.RTTIManager.SocketPort'
and AID = 'ExposedServices'
and GID = 'UserPortal'

--previous setting 'true'
Update properties
SET pValue = 'false'
Where pname = 'DepartureBoardService.GetTrainInfoFromCJP'
and AID = 'ExposedServices'
and GID = 'UserPortal'

--previous setting 'd:/....'
Update properties
SET pValue = 'C:\Inetpub\wwwroot\enhancedexposedservices\Schema\rttiEPTSchema.xsd'
Where pname = 'DepartureBoardService.RTTIManager.SchemaLocation'
and AID = 'ExposedServices'
and GID = 'UserPortal'

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1111
SET @ScriptDesc = 'Script add RTTI settings for Dev'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO