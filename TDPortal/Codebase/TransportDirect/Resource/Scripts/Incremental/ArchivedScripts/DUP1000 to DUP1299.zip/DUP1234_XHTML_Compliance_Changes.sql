-- ***********************************************
-- NAME 		: DUP1234_XHTML_Compliance_Changes.sql
-- DESCRIPTION 		: Update content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 08 January 2008
-- ************************************************

USE [Content]
GO

-- help page content for RefineTickets.aspx page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpRefineTickets'
,'<h3>View tickets, costs and fare information</h3><br/>
<h4>Public Transport ticket and fare information</h4>
<p>For the public transport elements of your journey, this page shows the available ticket types, the published fare for each ticket type and the associated flexibility.</p><br/>
<p>"Ticket type", in the Fares table, lists the tickets types. You can see more information about the ticket type by clicking on the name of the ticket. Ticket flexibility is shown as either "No", "Part" or "Full".</p><br/>
<div class="boxtypenineinner">
<div>
<ul>
<li><strong>No Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these types of tickets in advance for specified journeys. They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</li></ul></div>
<div>
<ul>
<li><strong>Part Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these tickets anytime, but travel is restricted to avoid certain times.</li></ul></div>
<div>
<ul>
<li><strong>Full Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</li></ul></div></div><br/>
<p>In some cases several legs of the journey can be included under one fare. The legs of the journey these fares cover are indicated at the top of the table (e.g. Fares: Brighton to Manchester Piccadilly). A blue outline around the details indicates which legs of the journey are included in this fare.</p><br/>
<p>Transport Direct may not have all fare information for all parts of the journey or all forms of transport used in the journey. You will need to buy tickets for these parts of your journey elsewhere.</p><br/>
<p>Please be aware that, if your overall journey is made up of several individual elements, it may be possible to get a cheaper fare by planning the journey as a through journey.</p><br/>
<h4>Change the fare details</h4>
<p>At the bottom of the page, you can choose to see the effect of applying a discount card to the fares, or seeing if in fact buying two singles may be cheaper than a return fare.</p><br/>
<p>Transport Direct only shows fares that are available to buy. It does this by checking ticket databases in real time, so there may be a slight delay in obtaining your fare information.</p><br/>
<h4>Car cost information</h4>
<p>If your journey involves using a car or a combination of public transport and car, there will be information about the cost of your car journey, including fuel costs and other associated costs, should you wish to view them.</p><br/>
<p>If the journey involves ferries or toll roads, the costs for these will be shown, if known. For more information on ferries or toll roads in your journey, click the ferry service or toll road name to be taken to the relevant website (e.g. <a href="http://www.m6toll.co.uk">www.m6toll.co.uk</a>).</p><br/>
<p>When you have finished viewing tickets, costs and fare information, press "Back to summary" to continue.</p>'
,'<h3>Edrychwch ar docynnau, costau a gwybodaeth am brisiau tocynnau</h3><br/>
<h4>Gwybodaeth am docynnau a phrisiau tocynnau cludiant cyhoeddus</h4>
<p>Ar gyfer elfennau cludiant cyhoeddus eich siwrnai, mae''r dudalen hon yn dangos y mathau o docynnau sydd ar gael, pris y tocynnau a gyhoeddwyd ar gyfer pob math o docyn a''r hyblygrwydd cysylltiedig.</p><br/>
<p>Mae''r ''Math o docyn'' yn y tabl prisiau tocynnau yn rhestru''r mathau o docynnau. Gallwch weld mwy o wybodaeth am y math o docyn drwy glicio ar enw''r tocyn. Dangosir hyblygrwydd y tocyn fel naill ai ''Nac ydynt'', ''Rhannol'' neu ''Llawn''.</p><br/>
<div class="boxtypenineinner">
<div>
<ul>
<li><strong>Dim Hyblygrwydd</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer siwrneion penodol. Maent ar gael mewn niferoedd cyfyngedig fel arfer, ar adegau penodol, ac ar wasanaethau penodol. Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf un diwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, nifer o ddyddiau ymlaen llaw), mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</li></ul></div>
<div>
<ul>
<li><strong>Hyblygrwydd Rhannol</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi rhai adegau arbennig.</li></ul></div>
<div>
<ul>
<li><strong>Hyblygrwydd Llawn</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod y maent yn ddilys. Mae''r rhain yn cynnwys tocynnau Agored a rhai tocynnau Dydd. Maent yn aml yn dda i deithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft, yr awr frys.</li></ul></div></div><br/>
<p>Mewn rhai achosion gellir cynnwys nifer o adrannau''r siwrnai o dan un pris tocyn. Nodir yr adrannau o''r siwrnai y mae''r tocynnau hyn yn ymdrin � nhw ar frig y tabl (e.e. Prisiau Tocynnau: Brighton i Manchester Piccadilly). Mae amlinelliad glas o amgylch y manylion yn nodi pa adrannau o''r siwrnai a gynhwysir yn y pris tocyn hwn.</p><br/>
<p>Mae''n bosib na fydd gan Transport Direct yr holl wybodaeth am brisiau tocynnau ar gyfer pob rhan o''r siwrnai neu pob ffurf ar gludiant a ddefnyddir yn y siwrnai hon. Bydd angen i chi brynu tocynnau ar gyfer y rhannau hyn o''r siwrnai mewn man arall.</p><br/>
<p>Cofiwch, os yw eich siwrnai gyffredinol yn cynnwys nifer o elfennau unigol, y gall fod yn bosib cael pris tocyn rhatach trwy gynllunio''r siwrnai fel siwrnai drwodd.</p><br/>
<h4>Newidiwch fanylion pris y tocyn</h4>
<p>Ar waelod y dudalen, gallwch ddewis gweld effaith ymgeisio am gerdyn disgownt i brisiau''r tocynnau, neu weld a all prynu dau sengl fod yn rhatach na thocyn mynd a dod.</p><br/>
<p>Mae Transport Direct yn dangos prisiau tocynnau sydd ar gael i''w prynu yn unig. Mae''n gwneud hyn drwy edrych ar ddatabasau tocynnau mewn amser real, felly mae''n bosibl y bydd rhywfaint o oedi wrth gael gwybodaeth am brisiau''r tocynnau.</p><br/>
<h4>Gwybodaeth am gostau car</h4>
<p>Os yw eich siwrnai yn golygu defnyddio car neu gyfuniad o gludiant cyhoeddus a char, bydd gwybodaeth am gost eich siwrnai car, gan gynnwys costau tanwydd a chostau cysylltiedig eraill, pe dymunech edrych arnyn nhw.</p><br/>
<p>Os yw siwrnai yn ymwneud � ffer�au neu dollffyrdd, dangosir y costau ar gyfer y rhain, os ydynt yn wybyddus. I gael mwy o wybodaeth am ffer�au neu dollffyrdd yn eich siwrnai, cliciwch ar y gwasanaeth fferi neu ar enw'' dollffordd i''w chymryd i''r wefan berthnasol (e.e. www.m6toll.co.uk).</p><br/>
<p>Pan ydych wedi gorffen edrych ar docynnau, costau a gwybodaeth am brisiau tocynnau, gwasgwch ''Yn �l i''r crynodeb'' i barhau.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpRefineTickets'
,'<h3>View tickets, costs and fare information</h3><br/>
<h4>Public Transport ticket and fare information</h4>
<p>For the public transport elements of your journey, this page shows the available ticket types, the published fare for each ticket type and the associated flexibility.</p><br/>
<p>"Ticket type", in the Fares table, lists the tickets types. You can see more information about the ticket type by clicking on the name of the ticket. Ticket flexibility is shown as either "No", "Part" or "Full".</p><br/>
<div class="boxtypenineinner">
<div>
<ul>
<li><strong>No Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these types of tickets in advance for specified journeys. They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</li></ul></div>
<div>
<ul>
<li><strong>Part Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these tickets anytime, but travel is restricted to avoid certain times.</li></ul></div>
<div>
<ul>
<li><strong>Full Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</li></ul></div></div><br/>
<p>In some cases several legs of the journey can be included under one fare. The legs of the journey these fares cover are indicated at the top of the table (e.g. Fares: Brighton to Manchester Piccadilly). A blue outline around the details indicates which legs of the journey are included in this fare.</p><br/>
<p>Transport Direct may not have all fare information for all parts of the journey or all forms of transport used in the journey. You will need to buy tickets for these parts of your journey elsewhere.</p><br/>
<p>Please be aware that, if your overall journey is made up of several individual elements, it may be possible to get a cheaper fare by planning the journey as a through journey.</p><br/>
<h4>Change the fare details</h4>
<p>At the bottom of the page, you can choose to see the effect of applying a discount card to the fares, or seeing if in fact buying two singles may be cheaper than a return fare.</p><br/>
<p>Transport Direct only shows fares that are available to buy. It does this by checking ticket databases in real time, so there may be a slight delay in obtaining your fare information.</p><br/>
<h4>Car cost information</h4>
<p>If your journey involves using a car or a combination of public transport and car, there will be information about the cost of your car journey, including fuel costs and other associated costs, should you wish to view them.</p><br/>
<p>If the journey involves ferries or toll roads, the costs for these will be shown, if known. For more information on ferries or toll roads in your journey, click the ferry service or toll road name to be taken to the relevant website (e.g. <a href="http://www.m6toll.co.uk">www.m6toll.co.uk</a>).</p><br/>
<p>When you have finished viewing tickets, costs and fare information, press "Back to summary" to continue.</p>'
,'<h3>Edrychwch ar docynnau, costau a gwybodaeth am brisiau tocynnau</h3><br/>
<h4>Gwybodaeth am docynnau a phrisiau tocynnau cludiant cyhoeddus</h4>
<p>Ar gyfer elfennau cludiant cyhoeddus eich siwrnai, mae''r dudalen hon yn dangos y mathau o docynnau sydd ar gael, pris y tocynnau a gyhoeddwyd ar gyfer pob math o docyn a''r hyblygrwydd cysylltiedig.</p><br/>
<p>Mae''r ''Math o docyn'' yn y tabl prisiau tocynnau yn rhestru''r mathau o docynnau. Gallwch weld mwy o wybodaeth am y math o docyn drwy glicio ar enw''r tocyn. Dangosir hyblygrwydd y tocyn fel naill ai ''Nac ydynt'', ''Rhannol'' neu ''Llawn''.</p><br/>
<div class="boxtypenineinner">
<div>
<ul>
<li><strong>Dim Hyblygrwydd</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer siwrneion penodol. Maent ar gael mewn niferoedd cyfyngedig fel arfer, ar adegau penodol, ac ar wasanaethau penodol. Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf un diwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, nifer o ddyddiau ymlaen llaw), mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</li></ul></div>
<div>
<ul>
<li><strong>Hyblygrwydd Rhannol</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi rhai adegau arbennig.</li></ul></div>
<div>
<ul>
<li><strong>Hyblygrwydd Llawn</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod y maent yn ddilys. Mae''r rhain yn cynnwys tocynnau Agored a rhai tocynnau Dydd. Maent yn aml yn dda i deithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft, yr awr frys.</li></ul></div></div><br/>
<p>Mewn rhai achosion gellir cynnwys nifer o adrannau''r siwrnai o dan un pris tocyn. Nodir yr adrannau o''r siwrnai y mae''r tocynnau hyn yn ymdrin � nhw ar frig y tabl (e.e. Prisiau Tocynnau: Brighton i Manchester Piccadilly). Mae amlinelliad glas o amgylch y manylion yn nodi pa adrannau o''r siwrnai a gynhwysir yn y pris tocyn hwn.</p><br/>
<p>Mae''n bosib na fydd gan Transport Direct yr holl wybodaeth am brisiau tocynnau ar gyfer pob rhan o''r siwrnai neu pob ffurf ar gludiant a ddefnyddir yn y siwrnai hon. Bydd angen i chi brynu tocynnau ar gyfer y rhannau hyn o''r siwrnai mewn man arall.</p><br/>
<p>Cofiwch, os yw eich siwrnai gyffredinol yn cynnwys nifer o elfennau unigol, y gall fod yn bosib cael pris tocyn rhatach trwy gynllunio''r siwrnai fel siwrnai drwodd.</p><br/>
<h4>Newidiwch fanylion pris y tocyn</h4>
<p>Ar waelod y dudalen, gallwch ddewis gweld effaith ymgeisio am gerdyn disgownt i brisiau''r tocynnau, neu weld a all prynu dau sengl fod yn rhatach na thocyn mynd a dod.</p><br/>
<p>Mae Transport Direct yn dangos prisiau tocynnau sydd ar gael i''w prynu yn unig. Mae''n gwneud hyn drwy edrych ar ddatabasau tocynnau mewn amser real, felly mae''n bosibl y bydd rhywfaint o oedi wrth gael gwybodaeth am brisiau''r tocynnau.</p><br/>
<h4>Gwybodaeth am gostau car</h4>
<p>Os yw eich siwrnai yn golygu defnyddio car neu gyfuniad o gludiant cyhoeddus a char, bydd gwybodaeth am gost eich siwrnai car, gan gynnwys costau tanwydd a chostau cysylltiedig eraill, pe dymunech edrych arnyn nhw.</p><br/>
<p>Os yw siwrnai yn ymwneud � ffer�au neu dollffyrdd, dangosir y costau ar gyfer y rhain, os ydynt yn wybyddus. I gael mwy o wybodaeth am ffer�au neu dollffyrdd yn eich siwrnai, cliciwch ar y gwasanaeth fferi neu ar enw'' dollffordd i''w chymryd i''r wefan berthnasol (e.e. www.m6toll.co.uk).</p><br/>
<p>Pan ydych wedi gorffen edrych ar docynnau, costau a gwybodaeth am brisiau tocynnau, gwasgwch ''Yn �l i''r crynodeb'' i barhau.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpRefineTickets'
,'<h3>View tickets, costs and fare information</h3><br/>
<h4>Public Transport ticket and fare information</h4>
<p>For the public transport elements of your journey, this page shows the available ticket types, the published fare for each ticket type and the associated flexibility.</p><br/>
<p>"Ticket type", in the Fares table, lists the tickets types. You can see more information about the ticket type by clicking on the name of the ticket. Ticket flexibility is shown as either "No", "Part" or "Full".</p><br/>
<div class="boxtypenineinner">
<div>
<ul>
<li><strong>No Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these types of tickets in advance for specified journeys. They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</li></ul></div>
<div>
<ul>
<li><strong>Part Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these tickets anytime, but travel is restricted to avoid certain times.</li></ul></div>
<div>
<ul>
<li><strong>Full Flexibility</strong></li></ul></div>
<div>
<ul class="lister"><li>You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</li></ul></div></div><br/>
<p>In some cases several legs of the journey can be included under one fare. The legs of the journey these fares cover are indicated at the top of the table (e.g. Fares: Brighton to Manchester Piccadilly). A blue outline around the details indicates which legs of the journey are included in this fare.</p><br/>
<p>Transport Direct may not have all fare information for all parts of the journey or all forms of transport used in the journey. You will need to buy tickets for these parts of your journey elsewhere.</p><br/>
<p>Please be aware that, if your overall journey is made up of several individual elements, it may be possible to get a cheaper fare by planning the journey as a through journey.</p><br/>
<h4>Change the fare details</h4>
<p>At the bottom of the page, you can choose to see the effect of applying a discount card to the fares, or seeing if in fact buying two singles may be cheaper than a return fare.</p><br/>
<p>Transport Direct only shows fares that are available to buy. It does this by checking ticket databases in real time, so there may be a slight delay in obtaining your fare information.</p><br/>
<h4>Car cost information</h4>
<p>If your journey involves using a car or a combination of public transport and car, there will be information about the cost of your car journey, including fuel costs and other associated costs, should you wish to view them.</p><br/>
<p>If the journey involves ferries or toll roads, the costs for these will be shown, if known. For more information on ferries or toll roads in your journey, click the ferry service or toll road name to be taken to the relevant website (e.g. <a href="http://www.m6toll.co.uk">www.m6toll.co.uk</a>).</p><br/>
<p>When you have finished viewing tickets, costs and fare information, press "Back to summary" to continue.</p>'
,'<h3>Edrychwch ar docynnau, costau a gwybodaeth am brisiau tocynnau</h3><br/>
<h4>Gwybodaeth am docynnau a phrisiau tocynnau cludiant cyhoeddus</h4>
<p>Ar gyfer elfennau cludiant cyhoeddus eich siwrnai, mae''r dudalen hon yn dangos y mathau o docynnau sydd ar gael, pris y tocynnau a gyhoeddwyd ar gyfer pob math o docyn a''r hyblygrwydd cysylltiedig.</p><br/>
<p>Mae''r ''Math o docyn'' yn y tabl prisiau tocynnau yn rhestru''r mathau o docynnau. Gallwch weld mwy o wybodaeth am y math o docyn drwy glicio ar enw''r tocyn. Dangosir hyblygrwydd y tocyn fel naill ai ''Nac ydynt'', ''Rhannol'' neu ''Llawn''.</p><br/>
<div class="boxtypenineinner">
<div>
<ul>
<li><strong>Dim Hyblygrwydd</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer siwrneion penodol. Maent ar gael mewn niferoedd cyfyngedig fel arfer, ar adegau penodol, ac ar wasanaethau penodol. Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf un diwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, nifer o ddyddiau ymlaen llaw), mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</li></ul></div>
<div>
<ul>
<li><strong>Hyblygrwydd Rhannol</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi rhai adegau arbennig.</li></ul></div>
<div>
<ul>
<li><strong>Hyblygrwydd Llawn</strong></li></ul></div>
<div>
<ul class="lister"><li>Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod y maent yn ddilys. Mae''r rhain yn cynnwys tocynnau Agored a rhai tocynnau Dydd. Maent yn aml yn dda i deithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft, yr awr frys.</li></ul></div></div><br/>
<p>Mewn rhai achosion gellir cynnwys nifer o adrannau''r siwrnai o dan un pris tocyn. Nodir yr adrannau o''r siwrnai y mae''r tocynnau hyn yn ymdrin � nhw ar frig y tabl (e.e. Prisiau Tocynnau: Brighton i Manchester Piccadilly). Mae amlinelliad glas o amgylch y manylion yn nodi pa adrannau o''r siwrnai a gynhwysir yn y pris tocyn hwn.</p><br/>
<p>Mae''n bosib na fydd gan Transport Direct yr holl wybodaeth am brisiau tocynnau ar gyfer pob rhan o''r siwrnai neu pob ffurf ar gludiant a ddefnyddir yn y siwrnai hon. Bydd angen i chi brynu tocynnau ar gyfer y rhannau hyn o''r siwrnai mewn man arall.</p><br/>
<p>Cofiwch, os yw eich siwrnai gyffredinol yn cynnwys nifer o elfennau unigol, y gall fod yn bosib cael pris tocyn rhatach trwy gynllunio''r siwrnai fel siwrnai drwodd.</p><br/>
<h4>Newidiwch fanylion pris y tocyn</h4>
<p>Ar waelod y dudalen, gallwch ddewis gweld effaith ymgeisio am gerdyn disgownt i brisiau''r tocynnau, neu weld a all prynu dau sengl fod yn rhatach na thocyn mynd a dod.</p><br/>
<p>Mae Transport Direct yn dangos prisiau tocynnau sydd ar gael i''w prynu yn unig. Mae''n gwneud hyn drwy edrych ar ddatabasau tocynnau mewn amser real, felly mae''n bosibl y bydd rhywfaint o oedi wrth gael gwybodaeth am brisiau''r tocynnau.</p><br/>
<h4>Gwybodaeth am gostau car</h4>
<p>Os yw eich siwrnai yn golygu defnyddio car neu gyfuniad o gludiant cyhoeddus a char, bydd gwybodaeth am gost eich siwrnai car, gan gynnwys costau tanwydd a chostau cysylltiedig eraill, pe dymunech edrych arnyn nhw.</p><br/>
<p>Os yw siwrnai yn ymwneud � ffer�au neu dollffyrdd, dangosir y costau ar gyfer y rhain, os ydynt yn wybyddus. I gael mwy o wybodaeth am ffer�au neu dollffyrdd yn eich siwrnai, cliciwch ar y gwasanaeth fferi neu ar enw'' dollffordd i''w chymryd i''r wefan berthnasol (e.e. www.m6toll.co.uk).</p><br/>
<p>Pan ydych wedi gorffen edrych ar docynnau, costau a gwybodaeth am brisiau tocynnau, gwasgwch ''Yn �l i''r crynodeb'' i barhau.</p>'

GO

-- help page contenet for ExtendJourneyInput.aspx page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpExtendInput'
,'<h3>Specify the location where you wish to add a connecting journey</h3><br/><br/>
<p>You have chosen to add a connecting journey to your main journey.</p><br/>
<p>This page allows you to enter the name of the place at which you will either be starting or ending your completed journey.</p><br/>
<p>The diagram shows you the journey so far. The grey part of the diagram shows the end of your current journey on which you have chosen to add a connecting journey.</p><br/>
<p>Similarly to the other journey planners in Transport Direct, you can choose the location and specify whether it is a station/airport, city/town/suburb, address/postcode, attraction/facility, or an actual transport stop (e.g. a bus stop). You can also choose to see journey options using either public transport or car or both.</p><br/>
<p>In addition, you can choose to allow a fixed time at a location before making the connecting journey. Transport Direct will add this time to the original journey in order to match your "Stopover" time.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>You have planned a journey from Lancaster to Carlisle. You want to see options for the connecting journeys to Workington, but would like to have some time in Carlisle to explore the town. Choose a stopover time of 2 hours on this page. Then press "Next".</li>
<li>Transport Direct will find journey options based on your choices.</li></ul></div></div><br/>
<p>If, when choosing a connecting journey, you would like to be more specific about exactly how to travel, choose "Advanced options". Here you will find ways to restrict certain types of transport, or certain routes, or ask for only direct services.</p><br/>
<p>If you decide none of the options are suitable, press "Back" to return to your original journey options.</p>'
,'<h3>Nodwch y lleoliad ble dymunwch ychwanegu siwrnai gysylltiol</h3><br/><br/>
<p>Rydych wedi dewis ychwanegu siwrnai gysylltiol at eich prif siwrnai.</p><br/>
<p>Mae''r dudalen hon yn caniat�u i chi roi enw''r lle y byddwch yn dechrau neu yn diweddu eich siwrnai derfynol.</p><br/>
<p>Mae''r diagram yn dangos y siwrnai i chi hyd yma.  Mae rhan llwyd y diagram yn dangos pen eich siwrnai gyfredol lle rydych wedi dewis ychwanegu siwrnai gysylltiol.</p><br/>
<p>Yn debyg i''r cynllunwyr siwrneion eraill yn Transport Direct, gallwch ddewis y lleoliad a nodi a yw yn orsaf/maes awyr, dinas/tref/maestref, cyfeiriad/c�d post, atyniad/cyfleuster neu yn arhosfan cludiant gwirioneddol (e.e. arhosfan bws).  Gallwch hefyd ddewis gweld dewisiadau siwrnai gan ddefnyddio naill ai cludiant cyhoeddus neu gar neu''r ddau.</p><br/>
<p>Yn ychwanegol, gallwch ddewis caniat�u amser penodol mewn lleoliad cyn gwneud y siwrnai gysylltiol.  Bydd Transport Direct yn ychwanegu''r amser hwn at y siwrnai wreiddiol er mwyn cyfateb eich amser ''Aros drosodd''.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Rydych wedi cynllunio siwrnai o Lancaster i Carlisle.  Rydych yn dymuno gweld dewisiadau ar gyfer y siwrneion cysylltiol i Workington, ond hoffech gael peth amser yn Carlisle i weld y dref.  Dewiswch ddwy awr o amser i aros yn ychwanegol yma ar y dudalen hon, yna gwasgwch ''Nesaf''.</li>
<li>Bydd Transport Direct yn dod o hyd i ddewisiadau siwrnai yn seiliedig ar eich dewisiadau.</li></ul></div></div><br/>
<p>Os wrth ddewis siwrnai gysylltiol, yr hoffech fod yn fwy penodol am yn union sut i deithio, dewiswch ''Dewisiadau mwy cymhleth''.  Yma fe welwch ffyrdd o gyfyngu ar rai mathau arbennig o gludiant, neu rai llwybrau arbennig, neu ofyn am wasanaethau uniongyrchol yn unig.</p><br/>
<p>Os penderfynwch nad oes unrhyw rai o''r dewisiadau yn addas, gwasgwch ''Yn �l'' i ddychwelyd i''ch dewisiadau siwrnai gwreiddiol.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpExtendInput'
,'<h3>Specify the location where you wish to add a connecting journey</h3><br/><br/>
<p>You have chosen to add a connecting journey to your main journey.</p><br/>
<p>This page allows you to enter the name of the place at which you will either be starting or ending your completed journey.</p><br/>
<p>The diagram shows you the journey so far. The grey part of the diagram shows the end of your current journey on which you have chosen to add a connecting journey.</p><br/>
<p>Similarly to the other journey planners in Transport Direct, you can choose the location and specify whether it is a station/airport, city/town/suburb, address/postcode, attraction/facility, or an actual transport stop (e.g. a bus stop). You can also choose to see journey options using either public transport or car or both.</p><br/>
<p>In addition, you can choose to allow a fixed time at a location before making the connecting journey. Transport Direct will add this time to the original journey in order to match your "Stopover" time.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>You have planned a journey from Lancaster to Carlisle. You want to see options for the connecting journeys to Workington, but would like to have some time in Carlisle to explore the town. Choose a stopover time of 2 hours on this page. Then press "Next".</li>
<li>Transport Direct will find journey options based on your choices.</li></ul></div></div><br/>
<p>If, when choosing a connecting journey, you would like to be more specific about exactly how to travel, choose "Advanced options". Here you will find ways to restrict certain types of transport, or certain routes, or ask for only direct services.</p><br/>
<p>If you decide none of the options are suitable, press "Back" to return to your original journey options.</p>'
,'<h3>Nodwch y lleoliad ble dymunwch ychwanegu siwrnai gysylltiol</h3><br/><br/>
<p>Rydych wedi dewis ychwanegu siwrnai gysylltiol at eich prif siwrnai.</p><br/>
<p>Mae''r dudalen hon yn caniat�u i chi roi enw''r lle y byddwch yn dechrau neu yn diweddu eich siwrnai derfynol.</p><br/>
<p>Mae''r diagram yn dangos y siwrnai i chi hyd yma.  Mae rhan llwyd y diagram yn dangos pen eich siwrnai gyfredol lle rydych wedi dewis ychwanegu siwrnai gysylltiol.</p><br/>
<p>Yn debyg i''r cynllunwyr siwrneion eraill yn Transport Direct, gallwch ddewis y lleoliad a nodi a yw yn orsaf/maes awyr, dinas/tref/maestref, cyfeiriad/c�d post, atyniad/cyfleuster neu yn arhosfan cludiant gwirioneddol (e.e. arhosfan bws).  Gallwch hefyd ddewis gweld dewisiadau siwrnai gan ddefnyddio naill ai cludiant cyhoeddus neu gar neu''r ddau.</p><br/>
<p>Yn ychwanegol, gallwch ddewis caniat�u amser penodol mewn lleoliad cyn gwneud y siwrnai gysylltiol.  Bydd Transport Direct yn ychwanegu''r amser hwn at y siwrnai wreiddiol er mwyn cyfateb eich amser ''Aros drosodd''.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Rydych wedi cynllunio siwrnai o Lancaster i Carlisle.  Rydych yn dymuno gweld dewisiadau ar gyfer y siwrneion cysylltiol i Workington, ond hoffech gael peth amser yn Carlisle i weld y dref.  Dewiswch ddwy awr o amser i aros yn ychwanegol yma ar y dudalen hon, yna gwasgwch ''Nesaf''.</li>
<li>Bydd Transport Direct yn dod o hyd i ddewisiadau siwrnai yn seiliedig ar eich dewisiadau.</li></ul></div></div><br/>
<p>Os wrth ddewis siwrnai gysylltiol, yr hoffech fod yn fwy penodol am yn union sut i deithio, dewiswch ''Dewisiadau mwy cymhleth''.  Yma fe welwch ffyrdd o gyfyngu ar rai mathau arbennig o gludiant, neu rai llwybrau arbennig, neu ofyn am wasanaethau uniongyrchol yn unig.</p><br/>
<p>Os penderfynwch nad oes unrhyw rai o''r dewisiadau yn addas, gwasgwch ''Yn �l'' i ddychwelyd i''ch dewisiadau siwrnai gwreiddiol.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpExtendInput'
,'<h3>Specify the location where you wish to add a connecting journey</h3><br/><br/>
<p>You have chosen to add a connecting journey to your main journey.</p><br/>
<p>This page allows you to enter the name of the place at which you will either be starting or ending your completed journey.</p><br/>
<p>The diagram shows you the journey so far. The grey part of the diagram shows the end of your current journey on which you have chosen to add a connecting journey.</p><br/>
<p>Similarly to the other journey planners in Transport Direct, you can choose the location and specify whether it is a station/airport, city/town/suburb, address/postcode, attraction/facility, or an actual transport stop (e.g. a bus stop). You can also choose to see journey options using either public transport or car or both.</p><br/>
<p>In addition, you can choose to allow a fixed time at a location before making the connecting journey. Transport Direct will add this time to the original journey in order to match your "Stopover" time.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>You have planned a journey from Lancaster to Carlisle. You want to see options for the connecting journeys to Workington, but would like to have some time in Carlisle to explore the town. Choose a stopover time of 2 hours on this page. Then press "Next".</li>
<li>Transport Direct will find journey options based on your choices.</li></ul></div></div><br/>
<p>If, when choosing a connecting journey, you would like to be more specific about exactly how to travel, choose "Advanced options". Here you will find ways to restrict certain types of transport, or certain routes, or ask for only direct services.</p><br/>
<p>If you decide none of the options are suitable, press "Back" to return to your original journey options.</p>'
,'<h3>Nodwch y lleoliad ble dymunwch ychwanegu siwrnai gysylltiol</h3><br/><br/>
<p>Rydych wedi dewis ychwanegu siwrnai gysylltiol at eich prif siwrnai.</p><br/>
<p>Mae''r dudalen hon yn caniat�u i chi roi enw''r lle y byddwch yn dechrau neu yn diweddu eich siwrnai derfynol.</p><br/>
<p>Mae''r diagram yn dangos y siwrnai i chi hyd yma.  Mae rhan llwyd y diagram yn dangos pen eich siwrnai gyfredol lle rydych wedi dewis ychwanegu siwrnai gysylltiol.</p><br/>
<p>Yn debyg i''r cynllunwyr siwrneion eraill yn Transport Direct, gallwch ddewis y lleoliad a nodi a yw yn orsaf/maes awyr, dinas/tref/maestref, cyfeiriad/c�d post, atyniad/cyfleuster neu yn arhosfan cludiant gwirioneddol (e.e. arhosfan bws).  Gallwch hefyd ddewis gweld dewisiadau siwrnai gan ddefnyddio naill ai cludiant cyhoeddus neu gar neu''r ddau.</p><br/>
<p>Yn ychwanegol, gallwch ddewis caniat�u amser penodol mewn lleoliad cyn gwneud y siwrnai gysylltiol.  Bydd Transport Direct yn ychwanegu''r amser hwn at y siwrnai wreiddiol er mwyn cyfateb eich amser ''Aros drosodd''.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Rydych wedi cynllunio siwrnai o Lancaster i Carlisle.  Rydych yn dymuno gweld dewisiadau ar gyfer y siwrneion cysylltiol i Workington, ond hoffech gael peth amser yn Carlisle i weld y dref.  Dewiswch ddwy awr o amser i aros yn ychwanegol yma ar y dudalen hon, yna gwasgwch ''Nesaf''.</li>
<li>Bydd Transport Direct yn dod o hyd i ddewisiadau siwrnai yn seiliedig ar eich dewisiadau.</li></ul></div></div><br/>
<p>Os wrth ddewis siwrnai gysylltiol, yr hoffech fod yn fwy penodol am yn union sut i deithio, dewiswch ''Dewisiadau mwy cymhleth''.  Yma fe welwch ffyrdd o gyfyngu ar rai mathau arbennig o gludiant, neu rai llwybrau arbennig, neu ofyn am wasanaethau uniongyrchol yn unig.</p><br/>
<p>Os penderfynwch nad oes unrhyw rai o''r dewisiadau yn addas, gwasgwch ''Yn �l'' i ddychwelyd i''ch dewisiadau siwrnai gwreiddiol.</p>'

GO

-- help page contenet for ExtendedFullItinerarySummary.aspx page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpExtendedFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by adding a connecting journey to your main journey plan.</p><br/>
<p>The diagram shows each of the places you have used in building this journey and indicates if the journey is one-way or a return.</p><br/>
<p>This page gives a summarised view of the complete journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the whole journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p><br/>
<h4>Is this journey complete?</h4>
<p>Transport Direct allows you to add up to two additional journeys to your main journey.</p>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your main journey is a flight from Heathrow to Glasgow.</li> 
<li>You have added a connecting journey from Glasgow airport to your meeting using a car/taxi.</li> 
<li>You can now add one further journey to the main journey. Perhaps you would like to see journey options from your home to Heathrow using public transport. </li></ul></div></div>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy ychwanegu siwrnai gysylltiol at eich prif gynllun siwrnai.</p><br/>
<p>Mae''r diagram yn dangos pob un o''r lleoedd rydych wedi eu defnyddio i greu''r siwrnai hon ac mae''n nodi a yw''r siwrnai yn mynd un ffordd neu yn siwrnai yn �l ac ymlaen.</p><br/>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyflawn.  Mae''n dangos yr holl fathau o gludiant y mae angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau.  Mae''n dangos pa bryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai i gyd ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai.  Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda''ch cais am siwrnai newydd.</p><br/>
<h4>A yw''r siwrnai hon yn gyflawn?</h4>
<p>Mae Transport Direct yn caniat�u i chi ychwanegu hyd at ddwy siwrnai ychwanegol at eich prif siwrnai.</p>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Mae eich prif siwrnai yn hedfaniad o Heathrow i Glasgow.</li> 
<li>Rydych wedi ychwanegu siwrnai gysylltiol o faes awyr Glasgow i''ch cyfarfod gan ddefnyddio car/tacsi.</li> 
<li>Gallwch yn awr ychwanegu un siwrnai arall at y brif siwrnai.  Efallai yr hoffech weld dewisiadau siwrneion o''ch cartref i Heathrow gan ddefnyddio cludiant cyhoeddus. </li></ul></div></div>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpExtendedFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by adding a connecting journey to your main journey plan.</p><br/>
<p>The diagram shows each of the places you have used in building this journey and indicates if the journey is one-way or a return.</p><br/>
<p>This page gives a summarised view of the complete journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the whole journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p><br/>
<h4>Is this journey complete?</h4>
<p>Transport Direct allows you to add up to two additional journeys to your main journey.</p>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your main journey is a flight from Heathrow to Glasgow.</li> 
<li>You have added a connecting journey from Glasgow airport to your meeting using a car/taxi.</li> 
<li>You can now add one further journey to the main journey. Perhaps you would like to see journey options from your home to Heathrow using public transport. </li></ul></div></div>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy ychwanegu siwrnai gysylltiol at eich prif gynllun siwrnai.</p><br/>
<p>Mae''r diagram yn dangos pob un o''r lleoedd rydych wedi eu defnyddio i greu''r siwrnai hon ac mae''n nodi a yw''r siwrnai yn mynd un ffordd neu yn siwrnai yn �l ac ymlaen.</p><br/>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyflawn.  Mae''n dangos yr holl fathau o gludiant y mae angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau.  Mae''n dangos pa bryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai i gyd ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai.  Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda''ch cais am siwrnai newydd.</p><br/>
<h4>A yw''r siwrnai hon yn gyflawn?</h4>
<p>Mae Transport Direct yn caniat�u i chi ychwanegu hyd at ddwy siwrnai ychwanegol at eich prif siwrnai.</p>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Mae eich prif siwrnai yn hedfaniad o Heathrow i Glasgow.</li> 
<li>Rydych wedi ychwanegu siwrnai gysylltiol o faes awyr Glasgow i''ch cyfarfod gan ddefnyddio car/tacsi.</li> 
<li>Gallwch yn awr ychwanegu un siwrnai arall at y brif siwrnai.  Efallai yr hoffech weld dewisiadau siwrneion o''ch cartref i Heathrow gan ddefnyddio cludiant cyhoeddus. </li></ul></div></div>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpExtendedFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by adding a connecting journey to your main journey plan.</p><br/>
<p>The diagram shows each of the places you have used in building this journey and indicates if the journey is one-way or a return.</p><br/>
<p>This page gives a summarised view of the complete journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the whole journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p><br/>
<h4>Is this journey complete?</h4>
<p>Transport Direct allows you to add up to two additional journeys to your main journey.</p>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your main journey is a flight from Heathrow to Glasgow.</li> 
<li>You have added a connecting journey from Glasgow airport to your meeting using a car/taxi.</li> 
<li>You can now add one further journey to the main journey. Perhaps you would like to see journey options from your home to Heathrow using public transport. </li></ul></div></div>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy ychwanegu siwrnai gysylltiol at eich prif gynllun siwrnai.</p><br/>
<p>Mae''r diagram yn dangos pob un o''r lleoedd rydych wedi eu defnyddio i greu''r siwrnai hon ac mae''n nodi a yw''r siwrnai yn mynd un ffordd neu yn siwrnai yn �l ac ymlaen.</p><br/>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyflawn.  Mae''n dangos yr holl fathau o gludiant y mae angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau.  Mae''n dangos pa bryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai i gyd ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai.  Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda''ch cais am siwrnai newydd.</p><br/>
<h4>A yw''r siwrnai hon yn gyflawn?</h4>
<p>Mae Transport Direct yn caniat�u i chi ychwanegu hyd at ddwy siwrnai ychwanegol at eich prif siwrnai.</p>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Mae eich prif siwrnai yn hedfaniad o Heathrow i Glasgow.</li> 
<li>Rydych wedi ychwanegu siwrnai gysylltiol o faes awyr Glasgow i''ch cyfarfod gan ddefnyddio car/tacsi.</li> 
<li>Gallwch yn awr ychwanegu un siwrnai arall at y brif siwrnai.  Efallai yr hoffech weld dewisiadau siwrneion o''ch cartref i Heathrow gan ddefnyddio cludiant cyhoeddus. </li></ul></div></div>'

GO

-- help page content for RefineMap.aspx page
EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelRefineMap'
,'<p>You can view specific stages of the journey in more detail:<br/>     1.    Select the journey stage from the drop-down list<br/>     2.    Click ''Show route''<br/><br/>Click ''Printer friendly'' to open a printer-friendly page that you can print as usual.<br/><br/>You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow).  They include transport symbols (shown automatically) and a range of attraction and facility symbols.<br/><br/>To show or hide any of these symbols, you must:<br/>1. Click on a category radio button e.g. ''Accommodation''<br/>2. Tick or untick the boxes next to the symbols<br/>3. Click ''Show selected symbols''</p><br/><br/><p>The colour coding used on the map may show traffic levels as:</p><ul><li>Low traffic</li><li>Medium traffic</li><li>High traffic</li><li>Traffic unknown</li></ul><p>�</p><p>Low, medium and high traffic levels are based upon past traffic measurements provided by the Highways Agency, the Welsh Assembly and the Scottish Executive. These take into consideration the road, the direction, and the day and time of travel. Where "Traffic unknown" is shown, no traffic measurements are available for the specific roads, so estimated traffic speeds for the time, day and type of road are used in planning the journey (based on the National Traffic Model).</p><br/>'
,'<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>     1.    Dewiswch gam y siwrnai fel rhestr a ollyngir i lawr<br/>     2.    Cliciwch ar ''Dangoswch y Llwybr''<br/><br/>Cliciwch ar ''Hawdd ei argraffu'' i agor tudalen briodol y gallwch ei hargraffu fel arfer<br/><br/>Gallwch weld symbolau ar y map pan fo wedi ei chwyddo''n fawr (o fewn y pump lefel chwyddo mwyaf a amlinellir mewn melyn).  Maent yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac amrywiaeth o symbolau atyniadau a chyfleusterau <br/><br/>I ddangos neu guddio unrhyw rai o''r symbolau hyn, rhaid i chi:<br/>1. Glicio ar fotwm radio a dewis categori e.e. ''Llety''<br/>2. Dicio neu ddad-dicio''r blychau ger y symbolau<br/>3. Glicio ar ''Dewiswch symbolau detholedig''</p><br/><br/><p>Mae''n bosibl y bydd y c�d lliw ar y map yn dangos lefelau trafnidiaeth fel:</p><ul><li>Traffig isel</li><li>Traffig canolig</li><li>Traffig uchel</li><li>Traffig anhysbys</li></ul><p>�</p><p>Mae lefelau trafnidiaeth isel, canolig ac uchel yn seiliedig ar fesurau traffig y gorffennol a ddarparwyd gan Awdurdod y Priffyrdd, Cynulliad Cenedlaethol Cymru a Gweithrediaeth yr Alban. Mae''r rhain yn cymryd y ffordd, y cyfeiriad a diwrnod ac amser teithio i ystyriaeth. Lle dangosir "Traffig anhysbys", nid oes mesuriadau traffig ar gael ar gyfer y ffyrdd penodol, felly defnyddir amcangyfrif o gyflymderau traffig ar gyfer yr amser, y diwrnod a''r math o ffordd wrth gynllunio''r siwrnai (yn seiliedig ar Model Traffig Cenedlaethol).</p><br/>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpMapPublic'
,'<h1><strong>Map of selected public transport journey</strong></h1>
<p><strong></strong>&nbsp;</p>
<p>This page shows the selected public transport journey route.</p>
<p>&nbsp;</p>
<p>The various coloured and patterned route sections show different types of transport (and walking). There is a key next to the map to show you which section is what type of transport.</p>
<p>&nbsp;</p>
<p>The initial map shows the full route, including all stages of the journey and all types of transport.</p>
<p>&nbsp;</p>
<p>You can view specific stages of the journey in more detail:<br/>1. Select the journey stage from the dropdown list e.g. ''Train 1''<br/>2. Click ''Show route''</p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<h1><strong>Map o''r siwrnai ddetholedig ar gludiant cyhoeddus </strong></h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos y siwrnai ddetholedig ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<p>Dengys yr adrannau o''r llwybr sydd wedi eu lliwio a''r rhai patrymog wahanaol fathau o gludiant (a cherdded).&nbsp; Mae allwedd ger y map i ddangos i chi pa adran yw pa fath o gludiant</p>
<p>&nbsp;</p>
<p>Mae''r map dechreuol yn dangos y llwybr llawn, gan gynnwys pob cam o''r siwrnai a phob math o gludiant.</p>
<p>&nbsp;</p>
<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>1. Dewiswch gam y siwrnai o''r rhestr a ollyngir i lawr e.e. ''Tr�n 1''<br/>2. Cliciwch ar ''Dangoswch lwybr''</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawdd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpMapPublic'
,'<h1><strong>Map of selected public transport journey</strong></h1>
<p><strong></strong>&nbsp;</p>
<p>This page shows the selected public transport journey route.</p>
<p>&nbsp;</p>
<p>The various coloured and patterned route sections show different types of transport (and walking). There is a key next to the map to show you which section is what type of transport.</p>
<p>&nbsp;</p>
<p>The initial map shows the full route, including all stages of the journey and all types of transport.</p>
<p>&nbsp;</p>
<p>You can view specific stages of the journey in more detail:<br/>1. Select the journey stage from the dropdown list e.g. ''Train 1''<br/>2. Click ''Show route''</p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<h1><strong>Map o''r siwrnai ddetholedig ar gludiant cyhoeddus </strong></h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos y siwrnai ddetholedig ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<p>Dengys yr adrannau o''r llwybr sydd wedi eu lliwio a''r rhai patrymog wahanaol fathau o gludiant (a cherdded).&nbsp; Mae allwedd ger y map i ddangos i chi pa adran yw pa fath o gludiant</p>
<p>&nbsp;</p>
<p>Mae''r map dechreuol yn dangos y llwybr llawn, gan gynnwys pob cam o''r siwrnai a phob math o gludiant.</p>
<p>&nbsp;</p>
<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>1. Dewiswch gam y siwrnai o''r rhestr a ollyngir i lawr e.e. ''Tr�n 1''<br/>2. Cliciwch ar ''Dangoswch lwybr''</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawdd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpMapPublic'
,'<h1><strong>Map of selected public transport journey</strong></h1>
<p><strong></strong>&nbsp;</p>
<p>This page shows the selected public transport journey route.</p>
<p>&nbsp;</p>
<p>The various coloured and patterned route sections show different types of transport (and walking). There is a key next to the map to show you which section is what type of transport.</p>
<p>&nbsp;</p>
<p>The initial map shows the full route, including all stages of the journey and all types of transport.</p>
<p>&nbsp;</p>
<p>You can view specific stages of the journey in more detail:<br/>1. Select the journey stage from the dropdown list e.g. ''Train 1''<br/>2. Click ''Show route''</p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<h1><strong>Map o''r siwrnai ddetholedig ar gludiant cyhoeddus </strong></h1>
<p><strong></strong>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos y siwrnai ddetholedig ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<p>Dengys yr adrannau o''r llwybr sydd wedi eu lliwio a''r rhai patrymog wahanaol fathau o gludiant (a cherdded).&nbsp; Mae allwedd ger y map i ddangos i chi pa adran yw pa fath o gludiant</p>
<p>&nbsp;</p>
<p>Mae''r map dechreuol yn dangos y llwybr llawn, gan gynnwys pob cam o''r siwrnai a phob math o gludiant.</p>
<p>&nbsp;</p>
<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:<br/>1. Dewiswch gam y siwrnai o''r rhestr a ollyngir i lawr e.e. ''Tr�n 1''<br/>2. Cliciwch ar ''Dangoswch lwybr''</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawdd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

GO

-- Departure Board page soft content
EXEC AddtblContent
1, 1, 'langStrings', 'DepartureBoard.Bus.1.Description'
,'Live bus stop departures for routes in:
			<ul><li>Preston </li></ul>'
,'Ymadawiadau arosfannau bws bwy ar gyfer llwybrau yn:
			<ul><li>Preston </li></ul>'

EXEC AddtblContent
1, 1, 'langStrings', 'DepartureBoard.Bus.2.Description'
,'Live bus stop departures and current bus locations for routes in:
			<ul><li>Bristol; </li>
			<li>Cardiff; </li>
			<li>Gwynedd &amp; Conwy; </li>
			<li>Gloucestershire; </li>
			<li>Nottingham; and </li>
			<li>Surrey </li></ul>'
,'Ymadawiadau arosfannau bws bwy ar gyfer llwybrau yn:
			<ul><li>Bryste; </li>
			<li>Caerdydd; </li>
			<li>Gwynedd a Conwy; </li>
			<li>Gloucester; </li>
			<li>Nottingham; a </li>
			<li>Surrey </li></ul>'

EXEC AddtblContent
1, 1, 'langStrings', 'DepartureBoard.Bus.3.Description'
,'Live bus stop departures plus details of live SMS updates for routes in:
			<ul><li>Leicester; </li>
			<li>Leicestershire; and </li>
			<li>Loughborough </li></ul>'
,'Ymadawiadau arosfannau bws byw a manylion am ddiweddariadau SMS byw ar gyfer llwybrau yn:
			<ul><li>Caerl r; </li>
			<li>Swydd Caerl r; a </li>
			<li>Loughborough </li></ul>'

EXEC AddtblContent
1, 1, 'langStrings', 'DepartureBoard.Bus.4.Description'
,'Live bus stop departures for routes in:
			<ul><li>Brighton and Hove</li></ul>'
,'Ymadawiadau arosfannau bws bwy ar gyfer llwybrau yn:
			<ul><li>Brighton and Hove</li></ul>'

EXEC AddtblContent
1, 1, 'langStrings', 'DepartureBoard.Bus.5.Description'
,'Live bus stop departures for routes in:
			<ul><li>Birmingham</li></ul>'
,'Ymadawiadau arosfannau bws bwy ar gyfer llwybrau yn:
			<ul><li>Birmingham</li></ul>'

EXEC AddtblContent
1, 1, 'langStrings', 'DepartureBoards.TopOfPage.HyperlinkImage.AlternateText'
,'Top of page'
,'Yn �l i''r brig'

GO

-- Find A Station page help for ambiguity

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindAStationAmbiguity'
,'<p>Choose a location from the yellow drop-down list.<br />If you cannot find the location you want in the list, you can either: </p>
<ul><li>Search for a different kind of location (e.g. by selecting "Address/postcode")</li></ul>
<p>&nbsp;</p>
<ul><li>Enter a new location (by clicking "New location")</li></ul>
<p>&nbsp;</p>
<p>Then click "Next".</p>'
,
'<p>Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br />Os na ellwch ddod o hyd i''r lleoliad yr ydych am ei gael yn y rhestr hon, gellwch naill ai: </p>
<ul><li>Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</li></ul>
<p>&nbsp;</p>
<ul><li>Rhoi lleoliad newydd (wrth glicio ar ''Lleoliad newydd'')</li></ul>
<p>&nbsp;</p>
<p>Yna cliciwch ''Nesa''.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAStationAmbiguity'
,'<p>Choose a location from the yellow drop-down list.<br />If you cannot find the location you want in the list, you can either: </p>
<ul>
<li>Search for a different kind of location (e.g. by selecting "Address/postcode")</li></ul>
<p>&nbsp;</p>
<ul>
<li>Enter a new location (by clicking "New location")</li></ul>
<p>&nbsp;</p>
<p>Then click "Next". </p>'
,
'<p>Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br />Os na ellwch ddod o hyd i''r lleoliad yr ydych am ei gael yn y rhestr hon, gellwch naill ai: </p>
<ul>
<li>Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</li></ul>
<p>&nbsp;</p>
<ul>
<li>Rhoi lleoliad newydd (wrth glicio ar ''Lleoliad newydd'')</li></ul>
<p>&nbsp;</p>
<p>Yna cliciwch ''Nesa''. </p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAStationAmbiguity'
,'<p>Choose a location from the yellow drop-down list.<br />If you cannot find the location you want in the list, you can either: </p>
<ul>
<li>Search for a different kind of location (e.g. by selecting "Address/postcode")</li></ul>
<p>&nbsp;</p>
<ul>
<li>Enter a new location (by clicking "New location")</li></ul>
<p>&nbsp;</p>
<p>Then click "Next". </p>'
,
'<p>Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br />Os na ellwch ddod o hyd i''r lleoliad yr ydych am ei gael yn y rhestr hon, gellwch naill ai: </p>
<ul>
<li>Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</li></ul>
<p>&nbsp;</p>
<ul>
<li>Rhoi lleoliad newydd (wrth glicio ar ''Lleoliad newydd'')</li></ul>
<p>&nbsp;</p>
<p>Yna cliciwch ''Nesa''. </p>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1234
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO