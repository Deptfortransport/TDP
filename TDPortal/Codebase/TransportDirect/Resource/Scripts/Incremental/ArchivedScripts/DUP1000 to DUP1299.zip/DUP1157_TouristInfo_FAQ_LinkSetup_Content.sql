-- ***********************************************
-- NAME 		: DUP1157_TouristInof_FAQ_LinkSetup_Content.sql
-- DESCRIPTION 		: Script to add new FAQ link for Visit Britain Tourist Info
-- AUTHOR		: D. Scott Angle
-- DATE			: 27 Oct 2008
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Tourist Info FAQ page - url
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- FAQ Tourist Info - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpTouristInfo', 'Page',
'/Web2/staticnoprint.aspx',
'/Web2/staticnoprint.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpTouristInfo', 'QueryString',
'staticnoprint',
'staticnoprint'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpTouristInfo', 'Channel',
'/Channels/TransportDirect/Help/HelpTouristInfo',
'/Channels/TransportDirect/Help/HelpTouristInfo'

-- FAQ Cycle Planning - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpTouristInfo', 'Page',
'/Web2/staticdefault.aspx',
'/Web2/staticdefault.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpTouristInfo', 'QueryString',
'staticdefault',
'staticdefault'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpTouristInfo', 'Channel',
'/Channels/TransportDirect/Printer/HelpTouristInfo',
'/Channels/TransportDirect/Printer/HelpTouristInfo'


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1157
SET @ScriptDesc = 'Script to add new FAQ link for Visit Britain Tourist Info'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO