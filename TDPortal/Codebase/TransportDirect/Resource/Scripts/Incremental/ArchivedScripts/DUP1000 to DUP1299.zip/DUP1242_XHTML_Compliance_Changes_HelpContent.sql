-- ***********************************************
-- NAME 		: DUP1242_XHTML_Compliance_Changes_HelpContent.sql
-- DESCRIPTION 		: Update help content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 19 January 2008
-- ************************************************

USE [Content]
GO

-- find car park results page help content
EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkResultsHelpLabelSelectFromTo'
,'You will see a list of the nearest car parks. The closest car park is already selected. You can either:<br/><br/>� Click "Drive from"/"Drive to" to select this car park for journey planning<br/>� Select the radio button of the car park that you are interested in and then click "Drive from"/"Drive to"<br/><br/>You can see the car parks on a map by clicking "Show map"<br/>'
,'Fe welwch restr o''r meysydd parcio agosaf.  Mae''r maes parcio agosaf wedi ei ddewis yn barod.  Gallwch naill ai:<br/><br/>� Glicio ''Gyrrwch o/Gyrrwch i'' i ddewis y maes parcio hwn i bwrpas cynllunio''r siwrnai<br/>� Ddewis botwm radio''r maes parcio y mae gennych ddiddordeb ynddo ac yna clicio ''Gyrrwch o''/''Gyrrwch i''<br/><br/>Gallwch weld y meysydd parcio ar fap drwy glicio ''Dangoswch fap''<br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkResultsHelpLabelSelectNext'
,'You will see a list of the nearest car parks. The closest car park is already selected. You can either:<br/><br/>� Click "Next" to select this car park for journey planning<br/>� Select the radio button of the car park that you are interested in and click "Next"<br/><br/>You can see the car parks on a map by clicking "Show map"<br/>'
,'Fe welwch restr o''r meysydd parcio agosaf.  Mae''r maes parcio agosaf wedi ei ddewis yn barod.  Gallwch naill ai:<br/><br/>� Glicio ''Gyrrwch o/Gyrrwch i'' i ddewis y maes parcio hwn i bwrpas cynllunio''r siwrnai<br/>� Ddewis botwm radio''r maes parcio y mae gennych ddiddordeb ynddo ac yna clicio ''Gyrrwch o''/''Gyrrwch i''<br/><br/>Gallwch weld y meysydd parcio ar fap drwy glicio ''Dangoswch fap''<br/>'

GO

--  help page content for find a coach input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindACoachInput'
,'<h3>Selecting stations to travel from and to</h3>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Type the location names in the boxes</strong></p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>&nbsp;</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>&nbsp;</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Find nearest�</strong> </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Selecting outward and return journey dates and times</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>1. Select the dates you would like to leave/return on</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select a day from the ''drop-down'' list, then select a month/year </p>
<p style="MARGIN-RIGHT: 0px"><br/>or</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Click the calendar and select a date from it</p>
<p style="MARGIN-RIGHT: 0px"><br/>� If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>2. Choose how you want to specify the times</strong></p>
<p style="MARGIN-RIGHT: 0px"><br/>� You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </p>
<p style="MARGIN-RIGHT: 0px"><br/>� Choose ''Leaving at'' to select the earliest time you want to leave the location</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Choose ''Arriving by'' to select the latest time you want to arrive at the destination</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>3. Select the times you would like to travel</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select ''Anytime''</p>
<p style="MARGIN-RIGHT: 0px"><br/>or</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select the time you want to either leave at or arrive by</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Select the hours from the ''drop-down'' list</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Advanced options</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>Public Transport journey details <br/>Changes (refers to changing from one vehicle to another)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Find (journeys with unlimited, few or no changes)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Speed (of changes)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong><br/></strong>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Fast''</strong> if you can make the changes quickly</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Average''</strong> if you can make the changes at an average pace</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Slow''</strong> if you think you will be making the changes at a slower than average pace&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>. Travelling via a station</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Type the station name in the box</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Once you have completed the page, click ''Next''.&nbsp; </h3>'
,'<h3>Dewis gorsafoedd i deithio ohonynt ac iddynt </h3>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau </strong></p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; id yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>&nbsp;</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>&nbsp;</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Dod o hyd i''r � agosaf </strong></p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Dewis dyddiadau ac amserau siwrneion allan a dychwel </h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</p>
<p style="MARGIN-RIGHT: 0px"><br/>neu</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.&nbsp;&nbsp; Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>2. Dewiswch sut y dymunwch nodi''r amserau </strong></p>
<p style="MARGIN-RIGHT: 0px"><br/>� Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>3. Dewiswch yr amserau yr hoffech deithio </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch "Unrhyw bryd"</p>
<p style="MARGIN-RIGHT: 0px"><br/>neu</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewiswch yr oriau o''r rhestr a ollyngir i lawr</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Dewisiadau mwy cymhleth</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>Manylion siwrnai cludiant cyhoeddus <br/><br/>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl.&nbsp; Dewiswch:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau.&nbsp; Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Cyflymder (newidiadau)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong><br/></strong>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn.&nbsp; Dewiswch:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Cyflym'' </strong>os gallwch wneud y newidiadau yn gyflym</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Cyfartaledd''</strong> os gallwch wneud y newidiadau ar gyflymder cyffredin</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Araf''</strong> os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>. Teithio drwy orsaf </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Teipiwch enw''r orsaf yn y blwch</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch&nbsp; Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa'' .&nbsp; </h3>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindACoachInput'
,'<h3>Selecting stations to travel from and to</h3>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Type the location names in the boxes</strong></p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>&nbsp;</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>&nbsp;</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Find nearest�</strong> </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Selecting outward and return journey dates and times</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>1. Select the dates you would like to leave/return on</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select a day from the ''drop-down'' list, then select a month/year </p>
<p style="MARGIN-RIGHT: 0px"><br/>or</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Click the calendar and select a date from it</p>
<p style="MARGIN-RIGHT: 0px"><br/>� If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>2. Choose how you want to specify the times</strong></p>
<p style="MARGIN-RIGHT: 0px"><br/>� You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </p>
<p style="MARGIN-RIGHT: 0px"><br/>� Choose ''Leaving at'' to select the earliest time you want to leave the location</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Choose ''Arriving by'' to select the latest time you want to arrive at the destination</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>3. Select the times you would like to travel</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select ''Anytime''</p>
<p style="MARGIN-RIGHT: 0px"><br/>or</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select the time you want to either leave at or arrive by</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Select the hours from the ''drop-down'' list</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Advanced options</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>Public Transport journey details <br/>Changes (refers to changing from one vehicle to another)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Find (journeys with unlimited, few or no changes)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Speed (of changes)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong><br/></strong>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Fast''</strong> if you can make the changes quickly</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Average''</strong> if you can make the changes at an average pace</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Slow''</strong> if you think you will be making the changes at a slower than average pace&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>. Travelling via a station</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Type the station name in the box</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Once you have completed the page, click ''Next''.&nbsp; </h3>'
,'<h3>Dewis gorsafoedd i deithio ohonynt ac iddynt </h3>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau </strong></p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; id yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>&nbsp;</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>&nbsp;</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Dod o hyd i''r � agosaf </strong></p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Dewis dyddiadau ac amserau siwrneion allan a dychwel </h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</p>
<p style="MARGIN-RIGHT: 0px"><br/>neu</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.&nbsp;&nbsp; Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>2. Dewiswch sut y dymunwch nodi''r amserau </strong></p>
<p style="MARGIN-RIGHT: 0px"><br/>� Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>3. Dewiswch yr amserau yr hoffech deithio </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch "Unrhyw bryd"</p>
<p style="MARGIN-RIGHT: 0px"><br/>neu</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewiswch yr oriau o''r rhestr a ollyngir i lawr</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Dewisiadau mwy cymhleth</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>Manylion siwrnai cludiant cyhoeddus <br/><br/>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl.&nbsp; Dewiswch:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau.&nbsp; Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Cyflymder (newidiadau)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong><br/></strong>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn.&nbsp; Dewiswch:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Cyflym'' </strong>os gallwch wneud y newidiadau yn gyflym</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Cyfartaledd''</strong> os gallwch wneud y newidiadau ar gyflymder cyffredin</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Araf''</strong> os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>. Teithio drwy orsaf </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Teipiwch enw''r orsaf yn y blwch</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch&nbsp; Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa'' .&nbsp; </h3>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindACoachInput'
,'<h3>Selecting stations to travel from and to</h3>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Type the location names in the boxes</strong></p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>&nbsp;</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>&nbsp;</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Find nearest�</strong> </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Selecting outward and return journey dates and times</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>1. Select the dates you would like to leave/return on</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select a day from the ''drop-down'' list, then select a month/year </p>
<p style="MARGIN-RIGHT: 0px"><br/>or</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Click the calendar and select a date from it</p>
<p style="MARGIN-RIGHT: 0px"><br/>� If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>2. Choose how you want to specify the times</strong></p>
<p style="MARGIN-RIGHT: 0px"><br/>� You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </p>
<p style="MARGIN-RIGHT: 0px"><br/>� Choose ''Leaving at'' to select the earliest time you want to leave the location</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Choose ''Arriving by'' to select the latest time you want to arrive at the destination</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>3. Select the times you would like to travel</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select ''Anytime''</p>
<p style="MARGIN-RIGHT: 0px"><br/>or</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Select the time you want to either leave at or arrive by</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Select the hours from the ''drop-down'' list</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Advanced options</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>Public Transport journey details <br/>Changes (refers to changing from one vehicle to another)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Find (journeys with unlimited, few or no changes)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Speed (of changes)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong><br/></strong>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Fast''</strong> if you can make the changes quickly</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Average''</strong> if you can make the changes at an average pace</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Slow''</strong> if you think you will be making the changes at a slower than average pace&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>. Travelling via a station</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Type the station name in the box</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Once you have completed the page, click ''Next''.&nbsp; </h3>'
,'<h3>Dewis gorsafoedd i deithio ohonynt ac iddynt </h3>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau </strong></p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; id yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>&nbsp;</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p>&nbsp;</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Dod o hyd i''r � agosaf </strong></p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Dewis dyddiadau ac amserau siwrneion allan a dychwel </h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</p>
<p style="MARGIN-RIGHT: 0px"><br/>neu</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.&nbsp;&nbsp; Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>2. Dewiswch sut y dymunwch nodi''r amserau </strong></p>
<p style="MARGIN-RIGHT: 0px"><br/>� Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>3. Dewiswch yr amserau yr hoffech deithio </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch "Unrhyw bryd"</p>
<p style="MARGIN-RIGHT: 0px"><br/>neu</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">� Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewiswch yr oriau o''r rhestr a ollyngir i lawr</p>
<p style="MARGIN-RIGHT: 0px"><br/>� Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Dewisiadau mwy cymhleth</h3>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>Manylion siwrnai cludiant cyhoeddus <br/><br/>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl.&nbsp; Dewiswch:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig</p>
<p style="MARGIN-RIGHT: 0px"><br/>o ''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau.&nbsp; Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Cyflymder (newidiadau)</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong><br/></strong>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn.&nbsp; Dewiswch:</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Cyflym'' </strong>os gallwch wneud y newidiadau yn gyflym</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Cyfartaledd''</strong> os gallwch wneud y newidiadau ar gyflymder cyffredin</p>
<p style="MARGIN-RIGHT: 0px"><br/>o <strong>''Araf''</strong> os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin&nbsp; </p>
<p style="MARGIN-RIGHT: 0px">Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>. Teithio drwy orsaf </strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px"><strong>� Teipiwch enw''r orsaf yn y blwch</strong></p>
<p style="MARGIN-RIGHT: 0px"><strong></strong>&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch&nbsp; Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<p style="MARGIN-RIGHT: 0px">Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa'' .&nbsp; </h3>'

GO

--  help page content for find a coach input  and find a train input ambiguity pages
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindATrainCoachAmbiguity'
,'<h2>Help</h2><br/><br/>
<h3>Confirming a location to travel from or to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down  list</li></ul><br/></blockquote>
<p>Choose locations from the lists highlighted on the page.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list </li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words �More options for�� written in front of them</li> 
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<ul>
<li><strong>Find nearest�</strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p>&nbsp;</p>
<p>Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page). This will return you to the current page. </p></blockquote>
<p>&nbsp;</p>
<h3>Correcting journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Select the dates you would like to leave/return on</h5>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it</li> 
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the location</li> 
<li>Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul><br/>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select <strong>''Anytime''</strong><br/>or<br/></li>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/></blockquote>
<h4>Confirming locations to travel via</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down list</li></ul><br/>
</blockquote>
<p>Choose locations from the lists highlighted on the page.</p><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If ther was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list</li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words "More options for ..." written in front of them </li>
<li>If you select one of these and click "Next", you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<p>&nbsp;</p>
<h4>Once you have confirmed all the highlighted sections in this page, click ''Next''.</h4>'
,'<h2>Help</h2><br/><br/>
<h3>Cadarnhau lleoliad i deithio ohono neu iddo</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul></blockquote>
<p>&nbsp;</p>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr </li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:</p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau&nbsp;</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li></ul><br/></blockquote>
<ul>
<li><strong>Dod o hyd i''r � </strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os hoffech chi gymorth i ddod o hyd i orsaf, gallwch glicio ar ''Find nearest...'' i weld rhestr o orsafoedd ger y lleoliad y nodoch.</p>
<p>&nbsp;</p>
<p>Wedi i chi weld rhestr o orsafoedd a thicio''r rhai yr hoffech chi deithio ohonynt, bydd gennych yr opsiwn o barhau i gynllunio''r siwrnai (drwy glicio ''Nesaf'' ar y dudalen honno).&nbsp; Byddwch yn dychwelyd at y dudalen gyfredol. </p></blockquote>
<p>&nbsp;</p>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/></li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li> 
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li> 
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch <strong>"Unrhyw bryd"</strong><br/>neu<br/></li>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul><br/></blockquote>
<h3>Cadarnhau lleoliadau i deithio drwyddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul>
<p>&nbsp;</p></blockquote>
<h4>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio: </p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr</li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn: </p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi </li></ul><br/></blockquote>
<h3>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.</h3>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindATrainCoachAmbiguity'
,'<h2>Help</h2><br/><br/>
<h3>Confirming a location to travel from or to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down  list</li></ul><br/></blockquote>
<p>Choose locations from the lists highlighted on the page.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list </li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words �More options for�� written in front of them</li> 
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<ul>
<li><strong>Find nearest�</strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p>&nbsp;</p>
<p>Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page). This will return you to the current page. </p></blockquote>
<p>&nbsp;</p>
<h3>Correcting journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Select the dates you would like to leave/return on</h5>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it</li> 
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the location</li> 
<li>Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul><br/>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select <strong>''Anytime''</strong><br/>or<br/></li>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/></blockquote>
<h4>Confirming locations to travel via</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down list</li></ul><br/>
</blockquote>
<p>Choose locations from the lists highlighted on the page.</p><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If ther was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list</li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words "More options for ..." written in front of them </li>
<li>If you select one of these and click "Next", you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<p>&nbsp;</p>
<h4>Once you have confirmed all the highlighted sections in this page, click ''Next''.</h4>'
,'<h2>Help</h2><br/><br/>
<h3>Cadarnhau lleoliad i deithio ohono neu iddo</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul></blockquote>
<p>&nbsp;</p>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr </li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:</p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau&nbsp;</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li></ul><br/></blockquote>
<ul>
<li><strong>Dod o hyd i''r � </strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os hoffech chi gymorth i ddod o hyd i orsaf, gallwch glicio ar ''Find nearest...'' i weld rhestr o orsafoedd ger y lleoliad y nodoch.</p>
<p>&nbsp;</p>
<p>Wedi i chi weld rhestr o orsafoedd a thicio''r rhai yr hoffech chi deithio ohonynt, bydd gennych yr opsiwn o barhau i gynllunio''r siwrnai (drwy glicio ''Nesaf'' ar y dudalen honno).&nbsp; Byddwch yn dychwelyd at y dudalen gyfredol. </p></blockquote>
<p>&nbsp;</p>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/></li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li> 
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li> 
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch <strong>"Unrhyw bryd"</strong><br/>neu<br/></li>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul><br/></blockquote>
<h3>Cadarnhau lleoliadau i deithio drwyddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul>
<p>&nbsp;</p></blockquote>
<h4>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio: </p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr</li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn: </p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi </li></ul><br/></blockquote>
<h3>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.</h3>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindATrainCoachAmbiguity'
,'<h2>Help</h2><br/><br/>
<h3>Confirming a location to travel from or to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down  list</li></ul><br/></blockquote>
<p>Choose locations from the lists highlighted on the page.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list </li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words �More options for�� written in front of them</li> 
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<ul>
<li><strong>Find nearest�</strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p>&nbsp;</p>
<p>Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page). This will return you to the current page. </p></blockquote>
<p>&nbsp;</p>
<h3>Correcting journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Select the dates you would like to leave/return on</h5>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it</li> 
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the location</li> 
<li>Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul><br/>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select <strong>''Anytime''</strong><br/>or<br/></li>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/></blockquote>
<h4>Confirming locations to travel via</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down list</li></ul><br/>
</blockquote>
<p>Choose locations from the lists highlighted on the page.</p><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If ther was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list</li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words "More options for ..." written in front of them </li>
<li>If you select one of these and click "Next", you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<p>&nbsp;</p>
<h4>Once you have confirmed all the highlighted sections in this page, click ''Next''.</h4>'
,'<h2>Help</h2><br/><br/>
<h3>Cadarnhau lleoliad i deithio ohono neu iddo</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul></blockquote>
<p>&nbsp;</p>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr </li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:</p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau&nbsp;</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li></ul><br/></blockquote>
<ul>
<li><strong>Dod o hyd i''r � </strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os hoffech chi gymorth i ddod o hyd i orsaf, gallwch glicio ar ''Find nearest...'' i weld rhestr o orsafoedd ger y lleoliad y nodoch.</p>
<p>&nbsp;</p>
<p>Wedi i chi weld rhestr o orsafoedd a thicio''r rhai yr hoffech chi deithio ohonynt, bydd gennych yr opsiwn o barhau i gynllunio''r siwrnai (drwy glicio ''Nesaf'' ar y dudalen honno).&nbsp; Byddwch yn dychwelyd at y dudalen gyfredol. </p></blockquote>
<p>&nbsp;</p>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/></li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li> 
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li> 
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch <strong>"Unrhyw bryd"</strong><br/>neu<br/></li>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul><br/></blockquote>
<h3>Cadarnhau lleoliadau i deithio drwyddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul>
<p>&nbsp;</p></blockquote>
<h4>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio: </p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr</li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn: </p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi </li></ul><br/></blockquote>
<h3>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.</h3>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindATrainCoachAmbiguity'
,'<h2>Help</h2><br/><br/>
<h3>Confirming a location to travel from or to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down  list</li></ul><br/></blockquote>
<p>Choose locations from the lists highlighted on the page.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If there was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list </li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words �More options for�� written in front of them</li> 
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<ul>
<li><strong>Find nearest�</strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p>&nbsp;</p>
<p>Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page). This will return you to the current page. </p></blockquote>
<p>&nbsp;</p>
<h3>Correcting journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Select the dates you would like to leave/return on</h5>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it</li> 
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the location</li> 
<li>Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul><br/>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select <strong>''Anytime''</strong><br/>or<br/></li>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/></blockquote>
<h4>Confirming locations to travel via</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>You may need to select from possible options for the station you entered:</p>
<ul>
<li>Choose an option from the drop-down list</li></ul><br/>
</blockquote>
<p>Choose locations from the lists highlighted on the page.</p><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If ther was more than one match for the locations you typed in:</p>
<ul>
<li>Choose one of the options in the list</li></ul><br/>
<p>Some locations have further locations within them:</p>
<ul>
<li>Some have the words "More options for ..." written in front of them </li>
<li>If you select one of these and click "Next", you will be given a list of all the locations that exist within this first location</li></ul><br/></blockquote>
<p>&nbsp;</p>
<h4>Once you have confirmed all the highlighted sections in this page, click ''Next''.</h4>'
,'<h2>Help</h2><br/><br/>
<h3>Cadarnhau lleoliad i deithio ohono neu iddo</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul></blockquote>
<p>&nbsp;</p>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr </li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:</p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau&nbsp;</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li></ul><br/></blockquote>
<ul>
<li><strong>Dod o hyd i''r � </strong></li></ul><br/>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os hoffech chi gymorth i ddod o hyd i orsaf, gallwch glicio ar ''Find nearest...'' i weld rhestr o orsafoedd ger y lleoliad y nodoch.</p>
<p>&nbsp;</p>
<p>Wedi i chi weld rhestr o orsafoedd a thicio''r rhai yr hoffech chi deithio ohonynt, bydd gennych yr opsiwn o barhau i gynllunio''r siwrnai (drwy glicio ''Nesaf'' ar y dudalen honno).&nbsp; Byddwch yn dychwelyd at y dudalen gyfredol. </p></blockquote>
<p>&nbsp;</p>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/></li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li> 
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.&nbsp;&nbsp; </li></ul><br/>
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li> 
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch <strong>"Unrhyw bryd"</strong><br/>neu<br/></li>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul><br/></blockquote>
<h3>Cadarnhau lleoliadau i deithio drwyddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae''n bosibl y bydd angen i chi ddewis o ddewisiadau posibl ar gyfer yr orsaf y bu i chi ei nodi:</p>
<ul>
<li>Dewiswch ddewis o''r rhestr a ollyngir i lawr</li></ul>
<p>&nbsp;</p></blockquote>
<h4>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen</h4>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio: </p>
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr</li></ul><br/>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn: </p>
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi </li></ul><br/></blockquote>
<h3>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.</h3>'

GO

--  help page content for find a flight input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindAFlightInput'
,'<h3>Selecting airports to travel from/to</h3>
<p>&nbsp;</p>
<ul>
<li><strong>Select the airports or regions from the drop-down lists</strong><br/><br/>The regions are listed nearest the top of the list, and the airports are listed below the regions.&nbsp; If you have JavaScript turned on and you select a region, the airports that service that region will appear below the region with tickboxes.&nbsp; All the airports will be ticked by default, but you can untick the ones you are not interested in flying from.&nbsp; If you don''t have JavaScript turned on, you will not be able to select specific airports for the region you choose.&nbsp; The airports will be listed on the next page however. <br/><br/></li>
<li><strong>Find nearest�</strong><br/><br/>If you would like help finding an airport, you can click on ''Find nearest�'' to see a list of airports near the location you specify.Once you see a list of airports and tick the ones you would like to travel from, you will be able to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>The tickbox for "Find direct flights only" is ticked as default. If however, you are interested in non-direct flights as well, then untick the box.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location </li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting operators </h4>
<h5>Operators</h5>
<p>All operators/airlines will be searched unless you wish to include or exclude specific ones.&nbsp; To do this decide whether you would like to exclude travel with certain operators or include travel with certain operators by clicking either:</p>
<p>&nbsp;</p>
<ul>
<li>Do <strong>not</strong> use these operators&nbsp; (this is set as the default option) </li>
<li><strong>Only</strong> use these operators</li></ul>
<p>&nbsp;</p>
<p>If you choose ''Do <strong>not</strong> use these operators'' you will need to tick any operators you do not wish to travel with.&nbsp; Please note that this may reduce the number of journeys in the results.</p>
<p>If you choose ''<strong>Only</strong> use these operators'' you will need to tick the operators that you would like to travel with. </p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting Check-in time</h4>
<h5>Check-in time</h5>
<p>Transport Direct will plan with the minimum check-in time required by each airline and will list them in the search results. If you need more time, choose from the options in the drop-down list: </p>
<p>If you don''t need any more time, select:</p>
<ul>
<li>''I just need the minimum required check-in time'' (this is set as the default option)</li></ul>
<p>&nbsp;</p>
<p>If you feel you do need more time select either:</p>
<ul>
<li>''I need 30 minutes longer''or </li>
<li>''I need 60 minutes longer'' </li></ul>
<p><strong>Note:</strong> Check-in times do not account for time spent shopping or dining in the airport so you may wish to opt for more time.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Travelling via an airport&nbsp; (Indirect flights only)</h4>
<h5>Select the airport from the drop-down list</h5>
<p>If you would like to stopover in a specific airport, select one from the drop-down list.&nbsp; If you don''t mind where you stopover (some operators require stopovers on certain flights) select ''I don''t mind, but only if required'' (this is set as the default option).</p>
<p>&nbsp;</p>
<h5>Stopover times</h5>
<ul>
<li>If you do not want to stopover at an airport for a specific amount of time select:<br/>''No longer than required'' </li></ul>
<p>&nbsp;</p>
<p>If you would like to stay for a specific amount of time, select:</p>
<ul>
<li>''An additional 2 hours'' </li>
<li>''An additional 4 hours'' </li>
<li>''An additional 6 hours''</li></ul></blockquote>
<h3>Once you have completed the page, click ''Next''. </h3>'
,'<h3>Dewis meysydd awyr i deithio ohonynt ac iddynt</h3>
<p>&nbsp;</p>
<ul>
<li><strong>Dewiswch y meysydd awyr neu ranbarthau o''r rhestr a ollyngir i lawr</strong><br/><br/>Mae''r rhanbarthau wedi''u rhestru ar frig y rhestr, a''r meysydd awyr o dan y rhanbarthau. Os oes gennych chi JavaScript wedi''i droi ymlaen a''ch bod yn dewis rhanbarth, bydd y meysydd awyr sy''n gwasanaethu''r rhanbarth hwnnw yn ymddangos o dan y rhanbarth gyda blychau ticio. Bydd y meysydd awyr i gyd yn cael eu ticio yn ddiofyn, ond fe allwch chi ddad-dicio y rhai nad oes gennych chi ddiddordeb mewn hedfan allan ohonynt. <br/><br/></li>
<li><strong>Dod o hyd i''r � agosaf </strong><br/><br/>Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.<br/>Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae blwch ticio ar gyfer ''Canfyddwch ehediadau uniongyrchol yn unig'' wedi''i dicio''n ddiofyn. Serch hynny, os oes gennych ddiddordeb mewn ehediadau anuniongyrchol hefyd, yna dad-diciwch y blwch.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis gweithredwyr </h4>
<h5>Gweithredwyr</h5>
<p>Chwilir am bob gweithredwr/maes awyr heblaw y dymunwch gynnwys neu eithrio rhai penodol. I wneud hyn mae''n rhaid i chi benderfynu os y dymunwch eithrio teithio gyda gweithredwyr penodol neu gynnwys teithio gyda gweithredwyr penodol drwy glicio naill ai:</p>
<p>&nbsp;</p>
<ul>
<li>Peidiwch � defnyddio''r gweithredwyr hyn (gosodir hyn fel y dewis diofyn) </li>
<li>Defnyddiwch y gweithredwyr hyn yn unig</li></ul>
<p>&nbsp;</p>
<p>Os ydych chi''n dewis ''Peidiwch � defnyddio''r gweithredwyr hyn'' bydd angen i chi dicio unrhyw weithredwyr na ddymunwch deithio gyda hwy. Nodwch os gwelwch yn dda y gall hyn leihau nifer y siwrneion yn y canlyniadau.</p>
<p>Os ydych chi''n dewis ''Defnyddiwch y gweithredwyr hyn yn unig'' bydd angen i chi dicio''r gweithredwyr y dymunwch chi deithio gyda hwy. </p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewiswch amser Cofrestru</h4>
<h5>Amser Cofrestru</h5>
<p>Bydd Transport Direct yn cynllunio gyda lleiafswm amser cofrestru sydd angen gan bob cwmni awyrennau a bydd yn eu rhestru yn y canlyniadau chwilio. Os ydych chi angen mwy o amser, dewiswch o''r rhestr a ollyngir i lawr: </p>
<p>Os nad ydych chi angen mwy o amser, dewiswch:</p>
<ul>
<li>''Dim ond lleiafswm yr amser cofrestru sy''n ofynnol sydd angen arnaf'' (gosodir hyn yn ddiofyn)</li></ul>
<p>&nbsp;</p>
<p>Os ydych chi''n teimlo eich bod angen mwy o amser dewiswch naill ai:</p>
<ul>
<li>''Rydw i angen 30 munud yn fwy, neu </li>
<li>''Rydw i angen 60 munud yn fwy'' </li></ul>
<p><strong>Noder:</strong> Nid yw amseroedd cofrestru yn cyfrif am yr amser a dreulir yn siopa ac yn bwyta yn y maes awyr felly mae''n bosibl y byddwch yn dymuno dewis mwy o amser.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Teithio drwy faes awyr (Ehediadau anuniongyrchol yn unig)</h4>
<h5>Dewiswch y maes awyr o''r rhestr a ollyngir i lawr</h5>
<p>Os dymunwch aros mewn maes awyr penodol, dewiswch un o''r rhestr a ollyngir i lawr. Os nad oes gwahaniaeth gennych lle yr ydych yn aros (weithiau mae arosiadau yn ofynnol gan weithredwyr ar rai ehediadau) dewiswch ''Does dim bwys gennyf i, ond dim ond os oes yn rhaid'' (gosodir hwn fel y dewis diofyn).</p>
<p>&nbsp;</p>
<h5>Amserau aros</h5>
<ul>
<li>Os na ddymunwch chi aros mewn maes awyr am gyfnod o amser penodol dewiswch:<br/>"Dim hirach na sy''n rhaid" </li></ul>
<p>&nbsp;</p>
<p>Os dymunwch chi aros am gyfnod o amser penodol, dewiswch:</p>
<ul>
<li>"2 awr ychwanegol" </li>
<li>"4 awr ychwanegol" </li>
<li>"8 awr ychwanegol"</li></ul></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAFlightInput'
,'<h3>Selecting airports to travel from/to</h3>
<p>&nbsp;</p>
<ul>
<li><strong>Select the airports or regions from the drop-down lists</strong><br/><br/>The regions are listed nearest the top of the list, and the airports are listed below the regions.&nbsp; If you have JavaScript turned on and you select a region, the airports that service that region will appear below the region with tickboxes.&nbsp; All the airports will be ticked by default, but you can untick the ones you are not interested in flying from.&nbsp; If you don''t have JavaScript turned on, you will not be able to select specific airports for the region you choose.&nbsp; The airports will be listed on the next page however. <br/><br/></li>
<li><strong>Find nearest�</strong><br/><br/>If you would like help finding an airport, you can click on ''Find nearest�'' to see a list of airports near the location you specify.Once you see a list of airports and tick the ones you would like to travel from, you will be able to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>The tickbox for "Find direct flights only" is ticked as default. If however, you are interested in non-direct flights as well, then untick the box.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location </li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting operators </h4>
<h5>Operators</h5>
<p>All operators/airlines will be searched unless you wish to include or exclude specific ones.&nbsp; To do this decide whether you would like to exclude travel with certain operators or include travel with certain operators by clicking either:</p>
<p>&nbsp;</p>
<ul>
<li>Do <strong>not</strong> use these operators&nbsp; (this is set as the default option) </li>
<li><strong>Only</strong> use these operators</li></ul>
<p>&nbsp;</p>
<p>If you choose ''Do <strong>not</strong> use these operators'' you will need to tick any operators you do not wish to travel with.&nbsp; Please note that this may reduce the number of journeys in the results.</p>
<p>If you choose ''<strong>Only</strong> use these operators'' you will need to tick the operators that you would like to travel with. </p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting Check-in time</h4>
<h5>Check-in time</h5>
<p>Transport Direct will plan with the minimum check-in time required by each airline and will list them in the search results. If you need more time, choose from the options in the drop-down list: </p>
<p>If you don''t need any more time, select:</p>
<ul>
<li>''I just need the minimum required check-in time'' (this is set as the default option)</li></ul>
<p>&nbsp;</p>
<p>If you feel you do need more time select either:</p>
<ul>
<li>''I need 30 minutes longer''or </li>
<li>''I need 60 minutes longer'' </li></ul>
<p><strong>Note:</strong> Check-in times do not account for time spent shopping or dining in the airport so you may wish to opt for more time.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Travelling via an airport&nbsp; (Indirect flights only)</h4>
<h5>Select the airport from the drop-down list</h5>
<p>If you would like to stopover in a specific airport, select one from the drop-down list.&nbsp; If you don''t mind where you stopover (some operators require stopovers on certain flights) select ''I don''t mind, but only if required'' (this is set as the default option).</p>
<p>&nbsp;</p>
<h5>Stopover times</h5>
<ul>
<li>If you do not want to stopover at an airport for a specific amount of time select:<br/>''No longer than required'' </li></ul>
<p>&nbsp;</p>
<p>If you would like to stay for a specific amount of time, select:</p>
<ul>
<li>''An additional 2 hours'' </li>
<li>''An additional 4 hours'' </li>
<li>''An additional 6 hours''</li></ul></blockquote>
<h3>Once you have completed the page, click ''Next''. </h3>'
,'<h3>Dewis meysydd awyr i deithio ohonynt ac iddynt</h3>
<p>&nbsp;</p>
<ul>
<li><strong>Dewiswch y meysydd awyr neu ranbarthau o''r rhestr a ollyngir i lawr</strong><br/><br/>Mae''r rhanbarthau wedi''u rhestru ar frig y rhestr, a''r meysydd awyr o dan y rhanbarthau. Os oes gennych chi JavaScript wedi''i droi ymlaen a''ch bod yn dewis rhanbarth, bydd y meysydd awyr sy''n gwasanaethu''r rhanbarth hwnnw yn ymddangos o dan y rhanbarth gyda blychau ticio. Bydd y meysydd awyr i gyd yn cael eu ticio yn ddiofyn, ond fe allwch chi ddad-dicio y rhai nad oes gennych chi ddiddordeb mewn hedfan allan ohonynt. <br/><br/></li>
<li><strong>Dod o hyd i''r � agosaf </strong><br/><br/>Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.<br/>Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae blwch ticio ar gyfer ''Canfyddwch ehediadau uniongyrchol yn unig'' wedi''i dicio''n ddiofyn. Serch hynny, os oes gennych ddiddordeb mewn ehediadau anuniongyrchol hefyd, yna dad-diciwch y blwch.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis gweithredwyr </h4>
<h5>Gweithredwyr</h5>
<p>Chwilir am bob gweithredwr/maes awyr heblaw y dymunwch gynnwys neu eithrio rhai penodol. I wneud hyn mae''n rhaid i chi benderfynu os y dymunwch eithrio teithio gyda gweithredwyr penodol neu gynnwys teithio gyda gweithredwyr penodol drwy glicio naill ai:</p>
<p>&nbsp;</p>
<ul>
<li>Peidiwch � defnyddio''r gweithredwyr hyn (gosodir hyn fel y dewis diofyn) </li>
<li>Defnyddiwch y gweithredwyr hyn yn unig</li></ul>
<p>&nbsp;</p>
<p>Os ydych chi''n dewis ''Peidiwch � defnyddio''r gweithredwyr hyn'' bydd angen i chi dicio unrhyw weithredwyr na ddymunwch deithio gyda hwy. Nodwch os gwelwch yn dda y gall hyn leihau nifer y siwrneion yn y canlyniadau.</p>
<p>Os ydych chi''n dewis ''Defnyddiwch y gweithredwyr hyn yn unig'' bydd angen i chi dicio''r gweithredwyr y dymunwch chi deithio gyda hwy. </p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewiswch amser Cofrestru</h4>
<h5>Amser Cofrestru</h5>
<p>Bydd Transport Direct yn cynllunio gyda lleiafswm amser cofrestru sydd angen gan bob cwmni awyrennau a bydd yn eu rhestru yn y canlyniadau chwilio. Os ydych chi angen mwy o amser, dewiswch o''r rhestr a ollyngir i lawr: </p>
<p>Os nad ydych chi angen mwy o amser, dewiswch:</p>
<ul>
<li>''Dim ond lleiafswm yr amser cofrestru sy''n ofynnol sydd angen arnaf'' (gosodir hyn yn ddiofyn)</li></ul>
<p>&nbsp;</p>
<p>Os ydych chi''n teimlo eich bod angen mwy o amser dewiswch naill ai:</p>
<ul>
<li>''Rydw i angen 30 munud yn fwy, neu </li>
<li>''Rydw i angen 60 munud yn fwy'' </li></ul>
<p><strong>Noder:</strong> Nid yw amseroedd cofrestru yn cyfrif am yr amser a dreulir yn siopa ac yn bwyta yn y maes awyr felly mae''n bosibl y byddwch yn dymuno dewis mwy o amser.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Teithio drwy faes awyr (Ehediadau anuniongyrchol yn unig)</h4>
<h5>Dewiswch y maes awyr o''r rhestr a ollyngir i lawr</h5>
<p>Os dymunwch aros mewn maes awyr penodol, dewiswch un o''r rhestr a ollyngir i lawr. Os nad oes gwahaniaeth gennych lle yr ydych yn aros (weithiau mae arosiadau yn ofynnol gan weithredwyr ar rai ehediadau) dewiswch ''Does dim bwys gennyf i, ond dim ond os oes yn rhaid'' (gosodir hwn fel y dewis diofyn).</p>
<p>&nbsp;</p>
<h5>Amserau aros</h5>
<ul>
<li>Os na ddymunwch chi aros mewn maes awyr am gyfnod o amser penodol dewiswch:<br/>"Dim hirach na sy''n rhaid" </li></ul>
<p>&nbsp;</p>
<p>Os dymunwch chi aros am gyfnod o amser penodol, dewiswch:</p>
<ul>
<li>"2 awr ychwanegol" </li>
<li>"4 awr ychwanegol" </li>
<li>"8 awr ychwanegol"</li></ul></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAFlightInput'
,'<h3>Selecting airports to travel from/to</h3>
<p>&nbsp;</p>
<ul>
<li><strong>Select the airports or regions from the drop-down lists</strong><br/><br/>The regions are listed nearest the top of the list, and the airports are listed below the regions.&nbsp; If you have JavaScript turned on and you select a region, the airports that service that region will appear below the region with tickboxes.&nbsp; All the airports will be ticked by default, but you can untick the ones you are not interested in flying from.&nbsp; If you don''t have JavaScript turned on, you will not be able to select specific airports for the region you choose.&nbsp; The airports will be listed on the next page however. <br/><br/></li>
<li><strong>Find nearest�</strong><br/><br/>If you would like help finding an airport, you can click on ''Find nearest�'' to see a list of airports near the location you specify.Once you see a list of airports and tick the ones you would like to travel from, you will be able to continue planning the journey (by clicking ''Next'' on that page).&nbsp; This will return you to the current page.</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>The tickbox for "Find direct flights only" is ticked as default. If however, you are interested in non-direct flights as well, then untick the box.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location </li>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting operators </h4>
<h5>Operators</h5>
<p>All operators/airlines will be searched unless you wish to include or exclude specific ones.&nbsp; To do this decide whether you would like to exclude travel with certain operators or include travel with certain operators by clicking either:</p>
<p>&nbsp;</p>
<ul>
<li>Do <strong>not</strong> use these operators&nbsp; (this is set as the default option) </li>
<li><strong>Only</strong> use these operators</li></ul>
<p>&nbsp;</p>
<p>If you choose ''Do <strong>not</strong> use these operators'' you will need to tick any operators you do not wish to travel with.&nbsp; Please note that this may reduce the number of journeys in the results.</p>
<p>If you choose ''<strong>Only</strong> use these operators'' you will need to tick the operators that you would like to travel with. </p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Selecting Check-in time</h4>
<h5>Check-in time</h5>
<p>Transport Direct will plan with the minimum check-in time required by each airline and will list them in the search results. If you need more time, choose from the options in the drop-down list: </p>
<p>If you don''t need any more time, select:</p>
<ul>
<li>''I just need the minimum required check-in time'' (this is set as the default option)</li></ul>
<p>&nbsp;</p>
<p>If you feel you do need more time select either:</p>
<ul>
<li>''I need 30 minutes longer''or </li>
<li>''I need 60 minutes longer'' </li></ul>
<p><strong>Note:</strong> Check-in times do not account for time spent shopping or dining in the airport so you may wish to opt for more time.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Travelling via an airport&nbsp; (Indirect flights only)</h4>
<h5>Select the airport from the drop-down list</h5>
<p>If you would like to stopover in a specific airport, select one from the drop-down list.&nbsp; If you don''t mind where you stopover (some operators require stopovers on certain flights) select ''I don''t mind, but only if required'' (this is set as the default option).</p>
<p>&nbsp;</p>
<h5>Stopover times</h5>
<ul>
<li>If you do not want to stopover at an airport for a specific amount of time select:<br/>''No longer than required'' </li></ul>
<p>&nbsp;</p>
<p>If you would like to stay for a specific amount of time, select:</p>
<ul>
<li>''An additional 2 hours'' </li>
<li>''An additional 4 hours'' </li>
<li>''An additional 6 hours''</li></ul></blockquote>
<h3>Once you have completed the page, click ''Next''. </h3>'
,'<h3>Dewis meysydd awyr i deithio ohonynt ac iddynt</h3>
<p>&nbsp;</p>
<ul>
<li><strong>Dewiswch y meysydd awyr neu ranbarthau o''r rhestr a ollyngir i lawr</strong><br/><br/>Mae''r rhanbarthau wedi''u rhestru ar frig y rhestr, a''r meysydd awyr o dan y rhanbarthau. Os oes gennych chi JavaScript wedi''i droi ymlaen a''ch bod yn dewis rhanbarth, bydd y meysydd awyr sy''n gwasanaethu''r rhanbarth hwnnw yn ymddangos o dan y rhanbarth gyda blychau ticio. Bydd y meysydd awyr i gyd yn cael eu ticio yn ddiofyn, ond fe allwch chi ddad-dicio y rhai nad oes gennych chi ddiddordeb mewn hedfan allan ohonynt. <br/><br/></li>
<li><strong>Dod o hyd i''r � agosaf </strong><br/><br/>Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.<br/>Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Mae blwch ticio ar gyfer ''Canfyddwch ehediadau uniongyrchol yn unig'' wedi''i dicio''n ddiofyn. Serch hynny, os oes gennych ddiddordeb mewn ehediadau anuniongyrchol hefyd, yna dad-diciwch y blwch.</p></blockquote>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad </li>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewis gweithredwyr </h4>
<h5>Gweithredwyr</h5>
<p>Chwilir am bob gweithredwr/maes awyr heblaw y dymunwch gynnwys neu eithrio rhai penodol. I wneud hyn mae''n rhaid i chi benderfynu os y dymunwch eithrio teithio gyda gweithredwyr penodol neu gynnwys teithio gyda gweithredwyr penodol drwy glicio naill ai:</p>
<p>&nbsp;</p>
<ul>
<li>Peidiwch � defnyddio''r gweithredwyr hyn (gosodir hyn fel y dewis diofyn) </li>
<li>Defnyddiwch y gweithredwyr hyn yn unig</li></ul>
<p>&nbsp;</p>
<p>Os ydych chi''n dewis ''Peidiwch � defnyddio''r gweithredwyr hyn'' bydd angen i chi dicio unrhyw weithredwyr na ddymunwch deithio gyda hwy. Nodwch os gwelwch yn dda y gall hyn leihau nifer y siwrneion yn y canlyniadau.</p>
<p>Os ydych chi''n dewis ''Defnyddiwch y gweithredwyr hyn yn unig'' bydd angen i chi dicio''r gweithredwyr y dymunwch chi deithio gyda hwy. </p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Dewiswch amser Cofrestru</h4>
<h5>Amser Cofrestru</h5>
<p>Bydd Transport Direct yn cynllunio gyda lleiafswm amser cofrestru sydd angen gan bob cwmni awyrennau a bydd yn eu rhestru yn y canlyniadau chwilio. Os ydych chi angen mwy o amser, dewiswch o''r rhestr a ollyngir i lawr: </p>
<p>Os nad ydych chi angen mwy o amser, dewiswch:</p>
<ul>
<li>''Dim ond lleiafswm yr amser cofrestru sy''n ofynnol sydd angen arnaf'' (gosodir hyn yn ddiofyn)</li></ul>
<p>&nbsp;</p>
<p>Os ydych chi''n teimlo eich bod angen mwy o amser dewiswch naill ai:</p>
<ul>
<li>''Rydw i angen 30 munud yn fwy, neu </li>
<li>''Rydw i angen 60 munud yn fwy'' </li></ul>
<p><strong>Noder:</strong> Nid yw amseroedd cofrestru yn cyfrif am yr amser a dreulir yn siopa ac yn bwyta yn y maes awyr felly mae''n bosibl y byddwch yn dymuno dewis mwy o amser.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Teithio drwy faes awyr (Ehediadau anuniongyrchol yn unig)</h4>
<h5>Dewiswch y maes awyr o''r rhestr a ollyngir i lawr</h5>
<p>Os dymunwch aros mewn maes awyr penodol, dewiswch un o''r rhestr a ollyngir i lawr. Os nad oes gwahaniaeth gennych lle yr ydych yn aros (weithiau mae arosiadau yn ofynnol gan weithredwyr ar rai ehediadau) dewiswch ''Does dim bwys gennyf i, ond dim ond os oes yn rhaid'' (gosodir hwn fel y dewis diofyn).</p>
<p>&nbsp;</p>
<h5>Amserau aros</h5>
<ul>
<li>Os na ddymunwch chi aros mewn maes awyr am gyfnod o amser penodol dewiswch:<br/>"Dim hirach na sy''n rhaid" </li></ul>
<p>&nbsp;</p>
<p>Os dymunwch chi aros am gyfnod o amser penodol, dewiswch:</p>
<ul>
<li>"2 awr ychwanegol" </li>
<li>"4 awr ychwanegol" </li>
<li>"8 awr ychwanegol"</li></ul></blockquote>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindAFlightAmbiguity'
,'<h2>Help</h2>
<h4>If you have JavaScript turned off, you may need to be more specific about the locations you selected.</h4>
<p>Choose locations from the lists highlighted on the page.</p>
<p>&nbsp;</p>
<h3>Correcting journey dates and times</h3>
<p>&nbsp;</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Select the dates you would like to leave/return on</strong></p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list </li></ul><br/>
<p><strong>2. Choose how you want to specify the times</strong></p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''<strong>Leaving at</strong>'' to select the earliest time you want to leave the location </li>
<li>Choose ''<strong>Arriving by</strong>'' to select the latest time you want to arrive at the destination</li></ul><br/>
<p><strong>3. Select the times you would like to travel</strong></p>
<ul>
<li>Select ''Anytime''<br/>or<br/></li>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/><br/></blockquote>
<p><strong>Once you have confirmed all the highlighted sections in this page, click ''Next''.</strong></p>'
,'<h2>Help</h2>
<p>&nbsp;</p>
<h5>Os oes gennych JavaScript wedi ei ddiffodd, mae''n bosibl y bydd angen i chi fod yn fwy penodol am y lleoliadau a ddewiswyd.</h5>
<p>&nbsp;</p>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p>
<p>&nbsp;</p>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<p>&nbsp;</p>
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/></li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul><br/></blockquote>
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li>
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/></blockquote>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Dewiswch "Unrhyw bryd"<br/>neu<br/></li>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul></blockquote>
<p><strong>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.</strong></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAFlightAmbiguity'
,'<h2>Help</h2>
<h4>If you have JavaScript turned off, you may need to be more specific about the locations you selected.</h4>
<p>Choose locations from the lists highlighted on the page.</p>
<p>&nbsp;</p>
<h3>Correcting journey dates and times</h3>
<p>&nbsp;</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Select the dates you would like to leave/return on</strong></p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list </li></ul><br/>
<p><strong>2. Choose how you want to specify the times</strong></p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''<strong>Leaving at</strong>'' to select the earliest time you want to leave the location </li>
<li>Choose ''<strong>Arriving by</strong>'' to select the latest time you want to arrive at the destination</li></ul><br/>
<p><strong>3. Select the times you would like to travel</strong></p>
<ul>
<li>Select ''Anytime''<br/>or<br/></li>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/><br/></blockquote>
<p><strong>Once you have confirmed all the highlighted sections in this page, click ''Next''.</strong></p>'
,'<h2>Help</h2>
<p>&nbsp;</p>
<h5>Os oes gennych JavaScript wedi ei ddiffodd, mae''n bosibl y bydd angen i chi fod yn fwy penodol am y lleoliadau a ddewiswyd.</h5>
<p>&nbsp;</p>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p>
<p>&nbsp;</p>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<p>&nbsp;</p>
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/></li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul><br/></blockquote>
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li>
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/></blockquote>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Dewiswch "Unrhyw bryd"<br/>neu<br/></li>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul></blockquote>
<p><strong>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.</strong></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAFlightAmbiguity'
,'<h2>Help</h2>
<h4>If you have JavaScript turned off, you may need to be more specific about the locations you selected.</h4>
<p>Choose locations from the lists highlighted on the page.</p>
<p>&nbsp;</p>
<h3>Correcting journey dates and times</h3>
<p>&nbsp;</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>1. Select the dates you would like to leave/return on</strong></p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year <br/>or<br/></li>
<li>Click the calendar and select a date from it </li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list </li></ul><br/>
<p><strong>2. Choose how you want to specify the times</strong></p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''<strong>Leaving at</strong>'' to select the earliest time you want to leave the location </li>
<li>Choose ''<strong>Arriving by</strong>'' to select the latest time you want to arrive at the destination</li></ul><br/>
<p><strong>3. Select the times you would like to travel</strong></p>
<ul>
<li>Select ''Anytime''<br/>or<br/></li>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list</li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul><br/><br/></blockquote>
<p><strong>Once you have confirmed all the highlighted sections in this page, click ''Next''.</strong></p>'
,'<h2>Help</h2>
<p>&nbsp;</p>
<h5>Os oes gennych JavaScript wedi ei ddiffodd, mae''n bosibl y bydd angen i chi fod yn fwy penodol am y lleoliadau a ddewiswyd.</h5>
<p>&nbsp;</p>
<p>Dewiswch leoliadau o''r rhestrau y tynnwyd sylw atynt ar y dudalen.</p>
<p>&nbsp;</p>
<h3>Cywiro dyddiadau ac amserau siwrneion</h3>
<p>&nbsp;</p>
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn<br/>neu<br/></li>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono</li>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr.</li></ul><br/></blockquote>
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li>
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul><br/></blockquote>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<blockquote style="MARGIN-RIGHT: 0px">
<ul>
<li>Dewiswch "Unrhyw bryd"<br/>neu<br/></li>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00)</li></ul></blockquote>
<p><strong>Wedi i chi gadarnhau''r holl adrannau a amlygwyd ar y dudalen hon, cliciwch ar ''Nesa''.</strong></p>'

GO

--  help page content for find a train input and find a train cost input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindATrainInput'
,'<h2>Help</h2><br/><br/>
<h3>Selecting stations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2.&nbsp; Find nearest�</h5>
<p>&nbsp;</p>
<p>If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p>Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page). This will return you to the current page.</p></blockquote>
<p>&nbsp;</p>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Advanced options</h3><br/>
<h4>Public Transport journey details</h4>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</li> 
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes </li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly</li> 
<li>''Average'' if you can make the changes at an average pace</li> 
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Travelling via a station</h4>
<ul>
<li>
<div>Type the station name in the box. </div></li></ul>
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you. Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in. </p></blockquote>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Once you have completed the page, click ''Next''.&nbsp; </h3>'
,'<h2>Help</h2><br/><br/>
<h3>Dewis gorsafoedd i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p></blockquote>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.</p>
<p></p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2.&nbsp; Dod o hyd i''r � agosaf</h5>
<p>&nbsp;</p>
<p>Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.</p>
<p>Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</p></blockquote>
<p>&nbsp;</p>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Dewisiadau mwy cymhleth</h3>
<h4>Manylion siwrnai cludiant cyhoeddus</h4>
<p><strong>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</li> 
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig </li>
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau)</strong></p>
<p>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym </li>
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Teithio drwy orsaf</h4>
<ul>
<li>
<div>Teipiwch enw''r orsaf yn y blwch</div></li></ul>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio. </p></blockquote>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''. </h3>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindATrainInput'
,'<h2>Help</h2><br/><br/>
<h3>Selecting stations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2.&nbsp; Find nearest�</h5>
<p>&nbsp;</p>
<p>If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p>Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page). This will return you to the current page.</p></blockquote>
<p>&nbsp;</p>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Advanced options</h3><br/>
<h4>Public Transport journey details</h4>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</li> 
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes </li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly</li> 
<li>''Average'' if you can make the changes at an average pace</li> 
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Travelling via a station</h4>
<ul>
<li>
<div>Type the station name in the box. </div></li></ul>
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you. Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in. </p></blockquote>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Once you have completed the page, click ''Next''.&nbsp; </h3>'
,'<h2>Help</h2><br/><br/>
<h3>Dewis gorsafoedd i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p></blockquote>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.</p>
<p></p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2.&nbsp; Dod o hyd i''r � agosaf</h5>
<p>&nbsp;</p>
<p>Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.</p>
<p>Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</p></blockquote>
<p>&nbsp;</p>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Dewisiadau mwy cymhleth</h3>
<h4>Manylion siwrnai cludiant cyhoeddus</h4>
<p><strong>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</li> 
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig </li>
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau)</strong></p>
<p>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym </li>
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Teithio drwy orsaf</h4>
<ul>
<li>
<div>Teipiwch enw''r orsaf yn y blwch</div></li></ul>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio. </p></blockquote>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''. </h3>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindATrainInput'
,'<h2>Help</h2><br/><br/>
<h3>Selecting stations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in. <br/></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p></blockquote>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2.&nbsp; Find nearest�</h5>
<p>&nbsp;</p>
<p>If you would like help finding a station, you can click on ''Find nearest�'' to see a list of stations near the location you specify.</p>
<p>Once you see a list of stations and tick the ones you would like to travel from, you will have the option to continue planning the journey (by clicking ''Next'' on that page). This will return you to the current page.</p></blockquote>
<p>&nbsp;</p>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Advanced options</h3><br/>
<h4>Public Transport journey details</h4>
<p><strong>Changes (refers to changing from one vehicle to another)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Find (journeys with unlimited, few or no changes)</strong></p>
<p>Choose how much you want the Journey Planner to limit its search to journeys that involve a few changes or no changes.&nbsp; Select:<br/></p>
<ul>
<li>''All journeys (I don''t mind changing)'' to find journeys that best fit your required travel times, regardless of the number of changes required</li> 
<li>''Journeys with a limited number of changes'' to find only those journeys requiring a small number of changes </li>
<li>''Journeys with no changes'' to find journeys with no changes.&nbsp; This could limit the number of journey options found</li></ul>
<p>&nbsp;</p>
<p><strong>Speed (of changes)</strong></p>
<p>Choose how quickly you think you can make these changes.&nbsp; Select:</p>
<ul>
<li>''Fast'' if you can make the changes quickly</li> 
<li>''Average'' if you can make the changes at an average pace</li> 
<li>''Slow'' if you think you will be making the changes at a slower than average pace&nbsp; </li></ul>
<p>For example, you should choose ''Slow'' if you are unfamiliar with the stations, require assistance or are travelling with luggage.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Travelling via a station</h4>
<ul>
<li>
<div>Type the station name in the box. </div></li></ul>
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you. Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in. </p></blockquote>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Once you have completed the page, click ''Next''.&nbsp; </h3>'
,'<h2>Help</h2><br/><br/>
<h3>Dewis gorsafoedd i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enwau''r lleoliad yn y blychau</h5>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<blockquote style="MARGIN-RIGHT: 0px">
<p>e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p></blockquote>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.</p>
<p></p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2.&nbsp; Dod o hyd i''r � agosaf</h5>
<p>&nbsp;</p>
<p>Os dymunwch help i ganfod maes awyr, gallwch glicio ar ''Find nearest...'' i weld rhestr o feysydd awyr sy''n agos i''r lleoliad y nodoch.</p>
<p>Wedi i chi weld rhestr o''r meysydd awyr a thicio''r rhai y dymunwch chi deithio ohonynt, gallwch barhau i gynllunio''r siwrnai (drwy glicio ''Nesa'' ar y dudalen honno). Byddwch yn dychwelyd i''r dudalen gyfredol.</p></blockquote>
<p>&nbsp;</p>
<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul>
<li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy </li>
<li>Ddewis <strong>''Gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd </li>
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr </li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Dewisiadau mwy cymhleth</h3>
<h4>Manylion siwrnai cludiant cyhoeddus</h4>
<p><strong>Newidiadau a ffafrir (mae''n cyfeirio at newid o un cerbyd i''r llall)</strong></p>
<blockquote style="MARGIN-RIGHT: 0px">
<p><strong>Canfyddwch (siwrneion gyda newidiadau niferus, ychydig o newidiadau neu ddim newidiadau) </strong></p>
<p>Dewiswch faint y dymunwch i''r Cynlluniwr Siwrnai gyfyngu ar ei chwiliad i siwrneion sy''n ymwneud ag ychydig o newidiadau neu ddim newidiadau o gwbl. Dewiswch: <br/></p>
<ul>
<li>''Pob siwrnai (does dim bwys gennyf newid)'' i ddod o hyd i siwrneion sy''n gweddu i''ch amserau teithio angenrheidiol, waeth bynnag faint o newidiadau sy''n angenrheidiol</li> 
<li>''Siwrneion gyda nifer cyfyngedig o newidiadau'' i ddarganfod y siwrneion hynny sydd angen nifer fechan o newidiadau yn unig </li>
<li>''Siwrneion gyda dim newidiadau'' i ddod o hyd i siwrneion gyda dim newidiadau. Gallai hyn gyfyngu ar nifer yr opsiynau o siwrneion a ganfyddir</li></ul>
<p>&nbsp;</p>
<p><strong>Cyflymder (newidiadau)</strong></p>
<p>Dewiswch pa mor gyflym y credwch y gallwch wneud y newidiadau hyn. Dewiswch: </p>
<ul>
<li>''Cyflym'' os gallwch wneud y newidiadau yn gyflym </li>
<li>''Cyfartaledd'' os gallwch wneud y newidiadau ar gyflymder cyffredin </li>
<li>''Araf'' os credwch y byddwch yn gwneud y newidiadau ar gyflymder arafach na chyffredin </li></ul>
<p>Er enghraifft dylech ddewis ''Araf'' os ydych yn anghyfarwydd �''r gorsafoedd, os oes arnoch angen cymorth neu os ydych yn teithio gyda bagiau.</p></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Teithio drwy orsaf</h4>
<ul>
<li>
<div>Teipiwch enw''r orsaf yn y blwch</div></li></ul>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch. Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio. </p></blockquote>
<p style="MARGIN-RIGHT: 0px">&nbsp;</p>
<h3 style="MARGIN-RIGHT: 0px">Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''. </h3>'

--  help page content for find a trunk input
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCityToCityInput'
,'<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li> 
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by</li> 
<li>Select the hours from the ''drop-down'' list</li> 
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul><li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li> 
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCityToCityInput'
,'<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li> 
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by</li> 
<li>Select the hours from the ''drop-down'' list</li> 
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul><li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li> 
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCityToCityInput'
,'<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5>
<p>&nbsp;</p>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Click the calendar and select a date from it</li></ul>
<ul>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.&nbsp;&nbsp; If you would like to plan a return journey but are not sure when you are returning, select ''Open return'' in the month/year ''drop-down'' list</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<p>&nbsp;</p>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li> 
<li>Choose ''Leaving at'' to select the earliest time you want to leave the location</li> 
<li>Choose ''Arriving by'' to select the latest time you want to arrive at the destination</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Select the times you would like to travel</h5>
<p>&nbsp;</p>
<ul>
<li>Select "Anytime" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>or</p></blockquote>
<ul>
<li>Select the time you want to either leave at or arrive by</li> 
<li>Select the hours from the ''drop-down'' list</li> 
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<p>&nbsp;</p>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis dyddiadau ac amserau siwrneion allan a dychwel</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch ddyddiad o''r rhestr a ollyngir i lawr ac yna dewiswch fis/blwyddyn</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Cliciwch ar ''Calendr'' a dewiswch ddyddiad ohono </li></ul>
<ul>
<li>Os ydych yn cynllunio siwrnai sydd yn unffordd yn unig, dewiswch ''Dim dychwelyd'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. Os hoffech gynllunio siwrnai ddychwel ond nad ydych yn sicr pryd yr ydych yn dychwelyd, dewiswch ''Tocyn dychwel agored'' yn y rhestr o''r misoedd/blwyddyn a ollyngir i lawr. </li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<p>&nbsp;</p>
<ul><li>Mae gennych ddewis o ddethol yr amser y dymunwch adael y lleoliad arno neu''r amser y dymunwch gyrraedd y gyrchfan erbyn drwy</li> 
<li>Ddewis ''Gadael am'' i ddewis yr amser cynharaf y dymunwch adael y lleoliad</li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewis ''Cyrraedd erbyn'' i ddewis yr amser diweddaraf y dymunwch gyrraedd yn y gyrchfan</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<p>&nbsp;</p>
<ul>
<li>Dewiswch "Unrhyw bryd" </li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>neu</p></blockquote>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00 p.m. = 17.00) </li></ul></blockquote>
<p>&nbsp;</p>
<h3>Wedi i chi gwblhau''r blychau sydd ar �l ar y dudalen hon, dylech glicio ar ''Nesa''.</h3>'

GO

--  help page content for journey details page
EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelJourneyDetails'
,'<p><strong> Journey details <br/> <br/> Public transport journey </strong> <br/> The journey details are initially shown on this page in a diagram format. If you prefer, you can view the details in a table format by clicking "Show details in table".<br/> <br/> <strong> Car journey <br/> </strong> The directions for your car journey are initially shown in a list. If you prefer, you can view them on a map by clicking "Show on map". The map will appear with the directions listed below it.<br/>Journey directions: </p><br/><ul><li>The directions for your journey are summarised at the top of the page</li><li>If the journey involves ferries, tolls, etc. you can click on the name in the instruction to be taken to their websites.</li></ul><br/><p><strong>Amend date and time</strong></p><br/><p>To amend the dates and times of your journey:<br/>1. Select the new date(s) and time(s) in the drop-down lists<br/>2. Click ''Search with new dates/times''<br/><br/>  To amend the entire journey, you can click ''Amend journey'' at the top of the page</p><br/><p><strong>Save as a favourite journey</strong></p><br/><p>To save the journey:<br/>1.   Make sure you are logged in<br/>2.   Enter a meaningful name for the journey (e.g. �Journey to work�) <br/>3. Click ''OK''<br/><br/>You can save up to five journeys and you can overwrite existing journeys.</p><br/><p><strong>Send to a friend</strong></p><p>To send this page to a friend:<br/>1. Make sure you are logged in.<br/>  2. If you are not logged in, you will need to enter your username and password.<br/>3. Type in the email address of the person you would like to send the page to in the box<br/>4. Click ''Send''<br/><br/>A text-based email with a summary of the journey and the details/directions will be sent to that email address.  Maps (if applicable) will be attached as an image file (Avg. email size 150k).  Your email address will be shown in the email.</p><br/>'
,'<p><strong> Manylion siwrnai <br/> <br/> Siwrnai cludiant cyhoeddus </strong> <br/> Dangosir manylion y siwrnai i ddechrau ar y dudalen hon ar ffurf diagram.  Os yw''n well gennych, gallwch weld y manylion ar ffurf tabl drwy glicio ar ''Dangos manylion mewn tabl''.<br/> <br/> <strong> Siwrnai car <br/> </strong> Dangosir y cyfeiriadau ar gyfer eich siwrnai car i ddechrau mewn rhestr.  Os byddai''n well gennych, gallwch eu gweld ar fap drwy glicio ar ''Dangoswch ar y map''. Bydd y map yn ymddangos gyda''r cyfarwyddiadau wedi eu rhestru oddi tano. <br/>Cyfeiriadau''r siwrnai: </p><br/><ul><li>Rhoddir crynodeb o''r cyfarwyddiadau ar gyfer eich siwrnai ar frig y dudalen.</li><li>Os yw''r siwrnai yn ymwneud � ffer�au, tollau ac ati, gallwch glicio ar yr enw yn y cyfarwyddyd i gael eich cymryd i''w gwefannau.</li></ul><br/><p><strong>Newidiwch y dyddiad a''r amser</strong></p><br/><p>I ddiwygio dyddiadau ac amserau eich siwrnai:<br/>1. Dewiswch y dyddiad(au) a''r amser(au) newydd yn y rhestrau a ollyngir i lawr<br/>2. Cliciwch ar ''Chwiliwch gyda dyddiadau/amserau newydd''<br/><br/>  I ddiwygio''r siwrnai gyfan, gallwch glicio ''Diwygiwch y siwrnai'' ar frig y dudalen.</p><br/><p><strong>Cadwch fel hoff siwrnai</strong></p><br/><p>I gadw''r siwrnai:<br/>1.   Gofalwch eich bod wedi logio i mewn<br/>2.   Rhowch enw ystyrlon i''r siwrnai (e.e. ''Siwrnai i''r gwaith'')<br/>3. Cliciwch ar ''Iawn''.<br/><br/>Gallwch gadw hyd at bump siwrnai a gallwch ysgrifennu dros siwrneion presennol.</p><br/><p><strong>Anfonwch y dudalen hon at ffrind drwy ebost</strong></p><br/><p>I anfon y dudalen hon at ffrind:<br/>1. Gofalwch eich bod wedi logio i mewn.<br/>  2. Os nad ydych wedi logio i mewn, bydd yn rhaid i chi roi eich enw defnyddiwr a''ch cyfrinair.<br/>3. Teipiwch gyfeiriad ebost y sawl yr hoffech anfon y dudalen atynt yn y blwch<br>4. Cliciwch ''Anfon''<br/><br/>Anfonir ebost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau at y cyfeiriad ebost hwnnw.  Atodir mapiau (os yn berthnasol) fel ffeil ddelwedd (maint ebost cyfartalog 150k). Dangosir eich cyfeiriad ebost yn yr e-bost.</p><br/>'

GO

--  help page content for journey summary page
EXEC AddtblContent
1, 1, 'langStrings', 'journeySummaryHelpLabel'
,'<p>To select and view information about a journey:<br/>1. Click one of the buttons in the blue column on the right to select a  journey<br/>   2. Click the buttons above the journeys to view ''Details'', ''Maps'', ''Tickets/Costs'', or ''Modify journey'' for the   selected journey<br/><br/>To print any of the pages, click ''Printer friendly''.  This will open a printer-friendly page that you can print  as usual.</p><br/><br/><strong>Amend date and time</strong><br/><p>To amend the dates and times of your journey:<br/>1. Select the new date(s) and time(s) in the drop-down lists<br/>2. Click ''Search with new dates/times''<br/><br/>  To amend the entire journey, you can click ''Amend journey'' at the top of the page</p><br/><strong>Save as a favourite journey</strong><br/><p>To save the journey:<br/>1.   Make sure you are logged in<br/>2.   Enter a meaningful name for the journey (e.g. �Journey to work�) <br/>3. Click ''OK''<br/><br/>You can save up to five journeys and you can overwrite existing journeys.</p><br/><strong>Send to a friend</strong><p>To send this page to a friend:<br/>1. Make sure you are logged in.<br/>  2. If you are not logged in, you will need to enter your username and password.<br/>3. Type in the email address of the person you would like to send the page to in the box<br/>4. Click ''Send''<br/><br/>A text-based email with a summary of the journey and the details/directions will be sent to that email address.  Maps (if applicable) will be attached as an image file (Avg. email size 150k).  Your email address will be shown in the email.</p><br/>'
,'<p>I ddewis a gweld gwybodaeth am siwrnai:<br/>1. Cliciwch un o''r botymau yn y golofn las ar y dde i ddewis siwrnai <br/>   2. Cliciwch y botymau uwchben y siwrneion i weld ''Manylion'', ''Mapiau'', "Tocynnau/Costau", neu ''Diwygiwch y siwrnai'' ar gyfer y siwrnai a ddewisiwyd <br/><br/>I argraffu unrhyw rai o''r tudalennau, cliciwch ''Hawdd ei argraffu''.  Bydd hwn yn agor tudalen hawdd ei hargraffu y gallwch ei hargraffu fel arfer.</p><br/><br/><strong>Newidiwch y dyddiad a''r amser</strong><br/><p>I ddiwygio dyddiadau ac amserau eich siwrnai:<br/>1. Dewiswch y dyddiad(au) a''r amser(au) newydd yn y rhestrau a ollyngir i lawr<br/>2. Cliciwch ar ''Chwiliwch gyda dyddiadau/amserau newydd''<br/><br/>  I ddiwygio''r siwrnai gyfan, gallwch glicio ''Diwygiwch y siwrnai'' ar frig y dudalen.</p><br/><strong>Cadwch fel hoff siwrnai</strong><br/><p>I gadw''r siwrnai:<br/>1.   Gofalwch eich bod wedi logio i mewn<br/>2.   Rhowch enw ystyrlon i''r siwrnai (e.e. ''Siwrnai i''r gwaith'')<br/>3. Cliciwch ar ''Iawn''.<br/><br/>Gallwch gadw hyd at bump siwrnai a gallwch ysgrifennu dros siwrneion presennol.</p><br/><strong>Anfonwch y dudalen hon at ffrind drwy ebost</strong><br/><p>I anfon y dudalen hon at ffrind:<br/>1. Gofalwch eich bod wedi logio i mewn.<br/>  2. Os nad ydych wedi logio i mewn, bydd yn rhaid i chi roi eich enw defnyddiwr a''ch cyfrinair.<br/>3. Teipiwch gyfeiriad ebost y sawl yr hoffech anfon y dudalen atynt yn y blwch<br/>4. Cliciwch ''Anfon''<br/><br/>Anfonir ebost testun gyda chrynodeb o''r siwrnai a''r manylion/cyfarwyddiadau at y cyfeiriad ebost hwnnw.  Atodir mapiau (os yn berthnasol) fel ffeil ddelwedd (maint ebost cyfartalog 150k). Dangosir eich cyfeiriad ebost yn yr e-bost.</p><br/>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpDetails'
,'<h1>Results page</h1>
<p>&nbsp;</p>
<p>This page displays the journey options that best match your search.&nbsp; These options are summarised in the table.</p>
<p>&nbsp;</p>
<p>You can also view the following information about a selected journey option:</p> 
<ul>
<li>Details</li> 
<li>Maps </li>
<li>Tickets/Costs</li></ul>
<p>&nbsp;</p>
<p>In order to view this information for a journey option:</p> 
<ol>
<li>Select a journey option by selecting the round button to its right</li> 
<li>Click one of the following buttons above the summary table: </li>
<li><ul id="bullet">
<li>''Details''</li> 
<li>''Maps''</li> 
<li>''Tickets/Costs'' </li></ul></li></ol>
<p>These views are described in more detail below:</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Details</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Details'' will display more details for the selected journey.&nbsp; You will see a different view depending on whether the journey involves car or public transport.</p>
<p>&nbsp;</p>
<ul>
<li>Public transport journeys are initially shown as a diagram </li>
<li>Click ''Show&nbsp;in table'' to view the details in a table</li> 
<li>Click ''Show Map'' to view a map for each leg of the journey </li>
<li>Click ''i'' to view information about the transport stations and stops </li>
<li>Car journeys are shown as a set of directions</li> 
<li>Car routes account for the expected traffic levels on the roads</li></ul>
<p><strong></strong>&nbsp;</p>
<p><strong>Maps</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Maps'' will display a map of the selected journey.&nbsp; You can also select to view specific stages of the journey in more detail.</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Tickets/Costs</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Tickets/Costs'' will display fares for the selected journey.&nbsp; </p>
<ul>
<li>For public transport journeys, if you have planned a return journey, return fares will be displayed. In the case where there aren''t any return fares, single fares for both Outward and Return journeys will be displayed. You can also choose to view the single fares clicking the �outward and return single fares� link.</li> 
<li>For car journeys, the various costs that apply to your car journey will be listed. For example, if your journey involves a ferry, the ferry charge will be listed, if a toll bridge is en route, the toll fare will be listed. The ''Fuel cost'' will be displayed by default, but you can also view the ''Total cost'' which includes the running costs, by selecting ''Total cost'' from the drop-down list. </li></ul>
<p>&nbsp;</p>
<p><strong>You can also choose to modify your journey by clicking ''Modify journey''.</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Ways to modify your journey:</p>
<ul>
<li>Add a connecting journey</li>
<li>Combine car and public transport</li>
<li>Adjust the timings within your journey.&nbsp;</li></ul>
<p>&nbsp;</p>
<p><strong>Bookmark this journey for the future</strong></p>
<p>If there''s a journey for which you often request information from Transport Direct, you can add it to your list of Internet "Favourites" so that you don''t need to re-enter the journey details each time (not including "Advanced options").&nbsp; This way, whenever you want to see current results for the journey, simply select it from your "Favourites" and the results page will open in a new window.&nbsp;&nbsp; </p>
<p>&nbsp;</p>
<p>To do this, click the "Bookmark this journey for the future" link.&nbsp; You will then see a window displaying the name of the specified journey.&nbsp; You can either keep that name or change it to something you are more familiar with (e.g. My journey to work) and click "Ok" to save the link.&nbsp; From then on, it will remain in your "Favourites" list.</p>
<p>&nbsp;</p>
<p>(Please note:&nbsp; This feature works with Internet Explorer.&nbsp; However, if you are using a browser that this feature does not work on, you could instead use the "Save as favourite journey" function when you are logged in.)</p>
<p>&nbsp;</p>
<p><strong>If you want to print out any page of information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong><br/></p>
<p></p>'
,'<h1>Tudalen canlyniadau</h1>
<p>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos yr opsiynau o ran siwrneion sy''n cyfateb orau i''ch ymchwil. Rhoddir crynodeb o''r opsiynau hyn yn y tabl.</p>
<p>&nbsp;</p>
<p>Gallwch hefyd weld yr wybodaeth ganlynol am ddewis ynghylch siwrnai ddetholedig:</p>
<ul>
<li>Manylion </li>
<li>Mapiau </li>
<li>Tocynnau/Costau</li></ul>
<p>&nbsp;</p>
<p>Er mwyn gweld yr wybodaeth hon ar gyfer siwrnai a ddewiswyd:</p>
<ol>
<li>Dewiswch siwrnai trwy ddewis y botwm crwn ar y dde </li>
<li>Cliciwch un o''r botymau canlynol uwchben y tabl crynodeb: </li>
<li><ul id="bullet">
<li>''Manylion'' </li>
<li>''Mapiau''&nbsp;</li> 
<li>''Tocynnau/Costau''</li></ul></li></ol>
<p>Disgrifir y rhain yn fanylach isod:</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Manylion</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Manylion'' yn rhoi mwy o fanylion am y siwrnai a ddewiswyd. Fe welwch olygfa wahanol yn dibynnu ar p''run ai a yw''r siwrnai yn ymwneud � theithio mewn car neu ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<ul>
<li>Dangosir siwrneion cludiant cyhoeddus i ddechrau fel diagram </li>
<li>Cliciwch ar ''Dangoswch fanylion ar ffurf tabl'' i weld y manylion yn y tabl </li>
<li>Cliiwch ar ''Map'' i weld map ar gyfer pob adran o''r siwrnai</li> 
<li>Cliciwch ar ''Gwyb.'' i weld gwybodaeth am y gorsafoedd cludiant a''r arosfannau </li>
<li>Dangosir y llwybrau i foduron fel set o gyfarwyddiadau </li>
<li>Mae''r llwybrau ar gyfer moduron yn ystyried y lefelau traffig disgwyliedig ar y ffyrdd.</li></ul>
<p><strong>&nbsp;</strong></p>
<p><strong>Mapiau</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Mapiau'' yn arddangos map o''r siwrnai a ddewiswyd. Gallwch hefyd ddewis gweld camau penodol o''r siwrnai yn fanylach.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>Tocynnau/Costau</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Tocynnau/Costau'' yn arddangos tocynnau a phrisiau neu gostau tocynnau am y siwrnai a ddewiswyd.</p>
<ul>
<li>Ar gyfer siwrneion cludiant cyhoeddus, os ydych wedi cynllunio siwrnai ddychwel, bydd tocynnau dychwel yn cael eu dangos. Mewn achos lle nad oes unrhyw docynnau dychwel, dangosir pris tocyn sengl ar gyfer siwrnai Allanol a siwrnai Dychwel. Gallwch hefyd ddewis edrych ar bris tocynnau sengl drwy glicio ar y ddolen ''Prisiau tocynnau mynd a dod sengl''. </li>
<li>Ar gyfer siwrneion ceir, bydd y costau sy''n berthnasol i''ch siwrnai car yn cael eu rhestru. Er enghraifft, os yw eich siwrnai yn ymwneud � fferi, bydd t�l y fferi yn cael ei restru, os oes pont gyda tholl arni ar y ffordd, rhestrir y doll. Dangosir ''Costau tanwydd'' yn ddiofyn, ond gallwch hefyd edrych ar Cyfanswm y gost sy''n cynnwys y costau cynnal drwy ddewis ''Pob costau'' o''r rhestr a ollyngir i lawr.</li></ul>
<p><strong>&nbsp;</strong></p>
<p><strong>Gallwch hefyd ddewis diwygiwch eich siwrnai drwy glicio ar ''Diwygiwch y siwrnai''.</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Ffyrdd o newid eich siwrnai:</p>
<ul>
<li>Ychwanegwch siwrnai gysylltiol </li>
<li>Cyfuno car a chludiant cyhoeddus </li>
<li>Addaswch yr amseriadau o fewn eich siwrnai.&nbsp;</li></ul>
<p>&nbsp;</p>
<p><strong>Rhowch nod llyfr ar y siwrnai hon ar gyfer y dyfodol</strong></p>
<p>&nbsp;</p>
<p>Os oes siwrnai yr ydych yn gofyn am wybodaeth amdani oddi wrth Transport Direct yn aml, gallwch ei hychwanegu at eich rhestr o ''Ffefrynnau''r'' Rhyngrwyd fel nad oes raid i chi roi manylion y siwrnai i mewn o''r newydd bob tro (heb gynnwys "Dewisiadau mwy cymhleth").&nbsp; Fel hyn, pryd bynnag y dymunwch weld canlyniadau cyfredol ar gyfer y siwrnai, dewiswch hi o''ch ''Ffefrynnau'' a bydd y dudalen canlyniadau yn agor mewn ffenestr newydd. </p>
<p>&nbsp;</p>
<p>I wneud hyn, cliciwch y cyswllt ''Rhowch nod llyfr ar y siwrnai hon ar gyfer y dyfodol''.&nbsp; Yna fe welwch ffenestr yn dangos enw''r siwrnai a ddetholwyd.&nbsp; Gallwch naill ai gadw''r enw hwnnw neu ei newid i rywbeth yr ydych yn fwy cyfarwydd ag ef (e.e. Fy siwrnai i''r gwaith) a chlicio ''Iawn'' i gadw''r cyswllt.&nbsp; O hynny ymlaen, bydd yn parhau yn eich rhestr ''Ffefrynnau''.</p>
<p>&nbsp;</p>
<p>(Sylwer:&nbsp; Mae''r nodwedd hon yn gweithio gydag Internet Explorer.&nbsp; Fodd bynnag, os ydych chi''n defnyddio porwr nad yw''r nodwedd hon yn gweithio arno, gallwch ddefnyddio''r swyddogaeth ''Cadwch fel hoff siwrnai'' yn hytrach pan fyddwch wedi logio i mewn.)</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ar ''Hawdd ei argraffu''. Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpDetails'
,'<h1>Results page</h1>
<p>&nbsp;</p>
<p>This page displays the journey options that best match your search.&nbsp; These options are summarised in the table.</p>
<p>&nbsp;</p>
<p>You can also view the following information about a selected journey option:</p> 
<ul>
<li>Details</li> 
<li>Maps </li>
<li>Tickets/Costs</li></ul>
<p>&nbsp;</p>
<p>In order to view this information for a journey option:</p> 
<ol>
<li>Select a journey option by selecting the round button to its right</li> 
<li>Click one of the following buttons above the summary table: </li>
<li><ul id="bullet">
<li>''Details''</li> 
<li>''Maps''</li> 
<li>''Tickets/Costs'' </li></ul></li></ol>
<p>These views are described in more detail below:</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Details</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Details'' will display more details for the selected journey.&nbsp; You will see a different view depending on whether the journey involves car or public transport.</p>
<p>&nbsp;</p>
<ul>
<li>Public transport journeys are initially shown as a diagram </li>
<li>Click ''Show&nbsp;in table'' to view the details in a table</li> 
<li>Click ''Show Map'' to view a map for each leg of the journey </li>
<li>Click ''i'' to view information about the transport stations and stops </li>
<li>Car journeys are shown as a set of directions</li> 
<li>Car routes account for the expected traffic levels on the roads</li></ul>
<p><strong></strong>&nbsp;</p>
<p><strong>Maps</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Maps'' will display a map of the selected journey.&nbsp; You can also select to view specific stages of the journey in more detail.</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Tickets/Costs</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Tickets/Costs'' will display fares for the selected journey.&nbsp; </p>
<ul>
<li>For public transport journeys, if you have planned a return journey, return fares will be displayed. In the case where there aren''t any return fares, single fares for both Outward and Return journeys will be displayed. You can also choose to view the single fares clicking the �outward and return single fares� link.</li> 
<li>For car journeys, the various costs that apply to your car journey will be listed. For example, if your journey involves a ferry, the ferry charge will be listed, if a toll bridge is en route, the toll fare will be listed. The ''Fuel cost'' will be displayed by default, but you can also view the ''Total cost'' which includes the running costs, by selecting ''Total cost'' from the drop-down list. </li></ul>
<p>&nbsp;</p>
<p><strong>You can also choose to modify your journey by clicking ''Modify journey''.</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Ways to modify your journey:</p>
<ul>
<li>Add a connecting journey</li>
<li>Combine car and public transport</li>
<li>Adjust the timings within your journey.&nbsp;</li></ul>
<p>&nbsp;</p>
<p><strong>Bookmark this journey for the future</strong></p>
<p>If there''s a journey for which you often request information from Transport Direct, you can add it to your list of Internet "Favourites" so that you don''t need to re-enter the journey details each time (not including "Advanced options").&nbsp; This way, whenever you want to see current results for the journey, simply select it from your "Favourites" and the results page will open in a new window.&nbsp;&nbsp; </p>
<p>&nbsp;</p>
<p>To do this, click the "Bookmark this journey for the future" link.&nbsp; You will then see a window displaying the name of the specified journey.&nbsp; You can either keep that name or change it to something you are more familiar with (e.g. My journey to work) and click "Ok" to save the link.&nbsp; From then on, it will remain in your "Favourites" list.</p>
<p>&nbsp;</p>
<p>(Please note:&nbsp; This feature works with Internet Explorer.&nbsp; However, if you are using a browser that this feature does not work on, you could instead use the "Save as favourite journey" function when you are logged in.)</p>
<p>&nbsp;</p>
<p><strong>If you want to print out any page of information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong><br/></p>
<p></p>'
,'<h1>Tudalen canlyniadau</h1>
<p>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos yr opsiynau o ran siwrneion sy''n cyfateb orau i''ch ymchwil. Rhoddir crynodeb o''r opsiynau hyn yn y tabl.</p>
<p>&nbsp;</p>
<p>Gallwch hefyd weld yr wybodaeth ganlynol am ddewis ynghylch siwrnai ddetholedig:</p>
<ul>
<li>Manylion </li>
<li>Mapiau </li>
<li>Tocynnau/Costau</li></ul>
<p>&nbsp;</p>
<p>Er mwyn gweld yr wybodaeth hon ar gyfer siwrnai a ddewiswyd:</p>
<ol>
<li>Dewiswch siwrnai trwy ddewis y botwm crwn ar y dde </li>
<li>Cliciwch un o''r botymau canlynol uwchben y tabl crynodeb: </li>
<li><ul id="bullet">
<li>''Manylion'' </li>
<li>''Mapiau''&nbsp;</li> 
<li>''Tocynnau/Costau''</li></ul></li></ol>
<p>Disgrifir y rhain yn fanylach isod:</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Manylion</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Manylion'' yn rhoi mwy o fanylion am y siwrnai a ddewiswyd. Fe welwch olygfa wahanol yn dibynnu ar p''run ai a yw''r siwrnai yn ymwneud � theithio mewn car neu ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<ul>
<li>Dangosir siwrneion cludiant cyhoeddus i ddechrau fel diagram </li>
<li>Cliciwch ar ''Dangoswch fanylion ar ffurf tabl'' i weld y manylion yn y tabl </li>
<li>Cliiwch ar ''Map'' i weld map ar gyfer pob adran o''r siwrnai</li> 
<li>Cliciwch ar ''Gwyb.'' i weld gwybodaeth am y gorsafoedd cludiant a''r arosfannau </li>
<li>Dangosir y llwybrau i foduron fel set o gyfarwyddiadau </li>
<li>Mae''r llwybrau ar gyfer moduron yn ystyried y lefelau traffig disgwyliedig ar y ffyrdd.</li></ul>
<p><strong>&nbsp;</strong></p>
<p><strong>Mapiau</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Mapiau'' yn arddangos map o''r siwrnai a ddewiswyd. Gallwch hefyd ddewis gweld camau penodol o''r siwrnai yn fanylach.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>Tocynnau/Costau</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Tocynnau/Costau'' yn arddangos tocynnau a phrisiau neu gostau tocynnau am y siwrnai a ddewiswyd.</p>
<ul>
<li>Ar gyfer siwrneion cludiant cyhoeddus, os ydych wedi cynllunio siwrnai ddychwel, bydd tocynnau dychwel yn cael eu dangos. Mewn achos lle nad oes unrhyw docynnau dychwel, dangosir pris tocyn sengl ar gyfer siwrnai Allanol a siwrnai Dychwel. Gallwch hefyd ddewis edrych ar bris tocynnau sengl drwy glicio ar y ddolen ''Prisiau tocynnau mynd a dod sengl''. </li>
<li>Ar gyfer siwrneion ceir, bydd y costau sy''n berthnasol i''ch siwrnai car yn cael eu rhestru. Er enghraifft, os yw eich siwrnai yn ymwneud � fferi, bydd t�l y fferi yn cael ei restru, os oes pont gyda tholl arni ar y ffordd, rhestrir y doll. Dangosir ''Costau tanwydd'' yn ddiofyn, ond gallwch hefyd edrych ar Cyfanswm y gost sy''n cynnwys y costau cynnal drwy ddewis ''Pob costau'' o''r rhestr a ollyngir i lawr.</li></ul>
<p><strong>&nbsp;</strong></p>
<p><strong>Gallwch hefyd ddewis diwygiwch eich siwrnai drwy glicio ar ''Diwygiwch y siwrnai''.</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Ffyrdd o newid eich siwrnai:</p>
<ul>
<li>Ychwanegwch siwrnai gysylltiol </li>
<li>Cyfuno car a chludiant cyhoeddus </li>
<li>Addaswch yr amseriadau o fewn eich siwrnai.&nbsp;</li></ul>
<p>&nbsp;</p>
<p><strong>Rhowch nod llyfr ar y siwrnai hon ar gyfer y dyfodol</strong></p>
<p>&nbsp;</p>
<p>Os oes siwrnai yr ydych yn gofyn am wybodaeth amdani oddi wrth Transport Direct yn aml, gallwch ei hychwanegu at eich rhestr o ''Ffefrynnau''r'' Rhyngrwyd fel nad oes raid i chi roi manylion y siwrnai i mewn o''r newydd bob tro (heb gynnwys "Dewisiadau mwy cymhleth").&nbsp; Fel hyn, pryd bynnag y dymunwch weld canlyniadau cyfredol ar gyfer y siwrnai, dewiswch hi o''ch ''Ffefrynnau'' a bydd y dudalen canlyniadau yn agor mewn ffenestr newydd. </p>
<p>&nbsp;</p>
<p>I wneud hyn, cliciwch y cyswllt ''Rhowch nod llyfr ar y siwrnai hon ar gyfer y dyfodol''.&nbsp; Yna fe welwch ffenestr yn dangos enw''r siwrnai a ddetholwyd.&nbsp; Gallwch naill ai gadw''r enw hwnnw neu ei newid i rywbeth yr ydych yn fwy cyfarwydd ag ef (e.e. Fy siwrnai i''r gwaith) a chlicio ''Iawn'' i gadw''r cyswllt.&nbsp; O hynny ymlaen, bydd yn parhau yn eich rhestr ''Ffefrynnau''.</p>
<p>&nbsp;</p>
<p>(Sylwer:&nbsp; Mae''r nodwedd hon yn gweithio gydag Internet Explorer.&nbsp; Fodd bynnag, os ydych chi''n defnyddio porwr nad yw''r nodwedd hon yn gweithio arno, gallwch ddefnyddio''r swyddogaeth ''Cadwch fel hoff siwrnai'' yn hytrach pan fyddwch wedi logio i mewn.)</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ar ''Hawdd ei argraffu''. Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpDetails'
,'<h1>Results page</h1>
<p>&nbsp;</p>
<p>This page displays the journey options that best match your search.&nbsp; These options are summarised in the table.</p>
<p>&nbsp;</p>
<p>You can also view the following information about a selected journey option:</p> 
<ul>
<li>Details</li> 
<li>Maps </li>
<li>Tickets/Costs</li></ul>
<p>&nbsp;</p>
<p>In order to view this information for a journey option:</p> 
<ol>
<li>Select a journey option by selecting the round button to its right</li> 
<li>Click one of the following buttons above the summary table: </li>
<li><ul id="bullet">
<li>''Details''</li> 
<li>''Maps''</li> 
<li>''Tickets/Costs'' </li></ul></li></ol>
<p>These views are described in more detail below:</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Details</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Details'' will display more details for the selected journey.&nbsp; You will see a different view depending on whether the journey involves car or public transport.</p>
<p>&nbsp;</p>
<ul>
<li>Public transport journeys are initially shown as a diagram </li>
<li>Click ''Show&nbsp;in table'' to view the details in a table</li> 
<li>Click ''Show Map'' to view a map for each leg of the journey </li>
<li>Click ''i'' to view information about the transport stations and stops </li>
<li>Car journeys are shown as a set of directions</li> 
<li>Car routes account for the expected traffic levels on the roads</li></ul>
<p><strong></strong>&nbsp;</p>
<p><strong>Maps</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Maps'' will display a map of the selected journey.&nbsp; You can also select to view specific stages of the journey in more detail.</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Tickets/Costs</strong></p>
<p>&nbsp;</p>
<p>Clicking ''Tickets/Costs'' will display fares for the selected journey.&nbsp; </p>
<ul>
<li>For public transport journeys, if you have planned a return journey, return fares will be displayed. In the case where there aren''t any return fares, single fares for both Outward and Return journeys will be displayed. You can also choose to view the single fares clicking the �outward and return single fares� link.</li> 
<li>For car journeys, the various costs that apply to your car journey will be listed. For example, if your journey involves a ferry, the ferry charge will be listed, if a toll bridge is en route, the toll fare will be listed. The ''Fuel cost'' will be displayed by default, but you can also view the ''Total cost'' which includes the running costs, by selecting ''Total cost'' from the drop-down list. </li></ul>
<p>&nbsp;</p>
<p><strong>You can also choose to modify your journey by clicking ''Modify journey''.</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Ways to modify your journey:</p>
<ul>
<li>Add a connecting journey</li>
<li>Combine car and public transport</li>
<li>Adjust the timings within your journey.&nbsp;</li></ul>
<p>&nbsp;</p>
<p><strong>Bookmark this journey for the future</strong></p>
<p>If there''s a journey for which you often request information from Transport Direct, you can add it to your list of Internet "Favourites" so that you don''t need to re-enter the journey details each time (not including "Advanced options").&nbsp; This way, whenever you want to see current results for the journey, simply select it from your "Favourites" and the results page will open in a new window.&nbsp;&nbsp; </p>
<p>&nbsp;</p>
<p>To do this, click the "Bookmark this journey for the future" link.&nbsp; You will then see a window displaying the name of the specified journey.&nbsp; You can either keep that name or change it to something you are more familiar with (e.g. My journey to work) and click "Ok" to save the link.&nbsp; From then on, it will remain in your "Favourites" list.</p>
<p>&nbsp;</p>
<p>(Please note:&nbsp; This feature works with Internet Explorer.&nbsp; However, if you are using a browser that this feature does not work on, you could instead use the "Save as favourite journey" function when you are logged in.)</p>
<p>&nbsp;</p>
<p><strong>If you want to print out any page of information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong><br/></p>
<p></p>'
,'<h1>Tudalen canlyniadau</h1>
<p>&nbsp;</p>
<p>Mae''r dudalen hon yn dangos yr opsiynau o ran siwrneion sy''n cyfateb orau i''ch ymchwil. Rhoddir crynodeb o''r opsiynau hyn yn y tabl.</p>
<p>&nbsp;</p>
<p>Gallwch hefyd weld yr wybodaeth ganlynol am ddewis ynghylch siwrnai ddetholedig:</p>
<ul>
<li>Manylion </li>
<li>Mapiau </li>
<li>Tocynnau/Costau</li></ul>
<p>&nbsp;</p>
<p>Er mwyn gweld yr wybodaeth hon ar gyfer siwrnai a ddewiswyd:</p>
<ol>
<li>Dewiswch siwrnai trwy ddewis y botwm crwn ar y dde </li>
<li>Cliciwch un o''r botymau canlynol uwchben y tabl crynodeb: </li>
<li><ul id="bullet">
<li>''Manylion'' </li>
<li>''Mapiau''&nbsp;</li> 
<li>''Tocynnau/Costau''</li></ul></li></ol>
<p>Disgrifir y rhain yn fanylach isod:</p>
<p><strong></strong>&nbsp;</p>
<p><strong>Manylion</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Manylion'' yn rhoi mwy o fanylion am y siwrnai a ddewiswyd. Fe welwch olygfa wahanol yn dibynnu ar p''run ai a yw''r siwrnai yn ymwneud � theithio mewn car neu ar gludiant cyhoeddus.</p>
<p>&nbsp;</p>
<ul>
<li>Dangosir siwrneion cludiant cyhoeddus i ddechrau fel diagram </li>
<li>Cliciwch ar ''Dangoswch fanylion ar ffurf tabl'' i weld y manylion yn y tabl </li>
<li>Cliiwch ar ''Map'' i weld map ar gyfer pob adran o''r siwrnai</li> 
<li>Cliciwch ar ''Gwyb.'' i weld gwybodaeth am y gorsafoedd cludiant a''r arosfannau </li>
<li>Dangosir y llwybrau i foduron fel set o gyfarwyddiadau </li>
<li>Mae''r llwybrau ar gyfer moduron yn ystyried y lefelau traffig disgwyliedig ar y ffyrdd.</li></ul>
<p><strong>&nbsp;</strong></p>
<p><strong>Mapiau</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Mapiau'' yn arddangos map o''r siwrnai a ddewiswyd. Gallwch hefyd ddewis gweld camau penodol o''r siwrnai yn fanylach.</p>
<p><strong>&nbsp;</strong></p>
<p><strong>Tocynnau/Costau</strong></p>
<p>&nbsp;</p>
<p>Bydd clicio ar ''Tocynnau/Costau'' yn arddangos tocynnau a phrisiau neu gostau tocynnau am y siwrnai a ddewiswyd.</p>
<ul>
<li>Ar gyfer siwrneion cludiant cyhoeddus, os ydych wedi cynllunio siwrnai ddychwel, bydd tocynnau dychwel yn cael eu dangos. Mewn achos lle nad oes unrhyw docynnau dychwel, dangosir pris tocyn sengl ar gyfer siwrnai Allanol a siwrnai Dychwel. Gallwch hefyd ddewis edrych ar bris tocynnau sengl drwy glicio ar y ddolen ''Prisiau tocynnau mynd a dod sengl''. </li>
<li>Ar gyfer siwrneion ceir, bydd y costau sy''n berthnasol i''ch siwrnai car yn cael eu rhestru. Er enghraifft, os yw eich siwrnai yn ymwneud � fferi, bydd t�l y fferi yn cael ei restru, os oes pont gyda tholl arni ar y ffordd, rhestrir y doll. Dangosir ''Costau tanwydd'' yn ddiofyn, ond gallwch hefyd edrych ar Cyfanswm y gost sy''n cynnwys y costau cynnal drwy ddewis ''Pob costau'' o''r rhestr a ollyngir i lawr.</li></ul>
<p><strong>&nbsp;</strong></p>
<p><strong>Gallwch hefyd ddewis diwygiwch eich siwrnai drwy glicio ar ''Diwygiwch y siwrnai''.</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Ffyrdd o newid eich siwrnai:</p>
<ul>
<li>Ychwanegwch siwrnai gysylltiol </li>
<li>Cyfuno car a chludiant cyhoeddus </li>
<li>Addaswch yr amseriadau o fewn eich siwrnai.&nbsp;</li></ul>
<p>&nbsp;</p>
<p><strong>Rhowch nod llyfr ar y siwrnai hon ar gyfer y dyfodol</strong></p>
<p>&nbsp;</p>
<p>Os oes siwrnai yr ydych yn gofyn am wybodaeth amdani oddi wrth Transport Direct yn aml, gallwch ei hychwanegu at eich rhestr o ''Ffefrynnau''r'' Rhyngrwyd fel nad oes raid i chi roi manylion y siwrnai i mewn o''r newydd bob tro (heb gynnwys "Dewisiadau mwy cymhleth").&nbsp; Fel hyn, pryd bynnag y dymunwch weld canlyniadau cyfredol ar gyfer y siwrnai, dewiswch hi o''ch ''Ffefrynnau'' a bydd y dudalen canlyniadau yn agor mewn ffenestr newydd. </p>
<p>&nbsp;</p>
<p>I wneud hyn, cliciwch y cyswllt ''Rhowch nod llyfr ar y siwrnai hon ar gyfer y dyfodol''.&nbsp; Yna fe welwch ffenestr yn dangos enw''r siwrnai a ddetholwyd.&nbsp; Gallwch naill ai gadw''r enw hwnnw neu ei newid i rywbeth yr ydych yn fwy cyfarwydd ag ef (e.e. Fy siwrnai i''r gwaith) a chlicio ''Iawn'' i gadw''r cyswllt.&nbsp; O hynny ymlaen, bydd yn parhau yn eich rhestr ''Ffefrynnau''.</p>
<p>&nbsp;</p>
<p>(Sylwer:&nbsp; Mae''r nodwedd hon yn gweithio gydag Internet Explorer.&nbsp; Fodd bynnag, os ydych chi''n defnyddio porwr nad yw''r nodwedd hon yn gweithio arno, gallwch ddefnyddio''r swyddogaeth ''Cadwch fel hoff siwrnai'' yn hytrach pan fyddwch wedi logio i mewn.)</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ar ''Hawdd ei argraffu''. Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

GO
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1242
SET @ScriptDesc = 'Update help content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO