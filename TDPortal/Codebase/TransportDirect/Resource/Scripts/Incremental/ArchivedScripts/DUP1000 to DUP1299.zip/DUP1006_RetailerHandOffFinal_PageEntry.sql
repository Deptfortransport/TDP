-- ***********************************************
-- NAME 		: DUP1006_RetailerHandOffFinal_PageEntry.sql
-- DESCRIPTION 		: Addded page entry event type for RetailerHandOffFinal page
-- AUTHOR		: Amit Patel
-- DATE			: 02 Jul 2008 12:53:00
-- ************************************************

USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'TicketRetailersHandOffFinal') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'TicketRetailersHandOffFinal', 'Ticket Retailers HandOff' FROM PageEntryType
GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1006
SET @ScriptDesc = 'Added TicketRetailerHandOff page event type'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO