-- ***********************************************
-- NAME 		: DUP1194_TDCycleUserPreferences_Properties_2.sql
-- DESCRIPTION 		: Script to add properties required for the TDCycleUserPreferences
-- AUTHOR		: Mark Turner
-- DATE			: 24 Nov 2008
-- ************************************************

-- Overides the properties specified in DUP1162

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.NumberOfPreferences' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.NumberOfPreferences', '15', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '15'
	where pname = 'CyclePlanner.TDUserPreference.NumberOfPreferences' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference0' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference0', '850', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '850'
	where pname = 'CyclePlanner.TDUserPreference.Preference0' AND aid = 'Web' AND gid = 'UserPortal'
END

GO


IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference1' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference1', '11000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '11000'
	where pname = 'CyclePlanner.TDUserPreference.Preference1' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference2' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference2', 'Congestion', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Congestion'
	where pname = 'CyclePlanner.TDUserPreference.Preference2' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference3' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference3', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference3' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference4' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference4', 'Bicycle', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Bicycle'
	where pname = 'CyclePlanner.TDUserPreference.Preference4' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference5' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference5', '19', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '19'
	where pname = 'CyclePlanner.TDUserPreference.Preference5' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference6' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference6', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference6' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference7' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference7', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference7' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference8' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference8', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference8' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference9' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference9', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference9' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference10' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference10', '', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = ''
	where pname = 'CyclePlanner.TDUserPreference.Preference10' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference11' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference11', '', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = ''
	where pname = 'CyclePlanner.TDUserPreference.Preference11' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference12' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference12', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference12' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference13' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference13', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference13' AND aid = 'Web' AND gid = 'UserPortal'
END

GO


IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference14' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference14', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference14' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1194
SET @ScriptDesc = 'Script to add properties required for the the TDCycleUserPreferences'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO