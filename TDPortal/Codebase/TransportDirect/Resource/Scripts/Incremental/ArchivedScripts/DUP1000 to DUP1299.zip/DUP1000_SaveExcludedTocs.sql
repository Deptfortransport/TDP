-- ***********************************************
-- NAME 		: DUP1000_SaveExcludedTocs.sql
-- DESCRIPTION 		: Script to add saveexcludedtocs stored proc
-- AUTHOR		: James Chapman
-- DATE			: 26 June 2008 18:00:00
-- ************************************************

USE [TransientPortal]
GO

/****** Object:  StoredProcedure [dbo].[SaveApplicableTocs]    Script Date: 06/12/2008 14:44:53 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

CREATE Procedure [dbo].[SaveExcludedTocs]
	(
		@TocRef text,
		@AtocName text,
		@ApplicableTocs_Id int
	)
AS

	--Delete From ExcludedTocs Where ApplicableTocs_Id = ApplicableTocs_Id
	
	Insert into ExcludedTocs
	(
		TocRef,
		AtocName,
		ApplicableTocs_Id
	)
	values
	(
		@TocRef,
		@AtocName,
		@ApplicableTocs_Id
	)

GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1000
SET @ScriptDesc = 'Script to add saveexcludedtocs stored proc'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

