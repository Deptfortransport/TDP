-- ***********************************************
-- NAME 		: DUP1199_Air_Accessibility_Link.sql
-- DESCRIPTION 		: Update with Welsh translation
-- AUTHOR		: John Frank
-- DATE			: 1st December 2008
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelAccessibilityFootnoteLine2.Text'
,'More information about ', 'Mwy o wybodaeth am eich '
GO

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelAccessibilityFootnoteLine2.LinkText'
,'your accessibility rights when you fly (opens new window).', 'hawliau hygyrchedd pan fyddwch yn hedfan (mae''n agor ffenestr newydd).'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1199
SET @ScriptDesc = 'Add rows to content DB for Air Accessibility Rights Link Welsh translations'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO