-- ***********************************************
-- NAME 		: DUP1173_CyclePlanner_RemoveLeftHandLinks.sql
-- DESCRIPTION 		: Script to remove left hand navigation and related links for Cycle planner
-- AUTHOR		: Mark Turner
-- DATE			: 10 Nov 2008
-- ************************************************


-- IMPORTANT, this script relies on DUP1081, and DU1082 having been run

USE [TransientPortal]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- BEING TIDY UP
-- If this script is run multiple times, we can end up with multiple Find a Cycle input links on the Homepage / Plan a Journey Homepage. 
-- So delete them first.



-- Remove any previously added Related Links that we added for the Cycle planner

DECLARE @ContextId INT

-- Tidy up ContextSuggestionLink
IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')

	DELETE 
	FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END

GO

DELETE     
FROM    ContextSuggestionLink
WHERE   (SuggestionLinkId IN
                            (SELECT     SuggestionLinkId    -- Get all suggestion links which are for the Plan a journey category
                             FROM          SuggestionLink   -- and use our new FindACycle resource 
                             WHERE      (LinkCategoryId =
                                                        (SELECT     LinkCategoryId
                                                         FROM          LinkCategory
                                                         WHERE      [name] = 'Plan a journey'))
                                                         AND (ResourceNameId =
                                                                              (SELECT     ResourceNameID
                                                                               FROM          ResourceName
                                                                               WHERE      ResourceName = 'FindACycle')))) 
                            AND (ThemeId IN (1, 2, 3, 4, 5, 6))    -- ALL THEMES
                            AND (ContextId IN    -- And only for the Homepage or Plan a journey mini homepage
                                              (SELECT     ContextId
                                                FROM          Context
                                                WHERE      [Name] = 'HomePageMenu' OR
                                                           [Name] = 'HomePageMenuPlanAJourney'))


-- And also need to delete the previously added Suggestion Links for Find a Cycle input. This ensures the correct one is used for the 
-- Homepage context, and the Plan a Journey homepage context

-- Tidy up SuggestionLink
DELETE
FROM          SuggestionLink    -- Get all suggestion links which are for the Plan a journey category
WHERE      (LinkCategoryId =    -- and use our new FindACycle resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Plan a journey')) AND (ResourceNameId =
                                                       (SELECT     ResourceNameID
                                                         FROM          ResourceName
                                                         WHERE      ResourceName = 'FindACycle'))





-- Remove any previously added Related Links that we added for the Cycle planner

DECLARE @ContextId INT

-- Tidy up ContextSuggestionLink
IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')

	DELETE 
	FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END

-- Remove the link to the CP FAQ page from the FAQ section of the Left hand nav bar
IF EXISTS (SELECT * FROM InternalLink WHERE [RELATIVEURL] = 'Help/HelpCycle.aspx')
BEGIN
	DELETE
	FROM	InternalLink
	WHERE	RELATIVEURL = 'Help/HelpCycle.aspx'
END

GO

-- END TIDY UP
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1173
SET @ScriptDesc = 'Remove Left hand navigation for cycle planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO