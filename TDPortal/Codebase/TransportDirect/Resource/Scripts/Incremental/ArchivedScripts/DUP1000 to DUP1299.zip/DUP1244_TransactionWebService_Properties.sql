-- ***********************************************
-- NAME 			: DUP1244_TransactionWebService_Properties.sql
-- DESCRIPTION 		        : Script to set up the new TransactionWebService URL properties
-- AUTHOR			: MarkTurner
-- DATE				: 22 Jan 2009
-- ************************************************

USE [PermanentPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- PROPERTIES
--------------------------------------------------------------------------------------------------------------------------------

-- Delete all existing TWS Service URL's properties
IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName LIKE 'TransactionWebService.Services.%')
BEGIN
	DELETE FROM properties WHERE pname LIKE 'TransactionWebService.Services.%'
END

-- Departure Board Service
INSERT INTO properties VALUES ('TransactionWebService.Services.DepartureBoardService.URL', 'http://localhost/EnhancedExposedServices/DepartureBoard/V1/DepartureBoardService.asmx', 'TransactionWebService', 'UserPortal', 0, 1)
GO

-- Find Nearest Service
INSERT INTO properties VALUES ('TransactionWebService.Services.FindNearestService.URL', 'http://localhost/EnhancedExposedServices/FindNearest/V1/FindNearestService.asmx', 'TransactionWebService', 'UserPortal', 0, 1)
GO

-- Sync Journey Planner Service
INSERT INTO properties VALUES ('TransactionWebService.Services.JourneyPlannerSynchronousService.URL', 'http://localhost/EnhancedExposedServices/JourneyPlannerSynchronous/V1/JourneyPlannerSynchronousService.asmx', 'TransactionWebService', 'UserPortal', 0, 1)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1244
SET @ScriptDesc = 'TWS Properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO