-- ***********************************************
-- NAME 		: DUP1063_SoftContent_For_TicketRetailerHandOffPage.sql
-- DESCRIPTION 	: Soft Content for TicketRetailerHandOffFinal Page
-- AUTHOR		: Amit Patel
-- DATE			: 16 Jul 2008 10:38:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO





DECLARE @ThemeId INT
SET @ThemeId = 1 -- for transport direct


EXEC AddtblContent
@ThemeId, 1, 'FaresAndTickets', 'TicketRetailersHandOffFinal.JavascriptDisabledText',
'If the results do not appear within 30 seconds, please click this link.',
'Os nad yw''r canlyniadau yn ymddangos o fewn 30 eiliad ... cliciwch ar y ddolen hon.'

GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1063
SET @ScriptDesc = 'Soft Content for TicketRetailerHandOffFinal Page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
