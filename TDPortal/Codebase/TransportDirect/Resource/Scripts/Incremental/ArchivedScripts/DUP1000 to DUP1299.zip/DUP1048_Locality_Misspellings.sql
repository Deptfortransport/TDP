-- ***********************************************
-- NAME 		: DUP1048_Locality_Misspellings.sql
-- DESCRIPTION 		: Drop and re create LocAliases table in the Gaz and Gaz Staging databases
-- AUTHOR		: John Frank
-- DATE			: 11/07/2008
-- ************************************************

USE GAZ


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'gazadmin.LocAliases') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [gazadmin].[LocAliases]
END
GO

CREATE TABLE [gazadmin].[LocAliases] (
	[AliasName] [varchar] (255)  NULL ,
	[PrimaryID] [varchar] (20)  NULL ,
	[MisSpelling] [varchar] (1)  NULL 
) ON [GAZ_DATA]
GO



USE GAZ_Staging


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'gazadmin.LocAliases') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [gazadmin].[LocAliases]
END
GO

CREATE TABLE [gazadmin].[LocAliases] (
	[AliasName] [varchar] (255)  NULL ,
	[PrimaryID] [varchar] (20)  NULL ,
	[MisSpelling] [varchar] (1)  NULL 
) ON [GAZ_DATA]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1048
SET @ScriptDesc = 'Drop and re create LocAliases table in the Gaz and Gaz Staging databases'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO