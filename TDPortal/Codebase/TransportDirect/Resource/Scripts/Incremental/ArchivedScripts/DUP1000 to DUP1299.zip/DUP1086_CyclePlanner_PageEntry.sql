-- ***********************************************
-- NAME 		: DUP1086_CyclePlanner_PageEntry.sql
-- DESCRIPTION 		: Addded page entry event type for Cycle Planner
-- AUTHOR		: Mitesh Modi
-- DATE			: 05 Jun 2008 18:00:00
-- ************************************************

USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindCycleInput') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindCycleInput', 'Find Cycle Input' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'CycleJourneyDetails') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'CycleJourneyDetails', 'Cycle journey details' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'CycleJourneyGPXDownload') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'CycleJourneyGPXDownload', 'Cycle journey GPX download' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableCycleJourneyDetails') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'PrintableCycleJourneyDetails', 'Printable Cycle journey details' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableJourneyMapTile') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'PrintableJourneyMapTile', 'Printable Cycle journey map' FROM PageEntryType
GO



IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'CycleJourneySummary') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'CycleJourneySummary', 'Cycle journey summary' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableCycleJourneySummary') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'PrintableCycleJourneySummary', 'Printable Cycle journey summary' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'CycleJourneyMap') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'CycleJourneyMap', 'Cycle journey map' FROM PageEntryType
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1086
SET @ScriptDesc = 'Added Cycle page entry event types'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO