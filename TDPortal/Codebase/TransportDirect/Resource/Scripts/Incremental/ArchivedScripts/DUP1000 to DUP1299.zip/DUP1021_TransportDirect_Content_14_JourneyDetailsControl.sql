-- *************************************************************************************
-- NAME 		: DUP1021_TransportDirect_Content_14_JourneyDetailsControl.sql
-- DESCRIPTION          : JourneyDetailsControl
-- AUTHOR		: Phil Scott
-- *************************************************************************************



USE [Content]
GO

-------------------------------------------------------------
-- Accessibility Content
-------------------------------------------------------------

EXEC AddtblContent 1, 1, 'langStrings','JourneyDetailsControl.ArrivalBoardLink.Text','Arrivals','Cyraeddiadau' 

EXEC AddtblContent 1, 1, 'langStrings','JourneyDetailsControl.DepartureBoardLink.Text','Departures','Ymadawiadau' 


EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsTableControl.HeaderItemText10','Map','Map'


EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.ArrivalBoardButton.Text','Click to view arrival board in a new browser window','Bwrdd'


EXEC AddtblContent 1,1,'LangStrings','ArrivalsBoardHyperlink.labelArrivalsBoardNavigation','Click to view arrival board in a new browser window','Bwrdd'



EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.DepartureBoardButton.Text','Click to view departure board in a new browser window','Bwrdd ymadael'


EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.imageDepartureBoardUrl',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/Departures2.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/Departures2.gif'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1021
SET @ScriptDesc = 'JDUP1021_TransportDirect_Content_14_JourneyDetailsControl.sql'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
