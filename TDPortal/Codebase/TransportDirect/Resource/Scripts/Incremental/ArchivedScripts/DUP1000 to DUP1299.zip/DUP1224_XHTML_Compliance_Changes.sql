-- ***********************************************
-- NAME 		: DUP1224_XHTML_Compliance_Changes.sql
-- DESCRIPTION 		: Update content to be XHTML Compliance
-- AUTHOR		: Tej Sohal
-- DATE			: 18 December 2008
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindAStationAmbiguity'
,'<p>Choose a location from the yellow drop-down list.<br />If you cannot find the location you want in the list, you can either: </p>
<ul><li>Search for a different kind of location (e.g. by selecting "Address/postcode")</li></ul>
<p>&nbsp;</p>
<ul><li>Enter a new location (by clicking "New location")</li></ul>
<p>&nbsp;</p>
<p>Then click "Next".</p>'
,
'<p>Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br />Os na ellwch ddod o hyd i''r lleoliad yr ydych am ei gael yn y rhestr hon, gellwch naill ai: </p>
<ul><li>Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</li></ul>
<p>&nbsp;</p>
<ul><li>Rhoi lleoliad newydd (wrth glicio ar ''Lleoliad newydd'')</li></ul>
<p>&nbsp;</p>
<p>Yna cliciwch ''Nesa''.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAStationAmbiguity'
,'<p>Choose a location from the yellow drop-down list.<br />If you cannot find the location you want in the list, you can either: </p>
<ul>
<li>Search for a different kind of location (e.g. by selecting "Address/postcode")</li></ul>
<p>&nbsp;</p>
<ul>
<li>Enter a new location (by clicking "New location")</li></ul>
<p>&nbsp;</p>
<p>Then click "Next". </p>'
,
'<p>Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br />Os na ellwch ddod o hyd i''r lleoliad yr ydych am ei gael yn y rhestr hon, gellwch naill ai: </p>
<ul>
<li>Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')</li></ul>
<p>&nbsp;</p>
<ul>
<li>Rhoi lleoliad newydd (wrth glicio ar ''Lleoliad newydd'')</li></ul>
<p>&nbsp;</p>
<p>Yna cliciwch ''Nesa''. </p>'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1224
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO