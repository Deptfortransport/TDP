-- ***********************************************
-- NAME 		: DUP1150_XHTML_SeasonalNoticeboard_Properties_Updates.sql
-- DESCRIPTION 		: Script to update Seasonal Noticeboard properties for XHTML compliance
-- AUTHOR		: Rich Broddle
-- DATE			: 27 Oct 2008
-- ************************************************

USE [PermanentPortal]
GO

UPDATE [PermanentPortal].[dbo].[properties]
SET  [pValue]='<br />This page shows changes to public transport that could cause Transport Direct to give inaccurate information.  Please check the table below and bear this in mind when planning travel by public transport using the services affected.<br />&nbsp;<br />When you request a public transport journey plan, Transport Direct checks several systems to give you the relevant information.  If these systems are not correct, the same will be true of Transport Direct.  Where we have been advised of incorrect information, details are shown below.'
WHERE [pName]='SeasonalNoticeBoardControl.SeasonalNoticeboardHeading.Text'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1150
SET @ScriptDesc = 'Properties updated for XHTML compliance work on Seasonal Noticeboard'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO