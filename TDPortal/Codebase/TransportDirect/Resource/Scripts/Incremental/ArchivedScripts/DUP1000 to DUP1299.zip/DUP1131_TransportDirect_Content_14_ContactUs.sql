-- ***********************************************
-- NAME 		: DUP1131_TransportDirect_Content_14_ContactUs.sql
-- DESCRIPTION 		: Add Contact Us content
-- AUTHOR		: Mitesh Modi
-- DATE			: 09 Oct 2008 
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 23, 'BodyText', '/Channels/TransportDirect/ContactUs/Details',
'
<div id="primcontent">
<div id="contentarea">
<p><strong>Address</strong></p>
<p>Programme Support Office&nbsp;</p>
<p>Transport Direct</p>
<p>Department for Transport</p>
<p>2nd Floor</p>
<p>55 Victoria Street</p>
<p>LONDON</p>
<p>SW1H 0EU</p><br /><br />
<p><strong>Email</strong></p>
<p>TDPortal.Feedback@dft.gsi.gov.uk</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p></div></div>'
,
'
<div id="primcontent">
<div id="contentarea">
<p><strong>Cyfeiriad</strong></p>
<p>Programme Support Office&nbsp;</p>
<p>Transport Direct</p>
<p>Department for Transport</p>
<p>2nd Floor</p>
<p>55 Victoria Street</p>
<p>LONDON</p>
<p>SW1H 0EU</p><br /><br />
<p><strong>Cyfeiriad ebost</strong></p>
<p>TDPortal.Feedback@dft.gsi.gov.uk</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p></div></div>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1131
SET @ScriptDesc = 'XHTML Updates to Contact Us content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO