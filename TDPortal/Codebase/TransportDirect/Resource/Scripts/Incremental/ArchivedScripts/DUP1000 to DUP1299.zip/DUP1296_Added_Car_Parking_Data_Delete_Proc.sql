-- ***********************************************
-- NAME 		: DUP1296_Updated_Car_Parking_Data_Delete_Proc.sql
-- DESCRIPTION 		: Adds sql procedure to delete data from CarParks database tables
-- AUTHOR		: Amit Patel
-- ************************************************

-- *****
-- ***** EXECUTE permissions below MUST be checked for each environment prior to implementation
-- *****

USE CarParks
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[DeleteCarParkingData]')  
AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[DeleteCarParkingData]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- Create new stored procedure
CREATE PROCEDURE dbo.DeleteCarParkingData 
	@Version int
AS

SET NOCOUNT ON
SET XACT_ABORT ON



BEGIN TRANSACTION T1
		DELETE FROM CarParkingAdditionalData WHERE VersionId = @Version
		DELETE FROM CarParkingPaymentType WHERE VersionId = @Version
		DELETE FROM CarParkingPaymentMethods WHERE VersionId = @Version
		DELETE FROM CarParkingOpeningTimes WHERE VersionId = @Version
		DELETE FROM CarParkingFacilities WHERE VersionId = @Version 
		DELETE FROM CarParkingAttractions WHERE VersionId = @Version 

		DELETE CarParkingCarParkCharges FROM CarParkingCarParkCharges 
			INNER JOIN CarParkingCarParkSpace
			ON CarParkingCarParkCharges.SpaceId = CarParkingCarParkSpace.Id 
			WHERE CarParkingCarParkSpace.VersionId = @Version

		DELETE CarParkingSpaceAvailability FROM CarParkingSpaceAvailability
			INNER JOIN CarParkingCarParkSpace
			ON CarParkingSpaceAvailability.SpaceId = CarParkingCarParkSpace.Id 
			WHERE CarParkingCarParkSpace.VersionId = @Version
		
		DELETE FROM CarParkingCarParkConcessions WHERE VersionId = @Version 	
		DELETE FROM CarParkingCalendar WHERE VersionId = @Version
		DELETE FROM CarParkingCarParkSpace WHERE VersionId = @Version 
		DELETE FROM CarParkingCarParkType WHERE VersionId = @Version 
		DELETE FROM CarParkingNPTGLocality WHERE VersionId = @Version
		DELETE FROM CarParking WHERE VersionId = @Version 
		DELETE FROM CarParkingOperator WHERE VersionId = @Version 
		DELETE FROM CarParkingTrafficNewsRegion WHERE VersionId = @Version
		DELETE FROM CarParkingAccessPoints WHERE VersionId = @Version
		DELETE FROM CarParkingNPTGAdminDistrict WHERE VersionId = @Version
		DELETE FROM CarParkingParkAndRideScheme WHERE VersionId = @Version
		DELETE FROM CarParkingLinkedNaPTANS WHERE VersionId = @Version

		DELETE FROM DataVersion WHERE [Id] = @Version

		
		
		

		
		
		
		
		
		
COMMIT TRANSACTION T1

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1296
SET @ScriptDesc = 'Add new DeleteCarParkingData procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------