-- ***********************************************
-- NAME 		: DUP1067_Update_LeftHandMenu_Links_For_Links_Opening_In_New_Window.sql
-- DESCRIPTION 	: Update to Left Hand Menu links display text for links opening in new window
-- AUTHOR		: Amit Patel
-- DATE		: 23 Jul 2008 10:38:00
-- ************************************************


USE [TransientPortal]
GO



EXEC UpdateSuggestionLinkDisplayText 'DisabilityInformation', 'Information for travellers with disabilities (opens new window)', 'Gwybodaeth i deithwyr gydag anableddau (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.ActOnCo2', 'Act on CO2 (opens new window)', 'Gweithredu ynghylch CO2 (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.Co2Railway', 'CO2 emissions on the railway (opens new window)', 'Allyriadau CO2 ar y rheilffordd (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.CompareFuelEfficiency', 'Compare fuel efficiency of different models of car (opens new window)', 'Cymharwch effeithlonrwydd tanwydd gwahanol fodelau ceir (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.Flying', 'What about the CO2 from flying? (opens new window)', 'Beth am y CO2 wrth hedfan? (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.FuelSavingTips', 'RAC''s fuel saving tips (opens new window)', 'Awgrymiadau arbed tanwydd RAC (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.MotoringAndEnvironment', 'Motoring and the environment (opens new window)', 'Moduro a''r amgylchedd (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.OffsetCarbonEmissions', 'How can I offset my car''s carbon emissions? (opens new window)', 'Sut y gallaf wneud rhywfaint o iawn am allyriadau carbon fy nghar? (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'JourneyEmissions.PT.AirPollutants', 'Emissions of Air Pollutants in the UK (opens new window)', 'Allyriadau Llygryddion Aer yn y DU (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'MobileDemonstrator', 'Mobile/PDA (opens new window)', 'Dolennau cysylltiedig (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'ProvideFeedback.TourismInformation', 'Information on tourism in Britain (opens new window)', 'Gwybodaeth am dwristiaeth ym Mhrydain (yn agor ffenestr newydd)'

EXEC UpdateSuggestionLinkDisplayText 'RealTimeTraffic', 'Real time traffic (opens new window)', 'cy Real time traffic (yn agor ffenestr newydd)'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1067
SET @ScriptDesc = 'Update to Left Hand Menu links display text for links opening in new window'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
