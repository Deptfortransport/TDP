-- *************************************************************************************
-- NAME 		: DUP1016_ArrivalDepartures_Hyperlink_Text.sql
-- DESCRIPTION  : Arrival board hyperlink text
-- AUTHOR		: Phil Scott
-- *************************************************************************************



USE [Content]
GO

-------------------------------------------------------------
-- Accessibility Content
-------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings','JourneyDetailsControl.ArrivalBoardLink.Text','Arrivals','Cyraeddiadau' 
EXEC AddtblContent
1, 1, 'langStrings','JourneyDetailsControl.DepartureBoardLink.Text','Departures','Ymadawiadau' 

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1016
SET @ScriptDesc = 'Arrival Departure board hyperlink text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
