-- ***********************************************
-- NAME 		: DUP1020_AddEventReceiverNameFilterProperties.sql
-- DESCRIPTION 		: Script to add properties used by the EventReceiver in initialising TDLocation
-- AUTHOR		: Mark Turner
-- DATE			: 09 July 2008
-- ************************************************

USE [PermanentPortal]
GO

IF NOT EXISTS (SELECT * FROM properties WHERE (pName = 'LocationService.FilterGivenNameTag') AND (AID = 'EventReceiver') AND 
	(GID = 'EventReceiver') AND (PartnerId = 0) AND (ThemeId = 1))
    BEGIN
	INSERT INTO properties VALUES ('LocationService.FilterGivenNameTag', 'True', 'EventReceiver', 'EventReceiver', 0, 1)
    END
ELSE
    BEGIN
	UPDATE properties SET pValue = 'True' WHERE (pName = 'LocationService.FilterGivenNameTag') AND (AID = 'EventReceiver') AND 
	(GID = 'EventReceiver') AND (PartnerId = 0) AND (ThemeId = 1)
    END


IF NOT EXISTS (SELECT * FROM properties WHERE (pName = 'LocationService.GivenNameTagFilterValues') AND (AID = 'EventReceiver') AND 
	(GID = 'EventReceiver') AND (PartnerId = 0) AND (ThemeId = 1))
    BEGIN
	INSERT INTO properties VALUES ('LocationService.GivenNameTagFilterValues', 'Main Coach Stops|Main Rail / Coach|Main Rail Stations', 'EventReceiver', 'EventReceiver', 0, 1)
    END
ELSE
    BEGIN
	UPDATE properties SET pValue = 'Main Coach Stops|Main Rail / Coach|Main Rail Stations' WHERE (pName = 'LocationService.GivenNameTagFilterValues') AND (AID = 'EventReceiver') AND 
	(GID = 'EventReceiver') AND (PartnerId = 0) AND (ThemeId = 1)
    END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1020
SET @ScriptDesc = 'Add properties used by the EventReceiver in initialising TDLocation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO