-- ***********************************************
-- NAME 		: DUP1272_RoutingGuide_Content.sql
-- DESCRIPTION 	: Content changes for Routing guide
-- AUTHOR		: Mitesh Modi
-- DATE			: 21 January 2009
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelLabelNotePrefix'
,'Note: '
,'Noder: '

EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelFaresAdditionalNoteText'
,'Transport Direct does not currently have fare information for all parts of the journey.<br />'
,'Nid oes gan Transport Direct wybodaeth am docynnau ar gyfer pob rhan o''r siwrnai ar hyn o bryd.<br />'


EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelSingleTicketsNote'
,'It is not possible to travel this rail journey using one ticket - more than one ticket would need to be purchased.<br />'
,'cy It is not possible to travel this rail journey using one ticket - more than one ticket would need to be purchased.<br />'


EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelBreakOfJourney'
,'<a href="/Web2/Help/HelpTrain.aspx#A3.9">For conditions associated with longer breaks of journey please check the relevant FAQ by selecting this link.</a>'
,'cy<a href="/Web2/Help/HelpTrain.aspx#A3.9">For conditions associated with longer breaks of journey please check the relevant FAQ by selecting this link.</a>'



GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1272
SET @ScriptDesc = 'Content changes for Routing Guide'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO