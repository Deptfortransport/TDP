-- ***********************************************
-- NAME 		: DUP1117_ContentDB_AddressPostcode_No_Search_Options.sql
-- DESCRIPTION 		: Add text for No options found in address/postcode gazetteer		: 
-- AUTHOR		: John Frank
-- ************************************************

Use Content
go

EXEC AddtblContent
1, 1, 'langStrings', 'LocationSelectControl2.labelNoMatchForAddressPostcode', 'No options found for <b>"{0}"</b> as<b> "{1}"</b> (Please note that due to the unreliability of PO Box locations, Transport Direct does not support PO Box postcodes)', 'Ni ddarganfuwyd dewis ar gyfer <b>"{0}"</b> fel<b> "{1}"</b> (Please note that due to the unreliability of PO Box locations, Transport Direct does not support PO Box postcodes)'


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1117
SET @ScriptDesc = 'Add text for No options found in address/postcode gazetteer'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------