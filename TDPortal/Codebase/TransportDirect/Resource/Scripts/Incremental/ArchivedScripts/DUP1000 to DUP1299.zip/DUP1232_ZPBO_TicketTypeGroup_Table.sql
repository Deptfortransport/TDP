-- ***********************************************
-- NAME 		: DUP1232_ZPBO_TicketTypeGroup_Table.sql
-- DESCRIPTION 	: Script to create new TicketTypeGroup table, to be used by ZPBO
-- AUTHOR		: Mitesh Modi
-- DATE			: 05 jan 2009
-- ************************************************


USE [TransientPortal]
GO

---------------------------------------------------
-- CREATE TABLE - [TicketTypeGroup]
---------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[TicketTypeGroup]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    DROP TABLE [dbo].[TicketTypeGroup]

END
GO

CREATE TABLE [dbo].[TicketTypeGroup] (
	[TicketTypeCode] [varchar] (10) NOT NULL ,
	[TicketTypeDescription] [varchar] (200) NULL ,
	[TicketTypeGroup] [varchar] (50) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[TicketTypeGroup] ADD 
	CONSTRAINT [PK_TicketTypeGroup] PRIMARY KEY  CLUSTERED 
	(
		[TicketTypeCode]
	)  ON [PRIMARY] 
GO



---------------------------------------------------
-- ADD DATA
---------------------------------------------------

-- Delete all existing data
TRUNCATE TABLE [TicketTypeGroup]

GO

-- Insert the data
INSERT INTO [TicketTypeGroup] VALUES ( '7TF', 'First Class Period Travelcard (7 Day)', 		'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( '7TS', 'Standard Class Travelcard (7 Day)', 			'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'ADT', 'Anytime Day Travelcard', 					'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'DTP', 'Off Peak Day Travelcard PLUS', 				'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'FDT', 'First Class Anytime Day Travelcard', 		'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'FTC', 'Family Travelcard', 							'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'FTP', 'First Class Off Peak Day Travelcard PLUS', 	'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'LOP', 'Low Off-peak Day Travelcard', 				'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'ODT', 'Off-peak Day Travelcard', 					'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'OTF', 'First Class Off-Peak Day Travelcard', 		'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'STO', 'Super Off-Peak Day Travelcard', 				'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'TRF', 'First Class Travelcard', 					'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'TRV', 'Standard Class Travelcard', 					'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'WDT', 'Super Off-Peak Day Travelcard', 				'Travelcard' )
INSERT INTO [TicketTypeGroup] VALUES ( 'WRE', 'Super Off-Peak Day Travelcard', 				'Travelcard' )

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1232
SET @ScriptDesc = 'Script to create new TicketTypeGroup table objects'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO