-- *************************************************************************************
-- NAME 		: DUP1007_ZonalAccessibilityLinks_TableCreate.sql
-- DESCRIPTION  	: Creation of Zonal Accessibility Links table
-- AUTHOR		: Sanjeev Johal
-- *************************************************************************************


USE [TransientPortal]
GO

-------------------------------------------------------------
-- Create Table Columns
-------------------------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ZonalAccessibilityLinks') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ZonalAccessibilityLinks (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[ExternalLinkId] [varchar] (500) NULL,
		[Naptan] [varchar] (12) NULL,
		[RegionId] [varchar] (20) NULL,
		[ModeId] [varchar] (20) NULL,
		[OperatorCode] [varchar] (20) NULL,
		[AdminAreaId] [int] NULL,
		[DistrictId] [int] NULL,
	) ON [PRIMARY]

	-- Primary Key
	ALTER TABLE dbo.ZonalAccessibilityLinks ADD CONSTRAINT
		PK_ZonalAccessibilityLinks PRIMARY KEY CLUSTERED ( Id ) 
END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1007
SET @ScriptDesc = 'Creation of Zonal Accessibility Links table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
