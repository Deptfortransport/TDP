-- ***********************************************
-- NAME 		: DUP1004_Add_XMLRailTicketFeed_link.sql
-- DESCRIPTION 		: Script to add XML rail ticket feed url property
-- AUTHOR		: Steve Tsang
-- DATE			: 30 June 2008 18:00:00
-- ************************************************

-----------------------------------------------------------------------
-- Properties 
-----------------------------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ThemeId INT
SET @ThemeId = 1


IF not exists (select top 1 * from properties where pName = 'XMLFeedSource' and ThemeId = @ThemeId)
BEGIN
	insert into properties values ('XMLFeedSource', 'http://internal.nationalrail.co.uk/ticketTypeDescriptions.xml', '<DEFAULT>', '<DEFAULT>', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://internal.nationalrail.co.uk/ticketTypeDescriptions.xml'
	where pname = 'XMLFeedSource' and ThemeId = @ThemeId
END

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1004
SET @ScriptDesc = 'Script to add XML rail ticket feed url property'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO