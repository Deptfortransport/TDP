-- *************************************************************************************
-- NAME 		: DUP1081_Update AddSuggestionLink.sql
-- DESCRIPTION  	: Add Related Link heading and FAQ 'Park Mark' section 6.5 url to
-- DESCRIPTION  	: Find nearest Carpark & Drive to Carpark result screens
-- AUTHOR		: Neil Rankin
-- *************************************************************************************

USE TransientPortal

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- =============================================  
-- Description: AddSuggestionLink (adds the link bringing together the url and display text)
-- NOTE: This currently as a default SubRootLinkID of 0
-- =============================================  
ALTER  PROCEDURE [dbo].[AddSuggestionLink]    
		@StringLinkResourceName	varchar(100),
		@StringLinkDescription	varchar(500),
		@LinkCategoryName 	varchar(100),
		@LinkPriority 		INT,
		@InternalLinkFlag	bit,
		@IsRoot			bit,
		@IsSubRootLink		bit,
		@SubRootLinkId 		INT,
		@ExternalLinkID		varchar(500)
AS    
BEGIN

	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)  

	DECLARE @SuggestionLinkID INT,
		@LinkCategoryID INT, 
		@ResourceNameID INT,
		@InternalExternalLinkID INT,
		@StringInternalExternal varchar (10)


	-- Get the ID's needed for a new suggestion link record
	SET @LinkCategoryID = (select LinkCategoryID from [dbo].[LinkCategory] where [Name] = @LinkCategoryName)
	SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @StringLinkResourceName)

	IF (@InternalLinkFlag = 1)
	BEGIN
		SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @StringLinkDescription)
		SET @StringInternalExternal = 'Internal'
	END
	ELSE
	BEGIN
		SET @InternalExternalLinkID = (select ExternalSuggestionLinkID from [dbo].[ExternalSuggestionLink] where ExternalLinkID = @ExternalLinkID)
		SET @StringInternalExternal = 'External'
	END


	SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from [dbo].[SuggestionLink]) + 1

	IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	BEGIN
		INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot], [IsSubRootLink], [SubRootLinkId])
		SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, @StringInternalExternal, @IsRoot, @IsSubRootLink, @SubRootLinkId
	END
	ELSE
	BEGIN
		SET @localString_UnableToCarryOutAction = 'Unable to add suggestion link with Link Category: ' + @LinkCategoryName 
			+ ', and Link Priority: ' + Cast( @LinkPriority as varchar(10) ) + '. Already exists in SuggestionLink table'
	        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
	        RETURN -1
	END
	
	IF @@error <> 0
    		BEGIN
			SET @localString_UnableToCarryOutAction = 'Unable to add record ' + @StringLinkResourceName + ' to SuggestionLink table'

		        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
		        RETURN -1
		END

END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1081
SET @ScriptDesc = 'Update AddSuggestionLink'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO