-- **********************************************************************
-- $Workfile:   DUP1104_AddNewBankHolidays_2009_Onwards.sql  $
-- AUTHOR       : j.roberts
-- DATE CREATED : 12/09/2008
-- REVISION     : $Revision:   1.0  $
-- DESCRIPTION  : Creates stored procedure to update bank holidays
--                Updates bank holidays to end of 2010
-- Information taken from http://www.direct.gov.uk/en/Governmentcitizensandrights/LivingintheUK/DG_073741
-- **********************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP1104_AddNewBankHolidays_2009_Onwards.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 11:00:16   mmodi
--Initial revision.
--
--   Rev 1.2   Sep 12 2008 15:30:48   jroberts
--.
--
--   Rev 1.1   Sep 12 2008 15:07:42   jroberts
--Creates stored procedure to update bank holidays
--
--   Rev 1.0   Sep 12 2008 15:05:24   jroberts
--Initial revision.
--
--
--

USE [PermanentPortal]

-- **********************************************************************
-- PROCEDURE INFAddBankHoliday
-- **********************************************************************
DECLARE @ObjectName AS varchar(128)
SET @ObjectName = N'INFAddBankHoliday'
IF NOT EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = @ObjectName
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
    EXEC ('CREATE PROCEDURE [dbo].INFAddBankHoliday AS BEGIN SELECT 1 END')

    EXEC sp_addextendedproperty @name=N'Design', @value=N'SD00?? ?????' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Owner', @value=N'TDP' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Used By', @value=N'TDP.??????' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName

END
GO


GO
-- **********************************************************************
-- PROCEDURE INFAddBankHoliday
-- Description: Adds bank holidays to database
-- **********************************************************************
ALTER PROCEDURE [dbo].INFAddBankHoliday
(
    @Holiday datetime,
    @Country int
) AS
BEGIN
    IF EXISTS(SELECT 1
                FROM [dbo].[BankHolidays]
               WHERE Holiday = @Holiday)
        BEGIN
            UPDATE [dbo].[BankHolidays]
               SET Country = @Country
             WHERE Holiday = @Holiday
        END
    ELSE
        BEGIN
            INSERT INTO [dbo].[BankHolidays]
            (
                [Holiday],
                [Country]
            )
            VALUES
            (
                @Holiday,
                @Country
            )
        END
    --END IF
END
GO

-- Update dates to end of 2010
BEGIN

    DECLARE @Holiday datetime

    DECLARE @EnglandWales int
    DECLARE @Scotland int
    DECLARE @UK int

    SET @EnglandWales = 1
    SET @Scotland = 2
    SET @UK = 3
    
    SET @Holiday = '2008-01-01'
    EXEC INFAddBankHoliday @Holiday, @UK 
    
    SET @Holiday = '2008-01-02'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2008-03-21'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2008-03-24'
    EXEC INFAddBankHoliday @Holiday, @EnglandWales

    SET @Holiday = '2008-04-06'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2008-05-05'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2008-05-26'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2008-08-04'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2008-08-25'
    EXEC INFAddBankHoliday @Holiday, @EnglandWales

    SET @Holiday = '2008-12-01'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2008-12-25'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2008-12-26'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2009-01-01'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2009-01-02'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2009-04-10'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2009-04-13'
    EXEC INFAddBankHoliday @Holiday, @EnglandWales

    SET @Holiday = '2009-05-04'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2009-05-25'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2009-08-03'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2009-08-31'
    EXEC INFAddBankHoliday @Holiday, @EnglandWales 

    SET @Holiday = '2009-11-30'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2009-12-25'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2009-12-28'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2010-01-01'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2010-01-04'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2010-04-02'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2010-04-05'
    EXEC INFAddBankHoliday @Holiday, @EnglandWales

    SET @Holiday = '2010-05-03'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2010-05-31'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2010-08-02'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2010-08-30'
    EXEC INFAddBankHoliday @Holiday, @EnglandWales 

    SET @Holiday = '2010-11-30'
    EXEC INFAddBankHoliday @Holiday, @Scotland 

    SET @Holiday = '2010-12-27'
    EXEC INFAddBankHoliday @Holiday, @UK

    SET @Holiday = '2010-12-28'
    EXEC INFAddBankHoliday @Holiday, @UK

END
GO




GO
-- ************************************************ 
-- Update the Change Log
-- ************************************************ 
DECLARE @ScriptNumber int
DECLARE @ScriptDesc varchar(200)

SET @ScriptNumber = 1104
SET @ScriptDesc = 'Creates stored procedure to update bank holidays and updates bank holidays'

IF EXISTS(SELECT * 
            FROM [dbo].[ChangeCatalogue] 
           WHERE ScriptNumber = @ScriptNumber)
    BEGIN
        UPDATE [dbo].[ChangeCatalogue]
           SET ChangeDate = getDate(), Summary = @ScriptDesc
         WHERE ScriptNumber = @ScriptNumber
    END
ELSE
    BEGIN
        INSERT INTO [dbo].[ChangeCatalogue] 
        (
            ScriptNumber,
            ChangeDate,
            Summary
        )
        VALUES 
        (
            @ScriptNumber,
            getDate(),
            @ScriptDesc
        )
    END
GO
GO
