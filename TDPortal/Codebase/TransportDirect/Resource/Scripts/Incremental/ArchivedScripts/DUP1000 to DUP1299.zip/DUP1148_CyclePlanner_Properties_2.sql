-- ***********************************************
-- NAME 		: DUP1148_CyclePlanner_Properties_2.sql
-- DESCRIPTION 		: Script to add Cycle Planner properties
-- AUTHOR		: Mitesh Modi
-- DATE			: 21 Oct 2008
-- ************************************************

USE [PermanentPortal]
GO

-- ***************************************************
-- The following amendments are required when running the script in SITest, BBP, ACP
-- 
-- 1. Amend the Coordinate.Convertor.DataPath to the appropriate location for each environment. This path refers to the location of GIQ60.dat
-- ***************************************************

------------------------------------------------------
-- TIDY UP
-- Delete property no longer required
IF EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'CyclePlanner.GPXDownload.File.Xslt')
	BEGIN
		DELETE 
		FROM [dbo].[properties]
		WHERE pName = 'CyclePlanner.GPXDownload.File.Xslt'
	END

GO
------------------------------------------------------


------------------------------------------------------
-- Cycle planner

IF EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'Coordinate.Convertor.DataPath')
	BEGIN
		UPDATE [dbo].[properties]
		SET pValue = 'C:\TDPortal\Codebase\build\Quest\'
		WHERE pName = 'Coordinate.Convertor.DataPath'
	END
ELSE
	BEGIN
		INSERT INTO properties VALUES ('Coordinate.Convertor.DataPath', 'C:\TDPortal\Codebase\build\Quest\', 'Web', 'UserPortal', 0, 1)
	END


IF EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'Coordinate.Convertor.InitialiseString')
	BEGIN
		UPDATE [dbo].[properties]
		SET pValue = 'GIQ.6.0'
		WHERE pName = 'Coordinate.Convertor.InitialiseString'
	END
ELSE
	BEGIN
		INSERT INTO properties VALUES ('Coordinate.Convertor.InitialiseString', 'GIQ.6.0', 'Web', 'UserPortal', 0, 1)
	END



GO
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1148
SET @ScriptDesc = 'Cycle planner properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO