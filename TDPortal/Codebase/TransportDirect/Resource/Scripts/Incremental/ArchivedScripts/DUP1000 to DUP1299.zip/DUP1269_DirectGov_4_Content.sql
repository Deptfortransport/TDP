-- ***********************************************
-- NAME 		: DUP1269_DirectGov_4_Content.sql
-- DESCRIPTION 	: Script to add specific content for a Theme - DirectGov
-- AUTHOR		: Amit Patel
-- DATE			: 2 Feb 2009 11:15:00
-- ************************************************

-----------------------------------------------------
-- SOFT CONTENT
-----------------------------------------------------

USE [Content]
GO

DECLARE @ThemeId INT
SET @ThemeId = 5

----------------------------------------------------------
-- Header text
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.headerHomepageLink.AlternateText', 'Directgov', 'Directgov'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.TDSmallBannerImage.AlternateText', 'Directgov', 'Directgov'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HeaderControl.defaultActionButton.AlternateText', 'Directgov', 'Directgov'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableHeaderControl.transportDirectLogoImg.AlternateText', 'Directgov - Public services all in one place', 'Directgov - Public services all in one place'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'PrintableHeaderControl.connectingPeopleImg.AlternateText', 'Provided by Transport Direct', 'Provided by Transport Direct'


----------------------------------------------------------
-- Footer links
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FooterControl1.ContactUsLinkButton', 'Contact Transport Direct', 'Cysylltu � Transport Direct '

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FooterControl1.AboutLinkButton', 'About Transport Direct', 'Amdanom Transport Direct '

----------------------------------------------------------
-- Contact us page
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FeedbackInitialPage.ContactUsLabel', 'Contact Transport Direct', 'cy Contact Transport Direct'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FeedbackInitialPage.labelTitle.Text', 'Send Transport Direct your feedback', 'cy Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.imageFeedback.AlternateText', 'Send Transport Direct your feedback', 'cy Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.imageFeedbackSkipLink.AlternateText', 'Skip to Send Transport Direct your feedback', 'cy Skip to Send Transport Direct your feedback'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.lblFeedback', 'Send Transport Direct <br /> your feedback', 'cy Send Transport Direct <br />your feedback'

----------------------------------------------------------
-- About us page
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 19, 'TitleText', '/Channels/TransportDirect/About/AboutUs', 'About Transport Direct', 'cy About Transport Direct'


----------------------------------------------------------
-- HomePage - Tips and Tools panel
----------------------------------------------------------

EXEC AddtblContent
@ThemeId, 15, 'TDTipsHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'<div class="Column2Header">
<h2><a class="Column2HeaderLink" title="Go to Tips and tools page" href="/Web2/Tools/Home.aspx"><span class="txtsevenbwl">Tips and tools</span></a></h2>
<a class="txtsevenbwrlink" title="Go to Tips and tools page" href="/Web2/Tools/Home.aspx">More... </a><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>
<div></div>
<div class="clearboth"></div><div class="Column2Content2">
<table class="TipsToolsTable" cellspacing="5" summary="">
<tbody>
<tr>
<td class="TipsToolsIconPadding"><a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx"><img title="Check journey CO2" height="30" alt="Check CO2 emissions" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Co2_30x30.gif" width="30" /></a></td>
<td><a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check CO2 emissions</a></td></tr>
<tr>
<td class="TipsToolsIconPadding"><a href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492"><img title="Services available on your mobile" height="30" alt="Services available on your mobile" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif" width="30"/></a></td>
<td><a href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Get departures on your mobile</a></td></tr>
</tbody></table></div>', 
'<div class="Column2Header">
<h2><a class="Column2HeaderLink" title="Ewch i''r dudalen Awgrymiadau a thedynnau" href="/Web2/Tools/Home.aspx"><span class="txtsevenbwl">Awgrymiadau a theclynnau</span></a></h2>
<a class="txtsevenbwrlink" title="Ewch i''r dudalen Awgrymiadau a thedynnau" href="/Web2/Tools/Home.aspx">Mwy... </a><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>
<div></div>
<div class="clearboth"></div><div class="Column2Content2">
<table class="TipsToolsTable" cellspacing="5" summary="">
<tbody>
<tr>
<td class="TipsToolsIconPadding"><a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx"><img title="Mesur CO2 y siwrnai" height="30" alt="Mesur CO2 y siwrnai" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/cy/Co2_30x30.gif" width="30" /></a></td>
<td><a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Mesur CO2 y siwrnai</a></td></tr>
<tr>
<td class="TipsToolsIconPadding"><a href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" ><img title="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" height="30" alt="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif" width="30"/></a></td>
<td><a href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Derbyniwch ymadawiadau byw ar eich ff&#244;n symudol</a></td></tr>
</tbody></table></div>'

GO


------------------------------------------------------------------------
-- Plan a Journey Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5


EXEC AddtblContent
@ThemeId, 18, 'PlanAJourneyInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/Home', 
'<div class="MinihomeHyperlinksInfoContent">  <div class="MinihomeHyperlinksInfoHeader">  <div class="txtsevenbbl"><h2>Getting what you want from the journey planners</h2></div><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  <div class="MinihomeSoftContent">  <p>You can plan a journey in a number of different ways to suit your needs. </p><br/>  <h3>Plan me a journey door to door...</h3><br/><br/>  <p>The simplest way to search is using the <a href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">door-to-door journey planner</a>, which searches for up to five journey options - by joined-up public transport or by car. You can plan from postcodes, places, stations and even local attractions. </p><br/>  <p>You can type in where and when you want to travel from and travel to... </p><img style="PADDING-RIGHT: 10px" alt="An image showing a summary of journey results" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneySummary.JPG" align="left" border="0"/>   <p>...and the system will give you a list of options to choose from. </p><br/><br/><img style="PADDING-RIGHT: 10px; PADDING-LEFT: 15px" alt="An image showing a diagram of the detail of a journey plan" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/journey_details_500L.GIF" align="right" border="0"/>   <p>Highlight your preferred journey, the "Details" button allows you to see step-by-step directions, including any connections you need to make, stations names, interchange times or driving instructions if you have selected the car journey. Some of the images and text on the Details page contain links to further useful information, too.</p>  <p>&nbsp;</p>  <p>The "Maps" and "Tickets/Costs" buttons allow you to see route maps, ticket prices and driving costs. <br/><br/>By clicking "Tickets/Costs", you can check the prices and availability of rail and coach tickets. If you want to book, we can automatically pass your journey details to one of our partner retailer sites so that you can buy online.<br/><br/>Similarly, you can see your route, or individual sections of it, on a map by clicking the "map button". You can also list stops for a service by clicking on the transport icon in your journey itinerary. </p><img alt="An image of a map showing the route of a specific journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyMap.JPG" align="left" border="0"/>   <p><img alt="An image showing a sample of car driving instructions" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyCarInstructions.JPG" align="top" border="0"/><br/></p>  <p>&nbsp;</p>  <h3>I know how I want to travel...</h3>  <p>&nbsp;</p>  <p>Perhaps you have already decided what form of transport to use for the main part of your journey. <br/><br/>In this case you would be better off starting with <a href="/Web2/JourneyPlanning/FindTrainInput.aspx">Find a train</a>, <a href="/Web2/JourneyPlanning/FindFlightInput.aspx">Find a flight</a>, <a href="/Web2/JourneyPlanning/FindCarInput.aspx">Find a car route</a> or <a href="/Web2/JourneyPlanning/FindCoachInput.aspx">Find a coach</a>. These will list journeys for just that type of transport. </p><br/><br/><img alt="Image showing the quick planner icons on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyQuickPlanners.JPG" border="0"/>   <p>&nbsp;</p>  <p>If you use <a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Find a Train</a>, you can choose between a search by time or by price. A search by price allows you to choose from a range of fares before you see the journey details relevant to that ticket price.</p>  <p>&nbsp;</p>  <p>You may also want to compare train, plane, coach and car journeys between two cities or towns in Britain on a given day. You can do this using <a href="/Web2/JourneyPlanning/FindTrunkInput.aspx">compare how to get from city to city</a>.</p>  <p>&nbsp;</p>  <p>Alternatively you may want to find your nearest station or car park and then plan a journey to or from there. Or find a place on a map and then plan to or from there. This is easy to do - see our <a href="/Web2/Maps/Home.aspx">Find a Place</a> page for more details.</p>  <p>&nbsp;</p>  <h3>Amending my chosen journey</h3>  <p>&nbsp;</p>  <p>Once you have found a journey you want, you can add further parts to your journey or amend some or all of your journey. </p>  <table class="txtseven" cellspacing="0" cellpadding="2" border="0">  <tbody>  <tr>  <td><img alt="Image representing the action of adding to the overall journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyExtend.JPG" border="0"/></td>  <td>You can find the main part of your journey and then extend the plan to show how to get from the station to your door by car or public transport. </td></tr>  <tr>  <td><img alt="Image representing the action of changing the journey plan" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyReplace.JPG" border="0"/></td>  <td>You can modify your journey by replacing a section that uses public transport with a car journey, for example to travel home from the station by taxi rather than by bus. </td></tr>  <tr>  <td><img alt="Image representing the action of adjusting the timings of a journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAdjust.JPG" border="0"/></td>  <td>If you would like to allow more time at the places where you have to change transport, you can adjust your journey.</td></tr></tbody></table>  <p>&nbsp;</p><img alt="Image of the �Amend date and time� feature" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAmend.JPG" border="0"/>   <p>&nbsp;</p>  <p>Once you have found some journey options, you can adjust the times and the routes, either by clicking the "Amend" button or by using the "Amend date and time" feature, at the bottom of the page.</p>  <p>&nbsp;</p>  <h3>Can you remember my journey request? </h3>  <p>&nbsp;</p>  <p>Once you have found a journey, you can save it as a bookmark ("favourite") in your browser...</p>  <p>&nbsp;</p><img alt="Image showing feature to bookmark a journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyBookmark.JPG" border="0"/>   <p>&nbsp;</p>  <p>...and retrieve it at a future time from the "Favourites" menu in your browser. </p>  <p>&nbsp;</p><img alt="Screenshot showing the browser favourites menu bar" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyFavourites.jpg" border="0"/> </div></div>',
'<div class="MinihomeHyperlinksInfoContent">  <div class="MinihomeHyperlinksInfoHeader">  <div class="txtsevenbbl"><h2>Dywedwch fwy wrthyf...</h2><!-- New heading should read "Getting what you want from the journey planners" replacing "Tell me more" --></div><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  <div class="MinihomeSoftContent">  <p>Gallwch gynllunio eich siwrnai mewn nifer o wahanol ffyrdd i weddu i''ch anghenion. </p><br/>  <h3>Cynlluniwch siwrnai o ddrws i ddrws i mi...</h3><br/><br/>  <p>Y ffordd symlaf o chwilio yw defnyddio''r <a href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">cynllunydd siwrnai o ddrws-i-ddrws</a>, sy''n chwilio am hyd at bump o ddewisiadau o ran siwrneion � drwy gludiant cyhoeddus wedi ei gydlynu neu mewn car. Gallwch gynllunio o godau post, lleoedd, gorsafoedd a hyd yn oed atyniadau lleol. </p><br/>  <p>Gallwch deipio i mewn ble a phryd y dymunwch deithio ohono a theithio iddo... </p><img style="PADDING-RIGHT: 10px" alt="Delwedd yn dangos crynodeb o ganlyniadau''r siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneySummary.JPG" align="left" border="0"/>   <p>...a bydd y system yn rhoi rhestr o ddewisiadau i chi ddewis ohonynt. </p><br/><br/><img style="PADDING-RIGHT: 10px; PADDING-LEFT: 15px" alt="Delwedd yn dangos diagram o fanylion cynllun siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/journey_details_500L.GIF" align="right" border="0"/>   <p>Tynnwch sylw at eich hoff siwrnai, yna cliciwch ar ''Manylion'' i weld cyfarwyddiadau manwl, gan gynnwys unrhyw gysylltiadau y bydd angen i chi eu gwneud, enwau''r gorsafoedd, amserau rhyng-newid neu gyfarwyddiadau gyrru os ydych wedi dewis y siwrnai car. Mae rhai o''r delweddau a''r testun ar y dudalen Manylion yn cynnwys dolennau i wybodaeth ddefnyddiol arall hefyd. </p>  <p>&nbsp;</p>  <p>Mae''r botymau ''Mapiau'' a ''Tocynnau/Costau'' yn caniat�u i chi weld mapiau o lwybrau, prisiau tocynnau a chostau gyrru. <br/><br/>Drwy glicio ar ''Tocynnau/Costau'' gallwch wirio''r prisiau ac argaeledd tocynnau rheilffordd a bysiau moethus. Os dymunwch archebu, gallwn drosglwyddo manylion eich siwrnai yn awtomatig i safle adwerthu un o''n partneriaid fel y gallwch brynu ar-lein.<br/><br/>Yn yr un modd, gallwch weld eich llwybr neu adrannau unigol ohono, ar fap drwy glicio ar ''botwm y map''. Gallwch hefyd restru arosfannau ar gyfer gwasanaeth drwy glicio ar yr eicon cludiant yn nisgrifiad eich siwrnai. </p><img alt="Delwedd o fap yn dangos llwybr siwrnai benodol" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyMap.JPG" align="left" border="0"/>   <p><img alt="Delwedd yn dangos sampl o''r cyfarwyddiadau gyrru car" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyCarInstructions.JPG" align="top" border="0"/><br/></p>  <p>&nbsp;</p>  <h3>Rwy''n gwybod sut rydw i eisiau teithio...</h3>  <p>&nbsp;</p>  <p>Efallai eich bod eisoes wedi penderfynu pa fath o gludiant i''w ddefnyddio ar gyfer prif ran eich siwrnai. <br/><br/>Yn yr achos hwn, byddai''n well i chi ddechrau gyda <a href="/Web2/JourneyPlanning/FindTrainInput.aspx">Canfyddwch dr�n</a>, <a href="/Web2/JourneyPlanning/FindFlightInput.aspx">Canfyddwch ehediad</a>, <a href="/Web2/JourneyPlanning/FindCarInput.aspx">Canfyddwch lwybr car</a> neu <a href="/Web2/JourneyPlanning/FindCoachInput.aspx">Canfyddwch fws moethus</a>. Bydd y rhain yn rhestru''r siwrneion am y math hwnnw o gludiant yn unig. </p><br/><br/><img alt="Delwedd yn dangos eiconau''r cynllunydd cyflym ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyQuickPlanners.JPG" border="0"/>   <p>&nbsp;</p>  <p>Os defnyddiwch <a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Canfyddwch Dr�n</a>, gallwch ddewis rhwng chwilio yn �l amser neu yn �l pris. Drwy chwilio yn �l pris gallwch ddewis o ystod o brisiau cyn i chi weld manylion y siwrnai sy''n berthnasol i''r pris tocyn hwnnw.</p>  <p>&nbsp;</p>  <p>Efallai hefyd y dymunwch gymharu siwrneion tr�n, awyren a bws moethus rhwng dwy ddinas neu dref ym Mhrydain ar ddiwrnod arbennig. Gallwch wneud hyn drwy ddefnyddio <a href="/Web2/JourneyPlanning/FindTrunkInput.aspx">cymharu siwrneion dinas-i-ddinas</a>. </p>  <p>&nbsp;</p>  <p>Neu efallai y dymunwch ddod o hyd i''ch gorsaf neu faes parcio agosaf ac yna cynllunio siwrnai i neu oddi yno. Neu ddarganfod lle ar fap ac yna cynllunio i fynd yno neu oddi yno. Mae hyn yn hawdd � gweler ein tudalen <a href="/Web2/Maps/Home.aspx">Canfyddwch le</a> am fwy o fanylion.</p>  <p>&nbsp;</p>  <h3>Diwygio fy newis siwrnai</h3>  <p>&nbsp;</p>  <p>Wedi i chi ddarganfod siwrnai a ddymunwch, gallwch ychwanegu rhannau pellach at eich siwrnai neu ddiwygio rhywfaint o''ch siwrnai neu''r siwrnai i gyd. </p>  <table class="txtseven" cellspacing="0" cellpadding="2" border="0">  <tbody>  <tr>  <td><img alt="Delwedd yn cynrychioli''r weithred o ychwanegu at y siwrnai gyffredinol" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyExtend.JPG" border="0"/></td>  <td>Gallwch ddarganfod prif ran eich siwrnai ac yna ymestyn y cynllun i ddangos sut i fynd o''r orsaf i''ch drws mewn car neu gludiant cyhoeddus. </td></tr>  <tr>  <td><img alt="Delwedd yn cynrychioli''r weithred o newid cynllun y siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyReplace.JPG" border="0"/></td>  <td>Gallwch ddiwygio eich siwrnai drwy amnewid adran sy''n defnyddio cludiant cyhoeddus gyda siwrnai mewn car, er enghraifft i deithio adref o''r orsaf mewn tacsi yn hytrach nag mewn bws. </td></tr>  <tr>  <td><img alt="Delwedd yn cynrychioli''r weithred o addasu amserau siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAdjust.JPG" border="0"/></td>  <td>Os hoffech gael mwy o amser yn y mannau lle mae''n rhaid i chi newid cludiant, gallwch addasu eich siwrnai.</td></tr></tbody></table>  <p>&nbsp;</p><img alt="Delwedd o''r nodwedd ''Newid dyddiad/amser''" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyAmend.JPG" border="0"/>   <p>&nbsp;</p>  <p>Cyn gynted ag yr ydych wedi darganfod rhai dewisiadau ar gyfer siwrneion, gallwch addasu''r amserau a''r llwybrau, naill ai drwy glicio''r botwm ''Newid'' neu drwy ddefnyddio''r nodwedd ''Newid dyddiad/amser'' ar waelod y dudalen.</p>  <p>&nbsp;</p>  <h3>Fedrwch chi gofio fy nghais am siwrnai? </h3>  <p>&nbsp;</p>  <p>Wedi i chi ganfod siwrnai, gallwch ei chadw fel nod llyfr (''ffefryn'') yn eich porwr...</p>  <p>&nbsp;</p><img alt="Delwedd yn dangos nodwedd i roi nod llyfr ar siwrnai" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyBookmark.JPG" border="0"/>   <p>&nbsp;</p>  <p>...a dod o hyd iddi rywbryd yn y dyfodol o''r ddewislen ''Ffefrynnau'' yn eich porwr. </p>  <p>&nbsp;</p><img alt="Delwedd o''r sgr�n yn dangos bar dewislen ffefrynnau''r porwr" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomePlanAJourneyFavourites.jpg" border="0"/> </div></div>'

GO


------------------------------------------------------------------------
-- Find A Place Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 17, 'FindAPlaceInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/Home', 
'<div class="MinihomeHyperlinksInfoContent">  <div class="MinihomeHyperlinksInfoHeader">  <div class="txtsevenbbl"><h2>Finding the place you want</h2></div><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  <div class="MinihomeSoftContent">  <h3>Find me a map...</h3><br/><br/>  <p>You can <a href="/Web2/Maps/JourneyPlannerLocationMap.aspx">find a map</a> of a place, city, attraction, station, stop, address or postcode. </p>  <p>&nbsp;</p><img style="PADDING-LEFT: 10px" alt="Image of a map showing a specific location" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceLocationMap1.JPG" align="right" border="0"/>   <p>You can view the local transport stops and stations in the area and local amenities such as hotels, attractions and public facilities.</p><br/>  <p>&nbsp;</p>  <h3>Now plan me a journey there...</h3>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 70px; PADDING-LEFT: 10px" alt="Screenshot of a Transport Direct map and the buttons from which to plan a journey" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceMapPlan1.JPG" align="right" border="0"/>You can then choose to plan a journey to or from the location shown on the map.</p><br/>  <p>&nbsp;</p>  <h3>Where''s the nearest transport?</h3>  <p>&nbsp;</p>  <p>Alternatively, you may wish to <a href="/Web2/JourneyPlanning/FindAStationInput.aspx">find the nearest stations &amp; airports</a> to a location.</p><br/><img alt="Screenshot of the output from the Find nearest station/airport feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearest1.JPG" align="right" border="0"/>   <p>You can view them as a list, in order of their distance from your location...</p><br/>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 10px" alt="Image of map showing numbered locations" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearestMap1.JPG" align="left" border="0"/>...or you can view them on a map.</p><br/>  <p>&nbsp;</p>  <h3>Now plan me a journey there...</h3>  <p>&nbsp;</p>  <p><img style="PADDING-LEFT: 10px" alt="Screenshot of the results from the Find nearest station/airport feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceStationJourneyResults.JPG" align="right" border="0"/>The closest station/airport is already selected. Once you have selected the station/airport required, click Travel from or Travel to. Then repeat for the other journey leg and click next.<br/><br/>You will then be able to ''Find journeys between stations/airports'' from the selection you have made.<br/><br/>You may not always get journeys to or from all of your selected stations but the results returned will be the best journeys available between the chosen origin(s) and destination(s).</p><br/>  <p>&nbsp;</p>  <h3>Where''s the nearest car park?</h3>  <p>&nbsp;</p>  <p>Similarly, you may wish to <a href="/Web2/JourneyPlanning/FindCarParkInput.aspx">find the nearest car parks</a> to a location.</p><br/><img alt="Screenshot of the output from the Find nearest car park feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkResults.JPG" align="right" border="0"/>   <p>You can view them as a list, in order of their distance from your location, the total number of spaces, and if they have disabled spaces...</p><br/>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 10px" alt="Image of map showing available car parks" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkMap.JPG" align="left" border="0"/>...or you can view them on a map.</p><br/>  <p>&nbsp;</p>  <h3>Now plan me a journey there...</h3>  <p>&nbsp;</p>  <p><img style="PADDING-LEFT: 10px" alt="Screenshot of the output from the Find nearest car park feature on Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkJourneyResults.JPG" align="right" border="0"/>The closest car park is already selected. Once you have selected the option required, click Drive from or Drive to.<br/><br/>You will then be able to ''Plan a car route'' from/to the car park selected.</p><br/>  <p>&nbsp;</p>  <h3>What will the roads be like?</h3>  <p>&nbsp;</p>  <p>If you are planning to visit a place, you may want to know what the traffic will be like when you travel there.</p><br/>  <p><img style="PADDING-LEFT: 10px" alt="Image of a map showing predicted traffic levels using different colours to represent estimated congestion" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceTrafficMap1.JPG" align="right" border="0"/>Our <a href="/Web2/Maps/TrafficMaps.aspx">traffic maps</a> are based on recorded traffic levels over the last few years and display an accurate prediction of the likely traffic levels at your precise time of travel.</p><br/>  <p>&nbsp;</p>  <h3>I need a tube map...</h3>  <p>&nbsp;</p>  <p>Finally, you may just need a map showing part of the rail network, bus routes or a map of the London Underground. Our <a href="/Web2/Maps/NetworkMaps.aspx">transport network maps</a> page links you to a range of sites containing these maps. </p></div></div>',
'<div class="MinihomeHyperlinksInfoContent">  <div class="MinihomeHyperlinksInfoHeader">  <div class="txtsevenbbl"><h2>Dywedwch fwy wrthyf...</h2></div><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  <div class="MinihomeSoftContent">  <h3>Darganfyddwch fap i mi...</h3><br/><br/>  <p>Gallwch <a href="/Web2/Maps/JourneyPlannerLocationMap.aspx">ddarganfyddwch map</a> o le, dinas, atyniad, gorsaf, arhosfan, cyfeiriad neu god post. </p>  <p>&nbsp;</p><img style="PADDING-LEFT: 10px" alt="Delwedd o fap yn dangos lleoliad penodol" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceLocationMap.JPG" align="right" border="0"/>   <p>Gallwch weld yr arosfannau a''r gorsafoedd cludiant lleol yn yr ardal a mwynderau lleol fel gwestai, atyniadau a chyfleusterau cyhoeddus.</p><br/>  <p>&nbsp;</p>  <h3>Yn awr cynlluniwch siwrnai i mi yno...</h3>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 70px; PADDING-LEFT: 10px" alt="Delwedd sgr�n o fap Transport Direct a''r botymau y bwriadwch gynllunio siwrneion ohonynt" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceMapPlan.JPG" align="right" border="0"/>Yna gallwch ddewis cynllunio siwrnai i neu o''r lleoliad a ddangosir ar y map.</p><br/>  <p>&nbsp;</p>  <h3>Ble mae''r cludiant agosaf?</h3>  <p>&nbsp;</p>  <p>Neu efallai y dymunwch <a href="/Web2/JourneyPlanning/FindAStationInput.aspx">dod o hyd i''r gorsafoedd a''r meysydd awyr agosaf</a> at leoliad.</p><br/><img alt="Delwedd sgr�n o''r allbwn o''r nodwedd Dod ohyd i''r orsaf/maes awyr agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearest.JPG" align="right" border="0"/>   <p>Gallwch edrych arnynt fel rhestr, yn nhrefn eu pellter o''ch lleoliad...</p><br/>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 10px" alt="Delwedd o fap yn dangos lleoliadau wedi eu rhifo" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceNearestMap.JPG" align="left" border="0"/>...neu gallwch eu gweld ar fap.</p><br/>  <p>&nbsp;</p>  <h3>Yn awr cynlluniwch siwrnai i mi yno...</h3>  <p>&nbsp;</p>  <p><img style="PADDING-LEFT: 10px" alt="Llun sgr�n o''r allbwn o''r nodwedd Dod o hyd i''r orsaf/maes awyr agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceStationJourneyResults.JPG" align="right" border="0"/>Mae''r orsaf/maes awyr agosaf wedi ei dicio yn barod. Wedi i chi ddewis yr opsiwn/opsiynau angenrheidiol, cliciwch ar Teithio o neu Teithio i. Yna ailadroddwch hyn ar gyfer yr adran arall o''r siwrnai a chliciwch nesaf.<br/><br/>Yna byddwch yn gallu ''Darganfyddwch siwrneion rhwng gorsafoedd/meysydd awyr'' o''r dewis yr ydych wedi ei wneud.<br/><br/>Efallai na fydd wastad yn bosibl i chi gael siwrneion sy''n gadael neu''n cyrraedd pob gorsaf a ddewiswyd gennych ond byddwn yn dychwelyd manylion y siwrneion gorau sydd ar gael rhwng y man(nau) cychwyn a''r cyrchfan(nau) a ddewiswyd.</p><br/>  <p>&nbsp;</p>  <h3>Ble mae''r maes parcio agosaf?</h3>  <p>&nbsp;</p>  <p>Yn yr un modd, mae''n bosibl y byddwch yn dymuno <a href="/Web2/JourneyPlanning/FindCarParkInput.aspx">darganfod y meysydd parcio agosaf</a> i leoliad.</p><br/><img alt="Llun sgr�n o''r allbwn o''r nodwedd Darganfyddwch y maes parcio agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkResults.JPG" align="right" border="0"/>   <p>Gallwch eu gweld fel rhestr, yn nhrefn eu pellter o''ch lleoliad chi�</p><br/>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 10px" alt="Delwedd o fap yn dangos y meysydd parcio sydd ar gael" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkMap.JPG" align="left" border="0"/>...neu gallwch eu gweld ar fap.</p><br/>  <p>&nbsp;</p>  <h3>Yn awr cynlluniwch siwrnai i mi yno...</h3>  <p>&nbsp;</p>  <p><img style="PADDING-LEFT: 10px" alt="Llun sgr�n o''r allbwn o''r nodwedd Darganfyddwch y maes parcio agosaf ar Transport Direct" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceCarParkJourneyResults.JPG" align="right" border="0"/>Mae''r maes parcio agosaf wedi ei ddewis yn barod. Wedi i chi ddewis yr opsiwn angenrheidiol, cliciwch ar Gyrrwch o neu Gyrrwch i.<br/><br/>Yna byddwch yn gallu ''Cynlluniwch lwybr car'' o/i''r maes parcio a ddewiswyd.</p><br/>  <p>&nbsp;</p>  <h3>Sut rai fydd y ffyrdd?</h3>  <p>&nbsp;</p>  <p>Os ydych chi''n cynllunio ymweld � lle, efallai y byddwch yn dymuno gwybod sut fydd y traffig pan deithiwch yno.</p><br/>  <p><img style="PADDING-LEFT: 10px" alt="Delwedd o fap yn dangos y lefelau traffig a ragfynegir gan ddefnyddio lliwiau gwahanol i gynrychioli amcangyfrif o''r tagfeydd" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeFindAPlaceTrafficMap.JPG" align="right" border="0"/>Seilir ein <a href="/Web2/Maps/TrafficMaps.aspx">mapiau traffig</a> ar lefelau traffig a gofnodwyd dros yr ychydig flynyddoedd diwethaf ac maent yn dangos rhagfynegiad cywir o''r lefelau traffig tebygol ar yr union adeg y byddwch yn teithio.</p><br/>  <p>&nbsp;</p>  <h3>Mae arnaf angen map o''r trenau tanddaearol...</h3>  <p>&nbsp;</p>  <p>Yn olaf, efallai y bydd arnoch angen map yn dangos rhan o rwydwaith y rheilffordd, y llwybrau bysiau neu fap o drenau tanddaearol Llundain. Mae ein tudalen <a href="/Web2/Maps/NetworkMaps.aspx">mapiau''r rhwydwaith cludiant</a> yn eich cysylltu ag ystod o safleoedd yn cynnwys y mapiau hyn. </p></div></div>'

GO


------------------------------------------------------------------------
-- Live Travel Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5


EXEC AddtblContent
@ThemeId, 16, 'HomeTravelInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/LiveTravel/Home', 
'<div class="MinihomeHyperlinksInfoContent">  <div class="MinihomeHyperlinksInfoHeader">  <div class="txtsevenbbl"><h2>Finding your news</h2></div><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  <div class="MinihomeSoftContent">  <h3>Are there any incidents that could affect my journey?</h3>  <p>&nbsp;</p><img style="PADDING-LEFT: 30px" alt="Image of a map showing incident symbols" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidents.JPG" align="right" border="0"/>   <p>You can check for any incidents on the roads or the public transport network that may affect your journey, either on a map or as a list, on our <a href="/Web2/LiveTravel/TravelNews.aspx">Live Travel news</a> page.</p><br/>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 40px" alt="Screenshot of the map with additional hover-over info" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidentPopup1.JPG" align="left" border="0"/></p>  <p>Hover-over the incident symbols on the map to find further details. <br/><br/>We also show future planned roadworks and public transport engineering works.</p><br/>  <p>&nbsp;</p>  <h3>When is the next train? </h3>  <p>&nbsp;</p>  <p>Find out when the next train or bus leaves, or whether there are any current delays to your service, by visiting our <a href="/Web2/LiveTravel/DepartureBoards.aspx">departure boards</a> page.</p></div></div>',
'<div class="MinihomeHyperlinksInfoContent">  <div class="MinihomeHyperlinksInfoHeader">  <div class="txtsevenbbl"><h2>Dywedwch fwy wrthyf...</h2><!-- New heading should read "Finding your news" replacing "Tell me more" --></div><!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  <div class="MinihomeSoftContent">  <h3>Oes yna unrhyw ddigwyddiadau a allai effeithio ar fy siwrnai?</h3>  <p>&nbsp;</p><img style="PADDING-LEFT: 30px" alt="Delwedd o fap yn dangos symbolau digwyddiadau" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidents.JPG" align="right" border="0"/>   <p>Gallwch weld a oes unrhyw ddigwyddiadau ar y ffyrdd neu''r rhwydwaith cludiant cyhoeddus a all effeithio ar eich siwrnai, naill ai ar fap neu fel rhestr, ar ein tudalen <a href="/Web2/LiveTravel/TravelNews.aspx">Newyddion teithio byw</a>.</p><br/>  <p>&nbsp;</p>  <p><img style="PADDING-RIGHT: 40px" alt="Delwedd sgr�n o fap gyda gwybodaeth ychwanegol i hofran drosto" src="/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeLiveTravelNewsIncidentPopup2.JPG" align="left" border="0"/></p>  <p>Arhoswch uwchben y symbolau digwyddiadau ar y map i ddarganfod manylion pellach. <br/><br/>Rydym hefyd yn dangos gwaith ffyrdd sy''n cael eu cynllunio yn y dyfodol a gwaith peirianyddol yn ymwneud � chludiant cyhoeddus.</p><br/>  <p>&nbsp;</p>  <h3>Pryd mae''r tr�n nesaf? </h3>  <p>&nbsp;</p>  <p>Darnganfyddwch pryd mae''r tr�n neu''r bws nesaf yn gadael, neu a oes unrhyw oedi i''ch gwasanaeth chi ar hyn o bryd drwy ymweld �''n tudalen <a href="/Web2/LiveTravel/DepartureBoards.aspx">byrddau cyrraedd a chychwyn</a>.</p></div></div>'

GO


------------------------------------------------------------------------
-- Tips and tools Home page information panel
------------------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 14, 'TipsToolsInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Tools/Home'
-- ENGLISH
,'<div class="MinihomeHyperlinksInfoContent">
<div class="MinihomeHyperlinksInfoHeader">
<div class="txtsevenbbl">
<h2>Helping you get the most from Transport Direct</h2>
</div>
<!-- Following spaces help   formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice   wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<div class="MinihomeSoftContent">
<h3>Compare CO2 emissions for your journey...</h3>

<p>&nbsp;</p>

<p>You can now compare the CO2 emissions of the four main modes of transport (Car, Rail,
Bus/coach, and Plane) for your journey.</p><br/>
<img alt="Screen shot of CO2 Emissions page" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissions2.jpg" align=
"right" border="0"/>

<p>You can do a simple emissions comparison by inputting a distance in miles or
kilometres. TD will tell you how much CO2 would be emitted if you travelled that distance
by car, train, bus, or plane.</p><br/>

<p>&nbsp;</p>

<p><img alt="Screen shot of CO2 Emissions for your journey" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissionsJourney2.jpg"
align="left" border="0"/>Or look at the emissions for your journey by different modes of
transport by following the links from your journey details page.</p><br/>

<p>&nbsp;</p>

<p>Go to the <a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">CO2
emissions</a> page to find out.</p>

<p>&nbsp;</p>

<h3>I use a screen-reader...</h3>

<p>&nbsp;</p>

<p>We aim to provide an equivalent experience for screen-reader users as well as users
who do not need this technology. In order for you to best understand how the site works
and how to get the most out of the journey planning features, visit the <a href=
"/Web2/About/Accessibility.aspx">Accessibility</a> section.</p>
</div>
</div>
'
-- WELSH
,'<div class="MinihomeHyperlinksInfoContent">
<div class="MinihomeHyperlinksInfoHeader">
<div class="txtsevenbbl">
<h2>Dywedwch fwy wrthyf...</h2>
<!-- New heading text should read "Helping you get the most from Transport Direct" replacing "Tell me more" -->
</div>
<!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<div class="MinihomeSoftContent">
<h3>Cymharwch allyriadau CO2 ar gyfer eich siwrnai...</h3>

<p>&nbsp;</p>

<p>Nawr fe allwch gymharu allyriadau CO2 y pedwar prif fath o drafnidiaeth (Car,
Tr&ecirc;n, Bws/coets, ac Awyren) ar gyfer eich siwrnai.</p><br/>
&nbsp;

<p><img alt="Llun sgrin o dudalen Allyriadau CO2" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissions2.jpg" align=
"right" border="0"/>Gallwch gymharu allyriadau yn syml drwy nodi pellter mewn milltiroedd
neu gilometrau. Bydd Transport Direct yn dweud wrthych faint o CO2 fyddai''n cael ei
ollwng pe byddech chi''n teithio''r pellter hwnnw mewn car, tr&ecirc;n, bws, neu
awyren.</p><br/>

<p>&nbsp;</p>

<p><img alt="Llun sgrin o Allyriadau CO2 ar gyfer eich siwrnai" src=
"/Web2/App_Themes/DirectGov/images/gifs/SoftContent/HomeTipsToolsEmissionsJourney2.jpg"
align="left" border="0"/>Neu edrychwch ar yr allyriadau ar gyfer eich siwrnai yn &ocirc;l
gwahanol fathau o drafnidiaeth drwy ddilyn y cysylltau o dudalen manylion eich
siwrnai.</p><br/>

<p>&nbsp;</p>

<p>Ewch i''r dudalen <a href=
"/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">allyriadau CO2</a> i gael
gwybod.</p>

<p>&nbsp;</p>

<h3>Rwy&rsquo;n defnyddio darllenwr sgr&icirc;n...</h3>

<p>&nbsp;</p>

<p>Anelwn at ddarparu profiad cyfwerth ar gyfer defnyddwyr darllenwyr sgr&icirc;n yn
ogystal &acirc; defnyddwyr nad oes arnynt angen y dechnoleg hon. Er mwyn i chi ddeall
orau sut mae''r safle yn gweithio a sut i gael y gorau o''r nodweddion cynllunio siwrnai,
ymwelwch &acirc;"r adran <a href=
"/TransportDirect/cy/About/Accessibility.aspx">Hygyrchedd</a> yn y tudalennau Amdanom
ni.</p>
</div>
</div>
'

GO



---------------------------------------------------------------
-- Home Page - Right hand info panel
---------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

-- Second Third items
EXEC AddtblContent
@ThemeId, 15, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', '<div class="Column3Header">
<div class="txtsevenbbl">Blue Badge map</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table1" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/bb.gif" alt="Blue Badge"/>
</td>
<td class="txtseven" valign="top">
The Blue Badge map shows Blue Badge parking bays, accessible toilets, council car parks, petrol stations, shopmobility centres, accessible 
beaches and train stations in over 100 locations across the UK.
<br/><br/>
Discover the <a href="http://bluebadge.direct.gov.uk/index.php?br_wid=1280&amp;br_hgt=768" >Blue Badge map here</a>
</td></tr></tbody></table></div>
<div class="Column3Header">
<div class="txtsevenbbl">Find schools and childcare in your area</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare"/>
</td>
<td class="txtseven" valign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br/><br/>
<a href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</a>
</td></tr></tbody></table></div>', 

'<div class="Column3Header">
<div class="txtsevenbbl">Blue Badge map</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table1" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/bb.gif" alt="Blue Badge"/>
</td>
<td class="txtseven" valign="top">
The Blue Badge map shows Blue Badge parking bays, accessible toilets, council car parks, petrol stations, shopmobility centres, accessible 
beaches and train stations in over 100 locations across the UK.
<br/><br/>
Discover the <a href="http://bluebadge.direct.gov.uk/index.php?br_wid=1280&amp;br_hgt=768" >Blue Badge map here</a>
</td></tr></tbody></table></div>
<div class="Column3Header">
<div class="txtsevenbbl">Find schools and childcare in your area</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare"/>
</td>
<td class="txtseven" valign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br/><br/>
<a href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</a>
</td></tr></tbody></table></div>'


-- Last item
EXEC AddtblContent
@ThemeId, 15, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', '<div class="Column3Header">
<div class="txtsevenbbl">Brush up on your Highway Code</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/highway_code.gif" alt="Highway Code"/>
</td>
<td class="txtseven">
The complete Highway Code is now available online. Wherever you are going, make sure you know the rules of the road before you set off.
<br/><br/>
<a href="http://www.direct.gov.uk/en/TravelAndTransport/Highwaycode/index.htm" >Click here</a> to read the Highway Code
</td></tr></tbody></table></div>', 

'<div class="Column3Header">
<div class="txtsevenbbl">Brush up on your Highway Code</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/highway_code.gif" alt="Highway Code"/>
</td>
<td class="txtseven">
The complete Highway Code is now available online. Wherever you are going, make sure you know the rules of the road before you set off.
<br/><br/>
<a href="http://www.direct.gov.uk/en/TravelAndTransport/Highwaycode/index.htm" >Click here</a> to read the Highway Code
</td></tr></tbody></table></div>'

GO


---------------------------------------------------------
-- Find a train input
---------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 50, 'TDFindTrainPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainInput', 
'<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</a> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>',

 '<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</A> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>'


-- Second Third items
EXEC AddtblContent
@ThemeId, 51, 'TDFindTrainPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput', 
'<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</A> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>',

 '<div class="Column3Header"><div class="txtsevenbbl">You can get <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >travel information</A> on Directgov mobile</div>&nbsp;&nbsp;</div>
<div class="Column3Content">
<table cellSpacing="0" cellPadding="2" width="100%" border="0" class="txtseven"><tr><td>
You can access travel information through the <A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492" >Directgov mobile service</A>. You can search for next train departures and arrivals, check whether a train is running on time and look up times for tomorrow.
</td></tr></table></div>'


----------------------------------------------------------------
-- Sitemap
----------------------------------------------------------------


-- Live travel
EXEC AddtblContent
@ThemeId, 43, 'LiveTravelBody', '/Channels/TransportDirect/SiteMap/SiteMap', 
'<P>
<DIV class="smcSiteMapLink"><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492">Travel information on your mobile</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check Journey CO2</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/FeedbackPage.aspx">Provide feedback</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/RelatedSites.aspx">Related sites</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/RelatedSites.aspx#NationalTransport">National transport</A><BR>
<LI><A href="/Web2/About/RelatedSites.aspx#LocalPublicTransport">Local public transport</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Motoring">Motoring</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#MotoringCosts">Motoring Costs</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#CarSharing">Car Sharing</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Government">Government</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Help/NewHelp.aspx">Frequently Asked Questions</A><BR></DIV></P>
', 

'<P>
<DIV class="smcSiteMapLink"><A href="http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492">cy Travel information on your mobile</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check Journey CO2</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/FeedbackPage.aspx">Rhowch adborth</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/RelatedSites.aspx">Safleoedd cysylltiedig</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/RelatedSites.aspx#NationalTransport">Cludiant cenedlaethol</A><BR>
<LI><A href="/Web2/About/RelatedSites.aspx#LocalPublicTransport">Cludiant cyhoeddus lleol</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Motoring">Moduro</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#MotoringCosts">Costau moduro</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#CarSharing">Rhannu ceir</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Government">Llywodraeth</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Help/NewHelp.aspx">Cwestiynau a Ofynnir yn Aml</A><BR></DIV></P>
'

-- TDOnTheMove title
EXEC AddtblContent
@ThemeId, 43, 'TDOnTheMoveTitle', '/Channels/TransportDirect/SiteMap/SiteMap',
'<H3>About Transport Direct</H3>',
'<H3>Amdanom Transport Direct</H3>'

-- TDOnTheMove body
EXEC AddtblContent
@ThemeId, 43, 'TDOnTheMoveBody', '/Channels/TransportDirect/SiteMap/SiteMap',
'<P><DIV class="smcSiteMapLink"><A href="/Web2/About/AboutUs.aspx">About Transport Direct</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/AboutUs.aspx#EnablingIntelligentTravel">Enabling intelligent travel</A><BR>
<LI><A href="/Web2/About/AboutUs.aspx#WhoOperates">Who operates Transport Direct? </A>
<LI><A href="/Web2/About/AboutUs.aspx#WhoBuilds">Who builds this site?</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhatsNext">What''s next?</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/About/Accessibility.aspx">Accessibility</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/Details.aspx">Contact details</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/DataProviders.aspx">Data providers</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/PrivacyPolicy.aspx">Privacy policy</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/TermsConditions.aspx">Terms &amp; conditions</A><BR></DIV>
</P>', 

'<P><DIV class="smcSiteMapLink"><A href="/Web2/About/AboutUs.aspx">Amdanom Transport Direct</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/AboutUs.aspx#EnablingIntelligentTravel">Galluogi teithio deallus</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhoOperates">Pwy sy''n gweithredu Transport Direct? </A>
<LI><A href="/Web2/About/AboutUs.aspx#WhoBuilds">Pwy sy''n adeiladu a datblygu''r safle hwn?</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhatsNext">Beth nesaf?</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/About/Accessibility.aspx">Hygyrchedd</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/Details.aspx">Manylion cyswllt</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/DataProviders.aspx">Darparwyr data</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/PrivacyPolicy.aspx">Polisi preifatrwydd</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/TermsConditions.aspx">Amodau a thelerau</A><BR></DIV>
</P>'


EXEC AddtblContent
@ThemeId, 43, 'sitemapFooterNote', '/Channels/TransportDirect/SiteMap/SiteMap',
' ',
' '

GO

----------------------------------------------------------------
-- Tips and Tools home - Mobile Demonstrator Icon link
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.PartnerSpecific.hyperlinkTDOnTheMove.NavigateURL',
'http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492',
'http://www.direct.gov.uk/en/Hl1/Help/YourQuestions/DG_069492'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.PartnerSpecific.hyperlinkTDOnTheMove.Target',
'_blank',
'_blank'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'HomeTipsTools.lblTDOnTheMove', 'Travel information on your mobile', 'cy Travel information on your mobile'

GO


----------------------------------------------------------------
-- Ambiguity page
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FindCarParkInput.labelNote.Ambiguous', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'FindStationInput.labelNote.StationMode.NoValid', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'ValidateAndRun.SelectFromList', 'Select an option from each list below.', 'cy Select an option from each list below. Then click "Next".'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'VisitPlannerInput.Instructional.Ambiguity', 'Select an option from each list below. Then click "Next".', 'cy Select an option from each list below. Then click "Next".'

GO


----------------------------------------------------------------
-- Amend tab images
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendCarDetailsTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendCarDetailsTabSelected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendCarDetailsTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendCarDetailsTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendCarDetailsTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendCarDetailsTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendDayTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendDayTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendViewTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendViewTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendViewTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonAmendViewTabUnSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendViewTabUnSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendViewTabUnSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonCostSearchDateTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonCostSearchDateTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendDateTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendDateTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonFareTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendFareDetailsTabSelected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendFareDetailsTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonFareTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendFareDetailsTabUnselected.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendFareDetailsTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonStopoverTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendStopoverBlue.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendStopoverBlue.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonStopoverTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/AmendStopoverGrey.gif','/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/AmendStopoverGrey.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSaveTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SaveTabSelected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SaveTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSaveTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SaveTabUnselected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SaveTabUnselected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSendTabSelected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SendTabSelected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SendTabSelected.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSend.ImageButtonSendTabUnselected', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/SendTabUnselected.gif', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/cy/SendTabUnselected.gif'

----------------------------------------------------------------
-- Back to top arrow
----------------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'DepartureBoards.TopOfPage.HyperlinkImage', '/Web2/App_Themes/DirectGov/images/gifs/Partner/back_to_top_icon.jpg', '/Web2/App_Themes/DirectGov/images/gifs/JourneyPlanning/en/uarrow_icon_slim.gif'

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'DepartureBoards.TopOfPage.Text', '', ''


GO


----------------------------------------------------------------
-- Powered by Transport Direct content
----------------------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 5

EXEC AddtblContent
@ThemeId, 1, 'langstrings', 'PoweredByControl.HTMLContent',
'<div class="Column3PoweredBy">
<div class="Column3Header Column3HeaderPoweredBy">
<div class="txtsevenbbl">
Provided by
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</div>
</div>
<div class="Column3Content Column3ContentPoweredBy">
<table>
<tr>
<td>
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/Partner/td_logo_4whbg.gif" alt="Provided by Transport Direct" />
</a>
</td>
</tr>
</table>
</div>
</div>',

'<div class="Column3PoweredBy">
<div class="Column3Header Column3HeaderPoweredBy">
<div class="txtsevenbbl">
Provided by
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</div>
</div>
<div class="Column3Content Column3ContentPoweredBy">
<table>
<tr>
<td>
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/Partner/td_logo_4whbg.gif" alt="Provided by Transport Direct" />
</a>
</td>
</tr>
</table>
</div>
</div>'

EXEC AddtblContent
@ThemeId, 1, 'langstrings', 'PoweredByControl.HTMLContent.LogoOnly',
'<div class="PoweredByLogo">
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/ProvidedBy1a.gif" alt="Provided by Transport Direct" />
</a>
</div>',

'<div class="PoweredByLogo">
<a href="/Web2/About/AboutUs.aspx">
<img src="/Web2/App_Themes/DirectGov/images/gifs/ProvidedBy1a.gif" alt="Provided by Transport Direct" />
</a>
</div>'

----------------------------------------------------------------
-- Wait page
----------------------------------------------------------------

EXEC AddtblContent
@ThemeId, 32, 'MessageDefinition', '/Channels/TransportDirect/JourneyPlanning/WaitPage',
'We are always seeking to improve our service. If you cannot find what you want, please tell Transport Direct by clicking <b>Contact Transport Direct</b>',
'cy We are always seeking to improve our service. If you cannot find what you want, please tell Transport Direct by clicking <b>Contact Transport Direct</b>'


EXEC dbo.[AddtblContent]
@ThemeId, 1, 'langStrings', 'WaitPage.TitleTipOfTheDay',
'<b>Tip of the Day</b>',
'cy <b>Tip of the Day</b>'


----------------------------------------------------------------
-- Send to friend text 
----------------------------------------------------------------

EXEC AddtblContent
@ThemeId, 1, 'langStrings', 'AmendSaveSendLoginControl.labelLoginRegisterNote',
'This feature is currently not used within this service.',
'cy This feature is currently not used within this service.'


GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1269
SET @ScriptDesc = 'Content added for theme Directgov'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO