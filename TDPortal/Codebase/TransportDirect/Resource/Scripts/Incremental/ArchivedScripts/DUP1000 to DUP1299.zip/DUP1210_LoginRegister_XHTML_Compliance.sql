-- ***********************************************
-- NAME 		: DUP1210_LoginRegister_XHTML_Compliance.sql
-- DESCRIPTION 		: Update LoginRegister page content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 12 December 2008
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'loginPanel.logoutLabel.Text'
,'Thank you for registering your details with Transport Direct. Now you are logged on you have access to the following functions: <br/><ul><li type="disc">Save your favourite journeys so that you can access them in future without having to  re-enter any information</li><li type="disc">Save travel preferences when entering information for a journey so that you won''t have to enter them again - but you can change them if you wish</li><li type="disc">Email travel information to other people</li></ul><br/><br/> Using the buttons below you are able to change your registered email address, delete your account or simply log out of the site. <br/><br/>'
, 'Thank you for registering your details with Transport Direct. Now you are logged on you have access to the following functions: <br/><ul><li type="disc">Save your favourite journeys so that you can access them in future without having to  re-enter any information</li><li type="disc">Save travel preferences when entering information for a journey so that you won''t have to enter them again - but you can change them if you wish</li><li type="disc">Email travel information to other people</li></ul><br/><br/> Using the buttons below you are able to change your registered email address, delete your account or simply log out of the site. <br/><br/>'
GO

-- Help page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpLoginRegister',
'<br/>   <blockquote style="MARGIN-RIGHT: 0px"> <h3>To log in:</h3><br/><br/>     <p>1. Type in the email address that you registered as your username<br/>     2. Type in your 

password<br/>     3. Click ''Next''<br/>     <br/>     If you have forgotten your password:<br/>     1. Type in the email 

address that you registered as your username<br/>     2. Click ''Forgotten Password''<br/>     <br/>     The password will be 

emailed to you.<br/>     <br/>     To change your Email address:<br/>     1. Type in your current email address and 

password<br/>     2. Click ''Change email address''<br/>     3. Type in and confirm the new email address. <br/>     <br/>     

your account will be changed to the new email address with your current password.     <br/>     <br/>     To delete your 

login account:<br/>     1. Type in your current email address and password<br/>     2. Click ''Delete account''<br/>     <br/>  

   Your account will be deleted from the system.   </p> </blockquote>
<br/>
<blockquote style="MARGIN-RIGHT: 0px"> <h3>To register:</h3><br/><p>1. Type in an email address (your username)<br/>2. Type in a password (passwords must be a minimum of 4 

characters and consist of letters or numbers, lower or upper case)<br/>3. Re-type the password<br/>4. Click ''Next'' 
<br/>
If the email address is recognised as a valid email address and the password is accepted, you will be asked to confirm 

the<br/>email address.<br/><br/>Click Confirm if it is the correct email address, and you will then be registered<br/>Click 

Cancel if it is not the correct email address, and you can start the process again</p> </blockquote>',
'<br/>    <blockquote dir="ltr" style="MARGIN-RIGHT: 0px"> <h3>I logio i mewn:</h3><br/><br/>    <p> 1. Teipiwch y cyfeiriad ebost y bu i chi ei gofrestru fel eich enw defnyddiwr<br/>     2. 

Teipiwch eich cyfrinair<br/>     3. Cliciwch ''Nesa''<br/>     <br/>     Os ydych wedi anghofio eich cyfrinair:<br/>     1. 

Teipiwch y cyfeiriad ebost y bu i chi ei gofrestru fel eich enw defnyddiwr<br/>     2. Cliciwch ar ''Wedi anghofio 

Cyfrinair''<br/>     <br/>     Bydd y cyfrinair yn cael ei ebostio atoch.     <br/>     <br/>     To change your Email 

address:<br/>     1. Type in your current email address and password<br/>     2. Click ''Change email address''<br/>     3. 

Type in and confirm the new email address. <br/>     <br/>     your account will be changed to the new email address with 

your current password.     <br/>     <br/>     To delete your login account:<br/>     1. Type in your current email address 

and password<br/>     2. Click ''Delete account''<br/>     <br/>     Your account will be deleted from the system.    
</p> </blockquote>
<br/>
<blockquote dir="ltr" style="MARGIN-RIGHT: 0px"> <h3>I gofrestru:</h3><br/><p>1. Teipiwch gyfeiriad ebost (eich enw defnyddiwr)<br/>2. Teipiwch gyfrinair (rhaid i gyfrineiriau fod yn 

isafswm o 4 symbol a bod yn llythrennau neu yn rhifau, prif lythrennau neu<br/>   lythrennau bach)<br/>3. Ail-deipiwch y 

cyfrinair<br/>4. Cliciwch ar ''Nesa''
<br/>
Os yw''r cyfeiriad ebost yn cael ei adnabod fel cyfeiriad ebost dilys a bod y cyfrinair yn cael ei dderbyn, gofynnir i 

chi<br/>gadarnhau''r cyfeiriad ebost.<br/><br/> � Cliciwch ar ''Cadarnhau'' os mai dyma"r cyfeiriad ebost cywir, ac yna byddwch 

yn cael eich cofrestru<br/>  � Cliciwch ar ''Dileu'' os mai nid dyma"r cyfeiriad ebost cywir, a gallwch ddechrau"r broses eto</p></blockquote>'


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1210
SET @ScriptDesc = 'Update LoginRegister page content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO