-- *************************************************************************************
-- NAME 		: DUP1053_TransportDirect_Content_10_SiteMap.sql
-- DESCRIPTION  	: Updates to Sitemap (all columns)
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER

USE [Content]
GO

-------------------------------------------------------------
-- Site map
-------------------------------------------------------------

-- Plan a journey
EXEC AddtblContent
1, 43, 'JourneyPlannerBody', '/Channels/TransportDirect/SiteMap/SiteMap', 
'<P>
<DIV class="smcSiteMapLink"><A href="/Web2/Maps/JourneyPlannerLocationMap.aspx">Find a map of a location</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Plan a journey to location</DIV>
<DIV class="smcSiteMapSubCategoryContent">Plan a journey from location</DIV>
</DIV> 
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindAStationInput.aspx?NotFindAMode=true">Find nearest station/airport</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Travel to station/airport</DIV>
<DIV class="smcSiteMapSubCategoryContent">Travel from station/airport</DIV>
</DIV> 
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindCarParkInput.aspx?NotFindAMode=true&amp;DriveFromTo=true">Find nearest car park</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Drive to this airport</DIV>
<DIV class="smcSiteMapSubCategoryContent">Drive from this airport</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/Maps/NetworkMaps.aspx">Transport network maps</A>
<UL id="lister">
<LI><A href="/Web2/Maps/NetworkMaps.aspx#Rail">Rail</A> 
<LI><A href="/Web2/Maps/NetworkMaps.aspx#Coach">Coach </A>
<LI><A href="/Web2/Maps/NetworkMaps.aspx#UndergroundMetro">Underground/Metro </A>
<LI><A href="/Web2/Maps/NetworkMaps.aspx#Bus">Bus </A></LI></UL></DIV>
<P></P>
<P>
<DIV class="smcSiteMapLink"><A href="/Web2/Maps/TrafficMaps.aspx">Predicted traffic level maps</A><BR></DIV></P>', 

'<P>
<DIV class="smcSiteMapLink"><A href="/Web2/Maps/JourneyPlannerLocationMap.aspx">Darganfyddwch fap o leoliad</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Plan a journey to location</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Plan a journey from location</DIV>
</DIV> 
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindAStationInput.aspx?NotFindAMode=true">Dod o hyd i''r orsaf/maes awyr agosaf</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Travel to station/airport</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Travel from station/airport</DIV>
</DIV> 
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindACarParkInput.aspx?NotFindAMode=true&amp;DriveFromTo=true">cy-Find a Car Park</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Drive to this airport</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Drive from this airport</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/Maps/NetworkMaps.aspx">Mapiau''r rhwydwaith cludiant</A> 
<UL id="lister">
<LI><A href="/Web2/Maps/NetworkMaps.aspx#Rail">Rheilffordd </A>
<LI><A href="/Web2/Maps/NetworkMaps.aspx#Coach">Bws moethus </A>
<LI><A href="/Web2/Maps/NetworkMaps.aspx#UndergroundMetro">Tr&#234;n tanddaearol/metro</A> 
<LI><A href="/Web2/Maps/NetworkMaps.aspx#Bus">Bws </A></LI></UL></DIV>
<P></P>
<P>
<DIV class="smcSiteMapLink"><A href="/Web2/Maps/TrafficMaps.aspx">cy Predicted traffic level maps</A><BR></DIV></P>'
GO

-- Live travel
EXEC AddtblContent
1, 43, 'LiveTravelBody', '/Channels/TransportDirect/SiteMap/SiteMap', 
'<P><DIV class="smcSiteMapLink"><A href="/Web2/Tools/BusinessLinks.aspx">Link to our website</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/Tools/ToolbarDownload.aspx">Download our toolbar</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Mobile demonstrator</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check Journey CO2</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/FeedbackPage.aspx">Provide feedback</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/RelatedSites.aspx">Related sites</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/RelatedSites.aspx#NationalTransport">National transport</A><BR>
<LI><A href="/Web2/About/RelatedSites.aspx#LocalPublicTransport">Local public transport</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Motoring">Motoring</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#MotoringCosts">Motoring Costs</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#CarSharing">Car Sharing</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Government">Government</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Help/NewHelp.aspx">Frequently Asked Questions</A><BR></DIV></P>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Tools/Home.aspx#digitvinfo">Digital TV</A><BR></DIV></P>
<P><A href="/Web2/LoginRegister.aspx">Login/Register</A></P>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Save Preferences</DIV>
<DIV class="smcSiteMapSubCategoryContent">Save Favourites</DIV>
<DIV class="smcSiteMapSubCategoryContent">Send to Friend</DIV>
</DIV>', 

'<P><DIV class="smcSiteMapLink"><A href="/Web2/Tools/BusinessLinks.aspx">Creu dolen i''n gwefan</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/Tools/ToolbarDownload.aspx">Lawrlwythwch ein bar offer</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Arddangosydd symudol</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Check Journey CO2</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/FeedbackPage.aspx">Rhowch adborth</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/RelatedSites.aspx">Safleoedd cysylltiedig</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/RelatedSites.aspx#NationalTransport">Cludiant cenedlaethol</A><BR>
<LI><A href="/Web2/About/RelatedSites.aspx#LocalPublicTransport">Cludiant cyhoeddus lleol</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Motoring">Moduro</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#MotoringCosts">Costau moduro</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#CarSharing">Rhannu ceir</A> 
<LI><A href="/Web2/About/RelatedSites.aspx#Government">Llywodraeth</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Help/NewHelp.aspx">Cwestiynau a Ofynnir yn Aml</A><BR></DIV></P>
<P><DIV class="smcSiteMapLink"><A href="/Web2/Tools/Home.aspx#digitvinfo">Deledu digidol</A><BR></DIV></P>
<P><A href="/Web2/LoginRegister.aspx">cy-Login/Register</A></P>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Save Preferences</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Save Favourites</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Send to Friend</DIV>
</DIV> '
GO

-- Maps
EXEC AddtblContent
1, 43, 'MapsBody', '/Channels/TransportDirect/SiteMap/SiteMap', 
'<P><DIV class="smcSiteMapLink"><A href="/Web2/LiveTravel/TravelNews.aspx">Table of live travel news</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/LiveTravel/DepartureBoards.aspx">Departure board information</A><BR>
<UL id="lister">
<LI><A href="/Web2/LiveTravel/DepartureBoards.aspx#Train">Train departure board</A> 
<LI><A href="/Web2/LiveTravel/DepartureBoards.aspx#top">Bus departure board</A> 
<P></P></LI></UL></DIV>', 

'<P><DIV class="smcSiteMapLink"><A href="/Web2/LiveTravel/TravelNews.aspx">Tabl o newyddion teithio byw</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/LiveTravel/DepartureBoards.aspx">Gwybodaeth am y bwrdd ymadael</A><BR>
<UL id="lister">
<LI><A href="/Web2/LiveTravel/DepartureBoards.aspx#Train">Bwrdd trenau yn ymadael</A> 
<LI><A href="/Web2/LiveTravel/DepartureBoards.aspx#top">Bwrdd bysiau yn ymadael</A> 
<P></P></LI></UL></DIV>'
GO

-- Quick planners
EXEC AddtblContent
1, 43, 'QuickPlannersBody', '/Channels/TransportDirect/SiteMap/SiteMap',
'<P><DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">Door-to-door journey planner</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">Buy Tickets</DIV>
<DIV class="smcSiteMapSubCategoryContent">Check CO2</DIV>
</DIV> 
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindTrainInput.aspx">Find a train</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Quickest</DIV>
<DIV class="smcSiteMapSubCategoryContent">Cheapest</DIV>
<DIV class="smcSiteMapSubCategoryContent">Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">Buy Tickets</DIV>
<DIV class="smcSiteMapSubCategoryContent">Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Find cheaper rail fares</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindFlightInput.aspx">Find a flight</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindCarInput.aspx">Find a car route</A><BR></div>
<p><DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Fastest</DIV>
<DIV class="smcSiteMapSubCategoryContent">Shortest</DIV>
<DIV class="smcSiteMapSubCategoryContent">Most fuel economic</DIV>
<DIV class="smcSiteMapSubCategoryContent">Cheapest overall</DIV>
<DIV class="smcSiteMapSubCategoryContent">Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">Check CO2</DIV>
</DIV></p>
<UL id="lister"> 
<LI><A href="/Web2/JourneyPlanning/ParkAndRide.aspx">Park and ride schemes</A></LI>
</UL></DIV>
</P>
<P>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindCoachInput.aspx">Find a coach</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindTrunkInput.aspx?ClassicMode=true">Compare city-to-city journeys</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/VisitPlannerInput.aspx">Day trip planner</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindCarParkInput.aspx?DriveFromTo=true">Drive to a car park</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to Park and Ride</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindBusInput.aspx">Find a bus</A></DIV></P>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">Check CO2</DIV>
</DIV>',

'<P><DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">Cynlluniwr siwrnai drws-i-ddrws</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Buy Tickets</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindTrainInput.aspx">Canfyddwch dr&#234;n</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Quickest</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Cheapest</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Buy Tickets</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">cy Find cheaper rail fares</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindFlightInput.aspx">Canfyddwch ehediad</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindCarInput.aspx">Canfyddwch lwybr car</A><BR></div>

<DIV class="smcSiteMapSubCategory">
<p><DIV class="smcSiteMapSubCategoryContent">cy-Fastest</DIV></p>
<p><DIV class="smcSiteMapSubCategoryContent">cy-Shortest</DIV></p>
<p><DIV class="smcSiteMapSubCategoryContent">cy-Most fuel economic</DIV></p>
<p><DIV class="smcSiteMapSubCategoryContent">cy-Cheapest overall</DIV></p>
<p><DIV class="smcSiteMapSubCategoryContent">cy-Costs</DIV></p>
<p><DIV class="smcSiteMapSubCategoryContent">cy-Check CO2</DIV></p>
</DIV>
<UL id="lister"> 
<LI><A href="/Web2/JourneyPlanning/ParkAndRide.aspx">Cynlluniau parcio a theithio</A></LI>
</UL></DIV>
</P>
<P>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindCoachInput.aspx">Canfyddwch fws moethus</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindTrunkInput.aspx">Cymharu siwrneion dinas-i-ddinas</A><BR></DIV>
<DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Check CO2</DIV>
</DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/VisitPlannerInput.aspx">Cynllunydd teithiau dydd</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindCarParkInput.aspx?DriveFromTo=true">cy-Drive to a car park</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Cynlluniwch i barcio a theithio</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/JourneyPlanning/FindBusInput.aspx">Canfyddwch fws</A></DIV>
</P><DIV class="smcSiteMapSubCategory">
<DIV class="smcSiteMapSubCategoryContent">cy-Ticket/Costs</DIV>
<DIV class="smcSiteMapSubCategoryContent">cy-Check CO2</DIV>
</DIV>'


-- TDOnTheMove
EXEC AddtblContent
1, 43, 'TDOnTheMoveBody', '/Channels/TransportDirect/SiteMap/SiteMap',
'<P><DIV class="smcSiteMapLink"><A href="/Web2/About/AboutUs.aspx">About us</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/AboutUs.aspx#EnablingIntelligentTravel">Enabling intelligent travel</A><BR>
<LI><A href="/Web2/About/AboutUs.aspx#WhoOperates">Who operates Transport Direct? </A>
<LI><A href="/Web2/About/AboutUs.aspx#WhoBuilds">Who builds this site?</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhatsNext">What''s next?</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/About/Accessibility.aspx">Accessibility</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/Details.aspx">Contact details</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/DataProviders.aspx">Data providers</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/PrivacyPolicy.aspx">Privacy policy</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/TermsConditions.aspx">Terms &amp; conditions</A><BR></DIV>
</P>', 

'<P><DIV class="smcSiteMapLink"><A href="/Web2/About/AboutUs.aspx">Amdanom ni</A><BR>
<UL id="lister">
<LI><A href="/Web2/About/AboutUs.aspx#EnablingIntelligentTravel">Galluogi teithio deallus</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhoOperates">Pwy sy''n gweithredu Transport Direct? </A>
<LI><A href="/Web2/About/AboutUs.aspx#WhoBuilds">Pwy sy''n adeiladu a datblygu''r safle hwn?</A> 
<LI><A href="/Web2/About/AboutUs.aspx#WhatsNext">Beth nesaf?</A> </LI></UL></DIV>
<P><DIV class="smcSiteMapLink"><A href="/Web2/About/Accessibility.aspx">Hygyrchedd</A> <BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/ContactUs/Details.aspx">Manylion cyswllt</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/DataProviders.aspx">Darparwyr data</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/PrivacyPolicy.aspx">Polisi preifatrwydd</A><BR></DIV>
<DIV class="smcSiteMapLink"><A href="/Web2/About/TermsConditions.aspx">Amodau a thelerau</A><BR></DIV>
</P>'
GO

EXEC AddtblContent
1, 43, 'sitemapFooterNote', '/Channels/TransportDirect/SiteMap/SiteMap',
'NOTE Items in black are secondary options of the preceding blue action
<br />
<br />',
'cy - NOTE Items in black are secondary options of the preceding blue action
<br />
<br />'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1053
SET @ScriptDesc = 'Updates to Sitemap'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
