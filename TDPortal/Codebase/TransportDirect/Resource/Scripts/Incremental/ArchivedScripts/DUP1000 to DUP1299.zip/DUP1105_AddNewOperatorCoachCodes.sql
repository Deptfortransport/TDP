-- **********************************************************************
-- $Workfile:   DUP1105_AddNewOperatorCoachCodes.sql  $
-- AUTHOR       : j.roberts
-- DATE CREATED : 15/09/2008
-- REVISION     : $Revision:   1.0  $
-- DESCRIPTION  : Creates the function to support adding CoachOperatorCode
--                and adds new CoachOperatorCodes
-- **********************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP1105_AddNewOperatorCoachCodes.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 11:00:16   mmodi
--Initial revision.
--
--   Rev 1.0   Sep 15 2008 10:10:10   jroberts
--Initial revision.
--
--
--

USE [PermanentPortal]
GO

-- **********************************************************************
-- PROCEDURE INFAddCoachOperatorCode
-- **********************************************************************
DECLARE @ObjectName AS varchar(128)
SET @ObjectName = N'INFAddCoachOperatorCode'
IF NOT EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = @ObjectName
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
    EXEC ('CREATE PROCEDURE [dbo].INFAddCoachOperatorCode AS BEGIN SELECT 1 END')

    EXEC sp_addextendedproperty @name=N'Design', @value=N'SD00?? ?????' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Owner', @value=N'TDP' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Used By', @value=N'Infrastructure' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName

END
GO


GO
-- **********************************************************************
-- PROCEDURE INFAddCoachOperatorCode
-- Description: 
-- 
-- **********************************************************************
ALTER PROCEDURE dbo.INFAddCoachOperatorCode
(
    @CJPOperatorCode  varchar(50),
    @TDOperatorCode   varchar(50)
) AS
BEGIN
    IF EXISTS(SELECT 1
                FROM [dbo].[CoachOperatorCodes]
               WHERE [CJPOperatorCode] = @CJPOperatorCode
                 AND [TDOperatorCode]  = @TDOperatorCode)
        BEGIN
            UPDATE [dbo].[CoachOperatorCodes]
               SET [CJPOperatorCode] = @CJPOperatorCode,
                   [TDOperatorCode]  =@TDOperatorCode
             WHERE [CJPOperatorCode] = @CJPOperatorCode
        END
    ELSE
        BEGIN    
            INSERT INTO [dbo].[CoachOperatorCodes]
            (
                [CJPOperatorCode],
                [TDOperatorCode]
            )
            VALUES
            (
                @CJPOperatorCode,
                @TDOperatorCode
            )    
        END
    --END IF
END
GO

DECLARE @CJPOperatorCode  varchar(50)
DECLARE @TDOperatorCode   varchar(50)

SET @TDOperatorCode = 'NX'

SET @CJPOperatorCode = 'CO'
EXEC dbo.INFAddCoachOperatorCode @CJPOperatorCode, @TDOperatorCode

SET @CJPOperatorCode = 'CK'
EXEC dbo.INFAddCoachOperatorCode @CJPOperatorCode, @TDOperatorCode

SET @CJPOperatorCode = 'IS'
EXEC dbo.INFAddCoachOperatorCode @CJPOperatorCode, @TDOperatorCode

SET @CJPOperatorCode = 'IN'
EXEC dbo.INFAddCoachOperatorCode @CJPOperatorCode, @TDOperatorCode

SET @CJPOperatorCode = 'SD'
EXEC dbo.INFAddCoachOperatorCode @CJPOperatorCode, @TDOperatorCode

GO

-- ************************************************ 
-- Update the Change Log
-- ************************************************ 

USE [PermanentPortal]
GO

DECLARE @ScriptNumber int
DECLARE @ScriptDesc varchar(200)

SET @ScriptNumber = 1105
SET @ScriptDesc = 'Creates the function to support adding CoachOperatorCode and adds new CoachOperatorCodes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
    BEGIN
        UPDATE [dbo].[ChangeCatalogue]
           SET ChangeDate = getDate(), Summary = @ScriptDesc
         WHERE ScriptNumber = @ScriptNumber
    END
ELSE
    BEGIN
        INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
        VALUES (@ScriptNumber, getDate(), @ScriptDesc)
    END
GO
GO
