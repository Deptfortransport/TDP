-- ***********************************************
-- NAME 		: DUP1279_Homepage_Messages.sql
-- DESCRIPTION 		: Update Homepage Messages
-- AUTHOR		: Tej Sohal
-- DATE			: 06 February 2009
-- ************************************************

USE [PermanentPortal]
GO

UPDATE HomePageMessage SET valueEN='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br />  &bull;  South West England including Hampshire<br />  &bull;  West Midlands<br />  &bull;  Yorkshire<br />   &bull;  Wales<br />  &bull;  North West of England including Liverpool and Manchester<br /> We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
, valueCY='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br />  &bull;  South West England including Hampshire<br />  &bull;  West Midlands<br />  &bull;  Yorkshire<br />   &bull;  Wales<br />  &bull;  North West of England including Liverpool and Manchester<br /> We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
WHERE Description='MRMD'

UPDATE HomePageMessage SET valueEN='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</font></td></tr>'
, valueCY='<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</font></td></tr>' 
WHERE Description='NCSD'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1279
SET @ScriptDesc = 'Update Homepage Messages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO