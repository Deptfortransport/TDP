-- ***********************************************
-- NAME 		: DUP1103_CyclePlanner_CreateCyclePlannerRoutesObjects.sql
-- DESCRIPTION 		: Script to create new Cycle Routes DB objects
-- AUTHOR		: Steve Craddock
-- DATE			: 08 Sep 2008
-- ************************************************

-- ***************************************
-- This script contains security settings that will need checking
-- ***************************************


USE [TDP_ROUTES]
GO
IF EXISTS(SELECT 1
                FROM INFORMATION_SCHEMA.TABLES
               WHERE TABLE_NAME = N'CYCLE_ROUTES')
BEGIN
	USE [TDP_ROUTES]
	DROP TABLE [routesadmin].[CYCLE_ROUTES]
END

GO

CREATE TABLE [routesadmin].[CYCLE_ROUTES] (
	[SessionID] nvarchar(88) NOT NULL ,
	[RouteNum] int NOT NULL,
	[CycleRoute] image NOT NULL ,
	[DataLen] int NOT NULL ,
	[TSDate] datetime NOT NULL 
) ON [TDP_ROUTES_DATA] TEXTIMAGE_ON [TDP_ROUTES_DATA]
GO


ALTER TABLE routesadmin.CYCLE_ROUTES ADD CONSTRAINT
	DF_CYCLE_ROUTES_DateCreated DEFAULT (getdate()) FOR TSDate
GO

ALTER TABLE [routesadmin].[CYCLE_ROUTES] WITH NOCHECK ADD 
	CONSTRAINT [PK_CYCLE_ROUTES] PRIMARY KEY  CLUSTERED 
	(
		[SESSIONID],[ROUTENUM]
	)  ON [TDP_ROUTES_DATA] 
GO

CREATE  INDEX [IX_CYCLE_ROUTES_DATE] ON [routesadmin].[CYCLE_ROUTES]([TSDate]) ON [TDP_ROUTES_INDEX]
GO

USE [TDP_ROUTES]
GO
IF EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = N'InsertCycleRoute'
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
	USE [TDP_ROUTES]
	DROP PROCEDURE [dbo].[InsertCycleRoute]
END

GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

setuser N'routesadmin'
GO

CREATE PROCEDURE [dbo].[InsertCycleRoute] (
	@sessionid nvarchar(88),
	@routenum int,
	@cycleroute  image,
	@datalen   int) AS
	SET NOCOUNT OFF
	INSERT INTO routesadmin.Cycle_Routes(sessionid,routenum,cycleroute,datalen)
		VALUES(@sessionid,@routenum,@cycleroute,@datalen)
GO
SETUSER
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

USE [TDP_ROUTES]
GO
IF EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = N'usp_DeleteESRIRouteMapData'
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
	USE [TDP_ROUTES]
	DROP PROCEDURE dbo.usp_DeleteESRIRouteMapData
END

GO

CREATE PROCEDURE [dbo].[usp_DeleteESRIRouteMapData] @expiry int
AS
BEGIN
 
	IF EXISTS(SELECT 1 FROM sysobjects WHERE name='RD_Routes_blob' and type='U')
		Begin
			-- road data ready for distribution
			
			DELETE FROM TDP_ROUTES.dbo.RD_Routes_blob
			WHERE TSDATE < dateadd(hour, @expiry, getdate())
		End
			
			
	IF EXISTS(SELECT 1 FROM sysobjects WHERE name='RD_Routes_blob_local' and type='U')
		Begin
			-- road data distributed ready for unpacking

			DELETE FROM TDP_ROUTES.dbo.RD_Routes_blob_local
			WHERE TSDATE < dateadd(hour, @expiry, getdate())
		End

	-- road data expanded
	DELETE FROM TDP_ROUTES.routesadmin.RD_Routes
	WHERE TSDATE < dateadd(hour, @expiry, getdate())

	-- pt data
	DELETE FROM TDP_ROUTES.routesadmin.PT_Routes 
	WHERE TSDATE < dateadd(hour, @expiry, getdate())

	-- cycle route data	
	DELETE FROM TDP_ROUTES.routesadmin.Cycle_Routes 
	WHERE TSDATE < dateadd(hour, @expiry, getdate())

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

USE TransientGIS
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_InsertCycleRoute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_InsertCycleRoute]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

---------------------------------------------------
-- Creates stored procedure for public transport --
---------------------------------------------------
CREATE   procedure usp_InsertCycleRoute (@sessionid nvarchar(88),
	@routenum int,
	@cycleroute  image,
	@datalen   int ) as

declare @idoc int
--------------------------------------------------------------------------
-- The following line need to be added for each and every linked server --
-- Replace linkedservername with the correct linked server              --
--------------------------------------------------------------------------
--exec [linkedservername].[MASTERMAP].[dbo].usp_Save_To_PT_Table_Arr @SESSIONID, @XML
exec [SID01].[TDP_ROUTES].[dbo].InsertCycleRoute @sessionid, @routenum, @cycleroute, @datalen
--exec [D06].[TDP_ROUTES].[dbo].InsertCycleRoute @sessionid, @routenum, @cycleroute, @datalen

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1103
SET @ScriptDesc = 'Script to create new Cycle Routes DB objects'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO