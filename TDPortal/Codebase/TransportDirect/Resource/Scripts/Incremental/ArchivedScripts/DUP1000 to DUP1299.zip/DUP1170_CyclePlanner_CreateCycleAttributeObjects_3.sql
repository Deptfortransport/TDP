-- ***********************************************
-- NAME 		: DUP1170_CyclePlanner_CreateCycleAttributeObjects_3.sql
-- DESCRIPTION 		: Script to create new Cycle Attribute table, stored procs, and data
-- AUTHOR		: Mark Turner
-- DATE			: 31 Oct 2008
-- ************************************************


USE [TransientPortal]
GO

---------------------------------------------------
-- Delete all existing attributes - [CycleAttribute]
---------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[CycleAttribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	TRUNCATE TABLE [CycleAttribute]    

END
GO



---------------------------------------------------
-- ADD DATA
---------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[CycleAttribute]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN


-- Insert the cycle attributes
--						  [CycleAttributeId], [Description], [Type], [Group], [Category], 				[ResourceName], 						  [Mask], [CycleInfrastructure], [CycleRecommendedRoute], [ShowAttribute]
INSERT INTO [CycleAttribute] VALUES (   0   , 'No attributes', 'Link', 'ITN', 'None',         			'CycleAttribute.NoCycleAttributes',       '0x00000000', 	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	1	, 'Motorway', 'Link', 'ITN',      'Type', 	                'CycleAttribute.Motorway',                '0x00000001',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	2	, 'A Road', 'Link', 'ITN',        'Type', 	                'CycleAttribute.ARoad',                   '0x00000002',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	3	, 'B Road', 'Link', 'ITN',        'Type', 	                'CycleAttribute.BRoad',                   '0x00000004',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	4	, 'Minor Road', 'Link', 'ITN',    'Type', 	                'CycleAttribute.MinorRoad',               '0x00000008',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	5	, 'Local Street', 'Link', 'ITN',  'Type', 	                'CycleAttribute.LocalStreet',             '0x00000010',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	6	, 'Alley', 'Link', 'ITN',         'Type', 	                'CycleAttribute.Alley',                   '0x00000020',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	7	, 'Private Road', 'Link', 'ITN',  'Type', 	                'CycleAttribute.PrivateRoad',             '0x00000040',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	8	, 'Pedestrianised Street', 'Link', 'ITN', 'Type', 	        'CycleAttribute.PedestrianisedStreet',    '0x00000080',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	9	, 'Toll Road', 'Link', 'ITN',     'Type', 	                'CycleAttribute.TollRoad',                '0x00000100',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	10	, 'Single Carriageway', 'Link', 'ITN', 'Type', 	            'CycleAttribute.SingleCarriageway',       '0x00000200',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	11	, 'Dual Carriageway', 'Link', 'ITN', 'Type', 	            'CycleAttribute.DualCarriageway',         '0x00000400',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	12	, 'Slip Road', 'Link', 'ITN',     'Type', 	                'CycleAttribute.SlipRoad',                '0x00000800',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	13	, 'Roundabout', 'Link', 'ITN',    'Type', 	                'CycleAttribute.Roundabout',              '0x00001000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	14	, 'Enclosed Traffic Area Link', 'Link', 'ITN', 'Type', 	    'CycleAttribute.EnclosedTrafficAreaLink', '0x00002000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	15	, 'Traffic Island Link At Junction', 'Link', 'ITN', 'Type', 'CycleAttribute.TrafficIslandLinkAtJunction', '0x00004000',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	16	, 'Traffic Island Link', 'Link', 'ITN', 'Type', 	        'CycleAttribute.TrafficIslandLink',       '0x00008000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	17	, 'Ferry', 'Link', 'ITN',         'Type', 	                'CycleAttribute.Ferry',                   '0x00010000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	18	, 'Limited Access', 'Link', 'ITN', 'Type', 	                'CycleAttribute.LimitedAccess',           '0x00020000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	19	, 'Prohibited Access', 'Link', 'ITN', 'Type', 	            'CycleAttribute.ProhibitedAccess',        '0x00040000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	20	, 'Footpath', 'Link', 'ITN',      'Type', 	                'CycleAttribute.Footpath',                '0x00080000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	21	, 'Cyclepath', 'Link', 'ITN',     'Type', 	                'CycleAttribute.Cyclepath',               '0x00100000',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	22	, 'Bridlepath', 'Link', 'ITN',    'Type', 	                'CycleAttribute.Bridlepath',              '0x00200000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	23	, 'Can drive A to B', 'Link', 'ITN', 'Type', 	            'CycleAttribute.CandriveAtoB',            '0x00400000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	24	, 'Can drive B to A', 'Link', 'ITN', 'Type', 	            'CycleAttribute.CandriveBtoA',            '0x00800000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	25	, 'Can enter at A i.e. no entry at B', 'Link', 'ITN', 'Type', 	'CycleAttribute.CanenteratAi.e.noentryatB', '0x01000000',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	26	, 'Can enter at B i.e. no entry at A', 'Link', 'ITN', 'Type', 	'CycleAttribute.CanenteratBi.e.noentryatA', '0x02000000',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	27	, 'Superlink', 'Link', 'ITN',     'Type', 	                'CycleAttribute.Superlink',               '0x04000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	28	, 'Trunk Road', 'Link', 'ITN',    'Type', 	                'CycleAttribute.TrunkRoad',               '0x08000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	29	, 'Turn Superlink', 'Link', 'ITN', 'Type', 	                'CycleAttribute.TurnSuperlink',           '0x10000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	30	, 'Connecting Link', 'Link', 'ITN', 'Type', 	            'CycleAttribute.ConnectingLink',          '0x20000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	31	, 'Towpath', 'Link', 'ITN',       'Type', 	                'CycleAttribute.Towpath',                 '0x40000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	32	, 'Gradient 2 - A to B uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient2-AtoBuphill',    '0x00000001',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	33	, 'Gradient 2 - B to A uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient2-BtoAuphill',    '0x00000002',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	34	, 'Gradient 3 - A to B uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient3-AtoBuphill',    '0x00000004',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	35	, 'Gradient 3 - B to A uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient3-BtoAuphill',    '0x00000008',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	36	, 'Gradient 4 - A to B uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient4-AtoBuphill',    '0x00000010',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	37	, 'Gradient 4 - B to A uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient4-BtoAuphill',    '0x00000020',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	38	, 'Gradient 5 - A to B uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient5-AtoBuphill',    '0x00000040',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	39	, 'Gradient 5 - B to A uphill', 'Link', 'User0', 'Characteristic', 'CycleAttribute.Gradient5-BtoAuphill',    '0x00000080',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	40	, 'Ford', 'Link', 'User0', 'Barrier', 	                    'CycleAttribute.Ford',                    '0x00000100',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	41	, 'Gate', 'Link', 'User0', 'Barrier', 	                    'CycleAttribute.Gate',                    '0x00000200',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	42	, 'Level Crossing', 'Link', 'User0', 'Barrier', 	        'CycleAttribute.LevelCrossing',           '0x00000400',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	43	, 'Bridge', 'Link', 'User0', 'Barrier', 	                'CycleAttribute.Bridge',                  '0x00000800',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	44	, 'Tunnel', 'Link', 'User0', 'Barrier', 	                'CycleAttribute.Tunnel',                  '0x00001000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	45	, 'Calming Unavoidable by Bike', 'Link', 'User0', 'Barrier', 	'CycleAttribute.CalmingUnavoidablebyBike', '0x00002000',	0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	46	, 'Footbridge', 'Link', 'User0', 'Barrier', 	            'CycleAttribute.Footbridge',              '0x00004000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	47	, 'Unused', 'Link', 'User0', 'None', 	            		'CycleAttribute.Unused',                  '0x00008000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	48	, 'Shared Use Footpath', 'Link', 'User0', 'Type', 	    	'CycleAttribute.SharedUseFootpath',       '0x00010000',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	49	, 'Footpath Only', 'Link', 'User0', 'Type', 	    		'CycleAttribute.FootpathOnly',            '0x00020000',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	50	, 'Cycles Only', 'Link', 'User0', 'Type', 	    			'CycleAttribute.CyclesOnly',              '0x00040000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	51	, 'Private Access', 'Link', 'User0', 'Characteristic', 	    'CycleAttribute.PrivateAccess',           '0x00080000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	52	, 'Unused', 'Link', 'User0', 'None', 	        		'CycleAttribute.Unused',                '0x00100000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	53	, 'Parkland', 'Link', 'User0', 'Barrier', 	                	'CycleAttribute.Parkland',                  '0x00200000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	54	, 'Subway', 'Link', 'User0', 'Barrier', 	            	'CycleAttribute.Subway',                  '0x00400000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	55	, 'Raisable Barrier', 'Link', 'User0', 'Barrier', 	        'CycleAttribute.RaisableBarrier',         '0x00800000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	56	, 'Hoop Lift Barrier', 'Link', 'User0', 'Barrier', 	        'CycleAttribute.HoopLiftBarrier',         '0x01000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	57	, 'Cattle Grid', 'Link', 'User0', 'Barrier', 	            'CycleAttribute.CattleGrid',              '0x02000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	58	, 'Stile', 'Link', 'User0', 'Barrier', 	                    'CycleAttribute.Stile',                   '0x04000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	59	, 'Hoop Through Barrier', 'Link', 'User0', 'Barrier', 	    'CycleAttribute.HoopThroughBarrier',      '0x08000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	60	, 'Humps', 'Link', 'User0', 'Barrier', 	                    'CycleAttribute.Humps',                   '0x10000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	61	, 'Cushions', 'Link', 'User0', 'Barrier', 	                'CycleAttribute.Cushions',                '0x20000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	62	, 'Chicane', 'Link', 'User0', 'Barrier', 	                'CycleAttribute.Chicane',                 '0x40000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	63	, 'Pinch Point', 'Link', 'User0', 'Barrier', 	            'CycleAttribute.PinchPoint',              '0x80000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	64	, 'Pelican', 'Link', 'User1', 'Crossing', 	                'CycleAttribute.Pelican',                 '0x00000001',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	65	, 'Toucan', 'Link', 'User1', 'Crossing', 	                'CycleAttribute.Toucan',                  '0x00000002',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	66	, 'Zebra', 'Link', 'User1', 'Crossing', 	                'CycleAttribute.Zebra',                   '0x00000004',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	67	, 'Walkabout Manoeuvre', 'Stopover', 'User1', 'Manoeuvrability', 	    	'CycleAttribute.WalkaboutManoeuvre',      '0x00000008',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	68	, 'Advanced Manoeuvre', 'Stopover', 'User1', 'Manoeuvrability', 	    	'CycleAttribute.AdvancedManoeuvre',       '0x00000010',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	69	, 'Prohibited Manoeuvre', 'Stopover', 'User1', 'Manoeuvrability', 	    	'CycleAttribute.ProhibitedManoeuvre',     '0x00000020',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	70	, 'Cycle Lane A to B', 'Link', 'User1', 'Type', 			'CycleAttribute.CycleLaneAtoB',           '0x00000040',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	71	, 'Cycle Lane B to A', 'Link', 'User1', 'Type', 			'CycleAttribute.CycleLaneBtoA',           '0x00000080',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	72	, 'Bus Lane A to B', 'Link', 'User1', 'Type', 				'CycleAttribute.BusLaneAtoB',             '0x00000100',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	73	, 'Bus Lane B to A', 'Link', 'User1', 'Type',     			'CycleAttribute.BusLaneBtoA',             '0x00000200',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	74	, 'Narrow A to B', 'Link', 'User1', 'Type', 	    		'CycleAttribute.NarrowAtoB',              '0x00000400',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	75	, 'Narrow B to A', 'Link', 'User1', 'Type', 	    		'CycleAttribute.NarrowBtoA',              '0x00000800',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	76	, 'Dedicated A to B', 'Link', 'User1', 'Type', 				'CycleAttribute.DedicatedAtoB',           '0x00001000',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	77	, 'Dedicated B to A', 'Link', 'User1', 'Type', 				'CycleAttribute.DedicatedBtoA',           '0x00002000',		1, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	78	, 'Unpaved A to B', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.UnpavedAtoB',             '0x00004000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	79	, 'Unpaved B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.UnpavedBtoA',             '0x00008000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	80	, 'When Dry A to B', 'Link', 'User1', 'Characteristic', 	'CycleAttribute.WhenDryAtoB',             '0x00010000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	81	, 'When Dry B to A', 'Link', 'User1', 'Characteristic', 	'CycleAttribute.WhenDryBtoA',             '0x00020000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	82	, 'Firm A to B', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.FirmAtoB',                '0x00040000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	83	, 'Firm B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.FirmBtoA',                '0x00080000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	84	, 'Paved A to B', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.PavedAtoB',               '0x00100000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	85	, 'Paved B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.PavedBtoA',               '0x00200000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	86	, 'Loose A to B', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.LooseAtoB',               '0x00400000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	87	, 'Loose B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.LooseBtoA',               '0x00800000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	88	, 'Cobbles A to B', 'Link', 'User1', 'Characteristic',      'CycleAttribute.CobblesAtoB',             '0x01000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	89	, 'Cobbles B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.CobblesBtoA',             '0x02000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	90	, 'Mixed A to B', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.MixedAtoB',               '0x04000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	91	, 'Mixed B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.MixedBtoA',               '0x08000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	92	, 'Rough A to B', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.RoughAtoB',               '0x10000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	93	, 'Rough B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.RoughBtoA',               '0x20000000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	94	, 'Blocks A to B', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.BlocksAtoB',              '0x40000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	95	, 'Blocks B to A', 'Link', 'User1', 'Characteristic', 	    'CycleAttribute.BlocksBtoA',              '0x80000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	96	, 'Individual Recommendation', 'Link', 'User2', 'None',		'CycleAttribute.IndividualRecommendation', '0x00000001',	0, 1, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	97	, 'LA Recommended', 'Link', 'User2', 'None', 	        	'CycleAttribute.LARecommended',           '0x00000002',		0, 1, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	98	, 'Recommended For Schools', 'Link', 'User2', 'None', 	    'CycleAttribute.RecommendedForSchools',   '0x00000004',		0, 1, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	99	, 'Other Recommendation', 'Link', 'User2', 'None', 	        'CycleAttribute.OtherRecommendation',     '0x00000008',		0, 1, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	100	, 'Well Lit', 'Link', 'User2', 'Characteristic', 	        'CycleAttribute.WellLit',                 '0x00000010',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	101	, 'Lighting Present', 'Link', 'User2', 'Characteristic', 	'CycleAttribute.LightingPresent',         '0x00000020',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	102	, 'Partial Lighting', 'Link', 'User2', 'Characteristic', 	'CycleAttribute.PartialLighting',         '0x00000040',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	103	, 'No lighting', 'Link', 'User2', 'Characteristic', 	    'CycleAttribute.Nolighting',              '0x00000080',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	104	, 'Busy', 'Link', 'User2', 'Characteristic', 	            'CycleAttribute.Busy',                    '0x00000100',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	105	, 'Very', 'Link', 'User2', 'Characteristic', 	            'CycleAttribute.Very',                    '0x00000200',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	106	, 'Quiet', 'Link', 'User2', 'Characteristic', 	            'CycleAttribute.Quiet',                   '0x00000400',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	107	, 'Traffic Free', 'Link', 'User2', 'Characteristic', 	    'CycleAttribute.TrafficFree',             '0x00000800',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	108	, 'Seldom Policed Urban Area', 'Link', 'User2', 'Characteristic', 	'CycleAttribute.SeldomPolicedUrbanArea', '0x00001000',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	109	, 'Isolated Area', 'Link', 'User2', 'Characteristic', 	    'CycleAttribute.IsolatedArea',            '0x00002000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	110	, 'Neighbourhood Watch', 'Link', 'User2', 'Characteristic', 'CycleAttribute.NeighbourhoodWatch',      '0x00004000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	111	, 'Cctv Monitored Area', 'Link', 'User2', 'Characteristic', 'CycleAttribute.Cctv MonitoredArea',      '0x00008000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	112	, 'Normally Safe In Daylight', 'Link', 'User2', 'Characteristic', 	'CycleAttribute.NormallySafeInDaylight', '0x00010000',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	113	, 'Normally Safe At Night', 'Link', 'User2', 'Characteristic', 	'CycleAttribute.NormallySafeAtNight', '0x00020000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	114	, 'Incidents Have Occured In Area', 'Link', 'User2', 'Characteristic', 	'CycleAttribute.IncidentsHave OccuredInArea', '0x00040000',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	115	, 'Frequently Policed Urban Area', 'Link', 'User2', 'Characteristic', 	'CycleAttribute.FrequentlyPolicedUrbanArea', '0x00080000',	0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	116 , 'Steps', 'Link', 'User2', 'Type', 	            		'CycleAttribute.Steps',                   '0x00100000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	117	, 'Channel alongside steps', 'Link', 'User2', 'Type', 		'CycleAttribute.Channelalongsidesteps',   '0x00200000',		0, 0, 1 )
INSERT INTO [CycleAttribute] VALUES ( 	118	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x00400000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	119	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x00800000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	120	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x01000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	121	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x02000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	122	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x04000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	123	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x08000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	124	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x10000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	125	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x20000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	126	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x40000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	127	, 'Unused', 'Link', 'User2', 'None', 	            		'CycleAttribute.Unused',                  '0x80000000',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	128 , 'Turn Restriction', 'Node', 'ITN', 'Type', 	    		'CycleAttribute.TurnRestriction',         '0x00000001',		0, 0, 0 )
INSERT INTO [CycleAttribute] VALUES ( 	129	, 'Mini Roundabout', 'Node', 'ITN', 'Type', 	    		'CycleAttribute.MiniRoundabout',          '0x00000002',		0, 0, 1 )

END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1170
SET @ScriptDesc = 'Script to update the CycleAttribute table data'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO