-- ***********************************************
-- NAME 		: DUP1286_ZPBO_DataSets_2.sql
-- DESCRIPTION 	: Script to add ZPBO data sets
-- AUTHOR		: Mitesh Modi
-- DATE			: 09 Feb 2009
-- ************************************************


USE [PermanentPortal]
GO

-- The following new datasets are added for ZPBO
--     FareTerminalZoneNLC
--     FareTravelcardZoneNLC
--     FareUndergroundZoneNLC
--	   FareTravelcardTicketTypes

-- This is done by specifying the dataset names,
-- and defining the storedprocedure properties to retrieve the datasets

-- Specify dataset names
IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'FareTerminalZoneNLC')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('FareTerminalZoneNLC', 0)     
   
    END

IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'FareTravelcardZoneNLC')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('FareTravelcardZoneNLC', 0)     
   
    END

IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'FareUndergroundZoneNLC')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('FareUndergroundZoneNLC', 0)     
   
    END

IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'FareTravelcardTicketTypes')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('FareTravelcardTicketTypes', 0)     
   
    END


-- Define the Properties to get the dataset values - DataServices, UserPortal
IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC%' 
										  AND AID like 'DataServices')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.query', 
            'SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareTerminalZoneNLC'' ORDER BY NLC', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.type', '2', 'DataServices', 'UserPortal', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC%'
										  AND AID like 'DataServices')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.query', 
            'SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareTravelcardZoneNLC'' ORDER BY NLC', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.type', '2', 'DataServices', 'UserPortal', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC%'
										  AND AID like 'DataServices')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.query', 
            'SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareUndergroundZoneNLC'' ORDER BY NLC',
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.type', '2', 'DataServices', 'UserPortal', 0, 1)

    END


IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes%'
										  AND AID like 'DataServices')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.db', 'TransientPortalDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.query', 
            'SELECT TicketTypeCode, TicketTypeGroup FROM TicketTypeGroup', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.type', '2', 'DataServices', 'UserPortal', 0, 1)

    END




-- Define the Properties to get the dataset values - TDRemotingHost, TDRemotingHost
IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC%' 
										  AND AID like 'TDRemotingHost')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.db', 'DefaultDB', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.query', 
            'SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareTerminalZoneNLC'' ORDER BY NLC', 
            'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.type', '2', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC%'
										  AND AID like 'TDRemotingHost')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.db', 'DefaultDB', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.query', 
            'SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareTravelcardZoneNLC'' ORDER BY NLC', 
            'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.type', '2', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC%'
										  AND AID like 'TDRemotingHost')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.db', 'DefaultDB', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.query', 
            'SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareUndergroundZoneNLC'' ORDER BY NLC',
            'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.type', '2', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

    END


IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes%'
										  AND AID like 'TDRemotingHost')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.db', 'TransientPortalDB', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.query', 
            'SELECT TicketTypeCode, TicketTypeGroup FROM TicketTypeGroup', 
            'TDRemotingHost', 'TDRemotingHost', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.type', '2', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

    END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1286
SET @ScriptDesc = 'Datasets for use by ZPBO'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO