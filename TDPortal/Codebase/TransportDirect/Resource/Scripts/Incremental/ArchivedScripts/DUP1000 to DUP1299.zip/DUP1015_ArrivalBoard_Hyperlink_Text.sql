-- *************************************************************************************
-- NAME 		: DUP1015_ArrivalBoard_Hyperlink_Text.sql
-- DESCRIPTION  : Arrival board hyperlink text
-- AUTHOR		: Amit Patel
-- *************************************************************************************



USE [Content]
GO

-------------------------------------------------------------
-- Accessibility Content
-------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings','ArrivalsBoardHyperlink.labelArrivalsBoardNavigation','Arrivals board','Bwrdd cyrraedd' 

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1015
SET @ScriptDesc = 'Arrival board hyperlink text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
