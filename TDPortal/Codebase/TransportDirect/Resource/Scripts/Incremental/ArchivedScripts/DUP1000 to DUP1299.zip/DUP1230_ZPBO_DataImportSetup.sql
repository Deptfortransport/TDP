-- ***********************************************
-- NAME 			: DUP1230_ZPBO_DataImportSetup.sql
-- DESCRIPTION 		: Script to set up the ZPBO Data Import 
-- AUTHOR			: Mitesh Modi
-- DATE				: 22 Dec 2008
-- ************************************************

USE [PermanentPortal]
GO

-- ************************************************
-- FOR PRODUCTION ENVIRONMENTS:
-- 		Update the IMPORT_CONFIGURATION feed location
--		Update the FTP_CONFIGURATION feed location
-- ************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- PROPERTIES
--------------------------------------------------------------------------------------------------------------------------------

-- Check if we've already inserted
IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName LIKE '%datagateway.retailbusinessobjects.zpbofeedname%')
BEGIN

	INSERT INTO properties VALUES ('datagateway.retailbusinessobjects.zpbofeedname', 'fge461', '', 'DataGateway', 0, 1)

END

-------------------------------------------------------------------------
-- IMPORT_CONFIGURATION
-------------------------------------------------------------------------

-- Delete
IF EXISTS(SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'fge461')
  BEGIN
    DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'fge461'
  END

-- Insert
INSERT INTO IMPORT_CONFIGURATION(DATA_FEED, IMPORT_CLASS, CLASS_ARCHIVE, IMPORT_UTILITY, PARAMETERS1, PARAMETERS2, PROCESSING_DIR)
VALUES ('fge461','TransportDirect.UserPortal.RetailBusinessObjects.RBOImportTask','C:/Gateway/bin/td.userportal.retailbusiness.dll',''
,'dljc.dat' ,'' ,'C:/Gateway/dat/Processing/fge461')

GO


-------------------------------------------------------------------------
-- FTP_CONFIGURATION
-------------------------------------------------------------------------

-- Delete
IF EXISTS (SELECT * FROM [dbo].[FTP_CONFIGURATION] WHERE [DATA_FEED] = 'fge461')
  BEGIN
	DELETE FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'fge461'
  END

-- Insert
INSERT INTO [dbo].[ftp_configuration](ftp_client, data_feed, ip_address, username, [password], local_dir,
     								  remote_dir, filename_filter, missing_feed_counter, missing_feed_threshold, 
									  data_feed_datetime, data_feed_filename, remove_files)
VALUES (1, 'fge461', '127.0.0.1', 'TDP28Nov', 'sI1732#3-', 'C:/Gateway/dat/Incoming/fge461', 
		'../fge461', '*.zip', 0, 1, 
		'01/01/2003', '', 1)

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1230
SET @ScriptDesc = 'ZPBO Data Import'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO