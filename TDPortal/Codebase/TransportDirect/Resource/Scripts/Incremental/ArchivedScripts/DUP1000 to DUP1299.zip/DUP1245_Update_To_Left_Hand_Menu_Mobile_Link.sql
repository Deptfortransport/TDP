-- ***********************************************
-- NAME 		: DUP1245_Update_To_Left_Hand_Menu_Mobile_Link.sql
-- DESCRIPTION 		: Update to left hand menu Mobile/PDA link
-- AUTHOR		: Amit Patel
-- DATE			: 23 January 2008
-- ************************************************

USE [TransientPortal]
GO

DECLARE @ResourceNameId INT

SELECT @ResourceNameId = ResourceNameId FROM ResourceName WHERE ResourceName='MobileDemonstrator'

-- updating english resource text
UPDATE Resource SET [Text]='Mobile/PDA' WHERE ResourceNameId = @ResourceNameId and Culture = 'en-GB'

-- updating welsh resource text
UPDATE Resource SET [Text]='Dolennau cysylltiedig' WHERE ResourceNameId = @ResourceNameId and Culture = 'cy-GB'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1245
SET @ScriptDesc = 'Update to left hand menu Mobile/PDA link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO