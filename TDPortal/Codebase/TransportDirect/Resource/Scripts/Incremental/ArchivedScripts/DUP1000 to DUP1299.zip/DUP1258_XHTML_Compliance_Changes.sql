-- ***********************************************
-- NAME 		: DUP1258_XHTML_Compliance_Changes.sql
-- DESCRIPTION 		: Update content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 21 January 2008
-- ************************************************

USE [Content]
GO

-- help content for travel news page
EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelTravelNewsNonMap',
'<p>To tailor the Live travel news (e.g. to your region, types of transport, date, etc.):<br/><br/>    1.    Select a region from the drop-down lists or the map and select other options from the drop-down lists.<br/>    2.    Click "OK"<br/><br/>The information is automatically sorted by "Severity" so that the most severe incidents appear at the top of the page.<br/><br/>You can also view these details on a map by clicking "Show on map".  In order to do this however, you need to select a region from the drop-down list before clicking the button.<br/><br/></p>',
'<p>I deilwrio''r newyddion teithio Byw (e.e. i''ch rhanbarth, mathau o gludiant, dyddiad, ac ati):<br/><br/>    1.    Dewiswch ranbarth o''r rhestrau a ollyngir i lawr neu''r map a dewiswch opsiynau eraill o''r rhestrau a ollyngir i lawr.<br/>    2.    Cliciwch ''Iawn''.<br/><br/>Mae''r wybodaeth yn cael ei didoli yn awtomatig yn �l ''Difrifoldeb'' fel bod y digwyddiadau mwyaf difrifol yn ymddangos ar frig y dudalen.Gellir hefyd weld y manylion hyn ar fap drwy glicio ''Dangoswch ar y map''.  Ond er mwyn gwneud hyn mae angen i chi ddewis rhanbarth o''r rhestr a ollyngir i lawr cyn clicio ar y botwm.<br/><br/></p>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelTravelNews',
'<p>To tailor the Live travel news (e.g. to your region, types of transport, date, etc.):<br/><br/>   1.    Select a region from the drop-down lists or the map and select other options from the drop-down lists.<br/>    2.    Click "OK"<br/><br/>If there are incidents in the regions you view, they will be indicated by symbols on the map.  If you mouse over these symbols, a box containing details of the incident will appear on the page.<br/><br/></p>',
'<p>I deilwrio''r newyddion teithio Byw (e.e. i''ch rhanbarth, mathau o gludiant, dyddiad, ac ati):<br/>    1.    Dewiswch ranbarth o''r rhestrau a ollyngir i lawr neu''r map a dewiswch opsiynau eraill o''r rhestrau a ollyngir i lawr.<br/>    2.    Cliciwch ''Iawn''. <br/><br/>Os oes unrhyw ddigwyddiadau yn y rhanbarthau yr edrychwch arnynt, fe''u nodir � symbolau ar y map.  Os ewch � llygoden dros y symbolau hyn, bydd blwch yn cynnwys manylion y digwyddiad yn ymddangos ar y dudalen.<br/></p>'

GO

-- Feedbackpage.aspx soft content
EXEC AddtblContent
1, 1, 'langStrings', 'FeedbackInitialPage.labelIntroduction.Text'
,'<p style="font-size: 12pt; line-heigt: 1.5;">We welcome comments that will help us to improve the service that we offer.  Please fill in the form below to tell us about:</p> <br/> <ul class="listround">  <li>Errors that you find with the information that we provide</li><li>Technical problems that you experience with the site.</li><li>Your suggestions for future developments</li></ul>  <br/>  <p>Please give us plenty of detail to support your comments.  For journey planning problems tell us the date and time of the journey; the exact start and finish points; the nature of the error, etc.  For technical problems please tell us what Operating System and browser you are using and so forth.</p><p> </p> <br/> <p>All comments are taken forward but we regret that we are unable to offer individual replies.</p><p> </p> <br/> <p><b>NOTE - If you want to know how to do something on this site, try clicking FAQ, or see the overview information on the first page under each part of the site.  Please do not use this form to ask us to search the site</b> </p>'
,'<p style="font-size: 12pt; line-heigt: 1.5;">Rydym yn croesawu sylwadau a fydd yn gymorth i ni wella''r gwasanaeth a gynigiwn. Llenwch y ffurflen isod i ddweud wrthym ynglyn �:</p> <br/> <ul class="listround"><li>Gwallau a welsoch gyda''r wybodaeth a ddarparwn</li><li>Problemau technegol a gawsoch gyda''r safle</li><li>Eich awgrymiadau am ddatblygiadau yn y dyfodol</li></ul> <br/> <p>Rhowch ddigon o fanylion i ni er mwyn cefnogi eich sylwadau. Am broblemau wrth gynllunio siwrneion dywedwch wrthym beth yw dyddiad ac amser y siwrnai; yr union fannau cychwyn a gorffen; natur y gwall ayb. Ar gyfer problemau technegol, dywedwch wrthym ba System Weithredu a phorwr rydych chi''n eu defnyddio ac ati.</p><p> </p> <br/> <p>Mae pob sylw yn cael ystyriaeth ond ni allwn gynnig atebion unigol yn anffodus. </p><p> </p> <br/> <p><b>SYLWER - Os hoffech wybod sut i wneud rhywbeth ar y safle hwn, beth am glicio Cwestiynau a Ofynnir yn Aml (COA), neu ewch i''r tudalennau "Gorolwg" o dan bob rhan o''r safle. Peidiwch � defnyddio''r ffurflen hon i ofyn i ni chwi</b> </p>'

GO

-- FindFareStep control image urls

-- FindFareStep1
EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep1.Image.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step one grey.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step one grey.gif'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep1.Image.Active.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step one blue.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step one blue.gif'

-- FindFareStep2
EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep2.Image.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step two grey.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step two grey.gif'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep2.Image.Active.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step two blue.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step two blue.gif'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep2.Image.Grey.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step two grey_with grey arrow.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step two grey_with grey arrow.gif'


-- FindFareStep3
EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep3.Image.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step three grey.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step three grey.gif'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep3.Image.Active.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step three blue.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step three blue.gif'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep3.Image.Blue.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step three grey_with blue arrow.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step three grey_with blue arrow.gif'

-- FindFareStep4
EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep4.Image.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step four grey.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step four grey.gif'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep4.Image.Active.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step four blue.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step four blue.gif'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareStepsControl.FindFareStep4.Image.Blue.URL'
,'/Web/images/gifs/JourneyPlanning/en/Step four grey_with blue arrow.gif'
,'/Web/images/gifs/JourneyPlanning/en/Step four grey_with blue arrow.gif'

GO


-- AdjustFullItinerarySummary.aspx page help content
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpAdjustFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by altering the time allowed at a certain point of your original journey plan.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey was from London to Beccles and involved changing trains three times. At Ipswich, the recommended change interval was 10 minutes but you wanted to allow more time as you knew you would have heavy luggage with you.</li>
<li>You altered the overall journey by choosing to see the next service leaving from Ipswich.</li>
<li>Transport Direct found the next journey combination which gives you the required additional time in Ipswich.</li></ul></div></div>
<br/><p></p>
<p>This page gives a summarised view of the whole end-to-end journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the entire journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<h3>Would you like to adjust this journey again?</h3><br/><br/>
<p>Transport Direct allows you to keep making this kind of adjustment to your overall journey as many times as you wish.</p><br/>
<p>If your overall journey is made up of an outward and return journey, then you must first choose which journey direction to work on. Choose from the options in the drop down menu then press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy newid yr amser a ganiateir mewn un pwynt arbennig yng nghynllun eich siwrnai wreiddiol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd eich siwrnai wreiddiol o Lundain i Beccles ac roedd yn golygu newid trenau dair gwaith. Yn Ipswich, yr amser a argymhellwyd ar gyfer y newid oedd 10 munud ond roeddech am gael mwy o amser oherwydd roeddech yn gwybod y byddai gennych gesys trwm gyda chi.</li>
<li>Bu i chi newid y siwrnai gyffredinol drwy ddewis gweld y gwasanaeth nesaf yn gadael o Ipswich.</li>
<li>Canfu Transport Direct y cyfuniad nesaf ar gyfer y siwrnai sy''n rhoi''r amser ychwanegol angenrheidiol i chi yn Ipswich.</li></ul></div></div>
<br/><p></p>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyfan o un pen i''r llall. Mae''n dangos yr holl fathau o gludiant fydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai gyfan ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<h3>Hoffech chi addasu''r siwrnai hon eto?</h3><br/><br/>
<p>Mae Transport Direct yn caniat�u i chi ddal ati i wneud y math hwn o addasiad i''ch siwrnai gyffredinol cymaint o weithiau ag y dymunwch.</p><br/>
<p>Os yw eich siwrnai gyffredinol yn cynnwys siwrnai yn �l ac ymlaen, yna rhaid i chi yn gyntaf ddewis pa gyfeiriad o''r siwrnai i weithio arno. Dewiswch o''r dewisiadau yn y ddewislen a ollyngir i lawr yna gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpAdjustFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by altering the time allowed at a certain point of your original journey plan.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey was from London to Beccles and involved changing trains three times. At Ipswich, the recommended change interval was 10 minutes but you wanted to allow more time as you knew you would have heavy luggage with you.</li>
<li>You altered the overall journey by choosing to see the next service leaving from Ipswich.</li>
<li>Transport Direct found the next journey combination which gives you the required additional time in Ipswich.</li></ul></div></div>
<br/><p></p>
<p>This page gives a summarised view of the whole end-to-end journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the entire journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<h3>Would you like to adjust this journey again?</h3><br/><br/>
<p>Transport Direct allows you to keep making this kind of adjustment to your overall journey as many times as you wish.</p><br/>
<p>If your overall journey is made up of an outward and return journey, then you must first choose which journey direction to work on. Choose from the options in the drop down menu then press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy newid yr amser a ganiateir mewn un pwynt arbennig yng nghynllun eich siwrnai wreiddiol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd eich siwrnai wreiddiol o Lundain i Beccles ac roedd yn golygu newid trenau dair gwaith. Yn Ipswich, yr amser a argymhellwyd ar gyfer y newid oedd 10 munud ond roeddech am gael mwy o amser oherwydd roeddech yn gwybod y byddai gennych gesys trwm gyda chi.</li>
<li>Bu i chi newid y siwrnai gyffredinol drwy ddewis gweld y gwasanaeth nesaf yn gadael o Ipswich.</li>
<li>Canfu Transport Direct y cyfuniad nesaf ar gyfer y siwrnai sy''n rhoi''r amser ychwanegol angenrheidiol i chi yn Ipswich.</li></ul></div></div>
<br/><p></p>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyfan o un pen i''r llall. Mae''n dangos yr holl fathau o gludiant fydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai gyfan ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<h3>Hoffech chi addasu''r siwrnai hon eto?</h3><br/><br/>
<p>Mae Transport Direct yn caniat�u i chi ddal ati i wneud y math hwn o addasiad i''ch siwrnai gyffredinol cymaint o weithiau ag y dymunwch.</p><br/>
<p>Os yw eich siwrnai gyffredinol yn cynnwys siwrnai yn �l ac ymlaen, yna rhaid i chi yn gyntaf ddewis pa gyfeiriad o''r siwrnai i weithio arno. Dewiswch o''r dewisiadau yn y ddewislen a ollyngir i lawr yna gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpAdjustFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by altering the time allowed at a certain point of your original journey plan.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey was from London to Beccles and involved changing trains three times. At Ipswich, the recommended change interval was 10 minutes but you wanted to allow more time as you knew you would have heavy luggage with you.</li>
<li>You altered the overall journey by choosing to see the next service leaving from Ipswich.</li>
<li>Transport Direct found the next journey combination which gives you the required additional time in Ipswich.</li></ul></div></div>
<br/><p></p>
<p>This page gives a summarised view of the whole end-to-end journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the entire journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<h3>Would you like to adjust this journey again?</h3><br/><br/>
<p>Transport Direct allows you to keep making this kind of adjustment to your overall journey as many times as you wish.</p><br/>
<p>If your overall journey is made up of an outward and return journey, then you must first choose which journey direction to work on. Choose from the options in the drop down menu then press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy newid yr amser a ganiateir mewn un pwynt arbennig yng nghynllun eich siwrnai wreiddiol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd eich siwrnai wreiddiol o Lundain i Beccles ac roedd yn golygu newid trenau dair gwaith. Yn Ipswich, yr amser a argymhellwyd ar gyfer y newid oedd 10 munud ond roeddech am gael mwy o amser oherwydd roeddech yn gwybod y byddai gennych gesys trwm gyda chi.</li>
<li>Bu i chi newid y siwrnai gyffredinol drwy ddewis gweld y gwasanaeth nesaf yn gadael o Ipswich.</li>
<li>Canfu Transport Direct y cyfuniad nesaf ar gyfer y siwrnai sy''n rhoi''r amser ychwanegol angenrheidiol i chi yn Ipswich.</li></ul></div></div>
<br/><p></p>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyfan o un pen i''r llall. Mae''n dangos yr holl fathau o gludiant fydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai gyfan ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<h3>Hoffech chi addasu''r siwrnai hon eto?</h3><br/><br/>
<p>Mae Transport Direct yn caniat�u i chi ddal ati i wneud y math hwn o addasiad i''ch siwrnai gyffredinol cymaint o weithiau ag y dymunwch.</p><br/>
<p>Os yw eich siwrnai gyffredinol yn cynnwys siwrnai yn �l ac ymlaen, yna rhaid i chi yn gyntaf ddewis pa gyfeiriad o''r siwrnai i weithio arno. Dewiswch o''r dewisiadau yn y ddewislen a ollyngir i lawr yna gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p>'

GO

-- FindFareTicket Selection page soft content
EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareTicketSelectionHelpLabel'
,'<p>To view what journeys the fares listed apply to:<br/>���1. Select a fare <br/>���2. Click ''Next''<br/>If you chose to make your journey dates flexible, you will be able to view other dates that you might want to travel on, by clicking ''Previous day'' or ''Next day''.</p>'
,'<p>I weld pa siwrneion y mae''r tocynnau a restrwyd yn berthnasol ar eu cyfer:<br/>���1. Dewiswch docyn<br/>���2. Cliciwch "Nesaf"<br/>Os dewiswch wneud dyddiadau eich siwrnai yn hyblyg, byddwch yn gallu gweld dyddiau eraill y gallech fod yn dymuno teithio arnynt, drwy glicio "Diwrnod blaenorol" neu "Diwrnod nesaf"</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindFareTicketSelection'
,'<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">This page also displays:</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US">Flexibility</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">The ''Flexibility'' column indicates whether a ticket is flexible or not.<span style="mso-spacerun: yes">&nbsp; </span>Tickets are listed as either ''No'', ''Part'' or ''Full''.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol; ">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">No Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"> </span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial; ">You can buy these types of tickets in advance for specified journeys.<span>&nbsp; </span>They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol; ">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Part Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial; ">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">You can buy these tickets anytime, but travel is restricted to avoid certain times.<b><span>&nbsp; </span></b></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Full Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"><span>&nbsp; </span></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Expected availability</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">The ''Expected availability'' column indicates whether the ticket is likely to be available or not.<span>&nbsp; </span>This information is indicative only at this stage.<span>&nbsp; </span>When you select a specific fare we will check the current availability.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">''Low'' means that the ticket is not likely to be available</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">''Medium'' means that the ticket is likely to be available</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-FAMILY: Symbol">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US">''High'' means that the ticket is very likely to be available.</span></p>
<p>&nbsp;</p>'
,'<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae''r dudalen hon hefyd yn arddangos:</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US">Hyblygrwydd</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae colofn ''Hyblygrwydd'' yn nodi a yw tocyn yn hyblyg ai peidio.<span>&nbsp; </span>Rhestrir tocynnau fel naill ai ''Nac ydynt'', ''Rhannol'' neu ''Llawn''.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Dim Hyblygrwydd</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer siwrneion penodol.<span>&nbsp; </span>Maent ar gael fel arfer mewn niferoedd cyfyngedig, ar adegau penodol ac ar wasanaethau penodol.<span>&nbsp; </span>Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf ddiwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, nifer o ddyddiau ymlaen llaw), mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Hyblygrwydd Rhannol</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi rhai adegau arbennig.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Hyblygrwydd Llawn</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"> </span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod y maent yn ddilys.<span>&nbsp; </span>Mae''r rhain yn cynnwys tocynnau agored a rhai tocynnau Dydd.<span>&nbsp; </span>Maent yn aml yn dda i weithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft, yr awr frys.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Argaeledd disgwyliedig</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae''r golofn ''Argaeledd disgwyliedig'' yn nodi p''run ai a yw''r tocyn yn debygol o fod ar gael ai peidio.<span>&nbsp; </span>Nid yw''r wybodaeth hon yn bendant ar hyn o bryd.<span>&nbsp; </span>Pan ddewiswch docyn penodol byddwn yn gwirio a yw ar gael ar y pryd.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Isel'' yn golygu nad yw''r tocyn yn debygol o fod ar gael</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Canolig'' yn golygu fod y tocyn yn debygol o fod ar gael.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Uchel'' yn golygu fod y tocyn yn debygol iawn o fod ar gael.</span></p>
<p class="CcList" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-FAMILY: Arial;">&nbsp;</span></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindFareTicketSelection'
,'<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">This page also displays:</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US">Flexibility</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">The ''Flexibility'' column indicates whether a ticket is flexible or not.<span style="mso-spacerun: yes">&nbsp; </span>Tickets are listed as either ''No'', ''Part'' or ''Full''.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol; ">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">No Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"> </span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial; ">You can buy these types of tickets in advance for specified journeys.<span>&nbsp; </span>They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol; ">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Part Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial; ">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">You can buy these tickets anytime, but travel is restricted to avoid certain times.<b><span>&nbsp; </span></b></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Full Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"><span>&nbsp; </span></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Expected availability</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">The ''Expected availability'' column indicates whether the ticket is likely to be available or not.<span>&nbsp; </span>This information is indicative only at this stage.<span>&nbsp; </span>When you select a specific fare we will check the current availability.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">''Low'' means that the ticket is not likely to be available</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">''Medium'' means that the ticket is likely to be available</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-FAMILY: Symbol">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US">''High'' means that the ticket is very likely to be available.</span></p>
<p>&nbsp;</p>'
,'<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae''r dudalen hon hefyd yn arddangos:</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US">Hyblygrwydd</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae colofn ''Hyblygrwydd'' yn nodi a yw tocyn yn hyblyg ai peidio.<span>&nbsp; </span>Rhestrir tocynnau fel naill ai ''Nac ydynt'', ''Rhannol'' neu ''Llawn''.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Dim Hyblygrwydd</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer siwrneion penodol.<span>&nbsp; </span>Maent ar gael fel arfer mewn niferoedd cyfyngedig, ar adegau penodol ac ar wasanaethau penodol.<span>&nbsp; </span>Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf ddiwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, nifer o ddyddiau ymlaen llaw), mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Hyblygrwydd Rhannol</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi rhai adegau arbennig.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Hyblygrwydd Llawn</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"> </span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod y maent yn ddilys.<span>&nbsp; </span>Mae''r rhain yn cynnwys tocynnau agored a rhai tocynnau Dydd.<span>&nbsp; </span>Maent yn aml yn dda i weithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft, yr awr frys.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Argaeledd disgwyliedig</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae''r golofn ''Argaeledd disgwyliedig'' yn nodi p''run ai a yw''r tocyn yn debygol o fod ar gael ai peidio.<span>&nbsp; </span>Nid yw''r wybodaeth hon yn bendant ar hyn o bryd.<span>&nbsp; </span>Pan ddewiswch docyn penodol byddwn yn gwirio a yw ar gael ar y pryd.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Isel'' yn golygu nad yw''r tocyn yn debygol o fod ar gael</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Canolig'' yn golygu fod y tocyn yn debygol o fod ar gael.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Uchel'' yn golygu fod y tocyn yn debygol iawn o fod ar gael.</span></p>
<p class="CcList" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-FAMILY: Arial;">&nbsp;</span></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindFareTicketSelection'
,'<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">This page also displays:</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US">Flexibility</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">The ''Flexibility'' column indicates whether a ticket is flexible or not.<span style="mso-spacerun: yes">&nbsp; </span>Tickets are listed as either ''No'', ''Part'' or ''Full''.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol; ">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">No Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"> </span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial; ">You can buy these types of tickets in advance for specified journeys.<span>&nbsp; </span>They are usually only available in limited numbers, at certain times, and on specific services. If you can plan your journey and buy your ticket at least one day in advance (or for some advance tickets, several days in advance), these tickets are often good value for money.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol; ">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Part Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial; ">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt; "><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">You can buy these tickets anytime, but travel is restricted to avoid certain times.<b><span>&nbsp; </span></b></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Full Flexibility</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"><span>&nbsp; </span></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">You can buy these tickets anytime and travel anytime during the period they are valid. These include Open and some Day tickets. They are often good for business travellers and anyone else who needs to travel at the busiest times, for example, rush hour.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Expected availability</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">The ''Expected availability'' column indicates whether the ticket is likely to be available or not.<span>&nbsp; </span>This information is indicative only at this stage.<span>&nbsp; </span>When you select a specific fare we will check the current availability.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">''Low'' means that the ticket is not likely to be available</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">''Medium'' means that the ticket is likely to be available</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-FAMILY: Symbol">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US">''High'' means that the ticket is very likely to be available.</span></p>
<p>&nbsp;</p>'
,'<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae''r dudalen hon hefyd yn arddangos:</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US">Hyblygrwydd</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae colofn ''Hyblygrwydd'' yn nodi a yw tocyn yn hyblyg ai peidio.<span>&nbsp; </span>Rhestrir tocynnau fel naill ai ''Nac ydynt'', ''Rhannol'' neu ''Llawn''.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Dim Hyblygrwydd</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Gallwch brynu''r mathau hyn o docynnau ymlaen llaw ar gyfer siwrneion penodol.<span>&nbsp; </span>Maent ar gael fel arfer mewn niferoedd cyfyngedig, ar adegau penodol ac ar wasanaethau penodol.<span>&nbsp; </span>Os gallwch gynllunio eich siwrnai a phrynu eich tocyn o leiaf ddiwrnod ymlaen llaw (neu ar gyfer rhai tocynnau ymlaen llaw, nifer o ddyddiau ymlaen llaw), mae''r tocynnau hyn yn aml yn rhoi gwerth da am arian.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Hyblygrwydd Rhannol</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"></span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Gallwch brynu''r tocynnau hyn unrhyw bryd, ond cyfyngir teithio i osgoi rhai adegau arbennig.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 18pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Hyblygrwydd Llawn</span></b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;"> </span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Gallwch brynu''r tocynnau hyn unrhyw bryd a theithio unrhyw bryd yn ystod y cyfnod y maent yn ddilys.<span>&nbsp; </span>Mae''r rhain yn cynnwys tocynnau agored a rhai tocynnau Dydd.<span>&nbsp; </span>Maent yn aml yn dda i weithwyr busnes ac unrhyw un arall sydd angen teithio ar yr adegau prysuraf, er enghraifft, yr awr frys.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><b><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Argaeledd disgwyliedig</span></b></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">&nbsp;</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">Mae''r golofn ''Argaeledd disgwyliedig'' yn nodi p''run ai a yw''r tocyn yn debygol o fod ar gael ai peidio.<span>&nbsp; </span>Nid yw''r wybodaeth hon yn bendant ar hyn o bryd.<span>&nbsp; </span>Pan ddewiswch docyn penodol byddwn yn gwirio a yw ar gael ar y pryd.</span></p>
<p class="MsoBodyText2" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Isel'' yn golygu nad yw''r tocyn yn debygol o fod ar gael</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Canolig'' yn golygu fod y tocyn yn debygol o fod ar gael.</span></p>
<p class="MsoNormal" style="MARGIN: 0cm 0cm 0pt 72pt; TEXT-INDENT: -18pt;"><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Symbol;">�<span style="FONT: 7pt">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span><span lang="EN-US" style="FONT-SIZE: 10pt; FONT-FAMILY: Arial;">Mae ''Uchel'' yn golygu fod y tocyn yn debygol iawn o fod ar gael.</span></p>
<p class="CcList" style="MARGIN: 0cm 0cm 0pt"><span lang="EN-US" style="FONT-FAMILY: Arial;">&nbsp;</span></p>'


GO

-- FindFareDate Selection page soft content
EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareDateSelection.ReturnSinglesNote'
,'Notes:<br />�  Some fares shown may be a combination of two single fares.<br />�  Availability is not guaranteed at this stage.<br />�  "*" means that all the fares for that date are unlikely to be available.'
,'Nodiadau:<br />�  Gall rhai tocynnau fod yn gyfuniad o ddau docyn sengl.<br />�   Ni ellir gwarantu fod y tocynnau ar gael ar hyn o bryd.<br />� Mae "*" yn golygu bod yr holl docynnau ar gyfer y cyfuniad o ddyddiad hwnnw yn annhebyg o fod ar gael.'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareDateSelection.SingleNote'
,'Notes:<br />� Availability is not guaranteed at this stage.<br />� "*" means that all the fares for that date are unlikely to be available.'
,'Nodiadau:<br />� Ni ellir gwarantu fod y tocynnau ar gael ar hyn o bryd.<br />� Mae "*" yn golygu bod yr holl docynnau ar gyfer y cyfuniad o ddyddiad hwnnw yn annhebyg o fod ar gael.'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareDateSelectionHelpLabel'
,'<p>To view more information about fares such as ticket types, expected availability, etc.:<br />&nbsp;&nbsp;&nbsp;1. Select a date and type of transport<br />&nbsp;&nbsp;&nbsp;2. Click ''Next''<br /><br />To sort the information in the columns either:<br /> � Click on the arrow next to the column being sorted to reverse the order of that column<br /> � Click on an underlined column header to sort that column<br /><br /></p>'
,'<p>I weld mwy o wybodaeth am docynnau fel math o docyn, argaeledd disgwyliedig ac ati:<br />&nbsp;&nbsp;&nbsp;1. Dewiswch ddyddiad a math o gludiant<br />&nbsp;&nbsp;&nbsp;2. Cliciwch ''Nesaf''<br /><br />I ddidoli''r wybodaeth yn y colofnau naill ai:<br /> � Cliciwch ar y saeth ger y golofn sy''n cael ei didoli i wyrdroi trefn y golofn honno<br /> � Cliciwch ar bennawd colofn sydd wedi ei danlinellu i ddidoli''r golofn honno<br /><br /></p>'


-- JourneyReplanInputPage title change
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyReplanInputPage.labelReplanInputTitle'
,'Replace journey leg'
,'Cynnwys rhan newydd yn y daith'


GO
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1258
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO