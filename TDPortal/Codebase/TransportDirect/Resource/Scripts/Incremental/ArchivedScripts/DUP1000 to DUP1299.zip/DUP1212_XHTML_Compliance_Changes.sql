-- ***********************************************
-- NAME 		: DUP1212_XHTML_Compliance_Changes.sql
-- DESCRIPTION 		: Update content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 15 December 2008
-- ************************************************

USE [Content]
GO

-- help page for park and ride input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpPlanToParkAndRide'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p dir="ltr">&nbsp;</p>
<h5 dir="ltr">2. Select the type of location</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li></ul>
<p>&nbsp;</p>
<h5>3. Select the Park and Ride location</h5>
<p>The drop-down list contains all of the known locations which offer a Park and Ride scheme.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year<br/>or</li>
<li>Click the calendar and select a date from it</li>
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination </li>
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the locationor<br/>� Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by </li>
<li>Select the hours from the ''drop-down'' list </li>
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<h3 dir="ltr">Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Car journey details</h4>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the Journey Planner will select the best driving route. Select:</p>
<ul>
<li>
<div>''Quickest'' if you would like a route with the shortest driving time</div></li>
<li>
<div>''Shortest'' if you would like a route with the shortest distance</div></li>
<li>
<div>''Most fuel economic'' if you would like a route with the lowest fuel consumption</div></li>
<li>
<div>''Cheapest overall'' if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
, '<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enw''r lleoliad yn y blwch</h5>
<p>&nbsp;</p>
<p>Mae''n well os gallwch deipio enw''r lleoliad yn llawn fel eich bod yn cael cyn lleied � phosib o gyfatebiaethau tebyg yn cael eu dychwelyd atoch.&nbsp; Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn siwr sut i sillafu enw lleoliad, gallwch dicio''r blwch "Ansicr o''r sillafiad" fel y bydd y Cynlluniwr Siwrnai yn chwilio hefyd am leoliadau sy''n swnio''n debyg i''r un a deipiwch.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag yr ydych yn gwybod a rhowch seren * ar �l y llythrennau.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliad</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn dweud wrth y Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad �. ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond eich bod yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>"Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,e.e. �Manceinion�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�.</div></li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch leoliad y parcio a theithio</h5>
<p>Mae''r rhestr a ollyngir i lawr yn cynnwys yr holl leoliadau y gwyddom sy''n cynnig cynllun Parcio a Theithio.</p></blockquote>
<h3>Dewis dyddiadau siwrneion allan a dychwel </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5></blockquote>
<blockquote>
<ul>
<li>Dewiswch ddiwrnod o''r rhestr "Gadael ar", yna dewiswch fis/blwyddyn<br/>neu</li> 
<li>Cliciwch ar y calendr a dewiswch ddyddiad ohono</li>
<li>Os ydych yn cynllunio siwrnai unffordd yn unig, gadewch "Dim dychwelyd" yn y rhestr a ollyngir i lawr o fisoedd/blwyddyn "Dychwelyd ar".</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Gallwch ddewis yr amser y dymunwch adael y lleoliad neu''r amser y dymunwch gyrraedd y gyrchfan</li>
<li>Dewiswch <strong>''Yn gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad neu</li>
<li>Dewiswch <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd erbyn</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li>
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00pm = 17:00)</li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4 dir="ltr">Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch:</p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf </div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf </div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol" os hoffech y llwybr rhataf sy''n cymryd pob agwedd o''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr.&nbsp; Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig.&nbsp; Gallwch ddewis o blith y canlynol:</p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd''<br/></div></li>
<li>
<div>''60 m.y.a.''&nbsp;<br/></div></li>
<li>
<div>''50 m.y.a.''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 m.y.a.''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Ticiwch y blwch os byddai''n well gennych beidio � gyrru ar draffyrdd.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl.</p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartalog ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km.</p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau ar ran siwrneion&nbsp; </h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>I osgoi ffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai.&nbsp;&nbsp; Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r dudalen, cliciwch "Nesaf.</h3>'
GO


-- printer friendly help page for park and ride input page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpPlanToParkAndRide'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Select the type of location</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li></ul>
<p>&nbsp;</p>
<h5>3. Select the Park and Ride location</h5>
<p>The drop-down list contains all of the known locations which offer a Park and Ride scheme.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year<br/>or</li>
<li>Click the calendar and select a date from it</li> 
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the locationor<br/>� Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li> 
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Car journey details</h4>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the Journey Planner will select the best driving route. Select:</p>
<ul>
<li>
<div>''Quickest'' if you would like a route with the shortest driving time</div></li>
<li>
<div>''Shortest'' if you would like a route with the shortest distance</div></li>
<li>
<div>''Most fuel economic'' if you would like a route with the lowest fuel consumption</div></li>
<li>
<div>''Cheapest overall'' if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enw''r lleoliad yn y blwch</h5>
<p>&nbsp;</p>
<p>Mae''n well os gallwch deipio enw''r lleoliad yn llawn fel eich bod yn cael cyn lleied � phosib o gyfatebiaethau tebyg yn cael eu dychwelyd atoch.&nbsp; Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn siwr sut i sillafu enw lleoliad, gallwch dicio''r blwch "Ansicr o''r sillafiad" fel y bydd y Cynlluniwr Siwrnai yn chwilio hefyd am leoliadau sy''n swnio''n debyg i''r un a deipiwch.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag yr ydych yn gwybod a rhowch seren * ar �l y llythrennau.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliad</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn dweud wrth y Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad �. ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond eich bod yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>"Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,e.e. �Manceinion�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�.</div></li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch leoliad y parcio a theithio</h5>
<p>Mae''r rhestr a ollyngir i lawr yn cynnwys yr holl leoliadau y gwyddom sy''n cynnig cynllun Parcio a Theithio.</p></blockquote>
<h3>Dewis dyddiadau siwrneion allan a dychwel </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5></blockquote>
<blockquote>
<ul>
<li>Dewiswch ddiwrnod o''r rhestr "Gadael ar", yna dewiswch fis/blwyddyn<br/>neu</li> 
<li>Cliciwch ar y calendr a dewiswch ddyddiad ohono</li> 
<li>Os ydych yn cynllunio siwrnai unffordd yn unig, gadewch "Dim dychwelyd" yn y rhestr a ollyngir i lawr o fisoedd/blwyddyn "Dychwelyd ar".</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Gallwch ddewis yr amser y dymunwch adael y lleoliad neu''r amser y dymunwch gyrraedd y gyrchfan</li> 
<li>Dewiswch <strong>''Yn gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad neu</li>
<li>Dewiswch <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd erbyn</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00pm = 17:00)</li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch:</p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf </div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf </div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol" os hoffech y llwybr rhataf sy''n cymryd pob agwedd o''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr.&nbsp; Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig.&nbsp; Gallwch ddewis o blith y canlynol:</p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd''<br/></div></li>
<li>
<div>''60 m.y.a.''&nbsp;<br/></div></li>
<li>
<div>''50 m.y.a.''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 m.y.a.''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Ticiwch y blwch os byddai''n well gennych beidio � gyrru ar draffyrdd.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl.</p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartalog ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km.</p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau ar ran siwrneion&nbsp; </h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>I osgoi ffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai.&nbsp;&nbsp; Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r dudalen, cliciwch "Nesaf.</h3>'

GO

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpPlanToParkAndRide'
,'<h3>Selecting locations to travel from and to</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Type the location names in the boxes</h5>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches''&nbsp; returned to you.&nbsp; Punctuation and use of capital letters are not important.</p>
<p>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Select the type of location</h5>
<p>&nbsp;</p>
<p>This will inform the Journey Planner whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>The categories are described below:</p>
<ul>
<li>
<div><strong>"Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; If you don''t know the postcode include as much of the address as possible.</div></li>
<li>
<div><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�</div></li></ul>
<p>&nbsp;</p>
<h5>3. Select the Park and Ride location</h5>
<p>The drop-down list contains all of the known locations which offer a Park and Ride scheme.</p></blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Select the dates you would like to leave/return on</h5></blockquote>
<blockquote>
<ul>
<li>Select a day from the ''drop-down'' list, then select a month/year<br/>or</li>
<li>Click the calendar and select a date from it</li> 
<li>If you are planning a journey that is only one way, choose ''No return'' in the month/year ''drop-down'' list.</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Choose how you want to specify the times</h5>
<ul>
<li>You have the choice of selecting the time you want to leave the location or the time you want to arrive at the destination</li>
<li>Choose <strong>''Leaving at''</strong> to select the earliest time you want to leave the locationor<br/>� Choose <strong>''Arriving by''</strong> to select the latest time you want to arrive at the destination</li></ul>
<p>&nbsp;</p>
<h5>3. Select the times you would like to travel</h5>
<ul>
<li>Select the time you want to either leave at or arrive by</li>
<li>Select the hours from the ''drop-down'' list</li> 
<li>Select the minutes from the ''drop-down'' list (the Journey Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li></ul></blockquote>
<h3>Advanced options</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Car journey details</h4>
<ul>
<li>
<div><strong>Find (quickest, shortest, most fuel economic or cheapest overall) journeys</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose how the Journey Planner will select the best driving route. Select:</p>
<ul>
<li>
<div>''Quickest'' if you would like a route with the shortest driving time</div></li>
<li>
<div>''Shortest'' if you would like a route with the shortest distance</div></li>
<li>
<div>''Most fuel economic'' if you would like a route with the lowest fuel consumption</div></li>
<li>
<div>''Cheapest overall'' if you would like the cheapest route which takes all aspects of the journey into account.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Speed (maximum driving speed)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose the maximum speed you are willing to drive from the ''drop-down'' list.&nbsp; Journey times will be based on this speed, but will also take into account the legal speed limits on the various roads in the proposed route.&nbsp; You can select from:</p>
<ul>
<li>
<div>''Max. legal speed on all roads''<br/></div></li>
<li>
<div>''60 mph''&nbsp;<br/></div></li>
<li>
<div>''50 mph''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 mph''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Do not use motorways </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Tick the box if you do not want to drive on motorways.</p></blockquote>
<h4>Car details</h4>
<p>Choose the size of your car and whether it is a petrol or diesel engined car.</p>
<p>For fuel consumption you can either select �Average for my type of car� or specify the amount of fuel your car consumes by entering the number of miles per gallon or litres per 100 kilometres.</p>
<p>For fuel cost you can either select the current average cost of fuel or specify the cost you pay per litre.</p>
<h4>Journey options&nbsp; </h4>
<ul>
<li>
<div><strong>Avoid tolls, ferries, motorways</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>If you would prefer your journey to avoid tolls/ ferries/ motorways, tick the boxes and, where possible, the journey planner will avoid them so that they are not included in your journey plan.</p></blockquote>
<ul>
<li>
<div><strong>Avoid roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to avoid when planning your journey.&nbsp;&nbsp; Type in 1 road per box.&nbsp; e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>To use roads</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Type in the numbers of up to 6 roads you would like the Journey Planner to use when planning your journey. Type in 1 road per box. e.g. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Travelling via a location by car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Choose where to travel via by typing in the location and selecting a location type.&nbsp; For more details on how to do this, see ''Selecting locations to travel from and to'' at the beginning of the Help page.&nbsp; You may also use a map to find the location.</p></blockquote></blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
,'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1.&nbsp; Teipiwch enw''r lleoliad yn y blwch</h5>
<p>&nbsp;</p>
<p>Mae''n well os gallwch deipio enw''r lleoliad yn llawn fel eich bod yn cael cyn lleied � phosib o gyfatebiaethau tebyg yn cael eu dychwelyd atoch.&nbsp; Nid yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p>Os nad ydych yn siwr sut i sillafu enw lleoliad, gallwch dicio''r blwch "Ansicr o''r sillafiad" fel y bydd y Cynlluniwr Siwrnai yn chwilio hefyd am leoliadau sy''n swnio''n debyg i''r un a deipiwch.</p>
<p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag yr ydych yn gwybod a rhowch seren * ar �l y llythrennau.&nbsp; </p>
<p>&nbsp;</p>
<h5>2. Dewiswch y math o leoliad</h5>
<p>&nbsp;</p>
<p>Bydd hyn yn dweud wrth y Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad �. ac ati.</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond eich bod yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>Disgrifir y categor�au isod:</p>
<ul>
<li>
<div><strong>"Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF".&nbsp; Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl.</div></li>
<li>
<div><strong>''Tref/rhanbarth/pentref'':</strong> Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,e.e. �Manceinion�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�.</div></li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch leoliad y parcio a theithio</h5>
<p>Mae''r rhestr a ollyngir i lawr yn cynnwys yr holl leoliadau y gwyddom sy''n cynnig cynllun Parcio a Theithio.</p></blockquote>
<h3>Dewis dyddiadau siwrneion allan a dychwel </h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>1. Dewiswch y dyddiadau yr hoffech adael/dychwelyd arnynt</h5></blockquote>
<blockquote>
<ul>
<li>Dewiswch ddiwrnod o''r rhestr "Gadael ar", yna dewiswch fis/blwyddyn<br/>neu</li> 
<li>Cliciwch ar y calendr a dewiswch ddyddiad ohono</li> 
<li>Os ydych yn cynllunio siwrnai unffordd yn unig, gadewch "Dim dychwelyd" yn y rhestr a ollyngir i lawr o fisoedd/blwyddyn "Dychwelyd ar".</li></ul></blockquote>
<blockquote style="MARGIN-RIGHT: 0px">
<h5>2. Dewiswch sut y dymunwch nodi''r amserau</h5>
<ul>
<li>Gallwch ddewis yr amser y dymunwch adael y lleoliad neu''r amser y dymunwch gyrraedd y gyrchfan</li> 
<li>Dewiswch <strong>''Yn gadael am''</strong> i ddewis yr amser cynharaf y dymunwch adael y lleoliad neu</li>
<li>Dewiswch <strong>''Cyrraedd erbyn''</strong> i ddewis yr amser diweddaraf y dymunwch gyrraedd y gyrchfan</li></ul>
<p>&nbsp;</p>
<h5>3. Dewiswch yr amserau yr hoffech deithio</h5>
<ul>
<li>Dewiswch yr amser y dymunwch naill ai adael neu gyrraedd erbyn</li> 
<li>Dewiswch yr oriau o''r rhestr a ollyngir i lawr</li> 
<li>Dewiswch y munudau o''r rhestr a ollyngir i lawr (mae''r Cynlluniwr Siwrnai yn defnyddio cloc 24 awr e.e. 5.00pm = 17:00)</li></ul></blockquote>
<h3>Dewisiadau mwy cymhleth</h3>
<blockquote style="MARGIN-RIGHT: 0px">
<h4>Manylion siwrnai car</h4>
<ul>
<li>
<div><strong>Canfyddwch y siwrneion (cyflymaf, byrraf, y rhai mwyaf economaidd o ran tanwydd, neu rhataf yn gyffredinol)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch sut y bydd y Cynlluniwr Siwrnai yn dewis y llwybr gyrru gorau. Dewiswch:</p>
<ul>
<li>
<div>''Cyflymaf'' os hoffech lwybr gyda''r amser gyrru byrraf </div></li>
<li>
<div>''Byrraf'' os hoffech lwybr gyda''r pellter byrraf </div></li>
<li>
<div>''Mwyaf economaidd o ran tanwydd'' os hoffech lwybr sy''n defnyddio''r lleiaf o danwydd</div></li>
<li>
<div>''Rhataf yn gyffredinol" os hoffech y llwybr rhataf sy''n cymryd pob agwedd o''r siwrnai i ystyriaeth.</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Cyflymder (uchafswm y cyflymder gyrru)</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch y cyflymder uchaf yr ydych yn barod i''w yrru o''r rhestr a ollyngir i lawr.&nbsp; Seilir amseroedd siwrneion ar y cyflymder hwn, ond byddant hefyd yn cymryd i ystyriaeth y ffiniau cyfreithiol ar gyflymder ar y gwahanol ffyrdd yn y llwybr arfaethedig.&nbsp; Gallwch ddewis o blith y canlynol:</p>
<ul>
<li>
<div>''Uchafswm cyflymder cyfreithiol ar bob ffordd''<br/></div></li>
<li>
<div>''60 m.y.a.''&nbsp;<br/></div></li>
<li>
<div>''50 m.y.a.''&nbsp;&nbsp;<br/></div></li>
<li>
<div>''40 m.y.a.''</div></li></ul></blockquote>
<ul>
<li>
<div><strong>Peidiwch � defnyddio traffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Ticiwch y blwch os byddai''n well gennych beidio � gyrru ar draffyrdd.</p></blockquote>
<h4>Manylion y car</h4>
<p>Dewiswch faint eich car a ph''run ai a oes ganddo injan betrol neu dd�sl.</p>
<p>Ar gyfer defnydd o danwydd gallwch ddewis �Cyfartalog ar gyfer fy math i o gar� neu nodwch faint o danwydd y mae eich car yn ei ddefnyddio drwy roi nifer y milltiroedd y galwyn neu litr ar gyfer pob 100km.</p>
<p>Ar gyfer cost tanwydd gallwch naill ai ddewis cost cyfartalog cyfredol y tanwydd neu nodi''r gost a dalwch ar gyfer pob litr.</p>
<h4>Dewisiadau ar ran siwrneion&nbsp; </h4>
<ul>
<li>
<div><strong>Osgoi tollau, ffer�au, traffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Os byddai''n well gennych i''ch siwrnai osgoi tollau / ffer�au / traffyrdd, cliciwch y blychau a lle bo hynny''n bosibl, bydd y Cynlluniwr Siwrnai yn ei osgoi fel nad ydynt yn cael eu cynnwys yng nghynllun eich siwrnai.</p></blockquote>
<ul>
<li>
<div><strong>I osgoi ffyrdd </strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu hosgoi wrth gynllunio eich siwrnai.&nbsp;&nbsp; Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>I ddefnyddio ffyrdd</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Teipiwch rifau hyd at 6 o ffyrdd yr hoffech i''r Cynlluniwr Siwrnai eu defnyddio wrth gynllunio eich siwrnai. Teipiwch 1 ffordd ym mhob blwch e.e. �M1�, �A23�, �B4132�.</p></blockquote>
<ul>
<li>
<div><strong>Teithio drwy leoliad mewn car</strong></div></li></ul>
<blockquote style="MARGIN-RIGHT: 0px">
<p>Dewiswch ble i deithio drwyddo drwy deipio''r lleoliad a dewis math o leoliad.&nbsp; I gael mwy o fanylion am sut i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac iddynt'' ar ddechrau''r dudalen Help.&nbsp; Gallwch hefyd ddefnyddio map i ddod o hyd i''r lleoliad.</p></blockquote></blockquote>
<h3>Wedi i chi gwblhau''r dudalen, cliciwch "Nesaf.</h3>'

GO

-- help page for park and ride scheme page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpParkAndRide'
,'<h3>View park and ride schemes</h3>
<p>&nbsp;</p>
<p>This page displays park and ride schemes across Britain.&nbsp;To view park and ride schemes in specific parts of the country, select a region from the drop-down list and click ''OK''.&nbsp;Alternatively, click on the corresponding region highlighted on the overview map. Please be aware that if you have Javascript disabled in the browser, it will not be possible to select regions on the overview map.&nbsp;In this instance, you should use the drop-down list to choose a region. </p><br/>
<p>To view information specific to a chosen park and ride scheme, click on the "Area" name in the table.&nbsp;This will open an external site with information in a new browser window. </p><br/>
<p>To plan a car journey to the park and ride location, click "Drive to" next to the area to which you would like to travel.&nbsp;This will take you to a new page where you must enter details of the place you''re travelling from.&nbsp;If your chosen destination has more than one park and ride location, Transport Direct will choose a car route to the one which is most suitable for your journey.</p>'
,'<h3>Edrychwch ar gynlluniau parcio a theithio</h3>
<p>&nbsp;</p>
<p>Mae''r dudalen hon yn arddangos cynlluniau ''Parcio a Theithio'' ar draws Prydain.&nbsp; I weld cynlluniau ''Parcio a Theithio'' mewn rhannau penodol o''r wlad, dewiswch ranbarth o''r rhestr a ollyngir i lawr a chliciwch ar ''Iawn''.&nbsp;Neu, cliciwch ar y rhanbarth cyfatebol a amlygir ar y map gorolwg. Cofiwch os bydd JavaScript wedi ei analluogi yn y porwr, ni fydd yn bosibl dewis rhanbarthau ar y map gorolwg. &nbsp;Yn yr enghraifft hon, dylech ddefnyddio''r rhestr a ollyngir i lawr i ddewis rhanbarth. </p><br/>
<p>I weld gwybodaeth am gynllun parcio a theithio penodol, cliciwch ar enw''r "Ardal" yn y tabl.&nbsp;Bydd hwn yn agor safle allanol gyda gwybodaeth mewn ffenestr porwr newydd. </p><br/>
<p>I gynllunio siwrnai car i leoliad y parcio a theithio, cliciwch ar "Gyrrwch i" ger yr ardal yr hoffech deithio iddi.&nbsp;Bydd hyn yn mynd � chi i dudalen newydd ble mae''n rhaid i chi roi manylion am y lle rydych yn teithio ohono.&nbsp;Os oes gan eich cyrchfan ddetholedig fwy nag un lleoliad parcio a theithio, bydd Transport Direct yn dewis llwybr car i''r un sydd fwyaf addas ar gyfer eich siwrnai.</p>'

GO

-- printer friendly help page for park and ride scheme page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpParkAndRide'
,'<h3>View park and ride schemes</h3>
<p>&nbsp;</p>
<p>This page displays park and ride schemes across Britain.&nbsp;To view park and ride schemes in specific parts of the country, select a region from the drop-down list and click ''OK''.&nbsp;Alternatively, click on the corresponding region highlighted on the overview map. Please be aware that if you have Javascript disabled in the browser, it will not be possible to select regions on the overview map.&nbsp;In this instance, you should use the drop-down list to choose a region. </p><br/>
<p>To view information specific to a chosen park and ride scheme, click on the "Area" name in the table.&nbsp;This will open an external site with information in a new browser window. </p><br/>
<p>To plan a car journey to the park and ride location, click "Drive to" next to the area to which you would like to travel.&nbsp;This will take you to a new page where you must enter details of the place you''re travelling from.&nbsp;If your chosen destination has more than one park and ride location, Transport Direct will choose a car route to the one which is most suitable for your journey.</p>'
,'<h3>Edrychwch ar gynlluniau parcio a theithio</h3>
<p>&nbsp;</p>
<p>Mae''r dudalen hon yn arddangos cynlluniau ''Parcio a Theithio'' ar draws Prydain.&nbsp; I weld cynlluniau ''Parcio a Theithio'' mewn rhannau penodol o''r wlad, dewiswch ranbarth o''r rhestr a ollyngir i lawr a chliciwch ar ''Iawn''.&nbsp;Neu, cliciwch ar y rhanbarth cyfatebol a amlygir ar y map gorolwg. Cofiwch os bydd JavaScript wedi ei analluogi yn y porwr, ni fydd yn bosibl dewis rhanbarthau ar y map gorolwg. &nbsp;Yn yr enghraifft hon, dylech ddefnyddio''r rhestr a ollyngir i lawr i ddewis rhanbarth. </p><br/>
<p>I weld gwybodaeth am gynllun parcio a theithio penodol, cliciwch ar enw''r "Ardal" yn y tabl.&nbsp;Bydd hwn yn agor safle allanol gyda gwybodaeth mewn ffenestr porwr newydd. </p><br/>
<p>I gynllunio siwrnai car i leoliad y parcio a theithio, cliciwch ar "Gyrrwch i" ger yr ardal yr hoffech deithio iddi.&nbsp;Bydd hyn yn mynd � chi i dudalen newydd ble mae''n rhaid i chi roi manylion am y lle rydych yn teithio ohono.&nbsp;Os oes gan eich cyrchfan ddetholedig fwy nag un lleoliad parcio a theithio, bydd Transport Direct yn dewis llwybr car i''r un sydd fwyaf addas ar gyfer eich siwrnai.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpParkAndRide'
,'<h3>View park and ride schemes</h3>
<p>&nbsp;</p>
<p>This page displays park and ride schemes across Britain.&nbsp;To view park and ride schemes in specific parts of the country, select a region from the drop-down list and click ''OK''.&nbsp;Alternatively, click on the corresponding region highlighted on the overview map. Please be aware that if you have Javascript disabled in the browser, it will not be possible to select regions on the overview map.&nbsp;In this instance, you should use the drop-down list to choose a region. </p><br/>
<p>To view information specific to a chosen park and ride scheme, click on the "Area" name in the table.&nbsp;This will open an external site with information in a new browser window. </p><br/>
<p>To plan a car journey to the park and ride location, click "Drive to" next to the area to which you would like to travel.&nbsp;This will take you to a new page where you must enter details of the place you''re travelling from.&nbsp;If your chosen destination has more than one park and ride location, Transport Direct will choose a car route to the one which is most suitable for your journey.</p>'
,'<h3>Edrychwch ar gynlluniau parcio a theithio</h3>
<p>&nbsp;</p>
<p>Mae''r dudalen hon yn arddangos cynlluniau ''Parcio a Theithio'' ar draws Prydain.&nbsp; I weld cynlluniau ''Parcio a Theithio'' mewn rhannau penodol o''r wlad, dewiswch ranbarth o''r rhestr a ollyngir i lawr a chliciwch ar ''Iawn''.&nbsp;Neu, cliciwch ar y rhanbarth cyfatebol a amlygir ar y map gorolwg. Cofiwch os bydd JavaScript wedi ei analluogi yn y porwr, ni fydd yn bosibl dewis rhanbarthau ar y map gorolwg. &nbsp;Yn yr enghraifft hon, dylech ddefnyddio''r rhestr a ollyngir i lawr i ddewis rhanbarth. </p><br/>
<p>I weld gwybodaeth am gynllun parcio a theithio penodol, cliciwch ar enw''r "Ardal" yn y tabl.&nbsp;Bydd hwn yn agor safle allanol gyda gwybodaeth mewn ffenestr porwr newydd. </p><br/>
<p>I gynllunio siwrnai car i leoliad y parcio a theithio, cliciwch ar "Gyrrwch i" ger yr ardal yr hoffech deithio iddi.&nbsp;Bydd hyn yn mynd � chi i dudalen newydd ble mae''n rhaid i chi roi manylion am y lle rydych yn teithio ohono.&nbsp;Os oes gan eich cyrchfan ddetholedig fwy nag un lleoliad parcio a theithio, bydd Transport Direct yn dewis llwybr car i''r un sydd fwyaf addas ar gyfer eich siwrnai.</p>'

GO

-- park and ride table summary 
EXEC AddtblContent
1, 1, 'langStrings', 'ParkAndRideTableControl.ParkAndRideTable.Summary'
,'Park and ride schemes for the selected region.'
,'Cynlluniau ''Parcio a Theithio'' ar gyfer y rhanbarth a ddewiswyd.'


-- help page for visit planner results page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpVisitPlannerResults'
,'<p>This page displays the journey options that best match your search.&nbsp; These options are summarised in the table.</p>
<p>&nbsp;</p>
<p>You can select an option from each box to create your journey.</p>
<p>&nbsp;</p>
<p>You can also view the following information about a selected journey option:</p>
<ul>
<li>Details (in a diagram or a table)</li>
<li>Maps</li></ul>
<p>&nbsp;</p>
<p>In order to view this information:</p>
<ol>
<li>Click the buttons next to the options you are interested in</li>
<li>Select the type of information you''d like to see for the selected journey from the drop-down list<br/>- ''Diagram of journey details''<br/>- ''Table of journey details''<br/>- ''Map of journey''<br/>- ''Summary of journey options''<br/></li>
<li>Then click ''Ok''.</li></ol>
<p>These views are described in more detail below:</p>
<p>&nbsp;</p>
<p><strong>Diagram of journey details</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Diagram of journey details'' will display more details for the selected journey in a diagram.</p>
<p>&nbsp;</p>
<p>In the diagram, along with more detail for the individual sections that make up your multi-visit journey, there are links to take you to more information about the individual parts of the journey.&nbsp; If you click on the ''Train'' links you will get more detail about that journey.&nbsp; If you click on the name of a station you will get the available ''Station information''.&nbsp; If you click on ''Map'' you can view maps for various parts of the journey.</p>
<p>&nbsp;</p>
<p><strong>Table of journey details</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Table of journey details'' will display more details for the selected journey in a table.</p>
<p>&nbsp;</p>
<p>In the table, along with more detail for the individual sections that make up your day trip, there are links to take you to more information about the individual parts of the trip.&nbsp; If you click on the ''Train'' links you will get more detail about that journey.&nbsp; If you click on the name of a station you will get the available ''Station information''.&nbsp; If you click on ''Map'' you can view maps for various parts of the journey.</p>
<p>&nbsp;</p>
<p><strong>Map of journey</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Map of journey'' will initially display a map of the entire day trip.&nbsp; You can then view steps of the day trip in more detail by selecting a step from the drop down list and clicking "show route".</p>
<p>&nbsp;</p>
<p><strong>Summary of journey options</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Summary of journey options'' will display the list of journey options only.</p>
<p>&nbsp;</p>
<p><strong>If you want to print out any page of information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<p>Mae''r dudalen hon yn arddangos dewisiadau''r siwrnai sy''n cyfateb i''ch chwiliad orau.&nbsp;Crynhoir y dewisiadau hyn yn y tabl.</p>
<p>&nbsp;</p>
<p>Gallwch ddewis opsiwn o bob blwch i greu eich siwrnai.</p>
<p>&nbsp;</p>
<p>Gallwch hefyd weld yr wybodaeth ganlynol am ddewis siwrnai a ddetholwyd:</p>
<ul>
<li>Manylion (mewn diagram neu dabl)</li> 
<li>Mapiau</li></ul>
<p>&nbsp;</p>
<p>Er mwyn gweld y wybodaeth hon:</p>
<ol>
<li>Cliciwch y botymau ger yr opsiynau y mae gennych ddiddordeb ynddynt</li> 
<li>Dewiswch y math o wybodaeth yr hoffech ei gweld ar gyfer y siwrnai a ddetholir o''r rhestr a ollyngir i lawr<br/>- ''Diagram o fanylion eich siwrnai''<br/>- ''Manylion tabl y siwrnai''<br/>- ''Map o''r siwrnai''<br/>- ''Crynodeb o ddewisiadau''r siwrnai''<br/></li>
<li>Yna cliciwch ''Iawn''.</li></ol>
<p>Disgrifir y rhain yn fanylach isod:</p>
<p>&nbsp;</p>
<p><strong>Diagram o fanylion siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Diagram o fanylion siwrnai'' yn arddangos mwy o fanylion am y siwrnai a ddetholwyd mewn diagram.</p>
<p>&nbsp;</p>
<p>Yn y diagram, ynghyd � mwy o fanylion am yr adrannau unigol sy''n ffurfio eich taith ddydd, mae cysylltiadau yn mynd � chi at fwy o wybodaeth am rannau unigol y daith.&nbsp; Os cliciwch ar y dolennau ''Tr�n'' fe gewch fwy o wybodaeth am y siwrnai honno.&nbsp; Os cliciwch ar enw gorsaf byddwch yn cael ''Gwybodaeth am orsafoedd'' sydd ar gael.&nbsp; Os cliciwch ar ''Map'' gallwch weld mapiau ar gyfer y gwahanol rannau o''r siwrnai.</p>
<p>&nbsp;</p>
<p><strong>Tabl o fanylion siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Tabl o fanylion siwrnai'' yn dangs mwy o fanylion am y siwrnai a ddewisiwyd mewn tabl.</p>
<p>&nbsp;</p>
<p>Yn y tabl, ynghyd � mwy o fanylion ar gyfer adrannau unigol sy''n ffurfio eich taith dydd mae cysylltiadau yn mynd � chi at fwy o wybodaeth am rannau unigol y daith.&nbsp; Os cliciwch ar y dolennau ''Tr�n'' fe gewch fwy o wybodaeth am y siwrnai honno.&nbsp; Os cliciwch ar enw gorsaf byddwch yn cael ''Gwybodaeth am orsafoedd'' sydd ar gael.&nbsp; Os cliciwch ar ''Map'' gallwch weld mapiau ar gyfer y gwahanol rannau o''r siwrnai.</p>
<p>&nbsp;</p>
<p><strong>Map o''r siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Map o''r siwrnai'' yn arddangos map o''r daith ddydd gyfan.&nbsp; na gallwch weld camau o''r daith ddydd yn fanylach drwy ddewis cam o''r rhestr a ollyngir i lawr a chlicio ar ''Dangos llwybr''.</p>
<p>&nbsp;</p>
<p><strong>Crynodeb o opsiynau''r siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Crynodeb o opsiynau''r siwrnai'' yn arddangos y rhestr o ddewisiadau''r siwrnai yn unig.</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ''Hawdd ei argraffu'', bydd hyn yn agor tudalen y gellir ei hargraffu fel arfer.</strong></p>
<p></p>'

GO

-- printer friendly help page for visit planner results page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpVisitPlannerResults'
,'<p>This page displays the journey options that best match your search.&nbsp; These options are summarised in the table.</p>
<p>&nbsp;</p>
<p>You can select an option from each box to create your journey.</p>
<p>&nbsp;</p>
<p>You can also view the following information about a selected journey option:</p>
<ul>
<li>Details (in a diagram or a table)</li>
<li>Maps</li></ul>
<p>&nbsp;</p>
<p>In order to view this information:</p>
<ol>
<li>Click the buttons next to the options you are interested in</li>
<li>Select the type of information you''d like to see for the selected journey from the drop-down list<br/>- ''Diagram of journey details''<br/>- ''Table of journey details''<br/>- ''Map of journey''<br/>- ''Summary of journey options''<br/></li>
<li>Then click ''Ok''.</li></ol>
<p>These views are described in more detail below:</p>
<p>&nbsp;</p>
<p><strong>Diagram of journey details</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Diagram of journey details'' will display more details for the selected journey in a diagram.</p>
<p>&nbsp;</p>
<p>In the diagram, along with more detail for the individual sections that make up your multi-visit journey, there are links to take you to more information about the individual parts of the journey.&nbsp; If you click on the ''Train'' links you will get more detail about that journey.&nbsp; If you click on the name of a station you will get the available ''Station information''.&nbsp; If you click on ''Map'' you can view maps for various parts of the journey.</p>
<p>&nbsp;</p>
<p><strong>Table of journey details</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Table of journey details'' will display more details for the selected journey in a table.</p>
<p>&nbsp;</p>
<p>In the table, along with more detail for the individual sections that make up your day trip, there are links to take you to more information about the individual parts of the trip.&nbsp; If you click on the ''Train'' links you will get more detail about that journey.&nbsp; If you click on the name of a station you will get the available ''Station information''.&nbsp; If you click on ''Map'' you can view maps for various parts of the journey.</p>
<p>&nbsp;</p>
<p><strong>Map of journey</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Map of journey'' will initially display a map of the entire day trip.&nbsp; You can then view steps of the day trip in more detail by selecting a step from the drop down list and clicking "show route".</p>
<p>&nbsp;</p>
<p><strong>Summary of journey options</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Summary of journey options'' will display the list of journey options only.</p>
<p>&nbsp;</p>
<p><strong>If you want to print out any page of information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<p>Mae''r dudalen hon yn arddangos dewisiadau''r siwrnai sy''n cyfateb i''ch chwiliad orau.&nbsp;Crynhoir y dewisiadau hyn yn y tabl.</p>
<p>&nbsp;</p>
<p>Gallwch ddewis opsiwn o bob blwch i greu eich siwrnai.</p>
<p>&nbsp;</p>
<p>Gallwch hefyd weld yr wybodaeth ganlynol am ddewis siwrnai a ddetholwyd:</p>
<ul>
<li>Manylion (mewn diagram neu dabl)</li> 
<li>Mapiau</li></ul>
<p>&nbsp;</p>
<p>Er mwyn gweld y wybodaeth hon:</p>
<ol>
<li>Cliciwch y botymau ger yr opsiynau y mae gennych ddiddordeb ynddynt</li> 
<li>Dewiswch y math o wybodaeth yr hoffech ei gweld ar gyfer y siwrnai a ddetholir o''r rhestr a ollyngir i lawr<br/>- ''Diagram o fanylion eich siwrnai''<br/>- ''Manylion tabl y siwrnai''<br/>- ''Map o''r siwrnai''<br/>- ''Crynodeb o ddewisiadau''r siwrnai''<br/></li>
<li>Yna cliciwch ''Iawn''.</li></ol>
<p>Disgrifir y rhain yn fanylach isod:</p>
<p>&nbsp;</p>
<p><strong>Diagram o fanylion siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Diagram o fanylion siwrnai'' yn arddangos mwy o fanylion am y siwrnai a ddetholwyd mewn diagram.</p>
<p>&nbsp;</p>
<p>Yn y diagram, ynghyd � mwy o fanylion am yr adrannau unigol sy''n ffurfio eich taith ddydd, mae cysylltiadau yn mynd � chi at fwy o wybodaeth am rannau unigol y daith.&nbsp; Os cliciwch ar y dolennau ''Tr�n'' fe gewch fwy o wybodaeth am y siwrnai honno.&nbsp; Os cliciwch ar enw gorsaf byddwch yn cael ''Gwybodaeth am orsafoedd'' sydd ar gael.&nbsp; Os cliciwch ar ''Map'' gallwch weld mapiau ar gyfer y gwahanol rannau o''r siwrnai.</p>
<p>&nbsp;</p>
<p><strong>Tabl o fanylion siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Tabl o fanylion siwrnai'' yn dangs mwy o fanylion am y siwrnai a ddewisiwyd mewn tabl.</p>
<p>&nbsp;</p>
<p>Yn y tabl, ynghyd � mwy o fanylion ar gyfer adrannau unigol sy''n ffurfio eich taith dydd mae cysylltiadau yn mynd � chi at fwy o wybodaeth am rannau unigol y daith.&nbsp; Os cliciwch ar y dolennau ''Tr�n'' fe gewch fwy o wybodaeth am y siwrnai honno.&nbsp; Os cliciwch ar enw gorsaf byddwch yn cael ''Gwybodaeth am orsafoedd'' sydd ar gael.&nbsp; Os cliciwch ar ''Map'' gallwch weld mapiau ar gyfer y gwahanol rannau o''r siwrnai.</p>
<p>&nbsp;</p>
<p><strong>Map o''r siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Map o''r siwrnai'' yn arddangos map o''r daith ddydd gyfan.&nbsp; na gallwch weld camau o''r daith ddydd yn fanylach drwy ddewis cam o''r rhestr a ollyngir i lawr a chlicio ar ''Dangos llwybr''.</p>
<p>&nbsp;</p>
<p><strong>Crynodeb o opsiynau''r siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Crynodeb o opsiynau''r siwrnai'' yn arddangos y rhestr o ddewisiadau''r siwrnai yn unig.</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ''Hawdd ei argraffu'', bydd hyn yn agor tudalen y gellir ei hargraffu fel arfer.</strong></p>
<p></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpVisitPlannerResults'
,'<p>This page displays the journey options that best match your search.&nbsp; These options are summarised in the table.</p>
<p>&nbsp;</p>
<p>You can select an option from each box to create your journey.</p>
<p>&nbsp;</p>
<p>You can also view the following information about a selected journey option:</p>
<ul>
<li>Details (in a diagram or a table)</li>
<li>Maps</li></ul>
<p>&nbsp;</p>
<p>In order to view this information:</p>
<ol>
<li>Click the buttons next to the options you are interested in</li>
<li>Select the type of information you''d like to see for the selected journey from the drop-down list<br/>- ''Diagram of journey details''<br/>- ''Table of journey details''<br/>- ''Map of journey''<br/>- ''Summary of journey options''<br/></li>
<li>Then click ''Ok''.</li></ol>
<p>These views are described in more detail below:</p>
<p>&nbsp;</p>
<p><strong>Diagram of journey details</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Diagram of journey details'' will display more details for the selected journey in a diagram.</p>
<p>&nbsp;</p>
<p>In the diagram, along with more detail for the individual sections that make up your multi-visit journey, there are links to take you to more information about the individual parts of the journey.&nbsp; If you click on the ''Train'' links you will get more detail about that journey.&nbsp; If you click on the name of a station you will get the available ''Station information''.&nbsp; If you click on ''Map'' you can view maps for various parts of the journey.</p>
<p>&nbsp;</p>
<p><strong>Table of journey details</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Table of journey details'' will display more details for the selected journey in a table.</p>
<p>&nbsp;</p>
<p>In the table, along with more detail for the individual sections that make up your day trip, there are links to take you to more information about the individual parts of the trip.&nbsp; If you click on the ''Train'' links you will get more detail about that journey.&nbsp; If you click on the name of a station you will get the available ''Station information''.&nbsp; If you click on ''Map'' you can view maps for various parts of the journey.</p>
<p>&nbsp;</p>
<p><strong>Map of journey</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Map of journey'' will initially display a map of the entire day trip.&nbsp; You can then view steps of the day trip in more detail by selecting a step from the drop down list and clicking "show route".</p>
<p>&nbsp;</p>
<p><strong>Summary of journey options</strong></p>
<p>&nbsp;</p>
<p>Selecting ''Summary of journey options'' will display the list of journey options only.</p>
<p>&nbsp;</p>
<p><strong>If you want to print out any page of information, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.</strong></p>'
,'<p>Mae''r dudalen hon yn arddangos dewisiadau''r siwrnai sy''n cyfateb i''ch chwiliad orau.&nbsp;Crynhoir y dewisiadau hyn yn y tabl.</p>
<p>&nbsp;</p>
<p>Gallwch ddewis opsiwn o bob blwch i greu eich siwrnai.</p>
<p>&nbsp;</p>
<p>Gallwch hefyd weld yr wybodaeth ganlynol am ddewis siwrnai a ddetholwyd:</p>
<ul>
<li>Manylion (mewn diagram neu dabl)</li> 
<li>Mapiau</li></ul>
<p>&nbsp;</p>
<p>Er mwyn gweld y wybodaeth hon:</p>
<ol>
<li>Cliciwch y botymau ger yr opsiynau y mae gennych ddiddordeb ynddynt</li> 
<li>Dewiswch y math o wybodaeth yr hoffech ei gweld ar gyfer y siwrnai a ddetholir o''r rhestr a ollyngir i lawr<br/>- ''Diagram o fanylion eich siwrnai''<br/>- ''Manylion tabl y siwrnai''<br/>- ''Map o''r siwrnai''<br/>- ''Crynodeb o ddewisiadau''r siwrnai''<br/></li>
<li>Yna cliciwch ''Iawn''.</li></ol>
<p>Disgrifir y rhain yn fanylach isod:</p>
<p>&nbsp;</p>
<p><strong>Diagram o fanylion siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Diagram o fanylion siwrnai'' yn arddangos mwy o fanylion am y siwrnai a ddetholwyd mewn diagram.</p>
<p>&nbsp;</p>
<p>Yn y diagram, ynghyd � mwy o fanylion am yr adrannau unigol sy''n ffurfio eich taith ddydd, mae cysylltiadau yn mynd � chi at fwy o wybodaeth am rannau unigol y daith.&nbsp; Os cliciwch ar y dolennau ''Tr�n'' fe gewch fwy o wybodaeth am y siwrnai honno.&nbsp; Os cliciwch ar enw gorsaf byddwch yn cael ''Gwybodaeth am orsafoedd'' sydd ar gael.&nbsp; Os cliciwch ar ''Map'' gallwch weld mapiau ar gyfer y gwahanol rannau o''r siwrnai.</p>
<p>&nbsp;</p>
<p><strong>Tabl o fanylion siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Tabl o fanylion siwrnai'' yn dangs mwy o fanylion am y siwrnai a ddewisiwyd mewn tabl.</p>
<p>&nbsp;</p>
<p>Yn y tabl, ynghyd � mwy o fanylion ar gyfer adrannau unigol sy''n ffurfio eich taith dydd mae cysylltiadau yn mynd � chi at fwy o wybodaeth am rannau unigol y daith.&nbsp; Os cliciwch ar y dolennau ''Tr�n'' fe gewch fwy o wybodaeth am y siwrnai honno.&nbsp; Os cliciwch ar enw gorsaf byddwch yn cael ''Gwybodaeth am orsafoedd'' sydd ar gael.&nbsp; Os cliciwch ar ''Map'' gallwch weld mapiau ar gyfer y gwahanol rannau o''r siwrnai.</p>
<p>&nbsp;</p>
<p><strong>Map o''r siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Map o''r siwrnai'' yn arddangos map o''r daith ddydd gyfan.&nbsp; na gallwch weld camau o''r daith ddydd yn fanylach drwy ddewis cam o''r rhestr a ollyngir i lawr a chlicio ar ''Dangos llwybr''.</p>
<p>&nbsp;</p>
<p><strong>Crynodeb o opsiynau''r siwrnai</strong></p>
<p>&nbsp;</p>
<p>Bydd dewis ''Crynodeb o opsiynau''r siwrnai'' yn arddangos y rhestr o ddewisiadau''r siwrnai yn unig.</p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu unrhyw dudalen o wybodaeth, cliciwch ''Hawdd ei argraffu'', bydd hyn yn agor tudalen y gellir ei hargraffu fel arfer.</strong></p>
<p></p>'

GO

-- printable map's alternate text
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyMapControl.imageMap.AlternateText'
,'Map of journey'
,'Map o''r siwrnai'

-- find station result help content
EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsHelpLabelSelectFromTo'
,'You will see a list of the nearest stations/airports. The closest stations airport are already ticked. You can either:<br/><br/>� Click "Travel from"/"Travel to" to enter the ones that are ticked as stations to travel from/to<br/>� Tick stations you are interested in and click "Travel from"/"Travel to"<br/><br/>You can see the stations/airports on a map by clicking "Show map"<br/>'
,'Fe welwch restr o''r gorsafoedd/meysydd awyr agosaf.  Mae''r gorsafoedd a''r maes awyr agosaf eisoes wedi eu ticio.  Gallwch naill ai:<br/><br/>� Glicio ''Teithio o'' / ''Teithio i'' i gofnodi''r rhai sydd wedi eu ticio fel gorsafoedd i chi naill ai deithio ohonynt neu iddynt<br/>� Ticio gorsafoedd y mae gennych ddiddordeb ynddynt a chlicio ''Teithio o'' neu ''Teithio i''<br/><br/>Gallwch weld y gorsafoedd/meysydd awyr ar fap drwy glicio ''Dangoswch fap''.<br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsHelpLabelSelectNext'
,'You will see a list of the nearest stations/airports. The closest stations airport are already ticked. You can either:<br/><br/>� Click "Travel from"/"Travel to" to enter the ones that are ticked as stations to travel from/to<br/>� Tick stations you are interested in and click "Travel from"/"Travel to"<br/><br/>You can see the stations/airports on a map by clicking "Show map"<br/>'
,'Fe welwch restr o''r gorsafoedd/meysydd awyr agosaf.  Mae''r gorsafoedd a''r maes awyr agosaf eisoes wedi eu ticio.  Gallwch naill ai:<br/><br/>� Glicio ''Teithio o'' / ''Teithio i'' i gofnodi''r rhai sydd wedi eu ticio fel gorsafoedd i chi naill ai deithio ohonynt neu iddynt<br/>� Ticio gorsafoedd y mae gennych ddiddordeb ynddynt a chlicio ''Teithio o'' neu ''Teithio i''<br/><br/>Gallwch weld y gorsafoedd/meysydd awyr ar fap drwy glicio ''Dangoswch fap''.<br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsTrainHelpLabelSelectFrom'
,'You will see a list of the nearest stations. All the stations are ticked so you can either:<br/>� Click "Next" to enter all of them as stations to travel from<br/>� Untick stations you are not interested in and click "Next"<br/>� Click "Show map" to see the stations on a map and click "Next"'
,'Fe welwch restr o''r gorsafoedd agosaf. Mae''r holl orsafoedd wedi cael eu ticio, felly:<br/><br/>� Cliciwch ''Nesaf'' i''w nodi i gyd fel gorsafoedd i chi deithio ohonynt<br/>� Cliciwch ''Dangos map'' i weld y gorsafoedd ar fap a chliciwch ''Nesaf''<br/>� Dad-diciwch y gorsafoedd nad oes gennych ddiddordeb ynddynt a chlicio ''Nesaf''<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsTrainHelpLabelSelectTo'
,'You will see a list of the nearest stations. All the stations are ticked so you can either:<br/>� Click "Next" to enter all of them as stations to travel to<br/>� Untick stations you are not interested in and click "Next"<br/>� Click "Show map" to see the stations on a map and click "Next"<br/>'
,'Fe welwch restr o''r gorsafoedd agosaf. Mae''r holl orsafoedd wedi cael eu ticio, felly:<br/><br/>� Cliciwch "Nesaf" i''w nodi i gyd fel gorsafoedd'

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsCoachHelpLabelSelectFrom'
,'You will see a list of the nearest coach stations. All the stations are ticked so you can either:<br/>�  Click "Next" to enter all of them as coach stations to travel from<br/>�  Untick coach stations you are not interested in and click "Next"<br/>�  Click "Show map" to see the coach stations on a map and click "Next"<br/>'
,'Byddwch yn gweld rhestr o''r gorsafoedd bysiau agosaf.  Mae''r gorsafoedd i gyd wedi''u ticio felly gallwch naill ai:<br/>�  Glicio ''Nesaf'' i''w dewis i gyd fel gorsafoedd bysiau i chi deithio ohonynt<br/>�  Clicio ''Dangos map'' i weld y gorsafoedd bysiau ar fap a chlicio ''Nesaf''<br/>�  Dad-dicio''r gorsafoedd bysiau nad oes gennych ddiddordeb ynddynt a chlicio ''Nesaf''<br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsCoachHelpLabelSelectTo'
,'You will see a list of the nearest coach stations. All the stations are ticked so you can either:<br/>�  Click "Next" to enter all of them as coach stations to travel to<br/>�  Untick coach stations you are not interested in and click "Next"<br/>�  Click "Show map" to see the coach stations on a map and click "Next"<br/>'
,'Byddwch yn gweld rhestr o''r gorsafoedd bysiau agosaf.  Mae''r gorsafoedd i gyd wedi''u ticio felly gallwch naill ai:<br/>�  Glicio ''Nesaf'' i''w dewis i gyd fel gorsafoedd bysiau i chi deithio ohonynt<br/>�  Clicio ''Dangos map'' i weld y gorsafoedd bysiau ar fap a chlicio ''Nesaf''<br/>�  Dad-dicio''r gorsafoedd bysiau nad oes gennych ddiddordeb ynddynt a chlicio ''Nesaf''<br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsAirportHelpLabelSelectFrom'
,'You will see a list of the nearest airports. All the airports are ticked so you can either:<br/>�  Click "Next" to enter all of them as airports to travel from<br/>�  Untick airports you are not interested in and click "Next"<br/>� Click "Show map" to see the airports on a map and click "Next"'
,'Byddwch yn gweld rhestr o''r meysydd awyr agosaf.  Mae''r meysydd awyr i gyd wedi''u ticio felly gallwch naill ai glicio ''Nesa'' i roi pob un fel meysydd awyr i deithio ohonynt, neu:<br/>�  Dad-diciwch feysydd awyr nad oes gennych ddiddordeb ynddynt a chliciwch ''Nesa''<br/>� Cliciwch ''Dangos map'' i weld y meysydd awyr ar y map a chliciwch ''Nesa'''

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsAirportHelpLabelSelectTo'
,'You will see a list of the nearest airports. All the airports are ticked so you can either:<br/>� Click "Next" to enter all of them as airports to travel to<br/>�  Untick airports you are not interested in and click "Next"<br/>� Click "Show map" to see the airports on a map and click "Next"'
,'Byddwch yn gweld rhestr o''r meysydd awyr agosaf.  Mae''r meysydd awyr i gyd wedi''u ticio felly gallwch naill ai glicio ''Nesa'' i roi pob un ohonynt fel meysydd awyr i deithio iddynt, neu:<br/>�  Dad-diciwch feysydd awyr nad oes gennych ddiddordeb ynddynt a chliciwch ''Nesa''<br/>� Cliciwch ''Dangos map'' i weld y meysydd awyr ar y map a chliciwch ''Nesa'''

GO

-- maplocationiconselect control's texts
EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.checklistAttractions'
,'Botanical &amp; zoological|Historical &amp; cultural|Recreational &amp; scenic|Tourist attractions'
,'Botanegol a swolegol|Hanesyddol a diwylliannol|Adloniadol a golygfaol|Atyniadau twristaidd'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.checklistAccommodation'
,'Eating &amp; drinking|Hotels &amp; guesthouses|Camping, caravanning &amp; mobile homes|Youth hostels'
,'Bwyta ac yfed|Gwestai a gwestai bach|Gwersylla, carafanio a chartrefi symudol|Hosteli Ieuenctid'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.checklistSport'
,'Outdoor pursuits|Sports complexes|Venues:Stages &amp; screens|Retail'
,'Gweithgareddau awyr agored|Canolfannau chwaraeon|Mannau cyfarfod: Llwyfannau a sgriniau|Adwerthu'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.checklistEducation'
,'Primary &amp; nursery|Secondary, middle &amp; independent|Colleges &amp; universities|Recreational'
,'Cynradd a meithrin|Uwchradd, canol ac annibynnol|Colegau a phrifysgolion|Adloniadol'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.checklistInfrastructure'
,'Police &amp; court services|Local services|Other government services|Public facilities'
,'Gwasanaethau heddlu a llysoedd|Gwasanaethau lleol|Gwasanaethau eraill y llywodraeth|Cyfleusterau cyhoeddus'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.checklistHealth'
,'Surgeries (doctor &amp; dental)|Hospitals, clinics &amp; health centres|Nursing &amp; care homes|Chemists &amp; opticians'
,'Meddygfeydd (doctoriaid a deintyddion)|Ysbytai, clinigiau a chanolfannau iechyd|Cartrefi nyrsio a gofal|Fferyllyddion ac optegwyr'

GO

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpVisitPlannerInput'
,'<p>Day trip&nbsp;planner allows you to plan a day trip to your choice of two destinations.</p>
<p>&nbsp;</p>
<p>To enter a location to travel from</p>
<ol>
<li>Type a location in the box </li>
<li>Select the type of location </li></ol>
<p>You can also click ''Find on map'' to look for the location on a map. </p>
<p>&nbsp;</p>
<p>If you would like this location to be where you finish your journey as well (your final destination) then tick the box ''Plan the journey so that I return to this location'' and a return journey will be planned for you.</p>
<p>&nbsp;</p>
<p>To enter a first location to visit:</p>
<ol>
<li>Type a location in the box </li>
<li>Select the type of location required</li></ol>
<p>Then select the length of time you would like to stay in this location.</p>
<p>&nbsp;</p>
<p>To enter a second location to visit:</p>
<ol>
<li>Type a location in the box </li>
<li>Select the type of location required</li></ol>
<p>Then select the length of time you would like to stay in this location.</p>
<p>&nbsp;</p>
<p>To select the date and time of your journey:</p>
<ol>
<li>Select the date you wish to travel (You can use the calendar) </li>
<li>Select the time you wish to leave (Times are shown as 24 hour. e.g. 5:00pm = 17:00)</li></ol>
<p>You can add more details to your search request by clicking on ''Advanced options'' at the bottom of the page.</p>
<p>&nbsp;</p>
<p>If you wish, you can enter or select your preferred travel options in this section.The Journey Planner will take them into account when searching for your journeys.&nbsp; If you are logged in, you can save these preferences and use them the next time you plan a journey.</p>
<p>&nbsp;</p>
<p>Finally, click ''Next''.</p>'
, '<p>Mae cynllunydd teithiau dydd yn caniat�u i chi gynllunio taith ddydd i''ch dewis o ddwy gyrchfan.</p>
<p>&nbsp;</p>
<p>I nodi lleoliad i deithio ohono</p>
<ol>
<li>Teipiwch leoliad yn y blwch </li>
<li>Dewiswch y math o leoliad sy''n angenrheidiol</li></ol>
<p>Gallwch hefyd glicio ''Darganfyddwch ar fap'' i chwilio am y lleoliad ar fap. </p>
<p>&nbsp;</p>
<p>Os hoffech i''r lleoliad hwn fod ble y bu i chi orffen eich siwrnai yn ogystal (eich cyrchfan derfynol) yna ticiwch y blwch ''Cynlluniwch y siwrnai fel fy mod yn dychwelyd i''r lleoliad hwn'' a bydd siwrnai ddychwel yn cael ei chynllunio ar eich cyfer.</p>
<p>&nbsp;</p>
<p>I nodi lleoliad cyntaf i ymweld ag ef:</p>
<ol>
<li>Teipiwch leoliad yn y blwch </li>
<li>Dewiswch y math o leoliad sy''n angenrheidiol</li></ol>
<p>Yna dewiswch hyd yr amser yr hoffech aros yn y lleoliad hwn.</p>
<p>&nbsp;</p>
<p>I nodi ail leoliad i ymweld ag ef:</p>
<ol>
<li>Teipiwch leoliad yn y blwch </li>
<li>Dewiswch y math o leoliad sy''n angenrheidiol</li></ol>
<p>Yna dewiswch hyd yr amser yr hoffech aros yn y lleoliad hwn.</p>
<p>&nbsp;</p>
<p>I ddewis dyddiad ac amser eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad y dymunwch deithio, (Gallwch ddefnyddio''r calendr) </li>
<li>Dewiswch yr amser y dymunwch ddechrau eich siwrnai. (Dangosir amserau fel 24 awr e.e. 5:00pm = 17:00 ac ati)</li></ol>
<p>Gallwch ychwanegu mwy o fanylion at eich cais am chwiliad drwy glicio ar ''Dewisiadau mwy cymhleth'' ar waelod y dudalen.</p>
<p>&nbsp;</p>
<p>Os dymunwch gallwch roi neu ddewis eich dewisiadau teithio a ffafrir gennych yn yr adran hon (fel y math o gludiant y dymunwch ei ddefnyddio neu nifer y newidiadau a fyddai''n well gennych). Bydd y Cynlluniwr Siwrnai yn eu cymryd i ystyriaeth wrth chwilio am eich siwrneion. Os ydych wedi logio i mewn, gallwch gadw''r hoffterau hyn a''u defnyddio''r tro nesaf y cynlluniwch siwrnai.</p>
<p>&nbsp;</p>
<p>Wedi i chi gwblhau''r dudalen, cliciwch ''Nesaf''.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpVisitPlannerInput'
,'<p>Day trip&nbsp;planner allows you to plan a day trip to your choice of two destinations.</p>
<p>&nbsp;</p>
<p>To enter a location to travel from</p>
<ol>
<li>Type a location in the box </li>
<li>Select the type of location </li></ol>
<p>You can also click ''Find on map'' to look for the location on a map. </p>
<p>&nbsp;</p>
<p>If you would like this location to be where you finish your journey as well (your final destination) then tick the box ''Plan the journey so that I return to this location'' and a return journey will be planned for you.</p>
<p>&nbsp;</p>
<p>To enter a first location to visit:</p>
<ol>
<li>Type a location in the box </li>
<li>Select the type of location required</li></ol>
<p>Then select the length of time you would like to stay in this location.</p>
<p>&nbsp;</p>
<p>To enter a second location to visit:</p>
<ol>
<li>Type a location in the box </li>
<li>Select the type of location required</li></ol>
<p>Then select the length of time you would like to stay in this location.</p>
<p>&nbsp;</p>
<p>To select the date and time of your journey:</p>
<ol>
<li>Select the date you wish to travel (You can use the calendar) </li>
<li>Select the time you wish to leave (Times are shown as 24 hour. e.g. 5:00pm = 17:00)</li></ol>
<p>You can add more details to your search request by clicking on ''Advanced options'' at the bottom of the page.</p>
<p>&nbsp;</p>
<p>If you wish, you can enter or select your preferred travel options in this section.The Journey Planner will take them into account when searching for your journeys.&nbsp; If you are logged in, you can save these preferences and use them the next time you plan a journey.</p>
<p>&nbsp;</p>
<p>Finally, click ''Next''.</p>'
, '<p>Mae cynllunydd teithiau dydd yn caniat�u i chi gynllunio taith ddydd i''ch dewis o ddwy gyrchfan.</p>
<p>&nbsp;</p>
<p>I nodi lleoliad i deithio ohono</p>
<ol>
<li>Teipiwch leoliad yn y blwch </li>
<li>Dewiswch y math o leoliad sy''n angenrheidiol</li></ol>
<p>Gallwch hefyd glicio ''Darganfyddwch ar fap'' i chwilio am y lleoliad ar fap. </p>
<p>&nbsp;</p>
<p>Os hoffech i''r lleoliad hwn fod ble y bu i chi orffen eich siwrnai yn ogystal (eich cyrchfan derfynol) yna ticiwch y blwch ''Cynlluniwch y siwrnai fel fy mod yn dychwelyd i''r lleoliad hwn'' a bydd siwrnai ddychwel yn cael ei chynllunio ar eich cyfer.</p>
<p>&nbsp;</p>
<p>I nodi lleoliad cyntaf i ymweld ag ef:</p>
<ol>
<li>Teipiwch leoliad yn y blwch </li>
<li>Dewiswch y math o leoliad sy''n angenrheidiol</li></ol>
<p>Yna dewiswch hyd yr amser yr hoffech aros yn y lleoliad hwn.</p>
<p>&nbsp;</p>
<p>I nodi ail leoliad i ymweld ag ef:</p>
<ol>
<li>Teipiwch leoliad yn y blwch </li>
<li>Dewiswch y math o leoliad sy''n angenrheidiol</li></ol>
<p>Yna dewiswch hyd yr amser yr hoffech aros yn y lleoliad hwn.</p>
<p>&nbsp;</p>
<p>I ddewis dyddiad ac amser eich siwrnai:</p>
<ol>
<li>Dewiswch y dyddiad y dymunwch deithio, (Gallwch ddefnyddio''r calendr) </li>
<li>Dewiswch yr amser y dymunwch ddechrau eich siwrnai. (Dangosir amserau fel 24 awr e.e. 5:00pm = 17:00 ac ati)</li></ol>
<p>Gallwch ychwanegu mwy o fanylion at eich cais am chwiliad drwy glicio ar ''Dewisiadau mwy cymhleth'' ar waelod y dudalen.</p>
<p>&nbsp;</p>
<p>Os dymunwch gallwch roi neu ddewis eich dewisiadau teithio a ffafrir gennych yn yr adran hon (fel y math o gludiant y dymunwch ei ddefnyddio neu nifer y newidiadau a fyddai''n well gennych). Bydd y Cynlluniwr Siwrnai yn eu cymryd i ystyriaeth wrth chwilio am eich siwrneion. Os ydych wedi logio i mewn, gallwch gadw''r hoffterau hyn a''u defnyddio''r tro nesaf y cynlluniwch siwrnai.</p>
<p>&nbsp;</p>
<p>Wedi i chi gwblhau''r dudalen, cliciwch ''Nesaf''.</p>'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareDateSelection.SingleNote'
,'Notes:<br />���Availability is not guaranteed at this stage.<br />���"*" means that all the fares for that date are unlikely to be available.'
, 'Nodiadau:<br />���Ni ellir gwarantu fod y tocynnau ar gael ar hyn o bryd.<br />���Mae "*" yn golygu bod yr holl docynnau ar gyfer y cyfuniad o ddyddiad hwnnw yn annhebyg o fod ar gael.'

GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1212
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO