-- *************************************************************************************
-- NAME 		: DUP1139_Update_AddExternalSuggestionLink.sql
-- DESCRIPTION 	: Updates the AddExternalSuggestionLink storedprocedure to work with ThemeId
-- AUTHOR		: Mitesh Modi
-- *************************************************************************************

USE [TransientPortal]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- =============================================  
-- Description: AddExternalSuggestionLink - wrapper stored procedure to call the appropriate add suggestion
--						link stored procedures in order
-- NOTE: THIS CURRENTLY ADDS A DEFAULT SubRootLinkID of 0
-- =============================================  
ALTER  PROCEDURE [dbo].[AddExternalSuggestionLink]
		@StringExternalLinkID		varchar(500),  	-- ID for ExternalLink table
		@StringLinkURL    	  		varchar(100),	-- Full external link URL
		@StringTestURL    	  		varchar(500),	-- Full test external link URL
		@StringLinkDescription    	varchar(500),	-- Description of external link. Ensure this is a unique external link description
		@StringLinkResourceName		varchar(100),  	-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
		@StringLinkResourceNameEN 	varchar(100),	-- English display text. Populate only if adding new ResourceName or updating existing display text
		@StringLinkResourceNameCY	varchar(100),	-- Welsh display text. Populate only if adding new ResourceName or updating existing display text
		@LinkCategoryName 			varchar(100),  	-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
		@LinkPriority 				int,			-- Priority must be unique for the selected CategoryName this link is for
		@IsRoot						bit,			-- Set to 0 if to be used as a Suggestion/Related Link
		@IsSubRootLink				bit,			-- Set to 1 if it is a second level Root link
		@StringContextName			varchar(100),	-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
		@StringContextDescription	varchar(500),	-- Populate only if adding a new ContextName, or updating description
		@ThemeId					int				-- Theme this link is added for, use 1 as default
AS    
BEGIN
	DECLARE @InternalLinkFlag 	bit,
			@SubRootLinkId		int

	SET @InternalLinkFlag = 0 -- Indicates external link
	SET @SubRootLinkId = 0

	-- Execute the stored procedures to add suggestion link
	EXEC AddExternalLink @StringExternalLinkID, @StringLinkURL, @StringTestURL, @StringLinkDescription

	EXEC AddExternalLinkToSuggestionLink @StringExternalLinkID

	EXEC AddResource @StringLinkResourceName, @StringLinkResourceNameEN, @StringLinkResourceNameCY 

	EXEC AddSuggestionLink @StringLinkResourceName, @StringLinkDescription, @LinkCategoryName, @LinkPriority, 
				@InternalLinkFlag, @IsRoot, @IsSubRootLink, @SubRootLinkId, @StringExternalLinkID

	EXEC AddContext @StringContextName, @StringContextDescription 

	EXEC AddContextSuggestionLink @StringLinkResourceName, @LinkCategoryName, @StringContextName, @ThemeId

END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1139
SET @ScriptDesc = 'Update AddExternalSuggestionLinkId'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
