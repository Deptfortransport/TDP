-- **********************************************************************
-- $Workfile:   DUP1106_AddCity2CtySprocs.sql  $
-- AUTHOR       : j.roberts
-- DATE CREATED : 15/09/2008
-- REVISION     : $Revision:   1.0  $
-- DESCRIPTION  : Creates sprocs INFAddImportantPlace, INFAddNaptanTimeRelationship, INFAddImportantPlaceLocationRelationship
-- **********************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP1106_AddCity2CtySprocs.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 11:00:16   mmodi
--Initial revision.
--
--   Rev 1.2   Sep 16 2008 11:49:50   jroberts
--.
--
--   Rev 1.1   Sep 16 2008 11:11:22   jroberts
--Add output to sprocs
--
--   Rev 1.0   Sep 15 2008 18:28:14   jroberts
--Initial revision.
--
--
--
--


USE PermanentPortal
GO


GO
-- **********************************************************************
-- PROCEDURE INFAddImportantPlace
-- **********************************************************************
DECLARE @ObjectName AS varchar(128)
SET @ObjectName = N'INFAddImportantPlace'
IF NOT EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = @ObjectName
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
    EXEC ('CREATE PROCEDURE [dbo].INFAddImportantPlace AS BEGIN SELECT 1 END')

    EXEC sp_addextendedproperty @name=N'Design', @value=N'SD00?? ?????' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Owner', @value=N'TDP' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Used By', @value=N'TDP.Infrastructure' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName

END
GO


GO
-- **********************************************************************
-- PROCEDURE INFAddImportantPlace
-- Description: 
-- 
-- **********************************************************************
ALTER PROCEDURE dbo.INFAddImportantPlace
(
	@TDNPGID int,
	@PlaceType varchar(20),
	@PlaceName varchar(50),
	@Locality varchar (8)
) AS
BEGIN
    SET NOCOUNT ON
    IF EXISTS(SELECT 1
                FROM dbo.ImportantPlace
               WHERE TDNPGID = @TDNPGID)
        BEGIN
          UPDATE dbo.ImportantPlace
             SET PlaceType = @PlaceType,
                 PlaceName = @PlaceName,
                 Locality  = @Locality
           WHERE TDNPGID   = @TDNPGID
           PRINT 'Updated ImportantPlace TDNPGID ' + Cast(@TDNPGID as varchar(10))
        END
    ELSE
        BEGIN
            INSERT INTO dbo.ImportantPlace 
            (
                TDNPGID,
                PlaceType,
                PlaceName,
                Locality
            )
            VALUES
            (
                @TDNPGID,
                @PlaceType,
                @PlaceName,
                @Locality            
            )
            PRINT 'Inserted ImportantPlace TDNPGID ' + Cast(@TDNPGID as varchar(10))
        END
    --END IF    
END
GO




GO
-- **********************************************************************
-- PROCEDURE INFAddNaptanTimeRelationship
-- **********************************************************************
DECLARE @ObjectName AS varchar(128)
SET @ObjectName = N'INFAddNaptanTimeRelationship'
IF NOT EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = @ObjectName
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
    EXEC ('CREATE PROCEDURE [dbo].INFAddNaptanTimeRelationship AS BEGIN SELECT 1 END')

    EXEC sp_addextendedproperty @name=N'Design', @value=N'SD00?? ?????' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Owner', @value=N'TDP' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Used By', @value=N'TDP.Infrastructure' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName

END
GO


GO
-- **********************************************************************
-- PROCEDURE INFAddNaptanTimeRelationship
-- Description: 
-- 
-- **********************************************************************
ALTER PROCEDURE dbo.INFAddNaptanTimeRelationship
(
	@TDNPGID int,
	@Naptan varchar(12),
	@Mode varchar(10),
	@OSGREasting int,
	@OSGRNorthing int,
	@UseForFareEnquiries char(1),
	@UseDirectAir bit,
	@UseCombinedAir bit,
	@CombinedAirSecondaryModes varchar(50) = NULL
) AS 
BEGIN

    SET NOCOUNT ON

    IF EXISTS(SELECT 1
                FROM dbo.NaptanTimeRelationship
               WHERE [TDNPGID] = @TDNPGID
                 AND [Naptan] = @Naptan)
        BEGIN
          UPDATE dbo.NaptanTimeRelationship
             SET Mode = @Mode,
                 OSGREasting = @OSGREasting,
                 OSGRNorthing = @OSGRNorthing,
                 UseForFareEnquiries = @UseForFareEnquiries,
                 UseDirectAir = @UseDirectAir,
                 UseCombinedAir = @UseCombinedAir,
                 CombinedAirSecondaryModes = @CombinedAirSecondaryModes
           WHERE [TDNPGID] = @TDNPGID
             AND [Naptan] = @Naptan
           PRINT 'Updated NaptanTimeRelationship TDNPGID ' + Cast(@TDNPGID as varchar(10)) + ', Naptan ' + @Naptan
            
        END
    ELSE
        BEGIN
            INSERT INTO dbo.NaptanTimeRelationship 
            (
                TDNPGID,
                Naptan,
                Mode,
                OSGREasting,
                OSGRNorthing,
                UseForFareEnquiries,
                UseDirectAir,
                UseCombinedAir,
                CombinedAirSecondaryModes
            )
            VALUES
            (
                @TDNPGID,
                @Naptan,
                @Mode,
                @OSGREasting,
                @OSGRNorthing,
                @UseForFareEnquiries,
                @UseDirectAir,
                @UseCombinedAir,
                @CombinedAirSecondaryModes
            )
           PRINT 'Inserted NaptanTimeRelationship TDNPGID ' + Cast(@TDNPGID as varchar(10)) + ', Naptan ' + @Naptan
        END
    --END IF    
END
GO




-- **********************************************************************
-- PROCEDURE dbo.INFAddImportantPlaceLocationRelationship
-- **********************************************************************
DECLARE @ObjectName AS varchar(128)
SET @ObjectName = N'INFAddImportantPlaceLocationRelationship'
IF NOT EXISTS(SELECT 1 
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = @ObjectName
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
    EXEC ('CREATE PROCEDURE [dbo].INFAddImportantPlaceLocationRelationship AS BEGIN SELECT 1 END')

    EXEC sp_addextendedproperty @name=N'Design', @value=N'SD00?? ?????' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Owner', @value=N'TDP' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName
    EXEC sp_addextendedproperty @name=N'Used By', @value=N'TDP.Infrastructure' ,@level0type=N'user', @level0name=N'dbo', @level1type=N'PROCEDURE', @level1name=@ObjectName

END
GO


GO
-- **********************************************************************
-- PROCEDURE dbo.INFAddImportantPlaceLocationRelationship
-- Description: 
-- 
-- **********************************************************************
ALTER PROCEDURE dbo.INFAddImportantPlaceLocationRelationship
(
    @TDNPGID      int,
    @Mode         varchar(10),
    @OSGREasting  int,
    @OSGRNorthing int,
    @StartTime    int,
    @EndTime      int,
    @DaysValid    varchar(7),
    @Comments     varchar(100)
) AS
BEGIN
    SET NOCOUNT ON
    IF EXISTS(SELECT 1
                FROM dbo.ImportantPlaceLocationRelationship
               WHERE TDNPGID = @TDNPGID
                 AND Mode = @Mode
                 AND OSGREasting = @OSGREasting
                 AND OSGRNorthing = @OSGRNorthing
                 AND StartTime = @StartTime
                 AND EndTime = @EndTime)
        BEGIN
          UPDATE dbo.ImportantPlaceLocationRelationship
             SET DaysValid = @DaysValid,
                 Comments = @Comments
           WHERE TDNPGID = @TDNPGID
             AND Mode = @Mode
             AND OSGREasting = @OSGREasting
             AND OSGRNorthing = @OSGRNorthing
             AND StartTime = @StartTime
             AND EndTime = @EndTime
           PRINT 'Updated ImportantPlaceLocationRelationship TDNPGID ' + Cast(@TDNPGID as varchar(10)) + ', Mode ' + @Mode + ', OSGREasting ' + Cast(@OSGREasting as varchar(10)) + ', OSGRNorthing ' + Cast(@OSGRNorthing as varchar(10))  + ', StartTime ' +  Cast(@StartTime as varchar(10))  +   ', EndTime ' +  Cast(@EndTime as varchar(10))  
        END
    ELSE
        BEGIN
            INSERT INTO dbo.ImportantPlaceLocationRelationship 
            (
                [TDNPGID],
                [Mode],
                [OSGREasting],
                [OSGRNorthing],
                [StartTime],
                [EndTime],
                [DaysValid],
                [Comments]
            )
            VALUES
            (
                @TDNPGID,
                @Mode,
                @OSGREasting,
                @OSGRNorthing,
                @StartTime,
                @EndTime,
                @DaysValid,
                @Comments
            )
           PRINT 'Inserted ImportantPlaceLocationRelationship TDNPGID ' + Cast(@TDNPGID as varchar(10)) + ', Mode ' + @Mode + ', OSGREasting ' + Cast(@OSGREasting as varchar(10)) + ', OSGRNorthing ' + Cast(@OSGRNorthing as varchar(10))  + ', StartTime ' +  Cast(@StartTime as varchar(10))  +   ', EndTime ' +  Cast(@EndTime as varchar(10))  
        END
    --END IF    
END
GO

GO
-- ************************************************ 
-- Update the Change Log
-- ************************************************ 

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1106
SET @ScriptDesc = 'INFAddImportantPlace, INFAddNaptanTimeRelationship, INFAddImportantPlaceLocationRelationship 1106'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
GO
