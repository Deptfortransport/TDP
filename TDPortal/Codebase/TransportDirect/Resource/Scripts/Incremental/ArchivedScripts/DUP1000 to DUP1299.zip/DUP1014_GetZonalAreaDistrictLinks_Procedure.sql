-- ************************************************************
-- NAME 	: DUP1014_GetZonalAreaDistrictLinks_Procedure.sql
-- AUTHOR	: Sanjeev Johal
-- DESCRIPTION 	: GetZonalAreaDistrictLinks Procedures
-- ************************************************************
--

USE [TransientPortal]
GO

---------------------------------------------------
-- 1. GetZonalAreaDistrictLinks Procedure change
----------------------------------------------------


--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetZonalAreaDistrictLinks'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetZonalAreaDistrictLinks] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
ALTER PROCEDURE GetZonalAreaDistrictLinks
AS

SELECT ExternalLinkId, AdminAreaId, DistrictId FROM ZonalAccessibilityLinks
WHERE 
(
	(AdminAreaId IS NOT NULL)
OR 
	(DistrictId IS NOT NULL)
AND Naptan IS NULL

)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1014
SET @ScriptDesc = 'GetZonalAreaDistrictLinks Procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO