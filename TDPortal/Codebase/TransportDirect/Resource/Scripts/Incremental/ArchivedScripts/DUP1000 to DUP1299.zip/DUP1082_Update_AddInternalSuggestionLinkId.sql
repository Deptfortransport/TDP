-- *************************************************************************************
-- NAME 		: DUP1082_Update AddInternalSuggestionLinkId.sql
-- DESCRIPTION  	: Add Related Link heading and FAQ 'Park Mark' section 6.5 url to
-- DESCRIPTION  	: Find nearest Carpark & Drive to Carpark result screens
-- AUTHOR		: Neil Rankin
-- *************************************************************************************

USE TransientPortal

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- =============================================  
-- Description: AddInternalSuggestionLink - wrapper stored procedure to call the appropriate add suggestion
--						link stored procedures in order
-- NOTE: This currently adds a default SubRootLinkID of 0
-- =============================================  
ALTER  PROCEDURE [dbo].[AddInternalSuggestionLink]    
		@StringLinkURL    	  	varchar(100),	-- Relative internal link URL
		@StringLinkDescription    	varchar(500),	-- Description of internal link. Ensure this is a unique internal link description
		@StringLinkResourceName		varchar(100),  	-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
		@StringLinkResourceNameEN 	varchar(100),	-- English display text. Populate only if adding new ResourceName or updating existing display text
		@StringLinkResourceNameCY	varchar(100),	-- Welsh display text. Populate only if adding new ResourceName or updating existing display text
		@LinkCategoryName 		varchar(100),  	-- Use 'General' if not a left hand navigation link
		@LinkPriority 			int,		-- Priority must be unique for the selected CategoryName this link is for
		@IsRoot				bit,		-- Set to 0 if to be used as a Suggestion/Related Link
		@IsSubRootLink			bit,		-- Set to 1 if it is a second level Root link
		@StringContextName		varchar(100),	-- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
		@StringContextDescription	varchar(500),	-- Populate only if adding a new ContextName, or updating description
		@ThemeId			int		-- Theme this link is added for, use 1 as default
AS    
BEGIN
	DECLARE @InternalLinkFlag 	bit,
		@SubRootLinkId		int

	SET @InternalLinkFlag = 1
	SET @SubRootLinkId = 0

	-- Execute the stored procedures to add suggestion link
	EXEC AddInternalLink @StringLinkURL, @StringLinkDescription 

	EXEC AddResource @StringLinkResourceName, @StringLinkResourceNameEN, @StringLinkResourceNameCY 

	EXEC AddSuggestionLink @StringLinkResourceName, @StringLinkDescription, @LinkCategoryName, @LinkPriority, 
				@InternalLinkFlag, @IsRoot, @IsSubRootLink, @SubRootLinkId, ''

	EXEC AddContext @StringContextName, @StringContextDescription 

	EXEC AddContextSuggestionLink @StringLinkResourceName, @LinkCategoryName, @StringContextName, @ThemeId

END


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1082
SET @ScriptDesc = 'Update AddInternalSuggestionLinkId'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
GO

