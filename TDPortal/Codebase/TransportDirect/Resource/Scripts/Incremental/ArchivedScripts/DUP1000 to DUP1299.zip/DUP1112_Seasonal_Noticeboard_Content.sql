-- ***********************************************
-- NAME 		: DUP1112_Seasonal_Noticeboard_Content.sql
-- DESCRIPTION 		: Script to add Seasonal Noticeboard content
-- AUTHOR		: Rich Broddle
-- DATE			: 26 Sept 2008 
-- ************************************************

USE [Content]
GO


-- Add the text for the new hyperlink
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlanner.hyperlinkBankHolidayInfo', 'Click here for information about changes to public transport services.', 'cy Click here for information about changes to public transport services.'

-- 

GO
----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1112
SET @ScriptDesc = 'Added Seasonal Noticeboard hyperlink content - CCN460'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO