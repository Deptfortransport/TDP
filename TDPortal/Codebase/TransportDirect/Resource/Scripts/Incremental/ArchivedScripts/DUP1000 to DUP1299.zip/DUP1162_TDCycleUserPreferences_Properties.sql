-- ***********************************************
-- NAME 		: DUP1162_TDCycleUserPreferences_Properties.sql
-- DESCRIPTION 		: Script to add properties required for the TDCycleUserPreferences
-- AUTHOR		: Mark Turner
-- DATE			: 31 Oct 2008
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.NumberOfPreferences' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.NumberOfPreferences', '9', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '9'
	where pname = 'CyclePlanner.TDUserPreference.NumberOfPreferences' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference0' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference0', '850', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '850'
	where pname = 'CyclePlanner.TDUserPreference.Preference0' AND aid = 'Web' AND gid = 'UserPortal'
END

GO


IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference1' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference1', '11000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '11000'
	where pname = 'CyclePlanner.TDUserPreference.Preference1' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference2' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference2', 'Congestion', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Congestion'
	where pname = 'CyclePlanner.TDUserPreference.Preference2' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference3' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference3', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference3' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference4' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference4', 'Bicycle', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Bicycle'
	where pname = 'CyclePlanner.TDUserPreference.Preference4' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference5' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference5', '19', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '19'
	where pname = 'CyclePlanner.TDUserPreference.Preference5' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference6' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference6', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference6' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference7' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference7', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference7' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

IF not exists (select top 1 * from properties where pName = 'CyclePlanner.TDUserPreference.Preference8' AND aid = 'Web' AND gid = 'UserPortal')
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.Preference8', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.TDUserPreference.Preference8' AND aid = 'Web' AND gid = 'UserPortal'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1162
SET @ScriptDesc = 'Script to add properties required for the the TDCycleUserPreferences'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO