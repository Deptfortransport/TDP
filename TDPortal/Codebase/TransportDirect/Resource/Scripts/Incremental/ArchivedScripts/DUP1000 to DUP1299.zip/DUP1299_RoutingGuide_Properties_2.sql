-- ***********************************************
-- NAME 		: DUP1299_RoutingGuide_Properties_2.sql
-- DESCRIPTION 	: Script to add RoutingGuide property values
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 Feb 2009
-- ************************************************

USE [PermanentPortal]
GO

-- clear existing Routing guide properies
delete from properties where pname like 'RoutingGuide.%'
delete from properties where pname like 'JourneyFaresControl.BreakOfJourney.InterchangeTime.Minutes'


insert into properties values ('RoutingGuide.DoorToDoor.RoutingGuideInfluenced', 					'false', 'Web', 'UserPortal', 0, 1)
insert into properties values ('RoutingGuide.DoorToDoor.RoutingGuideCompliantJourneysOnly', 		'false', 'Web', 'UserPortal', 0, 1)

insert into properties values ('RoutingGuide.FindATrain.RoutingGuideInfluenced', 					'false', 'Web', 'UserPortal', 0, 1)
insert into properties values ('RoutingGuide.FindATrain.RoutingGuideCompliantJourneysOnly', 		'false', 'Web', 'UserPortal', 0, 1)

insert into properties values ('RoutingGuide.CityToCity.RoutingGuideInfluenced', 					'false', 'Web', 'UserPortal', 0, 1)
insert into properties values ('RoutingGuide.CityToCity.RoutingGuideCompliantJourneysOnly', 		'false', 'Web', 'UserPortal', 0, 1)

insert into properties values ('RoutingGuide.FindNearestStation.RoutingGuideInfluenced', 			'false', 'Web', 'UserPortal', 0, 1)
insert into properties values ('RoutingGuide.FindNearestStation.RoutingGuideCompliantJourneysOnly', 'false', 'Web', 'UserPortal', 0, 1)

insert into properties values ('RoutingGuide.FindATrainCost.RoutingGuideInfluenced', 				'true', 'Web', 'UserPortal', 0, 1)
insert into properties values ('RoutingGuide.FindATrainCost.RoutingGuideCompliantJourneysOnly', 	'true', 'Web', 'UserPortal', 0, 1)


-- Interchange time value used to display FAQ for break of journey
insert into properties values ('JourneyFaresControl.BreakOfJourney.InterchangeTime.Minutes', '60', 'Web', 'UserPortal', 0, 1)


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1299
SET @ScriptDesc = 'Routing guide properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO