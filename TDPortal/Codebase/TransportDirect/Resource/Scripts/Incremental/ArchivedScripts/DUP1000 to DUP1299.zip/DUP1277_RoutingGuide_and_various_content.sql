-- ***********************************************
-- NAME 		: DUP1277_RoutingGuide_and_various_content.sql
-- DESCRIPTION 	: Content changes for Routing guide, and updates to various other text
-- AUTHOR		: Mitesh Modi
-- DATE			: 04 February 2009
-- ************************************************

USE [Content]
GO

-- Routing guide
EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelLabelNotePrefix'
,'Note: '
,'Noder: '

EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelFaresAdditionalNoteText'
,'Transport Direct does not currently have fare information for all parts of the journey.<br />'
,'Nid oes gan Transport Direct wybodaeth am docynnau ar gyfer pob rhan o''r siwrnai ar hyn o bryd.<br />'


EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelSingleTicketsNote'
,'It is not possible to travel this rail journey using one ticket - more than one ticket would need to be purchased.<br />'
,'Nid yw''n bosibl teithio''r siwrnai dr�n hon gan ddefnyddio un tocyn - byddai angen prynu mwy nag un tocyn.<br />'


EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelBreakOfJourney'
,'<a href="/Web2/Help/HelpTrain.aspx#A3.11">For conditions associated with longer breaks of journey please check the relevant FAQ by selecting this link.</a>'
,'<a href="/Web2/Help/HelpTrain.aspx#A3.11">Am amodau sy''n gysylltiedig � thorri siwrnai am adegau hirach darllenwch y Cwestiwn Cyffredin perthnasol drwy ddewis y ddolen hon.</a>'



-- Other areas
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelDownloadDescription.Text'
,'Click on the link below to save a GPX file <a href="/Web2/Help/HelpCycle.aspx#A16.4">(What is GPX?)</a> of your route for use on a GPS device'
,'Cliciwch ar y ddolen isod i gadw ffeil GPX <a href="/Web2/Help/HelpCycle.aspx#A16.4">(Beth yw GPX)</a> o''ch llwybr i''w defnyddio ar ddyfais GPS'


DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findcycleinput')

EXEC AddtblContent
1, @GroupId, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput',
'<div class="Column3Header"><div class="txtsevenbbl">
Cycle Planning</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
This is the first version of Transport Direct�s new cycle planner. We have worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure that there is good quality information on cycling in the following areas:
<ul>
<li> <strong>Merseyside</strong></li>
</ul>
<br />
We would really appreciate your feedback on this initial version of the planner. Please click on �Contact us� at the bottom of the page to let us know what you think or report any problems.
<br /><br />
We will consider all feedback and will be improving the planner over the coming weeks. Work is also ongoing to provide cycle planning information in more areas - please check again soon if your local area is not yet available.
<br /><br />
Our aim is to provide national coverage for cycle planning soon. Once data is available in more areas and we have considered initial feedback, this page will be linked to from the main Transport Direct site.
<br /><br />
</td></tr>
</tbody></table></div>'
,
'<div class="Column3Header"><div class="txtsevenbbl">
Trefnu Taith Feicio</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
Dyma''r fersiwn gyntaf o drefnwr teithiau beicio newydd Transport Direct. Rydym wedi gweithio gyda Cycling England, Arolwg Ordnans a''r awdurdodau lleol perthnasol i sicrhau bod gwybodaeth o ansawdd ar gael am feicio yn yr ardaloedd canlynol:
<ul>
<li> <strong>Glannau Mersi</strong></li>
</ul>
<br />
Byddem yn wirioneddol yn gwerthfawrogi eich adborth am y fersiwn wreiddiol hon o''r trefnwr. Cliciwch ar ''Cysylltwch � ni'' ar waelod y dudalen i roi gwybod inni beth yw eich barn neu adrodd am unrhyw broblemau.
<br /><br />
Byddwn yn ystyried pob adborth ac yn gwella''r trefnwr dros yr wythnosau nesaf. Mae gwaith yn parhau hefyd i roi gwybodaeth i drefnu teithiau beicio mewn mwy o ardaloedd - dewch yn �l eto cyn bo hir os nad yw eich ardal leol ar gael eto.
<br /><br />
Ein nod yw rhoi gwybodaeth ar gyfer trefnu teithiau beicio ledled y genedl cyn bo hir. Pan fydd data ar gael mewn mwy o ardaloedd a phan fyddwn wedi ystyried adborth cychwynnol, bydd prif safle Transport Direct yn cysylltu �''r dudalen hon.
<br /><br />
</td></tr>
</tbody></table></div>'


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1277
SET @ScriptDesc = 'Content changes for Routing Guide and other areas'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO