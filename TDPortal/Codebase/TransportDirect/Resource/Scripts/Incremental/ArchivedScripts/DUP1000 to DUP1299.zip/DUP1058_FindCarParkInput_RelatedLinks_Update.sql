-- *************************************************************************************
-- NAME 		: DUP1058_FindCarParkInput_RelatedLinks_Update.sql
-- DESCRIPTION  : Removed the plan to a car park link from related links on FindCarParkInput
-- AUTHOR		: Amit Patel
-- *************************************************************************************

USE [TransientPortal]
GO

--Remove the link from ContextSuggestionLink table


DECLARE @LinkCategoryID INT, 
	    @SuggestionLinkID INT,
	    @ResourceNameID INT,
	    @LinkResourceName varchar(100),
	    @ContextName varchar(100),
	    @ContextId INT



SET @LinkResourceName = 'FindNearestCarParkPlanTo'
SELECT @LinkCategoryID = LinkCategoryId from LinkCategory WHERE [Name] = 'Related links'
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)

SET @ContextName = 'RelatedLinksContextFindCarInput'

SET @ContextId = (SELECT [ContextId] FROM [dbo].[Context] WHERE [Name] = @ContextName)

DELETE FROM ContextSuggestionLink WHERE ContextId = @ContextId AND SuggestionLinkId = @SuggestionLinkId

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1058
SET @ScriptDesc = 'Removed the plan to a car park link from related links on FindCarParkInput'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO