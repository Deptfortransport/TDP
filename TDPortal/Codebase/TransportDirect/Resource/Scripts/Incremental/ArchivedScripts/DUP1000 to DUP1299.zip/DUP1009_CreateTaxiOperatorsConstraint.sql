-- ***********************************************
-- Name :        DUP1009_CreateTaxiOperatorsConstraint.sql
-- DESCRIPTION : Creates constraint to prevent rows with a TrainTaxiLink value of zero being added
--		 to Taxi_Operators table, which sometimes occurs if the feed has nulls in.
-- ************************************************


USE AtosAdditionalData

----------------------------------------------------------------
-- Drop and re - create the constraint
----------------------------------------------------------------

GO

ALTER TABLE [dbo].[Taxi_Operators] DROP
	CONSTRAINT [CK_Taxi_Operators] 
GO


ALTER TABLE [dbo].[Taxi_Operators] ADD 
	CONSTRAINT [CK_Taxi_Operators] CHECK ([TraintaxiLink] > 0)
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1009
SET @ScriptDesc = 'Create Taxi Operators Constraint'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO