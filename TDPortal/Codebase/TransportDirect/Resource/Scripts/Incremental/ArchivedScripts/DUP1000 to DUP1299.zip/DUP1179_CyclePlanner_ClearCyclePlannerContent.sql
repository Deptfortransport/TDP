-- *************************************************************************************
-- NAME 		: DUP1179_ClearCyclePlannerContent.sql
-- DESCRIPTION  	: Clear Up cycle planner FAQ content.
-- AUTHOR		: Mark Turner
-- DATE CREATED		: 11/11/2008
-- *************************************************************************************

USE [Content]
GO

-------------------------------
-- Crete DeletetblContent Stored Procedure
-------------------------------
CREATE PROCEDURE dbo.[DeletetblContent]
(
	@themeId int,
	@groupId int,
	@controlName varchar(500),
	@propertyName varchar(100)
)
AS
BEGIN
	IF EXISTS (SELECT * FROM [dbo].tblContent 
			WHERE tblContent.PropertyName = @propertyName 
				AND tblContent.ControlName = @controlName 
				AND tblContent.ThemeId = @themeId 
				AND tblContent.GroupId = @groupId )
    	   BEGIN
		DELETE FROM [dbo].tblContent
		WHERE tblContent.PropertyName = @propertyName 
			AND tblContent.ControlName = @controlName 
			AND tblContent.ThemeId = @themeId 
			AND tblContent.GroupId = @groupId
    	   END
END


GO

-------------------------------
-- Clean up the FAQ section 16 cycle planner content
-------------------------------

EXEC DeletetblContent
1, 19, 'TitleText', '/Channels/TransportDirect/Help/HelpCycle'

GO

EXEC DeletetblContent
1, 19, 'Body Text', '/Channels/TransportDirect/Help/HelpCycle'

GO

EXEC DeletetblContent
3, 19, 'Body Text', '/Channels/TransportDirect/Help/HelpCycle'

GO

EXEC DeletetblContent
5, 19, 'Body Text', '/Channels/TransportDirect/Help/HelpCycle'

GO

EXEC DeletetblContent
6, 19, 'Body Text', '/Channels/TransportDirect/Help/HelpCycle'

GO

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle FAQ page - url
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- FAQ Cycle Planning - Normal
EXEC DeletetblContent
1, @GroupId, '_Web2_Help_HelpCycle', 'Page'

EXEC DeletetblContent
1, @GroupId, '_Web2_Help_HelpCycle', 'QueryString'

EXEC DeletetblContent
1, @GroupId, '_Web2_Help_HelpCycle', 'Channel'

-- FAQ Cycle Planning - Printer
EXEC DeletetblContent
1, @GroupId, '_Web2_Printer_HelpCycle', 'Page'

EXEC DeletetblContent
1, @GroupId, '_Web2_Printer_HelpCycle', 'QueryString'

EXEC DeletetblContent
1, @GroupId, '_Web2_Printer_HelpCycle', 'Channel'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1179
SET @ScriptDesc = 'Clear Up cycle planner FAQ content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
