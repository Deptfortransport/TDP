-- ***********************************************
-- NAME 		: DUP1142_Heathrow_Aliases.sql
-- DESCRIPTION 		: Script to add aliases for Heathrow airport to the exchange alias table
-- AUTHOR		: John Frank
-- DATE			: 20 Oct 2008 
-- ************************************************

USE [GAZ]
GO

DELETE FROM gazadmin.ExchangeAlias
WHERE NAPTAN IN ('G38', 'G513', 'G514')
AND RECORD_TYPE = 'G'
GO

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G38', 'Heathrow Airport 123', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G38', 'London Heathrow 123', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G38', 'London Heathrow Airport 123', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G513', 'Heathrow Airport 4', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G513', 'London Heathrow 4', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G513', 'London Heathrow Airport 4', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G514', 'Heathrow Airport 5', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G514', 'London Heathrow 5', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G514', 'London Heathrow Airport 5', 'G')
GO

USE [GAZ_Staging]
GO

DELETE FROM gazadmin.ExchangeAlias
WHERE NAPTAN IN ('G38', 'G513', 'G514')
AND RECORD_TYPE = 'G'
GO

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G38', 'Heathrow Airport 123', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G38', 'London Heathrow 123', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G38', 'London Heathrow Airport 123', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G513', 'Heathrow Airport 4', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G513', 'London Heathrow 4', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G513', 'London Heathrow Airport 4', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G514', 'Heathrow Airport 5', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G514', 'London Heathrow 5', 'G')

INSERT INTO gazadmin.ExchangeAlias (NAPTAN, ALIASNAME, RECORD_TYPE)
VALUES ('G514', 'London Heathrow Airport 5', 'G')
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1142
SET @ScriptDesc = 'Script to add Heathrow Airport to ExchangeAliases for CCN0483'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO