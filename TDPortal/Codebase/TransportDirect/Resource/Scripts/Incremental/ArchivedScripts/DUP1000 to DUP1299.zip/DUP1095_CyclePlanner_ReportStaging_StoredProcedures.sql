-- ***********************************************
-- NAME 		: DUP1095_CyclePlanner_ReportStaging_StoredProcedures.sql
-- DESCRIPTION 		: Script to add stored procedures to create CyclePlannerEvents
-- AUTHOR		: Mitesh Modi
-- DATE			: 20 Aug 2008
-- ************************************************

USE [ReportStagingDB]
GO


-- ****IMPORTANT****
-- If running this script in the dev environment, please remove the value "ReportServer." 
-- where it occurs, (x instances) in this script

----------------------------------------------------------------
-- Create AddCyclePlannerRequestEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddCyclePlannerRequestEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddCyclePlannerRequestEvent 
        (@CyclePlannerRequestId varchar(50), 
         @Cycle bit, 
         @SessionId varchar(50), 
         @UserLoggedOn bit, 
         @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update AddCyclePlannerRequestEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE AddCyclePlannerRequestEvent (@CyclePlannerRequestId varchar(50), @Cycle bit, @SessionId varchar(50), @UserLoggedOn bit, @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into CyclePlannerRequestEvent Table'

    Insert into CyclePlannerRequestEvent (CyclePlannerRequestId, Cycle, SessionId, UserLoggedOn, TimeLogged)
    Values (@CyclePlannerRequestId, @Cycle, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Create AddCyclePlannerResultEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddCyclePlannerResultEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddCyclePlannerResultEvent 
        (@CyclePlannerRequestId varchar(50), 
         @ResponseCategory varchar(50), 
         @SessionId varchar(50), 
         @UserLoggedOn bit, 
         @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update AddCyclePlannerResultEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE AddCyclePlannerResultEvent (@CyclePlannerRequestId varchar(50), @ResponseCategory varchar(50), @SessionId varchar(50), @UserLoggedOn bit, @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into CyclePlannerResultEvent Table'

    Insert into CyclePlannerResultEvent (CyclePlannerRequestId, ResponseCategory, SessionId, UserLoggedOn, TimeLogged)
    Values (@CyclePlannerRequestId, @ResponseCategory, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO







----------------------------------------------------------------
-- Create TransferCyclePlannerEvents stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferCyclePlannerEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE dbo.TransferCyclePlannerEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferCyclePlannerEvents stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE dbo.TransferCyclePlannerEvents
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

--DELETE FROM ReportServer.Reporting.dbo.CyclePlannerEvents
DELETE FROM Reporting.dbo.CyclePlannerEvents
WHERE CONVERT(varchar(10), CPEDate, 121) = @Date

--INSERT INTO ReportServer.Reporting.dbo.CyclePlannerEvents
INSERT INTO Reporting.dbo.CyclePlannerEvents
(
	CPEDate,
	CPEHour,
	CPEHourQuarter,
	CPEWeekDay,
    CPEResponseTypeId,
	CPELoggedOn,
	CPECount,
	CPEAvMsDuration
)
SELECT Cast(Convert(varchar(10), CPRQE.TimeLogged, 121) AS datetime) CPEDate,
       DatePart(hour, CPRQE.TimeLogged) AS                           CPEHour,
       Cast(DatePart(minute, CPRQE.TimeLogged) / 15 AS smallint)     CPEHourQuarter,
       DatePart(weekday, CPRQE.TimeLogged)                           CPEWeekDay,
       JPRT.JPRTID                                                   CPEJPRTID,
       CPRQE.UserLoggedOn                                            CPQELoggedOn,
       Count(*)                                                      CPECount,
       Avg(IsNull(Cast(DateDiff(ms, CPRQE.TimeLogged, CPRSE.TimeLogged) AS decimal(18, 0)), 0)) AS CPEAvMsDuration
  FROM CyclePlannerRequestEvent CPRQE
 INNER JOIN CyclePlannerResultEvent CPRSE 
         ON CPRQE.CyclePlannerRequestId = CPRSE.CyclePlannerRequestId
--LEFT JOIN ReportServer.Reporting.dbo.JourneyPlanResponseType JPRT 
  LEFT JOIN Reporting.dbo.JourneyPlanResponseType JPRT 
         ON CPRSE.ResponseCategory = JPRT.JPRTCode
 WHERE Convert(varchar(10), CPRQE.TimeLogged, 121) = @Date
   AND CPRQE.Cycle = 1
 GROUP BY Cast(Convert(varchar(10), CPRQE.TimeLogged, 121) AS datetime),
          DatePart(hour, CPRQE.TimeLogged),
          Cast(DatePart(minute, CPRQE.TimeLogged) / 15 AS smallint),
          DatePart(weekday, CPRQE.TimeLogged),
          JPRT.JPRTID,
          CPRQE.UserLoggedOn

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1095
SET @ScriptDesc = 'Add ReportStaging stored procedures for CyclePlannerEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO