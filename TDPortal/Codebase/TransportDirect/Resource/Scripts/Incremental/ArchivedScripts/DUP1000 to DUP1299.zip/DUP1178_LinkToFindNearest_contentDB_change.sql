-- ***********************************************
-- NAME 		: DUP1178_LinkToFindNearest_contentDB_change.sql
-- DESCRIPTION 		: Script to change entries in the Content DB for CCN471
-- AUTHOR		: Phil Scott
-- DATE			: 07 Oct 2008 
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1,
 'langStrings',
 'JourneyPlannerOutput.CJPPartialReturnAmend',
 'Sorry we are unable to obtain public transport options for your journey. There are several possible reasons and solutions you may wish to consider:<br />
<ul class="listerdisc"><li>Public transport options may be available but not using the date, time or transport preferences you have specified - click the ''Amend'' button to revise your journey request.<br /></li>
<li>Some travel information supplied to us could be incorrect - if you suspect this, please help us to investigate further by <a href="targetUrlContactPage">submitting a feedback form.</a></li></ul>',
 'Sorry we are unable to obtain public transport options for your journey. There are several possible reasons and solutions you may wish to consider:<br />
<ul class="listerdisc"><li>Public transport options may be available but not using the date, time or transport preferences you have specified - click the ''Amend'' button to revise your journey request.<br /></li>
<li>Some travel information supplied to us could be incorrect - if you suspect this, please help us to investigate further by <a href="targetUrlContactPage">submitting a feedback form.</a></li></ul>'

GO

EXEC AddtblContent
1, 1,
 'langStrings',
 'JourneyPlannerOutput.JourneyWebNoResults',
 'Sorry we are unable to obtain transport options for your journey. There are several possible reasons and solutions you may wish to consider:<br />
<ul class="listerdisc"><li>Public transport options may be available but not using the date, time or transport preferences you have specified - click the ''Amend'' button to revise your journey request.<br /></li>
<li>Some travel information supplied to us could be incorrect - if you suspect this, please help us to investigate further by <a href="targetUrlContactPage">submitting a feedback form.</a></li></ul>',
 'Sorry we are unable to obtain transport options for your journey. There are several possible reasons and solutions you may wish to consider:<br />
<ul class="listerdisc"><li>Public transport options may be available but not using the date, time or transport preferences you have specified - click the ''Amend'' button to revise your journey request.<br /></li>
<li>Some travel information supplied to us could be incorrect - if you suspect this, please help us to investigate further by <a href="targetUrlContactPage">submitting a feedback form.</a></li></ul>'
GO

EXEC AddtblContent
1, 1,
 'langStrings',
 'JourneyPlannerOutput.CJPPartialReturnAmendFindNearest',
 '<ul class="listerdisc"><li>Alternatively, your intended origin or destination may have limited or no public transport services. <a href="targetUrlFindNearest">Click here for the Find nearest link to identify the closest public transport stations and airport to construct a composite Drive and Ride journey.</a></li></ul>',
 '<ul class="listerdisc"><li>Alternatively, your intended origin or destination may have limited or no public transport services. <a href="targetUrlFindNearest">Click here for the Find nearest link to identify the closest public transport stations and airport to construct a composite Drive and Ride journey.</a></li></ul>'
GO



----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1178
SET @ScriptDesc = 'Script to change entries in the Content DB for CCN471'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO