-- ***********************************************
-- NAME 		: DUP1183_ContentDB_AboutUs_Title.sql
-- DESCRIPTION 		: Add h1 tags around the title for the partner sites. 
-- AUTHOR		: John Frank
-- ************************************************

Use Content
go

EXEC AddtblContent
3, 19, 'TitleText', '/Channels/TransportDirect/About/AboutUs', '<h1>About Transport Direct</h1>', '<h1>cy About Transport Direct</h1>'

EXEC AddtblContent
2, 19, 'TitleText', '/Channels/TransportDirect/About/AboutUs', '<h1>About Transport Direct</h1>', '<h1>cy About Transport Direct</h1>'

EXEC AddtblContent
5, 19, 'TitleText', '/Channels/TransportDirect/About/AboutUs', '<h1>About Transport Direct</h1>', '<h1>cy About Transport Direct</h1>'


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1183
SET @ScriptDesc = 'About Us Titles'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------