-- ***********************************************
-- NAME 		: DUP1146_Content_Update_for_ArrivalBoardImage.sql
-- DESCRIPTION 		: Script to add URLs  for Arrival board 
-- AUTHOR		: Phil Scott
-- DATE			: 17 OCT 2008 15:00:00
-- ************************************************

USE [Content]
GO


EXEC AddtblContent 1,1,'LangStrings','JourneyDetailsControl.imageArrivalBoardUrl',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/arrivals2.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/arrivals2.gif'




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1146
SET @ScriptDesc = ' Script to add URLs  for Arrival board '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO