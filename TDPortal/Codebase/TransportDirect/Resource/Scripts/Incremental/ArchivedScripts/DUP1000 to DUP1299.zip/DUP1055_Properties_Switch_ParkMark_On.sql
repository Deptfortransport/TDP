-- ***********************************************
-- NAME 		: DUP1055_Properties_Switch_ParkMark_On.sql
-- DESCRIPTION 		: Script turn ParkMark on for CarParks
-- AUTHOR		: Neil Rankin
-- DATE			: 11 July 2008 12:00
-- ************************************************

-----------------------------------------------------
-- Properties --
-----------------------------------------------------

USE [PermanentPortal]
Go

UPDATE dbo.properties SET
		pValue = 'True' 
		WHERE pName like '%FindCarParkResults.Information.ShowIsSecureLogo%'
Go

UPDATE dbo.properties SET
		pValue = 'True' 
		WHERE pName like '%FindCarParkResults.ShowIsSecure%'
Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1055
SET @ScriptDesc = 'Script turn ParkMark on for CarParks'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO