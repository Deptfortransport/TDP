-- ***********************************************
-- NAME 		: DUP1287_Welsh_Translations.sql
-- DESCRIPTION 		: Script to add Welsh Translations
-- AUTHOR		: John Frank
-- DATE			: 09 Feb 2009
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1,1, 'langstrings', 'JourneyPlannerOutput.JourneyWebNoResults', 
'Sorry we are unable to obtain transport options for your journey. There are several possible reasons and solutions you may wish to consider:<br />
<ul class="listerdisc"><li>Public transport options may be available but not using the date, time or transport preferences you have specified - click the ''Amend'' button to revise your journey request.<br /></li>
<li>Some travel information supplied to us could be incorrect - if you suspect this, please help us to investigate further by <a href="targetUrlContactPage">submitting a feedback form.</a></li></ul>',
'Mae''n ddrwg gennym, ni allwn gael dewisiadau trafnidiaeth ar gyfer eich siwrnai chi. Mae sawl rheswm ac ateb posibl y gallech eu hystyried:<br />
<ul class="listerdisc"><li>Efallai bod dewisiadau trafnidiaeth ar gael ond heb y dyddiad, amser neu ddewisiadau trafnidiaeth rydych chi wedi''u nodi - cliciwch y botwm ''Diwygio'' i adolygu eich cais am siwrnai.<br /></li>
<li>Gallai rhywfaint o wybodaeth am deithio a gyflenwir i ni fod yn anghywir - os ydych yn amau hyn, a wnewch chi ein helpu i ymchwilio ymhellach drwy <a href="targetUrlContactPage">gyflwyno ffurflen adborth.</a></li></ul>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1287
SET @ScriptDesc = 'Welsh content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO