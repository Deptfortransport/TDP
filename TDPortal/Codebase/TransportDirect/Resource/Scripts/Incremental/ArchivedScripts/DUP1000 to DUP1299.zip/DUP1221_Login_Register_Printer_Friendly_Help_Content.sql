-- ***********************************************
-- NAME 		: DUP1221_Login_Register_Printer_Friendly_Help_Content.sql
-- DESCRIPTION 		: Login Register Printer Friendly Help Page Soft Content
-- AUTHOR		: Amit Patel
-- DATE			: 07 January 2009
-- ************************************************

USE [Content]
GO

-- login page printer friendly help page's page, querystring and channel content
EXEC AddtblContent
1, 2, '_web2_printer_helploginregister', 'Page'
,'/Web2/helpfulljp.aspx'
,'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, 2, '_web2_printer_helploginregister', 'QueryString'
,'helpfulljp'
,'helpfulljp'

EXEC AddtblContent
1, 2, '_web2_printer_helploginregister', 'Channel'
,'/Channels/TransportDirect/Printer/HelpLoginRegister'
,'/Channels/TransportDirect/Printer/HelpLoginRegister'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1221
SET @ScriptDesc = 'Login Register Printer Friendly Help Page Soft Content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO