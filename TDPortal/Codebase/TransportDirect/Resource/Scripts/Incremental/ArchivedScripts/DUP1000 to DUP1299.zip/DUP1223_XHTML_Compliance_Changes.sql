-- ***********************************************
-- NAME 		: DUP1223_XHTML_Compliance_Changes.sql
-- DESCRIPTION 		: Update content to be XHTML Compliance
-- AUTHOR		: Tej Sohal
-- DATE			: 18 December 2008
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindAStationInput'
,'<p><strong>To find nearest stations/airports:</strong></p>
<p><br />1. Select the type(s) of stations/airports you would like to find by ticking the tick boxes</p>
<p><br />2. Select the type of location you would like to find stations/airports near by clicking ''Town/district/village'', ''Address/postcode'', or ''Facility/attraction''</p>
<p><br />3. Enter the location would like to find stations/airports near and click ''Next''</p>
<p><br />4. Confirm the location (if prompted), and click ''Next''</p>'
, '<p><strong>I ddod o hyd i''r gorsafoedd/meysydd awyr agosaf:</strong></p>
<p><br />1. Dewiswch y math(au) o orsafoedd/meysydd awyr yr hoffech ddod o hyd iddynt drwy dicio''r blycha</p>
<p><br />2. Dewiswch y math o leoliad yr hoffech ddod o hyd i orsafoedd/meysydd awyr yn agos iddo drwy glicio ''Tref/rhanbarth/pentref'', ''Cyfeiriad/c�d post'', neu ''Cyfleuster/atyniad''</p>
<p><br />3. Nodwch y lleoliad yr hoffech ddod o hyd i orsafoedd/meysydd awyr yn agos iddo a chliciwch ''Nesaf''</p>
<p><br />4. Cadarnhewch y lleoliad (os gofynnir i chi wneud hynny), a chliciwch ''Nesaf''</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindAStationInput'
,'<p><strong>To find nearest stations/airports:</strong></p>
<p><br />1. Select the type(s) of stations/airports you would like to find by ticking the tick boxes</p>
<p><br />2. Select the type of location you would like to find stations/airports near by clicking ''Town/district/village'', ''Address/postcode'', or ''Facility/attraction''</p>
<p><br />3. Enter the location would like to find stations/airports near and click ''Next''</p>
<p><br />4. Confirm the location (if prompted), and click ''Next''</p>'
, '<p><strong>I ddod o hyd i''r gorsafoedd/meysydd awyr agosaf:</strong></p>
<p><br />1. Dewiswch y math(au) o orsafoedd/meysydd awyr yr hoffech ddod o hyd iddynt drwy dicio''r blycha</p>
<p><br />2. Dewiswch y math o leoliad yr hoffech ddod o hyd i orsafoedd/meysydd awyr yn agos iddo drwy glicio ''Tref/rhanbarth/pentref'', ''Cyfeiriad/c�d post'', neu ''Cyfleuster/atyniad''</p>
<p><br />3. Nodwch y lleoliad yr hoffech ddod o hyd i orsafoedd/meysydd awyr yn agos iddo a chliciwch ''Nesaf''</p>
<p><br />4. Cadarnhewch y lleoliad (os gofynnir i chi wneud hynny), a chliciwch ''Nesaf''</p>'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareDateSelection.SingleNote'
,'Notes:<br />� Availability is not guaranteed at this stage.<br />� "*" means that all the fares for that date are unlikely to be available.'
, 'Nodiadau:<br />� Ni ellir gwarantu fod y tocynnau ar gael ar hyn o bryd.<br />� Mae "*" yn golygu bod yr holl docynnau ar gyfer y cyfuniad o ddyddiad hwnnw yn annhebyg o fod ar gael.'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareDateSelection.ReturnSinglesNote'
,'Notes:<br />� Some fares shown may be a combination of two single fares.<br />� Availability is not guaranteed at this stage.<br />� "*" means that all the fares for that date are unlikely to be available.'
, 'Nodiadau:<br />� Gall rhai tocynnau fod yn gyfuniad o ddau docyn sengl.<br />�  Ni ellir gwarantu fod y tocynnau ar gael ar hyn o bryd.<br />� Mae "*" yn golygu bod yr holl docynnau ar gyfer y cyfuniad o ddyddiad hwnnw yn annhebyg o fod ar gael.'

EXEC AddtblContent
1, 1, 'FindAFare', 'FindFareDateSelectionHelpLabel'
,'To view more information about fares such as ticket types, expected availability, etc.:<br />���1. Select a date and type of transport<br />���2. Click ''Next''<br /><br />To sort the information in the columns either:<br /> � Click on the arrow next to the column being sorted to reverse the order of that column<br /> � Click on an underlined column header to sort that column<br /><br />'
, 'I weld mwy o wybodaeth am docynnau fel math o docyn, argaeledd disgwyliedig ac ati:<br />���1. Dewiswch ddyddiad a math o gludiant<br />���2. Cliciwch ''Nesaf''<br /><br />I ddidoli''r wybodaeth yn y colofnau naill ai:<br /> � Cliciwch ar y saeth ger y golofn sy''n cael ei didoli i wyrdroi trefn y golofn honno<br /> � Cliciwch ar bennawd colofn sydd wedi ei danlinellu i ddidoli''r golofn honno<br /><br />'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissions.imageSpacer.AlternateText'
,'Spacer'
,'cy Spacer'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpJourneyEmissionsCompare'
,'<h3>CO2 emissions Compare Distance Screen</h3><br /><br />
<p>1.&nbsp;Enter the distance which you would like to compare CO2 emissions for.</p><br />
<p>2.&nbsp;Select either miles or kilometres and click ''Next''.</p>'
,'<h3>Allyriadau CO2 Sgrin Cymharu Pellter </h3><br /><br />
<p>1. Nodwch y pellter yr hoffech gymharu allyriadau CO2 ar ei gyfer. </p><br />
<p>2. Dewiswch naill ai milltiroedd neu gilometrau a chlicio "Nesaf".</p>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyEmissionsCompare'
,'<h3>CO2 emissions Compare Distance Screen</h3><br /><br />
<p>1.&nbsp;Enter the distance which you would like to compare CO2 emissions for.</p><br />
<p>2.&nbsp;Select either miles or kilometres and click ''Next''.</p>'
,'<h3>Allyriadau CO2 Sgrin Cymharu Pellter </h3><br /><br />
<p>1. Nodwch y pellter yr hoffech gymharu allyriadau CO2 ar ei gyfer. </p><br />
<p>2. Dewiswch naill ai milltiroedd neu gilometrau a chlicio "Nesaf".</p>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelLocationSelect'
,'To see a traffic map for a specific location:<br />    1.    Enter the location you want to see on the map, and click ''Next''<br />    2.    Confirm the location (if prompted), and click ''Next''<br />    3.    The map will appear below, defaulting to the current date and time<br />     4.    You may then change when you want to see traffic levels for (date/time drop-down lists will be provided)<br /><br />'
,'I weld map trafnidiaeth ar gyfer lleoliad penodol:<br />    1.    Rhowch y lleoliad y dymunwch ei weld ar y map, a chliciwch ''Nesa''<br />    2.    Cadarnhewch y lleoliad (os gofynnir i chi) a chliciwch ''Nesa''<br />    3.    Bydd y map yn ymddangos isod, gan roi''r dyddiad a''r amser cyfredol fel dewis diofyn<br />     4.    Gallwch wedyn newid pan ddymunwch weld y lefelau trafnidiaeth ar gyfer (darperir rhestrau o amserau/dyddiadau a ollyngir i lawr)<br /><br />'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpEnteringLocationsTraffic'
,'<h1>Finding a traffic map</h1>
<p>&nbsp;</p>
<p>Traffic maps show you the various levels of traffic that typically occur in a given location or area, on a specific date and time.</p>
<p>&nbsp;</p>
<p>You must:</p>
<ol class="numberlist">
<li>Find a location/area for which to view a map of the traffic levels </li>
<li>Select the date and time of the traffic levels you want to view</li></ol>
<p><strong>To find a location/area for which to view a map of the traffic levels:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Select what type of location you are going to type in</strong><br />&nbsp;<br /></p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br />e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible <p></p>
<p>&nbsp;</p></li>
<li><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet,<br />e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations,<br />e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br />e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br />e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Type the location name in the box</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.<br />&nbsp;<br />If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.<br />&nbsp;<br />If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p> 
<p class="helpindent2">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>To select the date and time of the traffic levels you want to view:</strong></p>
<ol class="numberlist">
<li>Select a day and a month/year from the drop-down lists, or click ''Calendar'', and select a date from it </li>
<li>Select a time from hours and minutes drop-down lists </li>
<li>Click ''Show on map''</li></ol>'
,
'<h1>Darganfod map trafnidiaeth</h1>
<p>&nbsp;</p>
<p>Dengys mapiau trafnidiaeth lefelau amrywiol y drafnidiaeth sy''n digwydd fel arfer mewn lleoliad neu ardal a roddir, ar ddyddiad ac amser penodol.</p>
<p>&nbsp;</p>
<p>Rhaid i chi:</p>
<ol class="numberlist">
<li>Ddod o hyd i leoliad/ardal i weld map o''u lefelau trafnidiaeth </li>
<li>Ddewis dyddiad ac amser lefelau trafnidiaeth y dymunwch edrych arnynt</li></ol>
<p><strong>I ddarganfod lleoliad/ardal i edrych ar fap o''r lefelau trafnidiaeth ar eu cyfer:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Dewiswch pa fath o leoliad yr ydych yn mynd i''w deipio</strong><br />&nbsp;<br /></p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br />e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl <p></p>
<p>&nbsp;</p></li>
<li><strong>''Tref/rhanbarth/pentref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br />e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Cyfleuster/atyniad'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br />e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br />e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br />e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Teipiwch enw''r lleoliad yn y blwch</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig<br />&nbsp;<br />Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.<br />&nbsp;<br />Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag y gwyddoch a rhowch * ar �l y llythrennau. </p>
<p class="helpindent2">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>I ddewis dyddiad ac amser lefelau''r drafnidiaeth yr ydych yn dymuno eu gweld:</strong></p>
<ol class="numberlist">
<li>Dewiswch ddiwrnod a mis/blwyddyn o''r rhestrau a ollyngir i lawr, neu cliciwch ar ''Calendr'', a dewiswch ddyddiad ohono </li>
<li>Dewiswch amser o restrau''r oriau a''r munudau a ollyngir i lawr </li>
<li>Cliciwch ''Dangoswch ar y map''</li></ol>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEnteringLocationsTraffic'
,'<h1>Finding a traffic map</h1>
<p>&nbsp;</p>
<p>Traffic maps show you the various levels of traffic that typically occur in a given location or area, on a specific date and time.</p>
<p>&nbsp;</p>
<p>You must:</p>
<ol class="numberlist">
<li>Find a location/area for which to view a map of the traffic levels </li>
<li>Select the date and time of the traffic levels you want to view</li></ol>
<p><strong>To find a location/area for which to view a map of the traffic levels:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Select what type of location you are going to type in</strong><br/>&nbsp;<br/></p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible <p></p>
<p>&nbsp;</p></li>
<li><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet,<br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Type the location name in the box</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.<br/>&nbsp;<br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.<br/>&nbsp;<br/>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters. </p>
<p class="helpindent2">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>To select the date and time of the traffic levels you want to view:</strong></p>
<ol class="numberlist">
<li>Select a day and a month/year from the drop-down lists, or click ''Calendar'', and select a date from it </li>
<li>Select a time from hours and minutes drop-down lists </li>
<li>Click ''Show on map''</li></ol>'
,'<h1>Darganfod map trafnidiaeth</h1>
<p>&nbsp;</p>
<p>Dengys mapiau trafnidiaeth lefelau amrywiol y drafnidiaeth sy''n digwydd fel arfer mewn lleoliad neu ardal a roddir, ar ddyddiad ac amser penodol.</p>
<p>&nbsp;</p>
<p>Rhaid i chi:</p>
<ol class="numberlist">
<li>Ddod o hyd i leoliad/ardal i weld map o''u lefelau trafnidiaeth </li>
<li>Ddewis dyddiad ac amser lefelau trafnidiaeth y dymunwch edrych arnynt</li></ol>
<p><strong>I ddarganfod lleoliad/ardal i edrych ar fap o''r lefelau trafnidiaeth ar eu cyfer:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Dewiswch pa fath o leoliad yr ydych yn mynd i''w deipio</strong><br/>&nbsp;<br/></p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl <p></p>
<p>&nbsp;</p></li>
<li><strong>''Tref/rhanbarth/pentref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Cyfleuster/atyniad'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Teipiwch enw''r lleoliad yn y blwch</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig<br/>&nbsp;<br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.<br/>&nbsp;<br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag y gwyddoch a rhowch * ar �l y llythrennau. </p>
<p class="helpindent2">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>I ddewis dyddiad ac amser lefelau''r drafnidiaeth yr ydych yn dymuno eu gweld:</strong></p>
<ol class="numberlist">
<li>Dewiswch ddiwrnod a mis/blwyddyn o''r rhestrau a ollyngir i lawr, neu cliciwch ar ''Calendr'', a dewiswch ddyddiad ohono </li>
<li>Dewiswch amser o restrau''r oriau a''r munudau a ollyngir i lawr </li>
<li>Cliciwch ''Dangoswch ar y map''</li></ol>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelToolsSecond'
,'To change when you see traffic levels for:<br />1.	Select a date<br />2.	Select a time<br />3.	Click ''Show on map''<br /><br />'
,'I newid pan welwch lefelau trafnidiaeth ar gyfer:<br />1.	Dewiswch ddyddiad<br />2.	Dewiswch amser<br />3.	Cliciwch ar ''Dangoswch ar fap''<br /><br />'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpToolsSecond'
,'<h1>Finding a traffic map</h1>
<p>&nbsp;</p>
<p>Traffic maps show you the various levels of traffic that typically occur in a given location or area, on a specific date and time.</p>
<p>&nbsp;</p>
<p>You must:</p>
<ol class="numberlist">
<li>Find a location/area for which to view a map of the traffic levels </li>
<li>Select the date and time of the traffic levels you want to view</li></ol>
<p><strong>To find a location/area for which to view a map of the traffic levels:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Select what type of location you are going to type in</strong><br />&nbsp;<br /></p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br />e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible <p></p>
<p>&nbsp;</p></li>
<li><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet,<br />e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations,<br />e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br />e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br />e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Type the location name in the box</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.<br />&nbsp;<br />If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.<br />&nbsp;<br />If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.</p> 
<p class="helpindent2">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>To select the date and time of the traffic levels you want to view:</strong></p>
<ol class="numberlist">
<li>Select a day and a month/year from the drop-down lists, or click ''Calendar'', and select a date from it </li>
<li>Select a time from hours and minutes drop-down lists </li>
<li>Click ''Show on map''</li></ol>'
,
'<h1>Darganfod map trafnidiaeth</h1>
<p>&nbsp;</p>
<p>Dengys mapiau trafnidiaeth lefelau amrywiol y drafnidiaeth sy''n digwydd fel arfer mewn lleoliad neu ardal a roddir, ar ddyddiad ac amser penodol.</p>
<p>&nbsp;</p>
<p>Rhaid i chi:</p>
<ol class="numberlist">
<li>Ddod o hyd i leoliad/ardal i weld map o''u lefelau trafnidiaeth </li>
<li>Ddewis dyddiad ac amser lefelau trafnidiaeth y dymunwch edrych arnynt</li></ol>
<p><strong>I ddarganfod lleoliad/ardal i edrych ar fap o''r lefelau trafnidiaeth ar eu cyfer:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Dewiswch pa fath o leoliad yr ydych yn mynd i''w deipio</strong><br />&nbsp;<br /></p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br />e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl <p></p>
<p>&nbsp;</p></li>
<li><strong>''Tref/rhanbarth/pentref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br />e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Cyfleuster/atyniad'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br />e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br />e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br />e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Teipiwch enw''r lleoliad yn y blwch</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig<br />&nbsp;<br />Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.<br />&nbsp;<br />Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag y gwyddoch a rhowch * ar �l y llythrennau. </p>
<p class="helpindent2">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>I ddewis dyddiad ac amser lefelau''r drafnidiaeth yr ydych yn dymuno eu gweld:</strong></p>
<ol class="numberlist">
<li>Dewiswch ddiwrnod a mis/blwyddyn o''r rhestrau a ollyngir i lawr, neu cliciwch ar ''Calendr'', a dewiswch ddyddiad ohono </li>
<li>Dewiswch amser o restrau''r oriau a''r munudau a ollyngir i lawr </li>
<li>Cliciwch ''Dangoswch ar y map''</li></ol>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpToolsSecond'
,'<h1>Finding a traffic map</h1>
<p>&nbsp;</p>
<p>Traffic maps show you the various levels of traffic that typically occur in a given location or area, on a specific date and time.</p>
<p>&nbsp;</p>
<p>You must:</p>
<ol class="numberlist">
<li>Find a location/area for which to view a map of the traffic levels </li>
<li>Select the date and time of the traffic levels you want to view</li></ol>
<p><strong>To find a location/area for which to view a map of the traffic levels:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Select what type of location you are going to type in</strong><br/>&nbsp;<br/></p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible <p></p>
<p>&nbsp;</p></li>
<li><strong>''Town/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet,<br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Type the location name in the box</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.<br/>&nbsp;<br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.<br/>&nbsp;<br/>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters. </p>
<p class="helpindent2">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>To select the date and time of the traffic levels you want to view:</strong></p>
<ol class="numberlist">
<li>Select a day and a month/year from the drop-down lists, or click ''Calendar'', and select a date from it </li>
<li>Select a time from hours and minutes drop-down lists </li>
<li>Click ''Show on map''</li></ol>'
,'<h1>Darganfod map trafnidiaeth</h1>
<p>&nbsp;</p>
<p>Dengys mapiau trafnidiaeth lefelau amrywiol y drafnidiaeth sy''n digwydd fel arfer mewn lleoliad neu ardal a roddir, ar ddyddiad ac amser penodol.</p>
<p>&nbsp;</p>
<p>Rhaid i chi:</p>
<ol class="numberlist">
<li>Ddod o hyd i leoliad/ardal i weld map o''u lefelau trafnidiaeth </li>
<li>Ddewis dyddiad ac amser lefelau trafnidiaeth y dymunwch edrych arnynt</li></ol>
<p><strong>I ddarganfod lleoliad/ardal i edrych ar fap o''r lefelau trafnidiaeth ar eu cyfer:</strong></p>
<p><strong></strong>&nbsp;</p>
<p><strong>1. Dewiswch pa fath o leoliad yr ydych yn mynd i''w deipio</strong><br/>&nbsp;<br/></p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl <p></p>
<p>&nbsp;</p></li>
<li><strong>''Tref/rhanbarth/pentref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Cyfleuster/atyniad'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� <p></p>
<p>&nbsp;</p></li>
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Teipiwch enw''r lleoliad yn y blwch</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig<br/>&nbsp;<br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.<br/>&nbsp;<br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag y gwyddoch a rhowch * ar �l y llythrennau. </p>
<p class="helpindent2">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p class="helpindent1">&nbsp;</p>
<p><strong>I ddewis dyddiad ac amser lefelau''r drafnidiaeth yr ydych yn dymuno eu gweld:</strong></p>
<ol class="numberlist">
<li>Dewiswch ddiwrnod a mis/blwyddyn o''r rhestrau a ollyngir i lawr, neu cliciwch ar ''Calendr'', a dewiswch ddyddiad ohono </li>
<li>Dewiswch amser o restrau''r oriau a''r munudau a ollyngir i lawr </li>
<li>Cliciwch ''Dangoswch ar y map''</li></ol>'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1223
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO