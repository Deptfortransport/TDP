-- ***********************************************
-- NAME 		: DUP1113_XHTML_contentDB_change.sql
-- DESCRIPTION 		: Script to change entries in the Content DB for XHTML compliance
-- AUTHOR		: John Frank
-- DATE			: 01 Oct 2008 
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyTypeControl.ImageLargeCar.AlternateText', ' ', ' '
EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyTypeControl.ImageMediumCar.AlternateText', ' ', ' '
EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyTypeControl.ImageSmallCar.AlternateText', ' ', ' '
GO

EXEC AddtblContent
1, 1, 'langStrings', 'CarFuelEfficient.PetrolLogo', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/fuel_costs.gif" alt ="Fuel efficient" />', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/fuel_costs.gif" alt ="cyFuel efficient" />'
EXEC AddtblContent
1, 1, 'langStrings', 'CarCostingDetails.findNearestCarParkLogo', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/finda_CarPark.gif" alt ="Find nearest car parks logo" />', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/finda_CarPark.gif" alt ="Logo darganfod y meysydd parcio agosaf" />'

GO



----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1113
SET @ScriptDesc = 'Script to change entries in the Content DB for XHTML compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO