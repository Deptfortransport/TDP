-- ***********************************************
-- NAME 		: DUP1042_Remove_Waiting_Tip.sql
-- DESCRIPTION 		: Remove a specific tip from 'Tip of the Day'
-- AUTHOR		: D. Scott Angle
-- DATE			: 02 July 2008 10:00:00
-- ************************************************

Use TransientPortal

Delete FROM WaitPageMessageTips
WHERE (WaitPageTipTextEn LIKE '%Get taxi rank information or mini cab phone numbers on your PDA or mobile phone. Click the%') AND (WaitPageTipID = 71) AND (ThemeId = 1)

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1042
SET @ScriptDesc = 'Remove a specific tip from Tip of the Day'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO