-- ***********************************************
-- NAME 		: DUP1172_LinkToFindNearest_contentDB_change.sql    (from 1114  just extended hyperlink for whole message)
-- DESCRIPTION 		: Script to change entries in the Content DB for CCN471
-- AUTHOR		: Phil Scott
-- DATE			: 05 Nov 2008 
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1,
 'langStrings',
 'JourneyPlannerOutput.CJPPartialReturnAmendFindNearest',
 '<br><br>Alternatively, your intended origin or destination may have limited or no public transport services. <A href="targetUrl">Click here for the Find nearest link to identify the closest public transport stations and airport to construct a composite Drive and Ride journey.</A>',
 '<br><br>Alternatively, your intended origin or destination may have limited or no public transport services. <A href="targetUrl">Click here for the Find nearest link to identify the closest public transport stations and airport to construct a composite Drive and Ride journey.</A>'
GO



----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1172
SET @ScriptDesc = 'Script to change entries in the Content DB for CCN471'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO