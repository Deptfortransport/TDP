-- ***********************************************
-- NAME 		: DUP1164_TouristInfo_RelatedSites_LinkSetup_Navigation.sql
-- DESCRIPTION 		: Script to add new Related Sites link for Tourist Info to the suggestion links table
-- AUTHOR		: D. Scott Angle
-- DATE			: 31 Oct 2008
-- ************************************************

USE [TransientPortal]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Tourist Info Related Sites page - suggestion link
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddInternalSuggestionLink

	'About/RelatedSites.aspx#TouristInfo',  -- Relative internal link URL
	'Tourist Information',       		-- Description of internal link. Ensure this is a unique internal link description
	'RelatedSites.TouristInfo',		-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Tourist Information',		        -- English display text. Populate only if adding new ResourceName or updating existing display text
	'cy Tourist Information',		-- Welsh display text. Populate only if adding new ResourceName or updating existing display text	
	'RelatedSites',				-- Category Name (LinkCategory) -- Use 'General' if not a left hand navigation link
	7870,					-- Priority must be unique for the selected CategoryName this link is for
	0,					-- Set to 0 if to be used as a Suggestion/Related Link
	0,					-- Set to 1 if it is a second level Root link
	'RelatedSitesMenu',	                -- Context Name (Context) -- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',					-- Populate only if adding a new ContextName, or updating description
	1					-- Theme this link is added for, use 1 as default

GO


-- Add the new link for the Whitelabel partner sites

-- VisitBritain
EXEC AddContextSuggestionLink

	'RelatedSites.TouristInfo',	-- Resource Name (ResourceName) ResourceNameID 123
	'RelatedSites',			-- Category Name (LinkCategory)
	'RelatedSitesMenu',		-- Context Name (Context)
	2				-- Theme

-- BBC
EXEC AddContextSuggestionLink

	'RelatedSites.TouristInfo',	-- Resource Name (ResourceName) ResourceNameID 123
	'RelatedSites',			-- Category Name (LinkCategory)
	'RelatedSitesMenu',		-- Context Name (Context)
	3				-- Theme

-- DirecGov
EXEC AddContextSuggestionLink

	'RelatedSites.TouristInfo',	-- Resource Name (ResourceName) ResourceNameID 123
	'RelatedSites',			-- Category Name (LinkCategory)
	'RelatedSitesMenu',		-- Context Name (Context)
	5				-- Theme

-- London2012
EXEC AddContextSuggestionLink

	'RelatedSites.TouristInfo',	-- Resource Name (ResourceName) ResourceNameID 123
	'RelatedSites',			-- Category Name (LinkCategory)
	'RelatedSitesMenu',		-- Context Name (Context)
	6				-- Theme

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1144
SET @ScriptDesc = 'Tourist Information - Related Sites left navigation link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO