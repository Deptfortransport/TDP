-- ***********************************************
-- NAME 		: DUP1160_XHTML_Content_corrections.sql
-- DESCRIPTION 		: Script to make corrections to Content for XHTML compliance
-- AUTHOR		: Mitesh Modi
-- DATE			: 30 Oct 2008
-- ************************************************

USE [Content]
GO

-- Map pages Key control
EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblCar', 'Find a<br />car route', 'Canfyddwch<br />lwybr car'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblCitytoCity', 'Compare<br />city-to-city<br />journeys', 'Cymharu siwrneion<br />dinas-i<br />-ddinas'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblCoach', 'Find a<br />coach', 'Canfyddwch<br />fws moethus'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblFindAFare', 'Find a<br />fare', 'Darganfyddwch<br />docyn'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblFlight', 'Find a<br />flight', 'Canfyddwch<br />ehediad'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblMapText', 'Find location and traffic maps.<br />Find station and airport locations.', 'Canfyddwch fapiau lleoliad a thraffig.<br />Canfyddwch leoliadau gorsafoedd a meysydd awyr.'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.lblTrain', 'Find a<br />train', 'Canfyddwch<br />dr�n'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.lblFindAStation', 'Find nearest stations<br />and airports', 'Dod o hyd i''r orsaf/<br />maes awyr agosaf'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.lblNetworkMaps', 'Transport network<br />maps', 'Mapiau''r rhwydwaith <br />cludiant'

EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.lblCitytoCity', 'Compare<br />city-to-city<br />journeys', 'Cymharu<br />siwrneion<br />dinas-i-ddinas'

EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.lblDoorToDoor', 'Door-to-door<br />journey<br />planner', 'Cynlluniwr<br />siwrnai o<br />ddrws-i-ddrws'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.lblFAQ', 'Frequently asked<br />questions', 'Cwestiynau a <br />Ofynnir yn Aml'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.lblFeedback', 'Send us your<br />feedback', 'Anfonwch eich <br />adborth atom'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.lblLinkToUs', 'Link to our<br />website', 'Creu dolen <br />i''n gwefan'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.lblToolbarDownload', 'Download our<br />toolbar', 'Lawrlwythwch ein <br />bar offer'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1160
SET @ScriptDesc = 'XHTML corrections to Content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO