-- *************************************************************************************
-- NAME 		: DUP1083_Add_New_Related_link.sql
-- DESCRIPTION  	: Add Related Link heading and FAQ 'Park Mark' section 6.5 url to
-- DESCRIPTION  	: Find nearest Carpark & Drive to Carpark result screens
-- AUTHOR		: Neil Rankin
-- *************************************************************************************

USE [TransientPortal]
GO

-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks',
	'Related Links',
	'RelatedLinksContextFindCarParkResults',
	1
Go

-- Add the actual related link url
EXEC AddInternalSuggestionLink

	'Help/HelpParking.aspx#A6.5',			
	'FAQ - Park Mark Scheme',			
	'FindCarPark.ParkMarkScheme',			-- Resource Name (ResourceName)
	'What is the Park Mark scheme?',		
	'Beth yw''r cynllun Park Mark?',			
	'Related links',				-- Category Name (LinkCategory)
	1650,						
	0,						
	0,						
	'RelatedLinksContextFindCarParkResults',	-- Context Name (Context)
	'',						
	1						-- Theme
GO

-- Add for VisitBritain Partner
EXEC AddContextSuggestionLink

	'RelatedLinks',
	'Related Links',
	'RelatedLinksContextFindCarParkResults',
	2
Go


EXEC AddContextSuggestionLink

	'FindCarPark.ParkMarkScheme',			-- Resource Name (ResourceName) ResourceNameID 110
	'Related links',				-- Category Name (LinkCategory)
	'RelatedLinksContextFindCarParkResults',	-- Context Name (Context)
	2						-- Theme
GO

-- Add for BBC Partner
EXEC AddContextSuggestionLink

	'RelatedLinks',
	'Related Links',
	'RelatedLinksContextFindCarParkResults',
	3
Go

EXEC AddContextSuggestionLink

	'FindCarPark.ParkMarkScheme',			-- Resource Name (ResourceName) ResourceNameID 110
	'Related links',				-- Category Name (LinkCategory)
	'RelatedLinksContextFindCarParkResults',	-- Context Name (Context)
	3						-- Theme
GO

-- Add for DirecGov Partner
EXEC AddContextSuggestionLink

	'RelatedLinks',
	'Related Links',
	'RelatedLinksContextFindCarParkResults',
	5
Go

EXEC AddContextSuggestionLink

	'FindCarPark.ParkMarkScheme',			-- Resource Name (ResourceName) ResourceNameID 110
	'Related links',				-- Category Name (LinkCategory)
	'RelatedLinksContextFindCarParkResults',	-- Context Name (Context)
	5						-- Theme
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1083
SET @ScriptDesc = 'Add Related Link heading and FAQ Park Mark url to Find nearest Carpark and Drive to Carpark result screens'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO