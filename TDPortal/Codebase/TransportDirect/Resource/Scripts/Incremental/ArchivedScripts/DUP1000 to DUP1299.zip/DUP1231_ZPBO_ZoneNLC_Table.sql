-- ***********************************************
-- NAME 		: DUP1231_ZPBO_ZoneNLC_Table.sql
-- DESCRIPTION 	: Script to create new ZoneNLC table, to be used by ZPBO
-- AUTHOR		: Mitesh Modi
-- DATE			: 05 jan 2009
-- ************************************************


USE [PermanentPortal]
GO

---------------------------------------------------
-- CREATE TABLE - [ZoneNLC]
---------------------------------------------------
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ZoneNLC]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    DROP TABLE [dbo].[ZoneNLC]

END
GO

CREATE TABLE [dbo].[ZoneNLC] (
	[DataSet] [varchar] (200) NOT NULL ,
	[NLC] [varchar] (10) NOT NULL ,
	[NLCDescription] [varchar] (200)NULL ,
    [ZoneGroup] [varchar] (50)NULL 
) ON [PRIMARY]
GO



---------------------------------------------------
-- ADD DATA
---------------------------------------------------

-- Delete all existing data
TRUNCATE TABLE [ZoneNLC]

GO

-- Insert the data
INSERT INTO [ZoneNLC] VALUES ( 'FareTerminalZoneNLC', '1072', 'LONDON TERMINALS', 	'LondonTerminal' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTerminalZoneNLC', '4452', 'LONDON THAMESLINK',	'LondonTerminal' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTerminalZoneNLC', '3087', 'LONDON PADDINGTN',		'LondonTerminal' )

INSERT INTO [ZoneNLC] VALUES ( 'FareUndergroundZoneNLC', '0785', 'ZONE U1* LONDN',	'LondonUnderground' )
INSERT INTO [ZoneNLC] VALUES ( 'FareUndergroundZoneNLC', '0790', 'ZONE U12* LONDN',	'LondonUnderground' )
INSERT INTO [ZoneNLC] VALUES ( 'FareUndergroundZoneNLC', '0792', 'ZONE U1234* LONDN', 'LondonUnderground' )
INSERT INTO [ZoneNLC] VALUES ( 'FareUndergroundZoneNLC', '0070', 'ZONE U6* LONDN', 	'LondonUnderground' )

INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0034', 'ZONE R1234*ZONES', 	'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0035', 'ZONE R1236 ZONES', 	'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0036', 'ZONE R23* ZONES', 	'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0037', 'ZONE R234*ZONES', 	'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0038', 'ZONE R2356 ZONES', 	'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0040', 'ZONE R3456 ZONES', 	'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0054', 'ZONE R4* ZONE', 		'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0057', 'ZONE R456* ZONES', 	'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0059', 'ZONE R6* ZONE', 		'LondonTravelcard' )
INSERT INTO [ZoneNLC] VALUES ( 'FareTravelcardZoneNLC', '0063', 'ZONE R2345 ZONES', 	'LondonTravelcard' )


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1231
SET @ScriptDesc = 'Script to create new ZoneNLC table objects'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO