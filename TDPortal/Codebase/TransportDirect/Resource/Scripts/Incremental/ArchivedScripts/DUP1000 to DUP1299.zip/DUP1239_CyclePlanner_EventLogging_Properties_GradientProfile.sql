-- ***********************************************
-- NAME 		: DUP1239_CyclePlanner_EventLogging_Properties_GradientProfile.sql
-- DESCRIPTION 		: Script to add Gradient Profile event property values
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Jan 2009
-- ************************************************

USE [PermanentPortal]
GO


-- ****** IMPORTANT ******
-- 1) Where indicated, please change the value 'FILE1' value below to 'QUEUE1' for the Production environments
-- ***********************

------------------------------------------------------
-- Update existing custom event properties to also mointor for GRADIENTPROFILEEVENT events

DECLARE @LoggingEventCustom VARCHAR(500)


SET @LoggingEventCustom = ( select pValue from properties 
                            where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the events multiple times if the script is run more than once
    IF not exists ( select top 1 * from properties 
                    where pvalue like '%GRADIENTPROFILEEVENT%' and pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @LoggingEventCustom + ' GRADIENTPROFILEEVENT'
    	where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1
    END
END




SET @LoggingEventCustom = ( select pValue from properties 
                            where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the events multiple times if the script is run more than once
    IF not exists ( select top 1 * from properties 
                    where pvalue like '%GRADIENTPROFILEEVENT%' and pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @LoggingEventCustom + ' GRADIENTPROFILEEVENT'
    	where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and GID = 'ReportDataProvider' and PartnerId = 0 and ThemeId = 1
    END
END




SET @LoggingEventCustom = ( select pValue from properties 
                            where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the events multiple times if the script is run more than once
    IF not exists ( select top 1 * from properties 
                    where pvalue like '%GRADIENTPROFILEEVENT%' and pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @LoggingEventCustom + ' GRADIENTPROFILEEVENT'
    	where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1
    END
END


SET @LoggingEventCustom = ( select pValue from properties 
                            where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the events multiple times if the script is run more than once
    IF not exists ( select top 1 * from properties 
                    where pvalue like '%GRADIENTPROFILEEVENT%' and pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @LoggingEventCustom + ' GRADIENTPROFILEEVENT'
    	where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1
    END
END




------------------------------------------------------
-- GRADIENTPROFILEEVENT setup
delete from properties where pname like 'Logging.Event.Custom.GRADIENTPROFILEEVENT.%'

-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Assembly', 'td.userportal.cycleplannercontrol', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Name', 'GradientProfileEvent', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Trace', 'On', 'Web', 'UserPortal', 0, 1)

insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Assembly', 'td.userportal.cycleplannercontrol', 'EventReceiver', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Name', 'GradientProfileEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)

insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Assembly', 'td.userportal.cycleplannercontrol', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Name', 'GradientProfileEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)

-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Assembly', 'td.userportal.cycleplannercontrol', 'TDRemotingHost', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Name', 'GradientProfileEvent', 'TDRemotingHost', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Publishers', 'FILE1', 'TDRemotingHost', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1239
SET @ScriptDesc = 'Gradient profile event properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO