-- ***********************************************
-- NAME 		: DUP1297_Updated_Car_Parking_Stored_Proc.sql
-- DESCRIPTION 		: Updates sql procedure to get data from CarParks database tables
-- AUTHOR		: Amit Patel
-- ************************************************

-- *****
-- ***** EXECUTE permissions below MUST be checked for each environment prior to implementation
-- *****

USE CarParks
GO

-- Droping the stored procedures before creating them again if they exists in database already

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCarParkAccessPointData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetCarParkAccessPointData]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCarParkAdditionalData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetCarParkAdditionalData]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCarParkOperatorData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetCarParkOperatorData]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCarParkingAdminData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetCarParkingAdminData]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCarParkingData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetCarParkingData]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCarParkingParkAndRideData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetCarParkingParkAndRideData]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetCarParkingRegionData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetCarParkingRegionData]
GO


-- GetCarParkAccessPointData stored procedure


CREATE PROCEDURE dbo.GetCarParkAccessPointData
 @AccessKey int
AS
BEGIN
SELECT

CarParkingAccessPoints.Id,
CarParkingAccessPoints.GeocodeType,
CarParkingAccessPoints.Easting,
CarParkingAccessPoints.Northing,
CarParkingAccessPoints.StreetName,
CarParkingAccessPoints.BarrierInOperation

FROM
	CarParkingAccessPoints 

INNER JOIN DataVersion
	On CarParkingAccessPoints.VersionId = DataVersion.[Id]

WHERE
	CarParkingAccessPoints.Id = @AccessKey and DataVersion.Active = 1
END
GO

-- GetCarParkAdditionalData stored procedure

CREATE PROCEDURE dbo.GetCarParkAdditionalData
 @CarParkingId varchar (50)
AS
BEGIN

SELECT 
	cpOpeningTimes.OpensAt, cpOpeningTimes.ClosesAt, ISNULL(cpCarParkingSpace.totalSpaces,0) NumberOfSpaces, 
	ISNULL(cpAdditional.MaximumWidth,0) MaximumWidth, ISNULL(cpAdditional.MaximumHeight,0) MaximumHeight, 
	cpAdditional.PMSPA, cpAdditional.AdvancedReservationsAvailable,
	ISNULL(cpCarParkingType.Description,'') Description, ISNULL(disabledSpaces.totalDisabledSpaces,0) totalDisabledSpaces
FROM
	CarParkingAdditionalData AS cpAdditional 
	INNER JOIN DataVersion
		ON cpAdditional .VersionId = DataVersion.[Id]
	LEFT JOIN CarParkingOpeningTimes AS cpOpeningTimes 
		ON cpOpeningTimes.CarParkRef = cpAdditional.CarParkingId
	LEFT JOIN (SELECT CarParkRef,SUM(ISNULL(NumberOfSpaces,0)) as totalSpaces
			FROM CarParkingCarParkSpace
			GROUP BY CarParkRef) cpCarParkingSpace 
		ON cpCarParkingSpace.CarParkRef = cpAdditional.CarParkingId
	LEFT JOIN CarParkingCarParkType AS cpCarParkingType 
		ON cpCarParkingType.CarParkRef = cpAdditional.CarParkingId
	LEFT JOIN (SELECT CarParkRef,SUM(ISNULL(NumberOfSpaces,0)) as totalDisabledSpaces
			FROM CarParkingCarParkSpace
			WHERE CarParkingCarParkSpace.Description = 'Disabled' 
				OR CarParkingCarParkSpace.Description = 'Shopmobility'
			GROUP BY CarParkRef) disabledSpaces
		ON disabledSpaces.CarParkRef = cpAdditional.CarParkingId
WHERE
	cpAdditional.CarParkingId= @CarParkingId and DataVersion.Active = 1
END
GO

-- GetCarParkOperatorData stored procedure

CREATE PROCEDURE dbo.GetCarParkOperatorData
 @OperatorKey varchar (50)
AS
BEGIN
SELECT
	CarParkingOperator.OperatorCode, 
	CarParkingOperator.OperatorName, 
	CarParkingOperator.OperatorURL, 
	CarParkingOperator.OperatorTsAndCs, 
	CarParkingOperator.OperatorEmail

FROM
	CarParkingOperator 

INNER JOIN DataVersion
	ON CarParkingOperator.VersionId = DataVersion.[Id]

WHERE
	CarParkingOperator.OperatorCode = @OperatorKey AND DataVersion.Active = 1
END
GO

-- GetCarParkingAdminData stored procedure


CREATE PROCEDURE dbo.GetCarParkingAdminData
 @DistrictKey int

AS
BEGIN
SELECT
	CarParkingNPTGAdminDistrict.Id, 
	CarParkingNPTGAdminDistrict.AdminAreaCode,
	CarParkingNPTGAdminDistrict.DistrictCode

FROM
	CarParkingNPTGAdminDistrict 
INNER JOIN DataVersion
	ON CarParkingNPTGAdminDistrict.VersionId = DataVersion.[Id]

WHERE
	CarParkingNPTGAdminDistrict.Id = @DistrictKey AND DataVersion.Active = 1

END
GO

-- GetCarParkingData stored procudure


CREATE PROCEDURE dbo.GetCarParkingData
@CarParkKey varchar(50)
AS
	BEGIN
    SELECT 
	CarParking.Reference,
	CarParking.OperatorId,
	CarParking.AccessPointsMapId,
	CarParking.AccessPointsEntranceId,
	CarParking.AccessPointsExitId,
	CarParking.TrafficNewsRegionId, 
	CarParking.ParkAndRideSchemeId,
	CarParking.NPTGAdminDistrictId,
	CarParking.Name,
	CarParking.Location,
	CarParking.Address,
	CarParking.Postcode,
	CarParking.Notes,
	CarParking.Telephone,
	CarParking.Url,
	CarParking.MinCost,
	CarParking.ParkAndRide,
	CarParking.StayType,
	CarParking.PlanningPoint,
	CarParking.DateRecordLastUpdated,
	CarParking.WEUDate,
	CarParking.WEFDate

FROM
	CarParking 
INNER JOIN DataVersion 
	ON CarParking.VersionId = DataVersion.[Id]

WHERE Reference = @CarParkKey AND DataVersion.Active = 1

END
GO


-- GetCarParkingParkAndRideData stored procedure

CREATE PROCEDURE dbo.GetCarParkingParkAndRideData
@SchemeKey int
AS
BEGIN
SELECT
	CarParkingParkAndRideScheme.Id, 
	CarParkingParkAndRideScheme.Location, 
	CarParkingParkAndRideScheme.SchemeURL, 
	CarParkingParkAndRideScheme.Comments, 
	CarParkingParkAndRideScheme.LocationEasting, 
	CarParkingParkAndRideScheme.LocationNorthing,
	CarParkingParkAndRideScheme.TransferFrequency, 
	CarParkingParkAndRideScheme.TransferFrom, 
	CarParkingParkAndRideScheme.TransferTo

FROM
	CarParkingParkAndRideScheme 
INNER JOIN DataVersion
	ON CarParkingParkAndRideScheme.VersionId = DataVersion.[Id]

WHERE
	CarParkingParkAndRideScheme.Id = @SchemeKey AND DataVersion.Active = 1
END
GO

-- GetCarParkingRegionData stored procedure

CREATE PROCEDURE dbo.GetCarParkingRegionData
    @RegionKey int
AS
BEGIN
    SELECT
            CPTNR.Id,
            CPTNR.RegionName
            
    FROM
            dbo.CarParkingTrafficNewsRegion as CPTNR
   INNER JOIN DataVersion
	ON CPTNR.VersionId = DataVersion.[Id]

	WHERE
	            CPTNR.Id = @RegionKey AND DataVersion.Active = 1
END

GO


------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1297
SET @ScriptDesc = 'Updates sql procedure to get data from CarParks database tables'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------