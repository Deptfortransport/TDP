-- ***********************************************
-- NAME 		: DUP1175_Update_Tram_Light_Rail_text.sql
-- DESCRIPTION 		: Changing Light rail to Light Rail 
-- AUTHOR		: D. Scott Angle
-- DATE			: 06 November 2008 13:00:00
-- ************************************************



USE [Content]
GO

EXEC AddtblContent
1,1, 'FaresAndTickets', 'TransportMode.tram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'JourneyPlannerService', 'TransportMode.tram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'JourneyResults', 'TransportMode.tram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'langStrings', 'TransportMode.tram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'langStrings', 'TransportMode.tram.ImageAlternateText', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'langStrings', 'MapKeyControl.labelTram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'langStrings', 'MapKeyControl.labelTram.Print', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'langStrings', 'MapKeyControl.MapKeyControlItems.SpecificModes.Tram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'langStrings', 'JourneyAccessibilityLinksControl.ModeName.Tram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO

EXEC AddtblContent
1,1, 'langStrings', 'JourneyAccessibilityLinksControl.TitleText.Tram', 'Tram/Light Rail', 'Tram/Rheilffordd Ysgafn'
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1175
SET @ScriptDesc = 'Update contents so Tram/Light Rail appears in Journey Summarys'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO