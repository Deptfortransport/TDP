-- ***********************************************
-- NAME 		: DUP1276_Add_OnlineRetailer_column_to_Reporting_RetailerHandofftype_Table.sql
-- DESCRIPTION 		: Add OnlineRetailer column to Reporting RetailerHandofftype Table
--					 
-- AUTHOR		: Jps
-- ************************************************


USE [Reporting]
GO

------------------------------------------------------------
-- TABLE MODIFICATIONS
------------------------------------------------------------


ALTER TABLE RetailerHandOffType
ADD [RHTOnlineRetailer] [tinyint] not null DEFAULT 0
GO

----------------------------------------------------------

-- allocate OnlineRetaile flag to 3 and 17 i.e. NXEC and Trainline



UPDATE RetailerHandOffType
   SET RHTOnlineRetailer = 1
  where RHTID = 3 or RHTID = 17

GO


-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)
SET @ScriptNumber = 1276

SET @ScriptDesc = 'Add OnlineRetailer column to Reporting RetailerHandofftype Table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------