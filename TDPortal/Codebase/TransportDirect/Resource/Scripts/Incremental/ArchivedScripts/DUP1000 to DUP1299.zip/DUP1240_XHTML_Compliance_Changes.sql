-- ***********************************************
-- NAME 		: DUP1240_XHTML_Compliance_Changes.sql
-- DESCRIPTION 		: Update content to be XHTML Compliance
-- AUTHOR		: Amit Patel
-- DATE			: 13 January 2008
-- ************************************************

USE [Content]
GO

-- help page content for JourneyAdjust.aspx page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpJourneyAdjust'
,'<h3>Choose where to allow more time in your journey</h3><br/><br/>
<p>If your journey has at least one stage where you need to change transport, you may choose to adjust your journey by allowing more time at a specific interchange point.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey allows 10 minutes to change trains. You would like to allow more than this just in case the first train is delayed.</li>
<li>Choose to "Plan my journey to allow at least 15 minutes at location x" where x is location which currently only allows 10 minutes to make the connection.</li></ul></div></div><br/>
<p>The diagram shows you the journey so far. Select the part(s) of the journey by choosing from the options in the drop down menus. If Javascript is enabled on your browser, then a line will appear on the diagram. This line signifies which part(s) of the journey will be affected by your choices.</p><br/>
<p>When you are happy with your selection, press "Next". This will call the appropriate Transport Direct journey planners to find a new journey plan including your adjustments, which you can compare with your original journey.</p><br/>
<p>If you don''t want to change anything about this journey, press "Back" to see your original journey unchanged.</p><br/>
<div class="boxtypenineinner">
<p>Note: </p>
<p>Please be aware that, when making adjustments to a journey, Transport Direct uses all available transport options allowed for the original journey. This means that the next available connection may take quite a different route to your original journey.</p></div>'
,'<h3>Dewiswch ble i ganiat�u mwy o amser yn eich siwrnai</h3><br/><br/>
<p>Os oes gan eich siwrnai o leiaf un cam lle bydd angen i chi newid cludiant, gallwch ddewis addasu eich siwrnai drwy ganiat�u mwy o amser mewn man rhyng-newid penodol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Mae eich siwrnai wreiddiol yn caniat�u deng munud i newid trenau. Hoffech ganiat�u mwy na hyn rhag ofn bydd y tr�n cyntaf yn cael ei oedi.</li>
<li>Dewiswch ''Cynlluniwch fy siwrnai i ganiat�u o leiaf 15 munud yn lleoliad x" ble mae x yn lleoliad sydd ar hyn o bryd yn caniat�u dim ond 10 munud i wneud y cysylltiad.</li></ul></div></div>
<br/><p>Mae''r diagram yn dangos y siwrnai hyd yma i chi. Dewiswch y rhan(nau) o''r siwrnai drwy ddewis o''r dewisiadau yn y dewislenni a ollyngir i lawr. Os galluogir Javascript ar eich porwr, yna bydd llinell yn ymddangos ar y diagram. Mae''r llinell hon yn nodi pa ran(nau) o''r siwrnai a effeithir gan eich dewisiadau.</p><br/>
<p>Pan ydych yn fodlon gyda''ch dewis, gwasgwch ''Nesaf''. Bydd hyn yn galw''r cynllunwyr siwrneion Transport Direct priodol i ddarganfod cynllun siwrnai newydd gan gynnwys eich addasiadau, y gallwch eu cymharu �''ch siwrnai wreiddiol.</p><br/>
<p>Os nad ydych yn dymuno newid unrhyw beth am y siwrnai hon, gwasgwch ''Yn �l'' i weld eich siwrnai wreiddiol heb ei newid.</p><br/>
<div class="boxtypenineinner">
<p>Noder: </p>
<p>Cofiwch wrth wneud addasiadau i siwrnai, mae Transport Direct yn defnyddio''r holl ddewisiadau cludiant sydd ar gael a ganiateir ar gyfer y siwrnai wreiddiol. Golyga hyn y gall y cysylltiad nesaf sydd ar gael gymryd llwybr cwbl wahanol i''ch siwrnai wreiddiol.</p></div>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyAdjust'
,'<h3>Choose where to allow more time in your journey</h3><br/><br/>
<p>If your journey has at least one stage where you need to change transport, you may choose to adjust your journey by allowing more time at a specific interchange point.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey allows 10 minutes to change trains. You would like to allow more than this just in case the first train is delayed.</li>
<li>Choose to "Plan my journey to allow at least 15 minutes at location x" where x is location which currently only allows 10 minutes to make the connection.</li></ul></div></div><br/>
<p>The diagram shows you the journey so far. Select the part(s) of the journey by choosing from the options in the drop down menus. If Javascript is enabled on your browser, then a line will appear on the diagram. This line signifies which part(s) of the journey will be affected by your choices.</p><br/>
<p>When you are happy with your selection, press "Next". This will call the appropriate Transport Direct journey planners to find a new journey plan including your adjustments, which you can compare with your original journey.</p><br/>
<p>If you don''t want to change anything about this journey, press "Back" to see your original journey unchanged.</p><br/>
<div class="boxtypenineinner">
<p>Note: </p>
<p>Please be aware that, when making adjustments to a journey, Transport Direct uses all available transport options allowed for the original journey. This means that the next available connection may take quite a different route to your original journey.</p></div>'
,'<h3>Dewiswch ble i ganiat�u mwy o amser yn eich siwrnai</h3><br/><br/>
<p>Os oes gan eich siwrnai o leiaf un cam lle bydd angen i chi newid cludiant, gallwch ddewis addasu eich siwrnai drwy ganiat�u mwy o amser mewn man rhyng-newid penodol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Mae eich siwrnai wreiddiol yn caniat�u deng munud i newid trenau. Hoffech ganiat�u mwy na hyn rhag ofn bydd y tr�n cyntaf yn cael ei oedi.</li>
<li>Dewiswch ''Cynlluniwch fy siwrnai i ganiat�u o leiaf 15 munud yn lleoliad x" ble mae x yn lleoliad sydd ar hyn o bryd yn caniat�u dim ond 10 munud i wneud y cysylltiad.</li></ul></div></div>
<br/><p>Mae''r diagram yn dangos y siwrnai hyd yma i chi. Dewiswch y rhan(nau) o''r siwrnai drwy ddewis o''r dewisiadau yn y dewislenni a ollyngir i lawr. Os galluogir Javascript ar eich porwr, yna bydd llinell yn ymddangos ar y diagram. Mae''r llinell hon yn nodi pa ran(nau) o''r siwrnai a effeithir gan eich dewisiadau.</p><br/>
<p>Pan ydych yn fodlon gyda''ch dewis, gwasgwch ''Nesaf''. Bydd hyn yn galw''r cynllunwyr siwrneion Transport Direct priodol i ddarganfod cynllun siwrnai newydd gan gynnwys eich addasiadau, y gallwch eu cymharu �''ch siwrnai wreiddiol.</p><br/>
<p>Os nad ydych yn dymuno newid unrhyw beth am y siwrnai hon, gwasgwch ''Yn �l'' i weld eich siwrnai wreiddiol heb ei newid.</p><br/>
<div class="boxtypenineinner">
<p>Noder: </p>
<p>Cofiwch wrth wneud addasiadau i siwrnai, mae Transport Direct yn defnyddio''r holl ddewisiadau cludiant sydd ar gael a ganiateir ar gyfer y siwrnai wreiddiol. Golyga hyn y gall y cysylltiad nesaf sydd ar gael gymryd llwybr cwbl wahanol i''ch siwrnai wreiddiol.</p></div>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyAdjust'
,'<h3>Choose where to allow more time in your journey</h3><br/><br/>
<p>If your journey has at least one stage where you need to change transport, you may choose to adjust your journey by allowing more time at a specific interchange point.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey allows 10 minutes to change trains. You would like to allow more than this just in case the first train is delayed.</li>
<li>Choose to "Plan my journey to allow at least 15 minutes at location x" where x is location which currently only allows 10 minutes to make the connection.</li></ul></div></div><br/>
<p>The diagram shows you the journey so far. Select the part(s) of the journey by choosing from the options in the drop down menus. If Javascript is enabled on your browser, then a line will appear on the diagram. This line signifies which part(s) of the journey will be affected by your choices.</p><br/>
<p>When you are happy with your selection, press "Next". This will call the appropriate Transport Direct journey planners to find a new journey plan including your adjustments, which you can compare with your original journey.</p><br/>
<p>If you don''t want to change anything about this journey, press "Back" to see your original journey unchanged.</p><br/>
<div class="boxtypenineinner">
<p>Note: </p>
<p>Please be aware that, when making adjustments to a journey, Transport Direct uses all available transport options allowed for the original journey. This means that the next available connection may take quite a different route to your original journey.</p></div>'
,'<h3>Dewiswch ble i ganiat�u mwy o amser yn eich siwrnai</h3><br/><br/>
<p>Os oes gan eich siwrnai o leiaf un cam lle bydd angen i chi newid cludiant, gallwch ddewis addasu eich siwrnai drwy ganiat�u mwy o amser mewn man rhyng-newid penodol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Mae eich siwrnai wreiddiol yn caniat�u deng munud i newid trenau. Hoffech ganiat�u mwy na hyn rhag ofn bydd y tr�n cyntaf yn cael ei oedi.</li>
<li>Dewiswch ''Cynlluniwch fy siwrnai i ganiat�u o leiaf 15 munud yn lleoliad x" ble mae x yn lleoliad sydd ar hyn o bryd yn caniat�u dim ond 10 munud i wneud y cysylltiad.</li></ul></div></div>
<br/><p>Mae''r diagram yn dangos y siwrnai hyd yma i chi. Dewiswch y rhan(nau) o''r siwrnai drwy ddewis o''r dewisiadau yn y dewislenni a ollyngir i lawr. Os galluogir Javascript ar eich porwr, yna bydd llinell yn ymddangos ar y diagram. Mae''r llinell hon yn nodi pa ran(nau) o''r siwrnai a effeithir gan eich dewisiadau.</p><br/>
<p>Pan ydych yn fodlon gyda''ch dewis, gwasgwch ''Nesaf''. Bydd hyn yn galw''r cynllunwyr siwrneion Transport Direct priodol i ddarganfod cynllun siwrnai newydd gan gynnwys eich addasiadau, y gallwch eu cymharu �''ch siwrnai wreiddiol.</p><br/>
<p>Os nad ydych yn dymuno newid unrhyw beth am y siwrnai hon, gwasgwch ''Yn �l'' i weld eich siwrnai wreiddiol heb ei newid.</p><br/>
<div class="boxtypenineinner">
<p>Noder: </p>
<p>Cofiwch wrth wneud addasiadau i siwrnai, mae Transport Direct yn defnyddio''r holl ddewisiadau cludiant sydd ar gael a ganiateir ar gyfer y siwrnai wreiddiol. Golyga hyn y gall y cysylltiad nesaf sydd ar gael gymryd llwybr cwbl wahanol i''ch siwrnai wreiddiol.</p></div>'

GO

-- help page content for JourneyReplanInput.aspx page
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpJourneyReplanInputPage'
,'<h3>Choose which part of the journey to replan</h3><br/><br/>
<p>You have chosen to replan part or all of your journey using the other type of transport (i.e. if your original journey is using public transport, this screen allows you to change part or all of the journey to travel by car).</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>You have planned a journey from your nearest station to a friend''s house. It appears that your friend lives in a village where there are only two buses a day. You choose to replan the last part of your journey from the main station which is local to your friend, to their house, thinking you will probably get a taxi or a lift.</li>
<li>When you press "Next", Transport Direct will find a car journey based on your choices and make this part of your new overall journey plan.</li></ul></div></div>
<p>&nbsp;</p><p>The diagram/table shows you the journey so far. Select the part(s) of the journey you wish to replan by ticking the selection boxes. If Javascript is enabled on your browser, the relevant part(s) of the journey will be highlighted with each selection box you tick. This signifies which part(s) of the journey will be planned using an alternative form of transport. If Javascript is disabled, press "Next" to see which part(s) of the journey have been chosen.</p><br/>
<p>When you are happy with your selection, press "Next". This will call the appropriate Transport Direct journey planners to find a new journey plan.</p><br/>
<p>If you wish to start again, press "Clear page".</p><br/>
<p>If you don''t want change anything about this journey, press "Back" to see your original journey unchanged.</p><br/>
<p>Please be aware that Transport Direct will try to match the departure and arrival times to give you a suitable overall journey. However, if you choose to replace a public transport section of the journey in the middle of a longer overall journey, you may find that the car replacement journey is either shorter or longer in comparison. Transport Direct will leave the other sections of the journey unchanged, which means you may see an overlap of journeys or alternatively, a longer wait at an interchange point.</p>'
,'<h3>Dewiswch pa ran o''r siwrnai i''w hailgynllunio</h3><br/><br/>
<p>Rydych wedi dewis ail-gynllunio rhan neu''r cyfan o''ch siwrnai gan ddefnyddio math arall o gludiant (h.y. os yw eich siwrnai wreiddiol yn defnyddio cludiant cyhoeddus, mae''r sgr�n hon yn caniat�u i chi newid rhan neu''r cyfan o''r siwrnai i''w theithio mewn car).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Rydych wedi cynllunio siwrnai o''ch gorsaf agosaf i dy ffrind. Mae''n ymddangos fod eich ffrind yn byw mewn pentref lle nad oes ond dau fws y dydd. Rydych yn dewis ail-gynllunio rhan olaf eich siwrnai o''r brif orsaf sy''n lleol i''ch ffrind, at dy''r ffrind, gan feddwl y byddwch mae''n debyg yn cael tacsi neu lifft.</li> 
<li>Pan wasgwch ''Nesaf'' bydd Transport Direct yn dod o hyd i siwrnai car yn seiliedig ar eich dewisiadau ac yn gwneud hon yn rhan o''ch cynllun siwrnai gyffredinol newydd.</li></ul></div></div>
<p>&nbsp;</p>
<p>Mae''r diagram/tabl yn dangos y siwrnai hyd yma. Dewiswch y rhan(nau) o''r siwrnai y dymunwch eu hailgynllunio drwy dicio''r blychau dewis. Os galluogir Javascript ar eich porwr, bydd rhan(nau) perthnasol y siwrnai yn cael eu hamlygu gyda phob blwch dewis a diciwch. Mae hyn yn dangos pa ran(nau) o''ch siwrnai a gynllunir gan ddefnyddio ffurf arall o gludiant. Os analluogir Javascript, gwasgwch ''Nesaf'' i weld pa ran(nau) o''r siwrnai sydd wedi eu dewis.</p><br/>
<p>Pan ydych yn hapus gyda''ch dewis, gwasgwch ''Nesaf''. Bydd hyn yn galw''r cynllunwyr siwrneion Transport Direct priodol i ddarganfod cynllun siwrnai newydd.</p><br/>
<p>Os dymunwch ddechrau eto, gwasgwch ''Clirio''r dudalen''.</p><br/>
<p>Os nad ydych eisiau newid unrhyw beth am y siwrnai hon, gwasgwch ''Yn �l'' i weld eich siwrnai wreiddiol heb ei newid.</p><br/>
<p>Cofiwch y bydd Transport Direct yn ceisio cyfateb yr amserau ymadael a chyrraedd i roi siwrnai gyffredinol addas i chi. Ond os dewiswch amnewid adran cludiant cyhoeddus o''r siwrnai yng nghanol siwrnai gyffredinol hwy, efallai y gwelwch y bydd y siwrnai sy''n cael ei hamnewid a deithir mewn car naill ai''n fyrrach neu''n hwy o''i gymharu. Bydd Transport Direct yn gadael adrannau eraill y siwrnai heb eu newid, sy''n golygu y gallwch weld siwrneion yn gor-gyffwrdd neu y bydd raid aros yn hwy mewn pwynt rhyng-newid.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyReplanInputPage'
,'<h3>Choose which part of the journey to replan</h3><br/><br/>
<p>You have chosen to replan part or all of your journey using the other type of transport (i.e. if your original journey is using public transport, this screen allows you to change part or all of the journey to travel by car).</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>You have planned a journey from your nearest station to a friend''s house. It appears that your friend lives in a village where there are only two buses a day. You choose to replan the last part of your journey from the main station which is local to your friend, to their house, thinking you will probably get a taxi or a lift.</li>
<li>When you press "Next", Transport Direct will find a car journey based on your choices and make this part of your new overall journey plan.</li></ul></div></div>
<p>&nbsp;</p><p>The diagram/table shows you the journey so far. Select the part(s) of the journey you wish to replan by ticking the selection boxes. If Javascript is enabled on your browser, the relevant part(s) of the journey will be highlighted with each selection box you tick. This signifies which part(s) of the journey will be planned using an alternative form of transport. If Javascript is disabled, press "Next" to see which part(s) of the journey have been chosen.</p><br/>
<p>When you are happy with your selection, press "Next". This will call the appropriate Transport Direct journey planners to find a new journey plan.</p><br/>
<p>If you wish to start again, press "Clear page".</p><br/>
<p>If you don''t want change anything about this journey, press "Back" to see your original journey unchanged.</p><br/>
<p>Please be aware that Transport Direct will try to match the departure and arrival times to give you a suitable overall journey. However, if you choose to replace a public transport section of the journey in the middle of a longer overall journey, you may find that the car replacement journey is either shorter or longer in comparison. Transport Direct will leave the other sections of the journey unchanged, which means you may see an overlap of journeys or alternatively, a longer wait at an interchange point.</p>'
,'<h3>Dewiswch pa ran o''r siwrnai i''w hailgynllunio</h3><br/><br/>
<p>Rydych wedi dewis ail-gynllunio rhan neu''r cyfan o''ch siwrnai gan ddefnyddio math arall o gludiant (h.y. os yw eich siwrnai wreiddiol yn defnyddio cludiant cyhoeddus, mae''r sgr�n hon yn caniat�u i chi newid rhan neu''r cyfan o''r siwrnai i''w theithio mewn car).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Rydych wedi cynllunio siwrnai o''ch gorsaf agosaf i dy ffrind. Mae''n ymddangos fod eich ffrind yn byw mewn pentref lle nad oes ond dau fws y dydd. Rydych yn dewis ail-gynllunio rhan olaf eich siwrnai o''r brif orsaf sy''n lleol i''ch ffrind, at dy''r ffrind, gan feddwl y byddwch mae''n debyg yn cael tacsi neu lifft.</li> 
<li>Pan wasgwch ''Nesaf'' bydd Transport Direct yn dod o hyd i siwrnai car yn seiliedig ar eich dewisiadau ac yn gwneud hon yn rhan o''ch cynllun siwrnai gyffredinol newydd.</li></ul></div></div>
<p>&nbsp;</p>
<p>Mae''r diagram/tabl yn dangos y siwrnai hyd yma. Dewiswch y rhan(nau) o''r siwrnai y dymunwch eu hailgynllunio drwy dicio''r blychau dewis. Os galluogir Javascript ar eich porwr, bydd rhan(nau) perthnasol y siwrnai yn cael eu hamlygu gyda phob blwch dewis a diciwch. Mae hyn yn dangos pa ran(nau) o''ch siwrnai a gynllunir gan ddefnyddio ffurf arall o gludiant. Os analluogir Javascript, gwasgwch ''Nesaf'' i weld pa ran(nau) o''r siwrnai sydd wedi eu dewis.</p><br/>
<p>Pan ydych yn hapus gyda''ch dewis, gwasgwch ''Nesaf''. Bydd hyn yn galw''r cynllunwyr siwrneion Transport Direct priodol i ddarganfod cynllun siwrnai newydd.</p><br/>
<p>Os dymunwch ddechrau eto, gwasgwch ''Clirio''r dudalen''.</p><br/>
<p>Os nad ydych eisiau newid unrhyw beth am y siwrnai hon, gwasgwch ''Yn �l'' i weld eich siwrnai wreiddiol heb ei newid.</p><br/>
<p>Cofiwch y bydd Transport Direct yn ceisio cyfateb yr amserau ymadael a chyrraedd i roi siwrnai gyffredinol addas i chi. Ond os dewiswch amnewid adran cludiant cyhoeddus o''r siwrnai yng nghanol siwrnai gyffredinol hwy, efallai y gwelwch y bydd y siwrnai sy''n cael ei hamnewid a deithir mewn car naill ai''n fyrrach neu''n hwy o''i gymharu. Bydd Transport Direct yn gadael adrannau eraill y siwrnai heb eu newid, sy''n golygu y gallwch weld siwrneion yn gor-gyffwrdd neu y bydd raid aros yn hwy mewn pwynt rhyng-newid.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpJourneyReplanInputPage'
,'<h3>Choose which part of the journey to replan</h3><br/><br/>
<p>You have chosen to replan part or all of your journey using the other type of transport (i.e. if your original journey is using public transport, this screen allows you to change part or all of the journey to travel by car).</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>You have planned a journey from your nearest station to a friend''s house. It appears that your friend lives in a village where there are only two buses a day. You choose to replan the last part of your journey from the main station which is local to your friend, to their house, thinking you will probably get a taxi or a lift.</li>
<li>When you press "Next", Transport Direct will find a car journey based on your choices and make this part of your new overall journey plan.</li></ul></div></div>
<p>&nbsp;</p><p>The diagram/table shows you the journey so far. Select the part(s) of the journey you wish to replan by ticking the selection boxes. If Javascript is enabled on your browser, the relevant part(s) of the journey will be highlighted with each selection box you tick. This signifies which part(s) of the journey will be planned using an alternative form of transport. If Javascript is disabled, press "Next" to see which part(s) of the journey have been chosen.</p><br/>
<p>When you are happy with your selection, press "Next". This will call the appropriate Transport Direct journey planners to find a new journey plan.</p><br/>
<p>If you wish to start again, press "Clear page".</p><br/>
<p>If you don''t want change anything about this journey, press "Back" to see your original journey unchanged.</p><br/>
<p>Please be aware that Transport Direct will try to match the departure and arrival times to give you a suitable overall journey. However, if you choose to replace a public transport section of the journey in the middle of a longer overall journey, you may find that the car replacement journey is either shorter or longer in comparison. Transport Direct will leave the other sections of the journey unchanged, which means you may see an overlap of journeys or alternatively, a longer wait at an interchange point.</p>'
,'<h3>Dewiswch pa ran o''r siwrnai i''w hailgynllunio</h3><br/><br/>
<p>Rydych wedi dewis ail-gynllunio rhan neu''r cyfan o''ch siwrnai gan ddefnyddio math arall o gludiant (h.y. os yw eich siwrnai wreiddiol yn defnyddio cludiant cyhoeddus, mae''r sgr�n hon yn caniat�u i chi newid rhan neu''r cyfan o''r siwrnai i''w theithio mewn car).</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Rydych wedi cynllunio siwrnai o''ch gorsaf agosaf i dy ffrind. Mae''n ymddangos fod eich ffrind yn byw mewn pentref lle nad oes ond dau fws y dydd. Rydych yn dewis ail-gynllunio rhan olaf eich siwrnai o''r brif orsaf sy''n lleol i''ch ffrind, at dy''r ffrind, gan feddwl y byddwch mae''n debyg yn cael tacsi neu lifft.</li> 
<li>Pan wasgwch ''Nesaf'' bydd Transport Direct yn dod o hyd i siwrnai car yn seiliedig ar eich dewisiadau ac yn gwneud hon yn rhan o''ch cynllun siwrnai gyffredinol newydd.</li></ul></div></div>
<p>&nbsp;</p>
<p>Mae''r diagram/tabl yn dangos y siwrnai hyd yma. Dewiswch y rhan(nau) o''r siwrnai y dymunwch eu hailgynllunio drwy dicio''r blychau dewis. Os galluogir Javascript ar eich porwr, bydd rhan(nau) perthnasol y siwrnai yn cael eu hamlygu gyda phob blwch dewis a diciwch. Mae hyn yn dangos pa ran(nau) o''ch siwrnai a gynllunir gan ddefnyddio ffurf arall o gludiant. Os analluogir Javascript, gwasgwch ''Nesaf'' i weld pa ran(nau) o''r siwrnai sydd wedi eu dewis.</p><br/>
<p>Pan ydych yn hapus gyda''ch dewis, gwasgwch ''Nesaf''. Bydd hyn yn galw''r cynllunwyr siwrneion Transport Direct priodol i ddarganfod cynllun siwrnai newydd.</p><br/>
<p>Os dymunwch ddechrau eto, gwasgwch ''Clirio''r dudalen''.</p><br/>
<p>Os nad ydych eisiau newid unrhyw beth am y siwrnai hon, gwasgwch ''Yn �l'' i weld eich siwrnai wreiddiol heb ei newid.</p><br/>
<p>Cofiwch y bydd Transport Direct yn ceisio cyfateb yr amserau ymadael a chyrraedd i roi siwrnai gyffredinol addas i chi. Ond os dewiswch amnewid adran cludiant cyhoeddus o''r siwrnai yng nghanol siwrnai gyffredinol hwy, efallai y gwelwch y bydd y siwrnai sy''n cael ei hamnewid a deithir mewn car naill ai''n fyrrach neu''n hwy o''i gymharu. Bydd Transport Direct yn gadael adrannau eraill y siwrnai heb eu newid, sy''n golygu y gallwch weld siwrneion yn gor-gyffwrdd neu y bydd raid aros yn hwy mewn pwynt rhyng-newid.</p>'

GO

-- JourneyPlannerLocationMap.asp soft content
EXEC AddtblContent
1, 1, 'langStrings', 'MapFindInformationLocationControl.literalInstructions.Text'
,'You must firstly select a location.<br/>Then you can view information about it.'
,'Mae''n rhaid i chi ddewis lleoliad yn gyntaf.<br/>Yna cewch weld gwybodaeth amdano.'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelLocations'
,'To find a location on a map:<br/>1.	Enter the location you want to see on the map, and click ''Next''<br/>2.	Confirm the location (if prompted), and click ''Next''<br/>3.	The map will appear below.  If you then want to find a map of another location, click ''Find new map''.<br/><br/>'
,'I ddarganfod lleoliad ar fap:<br/>1.	Rhowch y lleoliad y dymunwch ei weld ar y map, a chliciwch ''Nesa''<br/>2.	Cadarnhewch y lleoliad (os gofynnir i chi) a chliciwch ''Nesa''<br/>3.	Bydd y map yn ymddangos isod.  Os byddwch wedyn yn dymuno darganfod map o leoliad arall, cliciwch ''Darganfod map newydd''.<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelLocationsAmbig'
,'You need to confirm which location to show on the map. Choose a location from the yellow drop-down list.<br/><br/>If you cannot find the location you want in this list, you can either:<br/>� Search for a different kind of location (e.g. by selecting ''Address/postcode'')<br/>� Enter a new location (by clicking ''New location'')<br/><br/>Then click ''Next''.<br/><br/>'
,'Mae angen i chi gadarnhau pa leoliad i''w ddangos ar y map.  Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br/><br/>Os na allwch ddod o hyd i''r lleoliad a ddymunwch yn y rhestr hon, gallwch naill ai:<br/> �	Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')<br/>�	Rhoi lleoliad newydd (drwy glicio ar ''Lleoliad newydd'')<br/><br/>Yna cliciwch ''Nesa''.<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelMapIcons'
,'You can view symbols on the map when it is highly magnified (within the top five zoom levels, outlined in yellow).  They include transport symbols (shown automatically) and a range of attraction and facility symbols.<br/><br/>To show or hide any of these symbols, you must:<br/>1. Click on a category radio button e.g. ''Accommodation''<br/>2. Tick or untick the boxes next to the symbols<br/>3. Click ''Show selected symbols'''
,'Gallwch weld symbolau ar y map pan fo wedi ei chwyddo''n fawr (o fewn y pump lefel chwyddo mwyaf a amlinellir mewn melyn).  Maent yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac amrywiaeth o symbolau atyniadau a chyfleusterau <br/><br/>I ddangos neu guddio unrhyw rai o''r symbolau hyn, rhaid i chi:<br/>1. Glicio ar fotwm radio a dewis categori e.e. ''Llety''<br/>2. Dicio neu ddad-dicio''r blychau ger y symbolau<br/>3. Glicio ar ''Dewiswch symbolau detholedig'''

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelMapTools'
,'Use the buttons above the map to:<br/>  � Plan a journey to or from the current location shown on the map<br/>  � Select a new location to show on the map.<br/><br/>  Use the buttons to the top-left of the map to:<br/>  � Zoom into (magnify) and zoom out of (shrink) the map<br/><br/>    Use the buttons beneath the map to:<br/>  � Show or hide various places of interest on the map<br/><br/>'
,'cy- Use the buttons above the map to:<br/>  � Plan a journey to or from the current location shown on the map<br/>  � Select a new location to show on the map.<br/><br/>  Use the buttons to the top-left of the map to:<br/>  � Zoom into (magnify) and zoom out of (shrink) the map<br/><br/>    Use the buttons beneath the map to:<br/>  � Show or hide various places of interest on the map<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelMapToolsStart'
,'Use the buttons on the right-hand side to:<br/>� Zoom into (magnify) and zoom out of (shrink) the map<br/>� See a previous map view or find a new map<br/><br/>Use the buttons on the left-hand side to:<br/>� Find information about the current location shown on the map<br/>� Select a new location to show on the map<br/><br/><strong>Once you have found the location you want to travel from, click "Next"</strong><br/><br/>'
,'Defnyddiwch y botymau ar yr ochr llaw dde i:<br/>� Chwyddo a lleihau''r map<br/>� Weld golygfa ar fap blaenorol neu ddarganfod map newydd<br/><br/>Defnyddiwch y botymau ar yr ochr llaw chwith i:<br/>� Gynllunio siwrnai i neu o''r lleoliad cyfredol a ddangosir ar y map<br/>� Ddod o hyd i wybodaeth am y lleoliad cyfredol a ddangosir ar y map<br/>� Ddewis lleoliad newydd i''w ddangos ar y map. <br/><br/><strong>Wedi i chi ddarganfod y lleoliad y dymunwch deithio ohono, cliciwch ''Nesa''</strong><br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelMapToolsDestination'
,'Use the buttons on the right-hand side to:<br/>� Zoom into (magnify) and zoom out of (shrink) the map<br/>� See a previous map view or find a new map<br/><br/>Use the buttons on the left-hand side to:<br/>� Find information about the current location shown on the map<br/>� Select a new location to show on the map<br/><br/><strong>Once you have found the location you want to travel to, click "Next"</strong><br/><br/>'
,'Defnyddiwch y botymau ar yr ochr llaw dde i:<br/>� Chwyddo a lleihau''r map<br/>� Weld golygfa ar fap blaenorol neu ddarganfod map newydd<br/><br/>Defnyddiwch y botymau ar yr ochr llaw chwith i:<br/>� Gynllunio siwrnai i neu o''r lleoliad cyfredol a ddangosir ar y map<br/>� Ddod o hyd i wybodaeth am y lleoliad cyfredol a ddangosir ar y map<br/>� Ddewis lleoliad newydd i''w ddangos ar y map. <br/><br/><strong>Wedi i chi ddarganfod y lleoliad y dymunwch deithio iddo, cliciwch ''Nesa''</strong><br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelMapToolsVia'
,'Use the buttons on the right-hand side to:<br/>� Zoom into (magnify) and zoom out of (shrink) the map<br/>� See a previous map view or find a new map<br/><br/>Use the buttons on the left-hand side to:<br/>� Find information about the current location shown on the map<br/>� Select a new location to show on the map<br/><br/><strong>Once you have found the location you want to travel via, click "Next"</strong><br/><br/>'
,'Defnyddiwch y botymau ar yr ochr llaw dde i:<br/>� Chwyddo a lleihau''r map<br/>� Weld golygfa ar fap blaenorol neu ddarganfod map newydd<br/><br/>Defnyddiwch y botymau ar yr ochr llaw chwith i:<br/>� Gynllunio siwrnai i neu o''r lleoliad cyfredol a ddangosir ar y map<br/>� Ddod o hyd i wybodaeth am y lleoliad cyfredol a ddangosir ar y map<br/>� Ddewis lleoliad newydd i''w ddangos ar y map. <br/><br/><strong>Wedi i chi ddarganfod y lleoliad y dymunwch deithio drwyddo, cliciwch ''Nesa''</strong><br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelStartLocation'
,'To find a start location on a map:<br/><br/>1. Enter the location you want to see on the map, and click ''Next''<br/>2. Confirm the location (if prompted), and click ''Next''<br/>3. The map will appear below.  If you then want to find a map of another location, click ''Find new map''.<br/><br/>'
,'I ddarganfod lleoliad dechrau ar fap:<br/><br/>1.	Rhowch y lleoliad y dymunwch ei weld ar y map, a chliciwch ''Nesa''<br/>2.	Cadarnhewch y lleoliad (os gofynnir i chi) a chliciwch ''Nesa''<br/>3.	Bydd y map yn ymddangos isod.  Os byddwch wedyn yn dymuno darganfod map o leoliad arall, cliciwch ''Darganfod map newydd''.<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelStartAmbiguity'
,'You need to confirm which start location to show on the map. Choose a location from the yellow drop-down list.<br/><br/>If you cannot find the start location you want in this list, you can either:<br/>� Search for a different kind of location (e.g. by selecting ''Address/postcode'')<br/>� Enter a new location (by clicking ''New location'')<br/><br/>Then click "Next"<br/><br/>'
,'Mae angen i chi gadarnhau pa leoliad dechrau i''w ddangos ar y map.  Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br/><br/>Os na allwch ddod o hyd i''r lleoliad a ddymunwch yn y rhestr hon, gallwch naill ai:<br/> �	Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')<br/>�	Rhoi lleoliad newydd (drwy glicio ar ''Lleoliad newydd'')<br/><br/>Yna cliciwch ''Nesa''.<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelDestination'
,'To find a destination on a map:<br/><br/>1. Enter the location you want to see on the map, and click ''Next''<br/>2. Confirm the location (if prompted), and click ''Next''<br/>3. The map will appear below.  If you then want to find a map of another location, click ''Find new map''.<br/><br/>'
,'I ddarganfod cyrchfan ar fap:<br/><br/>1.	Rhowch y lleoliad y dymunwch ei weld ar y map, a chliciwch ''Nesa''<br/>2.	Cadarnhewch y lleoliad (os gofynnir i chi) a chliciwch ''Nesa''<br/>3.	Bydd y map yn ymddangos isod.  Os byddwch wedyn yn dymuno darganfod map o leoliad arall, cliciwch ''Darganfod map newydd''.<br/><br/>'


EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelVia'
,'To find a via location (by car) on a map:<br/><br/>1. Enter the location you want to see on the map, and click ''Next''<br/>2.	Confirm the location (if prompted), and click ''Next''<br/>3. The map will appear below.  If you then want to find a map of another location, click ''Find new map''.<br/><br/>'
,'I ddarganfod lleoliad drwodd (mewn car) ar fap:<br/><br/>1.	Rhowch y lleoliad y dymunwch ei weld ar y map, a chliciwch ''Nesa''<br/>2.	Cadarnhewch y lleoliad (os gofynnir i chi) a chliciwch ''Nesa''<br/>3.	Bydd y map yn ymddangos isod.  Os byddwch wedyn yn dymuno darganfod map o leoliad arall, cliciwch ''Darganfod map newydd''.<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelDestinationAmbiguity'
,'You need to confirm which destination to show on the map. Choose a location from the yellow drop-down list.<br/><br/>If you cannot find the destination you want in this list, you can either:<br/>� Search for a different kind of location (e.g. by selecting ''Station/airport'')<br/>� Enter a new location (by clicking ''New location'')<br/><br/>Then click "Next"<br/><br/>'
,'Mae angen i chi gadarnhau pa gyrchfan i''w ddangos ar y map.  Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br/><br/>Os na allwch ddod o hyd i''r lleoliad a ddymunwch yn y rhestr hon, gallwch naill ai:<br/> �	Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')<br/>�	Rhoi lleoliad newydd (drwy glicio ar ''Lleoliad newydd'')<br/><br/>Yna cliciwch ''Nesa''.<br/><br/>'

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelViaAmbiguity'
,'You need to confirm which via location to show on the map. Choose a location from the yellow drop-down list.<br/><br/>If you cannot find the via location you want in this list, you can either:<br/>� Search for a different kind of location (e.g. by selecting ''Attractions/facilities'')<br/>� Enter a new location (by clicking ''New location'')<br/><br/>Then click "Next"<br/><br/>'
,'Mae angen i chi gadarnhau pa leoliad drwodd i''w ddangos ar y map.  Dewiswch leoliad o''r rhestr felen a ollyngir i lawr.<br/><br/>Os na allwch ddod o hyd i''r lleoliad a ddymunwch yn y rhestr hon, gallwch naill ai:<br/> �	Chwilio am fath gwahanol o leoliad (e.e. drwy ddewis ''Cyfeiriad/c�d post'')<br/>�	Rhoi lleoliad newydd (drwy glicio ar ''Lleoliad newydd'')<br/><br/>Yna cliciwch ''Nesa''.<br/><br/>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpEnteringLocations'
,'<h1>Using the map to find a location</h1>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Select what type of location you are going to type in</strong><br/>&nbsp;<br/></p>
<p class="helpindent1">This will allow the Journey Planner to know whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>&nbsp;</p>
<p class="helpindent1">It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>&nbsp;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Town</strong><strong>/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet,<br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </li></ul>
<p></p>
<p>&nbsp;</p>
<ul>
<li><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Type the location name in the box</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.</p>
<p class="helpindent1"><br/>&nbsp;<br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p class="helpindent1"><br/>&nbsp;<br/>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.<br/>&nbsp; e.g. If you selected ''Station/airport'' and typed in �kin*�you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p>&nbsp;</p>
<p><strong>3.&nbsp; Click ''Next''</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">At this point the Journey Planner will search for a map location you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p>
<p><br/>&nbsp;</p>'
,'<h1>Defnyddio''r map i ddod o hyd i leoliad</h1>
<p>&nbsp;</p>
<p><strong>1. &nbsp;Dewiswch pa fath o leoliad yr ydych yn mynd i''w deipio </strong><br/>&nbsp;<br/></p>
<p class="helpindent1">Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>&nbsp;</p>
<p class="helpindent1">Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>&nbsp;</p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Tref/rhanbarth/pentref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Cyfleuster/atyniad'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Teipiwch enw''r lleoliad yn y blwch</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p class="helpindent1"><br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p class="helpindent1"><br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.<br/>&nbsp; e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p>&nbsp;</p>
<p><strong>3.&nbsp; Cliciwch ar ''Nesa''</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Yn ystod y cam hwn bydd y Cynlluniwr Siwrnai yn chwilio am leoliad map yr ydych wedi ei deipio.&nbsp; Os oes mwy nag un lleoliad yn debyg i''r lleoliad yr ydych wedi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p>
<p>&nbsp;</p>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpEnteringLocationsAmbig'
,'<h1>Confirming a location to show on the map</h1>
<p>&nbsp;</p>
<p>Depending on the information entered, you will need to do <strong>one</strong> of the following:</p>
<ul>
<li>Choose a location option from the drop-down list.&nbsp; Please note if the location you want to travel from is already visible in the yellow box, you do not need to re-select it</li> 
<li>Search for the location as a different kind of location</li> 
<li>Enter a new location</li></ul>
<p>&nbsp;</p>
<p><strong>Choosing a location from the list</strong></p>
<p>&nbsp;</p>
<p>If there was more than one match for the location you typed in:</p> 
<ul>
<li>Choose one of the options in the list</li> 
<li>Click ''Next'' at the bottom of the page</li></ul>
<p>&nbsp;</p>
<p>Some locations have further locations within them:&nbsp;</p> 
<ul>
<li>Some have the words �More options for�� written in front of them&nbsp;</li> 
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location&nbsp;</li> 
<li>If you then click ''Back'', the first list of options will appear again</li></ul>
<p>&nbsp;</p>
<p><strong>Changing the kind of location</strong></p>
<p><strong></strong>&nbsp;</p>
<p>If the Journey Planner didn''t find any matches for the location you typed in, it may be because the Journey Planner didn''t match the type of location with the location you typed in.</p>
<p>&nbsp;</p>
<p></p>
<p>Select another kind of location (e.g. ''Address/postcode'') and select the button next it.&nbsp; The Journey Planner will then show you a list of possible locations for this kind of location.</p>
<p>&nbsp;</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>&nbsp;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''City/town/suburb'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, <br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Attraction/facility'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings, police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>Entering a new location</strong></p>
<p><br/>To enter a new location:</p> 
<ul>
<li>Click ''New location''</li> 
<li>Type the location name in the box</li></ul>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.</p>
<p><br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p><br/>If you do not know the full location name, type in as much as you know and put an asterisk&nbsp;&nbsp;&nbsp;&nbsp; * after the letters.<br/></p>
<p class="helpindent2">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p><br/><strong>Once you have confirmed the location, click ''Next''.</strong></p>
<p>&nbsp;</p>'
,'<h1>Cadarnhau lleoliad i''w ddangos ar y map</h1>
<p>&nbsp;</p>
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud <strong>un</strong> o''r canlynol:</p> 
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr.&nbsp; Nodwch os yw''r lleoliad y dymunwch deithio ohono eisoes yn weladwy yn y blwch melyn, nid oes angen i chi ei ail-ddewis</li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad</li>
<li>Rhoi lleoliad newydd </li></ul>
<p>&nbsp;</p>
<p><strong>Dewis lleoliad o''r rhestr</strong></p>
<p>&nbsp;</p>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p> 
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr</li> 
<li>Cliciwch ar ''Nesa'' ar waelod y dudalen</li></ul>
<p>&nbsp;</p>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:&nbsp;</p> 
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau &nbsp;</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li> 
<li>Os ydych wedyn yn clicio ''Yn �l'', bydd y rhestr gyntaf o ddewisiadau yn ymddangos eto</li></ul>
<p>&nbsp;</p>
<p><strong>Newid y math o leoliad</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p>
<p>&nbsp;</p>
<p></p>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad.</p>
<p>&nbsp;</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p>
<p>&nbsp;</p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Dinas/tref/maestref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Atyniad/cyfleuster'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>Nodi lleoliad newydd</strong></p>
<p><br/>I nodi lleoliad newydd:</p> 
<ul>
<li>Cliciwch ''Lleoliad newydd''</li> 
<li>Teipiwch enw''r lleoliad yn y blwch</li></ul>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y gallwch gael y nifer lleiaf o ''gyfatebiaethau tebyg'' wedi eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p><br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych yn ei deipio.</p>
<p><br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.<br/></p>
<p class="helpindent2">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p><br/><strong>Wedi i chi gadarnhau''r lleoliad, cliciwch ar ''Nesa''.</strong></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpMapTools'
,'<h1>Location map tools</h1>
<p><strong></strong>&nbsp;</p>
<p><strong>You can use the tools in this section to:</strong></p> 
<ul>
<li>Navigate around the map</li> 
<li>Find information about points on the map</li> 
<li>Select a new point on the map</li></ul>
<p>&nbsp;</p>
<p><strong>Map navigation buttons:</strong></p>
<ul>
<li><strong>''Zoom in''<br/></strong>Allows you to zoom into the map so that you can view more detail.&nbsp; 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Zoom out''<br/></strong>Allows you to zoom out so that you are able to view more of the surrounding areas, but less detail.
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Zoom bar''<br/></strong>This tool allows you to zoom in or out of the map quickly by clicking on one of the bars.&nbsp; ''Zoom level 13'' is closest to ''Zoom in +'' and will show you more detail than ''Zoom level 1'', which is closest to ''Zoom in -'', and will show you the least detail. 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Previous map''<br/></strong>Allows you to view the map as it was before your last action. 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Select new location''</strong><strong><br/></strong>Click ''Select new location'' to search for a map of a new location. </li></ul>
<p></p>
<p>&nbsp;</p>
<ul>
<li><strong>Navigation arrows<br/></strong>Click the arrows on the edge of the map to move up, down, left, right or diagonally. The map will then represent the areas you are navigating towards.</li></ul>
<p>&nbsp;</p>
<p><strong>''Plan a journey'' button<br/></strong>&nbsp;<br/></p>
<p>Clicking on ''Plan a journey'' will give you the choice to plan a journey <strong>to</strong> or <strong>from</strong>&nbsp;the current location showing on the map.</p>
<p></p>
<p>If you want to travel to or from the location currently shown on the map:</p> 
<p></p>
<ol class="numberlist">
<li>Click ''Plan a journey''</li> 
<li>Click either ''Travel <strong>from</strong> this location'' or ''Travel <strong>to</strong> this location''</li></ol>
<p></p>
<p>If you want to travel to or from a new location:</p> 
<p></p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the navigation tools so that you can see the location you wish to travel from or to </li> 
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the&nbsp;locations within 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li>  
<li>Click ''Plan a journey''</li>  
<li>Click either ''Travel <strong>from</strong> this location'' or ''Travel <strong>to</strong> this location''</li></ol>
<p><strong>''i'' button</strong></p>
<p><strong></strong><br/>Clicking on ''i'' will take you to a page which will give you information about the current location (if it is available).</p>
<p>If you want information about a new location:</p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the navigation tools so that you can see the location you wish to travel from or to</li>  
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the locations within 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li>  
<li>Click ''i'' </li></ol>
<p><strong>''Select new location'' button</strong><strong><br/></strong>&nbsp; <br/>Clicking on ''Select new location'' will allow you to select a location so that you can view a map of it and then proceed with either planning a journey or finding information. </p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the locations with 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li></ol>
<p><strong>To stop any action process click ''Cancel''.</strong></p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.<br/></strong></p>'
,'<h1>Teclynnau map lleoliad</h1>
<p><strong></strong>&nbsp;</p>
<p><strong>Gallwch ddefnyddio''r teclynnau yn yr adran hon i:</strong></p> 
<ul>
<li>Symud o gwmpas y map</li>  
<li>Darganfod gwybodaeth am bwyntiau ar y map</li>  
<li>Dewis pwynt newydd ar y map</li></ul>
<p>&nbsp;</p>
<p><strong>Botymau i symud o gwmpas y map:</strong></p>
<ul>
<li><strong>''Chwyddo''r map''<br/></strong>Mae''n caniat�u i chi chwyddo''r map fel y gallwch weld yn fwy manwl. &nbsp; 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Lleihau''r map''<br/></strong>Mae''n caniat�u i chi leihau''r map fel y gallwch weld mwy o''r ardaloedd cyfagos, ond llai o fanylder. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Bar chwyddo/lleihau''<br/></strong>Mae''r teclyn hwn yn caniat�u i chi chwyddo neu leihau''r map yn gyflym drwy glicio ar un o''r bariau.&nbsp; ""Lefel chwyddo 13 yw''r agosaf at ''Chwyddo +'' a bydd yn dangos i chi fwy o fanylion na ''Lefel chwyddo 1'' sydd agosaf at ''Chwyddo � '' a bydd yn dangos i chi''r lleiaf o fanylder. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Golygfa flaenorol''<br/></strong>Mae''n caniat�u i chi weld y map fel ag yr oedd cyn i chi weithredu y tro diwethaf. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Darganfod map newydd''<br/></strong>Cliciwch ar ''Darganfod map newydd'' i chwilio am fap o leoliad newydd. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>Saethau cyfeirio<br/></strong>Cliciwch ar y saethau ar ymyl y map i symud i fyny, i lawr, i''r chwith, i''r dde neu ar draws. Yna bydd y map yn cynrychioli''r ardaloedd yr ydych yn symud tuag atynt.</li></ul>
<p>&nbsp;</p>
<p><strong>Botwm ''Cynlluniwch siwrnai'' <br/></strong>&nbsp;<br/></p>
<p>Bydd clicio ''Cynlluniwch siwrnai'' yn rhoi dewis i chi gynllunio siwrnai <strong>i</strong> neu <strong>o</strong>''r lleoliad cyfredol a ddangosir ar y map.</p>
<p></p>
<p>Os ydych am deithio i neu o''r lleoliad cyfredol a ddangosir ar y map:</p> 
<p></p>
<ol class="numberlist">
<li>Cliciwch ar ''Cynlluniwch siwrnai''&nbsp;&nbsp;</li>  
<li>Cliciwch un ai ''Teithio <strong>o</strong>''r lleoliad hwn" neu ''Teithio <strong>i</strong>''r lleoliad hwn''</li></ol>
<p></p>
<p>Os ydych am deithio i neu o leoliad newydd:</p> 
<p></p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld y lleoliad rydych am deithio o neu i</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a byddwch yn gweld rhestr a ollyngir i lawr o''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad o''r rhestr a ollyngir i lawr a chliciwch ''Iawn"</li>  
<li>Cliciwch ''Cynlluniwch siwrnai''</li>  
<li>Cliciwch un ai ''Teithio o''r lleoliad hwn'' neu ''Teithio i''r lleoliad hwn'' </li></ol>
<p>&nbsp;</p>
<p><strong>Botwm ''Gwybodaeth''</strong></p>
<p><strong></strong><br/>Bydd clicio ar ''Gwybodaeth'' yn eich arwain at dudalen a fydd yn rhoi gwybodaeth ynghylch y lleoliad cyfredol (os yw ar gael).&nbsp; </p>
<p>Os bydd angen gwybodaeth ynghylch lleoliad newydd arnoch:</p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld y lleoliad rydych yn dymuno teithio i neu oddi yno</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a chliciwch ''Iawn''</li>  
<li>Cliciwch ''Gwybodaeth''</li></ol>
<p><strong></strong>&nbsp;</p>
<p><strong>''Botwm ''Dewiswch leoliad newydd''</strong><strong><br/></strong>&nbsp; <br/>Bydd clicio ar ''Dewiswch leoliad newydd'' yn eich galluogi i ddewis lleoliad fel eich bod yn gallu gweld map ac yna mynd ymlaen un ai i gynllunio siwrnai neu ddod o hyd i wybodaeth. </p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a chliciwch ''Iawn''</li></ol>
<p><strong>I atal unrhyw weithred cliciwch ar ''Dileu''.</strong></p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawwd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEnteringLocations'
,'<h1>Using the map to find a location</h1>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Select what type of location you are going to type in</strong><br/>&nbsp;<br/></p>
<p class="helpindent1">This will allow the Journey Planner to know whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>&nbsp;</p>
<p class="helpindent1">It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>&nbsp;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Town</strong><strong>/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet,<br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </li></ul>
<p></p>
<p>&nbsp;</p>
<ul>
<li><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Type the location name in the box</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.</p>
<p class="helpindent1"><br/>&nbsp;<br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p class="helpindent1"><br/>&nbsp;<br/>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.<br/>&nbsp; e.g. If you selected ''Station/airport'' and typed in �kin*�you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p>&nbsp;</p>
<p><strong>3.&nbsp; Click ''Next''</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">At this point the Journey Planner will search for a map location you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p>
<p><br/>&nbsp;</p>'
,'<h1>Defnyddio''r map i ddod o hyd i leoliad</h1>
<p>&nbsp;</p>
<p><strong>1. &nbsp;Dewiswch pa fath o leoliad yr ydych yn mynd i''w deipio </strong><br/>&nbsp;<br/></p>
<p class="helpindent1">Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>&nbsp;</p>
<p class="helpindent1">Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>&nbsp;</p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Tref/rhanbarth/pentref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Cyfleuster/atyniad'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Teipiwch enw''r lleoliad yn y blwch</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p class="helpindent1"><br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p class="helpindent1"><br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.<br/>&nbsp; e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p>&nbsp;</p>
<p><strong>3.&nbsp; Cliciwch ar ''Nesa''</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Yn ystod y cam hwn bydd y Cynlluniwr Siwrnai yn chwilio am leoliad map yr ydych wedi ei deipio.&nbsp; Os oes mwy nag un lleoliad yn debyg i''r lleoliad yr ydych wedi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p>
<p>&nbsp;</p>'


EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEnteringLocationsAmbig'
,'<h1>Confirming a location to show on the map</h1>
<p>&nbsp;</p>
<p>Depending on the information entered, you will need to do <strong>one</strong> of the following:</p>
<ul>
<li>Choose a location option from the drop-down list.&nbsp; Please note if the location you want to travel from is already visible in the yellow box, you do not need to re-select it</li> 
<li>Search for the location as a different kind of location</li> 
<li>Enter a new location</li></ul>
<p>&nbsp;</p>
<p><strong>Choosing a location from the list</strong></p>
<p>&nbsp;</p>
<p>If there was more than one match for the location you typed in:</p> 
<ul>
<li>Choose one of the options in the list</li> 
<li>Click ''Next'' at the bottom of the page</li></ul>
<p>&nbsp;</p>
<p>Some locations have further locations within them:&nbsp;</p> 
<ul>
<li>Some have the words �More options for�� written in front of them&nbsp;</li> 
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location&nbsp;</li> 
<li>If you then click ''Back'', the first list of options will appear again</li></ul>
<p>&nbsp;</p>
<p><strong>Changing the kind of location</strong></p>
<p><strong></strong>&nbsp;</p>
<p>If the Journey Planner didn''t find any matches for the location you typed in, it may be because the Journey Planner didn''t match the type of location with the location you typed in.</p>
<p>&nbsp;</p>
<p></p>
<p>Select another kind of location (e.g. ''Address/postcode'') and select the button next it.&nbsp; The Journey Planner will then show you a list of possible locations for this kind of location.</p>
<p>&nbsp;</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>&nbsp;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''City/town/suburb'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, <br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Attraction/facility'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings, police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>Entering a new location</strong></p>
<p><br/>To enter a new location:</p> 
<ul>
<li>Click ''New location''</li> 
<li>Type the location name in the box</li></ul>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.</p>
<p><br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p><br/>If you do not know the full location name, type in as much as you know and put an asterisk&nbsp;&nbsp;&nbsp;&nbsp; * after the letters.<br/></p>
<p class="helpindent2">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p><br/><strong>Once you have confirmed the location, click ''Next''.</strong></p>
<p>&nbsp;</p>'
,'<h1>Cadarnhau lleoliad i''w ddangos ar y map</h1>
<p>&nbsp;</p>
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud <strong>un</strong> o''r canlynol:</p> 
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr.&nbsp; Nodwch os yw''r lleoliad y dymunwch deithio ohono eisoes yn weladwy yn y blwch melyn, nid oes angen i chi ei ail-ddewis</li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad</li>
<li>Rhoi lleoliad newydd </li></ul>
<p>&nbsp;</p>
<p><strong>Dewis lleoliad o''r rhestr</strong></p>
<p>&nbsp;</p>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p> 
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr</li> 
<li>Cliciwch ar ''Nesa'' ar waelod y dudalen</li></ul>
<p>&nbsp;</p>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:&nbsp;</p> 
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau &nbsp;</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li> 
<li>Os ydych wedyn yn clicio ''Yn �l'', bydd y rhestr gyntaf o ddewisiadau yn ymddangos eto</li></ul>
<p>&nbsp;</p>
<p><strong>Newid y math o leoliad</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p>
<p>&nbsp;</p>
<p></p>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad.</p>
<p>&nbsp;</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p>
<p>&nbsp;</p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Dinas/tref/maestref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Atyniad/cyfleuster'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>Nodi lleoliad newydd</strong></p>
<p><br/>I nodi lleoliad newydd:</p> 
<ul>
<li>Cliciwch ''Lleoliad newydd''</li> 
<li>Teipiwch enw''r lleoliad yn y blwch</li></ul>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y gallwch gael y nifer lleiaf o ''gyfatebiaethau tebyg'' wedi eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p><br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych yn ei deipio.</p>
<p><br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.<br/></p>
<p class="helpindent2">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p><br/><strong>Wedi i chi gadarnhau''r lleoliad, cliciwch ar ''Nesa''.</strong></p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpMapTools'
,'<h1>Location map tools</h1>
<p><strong></strong>&nbsp;</p>
<p><strong>You can use the tools in this section to:</strong></p> 
<ul>
<li>Navigate around the map</li> 
<li>Find information about points on the map</li> 
<li>Select a new point on the map</li></ul>
<p>&nbsp;</p>
<p><strong>Map navigation buttons:</strong></p>
<ul>
<li><strong>''Zoom in''<br/></strong>Allows you to zoom into the map so that you can view more detail.&nbsp; 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Zoom out''<br/></strong>Allows you to zoom out so that you are able to view more of the surrounding areas, but less detail.
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Zoom bar''<br/></strong>This tool allows you to zoom in or out of the map quickly by clicking on one of the bars.&nbsp; ''Zoom level 13'' is closest to ''Zoom in +'' and will show you more detail than ''Zoom level 1'', which is closest to ''Zoom in -'', and will show you the least detail. 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Previous map''<br/></strong>Allows you to view the map as it was before your last action. 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Select new location''</strong><strong><br/></strong>Click ''Select new location'' to search for a map of a new location. </li></ul>
<p></p>
<p>&nbsp;</p>
<ul>
<li><strong>Navigation arrows<br/></strong>Click the arrows on the edge of the map to move up, down, left, right or diagonally. The map will then represent the areas you are navigating towards.</li></ul>
<p>&nbsp;</p>
<p><strong>''Plan a journey'' button<br/></strong>&nbsp;<br/></p>
<p>Clicking on ''Plan a journey'' will give you the choice to plan a journey <strong>to</strong> or <strong>from</strong>&nbsp;the current location showing on the map.</p>
<p></p>
<p>If you want to travel to or from the location currently shown on the map:</p> 
<p></p>
<ol class="numberlist">
<li>Click ''Plan a journey''</li> 
<li>Click either ''Travel <strong>from</strong> this location'' or ''Travel <strong>to</strong> this location''</li></ol>
<p></p>
<p>If you want to travel to or from a new location:</p> 
<p></p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the navigation tools so that you can see the location you wish to travel from or to </li> 
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the&nbsp;locations within 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li>  
<li>Click ''Plan a journey''</li>  
<li>Click either ''Travel <strong>from</strong> this location'' or ''Travel <strong>to</strong> this location''</li></ol>
<p><strong>''i'' button</strong></p>
<p><strong></strong><br/>Clicking on ''i'' will take you to a page which will give you information about the current location (if it is available).</p>
<p>If you want information about a new location:</p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the navigation tools so that you can see the location you wish to travel from or to</li>  
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the locations within 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li>  
<li>Click ''i'' </li></ol>
<p><strong>''Select new location'' button</strong><strong><br/></strong>&nbsp; <br/>Clicking on ''Select new location'' will allow you to select a location so that you can view a map of it and then proceed with either planning a journey or finding information. </p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the locations with 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li></ol>
<p><strong>To stop any action process click ''Cancel''.</strong></p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.<br/></strong></p>'
,'<h1>Teclynnau map lleoliad</h1>
<p><strong></strong>&nbsp;</p>
<p><strong>Gallwch ddefnyddio''r teclynnau yn yr adran hon i:</strong></p> 
<ul>
<li>Symud o gwmpas y map</li>  
<li>Darganfod gwybodaeth am bwyntiau ar y map</li>  
<li>Dewis pwynt newydd ar y map</li></ul>
<p>&nbsp;</p>
<p><strong>Botymau i symud o gwmpas y map:</strong></p>
<ul>
<li><strong>''Chwyddo''r map''<br/></strong>Mae''n caniat�u i chi chwyddo''r map fel y gallwch weld yn fwy manwl. &nbsp; 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Lleihau''r map''<br/></strong>Mae''n caniat�u i chi leihau''r map fel y gallwch weld mwy o''r ardaloedd cyfagos, ond llai o fanylder. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Bar chwyddo/lleihau''<br/></strong>Mae''r teclyn hwn yn caniat�u i chi chwyddo neu leihau''r map yn gyflym drwy glicio ar un o''r bariau.&nbsp; ""Lefel chwyddo 13 yw''r agosaf at ''Chwyddo +'' a bydd yn dangos i chi fwy o fanylion na ''Lefel chwyddo 1'' sydd agosaf at ''Chwyddo � '' a bydd yn dangos i chi''r lleiaf o fanylder. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Golygfa flaenorol''<br/></strong>Mae''n caniat�u i chi weld y map fel ag yr oedd cyn i chi weithredu y tro diwethaf. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Darganfod map newydd''<br/></strong>Cliciwch ar ''Darganfod map newydd'' i chwilio am fap o leoliad newydd. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>Saethau cyfeirio<br/></strong>Cliciwch ar y saethau ar ymyl y map i symud i fyny, i lawr, i''r chwith, i''r dde neu ar draws. Yna bydd y map yn cynrychioli''r ardaloedd yr ydych yn symud tuag atynt.</li></ul>
<p>&nbsp;</p>
<p><strong>Botwm ''Cynlluniwch siwrnai'' <br/></strong>&nbsp;<br/></p>
<p>Bydd clicio ''Cynlluniwch siwrnai'' yn rhoi dewis i chi gynllunio siwrnai <strong>i</strong> neu <strong>o</strong>''r lleoliad cyfredol a ddangosir ar y map.</p>
<p></p>
<p>Os ydych am deithio i neu o''r lleoliad cyfredol a ddangosir ar y map:</p> 
<p></p>
<ol class="numberlist">
<li>Cliciwch ar ''Cynlluniwch siwrnai''&nbsp;&nbsp;</li>  
<li>Cliciwch un ai ''Teithio <strong>o</strong>''r lleoliad hwn" neu ''Teithio <strong>i</strong>''r lleoliad hwn''</li></ol>
<p></p>
<p>Os ydych am deithio i neu o leoliad newydd:</p> 
<p></p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld y lleoliad rydych am deithio o neu i</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a byddwch yn gweld rhestr a ollyngir i lawr o''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad o''r rhestr a ollyngir i lawr a chliciwch ''Iawn"</li>  
<li>Cliciwch ''Cynlluniwch siwrnai''</li>  
<li>Cliciwch un ai ''Teithio o''r lleoliad hwn'' neu ''Teithio i''r lleoliad hwn'' </li></ol>
<p>&nbsp;</p>
<p><strong>Botwm ''Gwybodaeth''</strong></p>
<p><strong></strong><br/>Bydd clicio ar ''Gwybodaeth'' yn eich arwain at dudalen a fydd yn rhoi gwybodaeth ynghylch y lleoliad cyfredol (os yw ar gael).&nbsp; </p>
<p>Os bydd angen gwybodaeth ynghylch lleoliad newydd arnoch:</p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld y lleoliad rydych yn dymuno teithio i neu oddi yno</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a chliciwch ''Iawn''</li>  
<li>Cliciwch ''Gwybodaeth''</li></ol>
<p><strong></strong>&nbsp;</p>
<p><strong>''Botwm ''Dewiswch leoliad newydd''</strong><strong><br/></strong>&nbsp; <br/>Bydd clicio ar ''Dewiswch leoliad newydd'' yn eich galluogi i ddewis lleoliad fel eich bod yn gallu gweld map ac yna mynd ymlaen un ai i gynllunio siwrnai neu ddod o hyd i wybodaeth. </p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a chliciwch ''Iawn''</li></ol>
<p><strong>I atal unrhyw weithred cliciwch ar ''Dileu''.</strong></p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawwd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEnteringLocations'
,'<h1>Using the map to find a location</h1>
<p>&nbsp;</p>
<p><strong>1.&nbsp; Select what type of location you are going to type in</strong><br/>&nbsp;<br/></p>
<p class="helpindent1">This will allow the Journey Planner to know whether you are looking for an address, a postcode, a station or an attraction �etc.</p>
<p>&nbsp;</p>
<p class="helpindent1">It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>&nbsp;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Town</strong><strong>/district/village'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet,<br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea� </li></ul>
<p></p>
<p>&nbsp;</p>
<ul>
<li><strong>''Facility/attraction'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings and police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Type the location name in the box</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.</p>
<p class="helpindent1"><br/>&nbsp;<br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p class="helpindent1"><br/>&nbsp;<br/>If you do not know the full location name, type in as much as you know and put an asterisk * after the letters.<br/>&nbsp; e.g. If you selected ''Station/airport'' and typed in �kin*�you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p>&nbsp;</p>
<p><strong>3.&nbsp; Click ''Next''</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">At this point the Journey Planner will search for a map location you have typed in. If there is more than one location similar to the location you typed in, you will need to choose from a list of possible matches.</p>
<p><br/>&nbsp;</p>'
,'<h1>Defnyddio''r map i ddod o hyd i leoliad</h1>
<p>&nbsp;</p>
<p><strong>1. &nbsp;Dewiswch pa fath o leoliad yr ydych yn mynd i''w deipio </strong><br/>&nbsp;<br/></p>
<p class="helpindent1">Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a ydych yn chwilio am gyfeiriad, c�d post, gorsaf neu atyniad... ac ati.</p>
<p>&nbsp;</p>
<p class="helpindent1">Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo. </p>
<p>&nbsp;</p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Tref/rhanbarth/pentref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Cyfleuster/atyniad'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station� 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>2.&nbsp; Teipiwch enw''r lleoliad yn y blwch</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p class="helpindent1"><br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych wedi ei deipio.</p>
<p class="helpindent1"><br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.<br/>&nbsp; e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p>&nbsp;</p>
<p><strong>3.&nbsp; Cliciwch ar ''Nesa''</strong></p>
<p><strong></strong>&nbsp;</p>
<p class="helpindent1">Yn ystod y cam hwn bydd y Cynlluniwr Siwrnai yn chwilio am leoliad map yr ydych wedi ei deipio.&nbsp; Os oes mwy nag un lleoliad yn debyg i''r lleoliad yr ydych wedi ei deipio, bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p>
<p>&nbsp;</p>'


EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEnteringLocationsAmbig'
,'<h1>Confirming a location to show on the map</h1>
<p>&nbsp;</p>
<p>Depending on the information entered, you will need to do <strong>one</strong> of the following:</p>
<ul>
<li>Choose a location option from the drop-down list.&nbsp; Please note if the location you want to travel from is already visible in the yellow box, you do not need to re-select it</li> 
<li>Search for the location as a different kind of location</li> 
<li>Enter a new location</li></ul>
<p>&nbsp;</p>
<p><strong>Choosing a location from the list</strong></p>
<p>&nbsp;</p>
<p>If there was more than one match for the location you typed in:</p> 
<ul>
<li>Choose one of the options in the list</li> 
<li>Click ''Next'' at the bottom of the page</li></ul>
<p>&nbsp;</p>
<p>Some locations have further locations within them:&nbsp;</p> 
<ul>
<li>Some have the words �More options for�� written in front of them&nbsp;</li> 
<li>If you select one of these and click ''Next'', you will be given a list of all the locations that exist within this first location&nbsp;</li> 
<li>If you then click ''Back'', the first list of options will appear again</li></ul>
<p>&nbsp;</p>
<p><strong>Changing the kind of location</strong></p>
<p><strong></strong>&nbsp;</p>
<p>If the Journey Planner didn''t find any matches for the location you typed in, it may be because the Journey Planner didn''t match the type of location with the location you typed in.</p>
<p>&nbsp;</p>
<p></p>
<p>Select another kind of location (e.g. ''Address/postcode'') and select the button next it.&nbsp; The Journey Planner will then show you a list of possible locations for this kind of location.</p>
<p>&nbsp;</p>
<p>It is important that you select the appropriate type of location.&nbsp; For example, if you are looking for a railway station, but you select the ''Address/postcode'' category, the Journey Planner will not be able to find it. </p>
<p>&nbsp;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Address/postcode":</strong> If you select this, you can type in part or all of an address and/or a postcode,<br/>e.g. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. If you don''t know the postcode include as much of the address as possible
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''City/town/suburb'':</strong> If you select this, you can type in the name of a city, town, borough, district, area, suburb, village or hamlet, <br/>e.g. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Attraction/facility'':</strong> If you select this, you can type in the name of an attraction or facility, including: hotels, schools, universities, hospitals, surgeries, sports grounds, theatres, cinemas, tourist attractions, museums, government buildings, police stations,<br/>e.g. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Station/airport'':</strong>&nbsp; If you select this, you can type in the name of a railway station, a coach station, an airport or a ferry terminal.&nbsp; You may also type in the name of a town and choose to travel from any of the stations in this town,<br/>e.g. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''All stops'':</strong> If you select this, you can type in the name of a bus stop, an underground stop, a metro stop, or a tram stop,<br/>e.g. �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>Entering a new location</strong></p>
<p><br/>To enter a new location:</p> 
<ul>
<li>Click ''New location''</li> 
<li>Type the location name in the box</li></ul>
<p>&nbsp;</p>
<p>It is best to type in the full location name so that you get the fewest ''similar matches'' returned to you.&nbsp; Punctuation and use of capital letters are <strong>not</strong> important.</p>
<p><br/>If you are not sure how to spell the name of the location, you can tick the ''Unsure of spelling'' box so that the Journey Planner will also search for locations that sound similar to the one you type in.</p>
<p><br/>If you do not know the full location name, type in as much as you know and put an asterisk&nbsp;&nbsp;&nbsp;&nbsp; * after the letters.<br/></p>
<p class="helpindent2">e.g. If you selected ''Station/airport'' and typed in �Kin*� you would get all the stations and airports in Britain that start with the letters Kin � �Kinsbrace�, �Kingham�, �Kings Cross Thameslink�, �Kings Cross��etc</p>
<p><br/><strong>Once you have confirmed the location, click ''Next''.</strong></p>
<p>&nbsp;</p>'
,'<h1>Cadarnhau lleoliad i''w ddangos ar y map</h1>
<p>&nbsp;</p>
<p>Yn dibynnu ar yr wybodaeth a roddwyd, bydd angen i chi wneud <strong>un</strong> o''r canlynol:</p> 
<ul>
<li>Dewis lleoliad o''r rhestr a ollyngir i lawr.&nbsp; Nodwch os yw''r lleoliad y dymunwch deithio ohono eisoes yn weladwy yn y blwch melyn, nid oes angen i chi ei ail-ddewis</li>
<li>Chwilio am y lleoliad fel math gwahanol o leoliad</li>
<li>Rhoi lleoliad newydd </li></ul>
<p>&nbsp;</p>
<p><strong>Dewis lleoliad o''r rhestr</strong></p>
<p>&nbsp;</p>
<p>Os oedd mwy nag un gyfatebiaeth ar gyfer y lleoliad y bu i chi ei deipio:</p> 
<ul>
<li>Dewiswch un o''r opsiynau yn y rhestr</li> 
<li>Cliciwch ar ''Nesa'' ar waelod y dudalen</li></ul>
<p>&nbsp;</p>
<p>Mae gan rai lleoliadau leoliadau pellach o''u mewn:&nbsp;</p> 
<ul>
<li>Mae gan rai y geiriau �Mwy o ddewisiadau ar gyfer ...� wedi eu hysgrifennu o''u blaenau &nbsp;</li> 
<li>Os dewiswch un o''r rhain a chlicio ar ''Nesa'', rhoddir rhestr o''r holl leoliadau sy''n bodoli o fewn y lleoliad cyntaf hwn i chi</li> 
<li>Os ydych wedyn yn clicio ''Yn �l'', bydd y rhestr gyntaf o ddewisiadau yn ymddangos eto</li></ul>
<p>&nbsp;</p>
<p><strong>Newid y math o leoliad</strong></p>
<p><strong></strong>&nbsp;</p>
<p>Os na wnaeth y Cynlluniwr Siwrnai ddod o hyd i unrhyw gyfatebiaethau ar gyfer y lleoliad y bu i chi ei deipio, gall hyn fod oherwydd nad oedd y Cynlluniwr Siwrnai wedi cyfateb y math o leoliad gyda''r lleoliad y bu i chi ei deipio.</p>
<p>&nbsp;</p>
<p></p>
<p>Dewiswch fath arall o leoliad (e.e. ''Cyfeiriad/c�d post'') a dewiswch y botwm yn ei ymyl.&nbsp; Yna bydd y Cynlluniwr Siwrnai yn dangos rhestr o leoliadau posibl i chi ar gyfer y math hwn o leoliad.</p>
<p>&nbsp;</p>
<p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad.&nbsp; Er enghraifft, os ydych yn chwilio am orsaf rheilffordd, ond wedi dewis y categori ''Cyfeiriad/c�d post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddi. </p>
<p>&nbsp;</p>
<p class="helpindent1">Disgrifir y categor�au isod:</p>
<p>&nbsp;</p>
<ul>
<li><strong>''Cyfeiriad/cod post":</strong> Os dewiswch hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post,<br/>e.e. �3 Burleigh Road�, �3 Burleigh Road, Stretford�, �Burleigh Road, Stretford, Manchester�, �3 Burleigh Road, M32 0PF�, �M32 0PF�. Os nad ydych yn gwybod y cod post cynhwyswch gymaint o''r cyfeiriad � phosibl
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Dinas/tref/maestref'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth, ardal, maestref, pentref neu bentref bychan,<br/>e.e. �Manchester�, �Maidenhead�, �Anfield�, �Hockley�, �Chelsea�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Atyniad/cyfleuster'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw''r atyniad neu''r cyfleuster, gan gynnwys:&nbsp; gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, meysydd chwaraeon, theatrau, sinem�u, atyniadau twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd yr heddlu,<br/>e.e. �Edinburgh Castle�, �Queen''s Head Hotel�, �British Museum�, �Arsenal Football Club�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Gorsaf/maes awyr'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus, maes awyr neu derfynnell fferi.&nbsp; Gallwch hefyd deipio enw tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,<br/>e.e. �Kings Cross�, �London�, Derby�, �Newcastle�, �Gatwick�, �Victoria Coach Station�
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Pob arhosfan'':</strong>&nbsp; Os dewiswch hwn, gallwch deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan metro, neu arhosfan tramiau,<br/>e.e �Trafalgar Square bus stop�, �Whitley Bay�, �Piccadilly Circus�</li></ul>
<p>&nbsp;</p>
<p><strong>Nodi lleoliad newydd</strong></p>
<p><br/>I nodi lleoliad newydd:</p> 
<ul>
<li>Cliciwch ''Lleoliad newydd''</li> 
<li>Teipiwch enw''r lleoliad yn y blwch</li></ul>
<p>&nbsp;</p>
<p>Mae''n well teipio enw''r lleoliad yn llawn fel y gallwch gael y nifer lleiaf o ''gyfatebiaethau tebyg'' wedi eu hanfon yn �l atoch.&nbsp; <strong>Nid</strong> yw atalnodi a defnyddio prif lythrennau yn bwysig.</p>
<p><br/>Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un yr ydych yn ei deipio.</p>
<p><br/>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint ag a wyddoch a rhowch * ar �l y llythrennau.<br/></p>
<p class="helpindent2">e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio �Kin*� byddech yn cael yr holl orsafoedd a''r meysydd awyr ym Mhrydain sy''n dechrau gyda''r llythrennau Kin - �Kinsbrace�, �Kingham�, �King''s Cross Thameslink�, �King''s Cross��ac ati</p>
<p><br/><strong>Wedi i chi gadarnhau''r lleoliad, cliciwch ar ''Nesa''.</strong></p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpMapTools'
,'<h1>Location map tools</h1>
<p><strong></strong>&nbsp;</p>
<p><strong>You can use the tools in this section to:</strong></p> 
<ul>
<li>Navigate around the map</li> 
<li>Find information about points on the map</li> 
<li>Select a new point on the map</li></ul>
<p>&nbsp;</p>
<p><strong>Map navigation buttons:</strong></p>
<ul>
<li><strong>''Zoom in''<br/></strong>Allows you to zoom into the map so that you can view more detail.&nbsp; 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Zoom out''<br/></strong>Allows you to zoom out so that you are able to view more of the surrounding areas, but less detail.
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Zoom bar''<br/></strong>This tool allows you to zoom in or out of the map quickly by clicking on one of the bars.&nbsp; ''Zoom level 13'' is closest to ''Zoom in +'' and will show you more detail than ''Zoom level 1'', which is closest to ''Zoom in -'', and will show you the least detail. 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Previous map''<br/></strong>Allows you to view the map as it was before your last action. 
<p></p>
<p>&nbsp;</p></li>
<li><strong>''Select new location''</strong><strong><br/></strong>Click ''Select new location'' to search for a map of a new location. </li></ul>
<p></p>
<p>&nbsp;</p>
<ul>
<li><strong>Navigation arrows<br/></strong>Click the arrows on the edge of the map to move up, down, left, right or diagonally. The map will then represent the areas you are navigating towards.</li></ul>
<p>&nbsp;</p>
<p><strong>''Plan a journey'' button<br/></strong>&nbsp;<br/></p>
<p>Clicking on ''Plan a journey'' will give you the choice to plan a journey <strong>to</strong> or <strong>from</strong>&nbsp;the current location showing on the map.</p>
<p></p>
<p>If you want to travel to or from the location currently shown on the map:</p> 
<p></p>
<ol class="numberlist">
<li>Click ''Plan a journey''</li> 
<li>Click either ''Travel <strong>from</strong> this location'' or ''Travel <strong>to</strong> this location''</li></ol>
<p></p>
<p>If you want to travel to or from a new location:</p> 
<p></p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the navigation tools so that you can see the location you wish to travel from or to </li> 
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the&nbsp;locations within 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li>  
<li>Click ''Plan a journey''</li>  
<li>Click either ''Travel <strong>from</strong> this location'' or ''Travel <strong>to</strong> this location''</li></ol>
<p><strong>''i'' button</strong></p>
<p><strong></strong><br/>Clicking on ''i'' will take you to a page which will give you information about the current location (if it is available).</p>
<p>If you want information about a new location:</p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the navigation tools so that you can see the location you wish to travel from or to</li>  
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the locations within 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li>  
<li>Click ''i'' </li></ol>
<p><strong>''Select new location'' button</strong><strong><br/></strong>&nbsp; <br/>Clicking on ''Select new location'' will allow you to select a location so that you can view a map of it and then proceed with either planning a journey or finding information. </p>
<ol class="numberlist">
<li>Click ''Select new location''</li>  
<li>Use the pointer to click on the location, and you will be shown a drop-down list of all the locations with 50 metres of where you clicked</li>  
<li>Choose the location from the drop-down list and click ''OK''</li></ol>
<p><strong>To stop any action process click ''Cancel''.</strong></p>
<p>&nbsp;</p>
<p><strong>If you want to print out the map, click ''Printer friendly''.&nbsp; This will open a ''printer friendly'' page that you can print as normal.<br/></strong></p>'
,'<h1>Teclynnau map lleoliad</h1>
<p><strong></strong>&nbsp;</p>
<p><strong>Gallwch ddefnyddio''r teclynnau yn yr adran hon i:</strong></p> 
<ul>
<li>Symud o gwmpas y map</li>  
<li>Darganfod gwybodaeth am bwyntiau ar y map</li>  
<li>Dewis pwynt newydd ar y map</li></ul>
<p>&nbsp;</p>
<p><strong>Botymau i symud o gwmpas y map:</strong></p>
<ul>
<li><strong>''Chwyddo''r map''<br/></strong>Mae''n caniat�u i chi chwyddo''r map fel y gallwch weld yn fwy manwl. &nbsp; 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Lleihau''r map''<br/></strong>Mae''n caniat�u i chi leihau''r map fel y gallwch weld mwy o''r ardaloedd cyfagos, ond llai o fanylder. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Bar chwyddo/lleihau''<br/></strong>Mae''r teclyn hwn yn caniat�u i chi chwyddo neu leihau''r map yn gyflym drwy glicio ar un o''r bariau.&nbsp; ""Lefel chwyddo 13 yw''r agosaf at ''Chwyddo +'' a bydd yn dangos i chi fwy o fanylion na ''Lefel chwyddo 1'' sydd agosaf at ''Chwyddo � '' a bydd yn dangos i chi''r lleiaf o fanylder. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Golygfa flaenorol''<br/></strong>Mae''n caniat�u i chi weld y map fel ag yr oedd cyn i chi weithredu y tro diwethaf. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>''Darganfod map newydd''<br/></strong>Cliciwch ar ''Darganfod map newydd'' i chwilio am fap o leoliad newydd. 
<p></p>
<p>&nbsp;</p></li> 
<li><strong>Saethau cyfeirio<br/></strong>Cliciwch ar y saethau ar ymyl y map i symud i fyny, i lawr, i''r chwith, i''r dde neu ar draws. Yna bydd y map yn cynrychioli''r ardaloedd yr ydych yn symud tuag atynt.</li></ul>
<p>&nbsp;</p>
<p><strong>Botwm ''Cynlluniwch siwrnai'' <br/></strong>&nbsp;<br/></p>
<p>Bydd clicio ''Cynlluniwch siwrnai'' yn rhoi dewis i chi gynllunio siwrnai <strong>i</strong> neu <strong>o</strong>''r lleoliad cyfredol a ddangosir ar y map.</p>
<p></p>
<p>Os ydych am deithio i neu o''r lleoliad cyfredol a ddangosir ar y map:</p> 
<p></p>
<ol class="numberlist">
<li>Cliciwch ar ''Cynlluniwch siwrnai''&nbsp;&nbsp;</li>  
<li>Cliciwch un ai ''Teithio <strong>o</strong>''r lleoliad hwn" neu ''Teithio <strong>i</strong>''r lleoliad hwn''</li></ol>
<p></p>
<p>Os ydych am deithio i neu o leoliad newydd:</p> 
<p></p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld y lleoliad rydych am deithio o neu i</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a byddwch yn gweld rhestr a ollyngir i lawr o''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad o''r rhestr a ollyngir i lawr a chliciwch ''Iawn"</li>  
<li>Cliciwch ''Cynlluniwch siwrnai''</li>  
<li>Cliciwch un ai ''Teithio o''r lleoliad hwn'' neu ''Teithio i''r lleoliad hwn'' </li></ol>
<p>&nbsp;</p>
<p><strong>Botwm ''Gwybodaeth''</strong></p>
<p><strong></strong><br/>Bydd clicio ar ''Gwybodaeth'' yn eich arwain at dudalen a fydd yn rhoi gwybodaeth ynghylch y lleoliad cyfredol (os yw ar gael).&nbsp; </p>
<p>Os bydd angen gwybodaeth ynghylch lleoliad newydd arnoch:</p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld y lleoliad rydych yn dymuno teithio i neu oddi yno</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a chliciwch ''Iawn''</li>  
<li>Cliciwch ''Gwybodaeth''</li></ol>
<p><strong></strong>&nbsp;</p>
<p><strong>''Botwm ''Dewiswch leoliad newydd''</strong><strong><br/></strong>&nbsp; <br/>Bydd clicio ar ''Dewiswch leoliad newydd'' yn eich galluogi i ddewis lleoliad fel eich bod yn gallu gweld map ac yna mynd ymlaen un ai i gynllunio siwrnai neu ddod o hyd i wybodaeth. </p>
<ol class="numberlist">
<li>Cliciwch ''Dewiswch leoliad newydd''</li>  
<li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50 metr o''r man a gliciwyd arno</li>  
<li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a chliciwch ''Iawn''</li></ol>
<p><strong>I atal unrhyw weithred cliciwch ar ''Dileu''.</strong></p>
<p>&nbsp;</p>
<p><strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawwd ei argraffu''.&nbsp; Bydd hyn yn agor tudalen arbennig y gallwch ei hargraffu fel arfer.</strong></p>'


GO

-- AdjustFullItinerarySummary.aspx page help content
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpAdjustFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by altering the time allowed at a certain point of your original journey plan.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey was from London to Beccles and involved changing trains three times. At Ipswich, the recommended change interval was 10 minutes but you wanted to allow more time as you knew you would have heavy luggage with you.</li>
<li>You altered the overall journey by choosing to see the next service leaving from Ipswich.</li>
<li>Transport Direct found the next journey combination which gives you the required additional time in Ipswich.</li></ul></div></div>
<br/><p></p>
<p>This page gives a summarised view of the whole end-to-end journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the entire journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<h3>Would you like to adjust this journey again?</h3><br/><br/>
<p>Transport Direct allows you to keep making this kind of adjustment to your overall journey as many times as you wish.</p><br/>
<p>If your overall journey is made up of an outward and return journey, then you must first choose which journey direction to work on. Choose from the options in the drop down menu then press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy newid yr amser a ganiateir mewn un pwynt arbennig yng nghynllun eich siwrnai wreiddiol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd eich siwrnai wreiddiol o Lundain i Beccles ac roedd yn golygu newid trenau dair gwaith. Yn Ipswich, yr amser a argymhellwyd ar gyfer y newid oedd 10 munud ond roeddech am gael mwy o amser oherwydd roeddech yn gwybod y byddai gennych gesys trwm gyda chi.</li>
<li>Bu i chi newid y siwrnai gyffredinol drwy ddewis gweld y gwasanaeth nesaf yn gadael o Ipswich.</li>
<li>Canfu Transport Direct y cyfuniad nesaf ar gyfer y siwrnai sy''n rhoi''r amser ychwanegol angenrheidiol i chi yn Ipswich.</li></ul></div></div>
<br/><p></p>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyfan o un pen i''r llall. Mae''n dangos yr holl fathau o gludiant fydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai gyfan ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<h3>Hoffech chi addasu''r siwrnai hon eto?</h3><br/><br/>
<p>Mae Transport Direct yn caniat�u i chi ddal ati i wneud y math hwn o addasiad i''ch siwrnai gyffredinol cymaint o weithiau ag y dymunwch.</p><br/>
<p>Os yw eich siwrnai gyffredinol yn cynnwys siwrnai yn �l ac ymlaen, yna rhaid i chi yn gyntaf ddewis pa gyfeiriad o''r siwrnai i weithio arno. Dewiswch o''r dewisiadau yn y ddewislen a ollyngir i lawr yna gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpAdjustFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by altering the time allowed at a certain point of your original journey plan.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey was from London to Beccles and involved changing trains three times. At Ipswich, the recommended change interval was 10 minutes but you wanted to allow more time as you knew you would have heavy luggage with you.</li>
<li>You altered the overall journey by choosing to see the next service leaving from Ipswich.</li>
<li>Transport Direct found the next journey combination which gives you the required additional time in Ipswich.</li></ul></div></div>
<br/><p></p>
<p>This page gives a summarised view of the whole end-to-end journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the entire journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<h3>Would you like to adjust this journey again?</h3><br/><br/>
<p>Transport Direct allows you to keep making this kind of adjustment to your overall journey as many times as you wish.</p><br/>
<p>If your overall journey is made up of an outward and return journey, then you must first choose which journey direction to work on. Choose from the options in the drop down menu then press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy newid yr amser a ganiateir mewn un pwynt arbennig yng nghynllun eich siwrnai wreiddiol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd eich siwrnai wreiddiol o Lundain i Beccles ac roedd yn golygu newid trenau dair gwaith. Yn Ipswich, yr amser a argymhellwyd ar gyfer y newid oedd 10 munud ond roeddech am gael mwy o amser oherwydd roeddech yn gwybod y byddai gennych gesys trwm gyda chi.</li>
<li>Bu i chi newid y siwrnai gyffredinol drwy ddewis gweld y gwasanaeth nesaf yn gadael o Ipswich.</li>
<li>Canfu Transport Direct y cyfuniad nesaf ar gyfer y siwrnai sy''n rhoi''r amser ychwanegol angenrheidiol i chi yn Ipswich.</li></ul></div></div>
<br/><p></p>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyfan o un pen i''r llall. Mae''n dangos yr holl fathau o gludiant fydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai gyfan ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<h3>Hoffech chi addasu''r siwrnai hon eto?</h3><br/><br/>
<p>Mae Transport Direct yn caniat�u i chi ddal ati i wneud y math hwn o addasiad i''ch siwrnai gyffredinol cymaint o weithiau ag y dymunwch.</p><br/>
<p>Os yw eich siwrnai gyffredinol yn cynnwys siwrnai yn �l ac ymlaen, yna rhaid i chi yn gyntaf ddewis pa gyfeiriad o''r siwrnai i weithio arno. Dewiswch o''r dewisiadau yn y ddewislen a ollyngir i lawr yna gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpAdjustFullItinerarySummary'
,'<h3>View the overall journey</h3><br/><br/>
<p>You have created a new journey by altering the time allowed at a certain point of your original journey plan.</p><br/>
<div class="boxtypenineinner">
<p>For example: </p>
<div>
<ul>
<li>Your original journey was from London to Beccles and involved changing trains three times. At Ipswich, the recommended change interval was 10 minutes but you wanted to allow more time as you knew you would have heavy luggage with you.</li>
<li>You altered the overall journey by choosing to see the next service leaving from Ipswich.</li>
<li>Transport Direct found the next journey combination which gives you the required additional time in Ipswich.</li></ul></div></div>
<br/><p></p>
<p>This page gives a summarised view of the whole end-to-end journey. It shows all of the types of transport you will need to take, in the sequence you will have to make the changes. It shows what time to start your journey and how long the entire journey will take.</p><br/>
<p>It is possible to view further information about the entire journey in the form of a detailed breakdown, tickets/costs and fare information, and a map showing all or part of the journey route. Choose your preferred view from the menu and press "OK".</p><br/>
<h3>Would you like to adjust this journey again?</h3><br/><br/>
<p>Transport Direct allows you to keep making this kind of adjustment to your overall journey as many times as you wish.</p><br/>
<p>If your overall journey is made up of an outward and return journey, then you must first choose which journey direction to work on. Choose from the options in the drop down menu then press "OK".</p><br/>
<p>If you have finished planning this journey, press "New Search" to ask Transport Direct to start with a fresh journey request.</p>'
,'<h3>Edrychwch ar y siwrnai gyffredinol</h3><br/><br/>
<p>Rydych wedi creu siwrnai newydd drwy newid yr amser a ganiateir mewn un pwynt arbennig yng nghynllun eich siwrnai wreiddiol.</p><br/>
<div class="boxtypenineinner">
<p>Er enghraifft: </p>
<div>
<ul>
<li>Roedd eich siwrnai wreiddiol o Lundain i Beccles ac roedd yn golygu newid trenau dair gwaith. Yn Ipswich, yr amser a argymhellwyd ar gyfer y newid oedd 10 munud ond roeddech am gael mwy o amser oherwydd roeddech yn gwybod y byddai gennych gesys trwm gyda chi.</li>
<li>Bu i chi newid y siwrnai gyffredinol drwy ddewis gweld y gwasanaeth nesaf yn gadael o Ipswich.</li>
<li>Canfu Transport Direct y cyfuniad nesaf ar gyfer y siwrnai sy''n rhoi''r amser ychwanegol angenrheidiol i chi yn Ipswich.</li></ul></div></div>
<br/><p></p>
<p>Mae''r dudalen hon yn rhoi crynodeb o''r siwrnai gyfan o un pen i''r llall. Mae''n dangos yr holl fathau o gludiant fydd angen i chi eu cymryd, yn y dilyniant y bydd yn rhaid i chi wneud y newidiadau. Mae''n dangos pryd i ddechrau eich siwrnai a pha mor hir y bydd y siwrnai gyfan yn ei gymryd.</p><br/>
<p>Mae''n bosib gweld gwybodaeth bellach am y siwrnai gyfan ar ffurf manylion llawn, tocynnau/costau a gwybodaeth am brisiau tocynnau, a map yn dangos y cyfan neu ran o lwybr y siwrnai. Dewiswch yr un a ddymunwch o''r ddewislen a gwasgwch ''Iawn''.</p><br/>
<h3>Hoffech chi addasu''r siwrnai hon eto?</h3><br/><br/>
<p>Mae Transport Direct yn caniat�u i chi ddal ati i wneud y math hwn o addasiad i''ch siwrnai gyffredinol cymaint o weithiau ag y dymunwch.</p><br/>
<p>Os yw eich siwrnai gyffredinol yn cynnwys siwrnai yn �l ac ymlaen, yna rhaid i chi yn gyntaf ddewis pa gyfeiriad o''r siwrnai i weithio arno. Dewiswch o''r dewisiadau yn y ddewislen a ollyngir i lawr yna gwasgwch ''Iawn''.</p><br/>
<p>Os ydych wedi gorffen cynllunio''r siwrnai hon, gwasgwch ''Ymchwil newydd'' i ofyn i Transport Direct ddechrau gyda chais am siwrnai newydd.</p>'

GO

-- HelpToolBar.aspx page help content
EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpToolBar'
,'<p>The Toolbar allows you both quick access to the Transport Direct website and to plan a journey by only having to enter two postcodes.&nbsp; </p>
<p>&nbsp;</p>
<p>Click the arrow next to the Transport Direct logo to go directly to the following Transport Direct pages:</p>
<p><br/>. Transport Direct homepage <br/>. Live travel information<br/>. Plan a journey<br/>. Find a place<br/>------------------------------<br/>. Toolbar options<br/>. Clear Toolbar search history<br/>. Toolbar help</p>
<p>&nbsp;</p>
<h5>Toolbar Options</h5>
<p>&nbsp;</p>
<h5>Save search requests during and across sessions</h5>
<p><br/>If selected, any postcode you enter will be saved so that you can simply select it again from the dropdown lists below the text boxes to use in a new journey plan.</p>
<p>&nbsp;</p>
<h5>Start Transport Direct in a new window</h5>
<p><br/>If selected, a new window will appear each time you select an option or click "Go" on the Toolbar.</p>
<p>&nbsp;</p>
<h5>Settings</h5>
<p><br/>This allows you to specify settings for the Toolbar:</p>
<p>&nbsp;</p>
<h5>Specify a default origin</h5>
<p><br/>Enter a postcode that you travel from frequently and tick the box if you would like the postcode to appear as a default on the Toolbar.&nbsp; e.g.&nbsp; You may want to enter your home or work postcode.</p>
<p>&nbsp;</p>
<h5>Specify a default destination</h5>
<p><br/>Enter a postcode that you travel to frequently and tick the box if you would like the postcode to appear as a default on the Toolbar. </p>
<p>&nbsp;</p>
<h5>Include car journey in planning options</h5>
<p><br/>If selected, the journey planner will automatically search for car journeys as well as public transport journeys.&nbsp; If unselected, the journey planner will search for public transport journeys only.</p>
<p>&nbsp;</p>
<h5>Specifying date and time</h5>
<p>&nbsp;</p>
<p>Selecting "Automatically plan journey using date and time of the request" will give any journeys you plan via the toolbar a departure time of NOW (the current date and time).&nbsp; Alternatively, select "Allow input of dates before planning journey" to be taken to the Transport Direct journey planner input page where you can specify times of travel and request a return journey.</p>
<p>&nbsp;</p>
<h5>Clear search history </h5>
<p>&nbsp;</p>
<p>If clicked, this will clear all your previous journey searches.</p>'
,'<p>Mae''r Bar Offer yn rhoi mynediad cyflym i chi at wefan Transport Direct ac i gynllunio siwrnai drwy orfod nodi dau g�d post yn unig.&nbsp; </p>
<p>&nbsp;</p>
<p>Cliciwch y saeth ger logo Transport Direct i fynd yn uniongyrchol i dudalennau canlynol Transport Direct:</p>
<p><br/>. Tudalen gartref Transport Direct <br/>. Gwybodaeth teithio byw<br/>. Cynlluniwch siwrnai<br/>. Canfyddwch le<br/>------------------------------<br/>. Dewisiadau''r Bar Offer<br/>. Clirio hanes chwiliad y Bar Offer<br/>. Cymorth y Bar Offer</p>
<p>&nbsp;</p>
<h5>Dewisiadau''r Bar Offer</h5>
<p>&nbsp;</p>
<h5>Cadwch geisiadau am chwiliad yn ystod ac ar draws sesiynau</h5>
<p><br/>Os caiff ei ddewis, bydd unrhyw g�d post a nodwch yn cael ei gadw fel y gallwch ei ddewis eto o''r rhestrau a ollyngir i lawr islaw''r blychau testun i''w ddefnyddio mewn cynllun siwrnai newydd.</p>
<p>&nbsp;</p>
<h5>Dechreuwch Transport Direct mewn ffenestr newydd</h5>
<p><br/>Os caiff ei ddewis, bydd ffenestr newydd yn ymddangos bob tro y dewiswch opsiwn neu cliciwch "Ewch" ar y Bar Offer.</p>
<p>&nbsp;</p>
<h5>Setiadau</h5>
<p><br/>Mae hyn yn caniatau i chi nodi setiadau ar gyfer y Bar Offer:</p>
<p>&nbsp;</p>
<h5>Nodwch darddiad diofyn</h5>
<p><br/>Nodwch g�d post yr ydych yn teithio ohono yn aml a thiciwch y blwch os hoffech i''r c�d post ymddangos fel un diofyn ar y Bar Offer.&nbsp; e.e.&nbsp; Efallai y dymunwch nodi c�d post eich cartref neu waith.</p>
<p>&nbsp;</p>
<h5>Nodwch gyrchfan diofyn</h5>
<p><br/>Nodwch g�d post yr ydych yn teithio iddo yn aml a thiciwch y blwch os hoffech i''r c�d post ymddangos fel un diofyn ar y Bar Offer. </p>
<p>&nbsp;</p>
<h5>Cynhwyswch siwrnai car mewn dewisiadau cynllunio</h5>
<p><br/>Os dewisir ef, bydd y cynlluniwr siwrnai yn chwilio yn awtomatig am siwrneion ceir yn ogystal � siwrneion ar gludiant cyhoeddus.&nbsp; Os na chaiff ei ddewis, bydd y cynlluniwr siwrnai yn chwilio am siwrneion cludiant cyhoeddus yn unig.</p>
<p>&nbsp;</p>
<h5>Nodi dyddiad ac amser</h5>
<p>&nbsp;</p>
<p>Bydd dewis "Cynlluniwch siwrnai yn awtomatig gan ddefnyddio dyddiad ac amser y cais" yn rhoi i unrhyw siwrneion a gynlluniwch trwy gyfrwng y bar offer amser ymadael o YN AWR (y dyddiad a''r amser cyfredol).&nbsp; Neu, dewiswch "Caniatewch fewnbynnu dyddiadau cyn cynllunio''r siwrnai" i fynd i dudalen mewnbynnu cynlluniwr siwrnai Transport Direct ble y gallwch nodi amserau teithio a gofyn am siwrnai ddychwel.</p>
<p>&nbsp;</p>
<h5>Clirio hanes chwiliad </h5>
<p>&nbsp;</p>
<p>Os clicir ar hwn, bydd hyn yn clirio eich holl chwiliadau am siwrneion blaenorol.</p>'

EXEC AddtblContent
1, 10, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpToolBar'
,'<p>The Toolbar allows you both quick access to the Transport Direct website and to plan a journey by only having to enter two postcodes.&nbsp; </p>
<p>&nbsp;</p>
<p>Click the arrow next to the Transport Direct logo to go directly to the following Transport Direct pages:</p>
<p><br/>. Transport Direct homepage <br/>. Live travel information<br/>. Plan a journey<br/>. Find a place<br/>------------------------------<br/>. Toolbar options<br/>. Clear Toolbar search history<br/>. Toolbar help</p>
<p>&nbsp;</p>
<h5>Toolbar Options</h5>
<p>&nbsp;</p>
<h5>Save search requests during and across sessions</h5>
<p><br/>If selected, any postcode you enter will be saved so that you can simply select it again from the dropdown lists below the text boxes to use in a new journey plan.</p>
<p>&nbsp;</p>
<h5>Start Transport Direct in a new window</h5>
<p><br/>If selected, a new window will appear each time you select an option or click "Go" on the Toolbar.</p>
<p>&nbsp;</p>
<h5>Settings</h5>
<p><br/>This allows you to specify settings for the Toolbar:</p>
<p>&nbsp;</p>
<h5>Specify a default origin</h5>
<p><br/>Enter a postcode that you travel from frequently and tick the box if you would like the postcode to appear as a default on the Toolbar.&nbsp; e.g.&nbsp; You may want to enter your home or work postcode.</p>
<p>&nbsp;</p>
<h5>Specify a default destination</h5>
<p><br/>Enter a postcode that you travel to frequently and tick the box if you would like the postcode to appear as a default on the Toolbar. </p>
<p>&nbsp;</p>
<h5>Include car journey in planning options</h5>
<p><br/>If selected, the journey planner will automatically search for car journeys as well as public transport journeys.&nbsp; If unselected, the journey planner will search for public transport journeys only.</p>
<p>&nbsp;</p>
<h5>Specifying date and time</h5>
<p>&nbsp;</p>
<p>Selecting "Automatically plan journey using date and time of the request" will give any journeys you plan via the toolbar a departure time of NOW (the current date and time).&nbsp; Alternatively, select "Allow input of dates before planning journey" to be taken to the Transport Direct journey planner input page where you can specify times of travel and request a return journey.</p>
<p>&nbsp;</p>
<h5>Clear search history </h5>
<p>&nbsp;</p>
<p>If clicked, this will clear all your previous journey searches.</p>'
,'<p>Mae''r Bar Offer yn rhoi mynediad cyflym i chi at wefan Transport Direct ac i gynllunio siwrnai drwy orfod nodi dau g�d post yn unig.&nbsp; </p>
<p>&nbsp;</p>
<p>Cliciwch y saeth ger logo Transport Direct i fynd yn uniongyrchol i dudalennau canlynol Transport Direct:</p>
<p><br/>. Tudalen gartref Transport Direct <br/>. Gwybodaeth teithio byw<br/>. Cynlluniwch siwrnai<br/>. Canfyddwch le<br/>------------------------------<br/>. Dewisiadau''r Bar Offer<br/>. Clirio hanes chwiliad y Bar Offer<br/>. Cymorth y Bar Offer</p>
<p>&nbsp;</p>
<h5>Dewisiadau''r Bar Offer</h5>
<p>&nbsp;</p>
<h5>Cadwch geisiadau am chwiliad yn ystod ac ar draws sesiynau</h5>
<p><br/>Os caiff ei ddewis, bydd unrhyw g�d post a nodwch yn cael ei gadw fel y gallwch ei ddewis eto o''r rhestrau a ollyngir i lawr islaw''r blychau testun i''w ddefnyddio mewn cynllun siwrnai newydd.</p>
<p>&nbsp;</p>
<h5>Dechreuwch Transport Direct mewn ffenestr newydd</h5>
<p><br/>Os caiff ei ddewis, bydd ffenestr newydd yn ymddangos bob tro y dewiswch opsiwn neu cliciwch "Ewch" ar y Bar Offer.</p>
<p>&nbsp;</p>
<h5>Setiadau</h5>
<p><br/>Mae hyn yn caniatau i chi nodi setiadau ar gyfer y Bar Offer:</p>
<p>&nbsp;</p>
<h5>Nodwch darddiad diofyn</h5>
<p><br/>Nodwch g�d post yr ydych yn teithio ohono yn aml a thiciwch y blwch os hoffech i''r c�d post ymddangos fel un diofyn ar y Bar Offer.&nbsp; e.e.&nbsp; Efallai y dymunwch nodi c�d post eich cartref neu waith.</p>
<p>&nbsp;</p>
<h5>Nodwch gyrchfan diofyn</h5>
<p><br/>Nodwch g�d post yr ydych yn teithio iddo yn aml a thiciwch y blwch os hoffech i''r c�d post ymddangos fel un diofyn ar y Bar Offer. </p>
<p>&nbsp;</p>
<h5>Cynhwyswch siwrnai car mewn dewisiadau cynllunio</h5>
<p><br/>Os dewisir ef, bydd y cynlluniwr siwrnai yn chwilio yn awtomatig am siwrneion ceir yn ogystal � siwrneion ar gludiant cyhoeddus.&nbsp; Os na chaiff ei ddewis, bydd y cynlluniwr siwrnai yn chwilio am siwrneion cludiant cyhoeddus yn unig.</p>
<p>&nbsp;</p>
<h5>Nodi dyddiad ac amser</h5>
<p>&nbsp;</p>
<p>Bydd dewis "Cynlluniwch siwrnai yn awtomatig gan ddefnyddio dyddiad ac amser y cais" yn rhoi i unrhyw siwrneion a gynlluniwch trwy gyfrwng y bar offer amser ymadael o YN AWR (y dyddiad a''r amser cyfredol).&nbsp; Neu, dewiswch "Caniatewch fewnbynnu dyddiadau cyn cynllunio''r siwrnai" i fynd i dudalen mewnbynnu cynlluniwr siwrnai Transport Direct ble y gallwch nodi amserau teithio a gofyn am siwrnai ddychwel.</p>
<p>&nbsp;</p>
<h5>Clirio hanes chwiliad </h5>
<p>&nbsp;</p>
<p>Os clicir ar hwn, bydd hyn yn clirio eich holl chwiliadau am siwrneion blaenorol.</p>'

EXEC AddtblContent
1, 11, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpToolBar'
,'<p>The Toolbar allows you both quick access to the Transport Direct website and to plan a journey by only having to enter two postcodes.&nbsp; </p>
<p>&nbsp;</p>
<p>Click the arrow next to the Transport Direct logo to go directly to the following Transport Direct pages:</p>
<p><br/>. Transport Direct homepage <br/>. Live travel information<br/>. Plan a journey<br/>. Find a place<br/>------------------------------<br/>. Toolbar options<br/>. Clear Toolbar search history<br/>. Toolbar help</p>
<p>&nbsp;</p>
<h5>Toolbar Options</h5>
<p>&nbsp;</p>
<h5>Save search requests during and across sessions</h5>
<p><br/>If selected, any postcode you enter will be saved so that you can simply select it again from the dropdown lists below the text boxes to use in a new journey plan.</p>
<p>&nbsp;</p>
<h5>Start Transport Direct in a new window</h5>
<p><br/>If selected, a new window will appear each time you select an option or click "Go" on the Toolbar.</p>
<p>&nbsp;</p>
<h5>Settings</h5>
<p><br/>This allows you to specify settings for the Toolbar:</p>
<p>&nbsp;</p>
<h5>Specify a default origin</h5>
<p><br/>Enter a postcode that you travel from frequently and tick the box if you would like the postcode to appear as a default on the Toolbar.&nbsp; e.g.&nbsp; You may want to enter your home or work postcode.</p>
<p>&nbsp;</p>
<h5>Specify a default destination</h5>
<p><br/>Enter a postcode that you travel to frequently and tick the box if you would like the postcode to appear as a default on the Toolbar. </p>
<p>&nbsp;</p>
<h5>Include car journey in planning options</h5>
<p><br/>If selected, the journey planner will automatically search for car journeys as well as public transport journeys.&nbsp; If unselected, the journey planner will search for public transport journeys only.</p>
<p>&nbsp;</p>
<h5>Specifying date and time</h5>
<p>&nbsp;</p>
<p>Selecting "Automatically plan journey using date and time of the request" will give any journeys you plan via the toolbar a departure time of NOW (the current date and time).&nbsp; Alternatively, select "Allow input of dates before planning journey" to be taken to the Transport Direct journey planner input page where you can specify times of travel and request a return journey.</p>
<p>&nbsp;</p>
<h5>Clear search history </h5>
<p>&nbsp;</p>
<p>If clicked, this will clear all your previous journey searches.</p>'
,'<p>Mae''r Bar Offer yn rhoi mynediad cyflym i chi at wefan Transport Direct ac i gynllunio siwrnai drwy orfod nodi dau g�d post yn unig.&nbsp; </p>
<p>&nbsp;</p>
<p>Cliciwch y saeth ger logo Transport Direct i fynd yn uniongyrchol i dudalennau canlynol Transport Direct:</p>
<p><br/>. Tudalen gartref Transport Direct <br/>. Gwybodaeth teithio byw<br/>. Cynlluniwch siwrnai<br/>. Canfyddwch le<br/>------------------------------<br/>. Dewisiadau''r Bar Offer<br/>. Clirio hanes chwiliad y Bar Offer<br/>. Cymorth y Bar Offer</p>
<p>&nbsp;</p>
<h5>Dewisiadau''r Bar Offer</h5>
<p>&nbsp;</p>
<h5>Cadwch geisiadau am chwiliad yn ystod ac ar draws sesiynau</h5>
<p><br/>Os caiff ei ddewis, bydd unrhyw g�d post a nodwch yn cael ei gadw fel y gallwch ei ddewis eto o''r rhestrau a ollyngir i lawr islaw''r blychau testun i''w ddefnyddio mewn cynllun siwrnai newydd.</p>
<p>&nbsp;</p>
<h5>Dechreuwch Transport Direct mewn ffenestr newydd</h5>
<p><br/>Os caiff ei ddewis, bydd ffenestr newydd yn ymddangos bob tro y dewiswch opsiwn neu cliciwch "Ewch" ar y Bar Offer.</p>
<p>&nbsp;</p>
<h5>Setiadau</h5>
<p><br/>Mae hyn yn caniatau i chi nodi setiadau ar gyfer y Bar Offer:</p>
<p>&nbsp;</p>
<h5>Nodwch darddiad diofyn</h5>
<p><br/>Nodwch g�d post yr ydych yn teithio ohono yn aml a thiciwch y blwch os hoffech i''r c�d post ymddangos fel un diofyn ar y Bar Offer.&nbsp; e.e.&nbsp; Efallai y dymunwch nodi c�d post eich cartref neu waith.</p>
<p>&nbsp;</p>
<h5>Nodwch gyrchfan diofyn</h5>
<p><br/>Nodwch g�d post yr ydych yn teithio iddo yn aml a thiciwch y blwch os hoffech i''r c�d post ymddangos fel un diofyn ar y Bar Offer. </p>
<p>&nbsp;</p>
<h5>Cynhwyswch siwrnai car mewn dewisiadau cynllunio</h5>
<p><br/>Os dewisir ef, bydd y cynlluniwr siwrnai yn chwilio yn awtomatig am siwrneion ceir yn ogystal � siwrneion ar gludiant cyhoeddus.&nbsp; Os na chaiff ei ddewis, bydd y cynlluniwr siwrnai yn chwilio am siwrneion cludiant cyhoeddus yn unig.</p>
<p>&nbsp;</p>
<h5>Nodi dyddiad ac amser</h5>
<p>&nbsp;</p>
<p>Bydd dewis "Cynlluniwch siwrnai yn awtomatig gan ddefnyddio dyddiad ac amser y cais" yn rhoi i unrhyw siwrneion a gynlluniwch trwy gyfrwng y bar offer amser ymadael o YN AWR (y dyddiad a''r amser cyfredol).&nbsp; Neu, dewiswch "Caniatewch fewnbynnu dyddiadau cyn cynllunio''r siwrnai" i fynd i dudalen mewnbynnu cynlluniwr siwrnai Transport Direct ble y gallwch nodi amserau teithio a gofyn am siwrnai ddychwel.</p>
<p>&nbsp;</p>
<h5>Clirio hanes chwiliad </h5>
<p>&nbsp;</p>
<p>Os clicir ar hwn, bydd hyn yn clirio eich holl chwiliadau am siwrneion blaenorol.</p>'

EXEC AddtblContent
1, 2, '_web2_printer_helptoolbar', 'Page'
,'/Web2/helpfulljp.aspx'
,'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, 2, '_web2_printer_helptoolbar', 'QueryString'
,'helpfulljp'
,'helpfulljp'

EXEC AddtblContent
1, 2, '_web2_printer_helptoolbar', 'Channel'
,'/Channels/TransportDirect/Printer/HelpToolbar'
,'/Channels/TransportDirect/Printer/HelpToolbar'


GO

-- TimeOut.aspx page soft content
EXEC AddtblContent
1, 12, 'TimeOutHtmlPlaceholderDefinition', '/Channels/TransportDirect/TimeOut'
,'<p>&nbsp;</p>
<h1>Sorry, your session has expired.</h1>
<p>Your time (session) on Transport Direct expires after 20 minutes of inactivity. The session may also expire following a system error.</p>'
,'<p>&nbsp;</p>
<h1>Mae''n ddrwg gennym, mae eich sesiwn wedi dirwyn i ben.</h1>
<p>Mae eich amser (sesiwn) ar Transport Direct yn dirwyn i ben ar �l 20 munud o fod yn llonydd.&nbsp; Gall y sesiwn ddirwyn i ben hefyd ar �l gwall yn y system.</p>'

GO

-- Feedbackpage.aspx soft content
EXEC AddtblContent
1, 1, 'langStrings', 'FeedbackInitialPage.labelIntroduction.Text'
,'<p style="font-size: 12pt; line-heigt: 1.5;">We welcome comments that will help us to improve the service that we offer.  Please fill in the form below to tell us about:</p> <br/> <ul class="listround">  <li>Errors that you find with the information that we provide</li><li>Technical problems that you experience with the site.</li><li>Your suggestions for future developments</li></ul>  <br/>  <p>Please give us plenty of detail to support your comments.  For journey planning problems tell us the date and time of the journey; the exact start and finish points; the nature of the error, etc.  For technical problems please tell us what Operating System and browser you are using and so forth.</p><p> </p> <br/> <p>All comments are taken forward but we regret that we are unable to offer individual replies.</p><p> </p> <br/> <p><b>NOTE - If you want to know how to do something on this site, try clicking FAQ, or see the overview information on the first page under each part of the site.  Please do not use this form to ask us to search the site</b> </p>'
,'<p style="font-size: 12pt; line-heigt: 1.5;">Rydym yn croesawu sylwadau a fydd yn gymorth i ni wella''r gwasanaeth a gynigiwn. Llenwch y ffurflen isod i ddweud wrthym ynglyn �:</p> <br/> <ul class="listround"><li>Gwallau a welsoch gyda''r wybodaeth a ddarparwn</li><li>Problemau technegol a gawsoch gyda''r safle</li><li>Eich awgrymiadau am ddatblygiadau yn y dyfodol</li></ul> <br/> <p>Rhowch ddigon o fanylion i ni er mwyn cefnogi eich sylwadau. Am broblemau wrth gynllunio siwrneion dywedwch wrthym beth yw dyddiad ac amser y siwrnai; yr union fannau cychwyn a gorffen; natur y gwall ayb. Ar gyfer problemau technegol, dywedwch wrthym ba System Weithredu a phorwr rydych chi''n eu defnyddio ac ati.</p><p> </p> <br/> <p>Mae pob sylw yn cael ystyriaeth ond ni allwn gynnig atebion unigol yn anffodus. </p><p> </p> <br/> <p><b>SYLWER - Os hoffech wybod sut i wneud rhywbeth ar y safle hwn, beth am glicio Cwestiynau a Ofynnir yn Aml (COA), neu ewch i''r tudalennau "Gorolwg" o dan bob rhan o''r safle. Peidiwch � defnyddio''r ffurflen hon i ofyn i ni chwi</b> </p>'


EXEC AddtblContent
1, 1, 'langStrings', 'FeedbackControl.FeedbackConfirmationFail.Text'
,'A problem occured while submitting your feedback, please attempt to submit again.<br/><br/>Thank you'
,'Cafwyd problem wrth gyflwyno eich adborth, rhowch gynnig arall arni.<br/><br/>Diolch'

GO

EXEC AddtblContent
1, 46, 'TDToolbarHeaderHtmlPlaceholderControl', '/Channels/TransportDirect/Tools/ToolbarDownload'
,'<p>Our new toolbar is free and lets you use Transport Direct even more quickly and easily. It appears near the top of your screen (below the browser menu bars) and lets you plan a journey without leaving the web page you are viewing. 
</p>'
,'<p>Mae ein bar offer newydd am ddim ac yn gadael i chi ddefnyddio Transport Direct hyd yn oed yn gyflymach ac yn haws. Mae''n ymddangos ger brig eich sgr�n (islaw bariau dewislen y porwr) ac mae''n gadael i chi gynllunio siwrnai heb adael tudalen y we yr ydych yn edrych arni. 
</p>'

EXEC AddtblContent
1, 46, 'TDToolbarComingUpHtmlPlaceholderControl', '/Channels/TransportDirect/Tools/ToolbarDownload'
,'<p><strong>Installing the toolbar:</strong></p>  <p>Once you have clicked the "Download toolbar now" link:</p><br />  <p>(1) Select "Open" or "Run" when prompted.<br />(2) If you are prompted again, confirm that you want to run the software.<br />(3) Restart your browser once the installation has completed and the toolbar is ready to use.</p><br />  <p>If you experience problems during the installation, it may be because you do not have the necessary administrator rights, which are needed to install new software. In this case, please contact your IT department or vendor in order to install the toolbar.</p><br />  <p><strong>Hiding the toolbar:</strong><br />Once you have installed the toolbar, you can hide it at any time by selecting the following options on the main menu bar in Internet Explorer:<br /><br />(1) select "View"<br />(2) select "Toolbars"<br />(3) untick "Transport Direct" toolbar<br /><strong><br />Uninstalling the toolbar: </strong><br />You can uninstall the toolbar from your PC in the same way as other programmes <br /><br /></p>'
,'<p><strong>Gosod y bar offer:</strong></p>  <p>Ar �l i chi glicio''r cyswllt ''Llawrlwythwch y bar offer yn awr'':</p><br />  <p>(1) Dewiswch ''Agorwch'' neu ''Rhedeg'' pan gewch eich procio.<br />(2) Os rhoddir proc i chi eto, cadarnhewch eich bod yn dymuno rhedeg y meddalwedd.<br />(3) Ail-ddechreuwch eich porwr wedi i''r gosodiad gael ei gwblhau a bod y bar offer yn barod i''w ddefnyddio.</p><br />  <p>Os cewch broblemau yn ystod y gosod, efallai fod hyn oherwydd nad oes gennych yr hawliau gweinyddu angenrheidiol, y mae''n rhaid eu cael i osod meddalwedd newydd. Os felly, cysylltwch �''ch adran TG neu''r gwerthwr i osod y bar offer.</p><br />  <p><strong>Cuddio''r bar offer:</strong><br />Wedi i chi roi''r bar offer ar eich system, gallwch ei guddio unrhyw bryd drwy ddewis y dewisiadau canlynol ar far y prif ddewislen yn Internet Explorer:<br /><br />(1) dewiswch ""Edrychwch ar"<br />(2) dewiswch "Bariau Offer"<br />(3) dad-diciwch bar offer "Transport Direct"<br /><strong><br />Tynnu''r bar offer oddi ar y system: </strong><br />Gallwch dynnu''r bar offer oddi ar eich PC yn yr un modd � rhaglenni eraill <br /><br /></p>'

EXEC AddtblContent
1, 46, 'TDToolbarAvailableNowHtmlPlaceHolderControl', '/Channels/TransportDirect/Tools/ToolbarDownload'
,'<table cellspacing="2" cellpadding="1" border="0">
<tbody>
<tr>
<td>
<p><strong>Available now:</strong></p></td>
<td></td></tr>
<tr>
<td><img alt="Door-to-door" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Journey.gif" border="0"/></td>
<td>
<p><strong>Plan a door-to-door journey</strong></p>
<p>Plan a door-to-door journey between any two postcodes in Britain using any combination of transport.</p></td></tr></tbody></table>'
,'<table cellspacing="2" cellpadding="1" border="0">
<tbody>
<tr>
<td>
<p><strong>Ar gael yn awr:</strong></p></td>
<td></td></tr>
<tr>
<td><img alt="Door-to-door" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/Journey.gif" border="0"/></td>
<td>
<p><strong>Cynlluniwch siwrnai o ddrws i ddrws</strong></p>
<p>Cynlluniwch siwrnai o ddrws i ddrws rhwng unrhyw ddau g�d post ym Mhrydain gan ddefnyddio unrhyw gyfuniad o gludiant.</p></td></tr></tbody></table>'

EXEC AddtblContent
1, 1, 'langStrings', 'ToolbarDownload.labelSystemRequirements.Text'
,'System requirements:<br /> - Microsoft IE version 5.5 or later<br /> - Microsoft Windows 98 or later'
,'Gofynion y system: <br /> - Microsoft IE fersiwn 5.5 neu ddiweddarach<br /> - Microsoft Windows 98 neu ddiweddarach'

EXEC AddtblContent
1, 1, 'langStrings', 'LogViewer.labelInstruction'
,'Enter keywords below to match only on those values specified or leave blank to retrieve all logged events.<br /><br />To view a specific journey''s CJP events, enter the required Journey Reference into the Message box.<br /><br />Click "Submit" when ready to view events. <br /><br /><strong>Note:</strong> A maximum number of events which will be returned irrespective of the filter applied.'
,'Enter keywords below to match only on those values specified or leave blank to retrieve all logged events.<br /><br />To view a specific journey''s CJP events, enter the required Journey Reference into the Message box.<br /><br />Click "Submit" when ready to view events. <br /><br /><strong>Note:</strong> A maximum number of events which will be returned irrespective of the filter applied.'

EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'UserSurvey.LabelMainInstruction'
,'We would greatly appreciate it if you could let us know a bit about your recent journey planning experience so that
	we can improve our website.<br /><br />The questionnaire will take about 5 minutes to fill in.  It has three sections - the first is about the journey
	you just planned, the second is about the website itself and the third has some optional questions about you.<br /><br />
	Be assured that any details you supply will not be passed on to anyone else.'
,'We would greatly appreciate it if you could let us know a bit about your recent journey planning experience so that
		we can improve our website.<br /><br />The questionnaire will take about 5 minutes to fill in.  It has three sections - the first is about the journey
		you just planned, the second is about the website itself and the third has some optional questions about you.<br /><br />
		Be assured that any details you supply will not be passed on to anyone else.'


EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'UserSurvey.ImageSection1Arrow1.AlternateText'
,'Step 1'
,'Step 1'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'UserSurvey.ImageSection1Arrow1Grey.AlternateText'
,'Step 1'
,'Step 1'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'UserSurvey.ImageSection1Arrow2.AlternateText'
,'Step 2'
,'Step 2'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'UserSurvey.ImageSection1Arrow2Grey.AlternateText'
,'Step 2'
,'Step 2'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'UserSurvey.ImageSection1Arrow3.AlternateText'
,'Step 3'
,'Step 3'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'UserSurvey.ImageSection1Arrow3Grey.AlternateText'
,'Step 3'
,'Step 3'

EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'PanelHeaderImages.ImageSection1Arrow1.AlternateText'
,'Step 1'
,'Step 1'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'PanelHeaderImages.ImageSection1Arrow1Grey.AlternateText'
,'Step 1'
,'Step 1'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'PanelHeaderImages.ImageSection1Arrow2.AlternateText'
,'Step 2'
,'Step 2'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'PanelHeaderImages.ImageSection1Arrow2Grey.AlternateText'
,'Step 2'
,'Step 2'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'PanelHeaderImages.ImageSection1Arrow3.AlternateText'
,'Step 3'
,'Step 3'
EXEC AddtblContent
1, 1, 'UserSurveyStrings', 'PanelHeaderImages.ImageSection1Arrow3Grey.AlternateText'
,'Step 3'
,'Step 3'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1240
SET @ScriptDesc = 'Update content to be XHTML Compliance'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO