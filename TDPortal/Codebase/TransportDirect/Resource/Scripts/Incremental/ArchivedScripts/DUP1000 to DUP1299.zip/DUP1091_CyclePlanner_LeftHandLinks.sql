-- ***********************************************
-- NAME 		: DUP1091_CyclePlanner_LeftHandLinks.sql
-- DESCRIPTION 		: Script to add left hand navigation and related links for Cycle planner
-- AUTHOR		: Mitesh Modi
-- DATE			: 30 Jul 2008 18:00:00
-- ************************************************


-- IMPORTANT, this script relies on DUP1081, and DU1082 having been run

USE [TransientPortal]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- BEING TIDY UP
-- If this script is run multiple times, we can end up with multiple Find a Cycle input links on the Homepage / Plan a Journey Homepage. 
-- So delete them first.

-- Tidy up ContextSuggestionLink
DELETE     
FROM    ContextSuggestionLink
WHERE   (SuggestionLinkId IN
                            (SELECT     SuggestionLinkId    -- Get all suggestion links which are for the Plan a journey category
                             FROM          SuggestionLink   -- and use our new FindACycle resource 
                             WHERE      (LinkCategoryId =
                                                        (SELECT     LinkCategoryId
                                                         FROM          LinkCategory
                                                         WHERE      [name] = 'Plan a journey'))
                                                         AND (ResourceNameId =
                                                                              (SELECT     ResourceNameID
                                                                               FROM          ResourceName
                                                                               WHERE      ResourceName = 'FindACycle')))) 
                            AND (ThemeId IN (1, 2, 3, 4, 5, 6))    -- ALL THEMES
                            AND (ContextId IN    -- And only for the Homepage or Plan a journey mini homepage
                                              (SELECT     ContextId
                                                FROM          Context
                                                WHERE      [Name] = 'HomePageMenu' OR
                                                           [Name] = 'HomePageMenuPlanAJourney'))


-- And also need to delete the previously added Suggestion Links for Find a Cycle input. This ensures the correct one is used for the 
-- Homepage context, and the Plan a Journey homepage context

-- Tidy up SuggestionLink
DELETE
FROM          SuggestionLink    -- Get all suggestion links which are for the Plan a journey category
WHERE      (LinkCategoryId =    -- and use our new FindACycle resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Plan a journey')) AND (ResourceNameId =
                                                       (SELECT     ResourceNameID
                                                         FROM          ResourceName
                                                         WHERE      ResourceName = 'FindACycle'))





-- Remove any previously added Related Links that we added for the Cycle planner

DECLARE @ContextId INT

-- Tidy up ContextSuggestionLink
IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')

	DELETE 
	FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END


GO

-- END TIDY UP
--------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------
-- Set up the Cycle Planner input page link
----------------------------------------------------------------

-- This adds the actual link, and assigns it to the Home page
EXEC AddInternalSuggestionLink

	'JourneyPlanning/FindCycleInput.aspx',      -- Relative internal link URL
	'Find a cycle',                             -- Description of internal link. Ensure this is a unique internal link description
	'FindACycle',			                    -- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Find a cycle route',		                -- English display text. Populate only if adding new ResourceName or updating existing display text
	'cy Find a cycle route',		            -- Welsh display text. Populate only if adding new ResourceName or updating existing display text	
	'Plan a journey',				            -- Category Name (LinkCategory) -- Use 'General' if not a left hand navigation link
	130,						                -- Priority must be unique for the selected CategoryName this link is for
	0,						                    -- Set to 0 if to be used as a Suggestion/Related Link
	0,						                    -- Set to 1 if it is a second level Root link
	'HomePageMenu',	                            -- Context Name (Context) -- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',						                    -- Populate only if adding a new ContextName, or updating description
	1						                    -- Theme this link is added for, use 1 as default

GO

-- This adds it to the Plan a journey mini homepage, and all pages which display the Plan a journey's left nav
-- NOTE: we use the same physical Internal link record, but have a new Suggestion Link with a different priority
EXEC AddInternalSuggestionLink

	'JourneyPlanning/FindCycleInput.aspx',      
	'Find a cycle',                             
	'FindACycle',			                    
	'Find a cycle route',		                
	'cy Find a cycle route',		            
	'Plan a journey',				            
	2110,						                
	0,						                    
	0,						                    
	'HomePageMenuPlanAJourney',	                            
	'',						                    
	1						                    

GO






----------------------------------------------------------------
-- Set up the Related Links for Cycle Planner input page
----------------------------------------------------------------

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextFindCycleInput'
SET @ThemeId = 1


-- Add our new context for cycle input page related links
EXEC AddContext
    
    @ContextName,                            						-- Context
    'Related Link Context - Suggestions for Find Cycle Input Page'  -- Context description


-- Script DUPxxx_CyclePlanner_LeftHandLinks_2.sql adds the actual Related links as it relies on DUPxxx having been run


Go



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1091
SET @ScriptDesc = 'Left hand navigation for cycle planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO