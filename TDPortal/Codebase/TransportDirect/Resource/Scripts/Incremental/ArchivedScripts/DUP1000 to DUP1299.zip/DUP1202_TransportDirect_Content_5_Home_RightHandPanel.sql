-- ***********************************************
-- NAME 		: DUP1202_TransportDirect_Content_5_Home_RightHandPanel.sql
-- DESCRIPTION 	: Script to add the Right Hand Information panel text
-- AUTHOR		: John Frank
-- DATE			: 02 Dec 2008
-- ************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Content]
GO


DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')


-- Right hand items 1 and 2
EXEC AddtblContent
1, @GroupId, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<div class="Column3Header">  
<div class="txtsevenbbl">Christmas shopping?</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  
<div class="Column3Content">  
<table id="Table1" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top" align="center" width="26"><img title="" alt="Car Park Image" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_carpark.gif" border="0" /></td>  
<td class="txtseven">Locate <a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Park and ride</a> schemes near your shopping destination or <a href="/Web2/JourneyPlanning/FindCarParkInput.aspx">find a car park</a> to make things a little easier.</td></tr></tbody></table></div>  
<div class="Column3Header">  
<div class="txtsevenbbl">Travel at your fingertips</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Mobile Phone" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent\MobileSmallIcon.gif" border="0" /></td>  
<td class="txtseven">Did you know that you can send your favourite journeys to you mobile? With a click on your mobile you can get live rail departures, bus schedules and travel news for car and public transport while you''re on the move. Visit our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">mobile page</a></td></tr></tbody></table></div>'
, 
'<div class="Column3Header">  
<div class="txtsevenbbl">Christmas shopping?</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>  
<div class="Column3Content">  
<table id="Table1" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top" align="center" width="26"><img title="" alt="Car Park Image" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_carpark.gif" border="0" /></td>  
<td class="txtseven">Locate <a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Park and ride</a> schemes near your shopping destination or <a href="/Web2/JourneyPlanning/FindCarParkInput.aspx">find a car park</a> to make things a little easier.</td></tr></tbody></table></div>  
<div class="Column3Header">  
<div class="txtsevenbbl">Travel at your fingertips</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Mobile Phone" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent\MobileSmallIcon.gif" border="0" /></td>  
<td class="txtseven">Did you know that you can send your favourite journeys to you mobile? With a click on your mobile you can get live rail departures, bus schedules and travel news for car and public transport while you''re on the move. Visit our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">mobile page</a></td></tr></tbody></table></div>'


-- Right hand item 3
EXEC AddtblContent
1, @GroupId, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home',
'<div class="Column3Header">
<div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br /><br />Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink.xls">Excel link generator (opens new window)</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page (opens new window)</a> for more details.</td></tr></tbody></table></div>'
,
'<div class="Column3Header">
<div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">Does your website have a ''How to get here'' page?  You can now create links that open Transport Direct with your destination pre-set. For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br /><br />Download this <a target="_child" href="http://www.dft.gov.uk/172974/256753/intelligentlink.xls">Excel link generator (opens new window)</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page (opens new window)</a> for more details.</td></tr></tbody></table></div>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1202
SET @ScriptDesc = 'Script to add Homepage Right hand information text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO