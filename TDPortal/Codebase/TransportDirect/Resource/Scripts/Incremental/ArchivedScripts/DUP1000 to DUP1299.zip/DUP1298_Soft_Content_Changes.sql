-- ***********************************************
-- NAME 		: DUP1298_Soft_Content_Changes.sql
-- DESCRIPTION 		: Update soft content 
-- AUTHOR		: Tej Sohal
-- DATE			: 18 February 2009
-- ************************************************

USE [Content]
GO

-- Soft Content on FindTrainCostInput.aspx   --waiting for welsh translation-- 
EXEC AddtblContent
1, 51, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrainCostInput',
'<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Fare Details (select a discount card and choose to show either adult or child fares)</li></ul><br/></div></div>',
'<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>cy-Click the Advanced Options button above to amend some of the following options for your journey. Options include:</p><br/><ul><li>Fare Details (select a discount card and choose to show either adult or child fares)</li></ul><br/></div></div>'

GO

-- Soft Content on PrintableJourneyDetails.aspx
EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.labelTram.Print',
'Tram/Light Rail',
'Tram/ Rheilffordd Ysgafn'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1298
SET @ScriptDesc = 'Update soft content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO