-- ***********************************************
-- NAME 		: DUP1292_Amend_Bank_Holiday_Text.sql
-- DESCRIPTION 		: Amendments to English Bank Holiday Text
-- AUTHOR		: Rich Broddle
-- DATE			: 17 February 2009
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlanner.MessageHolidayInEnglandWales'
,'Note: This is a bank holiday in England and Wales.'
,'Nodyn: Mae hon yn wyl y banc yng Nghymru a Lloegr.'

GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlanner.hyperlinkBankHolidayInfo'
,'Click here for information about changes to public transport services.'
,'Cliciwch yma am wybodaeth am newidiadau i wasanaethau cludiant cyhoeddus.'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1292
SET @ScriptDesc = 'Amendments to English Bank Holiday Text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO