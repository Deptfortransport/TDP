-- ***********************************************
-- NAME 		: DUP1289_Soft_Content_Changes.sql
-- DESCRIPTION 		: Update content for Search Engine Optimisation
-- AUTHOR		: Tej Sohal
-- DATE			: 10 February 2009
-- ************************************************

USE [Content]
GO

-- Soft Content change for 4.1 T&C 'Link To Our Website'
EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.TermsConditions.Text',
'<table class="businesslinktermsdivtable" cellspacing="0" summary="Business Link Conditions">
<tr>
	<td width="30px">&nbsp;</td>
	<td width="45px">&nbsp;</td>
	<td>&nbsp;</td>
</tr>
<tr>
	<td class="businesslinkboldcenter" colspan="3">LINKING
		YOUR WEBSITE TO TRANSPORT DIRECT</td></tr>
<tr>
	<td class="businesslinkpadtop" colspan="3">These terms
		and conditions ("Terms and Conditions") set out the basis upon which you
		("you") are authorised by the Secretary of State for Transport ("we",
		"us", "our") to include a hypertext link ("link") from your company or
		organisation''s website ("your site") to the Transport Direct website at www.transportdirect.info ("our site"). </td></tr>
<tr>
	<td class="businesslinkpadtop" colspan="3">Use of our
		site in this way is also subject to our site <a href="../About/TermsConditions.aspx" target="_blank">
			terms and conditions</a> and by
		accepting these Terms and Conditions you agree to abide by our site terms
		and conditions.</td></tr>
<tr>
	<td class="businesslinkpadtop" colspan="3">You are not
		permitted to include a link from your site to our site unless you have
		agreed to and accepted these Terms and Conditions.</td></tr>
<tr>
	<td class="businesslinktablebold">1</td>
	<td colspan="2" class="businesslinktablebold">Ownership of Transport Direct</td></tr>
<tr class="businesslinktable">
	<td>1.1</td>
	<td colspan="2">The Secretary of State for Transport
		either owns or is licensed to use the intellectual property rights in the
		data and software ("data", "software") used in our site. </td></tr>
<tr class="businesslinktable">
	<td>1.2</td>
	<td colspan="2">The data remains our property, or our
		suppliers'' property, as the case may be.</td></tr>
<tr>
	<td class="businesslinktablebold">2</td>
	<td class="businesslinktablebold" colspan="2">Licence to
		link to Transport Direct</td></tr>
<tr class="businesslinktable">
	<td>2.1</td>
	<td colspan="2">Provided you accept these terms and
		conditions in full, we grant you a non-exclusive, revocable,
		non-transferable licence to link to our site. </td></tr>
<tr>
	<td class="businesslinktablebold">3</td>
	<td class="businesslinktablebold" colspan="2">Your
		obligations </td></tr>
<tr class="businesslinktable">
	<td>3.1</td>
	<td colspan="2">You shall ensure that: </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.1</td>
	<td>your site complies with all applicable law,
		regulations and legislation;</td></tr>
<tr class="businesslinktable">
	<td></td>
	<td class="businesslinktable">3.1.2</td>
	<td>your site maintains the highest standards of good
		taste and decency, does not offer products or services that encourage
		lawlessness or infringe public health or safety and does not disparage or
		bring into disrepute the concepts of public transport and environmental
		best practice; </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.3</td>
	<td>you do not charge anyone who makes use of the
		link to our site; </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.4</td>
	<td>users of your site use the link and our site for
		non-commercial purposes only; </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.5</td>
	<td>you protect and do not interfere with the
		Secretary of State''s rights in respect of Transport Direct''s trade names,
		trade marks and logos and do not distribute or re-use those names, marks
		and logos without prior permission; </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.6</td>
	<td>you do not infringe the intellectual property
		rights of any other person;</td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.7</td>
	<td>you do not pass to anyone your rights or
		obligations under these Terms and Conditions; </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.8</td>
	<td>you represent fairly and lawfully the data, the
		software and Transport Direct''s good name;</td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.9</td>
	<td>you do not do anything or include anything on
		your site that implies any endorsement, sponsorship or approval of your
		site by us, and you acknowledge that the inclusion of the link on your
		site does not in any way represent any such endorsement, sponsorship or
		approval of your site by us; and </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>3.1.10</td>
	<td>your site is not defamatory of any person,
		business or undertaking. </td></tr>
<tr class="businesslinktable">
	<td>3.2</td>
	<td colspan="2">You accept that we may keep records of
		your links and hold such records for periodic inspection and tracking
		purposes.</td></tr>
<tr>
	<td class="businesslinktablebold">4</td>
	<td class="businesslinktablebold" colspan="2">Your rights
	</td></tr>
<tr class="businesslinktable">
	<td>4.1</td>
	<td colspan="2">You may remove the link from your site
		at any time.</td></tr>
<tr>
	<td class="businesslinktablebold">5</td>
	<td class="businesslinktablebold" colspan="2">Our
		rights</td></tr>
<tr class="businesslinktable">
	<td>5.1</td>
	<td colspan="2">We reserve the right to terminate or
		modify your right to include the link on your site at any time by notice
		in writing to you at the email address that you have provided us with. We
		may disable/terminate your link to our site if: </td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>5.1.1</td>
	<td>you breach any part of these terms and
		conditions; or</td></tr>
<tr class="businesslinktable">
	<td></td>
	<td>5.1.2</td>
	<td>any legislation, order or regulation, or any
		other matter prevents us from granting or continuing your licence.</td></tr>
<tr class="businesslinktable">
	<td>5.2</td>
	<td colspan="2">We reserve the right to revise these
		Terms and Conditions at any time. We will post updated Terms and
		Conditions on our site. It is your responsibility to review these Terms
		and Conditions regularly so that you are aware of any revisions. If you
		continue to include a link on your site after a change to these Terms and
		Conditions has been made, you will be deemed to accept the revised Terms
		and Conditions. If you do not accept any revised Terms and Conditions,
		please remove the link from your site.</td></tr>
<tr class="businesslinktable">
	<td>5.3</td>
	<td colspan="2">If we disable your link to our site for
		any reason, you will have no claim against us and you will remove from
		your website all references and links to our site. </td></tr>
<tr>
	<td class="businesslinktablebold">6</td>
	<td class="businesslinktablebold" colspan="2">Responsibilities</td></tr>
<tr class="businesslinktable">
	<td>6.1</td>
	<td colspan="2">We make no promise or any other
		statement or representation regarding the accuracy, fitness for purpose,
		performance, satisfactory quality, or use of our site and exclude to the
		fullest extent permissible by law all warranties, obligations, conditions
		or terms which may be implied by common law, statute or otherwise in
		relation to the link or our site. Accordingly, it is your responsibility
		to ensure that the Transport Direct Portal is fit for your intended use.
	</td></tr>
<tr class="businesslinktable">
	<td>6.2</td>
	<td colspan="2">In no event shall we be liable to you
		for any losses (whether direct, indirect, special or consequential)
		suffered by you as a result of including a link on your site. </td></tr>
<tr class="businesslinktable">
	<td>6.3</td>
	<td colspan="2">We have no responsibility for any
		technical problem or failure of any kind relating to the installation of
		your link to our site.</td></tr></table>',


'<table width="98%" align="center">
<tr>
  <td colspan="3" class="businesslinkboldcenter">CYSYLLTU EICH GWEFAN - TRANSPORT DIRECT</td></tr>
<tr>
  <td colspan="3" class="businesslinkpadtop">Mae''r amodau a''r telerau hyn (''Amodau a Thelerau'') yn cyflwyno''r sail yr awdurdodir chi (''chi'') arni gan yr Ysgrifennydd Gwladol dros Gludiant (''ni'', ''ein'') i gynnwys dolen hyper-destun (''dolen'') o wefan eich cwmni neu sefydliad (''eich safle'') i wefan Transport Direct yn www.transportdirect.info (''ein safle''). </td></tr>
<tr>
  <td colspan="3" class="businesslinkpadtop">Mae defnyddio''r safle fel hyn yn ddarostyngedig hefyd i amodau a thelerau ein safle <a 
    href="http://www.transportdirect.info/Web2/About/TermsConditions.aspx" 
    target="_blank">rhowch ddolen i amodau a thelerau porth td</a> a thrwy dderbyn yr Amodau a''r Telerau hyn rydych yn cytuno i gadw at delerau ac amodau ein safle.</td></tr>
<tr>
  <td colspan="3" class="businesslinkpadtop">Ni chaniateir i chi gynnwys dolen o''ch safle i''n safle ni oni bai eich bod wedi cytuno i ac wedi derbyn yr Amodau a''r Telerau hyn. </td></tr>
<tr>
  <td class="businesslinktablebold">1</td>
  <td colspan="2" class="businesslinktablebold">Perchnogaeth Transport Direct </td></tr>
<tr class="businesslinktable">
  <td>1.1</td>
  <td colspan="2">Mae''r Ysgrifennydd Gwladol dros Gludiant naill ai yn berchen ar neu wedi ei drwyddedu i ddefnyddio hawliau eiddo deallusol yn y data a''r meddalwedd (''data'', ''meddalwedd'') a ddefnyddir yn ein safle. </td></tr>
<tr class="businesslinktable">
  <td>1.2</td>
  <td colspan="2">Mae''r data yn parhau i fod yn eiddo i ni, neu yn eiddo i''n cyflenwyr, fel y bo''r sefyllfa.</td></tr>
<tr>
  <td class="businesslinktablebold">2</td>
  <td colspan="2" class="businesslinktablebold">Trwydded i gysylltu � Transport Direct</td></tr>
<tr class="businesslinktable">
  <td>2.1</td>
  <td colspan="2">Cyn belled ag y b�ch yn derbyn yr amodau a''r telerau hyn yn llawn, rydym yn rhoi trwydded heb fod yn unigryw, y gellir ei diddymu, na ellir ei throsglwyddo i gysylltu �''n safle. </td></tr>
<tr>
  <td class="businesslinktablebold">3</td>
  <td colspan="2" class="businesslinktablebold">Eich Cyfrifoldebau </td></tr>
<tr class="businesslinktable">
  <td>3.1</td>
  <td colspan="2">Byddwch yn sicrhau: </td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.1</td>
  <td>bod eich safle yn cydymffurfio �''r holl ddeddfau, rheoliadau a deddfwriaeth gymwys;</td></tr>
<tr class="businesslinktable">
  <td></td>
  <td class="businesslinktable">3.1.2</td>
  <td>bod eich safle yn cynnal y safonau uchaf o ran chwaeth a gwedduster, nad yw''n cynnig cynhyrchion na gwasanaethau sy''n annog torri''r gyfraith nac yn tarfu ar iechyd neu ddiogelwch cyhoeddus ac nad yw''n amharchu nac yn dod ag enw drwg i gysyniadau cludiant cyhoeddus ac arfer gorau amgylcheddol; </td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.3</td>
  <td>nad ydych yn codi t�l ar unrhyw un sy''n gwneud defnydd o''r ddolen i''n safle; 
  </td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.4</td>
  <td>bod defnyddwyr eich safle yn defnyddio''r ddolen a''n safle i bwrpasau anfasnachol yn unig; </td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.5</td>
  <td>eich bod yn gwarchod ac nad ydych yn ymyrryd ar hawliau''r Ysgrifennydd Gwladol mewn perthynas ag enwau masnach, nodau masnach a logos Transport Direct ac nad ydych yn dosbarthu nac yn ail-ddefnyddio''r enwau, marciau a''r logos hynny heb ganiat�d ymlaen llaw; </td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.6</td>
  <td>nad ydych yn torri hawliau eiddo deallusol unrhyw unigolyn arall;</td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.7</td>
  <td>nad ydych yn trosglwyddo eich hawliau na''ch cyfrifoldebau i unrhyw un o dan y Telerau a''r Amodau hyn; </td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.8</td>
  <td>eich bod yn cynrychioli''r data, y meddalwedd ac enw da Transport Direct yn deg ac yn gyfreithiol;</td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.9</td>
  <td>nad ydych yn gwneud unrhyw beth nac yn cynnwys unrhyw beth ar eich safle sy''n awgrymu ein bod ni yn cefnogi, yn noddi nac yn cymeradwyo eich safle, a''ch bod yn cydnabod nad yw cynnwys y ddolen ar eich safle yn nodi cefnogaeth, nawdd na chymeradwyaeth o''ch safle gennym ni mewn unrhyw fodd; ac </td></tr>
<tr class="businesslinktable">
  <td></td>
  <td>3.1.10</td>
  <td>nad yw eich safle yn ddifr�ol o unrhyw unigolyn, busnes nac ymgymeriad. </td></tr>
<tr class="businesslinktable">
  <td>3.2</td>
  <td colspan="2">Rydych yn derbyn y gallwn gadw cofnodion o''ch dolennau a chadw cofnodion o''r fath ar gyfer archwiliad bob yn hyn a hyn ac i bwrpas olrhain.</td></tr>
<tr>
  <td class="businesslinktablebold">4</td>
  <td colspan="2" class="businesslinktablebold">Eich hawliau </td></tr>
<tr class="businesslinktable">
  <td>4.1</td>
  <td colspan="2">Gallwch ddileu''r ddolen o''ch safle unrhyw bryd.</td></tr>
<tr>
  <td class="businesslinktablebold">5</td>
  <td colspan="2" class="businesslinktablebold">Ein hawliau</td></tr>
<tr>
  <td>5.1</td>
  <td colspan="2">Rydym yn cadw''r hawl i ddirwyn i ben neu i ddiwygio eich hawl i gynnwys y ddolen ar eich safle unrhyw bryd drwy roi hysbysiad yn ysgrifenedig i chi yn y cyfeiriad ebost yr ydych wedi ei roi i ni.  Gallwn ddirymu/terfynu eich dolen i''n safle os: </td></tr>
<tr class="businesslinktable">
  <td>5.1.1</td>
  <td colspan="2">torrwch unrhyw ran o''r amodau a''r telerau hyn; neu 
  or</td></tr>
<tr class="businesslinktable">
  <td>5.1.2</td>
  <td colspan="2">unrhyw ddeddfwriaeth, gorchymyn neu reoliad, neu fod unrhyw fater arall yn ein hatal rhag rhoi neu barhau �''ch trwydded.</td></tr>
<tr class="businesslinktable">
  <td>5.2</td>
  <td colspan="2">Rydym yn cadw''r hawl i ddiwygio''r Amodau a''r Telerau hyn unrhyw bryd.  Byddwn yn postio Amodau a Thelerau wedi eu diweddaru ar ein safle.  Eich cyfrifoldeb chi yw adolygu''r Amodau a''r Telerau hyn yn rheolaidd fel eich bod yn ymwybodol o unrhyw ddiwygiadau.  Os parhewch i gynnwys dolen ar eich safle ar �l i newid i''r Amodau a''r Telerau hyn gael ei wneud, tybir eich bod wedi derbyn yr Amodau a''r Telerau diwygiedig.  Os nad ydych yn derbyn unrhyw Amodau a Thelerau diwygiedig, a fyddech gystal � dileu''r ddolen o''ch safle.</td></tr>
<tr class="businesslinktable">
  <td>5.3</td>
  <td colspan="2">Os ydym yn dirymu eich dolen i''n safle am unrhyw reswm, ni fydd gennych unrhyw hawliad yn ein herbyn a byddwch yn dileu o''ch gwefan bob cyfeiriad a dolen i''n safle. </td></tr>
<tr>
  <td class="businesslinktablebold">6</td>
  <td colspan="2" class="businesslinktablebold">Cyfrifoldebau</td></tr>
<tr class="businesslinktable">
  <td>6.1</td>
  <td colspan="2">Nid ydym yn gwneud unrhyw addewid nac unrhyw ddatganiad na sylw arall ynglyn � chywirdeb, ffitrwydd ar gyfer pwrpas, perfformiad, ansawdd boddhaol, na defnydd ein safle ac yr ydym yn allgau i''r graddau llawnaf y gellir eu caniat�u gan y ddeddf bob gwarant, rhwymedigaeth, amod neu delerau y gellir eu hawgrymu trwy ddeddf gyffredin, statud neu fel arall mewn perthynas �''r ddolen neu ein safle.  Felly eich cyfrifoldeb chi yw sicrhau bod Porth Transport Direct yn addas ar gyfer y defnydd a fwriedir. </td></tr>
<tr class="businesslinktable">
  <td>6.2</td>
  <td colspan="2">Ni fyddwn mewn unrhyw fodd yn gyfrifol i chi am unrhyw golledion (uniongyrchol, anuniongyrchol, arbennig neu ganlyniadol) a ddioddefir gennych chi o ganlyniad i gynnwys dolen ar eich safle. </td></tr>
<tr class="businesslinktable">
  <td>6.3</td>
  <td colspan="2">Nid ydym yn gyfrifol mewn unrhyw fodd am unrhyw broblem dechnegol neu fethiant o unrhyw fath sy''n ymwneud � gosod eich dolen chi ar ein safle.</td></tr></table>'

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1289
SET @ScriptDesc = 'Update Soft Content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO