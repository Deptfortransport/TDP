-- ***********************************************
-- NAME 		: DUP1203_CyclePlanner_DataSets_4.sql
-- DESCRIPTION 		: Script to add Data sets for cycle planner
--			: This is a copy of DUP1198, but updated to reflect actual Journey Type values (instead of all being "Fastest")
-- AUTHOR		: Mitesh Modi
-- DATE			: 04 Dec 2008
-- ************************************************


USE [PermanentPortal]
GO

-- The following new datasets are added for cycle planner
--     FindCycleLocationDrop
--     CycleViaLocationDrop
--     CycleJourneyType
--	   UnitsSpeedDrop
-- This is done by specifying the dataset names, adding the values for the datasets, 
-- and defining the storedprocedure properties to retrieve the datasets

-- Specify dataset names
IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'FindCycleLocationDrop')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('FindCycleLocationDrop', 0)     
   
    END

IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'CycleViaLocationDrop')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('CycleViaLocationDrop', 0)     
   
    END

IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'CycleJourneyType')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('CycleJourneyType', 0)     
   
    END

IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'UnitsSpeedDrop')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('UnitsSpeedDrop', 0)     
   
    END


-- Add the dataset values
IF NOT EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'FindCycleLocationDrop')
    BEGIN

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('FindCycleLocationDrop', 'Address', 'AddressPostCode', 1, 1, 0, 1)

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('FindCycleLocationDrop', 'Attraction', 'POI', 0, 2, 0, 1)

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('FindCycleLocationDrop', 'Stations', 'MainStationAirport', 0, 3, 0, 1)
    END

IF NOT EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'CycleViaLocationDrop')
    BEGIN

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleViaLocationDrop', 'Address', 'AddressPostCode', 1, 1, 0, 1)

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleViaLocationDrop', 'Attraction', 'POI', 0, 2, 0, 1)

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleViaLocationDrop', 'Stations', 'MainStationAirport', 0, 3, 0, 1)
    END


-- Tidy up
IF EXISTS (SELECT * FROM DropDownLists WHERE DataSet = 'CycleJourneyType')
	BEGIN 
		DELETE DropDownLists
		WHERE DataSet = 'CycleJourneyType'
	END

IF NOT EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'CycleJourneyType')
    BEGIN


        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleJourneyType', 'Quickest', 'Quickest', 1, 1, 0, 1)        

	INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleJourneyType', 'Quietest', 'Quietest', 0, 2, 0, 1)

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleJourneyType', 'Recreational', 'Greenest', 0, 3, 0, 1)

	END

IF NOT EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'UnitsSpeedDrop')
    BEGIN

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('UnitsSpeedDrop', 'kph', '2', 0, 2, 0, 1)

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('UnitsSpeedDrop', 'mph', '1', 1, 1, 0, 1)

    END


-- Define the Properties to get the dataset values
IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FindCycleLocationDrop%')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FindCycleLocationDrop.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FindCycleLocationDrop.query', 
            'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''FindCycleLocationDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FindCycleLocationDrop.type', '3', 'DataServices', 'UserPortal', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.CycleViaLocationDrop%')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.CycleViaLocationDrop.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.CycleViaLocationDrop.query', 
            'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''CycleViaLocationDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.CycleViaLocationDrop.type', '3', 'DataServices', 'UserPortal', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.CycleJourneyType%')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.CycleJourneyType.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.CycleJourneyType.query', 
            'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''CycleJourneyType'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.CycleJourneyType.type', '3', 'DataServices', 'UserPortal', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.UnitsSpeedDrop%')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.UnitsSpeedDrop.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.UnitsSpeedDrop.query', 
            'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''UnitsSpeedDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.UnitsSpeedDrop.type', '3', 'DataServices', 'UserPortal', 0, 1)

    END


---------------------------------------------------------------------
-- Feedback 
-- Add the Find a Cycle journey to the journey drop down
IF EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'UserFeedbackSearchType')
    BEGIN

	IF NOT EXISTS (SELECT * FROM DropDownLists WHERE DataSet = 'UserFeedbackSearchType' AND ResourceID = 'Find a cycle journey' )
		BEGIN
	        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
    	    VALUES ('UserFeedbackSearchType', 'Find a cycle journey', '50', 0, 10, 0, 1)
		END

    END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1203
SET @ScriptDesc = 'Datasets for cycle planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO