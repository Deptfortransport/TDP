-- ***********************************************
-- NAME 		: DUP1140_CyclePlanner_LeftHandLinks_2.sql
-- DESCRIPTION 		: Script number 2 to add left hand navigation and related links for Cycle planner
-- AUTHOR		: Mitesh Modi
-- DATE			: 13 Oct 2008
-- ************************************************


-- IMPORTANT, this script relies on DUP1081, DU1082, DUP1091, and DUPxxx having been run

-- NOTE, some of the prework for Cycle Planner related links was completed in DUP1091_CyclePlanner_LeftHandLinks.sql
-- This script finishes adding the related links as it required DUPxxx to be run, which was written
-- after DUP1091.

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- BEING TIDY UP

-- Remove any previously added Related Links that we added for the Cycle planner

DECLARE @ContextId INT

-- Tidy up ContextSuggestionLink
IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')

	DELETE 
	FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END

GO

-- END TIDY UP
--------------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------------------
-- Set up the Related Links for Cycle Planner input page
----------------------------------------------------------------

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextFindCycleInput'
SET @ThemeId = 1

-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme



-- Add the actual links
EXEC AddExternalSuggestionLink

	'CyclePlanner.GPXDownload',					-- ID for ExternalLink table
	'http://www.topografix.com/gpx.asp',      	-- Full external link URL
	'http://www.topografix.com/gpx.asp', 		-- Full test external link URL
	'Cycle planner - GPX download url',         -- Description of external link. Ensure this is a unique external link description
	'CyclePlanner.GPXDownload',                 -- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Find out about GPX downloads (opens new window)',		        -- English display text. Populate only if adding new ResourceName or updating existing display text
	'cy Find out about GPX downloads (yn agor ffenestr newydd)',    -- Welsh display text. Populate only if adding new ResourceName or updating existing display text	
	'Related links',				            -- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
	1660,						                -- Priority must be unique for the selected CategoryName this link is for
	0,						                    -- Set to 0 if to be used as a Suggestion/Related Link
	0,						                    -- Set to 1 if it is a second level Root link
	@ContextName,	                            -- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',						                    -- Populate only if adding a new ContextName, or updating description
	@ThemeId						            -- Theme this link is added for, use 1 as default


EXEC AddExternalSuggestionLink

	'CyclePlanner.Parking',					
	'http://www.dft.gov.uk/pgr/roads/tpm/tal/cyclefacilities/keyelementsofcycleparkingpro4085',      	
	'http://www.dft.gov.uk/pgr/roads/tpm/tal/cyclefacilities/keyelementsofcycleparkingpro4085', 		
	'Cycle planner - Cycle parking url',         
	'CyclePlanner.Parking',                 
	'Find out about cycle parking (opens new window)',		        
	'cy Find out about cycle parking (yn agor ffenestr newydd)',    
	'Related links',				            
	1670,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            


EXEC AddExternalSuggestionLink

	'CyclePlanner.CyclingScotland',					
	'http://www.cyclingscotland.org/',      	
	'http://www.cyclingscotland.org/', 		
	'Cycle planner - Cycling Scotland url',         
	'CyclePlanner.CyclingScotland',                 
	'Find out about cycling in Scotland (opens new window)',		        
	'cy Find out about cycling in Scotland (yn agor ffenestr newydd)',    
	'Related links',				            
	1680,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            


EXEC AddExternalSuggestionLink

	'CyclePlanner.CyclingEngland',					
	'http://www.cyclingengland.co.uk/',      	
	'http://www.cyclingengland.co.uk/', 		
	'Cycle planner - Cycling England url',         
	'CyclePlanner.CyclingEngland',                 
	'Find out about cycling in England (opens new window)',		        
	'cy Find out about cycling in England (yn agor ffenestr newydd)',    
	'Related links',				            
	1690,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            


EXEC AddExternalSuggestionLink

	'CyclePlanner.CyclingWales',					
	'http://www.cycling.visitwales.com/',      	
	'http://www.cycling.visitwales.com/', 		
	'Cycle planner - Cycling Wales url',         
	'CyclePlanner.CyclingWales',                 
	'Find out about cycling in Wales (opens new window)',		        
	'cy Find out about cycling in Wales (yn agor ffenestr newydd)',    
	'Related links',				            
	1700,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            


EXEC AddExternalSuggestionLink

	'CyclePlanner.NationalCycleRoutes',					
	'http://www.sustrans.org.uk/',      	
	'http://www.sustrans.org.uk/', 		
	'Cycle planner - National Cycle Routes url',         
	'CyclePlanner.NationalCycleRoutes',                 
	'Find out about National cycle routes (opens new window)',		        
	'cy Find out about National cycle routes (yn agor ffenestr newydd)',    
	'Related links',				            
	1710,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            


EXEC AddExternalSuggestionLink

	'CyclePlanner.CycleScheme',					
	'http://www.cyclescheme.co.uk/',      	
	'http://www.cyclescheme.co.uk/', 		
	'Cycle planner - Cycle schemes url',         
	'CyclePlanner.CycleScheme',                 
	'Find out about Bike to work schemes (opens new window)',		        
	'cy Find out about Bike to work schemes (yn agor ffenestr newydd)',    
	'Related links',				            
	1720,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            


EXEC AddExternalSuggestionLink

	'CyclePlanner.CycleSafety',					
	'http://www.dft.gov.uk/think/focusareas/children/?whoareyou_id=&page=Overview',      	
	'http://www.dft.gov.uk/think/focusareas/children/?whoareyou_id=&page=Overview', 		
	'Cycle planner - Cycle safety url',         
	'CyclePlanner.CycleSafety',                 
	'Find out about cycle safety (opens new window)',		        
	'cy Find out about cycle safety (yn agor ffenestr newydd)',    
	'Related links',				            
	1730,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            


EXEC AddExternalSuggestionLink

	'CyclePlanner.CycleSchool',					
	'http://www.bikeforall.net/content/cycling_to_school.php',      	
	'http://www.bikeforall.net/content/cycling_to_school.php', 		
	'Cycle planner - Cycle to school url',         
	'CyclePlanner.CycleSchool',                 
	'Find out about cycling to school (opens new window)',		        
	'cy Find out about cycling to school (yn agor ffenestr newydd)',    
	'Related links',				            
	1740,						                
	0,						                    
	0,						                    
	@ContextName,	                            
	'',						                    
	@ThemeId						            

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1140
SET @ScriptDesc = 'Left hand related links for cycle planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO