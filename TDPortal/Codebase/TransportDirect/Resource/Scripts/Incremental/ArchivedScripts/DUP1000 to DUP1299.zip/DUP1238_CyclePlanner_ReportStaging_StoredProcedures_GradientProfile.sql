-- ***********************************************
-- NAME 		: DUP1238_CyclePlanner_ReportStaging_StoredProcedures_GradientProfile.sql
-- DESCRIPTION 		: Script to add stored procedures to create GradientProfileEvents
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Jan 2009
-- ************************************************

USE [ReportStagingDB]
GO


-- ****IMPORTANT****
-- If running this script in the Production environment, please uncomment the lines with value "ReportServer.", and comment out the line below it.
-- There are 3 instances of this in the script.

----------------------------------------------------------------
-- Create AddGradientProfileEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddGradientProfileEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddGradientProfileEvent 
        (@DisplayCategory varchar(50),
		 @Submitted datetime, 
         @SessionId varchar(50), 
         @UserLoggedOn bit, 
         @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update AddGradientProfileEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE AddGradientProfileEvent (@DisplayCategory varchar(50), @Submitted datetime, @SessionId varchar(50), @UserLoggedOn bit, @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into GradientProfileEvent Table'

    Insert into GradientProfileEvent (DisplayCategory, Submitted, SessionId, UserLoggedOn, TimeLogged)
    Values (@DisplayCategory, @Submitted, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Create TransferGradientProfileEvents stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferGradientProfileEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE dbo.TransferGradientProfileEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferGradientProfileEvents stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE dbo.TransferGradientProfileEvents
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

--DELETE FROM ReportServer.Reporting.dbo.GradientProfileEvents
DELETE FROM Reporting.dbo.GradientProfileEvents
WHERE CONVERT(varchar(10), GPEDate, 121) = @Date

--INSERT INTO ReportServer.Reporting.dbo.GradientProfileEvents
INSERT INTO Reporting.dbo.GradientProfileEvents
(
	GPEDate,
	GPEHour,
	GPEHourQuarter,
	GPEWeekDay,
    GPEGPDTID,
	GPELoggedOn,
	GPECount,
	GPEAvMsDuration
)
SELECT 
	CAST(CONVERT(varchar(10), GPE.Submitted, 121) AS datetime) AS GPEDate,
	DATEPART(hour, GPE.Submitted) AS GPEHour,
	CAST(DATEPART(minute, GPE.Submitted) / 15 AS smallint) AS GPEHourQuarter,
	DATEPART(weekday, GPE.Submitted) AS GPEWeekDay,
	GPDT.GPDTID AS GPEGPDTID,
	GPE.UserLoggedOn AS GPELoggedOn,
	AVG(CAST(DATEDIFF(millisecond, GPE.Submitted, GPE.TimeLogged) AS decimal(18, 0))) AS GPEAvMsDuration,
	COUNT(*) AS GPECount

  FROM GradientProfileEvent GPE
--  LEFT OUTER JOIN ReportServer.Reporting.dbo.GradientProfileDisplayType GPDT ON GPE.DisplayCategory = GPDT.GPDTCode
  LEFT OUTER JOIN Reporting.dbo.GradientProfileDisplayType GPDT ON GPE.DisplayCategory = GPDT.GPDTCode

  WHERE CONVERT(varchar(10), GPE.Submitted, 121) = @Date
  GROUP BY
	CAST(CONVERT(varchar(10), GPE.Submitted, 121) AS datetime),
	DATEPART(hour, GPE.Submitted),
	CAST(DATEPART(minute, GPE.Submitted) / 15 AS smallint),
	DATEPART(weekday, GPE.Submitted),
	GPDT.GPDTID,
	GPE.UserLoggedOn

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1238
SET @ScriptDesc = 'Add ReportStaging stored procedures for GradientProfileEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO