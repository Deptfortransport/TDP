-- *************************************************************************************
-- NAME 		: DUP1012_ZonalAccessibilityLinks_TableCreate.sql
-- DESCRIPTION  	: Creation of Zonal Accessibility Links table
-- AUTHOR		: Sanjeev Johal
-- *************************************************************************************


USE [TransientPortal]
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ZonalAccessibilityLinks') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ZonalAccessibilityLinks] 
END
GO

-------------------------------------------------------------
-- Create Table Columns
-------------------------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ZonalAccessibilityLinks') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ZonalAccessibilityLinks (
		[ExternalLinkId] [varchar] (500) NULL,
		[Naptan] [varchar] (12) NULL,
		[RegionId] [varchar] (20) NULL,
		[ModeId] [varchar] (20) NULL,
		[OperatorCode] [varchar] (20) NULL,
		[AdminAreaId] [varchar] (20) NULL,
		[DistrictId] [varchar] (20) NULL,
	) ON [PRIMARY]

	
END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1012
SET @ScriptDesc = 'Creation of Zonal Accessibility Links table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
