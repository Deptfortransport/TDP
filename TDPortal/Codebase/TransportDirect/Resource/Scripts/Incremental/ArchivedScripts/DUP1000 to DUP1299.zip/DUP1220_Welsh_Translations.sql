-- ***********************************************
-- NAME 		: DUP1220_Welsh_Translations.sql
-- DESCRIPTION 		: Script to add Welsh Translations
-- AUTHOR		: John Frank
-- DATE			: 06 Jan 2009
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.labelFindPageTitle.Text', 'Find a cycle route', 'Canfod llwybr beicio'

EXEC AddtblContent
1,1, 'langstrings', 'RouteText.Uturn', 'Make a U-Turn on', 'Gwnewch dro pedol ar'

EXEC AddtblContent
1,1, 'langstrings' , 'MapKeyControl.ImageViaLocation.AlternateText', 'Key for Via', 'Allwedd ar gyfer ''Trwy'''

EXEC AddtblContent
1,1, 'langstrings', 'MapKeyControl.LabelViaLocation', 'Via Location', 'Trwy Lleoliad'

EXEC AddtblContent
1,1, 'langstrings', 'MapKeyControl.LabelViaLocation.Print', 'Via', 'Trwy'

EXEC AddtblContent
1,1, 'langstrings', 'DataServices.CycleJourneyType.Quietest', 'Quietest', 'Tawelaf'

EXEC AddtblContent
1,1, 'langstrings', 'DataServices.CycleJourneyType.Recreational', 'Most recreational', 'Mwyaf hamdden'

EXEC AddtblContent
1,1, 'langstrings', 'JourneyPlannerOutput.JourneyWebNoResults', 
'Sorry we are unable to obtain transport options for your journey. There are several possible reasons and solutions you may wish to consider:<br />
<ul class="listerdisc"><li>Public transport options may be available but not using the date, time or transport preferences you have specified - click the ''Amend'' button to revise your journey request.<br /></li>
<li>Some travel information supplied to us could be incorrect - if you suspect this, please help us to investigate further by <a href="targetUrlContactPage">submitting a feedback form.</a></li></ul>',
'Mae''n ddrwg gennym, nid ydym yn gallu cael opsiynau cludiant cyhoeddus ar gyfer eich siwrnai chi. Mae sawl rheswm ac ateb posibl y gallech chi eu hystyried:<br />
<ul class="listerdisc"><li>Efallai bod opsiynau cludiant cyhoeddus ar gael ond nid ar y dyddiad, yr amser neu''r dewisiadau cludiant rydych chi wedi''u nodi - cliciwch y botwm ''Newid'' i newid eich cais am siwrnai.<br /></li>
<li>Efallai bod rhywfaint o wybodaeth deithio sy''n cael ei chyflenwi i ni yn anghywir - os ydych yn amau hyn, helpwch ni i ymchwilio ymhellach drwy <a href="targetUrlContactPage">gyflwyno ffurflen adborth.</a></li></ul>'

EXEC AddtblContent
1,1, 'langstrings', 'JourneyPlannerOutput.CJPPartialReturnAmendFindNearest', '<ul class="listerdisc"><li>Your starting place or destination may have limited or no public transport services - <a href="targetUrlFindNearest">try our ''Find nearest'' planner for a list of the closest rail and coach stations</a> and use them to plan your journey.</li></ul>', '<ul class="listerdisc"><li>Efallai nad yw gwasanaethau cludiant cyhoeddus yn mynd yn aml neu''n mynd o gwbl o''ch man cychwyn neu''ch cyrchfan chi - <a href="targetUrlFindNearest">ewch i''n trefnwr ''Canfod yr agosaf'' am restr o''r gorsafoedd tr�n a bws agosaf</a> a''u defnyddio i drefnu eich siwrnai.</li></ul>'

EXEC AddtblContent
1,1, 'langstrings', 'CyclePlanner.Results.CPPartialReturn', 'Sorry we are currently unable to obtain cycle journeys using the details you have entered. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 'Mae''n ddrwg gennym, nid ydym yn gallu cael siwrnai feicio ar hyn o bryd gan ddefnyddio''r manylion a roesoch. A wnewch chi ein helpu i ymchwilio ymhellach i hyn drwy lenwi ffurflen adborth (gwnewch hyn drwy glicio "Cysylltwch � ni" ar waelod y dudalen).'

EXEC AddtblContent
1,1, 'langstrings', 'GradientProfiler.Results.GPPartialReturn', 'Sorry we are currently unable to obtain the gradient profile for your cycle journey. Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom of the page)', 'Mae''n ddrwg gennym, nid ydym yn gallu cael y proffil graddiant ar gyfer eich siwrnai feicio ar hyn o bryd. A wnewch chi ein helpu i ymchwilio ymhellach i hyn drwy lenwi ffurflen adborth (gwnewch hyn drwy glicio "Cysylltwch � ni" ar waelod y dudalen).'

EXEC AddtblContent
1,1, 'langstrings', 'CyclePlanner.CycleJourneyGraphControl.labelSRGradientProfile.Text', 'Below is a chart showing a gradient profile of the cycle journey. Select the Show table view button to display a table of the journey distances and heights.', 'Ceir siart isod sy''n dangos proffil graddiant y siwrnai feicio. Dewiswch y botwm Dangos tabl i arddangos tabl o bellteroedd ac uchderau''r siwrnai.'

EXEC AddtblContent
1,1, 'langstrings', 'CyclePlanner.CycleJourneyDetailsTableControl.buttonShowMore', 'More details', 'Rhagor o fanylion'

EXEC AddtblContent
1,1, 'langstrings', 'CyclePlanner.CycleJourneyDetailsTableControl.buttonShowLess', 'Fewer details', 'Llai o fanylion'

EXEC AddtblContent
1,1, 'langstrings', 'CarCostingDetails.highTrafficSymbol', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif" align="middle" alt="Road exclamation sign" />', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/roadexclamation.gif" align="middle" alt="Arwydd ebychnod ffordd" />'

EXEC AddtblContent
1,1, 'langstrings', 'JourneyMapControl.ButtonDirectionsShow.Text', 'Show directions', 'Dangos cyfarwyddiadau'

EXEC AddtblContent
1,1, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput', '<div class="Column3Header"><div class="txtsevenbbl">
Cycle Planning</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
This is the first version of Transport Direct�s new cycle planner. We have worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure that there is good quality information on cycling in the following areas:
<ul>
<li> Merseyside</li>
</ul>
<br />
We would really appreciate your feedback on this initial version of the planner. Please click on ''Contact us'' at the bottom of the page to let us know what you think or report any problems.
<br /><br />
We will consider all feedback and will be improving the planner over the coming weeks. Work is also ongoing to provide cycle planning information in more areas - please check again soon if your local area is not yet available.
<br /><br />
Our aim is to provide national coverage for cycle planning soon. Once data is available in more areas and we have considered initial feedback, this page will be 
linked to from the main Transport Direct site.
<br /><br />
</td></tr>
</tbody></table></div>'
,'<div class="Column3Header"><div class="txtsevenbbl">
Trefnu Taith Feicio</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
Dyma''r fersiwn gyntaf o drefnwr teithiau beicio newydd Transport Direct. Rydym wedi gweithio gyda Cycling England, Arolwg Ordnans a''r awdurdodau lleol perthnasol i sicrhau bod gwybodaeth o ansawdd ar gael am feicio yn yr ardaloedd canlynol:
<ul>
<li> Glannau Mersi</li>
</ul>
<br />
Byddem yn wirioneddol yn gwerthfawrogi eich adborth am y fersiwn wreiddiol hon o''r trefnwr. Cliciwch ar ''Cysylltwch � ni'' ar waelod y dudalen i roi gwybod inni beth yw eich barn neu adrodd am unrhyw broblemau.
<br /><br />
Byddwn yn ystyried pob adborth ac yn gwella''r trefnwr dros yr wythnosau nesaf. Mae gwaith yn parhau hefyd i roi gwybodaeth i drefnu teithiau beicio mewn mwy o ardaloedd - dewch yn �l eto cyn bo hir os nad yw eich ardal leol ar gael eto.
<br /><br />
Ein nod yw rhoi gwybodaeth ar gyfer trefnu teithiau beicio ledled y genedl cyn bo hir. Pan fydd data ar gael mewn mwy o ardaloedd a phan fyddwn wedi ystyried adborth cychwynnol, bydd prif safle Transport Direct yn cysylltu �''r dudalen hon. 
<br /><br />
</td></tr>
</tbody></table></div>'

EXEC AddtblContent
1,1, 'langstrings', 'CycleRouteText.TimeBasedAccessRestriction', 'Time based access restriction:', 'Cyfyngiad mynediad yn seiliedig ar amser:'

EXEC AddtblContent
1,1, 'langstrings', 'CyclePlanner.CycleJourneyDetailsTableControl.Instruction.ManoeuvreImage.AltText', 'Take care complex manoeuvre', 'Cymerwch ofal symudiad cymhleth'

EXEC AddtblContent
1,1, 'langstrings', 'RouteText.ChargeAdultAndCycle', 'Charge for adult and cycle:', 'T�l am oedolyn a beic:'

EXEC AddtblContent
1,1, 'langstrings', 'CycleAttribute.Unused', 'unused', 'heb ei ddefnyddio'

EXEC AddtblContent
1,1, 'langstrings', 'CycleAttribute.WalkaboutManoeuvre', 'At this point you may need to walk your bike', 'Yn y man hwn efallai bydd angen ichi gerdded gyda''ch beic'

EXEC AddtblContent
1,1, 'langstrings', 'CycleAttribute.AdvancedManoeuvre', 'Extra care should be taken with the road junctions at this point', 'Dylid cymryd gofal ychwanegol gyda''r cyffyrdd yn y man hwn'

EXEC AddtblContent
1,1, 'langstrings', 'CycleAttribute.FirmAtoB', 'is firm', 'yn gadarn'

EXEC AddtblContent
1,1, 'langstrings', 'CycleAttribute.Busy', 'is generally busy', 'yn brysur yn gyffredinol'

EXEC AddtblContent
1,1, 'langstrings', 'CycleAttribute.Quiet', 'is generally quiet', 'yn dawel yn gyffredinol'

EXEC AddtblContent
1,55, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindTrunkInput',
'<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>With the city-to-city planner you can compare train, plane, coach and car journeys between two cities or towns in Britain on a given day. Select your origin and destination from our dropdown lists of major locations within Britain and city-to-city will give you journey options broken down by transport type.</p><br/></div></div>',
'<div class="PageSoftContentContainer">  <div class="PageSoftContent"><p>Gyda''r trefnwr dinas-i-ddinas gallwch gymharu siwrneiau tr�n, awyren, bws a char rhwng dwy ddinas neu dref ym Mhrydain ar ddiwrnod penodol. Dewiswch eich man cychwyn a''ch cyrchfan o''n rhestri cwympo o leoliadau mawr ym Mhrydain a bydd y trefnwr dinas-i-ddinas yn rhoi siwrneiau ichi ddewis ohonynt yn �l math o gludiant.</p><br/></div></div>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1220
SET @ScriptDesc = 'Welsh content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO