-- ***********************************************
-- NAME 		: DUP1110_XMLRailTicketType_Add_To_FtpConfig_Table.sql
-- DESCRIPTION 		: Add XML RailTicketType to FTP_CONFIG table
-- AUTHOR		: Mitesh Modi
-- DATE			: 19 Sep 2008
-- ************************************************

USE [PermanentPortal]
GO

--insert into FTP_Config table
IF NOT EXISTS (SELECT * FROM FTP_CONFIGURATION WHERE [DATA_FEED] = 'yfk550')
   BEGIN
	INSERT INTO [dbo].[FTP_CONFIGURATION] ([FTP_CLIENT], [DATA_FEED], [IP_ADDRESS], [USERNAME], [PASSWORD], [LOCAL_DIR], [REMOTE_DIR], [FILENAME_FILTER], [MISSING_FEED_COUNTER], [MISSING_FEED_THRESHOLD], [DATA_FEED_DATETIME], [DATA_FEED_FILENAME], [REMOVE_FILES])
	VALUES ('1', 'yfk550', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 0, 1, '2008-01-01 00:00:00.000', ' ', 1)
   END
ELSE
   BEGIN
	UPDATE [dbo].[FTP_CONFIGURATION] 
	   SET 		[IP_ADDRESS] = 'N/A',
			  [USERNAME] = 'N/A', 
			  [PASSWORD] = 'N/A',
			 [LOCAL_DIR] = 'N/A', 
			[REMOTE_DIR] = 'N/A', 
		   [FILENAME_FILTER] = 'N/A', 
	      [MISSING_FEED_COUNTER] = 0, 
	    [MISSING_FEED_THRESHOLD] = 1, 
		[DATA_FEED_DATETIME] = '2008-01-01 00:00:00.000', 
		[DATA_FEED_FILENAME] = ' ', 
		      [REMOVE_FILES] = 1

	 WHERE [DATA_FEED] = 'yfk550'

   END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1110
SET @ScriptDesc = 'Add XML RailTicketType to FTP_CONFIG table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------