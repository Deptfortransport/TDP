-- ***********************************************
-- NAME 		: DUP1143_CyclePlanner_FAQ_LinkSetup_Content.sql
-- DESCRIPTION 		: Script to add new FAQ link for Cycle planner
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 Oct 2008
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle FAQ page - url
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- FAQ Cycle Planning - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycle', 'Page',
'/Web2/staticnoprint.aspx',
'/Web2/staticnoprint.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycle', 'QueryString',
'staticnoprint',
'staticnoprint'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpCycle', 'Channel',
'/Channels/TransportDirect/Help/HelpCycle',
'/Channels/TransportDirect/Help/HelpCycle'

-- FAQ Cycle Planning - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycle', 'Page',
'/Web2/staticdefault.aspx',
'/Web2/staticdefault.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycle', 'QueryString',
'staticdefault',
'staticdefault'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpCycle', 'Channel',
'/Channels/TransportDirect/Printer/HelpCycle',
'/Channels/TransportDirect/Printer/HelpCycle'


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1143
SET @ScriptDesc = 'Cycle planner - FAQ Content page link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO