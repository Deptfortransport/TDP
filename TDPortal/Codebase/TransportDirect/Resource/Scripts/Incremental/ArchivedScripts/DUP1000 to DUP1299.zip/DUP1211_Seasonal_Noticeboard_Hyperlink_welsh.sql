-- ***********************************************
-- NAME 		: DUP1211_Seasonal_Noticeboard_Hyperlink_welsh.sql
-- DESCRIPTION 		: Script to update Seasonal Noticeboard content to include welsh
-- AUTHOR		: Rich Broddle
-- DATE			: 16 Dec 2008 
-- ************************************************

USE [Content]
GO


-- Update the text for the new hyperlink
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlanner.hyperlinkBankHolidayInfo', '<STRONG>Click here for information about changes to public transport services.</STRONG>', '<STRONG>Cliciwch yma am wybodaeth am newidiadau i wasanaethau cludiant cyhoeddus.</STRONG>'

-- 

GO
----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1211
SET @ScriptDesc = 'updated Seasonal Noticeboard content to include welsh'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO