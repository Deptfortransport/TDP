-- ***********************************************
-- NAME 		: DUP0531_CO2_PT_Link_Update.sql
-- DESCRIPTION 		: Update for CO2 PT expandable link name
-- ************************************************

USE [TransientPortal]
GO


IF EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = 'Journey Emissions Compare'))
UPDATE [dbo].[Resource]
SET [Text] = 'Check journey CO2'
WHERE [Text] = 'Journey Emissions Compare' AND [Culture] = 'en-GB'

IF EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = 'cy Journey Emissions Compare'))
UPDATE [dbo].[Resource]
SET [Text] = 'cy Check journey CO2'
WHERE [Text] = 'cy Journey Emissions Compare' AND [Culture] = 'cy-GB'

GO



----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 531
SET @ScriptDesc = 'Updated CO2 link name on Tips and tools menu'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO