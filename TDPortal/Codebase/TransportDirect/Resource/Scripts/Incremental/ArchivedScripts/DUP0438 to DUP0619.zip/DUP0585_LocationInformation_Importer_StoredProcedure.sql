-- ***********************************************
-- NAME 		: DUP0585_LocationInformation_Importer_StoredProcedure.sql
-- DESCRIPTION 		: sql to setup the Airport Links import (Location Information) stored procedures
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [TransientPortal]
GO
-------------------------------------------------------------------------
-- ADD IMPORT STORED PROCEDURE
-------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportAirportLinksData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ImportAirportLinksData]
GO

/* Imports all airport links location information data, creating external links 
and populating LocationInformation table. Will first delete existing row for a NaPTAN 
before inserting*/
CREATE PROCEDURE [dbo].[ImportAirportLinksData]
(
	@XML text
)
AS
BEGIN
	SET NOCOUNT ON
	SET XACT_ABORT ON

	DECLARE @DocID int, @RowCount int, @XMLPathData varchar(50)

	-- Datafeed data
	DECLARE @NaPTANCode varchar(12)
	DECLARE @DepartureURL varchar(500), @ArrivalURL varchar(500), @InformationURL varchar(500)	

	-- External link
	DECLARE @ExternalLinksID varchar(500)
	DECLARE @DepartureLinkID varchar(500), @ArrivalLinkID varchar(500), @InformationLinkID varchar(500)

	-- TextConstants
	DECLARE @DepartureType varchar(20), @ArrivalType varchar(20), @InformationType varchar(20), @NoneType varchar(20)
	SET @DepartureType = 'Departure'
	SET @ArrivalType = 'Arrival'
	SET @InformationType = 'Information'
	SET @NoneType = 'None'

	-- Load xml document 
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData =  '/airportlinks/AirportLink'

	-- Start transaction
	BEGIN TRANSACTION

	--use a cursor to insert data because we are inserting into more than one table
	--Insert into tables
	DECLARE cursorAirportLink CURSOR FOR
		SELECT 
			X.[NaPTAN],
			X.[DepartureBoard],
			X.[ArrivalsBoard],
			X.[GeneralInformation]
		FROM
		OPENXML (@DocID, @XMLPathData, 2)
		WITH
		(	
			[NaPTAN] varchar(12) ,
			[DepartureBoard] varchar(500) ,				
			[ArrivalsBoard] varchar(500),
			[GeneralInformation] varchar(500)
		) X 
	
	OPEN cursorAirportLink

	FETCH NEXT FROM cursorAirportLink INTO 
		@NaPTANCode, @DepartureURL, @ArrivalURL, @InformationURL

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @NaPTANCode <> ''
		BEGIN

			-- Delete existing LocationInformation and External link records for this Naptan
			IF EXISTS(SELECT * FROM [dbo].[LocationInformation] WHERE [Naptan] = @NaPTANCode)
			BEGIN
				SET @DepartureLinkID = (
					SELECT ExternalLinkID FROM [dbo].[LocationInformation] 
					WHERE [Naptan] = @NaPTANCode AND [LinkType] = @DepartureType)
	
				SET @ArrivalLinkID = (
					SELECT ExternalLinkID FROM [dbo].[LocationInformation] 
					WHERE [Naptan] = @NaPTANCode AND [LinkType] = @ArrivalType)

				SET @InformationLinkID = (
					SELECT ExternalLinkID FROM [dbo].[LocationInformation] 
					WHERE [Naptan] = @NaPTANCode AND [LinkType] = @InformationType)

				DELETE FROM [LocationInformation] WHERE [Naptan] = @NaPTANCode
				DELETE FROM [ExternalLinks] WHERE [Id] IN (@DepartureLinkID, @ArrivalLinkID, @InformationLinkID)
			END

			-- Insert new external links and location information entries
			IF @DepartureURL <> ''
			BEGIN

				SELECT @ExternalLinksID = NEWID()

				INSERT INTO [dbo].[ExternalLinks] ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
				VALUES(	@ExternalLinksID, 
					@DepartureURL, 
					@DepartureURL, 
					CONVERT(datetime, '01/01/2007', 103),
					CONVERT(datetime, '31/12/2099', 103),
					@NaPTANCode, 
					'Added by Airport Links Import')

				INSERT INTO [dbo].[LocationInformation] (Naptan, ExternalLinkID, LinkType)
				VALUES( @NaPTANCode,
					@ExternalLinksID,
					@DepartureType)
			END

			IF @ArrivalURL <> ''
			BEGIN

				SELECT @ExternalLinksID = NEWID()
				
				INSERT INTO [dbo].[ExternalLinks] ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
				VALUES(	@ExternalLinksID, 
					@ArrivalURL, 
					@ArrivalURL, 
					CONVERT(datetime, '01/01/2007', 103),
					CONVERT(datetime, '31/12/2099', 103),
					@NaPTANCode, 
					'Added by Airport Links Import')

				INSERT INTO [dbo].[LocationInformation] (Naptan, ExternalLinkID, LinkType)
				VALUES( @NaPTANCode,
					@ExternalLinksID,
					@ArrivalType)
			END

			IF @InformationURL <> ''
			BEGIN

				SELECT @ExternalLinksID = NEWID()
				
				INSERT INTO [dbo].[ExternalLinks] ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
				VALUES(	@ExternalLinksID, 
					@InformationURL, 
					@InformationURL, 
					CONVERT(datetime, '01/01/2007', 103),
					CONVERT(datetime, '31/12/2099', 103),
					@NaPTANCode, 
					'Added by Airport Links Import')

				INSERT INTO [dbo].[LocationInformation] (Naptan, ExternalLinkID, LinkType)
				VALUES( @NaPTANCode,
					@ExternalLinksID,
					@InformationType)
			END

			-- If the naptan has no URLs, then insert a blank row
			IF  @DepartureURL = '' AND @ArrivalURL = '' AND @InformationURL = ''
			BEGIN
				INSERT INTO [dbo].[LocationInformation] (Naptan, ExternalLinkID, LinkType)
				VALUES( @NaPTANCode,
					'',
					@NoneType) --Default it to no type
			END

		END --IF Naptan
		
		-- This is executed as long as the previous fetch succeeds.
		FETCH NEXT FROM cursorAirportLink INTO 
		@NaPTANCode, @DepartureURL, @ArrivalURL, @InformationURL

	END --WHILE
	
	CLOSE cursorAirportLink
	DEALLOCATE cursorAirportLink 


	-- Remove xml doc from memorry
	EXEC sp_xml_removedocument @DocID

	IF @@ERROR<>0
		ROLLBACK TRANSACTION
	ELSE
	BEGIN
		COMMIT TRANSACTION		
		
		UPDATE [dbo].[ChangeNotification]
		SET [Version] = Version + 1
		WHERE [Table] = 'LocationInformation'

	 	UPDATE [dbo].[ChangeNotification]
		SET [Version] = Version + 1
		WHERE [Table] = 'ExternalLinks'
	END
END
GO

GRANT EXECUTE ON [ImportAirportLinksData] TO [???]
GO

-------------------------------------------------------------------------
-- ADD GET DATA STORED PROCEDURE
-------------------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLocationInformation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetLocationInformation]
GO

/* Returns all rows contained in location information data for all indate external links*/
CREATE PROCEDURE [dbo].[GetLocationInformation]
AS
BEGIN

	DECLARE @date SMALLDATETIME

	SET @date = CONVERT(char(8), GetDate(), 112)

	SELECT Naptan, [LocationInformation].[ExternalLinkId], LinkType FROM [LocationInformation]
	INNER JOIN [ExternalLinks] ON [LocationInformation].[ExternalLinkId] = [ExternalLinks].[Id]
	WHERE 
	(
		(ExternalLinks.EndDate >= @date AND ExternalLinks.StartDate IS NULL)
	OR 
		(ExternalLinks.StartDate IS NULL AND ExternalLinks.EndDate IS NULL) 
	OR 
		(ExternalLinks.StartDate <= @date AND ExternalLinks.EndDate IS NULL)
	OR
		(ExternalLinks.StartDate <= @date AND ExternalLinks.EndDate >= @date)
	)
END
GO

GRANT EXECUTE ON [GetLocationInformation] TO [???]
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 585
SET @ScriptDesc = 'Airport Links import and get stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------