-- ************************************************************
-- NAME 	: DUP0602_Gaz_and_GazStaging_Create_LocAliases.sql
-- DESCRIPTION 	: Create Locality Alias table in GAZ and GAZ_Staging
-- ************************************************************

USE GAZ

if exists (select * from dbo.sysobjects where id = object_id(N'[gazadmin].[LocAliases]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [gazadmin].[LocAliases]
GO

CREATE TABLE [gazadmin].[LocAliases] (
	[AliasName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PrimaryID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [GAZ_DATA]
GO

USE GAZ_STAGING

if exists (select * from dbo.sysobjects where id = object_id(N'[gazadmin].[LocAliases]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [gazadmin].[LocAliases]
GO

CREATE TABLE [gazadmin].[LocAliases] (
	[AliasName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PrimaryID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [GAZ_DATA]
GO


-- =============================================  
-- CHANGE LOG
-- =============================================  
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 602
SET @ScriptDesc = 'Create Locality Alias table in GAZ and GAZ_Staging'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-- =============================================  