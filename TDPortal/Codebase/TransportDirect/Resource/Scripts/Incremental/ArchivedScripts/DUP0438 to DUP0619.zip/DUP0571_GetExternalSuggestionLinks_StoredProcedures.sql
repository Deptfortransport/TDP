-- ************************************************************
-- NAME 	: DUP0571_GetExternalSuggestionLinks_StoredProcedures.sql
-- DESCRIPTION 	: Creates new stored procedure GetExternalSuggestionLinks
-- ************************************************************

USE [TransientPortal]
GO

---------------------------------------------------------------
-- Drop SP
----------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetExternalSuggestionLinkData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetExternalSuggestionLinkData]
GO

---------------------------------------------------------------
-- Create new SP
----------------------------------------------------------------

CREATE PROCEDURE [dbo].[GetExternalSuggestionLinkData]
AS
	SELECT 	
		Context.[Name] ContextName, 
		SuggestionLink.SuggestionLinkId, 
		LinkCategory.Priority CategoryPriority, 
		LinkCategory.[Name] CategoryName,
		SuggestionLink.Priority LinkPriority, 
		ExternalLinks.URL, 
		Resource.Culture, 
		Resource.[Text] ResourceString, 
		SuggestionLink.IsRoot
	FROM SuggestionLink 
	INNER JOIN ContextSuggestionLink 
		ON SuggestionLink.SuggestionLinkId = ContextSuggestionLink.SuggestionLinkId 
	INNER JOIN Context 
		ON ContextSuggestionLink.ContextId = Context.ContextId 
	INNER JOIN LinkCategory 
		ON SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId 
	INNER JOIN ResourceName 
		ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId 
	INNER JOIN Resource 
		ON ResourceName.ResourceNameId = Resource.ResourceNameId 
	INNER JOIN ExternalSuggestionLink
		ON SuggestionLink.ExternalInternalLinkId = ExternalSuggestionLink.ExternalSuggestionLinkId
	INNER JOIN ExternalLinks
		ON ExternalSuggestionLink.ExternalLinkId = ExternalLinks.[Id]
			AND SuggestionLink.ExternalInternalLinkType = 'External'
ORDER BY Context.ContextID, CategoryPriority, LinkPriority, Culture

GO

GRANT  EXECUTE  ON [dbo].[GetExternalSuggestionLinkData]  TO [???]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 571
SET @ScriptDesc = 'Added GetExternalSuggestionLinks procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO