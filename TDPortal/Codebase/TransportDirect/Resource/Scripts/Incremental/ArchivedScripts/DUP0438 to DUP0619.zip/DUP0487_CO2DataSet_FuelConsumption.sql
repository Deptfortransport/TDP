-- *************************************************************************************
-- NAME 		: DUP0487_CO2DataSet_FuelConsumption.sql
-- DESCRIPTION 		: Adds the Journey Emissions Fuel Consumption data set
-- *************************************************************************************

USE PermanentPortal
GO

----------------------------------------------------------------
-- JourneyEmissions Fuel Consumption options Data Set type
----------------------------------------------------------------
DELETE FROM DataSet WHERE DataSet = 'FuelConsumptionCO2SelectRadio' AND PartnerId = 0
GO

INSERT INTO DataSet (DataSet, PartnerId) VALUES ('FuelConsumptionCO2SelectRadio', 0)
GO


----------------------------------------------------------------
-- Add data set to properties list
----------------------------------------------------------------
DELETE FROM properties WHERE pName LIKE 'TransportDirect.UserPortal.DataServices.FuelConsumptionCO2SelectRadio.%' AND PartnerId = 0
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.FuelConsumptionCO2SelectRadio.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''FuelConsumptionCO2SelectRadio'' AND PartnerId = 0 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.FuelConsumptionCO2SelectRadio.db', 'DefaultDB', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.FuelConsumptionCO2SelectRadio.type', '3', 'DataServices', 'UserPortal', 0)
GO

----------------------------------------------------------------
-- Creat the items in the data set
----------------------------------------------------------------
DELETE FROM DropDownLists WHERE DataSet = 'FuelConsumptionCO2SelectRadio'
GO

INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('FuelConsumptionCO2SelectRadio', 'Average for my type of car', '1', 1, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('FuelConsumptionCO2SelectRadio', 'More specifically', '2', 0, 2, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('FuelConsumptionCO2SelectRadio', 'Gramms of CO<sub>2</sub> per km', '3', 0, 3, 0)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 487
SET @ScriptDesc = 'Added the Journey Emissions Fuel Consumption data set'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
