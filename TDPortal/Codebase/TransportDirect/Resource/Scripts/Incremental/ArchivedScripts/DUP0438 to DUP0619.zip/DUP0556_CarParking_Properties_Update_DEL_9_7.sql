-- ***********************************************
-- NAME 		: DUP0554_CarParking_Properties_Update.sql
-- DESCRIPTION 		: Updates the properties for Car Parking used in Find nearest car parks
--			  - Number of car parks returned to 20
--			  - New radius to perform the second car park search
--			  - New property for the car park data providers PDF URL
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE FIND CAR PARK PROPERTIES
----------------------------------------

-- NUMBER OF CAR PARKS 
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.NumberCarParksReturned')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.NumberCarParksReturned'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.NumberCarParksReturned', '20', 'Web', 'UserPortal', 0)


-- REMOVE EXISTING RADIUS
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.InitialRadius')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.InitialRadius'
  END

IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.MaximumRadius')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.MaximumRadius'
  END


-- ADD NEW RADIUS
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius1.Initial')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius1.Initial'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.Radius1.Initial', '3218', 'Web', 'UserPortal', 0)


IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius1.Maximum')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius1.Maximum'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.Radius1.Maximum', '3219', 'Web', 'UserPortal', 0)


IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Initial')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Initial'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.Radius2.Initial', '16094', 'Web', 'UserPortal', 0)


IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Maximum')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Maximum'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.Radius2.Maximum', '16095', 'Web', 'UserPortal', 0)


-- ADD NEW PDF URLs
-- English
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.CarParkProviders.PDF.English')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.CarParkProviders.PDF.English'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.CarParkProviders.PDF.English', '/Web/downloads/CarParkProviders.pdf', 'Web', 'UserPortal', 0)

-- Welsh
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.CarParkProviders.PDF.Welsh')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.CarParkProviders.PDF.Welsh'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.CarParkProviders.PDF.Welsh', '/Web/downloads/CarParkProviders_CY.pdf', 'Web', 'UserPortal', 0)

GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 554
SET @ScriptDesc = 'Updates for Find nearest car park properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO