-- ************************************************************
-- NAME 	: DUP0468_CarParking_SwitchON.sql
-- DESCRIPTION 	: Turns car parking functionality on
--		: (All car parking incremental scripts must have been run)
--
-- IMPORTANT    : THIS SCRIPT REQUIRES A DEPLOYMENT DECISION
--		:
-- 		: If car parking functionality is to be 
--		: switched ON, uncomment all the sql code and run.
--		:
--		: To make uncommenting easier, do a global replace 
--		: for:  --++
-- ************************************************************

------------------------------------------
-- SET CAR PARK SWITCH TO TRUE
------------------------------------------

--++USE PermanentPortal

--++UPDATE [properties] 
--++SET pValue = 'True' 
--++WHERE pName = 'CarParkingAvailable'
--++GO


------------------------------------------
-- INSERT AN EXPANDABLE MENU LINK
------------------------------------------

--++USE TransientPortal
--++GO

--++DECLARE @ResourceNameID INT,
--++	@SuggestionLinkID INT,
--++	@ContextSuggestionLinkID INT

--++SET @ResourceNameID = (SELECT ResourceNameId FROM dbo.ResourceName WHERE ResourceName = 'FindNearestCarPark')
--++SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM dbo.SuggestionLink 
--++				WHERE LinkCategoryId = 4
--++				AND ResourceNameID = @ResourceNameID)
--++SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from dbo.ContextSuggestionLink) + 1


--insert into ContextSuggestionLink table
--++INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
--++SELECT @ContextSuggestionLinkId, 3, @SuggestionLinkID  -- FIND NEAREST CAR PARK EXPANDABLE MENU LINK

--++GO


------------------------------------------
-- Insert find car route suggestion link for find car park
------------------------------------------

--++USE TransientPortal
--++GO

--++DECLARE @ResourceNameID INT,
--++	@SuggestionLinkID INT,
--++	@ContextSuggestionLinkID INT

--++SET @ResourceNameID = (SELECT ResourceNameId FROM dbo.ResourceName WHERE ResourceName = 'FindNearestCarPark')
--++SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM dbo.SuggestionLink 
--++				WHERE LinkCategoryId = 1
--++				AND ResourceNameID = @ResourceNameID)
--++SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from dbo.ContextSuggestionLink) + 1

--insert into ContextSuggestionLink table
--++INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
--++SELECT @ContextSuggestionLinkId, 2, @SuggestionLinkID  -- FIND NEAREST CAR PARK SUGGESTION LINK IN FIND A CAR ROUTE

--++GO


------------------------------------------
-- INSERT DROPDOWN ITEM
------------------------------------------

--++USE PermanentPortal
--++GO

--insert into DropDownLists table for FindAPlaceControl
--++INSERT INTO [DropDownLists] (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
--++VALUES ('FindLocationShowOptions', 'CarPark', '4', 0, 4, 0)
--++GO

--shift the TrafficLevels entry down one
--++UPDATE [DropDownLists] 
--++SET SortOrder = 5 
--++WHERE ResourceID = 'TrafficLevels' 
--++GO


------------------------------------------
-- UPDATE CHANGE CATALOGUE
------------------------------------------

--++USE PermanentPortal
--++GO

--++IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 468)
--++	UPDATE dbo.ChangeCatalogue
--++	SET
--++		ChangeDate = (getDate()),
--++		Summary = 'Car parking has been turned on - expandable link, mini find a place dropdown, and car route suggestion link all inserted'
--++	WHERE ScriptNumber = 468
--++ELSE
--++	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
--++		VALUES (468, (getDate()), 'Car parking has been turned on - expandable link, mini find a place dropdown, and car route suggestion link all inserted')
--++GO
