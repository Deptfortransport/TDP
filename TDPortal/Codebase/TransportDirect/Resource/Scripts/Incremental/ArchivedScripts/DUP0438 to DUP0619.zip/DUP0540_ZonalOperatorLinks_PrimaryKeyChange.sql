-- ************************************************************
-- NAME 	: DUP0540_ZonalOperatorLinks_PrimaryKeyChange.sql
-- DESCRIPTION 	: Changes the primary key on zonalOperatorLinks table to ModeId & OperatorCode
--                
-- ************************************************************


USE TransientPortal
GO

ALTER TABLE dbo.[ZonalOperatorLinks] DROP 
	CONSTRAINT [PK_ZonalOperatorLinks] 

ALTER TABLE dbo.[ZonalOperatorLinks] ADD 
	CONSTRAINT [PK_ZonalOperatorLinks] PRIMARY KEY  CLUSTERED 
	(
		[OperatorCode],
		[ModeId]		
	)
GO


-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 540)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Changes the primary key on zonalOperatorLinks table to ModeId & OperatorCode'
	WHERE ScriptNumber = 540
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (540, (getDate()), 'Changes the primary key on zonalOperatorLinks table to ModeId & OperatorCode')
GO