-- ***********************************************
-- NAME 		: DUP0548_CO2_PT_DefaultCar_Property.sql
-- DESCRIPTION 		: Added the default car properties to be used when calculating 
-- 			: the car CO2 emissions for a PT journey
-- ************************************************

----------------------------------------
-- Update Properties
----------------------------------------

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.CarSize.Default')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.CarSize.Default'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.CarSize.Default', 'medium', 'Web', 'UserPortal', 0)
GO


IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.FuelType.Default')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.FuelType.Default'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.FuelType.Default', 'petrol', 'Web', 'UserPortal', 0)
GO


----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 548
SET @ScriptDesc = 'Added journey emissions CO2 default car size and fuel type properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO