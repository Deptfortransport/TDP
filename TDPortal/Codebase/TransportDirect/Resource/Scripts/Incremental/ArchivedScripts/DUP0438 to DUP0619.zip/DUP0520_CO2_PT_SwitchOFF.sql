-- ************************************************************
-- NAME 	: DUP0520_CO2_PT_SwitchOFF.sql
-- DESCRIPTION 	: Turns CO2 Emissions for Public Transport functionality off
--
-- IMPORTANT    : THIS SCRIPT REQUIRES A DEPLOYMENT DECISION
--		:
-- 		: If CO2 Emissions for Public Transport is to be 
--		: switched OFF, uncomment all the sql code and run.
--		:
--		: To make uncommenting easier, do a global replace 
--		: for:  --++
-- ************************************************************

------------------------------------------
-- SET SWITCH TO FALSE
------------------------------------------

USE [PermanentPortal]
GO

UPDATE [properties]
SET pValue = 'False'
WHERE pName = 'JourneyEmissions.PTAvailable'
GO


------------------------------------------
-- DELETE EXPANDABLE MENU LINK
------------------------------------------

USE [TransientPortal]
GO

DECLARE @ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT

SET @ResourceNameID = (SELECT [ResourceNameId] FROM [dbo].[ResourceName] WHERE [ResourceName] = 'JourneyEmissionsCompare')
SET @SuggestionLinkID = (SELECT [SuggestionLinkID] FROM [dbo].[SuggestionLink] 
					WHERE [LinkCategoryId] = 6
					AND [ResourceNameID] = @ResourceNameID)
SET @ContextSuggestionLinkID = (SELECT [ContextSuggestionLinkId] FROM [dbo].[ContextSuggestionLink] 
					WHERE [ContextId] = 3
					AND [SuggestionLinkID] = @SuggestionLinkID)


--delete from ContextSuggestionLink table
DELETE FROM [ContextSuggestionLink] 
WHERE [ContextSuggestionLinkId] =  @ContextSuggestionLinkId
GO


------------------------------------------
-- UPDATE CHANGE CATALOGUE
------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 520
SET @ScriptDesc = 'CO2 emissions for public transport has been turned off - expandable link deleted, and switch set to false'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO