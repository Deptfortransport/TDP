-- ***********************************************
-- NAME 		: DUP0510_Feedback_DataSets_Update.sql
-- DESCRIPTION 		: Adds a Feedback Status datasets required for the Feedback Viewer page:
--				UserFeedbackStatus
-- ************************************************

USE PermanentPortal
GO

----------------------------------------------------------------
-- Delete appropriate datasets before adding
----------------------------------------------------------------
DELETE FROM DropDownLists WHERE DataSet = 'UserFeedbackStatus'
GO

DELETE FROM properties WHERE pName LIKE 'TransportDirect.UserPortal.DataServices.UserFeedbackStatus.%' AND PartnerId = 0
GO

DELETE FROM DataSet WHERE DataSet = 'UserFeedbackStatus' AND PartnerId = 0
GO

----------------------------------------------------------------
-- Create Data Set types
----------------------------------------------------------------
INSERT INTO DataSet (DataSet, PartnerId) VALUES ('UserFeedbackStatus', 0)
GO


----------------------------------------------------------------
-- Add data sets to properties list
----------------------------------------------------------------
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackStatus.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''UserFeedbackStatus'' AND PartnerId = 0 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackStatus.db', 'DefaultDB', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackStatus.type', '3', 'DataServices', 'UserPortal', 0)
GO


----------------------------------------------------------------
-- Create the items in the data sets
----------------------------------------------------------------
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackStatus', 'In progress', '1', 0, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackStatus', 'Submitted', '2', 0, 2, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackStatus', 'Assigned', '3', 0, 3, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackStatus', 'Investigating', '4', 0, 4, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackStatus', 'Completed', '5', 0, 5, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackStatus', 'Closed', '6', 0, 6, 0)
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 510
SET @ScriptDesc = 'Added the Feedback Status data sets'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
