-- ************************************************************
-- NAME 	: DUP0605_AddVersionColTodft_placesTable.sql
-- DESCRIPTION 	: Add Version column to the dft_places tables in the GAZ DBs
-- ************************************************************

USE GAZ_Staging
GO

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'dft_places'
                  AND COLUMN_NAME = N'Version')
BEGIN 
	ALTER TABLE gazadmin.dft_places
	ADD Version int

	Update gazadmin.dft_places SET Version = 1

END
GO

USE GAZ
GO

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'dft_places'
                  AND COLUMN_NAME = N'Version')
BEGIN
	ALTER TABLE gazadmin.dft_places
	ADD Version int

	Update gazadmin.dft_places SET Version = 1
END
GO

-- =============================================  
-- CHANGE LOG
-- =============================================  
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 605
SET @ScriptDesc = 'Add Version column to the dft_places tables in the GAZ DBs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-- =============================================  

