-- ***********************************************
-- NAME 		: DUP0589_FindNearestLandingPage_PageEntry.sql
-- DESCRIPTION 		: sql to setup Page entry events for FindNearestLandingPage
-- AUTHOR		: Mitesh Modi
-- ************************************************

----------------------------------------
-- INSERT PAGE ENTRY
----------------------------------------
USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindNearestLandingPage') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindNearestLandingPage', 'Find nearest landing page' FROM PageEntryType
GO

----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 589
SET @ScriptDesc = 'Added page entry event for find nearest landing page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO