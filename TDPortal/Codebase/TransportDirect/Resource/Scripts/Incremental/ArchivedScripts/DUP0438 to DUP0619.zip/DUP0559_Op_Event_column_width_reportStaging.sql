-- ***********************************************
-- NAME 		: DUP0559_Op_Event_column_width_reportStaging.sql
-- DESCRIPTION 		: Increase the message column width for operational events in the reportStaging database
--
-- ************************************************

Use ReportStagingDB

ALTER TABLE OperationalEvent
ALTER COLUMN Message Varchar(800)
GO