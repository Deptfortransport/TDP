-- ***********************************************
-- NAME :        DUP0541_TrunkSearchInterval_Underground_Properties.sql
-- DESCRIPTION : Create TrunkSearchInterval properties for Underground - resolution for Vantive 4524120
-- ************************************************

USE PermanentPortal

DELETE FROM properties
WHERE pName = 'JourneyControl.TrunkSearchInterval1.Underground'


DELETE FROM properties
WHERE pName = 'JourneyControl.TrunkSearchInterval2.Underground'


DELETE FROM properties
WHERE pName = 'JourneyControl.TrunkSearchInterval3.Underground'


DELETE FROM properties
WHERE pName = 'JourneyControl.TrunkSearchInterval4.Underground'

insert into properties (pName, pValue, AID, GID, PartnerId) 
values ('JourneyControl.TrunkSearchInterval1.Underground',2,'<DEFAULT>','<DEFAULT>',0)

insert into properties (pName, pValue, AID, GID, PartnerId) 
values ('JourneyControl.TrunkSearchInterval2.Underground',22,'<DEFAULT>','<DEFAULT>',0)

insert into properties (pName, pValue, AID, GID, PartnerId) 
values ('JourneyControl.TrunkSearchInterval3.Underground',22,'<DEFAULT>','<DEFAULT>',0)

insert into properties (pName, pValue, AID, GID, PartnerId) 
values ('JourneyControl.TrunkSearchInterval4.Underground',2,'<DEFAULT>','<DEFAULT>',0)


-------------------------------------------------
-- Update the ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 541)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Create TrunkSearchInterval properties for Underground - resolution for Vantive 4524120'
	WHERE ScriptNumber = 541
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (541, (getDate()), 'Create TrunkSearchInterval properties for Underground - resolution for Vantive 4524120')
GO
