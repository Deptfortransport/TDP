-- ************************************************************
-- NAME 	: DUP0581_D08_AddOperationalEvent_Stored_Procedure.sql
-- DESCRIPTION 	: Amend message variable size.
-- ************************************************************

USE ReportStagingDB

-- Check for existance of the procedure and if it exists drop it.
IF EXISTS (SELECT * FROM information_schema.routines WHERE specific_name = 'AddOperationalEvent')
  BEGIN
   DROP PROCEDURE dbo.AddOperationalEvent
  END

GO

--create procedure
CREATE PROCEDURE AddOperationalEvent (@SessionId varchar(50), @Message varchar(1500), @MachineName varchar(50), @AssemblyName varchar(50), @MethodName varchar(50), @TypeName varchar(50), @Level varchar(50), @Category varchar(50), @Target varchar(50), @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsertOperationalEvent AS nvarchar(256)
    set @localized_string_UnableToInsertOperationalEvent = 'Unable to Insert a new record into OperationalEvent Table'

    Insert into OperationalEvent (SessionId, Message, MachineName, AssemblyName, MethodName, TypeName, Level, Category, Target, TimeLogged)
    Values (@SessionId, @Message, @MachineName, @AssemblyName, @MethodName, @TypeName, @Level, @Category, @Target, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsertOperationalEvent, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End
GO

-- permissions
GRANT EXECUTE ON [AddOperationalEvent] TO [DFTSIW\ASPUSER]
GO
GRANT EXECUTE ON [AddOperationalEvent] TO [BBPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [AddOperationalEvent] TO [ACPDFTW\ASPUSER]
GO

-------------------------------------------------
-- Update the ChangeCatalogue
-------------------------------------------------

USE ReportStagingDB
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 581)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Increased message variable size to 1500'
	WHERE ScriptNumber = 581
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (581, (getDate()), 'Increased message variable size to 1500')
GO
