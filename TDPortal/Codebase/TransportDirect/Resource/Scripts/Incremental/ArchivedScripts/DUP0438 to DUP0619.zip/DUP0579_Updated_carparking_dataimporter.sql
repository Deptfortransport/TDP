-- ***********************************************
-- NAME 		: DUP0579_Updated_carparking_dataimporter.sql
-- DESCRIPTION 		: Improved performance of data importer but this trades off
--			: against recoverability.
-- AUTHOR		: Steve Craddock
--
-- Notes : This updated procedure trades off resilience for performance. Previously this
-- whole procedure was wrapped in a single transaction, however this placed a large demand
-- on the databases large transaction memory space. 
-- ************************************************

-- *****
-- ***** EXECUTE permissions below MUST be checked for each environment prior to implementation
-- *****

USE TransientPortal
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportCarParkingData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ImportCarParkingData]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- Create new stored procedure
CREATE PROCEDURE dbo.ImportCarParkingData (@XML text) AS

	SET NOCOUNT ON
	SET XACT_ABORT ON

	-- Start Transaction

	DECLARE @DocID int
	DECLARE @XMLPathData varchar(50)

	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/'

BEGIN TRANSACTION T1
		DELETE FROM [dbo].[CarParking] 
		DELETE FROM [dbo].[CarParkingAdditionalData] 
		DELETE FROM [dbo].[CarParkingOperator] 
		DELETE FROM [dbo].[CarParkingTrafficNewsRegion]
		DELETE FROM [dbo].[CarParkingAccessPoints]
		DELETE FROM [dbo].[CarParkingNPTGAdminDistrict]
		DELETE FROM [dbo].[CarParkingParkAndRideScheme]
		DELETE FROM [dbo].[CarParkingLinkedNaPTANS] 
		DELETE FROM [dbo].[CarParkingCarParkType] 
		DELETE FROM [dbo].[CarParkingNPTGLocality]
		DELETE FROM [dbo].[CarParkingPaymentType] 
		DELETE FROM [dbo].[CarParkingPaymentMethods] 
		DELETE FROM [dbo].[CarParkingOpeningTimes]
		DELETE FROM [dbo].[CarParkingFacilities] 
		DELETE FROM [dbo].[CarParkingAttractions] 
		DELETE FROM [dbo].[CarParkingFacilitiesType] 
		DELETE FROM [dbo].[CarParkingAttractionType]
		DELETE FROM [dbo].[CarParkingCarParkChargeType] 
		DELETE FROM [dbo].[CarParkingSpaceAvailability] 
		DELETE FROM [dbo].[CarParkingCarParkCharges] 
		DELETE FROM [dbo].[CarParkingCarParkConcessions] 	
		DELETE FROM [dbo].[CarParkingCalendar]
		DELETE FROM [dbo].[CarParkingCarParkSpace] 
		DELETE FROM [dbo].[CarParkingSpaceType]
COMMIT TRANSACTION T1
		----------------------------------------------------
		-- Reference Data Tables
		----------------------------------------------------

BEGIN TRANSACTION T2
		-- Car Park Access Points
		INSERT INTO CarParkingAccessPoints (GeocodeType, Easting, Northing, StreetName, BarrierInOperation)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/AccessPoints', 2)
		WITH
		(
			GeocodeType varchar(10),
			Easting varchar(7),
			Northing varchar(7),
			StreetName varchar(100),
			BarrierInOperation varchar(3)
		)
		 	


		-- Car Park Operator
		INSERT INTO CarParkingOperator (OperatorCode, OperatorName, OperatorURL, OperatorTsAndCs, OperatorEmail)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/CarParkOperator', 2)
		WITH
		(
			OperatorCode varchar(50),
			OperatorName varchar(100),
			OperatorURL varchar(2048),
			OperatorTsAndCs varchar(2048),
			OperatorEmail varchar(100)
		)


		-- Traffic News Region
		INSERT INTO CarParkingTrafficNewsRegion (RegionName)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/TrafficNewsRegion', 2)
		WITH
		(
			RegionName varchar (100)
		)	


		-- Car Park Attraction Type
		INSERT INTO CarParkingAttractionType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/Attractions', 2)
		WITH	
		(
			AttractionTypeCode int,
			AttractionTypeDescription varchar(50)
		)

		-- Car Park Facilties Type
		INSERT INTO CarParkingFacilitiesType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/Facilities', 2)
		WITH
		(
			FacilityTypeCode varchar(100),
			FacilityTypeDescription varchar(100)
		)

		-- Car Park Type
		INSERT INTO CarParkingCarParkType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkType', 2)
		WITH
		(
			TypeCode varchar(50),
			TypeDescription varchar(100)
		)

		-- Park and Ride Scheme
		INSERT INTO CarParkingParkAndRideScheme (Location, SchemeUrl, Comments, LocationEasting, LocationNorthing, TransferFrequency, TransferFrom, TransferTo)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/ParkAndRideScheme' ,2)
		WITH
		(
			Location varchar(100),
			SchemeURL varchar(2048),
			Comments varchar(200),
			LocationEasting varchar(7),
			LocationNorthing varchar(7),
			TransferFrequency varchar(100),
			TransferFrom varchar(250),
			TransferTo varchar(250)
		)

		-- NPTG Admin District
		INSERT INTO CarParkingNPTGAdminDistrict (AdminAreaCode, DistrictCode)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/NPTGAdminDistrict' ,2)
		WITH
		(
			AdminAreaCode varchar(50),
			DistrictCode varchar(50)
		)

COMMIT TRANSACTION T2

BEGIN TRANSACTION T3
		-- Car Parking Table
		INSERT INTO CarParking (
			Reference,
			OperatorId,
			AccessPointsMapId,
			AccessPointsEntranceId,
			AccessPointsExitId,			
			TrafficNewsRegionId,
			ParkAndRideSchemeId,
			NPTGAdminDistrictId,
			Name,
			Location,
			Address,
			Postcode,
			Notes,
			Telephone,
			Url,
			MinCost,
			ParkAndRide,
			StayType,
			PlanningPoint,
			DateRecordLastUpdated,
			WEUDate,
			WEFDate)
		SELECT  X.CarParkRef,
			(SELECT top 1 Id FROM CarParkingOperator WHERE operatorcode = x.operatorcode) AS OperatorId,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing = x.mapaccesspointnorthing AND easting = x.mapaccesspointeasting and geocodetype = 'Map') AS AccessPointsMapId,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing = x.entranceaccesspointnorthing AND easting = x.entranceaccesspointeasting and geocodetype = 'Entrance') AS AccessPointsEntranceId,
			(SELECT top 1 Id FROM CarParkingAccessPoints WHERE northing = x.exitaccesspointnorthing AND easting = x.exitaccesspointeasting and geocodetype = 'Exit') AS AccessPointsExitId,
			(SELECT top 1 Id FROM CarParkingTrafficNewsRegion WHERE regionname = x.trafficnewsregionname) AS RegionId,
			(SELECT top 1 Id FROM CarParkingParkAndRideScheme WHERE location = x.ParkAndRideLocation) AS ParkAndRideId,
			(SELECT top 1 Id FROM CarParkingNPTGAdminDistrict WHERE adminareacode = x.nptgareacode) as NPTGAdminDistrictId,
			X.CarParkName,
			X.Location,
			X.Address,
			X.PostCode,
			X.Notes,
			X.Telephone,
			X.Url,
			X.MinCostPence,
			X.IsParkAndRide,
			X.StayType,
			X.PlanningPoint,
			X.DateRecordLastUpdated,
			X.WEUDate,
			X.WEFDate	
		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark', 2)
		WITH (	
			CarParkRef varchar(50),
			CarParkName varchar(50),
			Location varchar(50),
			Address varchar(100),
			Postcode varchar(8),
			Notes varchar(250), 
			Telephone varchar(11),
			URL varchar(2048),	
			MinCostPence int,
			IsParkAndRide char(5),
			StayType varchar(20),
			PlanningPoint char(5),
			DateRecordLastUpdated datetime,
			WEUDate datetime,
			WEFDate datetime,
			OperatorCode varchar(100) 'CarParkOperator/OperatorCode',
			EntranceGeoCodeType varchar(10) 'AccessPoints[GeocodeType="Entrance"]/GeocodeType', 
			EntranceAccessPointNorthing varchar(7) 'AccessPoints[GeocodeType="Entrance"]/Northing', 
			EntranceAccessPointEasting varchar(7) 'AccessPoints[GeocodeType="Entrance"]/Easting', 
			MapGeoCodeType varchar(10) 'AccessPoints[GeocodeType="Map"]/GeocodeType', 
			MapAccessPointNorthing varchar(7) 'AccessPoints[GeocodeType="Map"]/Northing', 
			MapAccessPointEasting varchar(7) 'AccessPoints[GeocodeType="Map"]/Easting', 
			ExitGeoCodeType varchar(10) 'AccessPoints[GeocodeType="Exit"]/GeocodeType', 
			ExitAccessPointNorthing varchar(7) 'AccessPoints[GeocodeType="Exit"]/Northing', 
			ExitAccessPointEasting varchar(7) 'AccessPoints[GeocodeType="Exit"]/Easting', 
			TrafficNewsRegionName varchar(100) 'TrafficNewsRegion/RegionName',
			ParkAndRideLocation varchar(100) 'ParkAndRideScheme/Location',
			NPTGAreaCode varchar(5) 'NPTGAdminDistrict/AdminAreaCode'
			) X
COMMIT TRANSACTION T3

BEGIN TRANSACTION T4
		-- Car Park Calendar Elements
		INSERT INTO CarParkingCalendar (
			Start,
			[End],
			Days,
			PublicHols)
		SELECT  X.CalendarStartDate,
			X.CalendarEndDate,
			X.Days,
			X.PublicHolidays
		FROM	
		OPENXML (@docId, '//Calendar', 2)
		WITH (	
			CalendarStartDate datetime,
			CalendarEndDate datetime,
			Days varchar(7),
			PublicHolidays varchar(8)
			) X

		-- Linked NaPTANs
		INSERT INTO CarParkingLinkedNaPTANs (
			StopPointType,
			StopCode,
			InterchangeTime,
			InterchangeMode)
		SELECT  X.StopPointType,
			X.StopCode,
			X.InterchangeTime,
			X.InterchangeMode
 		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark/CarParkAdditionalData/LinkedNaPTANs', 2)
		WITH (	
			StopPointType varchar(50),
			StopCode varchar(20),
			InterchangeTime int,
			InterchangeMode varchar(100)
			) X 

		--COMMIT TRANSACTION 

COMMIT TRANSACTION T4
		-- release temp storage object
		EXEC sp_xml_removedocument @DocID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ImportCarParkingData]  TO [ASPUSER]
GO
GRANT  EXECUTE  ON [dbo].[ImportCarParkingData]  TO [-service-tng]
GO




------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 579
SET @ScriptDesc = 'Updated carparking data importer'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------