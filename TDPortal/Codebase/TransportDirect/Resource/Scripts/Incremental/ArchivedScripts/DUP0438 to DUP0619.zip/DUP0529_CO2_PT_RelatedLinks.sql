-- *************************************************************************************
-- NAME 		: DUP0529_CO2_PT_RelatedLinks.sql
-- DESCRIPTION 		: Related links for CO2 PT added to External Links table
-- Added by		: Mitesh Modi
-- Date 		: 09 Mar 2007
-- *************************************************************************************

USE [TransientPortal]
GO


------------------------
-- Related Links
------------------------

IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.PT.AirPollutants')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.PT.AirPollutants'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.PT.AirPollutants', 'http://www.naei.org.uk/index.php', 'http://www.naei.org.uk/index.php', '1', 'Emissions of Air Pollutants in the UK', NULL, NULL, NULL)

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 529
SET @ScriptDesc = 'Added Journey Emission for PT Related links to External Links table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO