-- *************************************************************************************
-- NAME 		: DUP0465_RemoveDisabledChildDiscountCard.sql
-- DESCRIPTION 		: Removes the Disabled Child Discount Card from
--                        the rail discount cards
-- *************************************************************************************


USE [PermanentPortal]
go

UPDATE DiscountCards SET SortOrder = SortOrder - 1
WHERE SortOrder > (SELECT SortOrder FROM DiscountCards WHERE ItemValue = 'DIC')
AND Mode = 'Rail'

DELETE FROM DiscountCards WHERE ItemValue = 'DIC'
go


----------------
-- Change Log --
----------------
use PermanentPortal
go

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 465)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Remove Disabled Child DiscountCard'
    WHERE ScriptNumber = 465
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (465, getDate(), 'Remove Disabled Child Discount Card' )
  END
GO