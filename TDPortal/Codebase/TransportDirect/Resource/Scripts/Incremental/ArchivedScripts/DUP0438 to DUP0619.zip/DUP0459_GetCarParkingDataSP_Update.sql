-- ************************************************************
-- NAME 	: DUP0459_GetCarParkingData_SP_Update.sql
-- DESCRIPTION 	: Deletes previous stored procedures to obtain
--		  car parking data and creates new parameterised
--		  SP
-- ************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0459_GetCarParkingDataSP_Update.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:57:56   mmodi
--Initial revision.
--
--   Rev 1.0   Nov 08 2007 12:41:20   mturner
--Initial revision.
--
--   Rev 1.0   Sep 08 2006 14:30:50   esevern
--Initial revision.
--Resolution for 4143: CCN319 Car Parking Phase 1 and 2
--



USE TransientPortal

-- Check for existance of the procedure and if it exists drop it.

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TransientPortal' 
              AND ROUTINE_NAME = 'GetCarParkingData' )
BEGIN
    DROP PROCEDURE GetCarParkingData
END

GO

-- create new SP

CREATE PROCEDURE dbo.GetCarParkingData
 @CarParkKey varchar(50)
AS
	BEGIN
    SELECT 
	CarParking.Reference,
	CarParking.OperatorId,
	CarParking.AccessPointsMapId,
	CarParking.AccessPointsEntranceId,
	CarParking.AccessPointsExitId,
	CarParking.TrafficNewsRegionId, 
	CarParking.ParkAndRideSchemeId,
	CarParking.NPTGAdminDistrictId,
	CarParking.Name,
	CarParking.Location,
	CarParking.Address,
	CarParking.Postcode,
	CarParking.Notes,
	CarParking.Telephone,
	CarParking.Url,
	CarParking.MinCost,
	CarParking.ParkAndRide,
	CarParking.StayType,
	CarParking.PlanningPoint,
	CarParking.DateRecordLastUpdated,
	CarParking.WEUDate,
	CarParking.WEFDate

FROM
	CarParking 
WHERE
	CarParking.Reference = @CarParkKey
END
GO



-- update change catalogue
USE PermanentPortal
GO

BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		459,
		getDate(),
		'Dropped and re-created stored procedure to get Car Parking data - includes reference parameter'
	)
END
GO