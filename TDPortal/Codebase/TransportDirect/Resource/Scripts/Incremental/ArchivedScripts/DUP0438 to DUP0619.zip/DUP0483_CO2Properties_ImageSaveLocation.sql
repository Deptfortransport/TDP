-- *************************************************************************************
-- NAME 		: DUP0483_CO2Properties_ImageSaveLocation.sql
-- DESCRIPTION 		: Adds the location where the Speedo Dial image is temporarily saved to
--
-- *************************************************************************************

------------------------
-- Properties Table
------------------------

USE [PermanentPortal]
GO


IF EXISTS (SELECT * FROM Properties WHERE pName = 'JourneyEmissions.SpeedoDialReferralURL')
  BEGIN
    DELETE FROM Properties WHERE pName = 'JourneyEmissions.SpeedoDialReferralURL' AND AID='Web'
  END

 INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
 VALUES ('JourneyEmissions.SpeedoDialReferralURL', 'http://fs/Maps/', 'Web', 'UserPortal', 0)

GO

IF EXISTS (SELECT * FROM Properties WHERE pName = 'JourneyEmissions.SpeedoDialImageSaveLocation')
  BEGIN
    DELETE FROM Properties WHERE pName = 'JourneyEmissions.SpeedoDialImageSaveLocation' AND AID='Web'
  END

 INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
 VALUES ('JourneyEmissions.SpeedoDialImageSaveLocation', '\\fs\Maps\', 'Web', 'UserPortal', 0)

GO


------------------------
-- Change Log 
------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 483)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Journey Emissions Speedo Dial save locations added'
    WHERE ScriptNumber = 483
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (483, getDate(), 'Journey Emissions Speedo Dial save locations added')
  END
GO