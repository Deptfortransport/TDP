-- *************************************************************************************
-- NAME 		: DUP0527_CO2_PT_EmissionsFactorsData_Update.sql
-- DESCRIPTION 		: Updates the transport modes emission factors to the JourneyEmissionsFactor
-- *************************************************************************************


USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Insert factors
----------------------------------------------------------------
IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirDefault', '0185')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirSmall')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirSmall'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirSmall', '0014')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirMedium')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirMedium'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirMedium', '0185')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirLarge')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirLarge'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirLarge', '0185')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'BusDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'BusDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('BusDefault', '0095')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'CoachDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'CoachDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('CoachDefault', '0095')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'RailDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'RailDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('RailDefault', '0040')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'FerryDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'FerryDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('FerryDefault', '0000')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailDefault', '0065')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDL')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDL'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailDL', '0083')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailCR')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailCR'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailCR', '0069')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailMA')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailMA'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailMA', '0043')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailTW')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailTW'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailTW', '0124')

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 527
SET @ScriptDesc = 'Updated emission factors for transport modes data values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO