-- *************************************************************************************
-- NAME 		: DUP0553_CO2_PT_RailEmissionsFactor_Update.sql
-- DESCRIPTION 		: Updates the Rail emission factor in JourneyEmissionsFactor
-- *************************************************************************************


USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Update Emission Factors
----------------------------------------------------------------

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'RailDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'RailDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('RailDefault', '0602')

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 553
SET @ScriptDesc = 'Updated Rail emission factor'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO