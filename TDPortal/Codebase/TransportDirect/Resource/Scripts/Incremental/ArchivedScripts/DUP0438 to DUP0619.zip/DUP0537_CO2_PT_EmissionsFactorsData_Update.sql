-- *************************************************************************************
-- NAME 		: DUP0537_CO2_PT_EmissionsFactorsData_Update.sql
-- DESCRIPTION 		: Updates the transport modes emission factors to the JourneyEmissionsFactor
-- *************************************************************************************


USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Update Emission Factors
----------------------------------------------------------------
IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirDefault', '1580')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirSmall')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirSmall'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirSmall', '1580')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirMedium')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirMedium'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirMedium', '1580')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirLarge')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'AirLarge'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('AirLarge', '1580')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'BusDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'BusDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('BusDefault', '0891')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'CoachDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'CoachDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('CoachDefault', '0891')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'FerryDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'FerryDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('FerryDefault', '1250')

GO


IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailDefault', '0650')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDL')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailDL'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailDL', '0830')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailCR')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailCR'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailCR', '0690')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailLU')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailLU'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailLU', '0526')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailMA')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailMA'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailMA', '0430')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailTW')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'LightRailTW'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('LightRailTW', '1320')

GO

IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'RailDefault')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'RailDefault'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('RailDefault', '0613')

GO

----------------------------------------------------------------
-- Update Properties
----------------------------------------------------------------
USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.AirDistanceFactor')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.AirDistanceFactor'
  END

INSERT INTO [properties] ([pName], [pValue], [AID], [GID], [PartnerId])
VALUES ('JourneyEmissions.AirDistanceFactor', '1.09', 'Web', 'UserPortal', '0')

GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.BusDistanceFactor')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.BusDistanceFactor'
  END

INSERT INTO [properties] ([pName], [pValue], [AID], [GID], [PartnerId])
VALUES ('JourneyEmissions.BusDistanceFactor', '1.25', 'Web', 'UserPortal', '0')

GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.CongestionAndUrbanDrivingFactor')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.CongestionAndUrbanDrivingFactor'
  END

INSERT INTO [properties] ([pName], [pValue], [AID], [GID], [PartnerId])
VALUES ('JourneyEmissions.CongestionAndUrbanDrivingFactor', '1.03', 'Web', 'UserPortal', '0')

GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Small')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Small'
  END

INSERT INTO [properties] ([pName], [pValue], [AID], [GID], [PartnerId])
VALUES ('JourneyEmissions.Distance.Air.Small', '71', 'Web', 'UserPortal', '0')

GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Medium')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Medium'
  END

INSERT INTO [properties] ([pName], [pValue], [AID], [GID], [PartnerId])
VALUES ('JourneyEmissions.Distance.Air.Medium', '480', 'Web', 'UserPortal', '0')

GO


IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.EmissionBar.MaxWidth')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.EmissionBar.MaxWidth'
  END

INSERT INTO [properties] ([pName], [pValue], [AID], [GID], [PartnerId])
VALUES ('JourneyEmissions.EmissionBar.MaxWidth', '178', 'Web', 'UserPortal', '0')

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 537
SET @ScriptDesc = 'Updated emission factors for transport modes data values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO