-- ***********************************************
-- NAME 		: DUP0513_CO2_PT_Setup.sql
-- DESCRIPTION 		: sql to setup CO2 emissions for Public Transport
-- 				- Journey emissions compare page link in left hand navigation menu,
--				- visibility switch (set to true)
--				- journey distance properties
-- ************************************************

----------------------------------------
-- SET UP DATA FOR EXPANDABLE MENU LINK
----------------------------------------
USE [TransientPortal]
GO

DECLARE @ResourceNameID INT,
	@ResourceID INT,
	@InternalLinkID INT, 
	@SuggestionLinkID INT

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = 'JourneyEmissionsCompare') 
INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
SELECT @ResourceNameID , 'JourneyEmissionsCompare'

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = 'Check Journey CO2'))
INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
SELECT @ResourceID, @ResourceNameID, 'en-GB', 'Journey Emissions Compare'

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = 'cy Check Journey CO2'))
INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', 'cy Journey Emissions Compare'

--insert into InternalLink table
IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = 'Journey Emissions Compare Page')
INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
SELECT @InternalLinkID , 'JourneyPlanning/JourneyEmissionsCompare.aspx', 'Journey Emissions Compare Page'


--insert into SuggestionLink table - Used for expandable menu link below
IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = 6) AND ([Priority] = 47))
INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], 
[ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
SELECT @SuggestionLinkID, 6, 47, @ResourceNameID, @InternalLinkID, 'Internal', 0

GO


----------------------------------------
-- INSERT AN EXPANDABLE MENU LINK
----------------------------------------

DECLARE @ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT

SET @ResourceNameID = (SELECT ResourceNameId FROM dbo.ResourceName WHERE ResourceName = 'JourneyEmissionsCompare')
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM dbo.SuggestionLink 
				WHERE LinkCategoryId = 6
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from dbo.ContextSuggestionLink) + 1


--insert into ContextSuggestionLink table
IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = 3))
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
SELECT @ContextSuggestionLinkId, 3, @SuggestionLinkID  -- EXPANDABLE MENU LINK

GO


----------------------------------------
-- INSERT VISIBILITY SWITCH
----------------------------------------

-- DESCRIPTION : Value of property will be checked in pages using/showing CO2 Emissions 
-- 		 for Public Transport to determine whether or not to display the functionality

USE [PermanentPortal]
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.PTAvailable')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.PTAvailable', 'True', 'Web', 'UserPortal', 0)
GO

----------------------------------------
-- INSERT PROPERTIES
----------------------------------------

USE [PermanentPortal]
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxDistance')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MaxDistance', '2000', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MinDistance')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MinDistance', '1', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxDistance.Air')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MaxDistance.Air', '2000', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MinDistance.Air')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MinDistance.Air', '150', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.EmissionBar.MaxWidth')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.EmissionBar.MaxWidth', '180', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxNumberOfCarPassengers')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MaxNumberOfCarPassengers', '8', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.AirDistanceFactor')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.AirDistanceFactor', '1.15', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.CongestionAndUrbanDrivingFactor')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.CongestionAndUrbanDrivingFactor', '1.15', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.BusDistanceFactor')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.BusDistanceFactor', '1.25', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.CarSize.Medium')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.CarSize.Medium', 'medium', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.FuelType.Petrol')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.FuelType.Petrol', 'petrol', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.FuelType.Diesel')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.FuelType.Diesel', 'diesel', 'Web', 'UserPortal', 0)
GO

----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 513
SET @ScriptDesc = 'sql to setup CO2 emissions for public transport'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO