-- *************************************************************************************
-- NAME 		: DUP0480_UpdateSetHomePageMessagesStoredProcedure.sql
-- DESCRIPTION 		: Updates the stored procedure that updates the home page CMS
--                        text.
-- *************************************************************************************

USE [PermanentPortal]
GO

ALTER  PROCEDURE usp_SetHomePageMessage AS


declare @messageEN VARCHAR(8000)
declare @messageCY VARCHAR(8000)
declare @messageFR VARCHAR(8000)
declare @loopcounter int 

-- check if any new items need to be displayed (and raise the reqd changed flag)
-- add new messages
update dbo.HomePageMessage 
	set Display = 1, Changed = 1 
	where DisplayFrom <= getdate() and 	-- check display from has been passed 
		DisplayUntil >= getdate() and 	-- check display until has not exceeded
		Display = 0			-- check is not already being displayed

-- remove old messages
update dbo.HomePageMessage 
	set Display = 0, Changed = 1 
	where DisplayUntil <= getdate() and	-- check that display until has been passed
		Display = 1			-- check that item is already being displayed

-- ok lets see if any changed flags have raised....

if (select count(*) from dbo.HomePageMessage where Changed = 1) > 0
begin 

	-- print 'Changed item detected'

	-- Begin CR Del 8 change
	-- now need to establish if any items except header and footer are set to display
	
	if (SELECT count(*) FROM dbo.HomePageMessage WHERE Display = 1 AND Description NOT IN ('Header','Footer')) >0
		begin
			UPDATE dbo.HomePageMessage
				SET Display =1, Changed = 1, DisplayFrom = NULL, DisplayUntil = NULL
				WHERE Description IN ('Header','Footer')
		end
	else
		begin
			
			UPDATE dbo.HomePageMessage
				SET Display = 0, Changed = 1, DisplayFrom = NULL, DisplayUntil = NULL
				WHERE Description IN ('Header','Footer')
		end

	-- end CR Del 8 Change

	-- ok lets build the message string up

	set @messageEN = '' 
	set @messageCY = ''
	set @messageFR = ''
	set @loopcounter = 0

	while @loopcounter <= (select max(seqno) from dbo.HomePageMessage)
	Begin
		
		-- get English message text
		select @messageEN = @messageEN + valueEN from dbo.HomePageMessage  where display = 1 and seqno = @loopcounter 
		-- get Welsh message text
		select @messageCY = @messageCY + valueCY from dbo.HomePageMessage  where display = 1 and seqno = @loopcounter 
		-- get French message text
		select @messageFR = @messageFR + valueFR from dbo.HomePageMessage  where display = 1 and seqno = @loopcounter 
		
		select @loopcounter = @loopcounter + 1 

		-- check message length has not exceed maximum permitted
		if len(@messageEN) >= 7300
		Begin	
			raiserror ('Message Exceeded Maximum Length (English)', 16,1) with LOG
			Return 1
		End
		
		if len(@messageCY) >= 7300
		Begin	
			raiserror ('Message Exceeded Maximum Length (Welsh)', 16,1) with LOG
			Return 1
		End

		if len(@messageFR) >= 7300
		Begin	
			raiserror ('Message Exceeded Maximum Length (French)', 16,1) with LOG
			Return 1
		End

	End
	
	-- we need to write the message to the CMS entries table
	-- Print @message

	-- EN 'Home' postings on transportdirect/en channel 
	IF EXISTS (select * from [TransientPortal].[dbo].[CmsTextEntries] where Channel ='/Channels/TransportDirect/en' and Posting ='Home' and PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
  		BEGIN
			Update [TransientPortal].[dbo].[CmsTextEntries]	
			set Text = @messageEN
			where (Channel ='/Channels/TransportDirect/en' and
				Posting ='Home' and
				PlaceHolder ='TDInformationHtmlPlaceholderDefinition')
		END
	ELSE
		BEGIN
			INSERT INTO [TransientPortal].[dbo].[CmsTextEntries] 
			VALUES ('/Channels/TransportDirect/en', 'Home', 'TDInformationHtmlPlaceholderDefinition', @messageEN)
		END
		


	-- CY 'Home' postings on transportdirect/en channel 
	IF EXISTS (select * from [TransientPortal].[dbo].[CmsTextEntries] where Channel ='/Channels/TransportDirect/cy' and Posting ='Home' and PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
		BEGIN			
			Update [TransientPortal].[dbo].[CmsTextEntries]	
			set Text = @messageCY
			where (Channel ='/Channels/TransportDirect/cy' and
				Posting ='Home' and
				PlaceHolder ='TDInformationHtmlPlaceholderDefinition')
		END
	ELSE
		BEGIN
			INSERT INTO [TransientPortal].[dbo].[CmsTextEntries]
			VALUES ('/Channels/TransportDirect/cy', 'Home', 'TDInformationHtmlPlaceholderDefinition', @messageCY)	
		END


	-- NOTE: The FindTrain[Cost]Input postings will not have a row created if one does not
	-- exist. This is the job of script DUP0479 to create these rows and not this procedure.

	-- EN 'FindTrain' posting on transportdirect/en/journeyplanning channel
	IF EXISTS (SELECT * FROM [TransientPortal].[dbo].[CmsTextEntries] WHERE Channel = '/Channels/TransportDirect/en/JourneyPlanning' AND Posting LIKE '%FindTrain%' AND PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
		BEGIN
			Update [TransientPortal].[dbo].[CmsTextEntries]
			set [text] = @messageEN
			where (Channel = '/Channels/TransportDirect/en/JourneyPlanning' AND
                               Posting LIKE '%FindTrain%' AND
                               PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
		END


	-- CY 'FindTrain' posting on transportdirect/en/journeyplanning channel
	IF EXISTS (SELECT * FROM [TransientPortal].[dbo].[CmsTextEntries] WHERE Channel = '/Channels/TransportDirect/en/JourneyPlanning' AND Posting LIKE '%FindTrain%' AND PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
		BEGIN	
			Update [TransientPortal].[dbo].[CmsTextEntries]
			set [text] = @messageCY
			where (Channel = '/Channels/TransportDirect/cy/JourneyPlanning' AND
                               Posting LIKE '%FindTrain%' AND
                               PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
		END


	-- built messages up now lets remove the changed flags
	update dbo.HomePageMessage 
		set Changed = 0

	-- raise windows event to get TNG to run the CMS update entries job on the webserver.
	begin
		raiserror ('CMS UPDATE REQUIRED', 16,1) with LOG
	end

End

GO

-- Change Catalogue

USE [PermanentPortal]

DELETE ChangeCatalogue WHERE ScriptNumber = 480
INSERT INTO ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
VALUES (480, GETDATE(), 'UpdateSetHomePageMessageStoredProcedure')

GO
