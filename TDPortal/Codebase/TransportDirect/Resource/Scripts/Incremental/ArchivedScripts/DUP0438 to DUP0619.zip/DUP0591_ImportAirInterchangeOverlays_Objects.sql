-- ***********************************************
-- NAME 		: DUP0591_ImportAirInterchangeOverlays_Objects
-- DESCRIPTION 		: Create objects for the AirInterchangeOverlays process
--			: 
-- AUTHOR		: Steve Craddock
-- ************************************************

-- *** This script contain permissions that require updating for each environment ***


Use PermanentPortal
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AirInterchangeOverlays]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[AirInterchangeOverlays]
GO

CREATE TABLE [dbo].[AirInterchangeOverlays] (
	[ID] [int] NOT NULL ,
	[TotalTime] [int] NOT NULL ,
	[FromName] [varchar] (256) NULL ,
	[FromNodeID] [varchar] (24)  NOT NULL ,
	[FromNodeTypeID] [varchar] (12)  NOT NULL ,
	[FromGridType] [varchar] (12)  NULL ,
	[FromEasting] [int] NULL ,
	[FromNorthing] [int] NULL ,
	[FromBay] [varchar] (50)  NULL ,
	[FromOperatorCode] [varchar] (12)  NULL ,
	[FromOperatorName] [varchar] (50)  NULL ,
	[ToName] [varchar] (256)  NULL ,
	[ToNodeID] [varchar] (24)  NOT NULL ,
	[ToNodeTypeID] [varchar] (12)  NOT NULL ,
	[ToGridType] [varchar] (12)  NULL ,
	[ToEasting] [int] NULL ,
	[ToNorthing] [int] NULL ,
	[ToBay] [varchar] (50)  NULL ,
	[ToOperatorCode] [varchar] (12)  NULL ,
	[ToOperatorName] [varchar] (50)  NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AirInterchangeOverlays] WITH NOCHECK ADD 
	CONSTRAINT [PK_AirInterchangeOverlays] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] ,
	CONSTRAINT [IX_Interchange_DuplicateChecking] UNIQUE  NONCLUSTERED 
	(
		[FromNodeID],
		[FromNodeTypeID],
		[ToNodeID],
		[ToNodeTypeID]
	) WITH  FILLFACTOR = 10  ON [PRIMARY] 


GO
----------------------------------------------------------------


USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Check for existance of the procedure and if it exists drop it
----------------------------------------------------------------
IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'PermanentPortal' 
              AND ROUTINE_NAME = 'usp_ImportAirInterchangeOverlays' )
BEGIN
    DROP PROCEDURE [usp_ImportAirInterchangeOverlays]
END

GO

---------------------------------------------------------------
-- Create new SP
----------------------------------------------------------------

CREATE PROCEDURE [dbo].[usp_ImportAirInterchangeOverlays]
AS
--
-- this script is intended the create the necessary interchange records
-- to permit D2D planning to airports that don't have any other PT nodes 
-- at them ie no bus stops etc.....
--
insert into Airinterchange..Interchange
select 
	(select max([ID]) from AirInterchange..Interchange)+ 500 + AIO.[ID] [ID], -- create unique record id's
	TotalTime,
	FromName,
	FromNodeID,
	FromNodeTypeID,
	FromGridType,
	FromEasting,
	FromNorthing,
	FromBay,
	FromOperatorCode,
	FromOperatorName,
	ToName,
	ToNodeID,
	ToNodeTypeID,
	ToGridType,
	ToEasting,
	ToNorthing,
	ToBay,
	ToOperatorCode,
	ToOperatorName  
from permanentportal..AirInterchangeOverlays AIO
where AIO.fromnodeid collate Latin1_General_CI_AS not in -- remove records from the list we don't need
		(select fromnodeid from Airinterchange..Interchange) 


GO


GRANT  EXECUTE  ON [dbo].[usp_ImportAirInterchangeOverlays]  TO [-service-tng]
GO
GRANT  EXECUTE  ON [dbo].[usp_ImportAirInterchangeOverlays]  TO [ASPUSER_S]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 591
SET @ScriptDesc = 'Create objects for the AirInterchangeOverlays process'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------