-- ************************************************************
-- NAME 	: DUP0560_welsh_traval_news_region_map.sql
-- DESCRIPTION 	: Amend welsh traval news region map tile settings
--  		: ref USD 1282580  IR4476
-- ************************************************************

USE [PermanentPortal]
GO

update properties
set pvalue = '158900,163000,307100,396000'
where pname = 'Web.MappingComponent.RegionCoordinates.11' 
and AID in ('web','microsite')
and GID = 'UserPortal'

go

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 560
SET @ScriptDesc = 'Amend welsh traval news region map tile settings'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO