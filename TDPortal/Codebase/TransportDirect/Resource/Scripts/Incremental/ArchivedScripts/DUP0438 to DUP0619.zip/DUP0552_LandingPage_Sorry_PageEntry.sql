-- ***********************************************
-- NAME 		: DUP0552_LandingPage_Sorry_PageEntry.sql
-- DESCRIPTION 		: sql to setup Page entry types for SorryPage to be used by landing page
-- ************************************************

----------------------------------------
-- INSERT PAGE ENTRY
----------------------------------------
USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'SorryPage') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'SorryPage', 'Sorry page used in specific landing page scenario' FROM PageEntryType
GO

----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 552
SET @ScriptDesc = 'Added page entry types for Sorry page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO