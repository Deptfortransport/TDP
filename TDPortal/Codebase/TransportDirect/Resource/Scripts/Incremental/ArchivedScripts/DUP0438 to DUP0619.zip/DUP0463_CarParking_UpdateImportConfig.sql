-- ************************************************************
-- NAME 	: DUP0461_CarParking_InsertTables.sql
-- DESCRIPTION 	: Updates to Import Configuration
-- ************************************************************

------------------------------------------
-- Update to Import Configuration
------------------------------------------

USE PermanentPortal
GO

UPDATE import_configuration SET parameters1 = 'd:\gateway\bat\etd565_osmap_import.bat' WHERE data_feed = 'etd565'


------------------------------------------
-- Update Change Catalogue
------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 463)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Updated import configuration'
	WHERE ScriptNumber = 463
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (463, (getDate()), 'Updated import configuration')
GO