-- ************************************************************
-- NAME 	: DUP0504_Feedback_Tables.sql
-- DESCRIPTION 	: Creates the UserFeedback, UserFeedbackSessionData, and UserFeedbackClassification
--  		: used to save session information
-- ************************************************************

USE [TDUserInfo]
GO

------------------------------------------
-- Delete existing tables
------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[UserFeedback]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[UserFeedback]
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[UserFeedbackSessionData]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[UserFeedbackSessionData]
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[UserFeedbackClassification]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[UserFeedbackClassification]
GO

------------------------------------------
-- Create tables: UserFeedback, UserFeedbackSessionData, UserFeedbackClassification
------------------------------------------

CREATE TABLE [dbo].[UserFeedback] (
	[FeedbackId] [int] IDENTITY (10000, 1) NOT NULL ,
	[SessionId] [varchar] (100) NOT NULL ,
	[SessionCreated] [datetime] NULL ,
	[SessionExpires] [datetime] NULL ,
	[SubmittedTime] [datetime] NULL ,
	[AcknowledgedTime] [datetime] NULL ,
	[AcknowledgementSent] [bit] NOT NULL ,
	[UserLoggedOn] [bit] NOT NULL ,
	[TimeLogged] [datetime] NOT NULL ,
	[VantiveId] [varchar] (10) NULL ,
	[FeedbackStatus] [varchar] (50) NOT NULL ,
	[DeleteFlag] [bit] NOT NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[UserFeedbackSessionData] (
	[FeedbackId] [int] NOT NULL ,
	[SessionId] [varchar] (100) NOT NULL ,
	[KeyId] [varchar] (100) NOT NULL ,
	[SessionItemLong] [image] NULL ,
	[DeleteFlag] [bit] NOT NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[UserFeedbackClassification] (
	[FeedbackId] [int] NOT NULL ,
	[FeedbackTypeId] [varchar] (10) NOT NULL ,
	[Details] [varchar] (1000) NULL ,
	[Email] [varchar] (100) NULL ,
	[DeleteFlag] [bit] NOT NULL
) ON [PRIMARY]
GO

------------------------------------------
-- Set the Primary Key
------------------------------------------

ALTER TABLE [dbo].[UserFeedback] ADD 
	CONSTRAINT [PK_UserFeedback] PRIMARY KEY  CLUSTERED 
	(
		[FeedbackId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[UserFeedbackSessionData] ADD 
	CONSTRAINT [PK_UserFeedbackSessionData] PRIMARY KEY  CLUSTERED 
	(
		[FeedbackId],
		[SessionId],
		[KeyId]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[UserFeedbackClassification] ADD 
	CONSTRAINT [PK_UserFeedbackClassification] PRIMARY KEY  CLUSTERED 
	(
		[FeedbackId],
		[FeedbackTypeId]
	)  ON [PRIMARY] 
GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 504
SET @ScriptDesc = 'Added UserFeedback, UserFeedbackSessionData, and UserFeedbackClassification tables'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO