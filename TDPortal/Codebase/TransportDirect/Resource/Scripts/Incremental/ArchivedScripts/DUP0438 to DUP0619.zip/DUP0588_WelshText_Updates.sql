-- ***********************************************
-- NAME 		: DUP0588_WelshText_Updates.sql
-- DESCRIPTION 		: sql to update welsh text
-- ************************************************

USE [TransientPortal]
GO

-- Update Car sharing link on CO2 emissions page
EXEC UpdateSuggestionLinkDisplayText
	'JourneyEmissions.RelatedSitesCarSharing', 'How can I find information on car sharing?', 'Sut allaf i gael gafael ar wybodaeth ar rannu ceir?'

GO

------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 588
SET @ScriptDesc = 'Updated welsh text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------