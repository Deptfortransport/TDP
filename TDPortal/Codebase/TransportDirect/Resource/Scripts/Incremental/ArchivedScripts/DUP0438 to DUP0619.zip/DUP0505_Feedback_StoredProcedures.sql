-- ************************************************************
-- NAME 	: DUP0505_Feedback_StoredProcedures.sql
-- DESCRIPTION 	: Creates stored procedures to obtain
--		  User Feedback data and for requested FeedbackId
-- ************************************************************
--

USE [TDUserInfo]
GO

------------------------------------------
-- Delete existing procedures
------------------------------------------

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'AddUserFeedback' )
BEGIN
    DROP PROCEDURE [AddUserFeedback]
END
GO


IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'GetUserFeedbackId' )
BEGIN
    DROP PROCEDURE [GetUserFeedbackId]
END
GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'GetUserFeedback' )
BEGIN
    DROP PROCEDURE [GetUserFeedback]
END
GO


IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'UpdateUserFeedback' )
BEGIN
    DROP PROCEDURE [UpdateUserFeedback]
END
GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'AddFeedbackUserOptions' )
BEGIN
    DROP PROCEDURE [AddFeedbackUserOptions]
END
GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'DeleteUserFeedback' )
BEGIN
    DROP PROCEDURE [DeleteUserFeedback]
END
GO

------------------------------------------
-- Create new stored procedures
------------------------------------------

-- AddUserFeedback
CREATE PROCEDURE [dbo].[AddUserFeedback]
(
	@SessionId varchar (100) ,
	@SubmittedTime datetime ,
	@AcknowledgedTime datetime ,
	@AcknowledgementSent bit ,
	@UserLoggedOn bit ,
	@TimeLogged datetime ,
	@VantiveId varchar (10) ,
	@FeedbackStatus varchar (50) ,
	@DeleteFlag bit
)
AS
    DECLARE @localized_string_UnableToCarryOutAction AS nvarchar(256)
    SET @localized_string_UnableToCarryOutAction = 'Unable to create record for ' + CAST(@SessionId AS varchar(50)) + ' in UserFeedback table'
    
    DECLARE @SessionCreated AS datetime
    EXEC GetSessionCreatedDateTime @SessionId, @SessionCreated OUTPUT

    DECLARE @SessionExpires AS datetime
    EXEC GetSessionExpiryDateTime @SessionId, @SessionExpires OUTPUT

 	BEGIN
	
	    INSERT INTO [UserFeedback] 
		(
		[SessionId],
		[SessionCreated],
		[SessionExpires],
		[SubmittedTime],
		[AcknowledgedTime],
		[AcknowledgementSent],
		[UserLoggedOn],
		[TimeLogged],
		[VantiveId],
		[FeedbackStatus],
		[DeleteFlag]
		)
	    VALUES 
		(
		@SessionId,
		@SessionCreated,
		@SessionExpires,
		@SubmittedTime,
		@AcknowledgedTime,
		@AcknowledgementSent,
		@UserLoggedOn,
		@TimeLogged,
		@VantiveId,
		@FeedbackStatus,
		@DeleteFlag
		)
	  END

    IF @@error <> 0
    BEGIN
        raiserror (@localized_string_UnableToCarryOutAction, 1,1)
        RETURN -1
    END
    ELSE
    BEGIN
	RETURN @@rowcount
    END
GO

-- GetUserFeedbackId
CREATE PROCEDURE [dbo].[GetUserFeedbackId]
	@SessionId varchar(100)
AS
BEGIN
	SELECT 
		MAX([UserFeedback].[FeedbackId])
	FROM
		[UserFeedback]
	WHERE
		[UserFeedback].[SessionId] = @SessionId
END
GO


-- GetUserFeedback
CREATE PROCEDURE [dbo].[GetUserFeedback]
	@FeedbackId varchar(50)
AS
BEGIN
	SELECT 
		UserFeedback.FeedbackId,
		UserFeedback.SessionId,
		UserFeedback.SessionCreated, 
		UserFeedback.SessionExpires,
		UserFeedback.SubmittedTime,
		UserFeedback.AcknowledgedTime,
		UserFeedback.AcknowledgementSent,
		UserFeedback.UserLoggedOn,
		UserFeedback.TimeLogged,
		UserFeedback.VantiveId,
		UserFeedback.FeedbackStatus,
		UserFeedback.DeleteFlag
	FROM
		[UserFeedback]
	WHERE
		[UserFeedback].[FeedbackId] = @FeedbackId
END
GO


--UpdateUserFeedback
CREATE PROCEDURE [dbo].[UpdateUserFeedback]
(
	@FeedbackId int ,
	@SessionId varchar (100) ,
	@SubmittedTime datetime ,
	@AcknowledgedTime datetime ,
	@AcknowledgementSent bit ,
	@UserLoggedOn bit ,
	@TimeLogged datetime ,
	@VantiveId varchar (10) ,
	@FeedbackStatus varchar (50) ,
	@DeleteFlag bit
)
AS
    DECLARE @localized_string_UnableToCarryOutAction AS nvarchar(256)   

    IF EXISTS (SELECT * FROM [UserFeedback] WHERE [FeedbackId] = @FeedbackId AND [SessionId] = @SessionId)
	  BEGIN
	    SET @localized_string_UnableToCarryOutAction = 'Unable to update record ' + CAST(@FeedbackId AS varchar(50)) + ' in UserFeedback table'
	    UPDATE [UserFeedback]
	    SET [SubmittedTime] = @SubmittedTime,
		[AcknowledgedTime] = @AcknowledgedTime,
		[AcknowledgementSent] = @AcknowledgementSent,
		[UserLoggedOn] = @UserLoggedOn,
		[TimeLogged] = @TimeLogged,
		[VantiveId] = @VantiveId,
		[FeedbackStatus] = @FeedbackStatus,
		[DeleteFlag] = @DeleteFlag
	    WHERE [FeedbackId] = @FeedbackId AND [SessionId] = @SessionId
	  END

    IF @@error <> 0
    BEGIN
        raiserror (@localized_string_UnableToCarryOutAction, 1,1)
        RETURN -1
    END
    ELSE
    BEGIN
	RETURN @@rowcount
    END
GO


-- AddFeedbackUserOptions
CREATE PROCEDURE [dbo].[AddFeedbackUserOptions]
(
	@FeedbackId int ,
	@FeedbackTypeId varchar (10) ,
	@Details varchar (1000) ,
	@Email varchar (100) ,
	@DeleteFlag bit
)
AS
    DECLARE @localized_string_UnableToCarryOutAction AS nvarchar(256)
    SET @localized_string_UnableToCarryOutAction = 'Unable to create record for ' + CAST(@FeedbackId AS varchar(50)) + ' in UserFeedback table'

 	BEGIN
	
	    INSERT INTO [UserFeedbackClassification] 
		(
		[FeedbackId],
		[FeedbackTypeId],
		[Details],
		[Email],
		[DeleteFlag]
		)
	    VALUES 
		(
		@FeedbackId ,
		@FeedbackTypeId ,
		@Details ,
		@Email , 
		@DeleteFlag
		)
	  END

    IF @@error <> 0
    BEGIN
        raiserror (@localized_string_UnableToCarryOutAction, 1,1)
        RETURN -1
    END
    ELSE
    BEGIN
	RETURN @@rowcount
    END
GO



-- DeleteUserFeedback
CREATE PROCEDURE [dbo].[DeleteUserFeedback]
AS
    DELETE [dbo].[UserFeedbackClassification]
    WHERE DeleteFlag = 0

    DELETE [dbo].[UserFeedbackSessionData]
    WHERE DeleteFlag = 0

    DELETE [dbo].[UserFeedback]
    WHERE DeleteFlag = 0

    RETURN 0
GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 505
SET @ScriptDesc = 'Added User Feedback stored procedures: Add, Get, Update, Delete'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO