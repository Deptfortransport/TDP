-- *************************************************************************************
-- NAME 		: DUP0512_ExternalLinksUpdate.sql
-- DESCRIPTION 		: Updating 3 seoerate links in the External Links table that have
--                        become out of date (vantive 4522058)
-- Added by		: Mark Turner
-- Date 		: 11/Jan/2007
-- *************************************************************************************

USE [TransientPortal]
GO


------------------------
-- Related Links
------------------------


IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.OffsetCarbonEmissions')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.OffsetCarbonEmissions'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.OffsetCarbonEmissions', 'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm', 'http://www.defra.gov.uk/environment/climatechange/uk/carbonoffset/index.htm', '1', 'Offset Carbon Emissions', NULL, NULL, NULL)

GO

IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.Flying')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.Flying'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.Flying', 'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429', 'http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064429', '1', 'Flying', NULL, NULL, NULL)

GO

IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.FuelSavingTips')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.FuelSavingTips'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.FuelSavingTips', 'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption', 'http://www.rac.co.uk/web/knowhow/hints_tips/fuel_consumption', '1', 'Fuel Saving Tips', NULL, NULL, NULL)

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 512
SET @ScriptDesc = 'Updating 3 seperate links in External Links table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO