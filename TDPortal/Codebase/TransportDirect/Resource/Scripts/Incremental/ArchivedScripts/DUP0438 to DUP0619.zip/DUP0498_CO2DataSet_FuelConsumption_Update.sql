-- *************************************************************************************
-- NAME 		: DUP0498_CO2DataSet_FuelConsumption_Update.sql
-- DESCRIPTION 		: Updates the Journey Emissions Fuel Consumption data set
-- *************************************************************************************

USE PermanentPortal
GO

----------------------------------------------------------------
-- Creat the items in the data set
----------------------------------------------------------------
DELETE FROM DropDownLists WHERE DataSet = 'FuelConsumptionCO2SelectRadio'
GO

INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('FuelConsumptionCO2SelectRadio', 'Average for my type of car', '1', 1, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('FuelConsumptionCO2SelectRadio', 'More specifically', '2', 0, 2, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('FuelConsumptionCO2SelectRadio', 'Gramms of CO2 per km', '3', 0, 3, 0)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 498
SET @ScriptDesc = 'Updated the Journey Emissions Fuel Consumption data set'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
