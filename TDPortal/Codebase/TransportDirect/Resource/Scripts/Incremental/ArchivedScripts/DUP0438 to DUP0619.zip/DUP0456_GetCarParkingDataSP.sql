-- ************************************************************
-- NAME 	: DUP0456_GetCarParkingData_SP.sql
-- DESCRIPTION 	: Creates stored procedures to obtain
--		  car parking data
-- ************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0456_GetCarParkingDataSP.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:57:54   mmodi
--Initial revision.
--
--   Rev 1.0   Nov 08 2007 12:41:18   mturner
--Initial revision.
--
--   Rev 1.4   Aug 30 2006 11:10:48   mmodi
--Corrected parse error - missing GO statement
--Resolution for 4143: CCN319 Car Parking Phase 1 and 2
--
--   Rev 1.3   Aug 30 2006 10:40:54   esevern
--added entrance and exit ids to car park access points sp
--Resolution for 4143: CCN319 Car Parking Phase 1 and 2
--
--   Rev 1.2   Aug 29 2006 14:17:08   esevern
--added stored procedure to obtain car park access point data
--Resolution for 4143: CCN319 Car Parking Phase 1 and 2
--
--   Rev 1.1   Aug 25 2006 15:07:50   esevern
--Additional stored procedures to obtain data in other car parking tables
--Resolution for 4143: CCN319 Car Parking Phase 1 and 2
--
--   Rev 1.0   Aug 24 2006 13:07:20   esevern
--Initial revision.

-- Create get car parking stored procedure 

Use TransientPortal
GO


CREATE PROCEDURE dbo.GetCarParkingData
AS
	BEGIN
    SELECT 
	CarParking.Reference,
	CarParking.OperatorId,
	CarParking.AccessPointsMapId,
	CarParking.AccessPointsEntranceId,
	CarParking.AccessPointsExitId,
	CarParking.TrafficNewsRegionId, 
	CarParking.ParkAndRideSchemeId,
	CarParking.NPTGAdminDistrictId,
	CarParking.Name,
	CarParking.Location,
	CarParking.Address,
	CarParking.Postcode,
	CarParking.Notes,
	CarParking.Telephone,
	CarParking.Url,
	CarParking.MinCost,
	CarParking.ParkAndRide,
	CarParking.StayType,
	CarParking.PlanningPoint,
	CarParking.DateRecordLastUpdated,
	CarParking.WEUDate,
	CarParking.WEFDate

FROM
	CarParking 

	ORDER BY 
		CarParking.Location
END
GO

-- create get car parking operator sp

/*
Returns columns from the CarParkingOperator table for the supplied 
operator key.  The operator key is supplied as a parameter of type int.
*/
CREATE PROCEDURE dbo.GetCarParkOperatorData
 @OperatorKey int
AS
BEGIN
SELECT
	CarParkingOperator.Id, 
	CarParkingOperator.OperatorCode, 
	CarParkingOperator.OperatorName, 
	CarParkingOperator.OperatorURL, 
	CarParkingOperator.OperatorTsAndCs, 
	CarParkingOperator.OperatorEmail

FROM
	CarParkingOperator 

WHERE
	CarParkingOperator.Id = @OperatorKey
END
GO

-- create get car parking park and ride scheme sp
/*
Returns columns from the CarParkingParkAndRideScheme table for the supplied 
scheme key.  The scheme key is supplied as a parameter of type int.
*/
CREATE PROCEDURE dbo.GetCarParkingParkAndRideData
@SchemeKey int
AS
BEGIN
SELECT
	CarParkingParkAndRideScheme.Id, 
	CarParkingParkAndRideScheme.Location, 
	CarParkingParkAndRideScheme.SchemeURL, 
	CarParkingParkAndRideScheme.Comments, 
	CarParkingParkAndRideScheme.LocationEasting, 
	CarParkingParkAndRideScheme.LocationNorthing,
	CarParkingParkAndRideScheme.TransferFrequency, 
	CarParkingParkAndRideScheme.TransferFrom, 
	CarParkingParkAndRideScheme.TransferTo

FROM
	CarParkingParkAndRideScheme 

WHERE
	CarParkingParkAndRideScheme.Id = @SchemeKey
END
GO

-- create get traffic news region sp
/*
Returns columns from the CarParkingTrafficNewsRegion table for the supplied 
traffic news region key.  The region key is supplied as a parameter of type int.
*/
CREATE PROCEDURE dbo.GetCarParkingRegionData
    @RegionKey int
AS
BEGIN
    SELECT
            CPTNR.Id,
            CPTNR.RegionName
            
    FROM
            dbo.CarParkingTrafficNewsRegion as CPTNR

	WHERE
            CPTNR.Id = @RegionKey
END
GO

-- create get nptg admin district sp
/*
Returns columns from the CarParkingParkAndRideScheme table for the supplied 
NPTG admin district key.  The district key is supplied as a parameter of type int.
*/
CREATE PROCEDURE dbo.GetCarParkingAdminData
 @DistrictKey int

AS
BEGIN
SELECT
	CarParkingNPTGAdminDistrict.Id, 
	CarParkingNPTGAdminDistrict.AdminAreaCode,
	CarParkingNPTGAdminDistrict.DistrictCode

FROM
	CarParkingNPTGAdminDistrict 

WHERE
	CarParkingNPTGAdminDistrict.Id = @DistrictKey

END
GO

-- create car parking access points stored procedure
/*
Returns row from the CarParkingAccessPoints table for the supplied 
access point key.  The key is supplied as a parameter of type int.
*/
CREATE PROCEDURE dbo.GetCarParkAccessPointData
 @AccessKey int
AS
BEGIN
SELECT

CarParkingAccessPoints.Id,
CarParkingAccessPoints.GeocodeType,
CarParkingAccessPoints.Easting,
CarParkingAccessPoints.Northing,
CarParkingAccessPoints.StreetName,
CarParkingAccessPoints.BarrierInOperation

FROM
	CarParkingAccessPoints 

WHERE
	CarParkingAccessPoints.Id = @AccessKey
END
GO


-- update change catalogue
USE PermanentPortal
GO

BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		456,
		getDate(),
		'Created stored procedures to get Car Parking data'
	)
END
GO

