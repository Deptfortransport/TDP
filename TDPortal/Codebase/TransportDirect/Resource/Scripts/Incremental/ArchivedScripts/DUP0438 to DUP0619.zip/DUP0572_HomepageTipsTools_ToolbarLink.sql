-- ************************************************************
-- NAME 	: DUP0572_HomepageTipsTools_ToolbarLink.sql
-- DESCRIPTION 	: Tips and tools link for toolbar, could you   
--		make the entire text link. text changes 
--		(Welsh and English)
-- ************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0572_HomepageTipsTools_ToolbarLink.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:58:20   mmodi
--Initial revision.
--
--   Rev 1.0   Nov 08 2007 12:42:00   mturner
--Initial revision.
--
--   Rev 1.1   Sep 11 2007 14:48:24   nrankin
--Resolution for 4494: Home pange changes for DEL 9.7
--Slight amendment
--Resolution for 4494: Home pange changes for DEL 9.7
--
--   Rev 1.0   Sep 07 2007 12:24:56   nrankin
--Initial revision.
--Resolution for 4494: Home pange changes for DEL 9.7
--

--


USE [TransientPortal]
GO

-- Have 3 placeholders to enter text for and for each there is the english/welsh variant

-- Declare variables
DECLARE @EnglishHomepageChannel VARCHAR(100)
DECLARE @TipsTextEnglish VARCHAR(2500)

DECLARE @WelshHomepageChannel VARCHAR(100)
DECLARE @TipsTextWelsh VARCHAR(2500)

DECLARE @PostingName VARCHAR(50)
DECLARE @TipsPlaceholder VARCHAR(100)


-- Set config settings. These settings correspond to MCMS settings so must match.
SET @EnglishHomepageChannel = '/Channels/TransportDirect/en'
SET @WelshHomepageChannel = '/Channels/TransportDirect/cy'
SET @PostingName = 'Home'
SET @TipsPlaceholder = 'TDTipsHtmlPlaceholderDefinition'

SET @TipsTextEnglish = '<DIV class=Column2Header>
<H1><SPAN class=txtsevenbwl>Tips and tools</SPAN></H1>
<A class=txtsevenbwrlink href="/TransportDirect/en/Tools/Home.aspx" title="Go to Tips and tools page">More... </A>
<!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </DIV>
</DIV>
<DIV class=Column2Content2>
<TABLE class=TipsToolsTable cellSpacing=5 summary="">
<TBODY>
<TR>
<TD class=TipsToolsIconPadding><A href="/TransportDirect/en/JourneyPlanning/JourneyEmissionsCompare.aspx"><IMG title="Check journey CO2" height=30 alt="Check C02 emissions" src="/Web/images/gifs/SoftContent/en/Co2_30x30.gif" width=30></A></TD>
<TD><A href="/TransportDirect/en/JourneyPlanning/JourneyEmissionsCompare.aspx">Check C02 emissions</A></TD>
</TR>
<TR>
<TD class=TipsToolsIconPadding><A href="/TransportDirect/en/Tools/BusinessLinks.aspx"><IMG title="Business Links" height=30 alt="Business Links" src="/Web/images/gifs/SoftContent/en/WebsiteLinkB70.gif" width=30></A></TD>
<TD><A href="/TransportDirect/en/Tools/BusinessLinks.aspx">Add Transport Direct to your website for free</A></TD>
</TR>
<TR>
<TD class=TipsToolsIconPadding><A href="/TransportDirect/en/Tools/ToolbarDownload.aspx"><IMG title="Toolbar download" height=30 alt="Toolbar download" src="/Web/images/gifs/SoftContent/en/Toolbox30.gif" width=30></A></TD>
<TD><A href="/TransportDirect/en/Tools/ToolbarDownload.aspx">Speed up your travel searches with our free toolbar</A></TD>
</TR>
<TR>
<TD class=TipsToolsIconPadding><A href="/TransportDirect/en/TDOnTheMove/TDOnTheMove.aspx"><IMG title="Services available on your mobile" height=30 alt="Services available on your mobile" src="/Web/images/gifs/SoftContent/en/phone.gif" width=30></A></TD>
<TD><A href="/TransportDirect/en/TDOnTheMove/TDOnTheMove.aspx">Get live departures on your mobile</A></TD>
</TR>
<TR>
<TD class=TipsToolsIconPadding><A href="/TransportDirect/en/Tools/Home.aspx#digitvinfo"><IMG title="Digital TV" height=30 alt="Digital TV" src="/Web/images/gifs/SoftContent/en/DigiTV_30x30.gif" width=30></A></TD>
<TD><A href="/TransportDirect/en/Tools/Home.aspx#digitvinfo">Get live departures through Digital TV</A></TD>
</TR></TBODY></TABLE></DIV>'

SET @TipsTextWelsh = '<DIV class=Column2Header>
<H1><SPAN class=txtsevenbwl>Awgrymiadau a theclynnau</SPAN></H1>
<A class=txtsevenbwrlink href="/TransportDirect/cy/Tools/Home.aspx" title="Ewch i''r dudalen Awgrymiadau a thedynnau">Mwy... </A>
<!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div></div>
<DIV class=Column2Content2>
<TABLE class=TipsToolsTable cellSpacing=5 summary="">
<TBODY>
<TR>
<TD class=TipsToolsIconPadding><A href="/TransportDirect/cy/JourneyPlanning/JourneyEmissionsCompare.aspx"><IMG title="Mesur CO2 y siwrnai" height=30 alt="Mesur CO2 y siwrnai" src="/Web/images/gifs/SoftContent/cy/Co2_30x30.gif" width=30></A></TD>
<TD><A href="/TransportDirect/cy/JourneyPlanning/JourneyEmissionsCompare.aspx">Mesur CO2 y siwrnai</A></TD>
</TR>
<TR>
<TD class="TipsToolsIconPadding"><A href="/TransportDirect/cy/Tools/BusinessLinks.aspx"><IMG title="Cysylltiadau Busnes" height="30" alt="Cysylltiadau Busnes" src="/Web/images/gifs/SoftContent/en/WebsiteLinkB70.gif" width="30"></A></TD>
<TD><A href="/TransportDirect/cy/Tools/BusinessLinks.aspx">Ychwanegwch Transport Direct at eich gwefan am ddim</A></TD>
</TR>
<TR>
<TD class="TipsToolsIconPadding"><A href="/TransportDirect/cy/Tools/ToolbarDownload.aspx"><IMG title="Lawrlwythwch y Bar Offer" height="30" alt="Lawrlwythwch y Bar Offer" src="/Web/images/gifs/SoftContent/en/Toolbox30.gif" width="30"></A></TD>
<TD><A href="/TransportDirect/cy/Tools/ToolbarDownload.aspx">Cyflymwch eich chwiliadau teithio gyda''n bar offer</A> am ddim</TD>
</TR>
<TR>
<TD class="TipsToolsIconPadding"><A href="/TransportDirect/cy/TDOnTheMove/TDOnTheMove.aspx"><IMG title="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" height="30" alt="Gwasanaethau sydd ar gael ar eich ff&#244;n symudol" src="/Web/images/gifs/SoftContent/en/phone.gif" width="30"></A></TD>
<TD><A href="/TransportDirect/cy/TDOnTheMove/TDOnTheMove.aspx">Derbyniwch ymadawiadau byw ar eich ff&#244;n symudol</A></TD>
</TR>
<TR>
<TD class=TipsToolsIconPadding><A href="/TransportDirect/cy/Tools/Home.aspx#digitvinfo"><IMG title="Digital TV" height=30 alt="Digital TV" src="/Web/images/gifs/SoftContent/cy/DigiTV_30x30.gif" width=30></A></TD>
<TD><A href="/TransportDirect/cy/Tools/Home.aspx#digitvinfo">Get live departures through Digital TV</A></TD>
</TR></TBODY></TABLE></DIV>'


IF EXISTS (SELECT * FROM [dbo].[CmsTextEntries] where Channel = @EnglishHomepageChannel and Posting = @PostingName and PlaceHolder = @TipsPlaceholder)

	UPDATE [dbo].[CmsTextEntries]	
	SET  Text = @TipsTextEnglish
	WHERE Channel = @EnglishHomepageChannel and Posting = @PostingName and PlaceHolder = @TipsPlaceholder

ELSE
	INSERT INTO CmsTextEntries VALUES (@EnglishHomepageChannel, @PostingName, @TipsPlaceholder, @TipsTextEnglish)


IF EXISTS (SELECT * FROM [dbo].[CmsTextEntries] where Channel = @WelshHomepageChannel and Posting = @PostingName and PlaceHolder = @TipsPlaceholder)

	UPDATE [dbo].[CmsTextEntries]	
	SET  Text = @TipsTextWelsh
	WHERE Channel = @WelshHomepageChannel and Posting = @PostingName and PlaceHolder = @TipsPlaceholder

ELSE
	INSERT INTO CmsTextEntries VALUES (@WelshHomepageChannel, @PostingName, @TipsPlaceholder, @TipsTextWelsh)


GO



----------------------------------
-- Update the ChangeCatalogue
----------------------------------
use PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 572)
BEGIN
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = getDate(),
		Summary = 'Tips and tools link for toolbar, could you make the entire text link.'
	WHERE ScriptNumber = 572
END
ELSE
BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		572,
		getDate(),
		'Tips and tools link for toolbar, could you make the entire text link.'
	)
END

GO