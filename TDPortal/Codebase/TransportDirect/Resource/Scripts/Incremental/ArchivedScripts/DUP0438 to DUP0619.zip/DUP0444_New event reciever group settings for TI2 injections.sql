-- ***********************************************
-- AUTHOR      	: John Frank
-- NAME 	: DUP0444_New event receiver group settings for TI2 injections.sql
-- DESCRIPTION 	: Sets up Event receiver group for consuming the MSMQ on TI2
-- Additional Steps Required : Run on ACP ONLY
-- ************************************************

USE PermanentPortal
GO

IF NOT EXISTS (SELECT * FROM Properties WHERE pName = 'Receiver.Queue.SourceQueueInj2.Path' AND AID = 'EventReceiverGroup' AND GID = 'ReportDataProvider' AND PartnerId = 0)
BEGIN

  INSERT INTO Properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('Receiver.Queue.SourceQueueInj2.Path', 'FormatName:DIRECT=OS:Injbox2\Private$\TDPrimaryQueue', 'EventReceiverGroup', 'ReportDataProvider', 0)

END


IF NOT EXISTS (SELECT * FROM Properties WHERE pName = 'Receiver.Queue'AND pValue LIKE '%SourceQueueInj2%' AND AID = 'EventReceiverGroup' AND GID = 'ReportDataProvider' AND PartnerId = 0)
BEGIN

  UPDATE Properties SET pValue = pValue + ' SourceQueueInj2'
  WHERE pName = 'Receiver.Queue' AND AID = 'EventReceiverGroup' AND GID = 'ReportDataProvider' AND PartnerId = 0

END

GO

----------------------------------
-- Update the ChangeCatalogue
----------------------------------
use PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 444)
BEGIN
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = getDate(),
		Summary = 'Updates EventReceiverGroup properties for TI2'
	WHERE ScriptNumber = 444
END
ELSE
BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		444,
		getDate(),
		'Updates EventReceiverGroup properties for TI2'
	)
END

GO