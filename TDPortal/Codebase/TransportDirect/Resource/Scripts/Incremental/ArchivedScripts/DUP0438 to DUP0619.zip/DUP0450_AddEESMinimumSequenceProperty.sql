-- *************************************************************************************
-- NAME 			: DUP0450_AddEESMinimumSequenceProperty.sql
-- DESCRIPTION 		: Add a minimum value for Sequence parameter passed to CJP by EES JP
-- *************************************************************************************

USE [PermanentPortal]
go

-- Remove old db entries

DELETE FROM properties WHERE pname = 'JourneyPlannerService.MinimumSequence'
go


insert into [dbo].[properties] (pName, pValue, aid, gid ) 
values ('JourneyPlannerService.MinimumSequence', '2', 'TDRemotingHost', '')
go


----------------
-- Change Log --
----------------
use PermanentPortal
go

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 450)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Add minimum value for EES sequence parameter'
    WHERE ScriptNumber = 450
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (450, getDate(), 'Add minimum value for EES sequence parameter' )
  END
GO