-- ************************************************************
-- NAME 	: DUP0521_CO2_PT_SwitchON.sql
-- DESCRIPTION 	: Turns CO2 Emissions for Public Transport functionality on
--
-- IMPORTANT    : THIS SCRIPT REQUIRES A DEPLOYMENT DECISION
--		:
-- 		: If CO2 Emissions for Public Transport is to be 
--		: switched ON, uncomment all the sql code and run.
--		:
--		: To make uncommenting easier, do a global replace 
--		: for:  
-- ************************************************************

------------------------------------------
-- SET CAR PARK SWITCH TO TRUE
------------------------------------------

USE [PermanentPortal]

UPDATE [properties]
SET pValue = 'True'
WHERE pName = 'JourneyEmissions.PTAvailable'
GO


------------------------------------------
-- INSERT AN EXPANDABLE MENU LINK
------------------------------------------

USE TransientPortal
GO

DECLARE @ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT

SET @ResourceNameID = (SELECT [ResourceNameId] FROM [dbo].[ResourceName] WHERE [ResourceName] = 'JourneyEmissionsCompare')
SET @SuggestionLinkID = (SELECT [SuggestionLinkID] FROM [dbo].[SuggestionLink] 
				WHERE [LinkCategoryId] = 6
				AND [ResourceNameID] = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX([ContextSuggestionLinkId]) from [dbo].[ContextSuggestionLink]) + 1


--insert into ContextSuggestionLink table
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
SELECT @ContextSuggestionLinkId, 3, @SuggestionLinkID  -- EXPANDABLE MENU LINK

GO


------------------------------------------
-- UPDATE CHANGE CATALOGUE
------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 521
SET @ScriptDesc = 'CO2 emissions for public transport has been turned on - expandable link inserted, and switch set to true'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO