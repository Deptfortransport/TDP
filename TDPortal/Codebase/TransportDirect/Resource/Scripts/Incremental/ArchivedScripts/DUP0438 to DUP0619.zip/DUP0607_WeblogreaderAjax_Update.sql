-- ***********************************************
-- NAME 		: DUP0607_WeblogreaderAjax_Update.sql
-- DESCRIPTION 		: Updates the weblogreader page extension properties 
--			  - to include the ajax extension ashx
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE WebLogReader WebPageExtension PROPERTIES
----------------------------------------

-- NUMBER OF CAR PARKS 
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'WebLogReader.WebPageExtensions')
  BEGIN
   UPDATE properties
	SET pValue = 'asp aspx ashx htm html pdf [none]'
        WHERE (pName LIKE 'WeblogReader.WebPageExtensions')
  END


----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 607
SET @ScriptDesc = 'Updates the weblogreader page extension properties '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO