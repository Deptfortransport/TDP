-- ***********************************************
-- NAME 		: DUP0557_Amend_TrainTaxi_Gateway_ Import.sql
-- DESCRIPTION 		: Updates the feed properties for the yvs938 data feed
--
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE FEED CONFIGURATION
----------------------------------------

IF EXISTS(SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'yvs938')
  BEGIN
    DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'yvs938'
  END

INSERT INTO IMPORT_CONFIGURATION(DATA_FEED, IMPORT_CLASS, CLASS_ARCHIVE, IMPORT_UTILITY, PARAMETERS1, PARAMETERS2, PROCESSING_DIR)
VALUES ('yvs938','TransportDirect.UserPortal.LocationService.TrainTaxiImportClass','td.userportal.locationservice.dll','','D:\Gateway\bat\TrainTaxi.bat','','D:/Gateway/dat/Processing/yvs938')


----------------------------------------
-- UPDATE FEED PROPERTIES
----------------------------------------

IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.traintaxi.database','datagateway.sqlimport.traintaxi.feedname','datagateway.sqlimport.traintaxi.Name','datagateway.sqlimport.traintaxi.elementnames',
     'datagateway.sqlimport.traintaxi.schemea','datagateway.sqlimport.traintaxi.sqlcommandtimeout','datagateway.sqlimport.traintaxi.storedprocedure',
     'datagateway.sqlimport.traintaxi.xmlnamespace','datagateway.sqlimport.traintaxi.xmlnamespacexsi','datagateway.sqlimport.traintaxi.xmlschemalocation'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.traintaxi.database','datagateway.sqlimport.traintaxi.feedname','datagateway.sqlimport.traintaxi.Name','datagateway.sqlimport.traintaxi.elementnames',
     'datagateway.sqlimport.traintaxi.schemea','datagateway.sqlimport.traintaxi.sqlcommandtimeout','datagateway.sqlimport.traintaxi.storedprocedure',
     'datagateway.sqlimport.traintaxi.xmlnamespace','datagateway.sqlimport.traintaxi.xmlnamespacexsi','datagateway.sqlimport.traintaxi.xmlschemalocation')
  END


INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.database','AtosAdditionalDataDB','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.feedname','yvs938','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.Name','traintaxi','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.elementnames','NaPTANcode|destinationname|traintaxilink|commentline|accessibilitytext|firm1name|firm2name|firm3name|firm4name|firm1phone|firm2phone|firm3phone|firm4phone|firm1accessibility|firm2accessibility|firm3accessibility|firm4accessibility|GOTO1name|GOTO2name|GOTO3name|GOTO4name|GOTO1link|GOTO2link|GOTO3link|GOTO4link|copyright','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.schemea','D:\gateway\bin\xml\traintaxi.xsd','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.sqlcommandtimeout','3000','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.storedprocedure','ImporttraintaxiData','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.xmlnamespace','http://www.transportdirect.info/traintaxi','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.xmlnamespacexsi','http://www.w3.org/2001/XMLSchema-instance','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.traintaxi.xmlschemalocation','http://www.transportdirect.info/TrainTaxi.xsd','','DataGateway','0')


---------------------------------------------
-- Add AtosAdditionalDataDB Connection string
---------------------------------------------

IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] = 'AtosAdditionalDataDB')
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] = 'AtosAdditionalDataDB'
  END

INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('AtosAdditionalDataDB','Server=D03;Initial Catalog=AtosAdditionalData;Trusted_Connection=true;','<DEFAULT>','<DEFAULT>','0')


----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 557
SET @ScriptDesc = 'Updates for TrainTaxi data import'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO