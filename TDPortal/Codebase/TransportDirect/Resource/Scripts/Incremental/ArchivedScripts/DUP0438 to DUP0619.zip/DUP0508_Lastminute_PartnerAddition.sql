-- *************************************************************************************
-- NAME 		: DUP0508_Lastminute_PartnerAddition.sql
-- DESCRIPTION 		: lastminute_PartnerAddition
-- DATE                 : 15-JAN-2007
-- *************************************************************************************

------------------------
-- Properties Table
------------------------

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [PARTNER] WHERE [PartnerName] = 'lastminute' AND [PartnerId] = '5')
  BEGIN
     DELETE FROM [PARTNER] WHERE [PartnerName] = 'lastminute'
  END
INSERT INTO PARTNER ([PartnerId], [HostName], [PartnerName], [Channel], [PartnerPassword])
VALUES ('5', 'lastminute', 'lastminute', 'iframes', NULL)

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 508
SET @ScriptDesc = 'lastminute_PartnerAddition'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO