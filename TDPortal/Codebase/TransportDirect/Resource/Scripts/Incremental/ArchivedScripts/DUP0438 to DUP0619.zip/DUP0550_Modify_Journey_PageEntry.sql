-- ***********************************************
-- NAME 		: DUP0550_Modify_Journey_PageEntry.sql
-- DESCRIPTION 		: sql to setup Page entry events for user actions on the Modify my journey page
-- ************************************************

----------------------------------------
-- INSERT PAGE ENTRY
----------------------------------------
USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyExtendOutwardClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'ModifyExtendOutwardClicked', 'Indicates user selected to Extend Outward Journey' FROM PageEntryType
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableJourneyEmissionsCompare') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription) 
SELECT MAX(PETID)+1, 'ModifyExtendReturnClicked', 'Indicates user selected to Extend Return Journey' FROM PageEntryType 
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyReplaceOutwardClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'ModifyReplaceOutwardClicked', 'Indicates user selected to Replace Outward Journey' FROM PageEntryType
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyReplaceReturnClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription) 
SELECT MAX(PETID)+1, 'ModifyReplaceReturnClicked', 'Indicates user selected to Replace Return Journey' FROM PageEntryType 
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyAdjustOutwardClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'ModifyAdjustOutwardClicked', 'Indicates user selected to Adjust Outward Journey' FROM PageEntryType
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyAdjustReturnClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription) 
SELECT MAX(PETID)+1, 'ModifyAdjustReturnClicked', 'Indicates user selected to Adjust Return Journey' FROM PageEntryType 
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyAmendClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'ModifyAmendClicked', 'Indicates user selected to Amend the Journey' FROM PageEntryType
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyBackClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription) 
SELECT MAX(PETID)+1, 'ModifyBackClicked', 'Indicates user selected the Back button' FROM PageEntryType 
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'ModifyNewClicked') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'ModifyNewClicked', 'Indicates user selected the New Journey button' FROM PageEntryType
GO


----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 550
SET @ScriptDesc = 'Added page entry events for Modify Journey Page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO