-- *************************************************************************************
-- NAME 			: DUP0617_UpdateTDMobileUiURLProperty.sql
-- DESCRIPTION 		: Add correct TDMobileUi URL Property for Del 10 - SC/MT Solution
-- *************************************************************************************

USE [PermanentPortal]
go

-- Remove old db entries

DELETE FROM properties WHERE pname = 'TDOnTheMove.TDMobileUI.URL'
go

--------------------------------------------------------------------------------------
-- Assume ACP...
--------------------------------------------------------------------------------------
insert into [dbo].[properties] (pName, pValue, aid, gid, PartnerId, ThemeId ) 
values ('TDOnTheMove.TDMobileUI.URL', 'http://tdti.kizoom.co.uk/en/deps/index', 'Web', 'UserPortal', 0, 1)
go
--------------------------------------------------------------------------------------
-- ...Now set it to the actual one as we could be running on siTest or BBP
--------------------------------------------------------------------------------------
UPDATE [PermanentPortal].[dbo].[properties]
SET [pValue]= (SELECT [pValue] FROM [PermanentPortal].[dbo].[properties] WHERE [pName] = 'TDOnTheMove.TDMobileUI.URL.en-GB')
WHERE [pName] = 'TDOnTheMove.TDMobileUI.URL'
go

----------------
-- Change Log --
----------------
use PermanentPortal
go

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 450)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Add correct TDMobileUi URL Property for Del 10'
    WHERE ScriptNumber = 617
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (617, getDate(), 'Add correct TDMobileUi URL Property for Del 10' )
  END
GO