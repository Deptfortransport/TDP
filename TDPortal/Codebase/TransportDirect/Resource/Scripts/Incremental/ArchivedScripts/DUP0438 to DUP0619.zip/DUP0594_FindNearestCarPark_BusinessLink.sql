-- ***********************************************
-- NAME 		: DUP0594_FindNearestCarPark_BusinessLink.sql
-- DESCRIPTION 		: sql to setup a new Business Link template for Find nearest car park
-- AUTHOR		: Mitesh Modi
-- ************************************************

----------------------------------------
-- INSERT PAGE ENTRY
----------------------------------------
USE [PermanentPortal]
GO

-- Add template without HTML
IF EXISTS (SELECT * FROM BusinessLinkTemplates WHERE BusinessLinkTemplatesId = 5)
BEGIN
	DELETE FROM BusinessLinkTemplates WHERE BusinessLinkTemplatesId = 5
END

INSERT INTO BusinessLinkTemplates	
	(BusinessLinkTemplatesId, NameResourceId, ImageUrl, HTMLScript)
	VALUES
	(5, 'BusinessLinks.Template5Radio', '/web/images/gifs/misc/BusinessLinksTemplate5.gif', '')
GO

-- Add HTML
DECLARE @ptrval varbinary(16)

	SELECT @ptrval = TEXTPTR(HTMLScript)
	FROM BusinessLinkTemplates
	WHERE BusinessLinkTemplatesId = 5

	WRITETEXT BusinessLinkTemplates.HTMLScript @ptrval
	
'<style type="text/css">
.hidelabel { display: none; }
</style>
<form method="post" id="Form1" onsubmit="AssembleParameters()" target="_blank" action="{TARGET_URL}/transportdirect/en/journeyplanning/FindNearestLandingPage.aspx">
<table width="230px" cellspacing="0" style="margin: 3px 3px 3px 3px;">
		<tr bgcolor="#330099">
		<td><p style="margin: 2px 2px 2px 4px"><img alt="Transport Direct" src="{TARGET_URL}/web/images/gifs/misc/TDLogo38.gif" /></p>
		</td>
		<td colspan="2"></td>
	</tr>
	
	<tr bgcolor="#99ccff">
		<td colspan="3">
			<p style="font-family: verdana, arial, helvetica, sans-serif; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">Enter a location and let <a href="http://www.transportdirect.info/TransportDirect/en/Home.aspx" target="_blank">Transport Direct</a> find the nearest car parks.</p>
		</td>
	</tr>
		
	<tr bgcolor="#99ccff">
		<td colspan="3">
		<p style="font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: left; margin: 5px 5px 5px 5px;">
		<table cellpadding="2" cellspacing="0" border="0">
			<tr>
				<td><p style="font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: left;">Place</p></td>
				<td><input type="text" id="txtLocation" name="txtLocation" style="width: 120px; border-color: lightgrey; border-width: 1px; border-style: solid; font-size: 12px; font-family: verdana, arial, helvetica, sans-serif; background-color: white; height: 20px; width: 160px;" /></td>
			</tr>
			<tr>
				<td></td>
				<td>
					<span class="hidelabel"><label for="drpLocationType">Select the location type</label></span>
					<select id="drpLocationType" name="drpLocationType" style="border-right: lightgrey 1px solid; border-top: lightgrey 1px solid; font-size: 12px; border-left: lightgrey 1px solid; border-bottom: lightgrey 1px solid; font-family: verdana, arial, helvetica, sans-serif; background-color: white; height: 20px; width: 160px;">
						<option value="AddressPostcode" selected="selected">Address/postcode</option>
						<option value="CityTownSuburb">Town/district/village</option>
						<option value="StationAirport">Station/airport</option>
						<option value="AttractionFacility">Facility/attraction</option>
					</select>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="right">

					<input type="submit" id="btnSubmit" value="Go" style="color: #264266; background-color: #ebebeb; font-family: verdana, arial, helvetica, sans-serif; font-weight: bold; font-size: 12px; text-align: center; text-decoration: none; border-bottom-color: #808080; border-top-color: #C0C0C0; border-right-color: #808080;  border-left-color: #C0C0C0; border-width: 1px; border-style: solid; cursor: pointer; cursor: hand; width: auto; overflow: visible; padding: 0px 0px 1px 0px; " />
	
					<input type="hidden" name="et" id="entryType" value="fn" />
					<input type="hidden" name="ft" id="originData" value="cp" />					
					<input type="hidden" name="pn" id="placeName" value="" /> 
					<input type="hidden" name="lg" id="locationGazetteer" value="" />
					<input type="hidden" name="nd" id="numberDisplayed" value="50" />

					<input type="hidden" name="id" id="partnerID" value="{PARTNER_ID}" /> 
					<input type="hidden" name="p" id="autoPlan" value="1" />
				</td>
			</tr>
		</table>
		</p>

		</td>
	</tr>
</table>

</form>
<script language="javascript" type="text/javascript">
<!--
function AssembleParameters()
{
	var inputText = document.getElementById("txtLocation").value;
	var locationTypeList = document.getElementById("drpLocationType");
	var locationType = locationTypeList.options[locationTypeList.selectedIndex].value;

	document.getElementById("placeName").value = inputText;    
	document.getElementById("locationGazetteer").value = locationType;	 
}
//-->
</script>'

GO

----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 594
SET @ScriptDesc = 'Added Business Link template for find nearest car park'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO