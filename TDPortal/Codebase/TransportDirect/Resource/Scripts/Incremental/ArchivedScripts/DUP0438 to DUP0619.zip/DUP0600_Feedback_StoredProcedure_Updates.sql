-- ***********************************************
-- NAME 		: DUP0600_Feedback_StoredProcedure_Updates
-- DESCRIPTION 		: User Feedback Stored Procedures updated to include larger session id
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [TDUserInfo]
GO

-- =============================================  
-- GetSessionData
-- =============================================  

ALTER PROCEDURE [dbo].[AddSessionData]
(
	@FeedbackId varchar(50),
	@SessionId varchar(100)
)
AS
BEGIN
	SELECT @SessionId = RTRIM(@SessionId) + '%'

	INSERT INTO UserFeedbackSessionData
	(
		FeedbackId,
		SessionId,
		KeyId,
		SessionItemLong,
		DeleteFlag
	)
	SELECT
		@FeedbackId AS Expr1,
		SessionId,
		KeyId,
		SessionItemLong,
		0 AS Expr2
	FROM
		ASPState.dbo.DeferredData
	WHERE
		SessionId LIKE @SessionId
END

GO

-- =============================================  
-- GetSessionCreatedDateTime
-- =============================================  

ALTER PROCEDURE [dbo].[GetSessionCreatedDateTime]
(
	@SessionId varchar(100),
	@Created datetime OUTPUT
)
AS
BEGIN
	SELECT @SessionId = RTRIM(@SessionId) + '%'
	SET @Created = (SELECT	[Created]
			FROM	ASPState.dbo.ASPStateTempSessions
			WHERE	[SessionId] LIKE @SessionId)
END

GO


-- =============================================  
-- GetSessionData
-- Retrieves session data from TDUserInfo.UserFeedbackSessionData
-- This sp is similar to that in ASPState (GetDeferredData)
-- =============================================  

ALTER PROCEDURE [dbo].[GetSessionData] 
(
	@FeedbackId int,
	@SessionId varchar(100), 
	@KeyId char(48) 
)
AS
DECLARE @textptr AS tTextPtr
DECLARE @length AS INT

-- Test for an entry UserFeedbackSessionData
IF EXISTS (SELECT SessionID FROM [dbo].[UserFeedbackSessionData] WHERE FeedbackId = @FeedbackId AND SessionId = @SessionId AND KeyId = @KeyId)
BEGIN
    SELECT
        @textptr = TEXTPTR(SessionItemLong),
        @length = DATALENGTH(SessionItemLong)
    FROM TDUserInfo..UserFeedbackSessionData
    WHERE FeedbackId = @FeedbackId
	  AND SessionId = @SessionId
          AND KeyId = @KeyId
   
     IF @length IS NOT NULL 
	BEGIN
	        READTEXT TDUserInfo..UserFeedbackSessionData.SessionItemLong @textptr 0 @length
	END

    RETURN 0

END
  ELSE
BEGIN
    RETURN -1
END


GO


-- =============================================  
-- GetSessionExpiryDateTime
-- =============================================  

ALTER PROCEDURE [dbo].[GetSessionExpiryDateTime]
(
	@SessionId varchar(100),
	@Expires datetime OUTPUT
)
AS
BEGIN
	SELECT @SessionId = RTRIM(@SessionId) + '%'
	SET @Expires = (SELECT	[Expires]
			FROM	ASPState.dbo.ASPStateTempSessions
			WHERE	[SessionId] LIKE @SessionId)
END

GO

-- =============================================  
-- CHANGE LOG
-- =============================================  
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 600
SET @ScriptDesc = 'Updated user feedback stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-- =============================================  