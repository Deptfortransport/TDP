-- *************************************************************************************
-- NAME 		: DUP0538_Updated User feedback SP.sql
-- DESCRIPTION 		: Update to the User feedback SP 
-- *************************************************************************************
-- 
-- Security permissions must be updated in this script.


USE [TDUserInfo]
GO

------------------------------------------
-- Remove old stored procedure
------------------------------------------


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddUserFeedback]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[AddUserFeedback]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


------------------------------------------
-- Create new stored procedure
------------------------------------------

-- AddUserFeedback

CREATE PROCEDURE [dbo].[AddUserFeedback]
(
	@SessionId varchar (100) = '999999999' ,
	@SubmittedTime datetime ,
	@AcknowledgedTime datetime ,
	@AcknowledgementSent bit ,
	@UserLoggedOn bit ,
	@TimeLogged datetime ,
	@VantiveId varchar (10),
	@FeedbackStatus varchar (50) ,
	@DeleteFlag bit
)
AS

	DECLARE @ins_error int , @ins_rowcount int
	DECLARE @localized_string_UnableToCarryOutAction AS nvarchar(256)
	DECLARE @SessionCreated AS datetime
	DECLARE @SessionExpires AS datetime
	    	
	SELECT @SessionCreated = (SELECT [Created] FROM ASPState.dbo.ASPStateTempSessions WHERE	[SessionId] LIKE RTRIM(@SessionId) + '%')
 
	SELECT @SessionExpires = (SELECT [Expires] FROM ASPState.dbo.ASPStateTempSessions WHERE	[SessionId] LIKE RTRIM(@SessionId) + '%')

 	BEGIN
	
	    INSERT INTO [UserFeedback] 
		(
		[SessionId],
		[SessionCreated],
		[SessionExpires],
		[SubmittedTime],
		[AcknowledgedTime],
		[AcknowledgementSent],
		[UserLoggedOn],
		[TimeLogged],
		[VantiveId],
		[FeedbackStatus],
		[DeleteFlag]
		)
	    VALUES 
		(
		@SessionId,
		@SessionCreated,
		@SessionExpires,
		@SubmittedTime,
		@AcknowledgedTime,
		@AcknowledgementSent,
		@UserLoggedOn,
		@TimeLogged,
		@VantiveId ,
		@FeedbackStatus,
		@DeleteFlag
		)

	-- capture the runtime values from the above
	select @ins_error = @@error, @ins_rowcount = @@rowcount		

	

	IF @ins_rowcount <> 1
   		BEGIN
			select @localized_string_UnableToCarryOutAction = ('incorrect rows updated !!!! Row count: ' + cast (@ins_rowcount as char)) 
			raiserror (@localized_string_UnableToCarryOutAction, 16,1) with log
        			RETURN -1
    		
		END		
	
	IF @ins_error <> 0
    		BEGIN
			SET @localized_string_UnableToCarryOutAction = 'Unable to create record for  ' + cast (@SessionId AS char) + '  in UserFeedback table. Error Code: ' + cast (@ins_error as char)   
        			--raiserror (@localized_string_UnableToCarryOutAction, 16,1) with log
        			RETURN -1
    		END
    	ELSE
		BEGIN
			--raiserror ('successfull user feedback ', 16,1) with log
			RETURN @ins_rowcount
    		END


	  
        END
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Update Permissions	
-- comment out as appropriate.

----------------------------------------------------------------

GRANT EXECUTE ON [AddUserFeedback] TO [DFTSIW\ASPUSER]
go
GRANT EXECUTE ON [AddUserFeedback] TO [BBPDFTW\ASPUSER]
go
GRANT EXECUTE ON [AddUserFeedback] TO [ACPDFTW\ASPUSER]

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 538
SET @ScriptDesc = 'Update to the User feedback SP'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
