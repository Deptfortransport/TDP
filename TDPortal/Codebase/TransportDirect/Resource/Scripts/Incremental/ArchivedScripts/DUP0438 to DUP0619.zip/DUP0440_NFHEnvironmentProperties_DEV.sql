-- ************************************************************
-- NAME 	: DUD0440_NFHEnvironmentProperties_DEV.sql
-- DESCRIPTION 	: Updates environment specific properties. This
-- 		  script should be run locally on DEV machines
--		  only. 
-- ************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0440_NFHEnvironmentProperties_DEV.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:57:52   mmodi
--Initial revision.
--
--   Rev 1.0   Nov 08 2007 12:41:14   mturner
--Initial revision.
--
--   Rev 1.1   May 23 2006 10:41:26   kjosling
--Updated
--
--   Rev 1.0   May 22 2006 17:15:56   kjosling
--Initial revision.


USE PermanentPortal
GO

UPDATE Properties SET pValue = 'data source=D01; initial catalog=AdditionalData; user id=AdditionalDataUser; password=password; persist security info=False'
WHERE     (pName = 'AdditionalDataDB')

UPDATE Properties SET pValue = 'data source=SID01;initial catalog=mastermap;user id=mapadmin;password=Alum1n1um!'
WHERE     (pName = 'EsriDB')

UPDATE Properties SET pValue = 'tdp_del8'
WHERE     (pName = 'locationservice.servicename')

UPDATE Properties SET pValue = 'data source=TRI-TDP-IIS; initial catalog=NPTG; uid=cjp;pwd=cjp; persist security info=False;packet size=4096'
WHERE     (pName = 'LocationService.NPTGAccess.ConnectionString')


-- Change Catalogue
DELETE FROM ChangeCatalogue WHERE ScriptNumber = 440
INSERT INTO ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
VALUES (440, GETDATE(), 'Changed properties to match NFH dev environment')
GO


