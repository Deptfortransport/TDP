-- ***********************************************
-- NAME 		: DUP0583_LocationInformation_Importer_Setup.sql
-- DESCRIPTION 		: sql to setup the Airport Links (Location Information) data feed import
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [PermanentPortal]
GO
-------------------------------------------------------------------------
-- ADD FEED IMPORT CONFIGURATION
-------------------------------------------------------------------------

IF EXISTS(SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'pik611')
  BEGIN
    DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'pik611'
  END

INSERT INTO IMPORT_CONFIGURATION(DATA_FEED, IMPORT_CLASS, CLASS_ARCHIVE, IMPORT_UTILITY, PARAMETERS1, PARAMETERS2, PROCESSING_DIR)
VALUES ('pik611','TransportDirect.UserPortal.LocationInformationService.LocationInformationImportTask','td.userportal.locationinformationservice.dll','','','','C:/Gateway/dat/Processing/pik611')

GO


-------------------------------------------------------------------------
-- ADD FEED PROPERTIES
-------------------------------------------------------------------------

IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.airportlinks.database','datagateway.sqlimport.airportlinks.feedname','datagateway.sqlimport.airportlinks.Name',
     'datagateway.sqlimport.airportlinks.schemea','datagateway.sqlimport.airportlinks.sqlcommandtimeout','datagateway.sqlimport.airportlinks.storedprocedure',
     'datagateway.sqlimport.airportlinks.xmlnamespace','datagateway.sqlimport.airportlinks.xmlnamespacexsi','datagateway.sqlimport.airportlinks.xmlschemalocation'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.airportlinks.database','datagateway.sqlimport.airportlinks.feedname','datagateway.sqlimport.airportlinks.Name',
     'datagateway.sqlimport.airportlinks.schemea','datagateway.sqlimport.airportlinks.sqlcommandtimeout','datagateway.sqlimport.airportlinks.storedprocedure',
     'datagateway.sqlimport.airportlinks.xmlnamespace','datagateway.sqlimport.airportlinks.xmlnamespacexsi','datagateway.sqlimport.airportlinks.xmlschemalocation')
  END

INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.database','TransientPortalDB','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.feedname','pik611','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.Name','airportlinks','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.schemea','C:\gateway\bin\xml\AirportLinks.xsd','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.sqlcommandtimeout','3000','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.storedprocedure','ImportAirportLinksData','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.xmlnamespace','http://www.transportdirect.info/AirportLinks','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.xmlnamespacexsi','http://www.w3.org/2001/XMLSchema-instance','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.airportlinks.xmlschemalocation','http://www.transportdirect.info/AirportLinks.xsd','','DataGateway','0')

GO


-------------------------------------------------------------------------
-- UPDATE FTP_CONFIGURATION
-------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [dbo].[ftp_configuration] WHERE data_feed = 'pik611')
  BEGIN
    UPDATE
      [dbo].[ftp_configuration]
    SET
      ftp_client = 1,
      data_feed = 'pik611',
      ip_address = 'LocalHost',
      username = 'TDP28Nov',
      password = 'sI1732#3-',
      local_dir = 'C:/Gateway/dat/Incoming/pik611',
      remote_dir = '../pik611',
      filename_filter = '*.zip',
      missing_feed_counter = 0,
      missing_feed_threshold = 1,
      data_feed_datetime = '01/01/2003',
      data_feed_filename = '',
      remove_files = 1      
    WHERE
      data_feed = 'pik611'
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ftp_configuration](ftp_client, data_feed, ip_address, username, password, local_dir,
     remote_dir,filename_filter,missing_feed_counter, missing_feed_threshold,data_feed_datetime,
     data_feed_filename,remove_files)
    VALUES (1, 'pik611','LocalHost','TDP28Nov','sI1732#3-','C:/Gateway/dat/Incoming/pik611','../pik611','*.zip',
	 0, 1, '01/01/2003','', 1)
  END

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 583
SET @ScriptDesc = 'Airport Links data feed import setup'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------