-- ***********************************************
-- NAME 		: DUP0587_LocationInformation_ChangeNotification_Setup.sql
-- DESCRIPTION 		: sql to setup the Location Information import change notification
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [PermanentPortal]
GO

-------------------------------------------------------------------------
-- ADD DATANOTIFICATION GROUP PROPERTIES
-------------------------------------------------------------------------
UPDATE 	PROPERTIES
SET 	pValue = 'Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare,ZonalServiceCatalogue'
WHERE	(pName = 'DataServices.DataNotification.Groups') AND 
	(AID = '<DEFAULT>')AND
	(GID = '<DEFAULT>')


UPDATE 	PROPERTIES
SET 	pValue = 'Air,TravelNewsImport,SeasonalNoticeBoardImport,CarCosting,ExternalLinks,OperatorCatalogue,LocationInformationCatalogue,NetworkMapLinks,BayTextFilter,ParkAndRide,SuggestionBoxLinkCatalogue,CoachRoutesQuotaFare, PartnerCatalogue,ZonalServiceCatalogue'
WHERE	(pName = 'DataServices.DataNotification.Groups') AND 
	(AID = 'EnhancedExposedServices')AND
	(GID = 'UserPortal')
GO	


-------------------------------------------------------------------------
-- ADD DATANOTIFICATION TABLE PROPERTIES
-------------------------------------------------------------------------

IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    ('DataServices.DataNotification.LocationInformationCatalogue.Database',
     'DataServices.DataNotification.LocationInformationCatalogue.Tables)'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    ('DataServices.DataNotification.LocationInformationCatalogue.Database',
     'DataServices.DataNotification.LocationInformationCatalogue.Tables)')
  END

INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('DataServices.DataNotification.LocationInformationCatalogue.Database','TransientPortalDB','<DEFAULT>','<DEFAULT>','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('DataServices.DataNotification.LocationInformationCatalogue.Tables','LocationInformation','<DEFAULT>','<DEFAULT>','0')

GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 587
SET @ScriptDesc = 'Added LocationInformation data notification properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------