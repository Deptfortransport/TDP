-- ***********************************************
-- NAME 		: DUP0452_FindCarParkSetup.sql
-- DESCRIPTION 		: sql to setup find car park in left hand navigation menu,
--			  Find a place dropdown list, and Find Car route input suggestion link
-- ************************************************

----------------------------------------
-- SET UP DATA FOR EXPANDABLE MENU LINK AND SUGGESTION LINK
----------------------------------------
USE [TransientPortal]
GO

DECLARE @ResourceNameID INT,
	@ResourceID INT,
	@InternalLinkID INT, 
	@SuggestionLinkID INT

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = 'FindNearestCarPark') 
INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
SELECT @ResourceNameID , 'FindNearestCarPark'

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = 'Find nearest car park'))
INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
SELECT @ResourceID, @ResourceNameID, 'en-GB', 'Find nearest car park'

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = 'Darganfyddwch y maes parcio agosaf'))
INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', 'Darganfyddwch y maes parcio agosaf'

--insert into InternalLink table
IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = 'Find Nearest Car Park Input Page')
INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
SELECT @InternalLinkID , 'JourneyPlanning/FindCarParkInput.aspx', 'Find Nearest Car Park Input Page'


--insert into SuggestionLink table - Used for Find nearest car park expandable menu link below
IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = 4) AND ([Priority] = 35))
INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], 
[ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
SELECT @SuggestionLinkID, 4, 35, @ResourceNameID, @InternalLinkID, 'Internal', 0

--insert into SuggestionLink table - Used for Find nearest car park suggestion link in Find a Car Route below
IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = 1) AND ([Priority] = 85))
INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], 
[ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
SELECT @SuggestionLinkID + 1, 1, 85, @ResourceNameID, @InternalLinkID, 'Internal', 1

GO


----------------------------------------
-- INSERT AN EXPANDABLE MENU LINK
----------------------------------------

DECLARE @ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT

SET @ResourceNameID = (SELECT ResourceNameId FROM dbo.ResourceName WHERE ResourceName = 'FindNearestCarPark')
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM dbo.SuggestionLink 
				WHERE LinkCategoryId = 4
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from dbo.ContextSuggestionLink) + 1


--insert into ContextSuggestionLink table
IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = 3))
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
SELECT @ContextSuggestionLinkId, 3, @SuggestionLinkID  -- FIND NEAREST CAR PARK EXPANDABLE MENU LINK

GO


----------------------------------------
-- INSERT FIND CAR ROUTE SUGGESTION LINK FOR FIND NEAREST CAR PARK
----------------------------------------

DECLARE @ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT

SET @ResourceNameID = (SELECT ResourceNameId FROM dbo.ResourceName WHERE ResourceName = 'FindNearestCarPark')
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM dbo.SuggestionLink 
				WHERE LinkCategoryId = 1
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from dbo.ContextSuggestionLink) + 1

--insert into ContextSuggestionLink table
IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = 2))
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
SELECT @ContextSuggestionLinkId, 2, @SuggestionLinkID  -- FIND NEAREST CAR PARK SUGGESTION LINK IN FIND A CAR ROUTE

GO


----------------------------------------
-- INSERT DROPDOWN ITEM
----------------------------------------
USE [PermanentPortal]
GO

--insert into DropDownLists table for FindAPlaceControl
IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'FindLocationShowOptions') AND ([ResourceID] = 'CarPark'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('FindLocationShowOptions', 'CarPark', '4', 0, 4, 0)
GO

--shift the TrafficLevels entry down one
If NOT EXISTS (SELECT * FROM [DropDownLists] WHERE ([ResourceID] = 'TrafficLevels') AND ([SortOrder] = 5))
UPDATE DropDownLists SET SortOrder = 5 WHERE ResourceID = 'TrafficLevels' 
GO


----------------------------------------
-- INSERT FIND CAR PARK PROPERTIES
----------------------------------------

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.InitialRadius')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES     ('FindNearestCarParks.InitialRadius', '16092', '<DEFAULT>', '<DEFAULT>', 0)

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.MaximumRadius')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES     ('FindNearestCarParks.MaximumRadius', '16093', '<DEFAULT>', '<DEFAULT>', 0)

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.NumberCarParksReturned')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES     ('FindNearestCarParks.NumberCarParksReturned', '10', '<DEFAULT>', '<DEFAULT>', 0)
GO


----------------------------------------
-- INSERT PAGE ENTRY
----------------------------------------
USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindCarParkInput') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'FindCarParkInput', 'Used to find nearest car parks to a location' FROM PageEntryType
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableCarParkResults') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription) 
SELECT MAX(PETID)+1, 'PrintableCarParkResults', 'Printable car park results page' FROM PageEntryType 
GO


----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 452
SET @ScriptDesc = 'sql to setup find car park'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO