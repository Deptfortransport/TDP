-- ***********************************************
-- NAME 		: DUP0501_FeedbackPage_PageEntry.sql
-- DESCRIPTION 		: Addded page entry event type for FeedbackPage for Contact Us Improvements
-- ************************************************

-- INSERT PAGE ENTRY EVENTS
USE Reporting
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FeedbackPage') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'FeedbackPage', 'FeedbackPage' FROM PageEntryType
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FeedbackViewer') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'FeedbackViewer', 'FeedbackViewer' FROM PageEntryType
GO

-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 501
SET @ScriptDesc = 'Addded FeedbackPage and FeedbackViewer page entry event type'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO