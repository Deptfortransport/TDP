-- ***********************************************
-- NAME 		: DUP0565_Add_Coach_NaPTAN_Lookup_Gateway_Import.sql
-- DESCRIPTION 		: Adds or updates the feed properties for the qsx462 data feed
--
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE FEED CONFIGURATION
----------------------------------------

IF EXISTS(SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'qsx462')
  BEGIN
    DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'qsx462'
  END

INSERT INTO IMPORT_CONFIGURATION(DATA_FEED, IMPORT_CLASS, CLASS_ARCHIVE, IMPORT_UTILITY, PARAMETERS1, PARAMETERS2, PROCESSING_DIR)
VALUES ('qsx462','TransportDirect.UserPortal.LocationService.CoachNaPTANImport','td.userportal.locationservice.dll','','D:\Gateway\bat\CoachNaptanLookup.bat','','D:/Gateway/dat/Processing/qsx462')


----------------------------------------
-- UPDATE FEED PROPERTIES
----------------------------------------

IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.coachnaptanlookup.database','datagateway.sqlimport.coachnaptanlookup.feedname','datagateway.sqlimport.coachnaptanlookup.Name',
     'datagateway.sqlimport.coachnaptanlookup.schemea','datagateway.sqlimport.coachnaptanlookup.sqlcommandtimeout','datagateway.sqlimport.coachnaptanlookup.storedprocedure',
     'datagateway.sqlimport.coachnaptanlookup.xmlnamespace','datagateway.sqlimport.coachnaptanlookup.xmlnamespacexsi','datagateway.sqlimport.coachnaptanlookup.xmlschemalocation'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.coachnaptanlookup.database','datagateway.sqlimport.coachnaptanlookup.feedname','datagateway.sqlimport.coachnaptanlookup.Name',
     'datagateway.sqlimport.coachnaptanlookup.schemea','datagateway.sqlimport.coachnaptanlookup.sqlcommandtimeout','datagateway.sqlimport.coachnaptanlookup.storedprocedure',
     'datagateway.sqlimport.coachnaptanlookup.xmlnamespace','datagateway.sqlimport.coachnaptanlookup.xmlnamespacexsi','datagateway.sqlimport.coachnaptanlookup.xmlschemalocation')
  END

INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.database','AtosAdditionalDataDB','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.feedname','qsx462','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.Name','coachnaptanlookup','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.schemea','D:\gateway\bin\xml\CoachNaptanLookup.xsd','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.sqlcommandtimeout','3000','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.storedprocedure','ImportCoachNaptanLookupData','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.xmlnamespace','http://www.transportdirect.info/coachnaptanlookup','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.xmlnamespacexsi','http://www.w3.org/2001/XMLSchema-instance','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.coachnaptanlookup.xmlschemalocation','http://www.transportdirect.info/coachnaptanlookup.xsd','','DataGateway','0')

----------------------------------------
-- UPDATE FTP_CONFIGURATION
----------------------------------------
IF EXISTS (SELECT * FROM [dbo].[ftp_configuration] WHERE data_feed = 'qsx462')
  BEGIN
    UPDATE
      [dbo].[ftp_configuration]
    SET
      ftp_client = 1,
      data_feed = 'qsx462',
      ip_address = 'LocalHost',
      username = 'TDP28Nov',
      password = 'sI1732#3-',
      local_dir = 'D:/Gateway/dat/Incoming/qsx462',
      remote_dir = '../qsx462',
      filename_filter = '*.zip',
      missing_feed_counter = 0,
      missing_feed_threshold = 1,
      data_feed_datetime = '01/01/2003',
      data_feed_filename = '',
      remove_files = 1      
    WHERE
      data_feed = 'qsx462'
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ftp_configuration](ftp_client, data_feed, ip_address, username, password, local_dir,
     remote_dir,filename_filter,missing_feed_counter, missing_feed_threshold,data_feed_datetime,
     data_feed_filename,remove_files)
    VALUES (1, 'qsx462','LocalHost','TDP28Nov','sI1732#3-','D:/Gateway/dat/Incoming/qsx462','../qsx462','*.zip',
	 0, 1, '01/01/2003','', 1)
  END
GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 565
SET @ScriptDesc = 'Add Coach NaPTAN Lookup Gateway Import'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO