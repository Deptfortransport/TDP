-- ************************************************************
-- NAME 	: DUP0466_CarParking_UpdateExpandableLink_Welsh.sql
-- DESCRIPTION 	: Updates to left hand Expandable link navigation for car parking, adding Welsh text
-- ************************************************************

------------------------------------------
-- Update to Import Configuration
------------------------------------------

USE TransientPortal
GO

UPDATE [Resource]
SET Text = 'Darganfyddwch y maes parcio agosaf'
WHERE Text = 'cy Find nearest car park' AND Culture = 'cy-GB'
GO

------------------------------------------
-- Update Change Catalogue
------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 466)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Updated Car parking expandable link welsh text'
	WHERE ScriptNumber = 466
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (466, (getDate()), 'Updated Car parking expandable link welsh text')
GO
