-- ************************************************************
-- NAME 	: DUP0543_NXFares_Tables.sql
-- DESCRIPTION 	: Creates the new Coach Fares table used to hold the different coach tickets types
-- ************************************************************

USE [PermanentPortal]
GO

------------------------------------------
-- Delete existing tables
------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[CoachFares]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[CoachFares]
GO

------------------------------------------
-- Create tables: UserFeedback, UserFeedbackSessionData, UserFeedbackClassification
------------------------------------------

CREATE TABLE [dbo].[CoachFares] (
	[FareTypeCode] [varchar] (200) NOT NULL ,
	[Description] [varchar] (200) NULL ,
	[Amendable] [bit] NOT NULL ,
	[Refundable] [bit] NOT NULL ,
	[RestrictionPriority] [int] NOT NULL,
	[Action] [char] (2) NULL ,
) ON [PRIMARY]
GO

------------------------------------------
-- Set the Primary Key
------------------------------------------

ALTER TABLE [dbo].[CoachFares] ADD 
	CONSTRAINT [PK_CoachFares] PRIMARY KEY  CLUSTERED 
	(
		[FareTypeCode]
	)  ON [PRIMARY] 
GO


-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 543
SET @ScriptDesc = 'Added table CoachFares'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO