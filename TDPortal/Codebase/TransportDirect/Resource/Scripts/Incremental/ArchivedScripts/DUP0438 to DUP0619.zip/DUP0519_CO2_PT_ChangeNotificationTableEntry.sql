-- ************************************************************
-- NAME 	: DUP0519_CO2_PT_ChangeNotificationTableEntry.sql
-- DESCRIPTION 	: Creates entry for JourneyEmissionsFactor table in
--		  ChangeNotificationTable to ensure that updates are automatically propagated
-- ************************************************************

------------------------------
-- ChangeNotification Table
-----------------------------

USE [PermanentPortal]
GO

--------------------------------------------------

IF EXISTS (SELECT * FROM ChangeNotification WHERE [Table] = 'JourneyEmissionsFactor')
  BEGIN
    DELETE FROM ChangeNotification WHERE [Table] = 'JourneyEmissionsFactor'
  END

INSERT INTO ChangeNotification ([version], [Table])
VALUES (1, 'JourneyEmissionsFactor')

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 519
SET @ScriptDesc = 'Added JourneyEmissionsFactor to Change Notification table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO