-- *************************************************************************************
-- NAME 		: DUP0535_ActOnCO2_External_Link.sql
-- DESCRIPTION 		: Adding a new Act On C02 link and a link for C02 on the Railways
--                       
-- Added by		: Andrew Sinclair
-- Date 		: 28 March 2007
-- *************************************************************************************

USE [TransientPortal]
GO


------------------------
-- Related Links
------------------------


IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.ActOnCo2')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.ActOnCo2'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.ActOnCo2', 'http://www.dft.gov.uk/ActOnCO2/', 'http://www.dft.gov.uk/ActOnCO2/', '1', 'Act On CO2', NULL, NULL, NULL)

GO

IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.Co2Railway')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.Co2Railway'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.Co2Railway', 'http://www.atoc-comms.org/dynamic/publication.php?publication=15', 'http://www.atoc-comms.org/dynamic/publication.php?publication=15', '1', 'CO2 on Railways', NULL, NULL, NULL)

GO


------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 512
SET @ScriptDesc = 'Adding a new Act On C02 link and a link for C02 on the Railways'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO