-- ***********************************************
-- NAME 		: DUP0558_Op_Event_column_width_reporting.sql
-- DESCRIPTION 		: Increase the message column width for operational events in the reporting database
--
-- ************************************************

Use Reporting

ALTER TABLE OperationalEvents
ALTER COLUMN OEMessage Varchar(1500)
GO