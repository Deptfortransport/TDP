-- **************************************************************
-- NAME 	: DUP0441_GatewayEventsProperties.sql		
-- DESCRIPTION 	: add Queue1 to GATE Publisher so gateway events go through to DB
-- **************************************************************
-- $Log

USE [PermanentPortal]
GO


update properties
set pValue = pvalue + ' Queue1' 
WHERE (pName = 'Logging.Event.Custom.GATE.Publishers') 
AND (AID = 'TDRemotingHost')
AND (GID = 'TDRemotingHost')

----------------
-- Change Log --
----------------


GO

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 441)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'add Queue1 to GATE Publisher'
    WHERE ScriptNumber = 441
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (441, getDate(), 'add Queue1 to GATE Publisher' )
  END
GO