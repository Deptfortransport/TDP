-- ************************************************************
-- NAME 	: DUP0516_CO2_PT_StoredProcedures.sql
-- DESCRIPTION 	: Creates new stored procedure GetJourneyEmissionsFactor,
--              : deleting if it exists
-- ************************************************************

USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Check for existance of the procedure and if it exists drop it
----------------------------------------------------------------
IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'PermanentPortal' 
              AND ROUTINE_NAME = 'GetJourneyEmissionsFactor' )
BEGIN
    DROP PROCEDURE [GetJourneyEmissionsFactor]
END

GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'PermanentPortal' 
              AND ROUTINE_NAME = 'GetLightRailSystemCode' )
BEGIN
    DROP PROCEDURE [GetLightRailSystemCode]
END

GO

----------------------------------------------------------------
-- Create new SP
----------------------------------------------------------------
CREATE PROCEDURE [dbo].[GetJourneyEmissionsFactor]
AS
	SELECT	[FactorType],
		[FactorValue]
	FROM 	[JourneyEmissionsFactor]
	ORDER BY [FactorType]
GO

GRANT  EXECUTE  ON [dbo].[GetJourneyEmissionsFactor]  TO [???????????????]
GO


CREATE PROCEDURE [dbo].[GetLightRailSystemCode]
AS
	SELECT	[TOCCode],
		[SystemCode]
	FROM 	[LightRailSystemCode]
	ORDER BY [TOCCode]
GO

GRANT  EXECUTE  ON [dbo].[GetLightRailSystemCode]  TO [???????????????]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 516
SET @ScriptDesc = 'Added GetJourneyEmissionsFactor stored procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO