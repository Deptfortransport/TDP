-- ***********************************************
-- NAME 		: DUP0590_DepartureBoard_ExternalLinks.sql
-- DESCRIPTION 		: sql to amend the Departure board link for help2travel
-- AUTHOR		: Neil Rankin
-- ************************************************

USE [TransientPortal]
GO
-------------------------------------------------------------------------
-- Update LINKS
-------------------------------------------------------------------------

-- Bus
UPDATE [dbo].[ExternalLinks]
SET [URL] = 'http://www.help2travel.co.uk/mattisse/bus-realtime.htm'
WHERE [ID] = 'DepartureBoard.Bus.5'

GO

UPDATE [dbo].[ExternalLinks]
SET [TestURL] = 'http://www.help2travel.co.uk/mattisse/bus-realtime.htm'
WHERE [ID] = 'DepartureBoard.Bus.5'

GO

-------------------------------------------------------------------------
-- Update display text for each link
-------------------------------------------------------------------------

-- Bus
UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'http://www.help2travel.co.uk/mattisse/bus-realtime'
WHERE [ID] = 'DepartureBoard.Bus.5'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 590
SET @ScriptDesc = 'Amend the Departure board link for help2travel'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------