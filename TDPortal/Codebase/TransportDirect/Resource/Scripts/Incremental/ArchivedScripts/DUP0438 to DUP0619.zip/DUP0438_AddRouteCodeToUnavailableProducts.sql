-- ***********************************************
-- NAME :        DUP0438_AddRouteCodeToUnavailableProducts
-- DESCRIPTION : Add routecode column to UnavailableProducts 
--               table and associated stored procedures.
-- ************************************************

USE ProductAvailability
GO

------------------------------------------------------------
-- TABLE MODIFICATIONS
------------------------------------------------------------


ALTER TABLE UnavailableProducts
ADD [RouteCode] [varchar] (10) DEFAULT ''
GO

------------------------------------------------------------
-- STORED PROCEDURE MODIFICATIONS
------------------------------------------------------------

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

-- Update AddUnavailableProduct

ALTER  procedure AddUnavailableProduct
(
	@Mode varchar(10),
	@Origin varchar(10),
	@Destination varchar(10),
	@TicketCode varchar(10),
	@RouteCode varchar(10),
	@OutwardTravelDate datetime,
	@ReturnTravelDate datetime
)
as
    set nocount on

    insert into UnavailableProducts
    ( 
	Mode,
	Origin,
	Destination,
	TicketCode,
	RouteCode,
	OutwardTravelDate,
	ReturnTravelDate
    )
    values
    (
	@Mode,
	@Origin,
	@Destination,
	@TicketCode,
	@RouteCode,
	@OutwardTravelDate,
	@ReturnTravelDate
    )
GO

-- Update CheckUnavailableProducts

ALTER  procedure CheckUnavailableProducts 
			@Mode varchar(10),
			@Origin varchar(10),
			@Destination varchar(10),
			@TicketCode varchar(10),
			@RouteCode varchar(10),	
			@OutwardTravelDate datetime,
			@ReturnTravelDate datetime
as

set nocount on

select count(*) 
from UnavailableProducts
where Mode = @Mode
and Origin = @Origin
and Destination = @Destination
and TicketCode = @TicketCode
and RouteCode = @RouteCode
and OutwardTravelDate = @OutwardTravelDate
and ((ReturnTravelDate = @ReturnTravelDate) or ((@ReturnTravelDate is null) and (ReturnTravelDate is null)))
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------
-- Update the ChangeCatalogue
----------------------------------

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 438)
BEGIN
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = getDate(),
		Summary = 'Add routecode column to UnavailableProducts table and associated stored procedures.'
	WHERE ScriptNumber = 438
END
ELSE
BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		438,
		getDate(),
		'Add routecode column to UnavailableProducts table and associated stored procedures.'
	)
END
GO