-- ***********************************************
-- NAME 		: DUP0574_JourneyEmissions_InfoLinks.sql
-- DESCRIPTION 		: sql to setup journey emissions info links
-- ************************************************

-- We're adding the following links:

-- Link 1 (INTERNAL) JourneyEmissions.EstimateCarCO2EmissionsInfo
-- Link 2 (INTERNAL) JourneyEmissions.AboutCarCO2Emissions
-- Link 3 (INTERNAL) JourneyEmissions.EstimatingPublicTransportCO2
-- Link 4 (INTERNAL) JourneyEmissions.CO2FromDifferentTransport
-- Link 5 (INTERNAL) JourneyEmissions.ComparingCarAndPublicTransport


-------------------------------------------------------------------------
-- SET UP SUGGESTION LINKS FOR PUBLIC TRANSPORT JOURNEY EMISSIONS PAGE
-------------------------------------------------------------------------
USE [TransientPortal]
GO

------------------------------------------------------------
-- Add the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)

-- Link 1 
SET @RelativeURL = 'Help/HelpCosts.aspx#A3.8'
SET @InternalLinkDescription = 'FAQ - Estimate Car CO2 Emissions Info Link'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

-- Link 2 
SET @RelativeURL = 'Help/HelpCosts.aspx#A3.9'
SET @InternalLinkDescription = 'FAQ - About Car CO2 Emissions'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

-- Link 3 
SET @RelativeURL = 'Help/HelpCosts.aspx#A3.10'
SET @InternalLinkDescription = 'FAQ - Estimating Public Transport CO2'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

-- Link 4 
SET @RelativeURL = 'Help/HelpCosts.aspx#A3.11'
SET @InternalLinkDescription = 'FAQ - CO2 From Different Transport'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription

-- Link 5 
SET @RelativeURL = 'Help/HelpCosts.aspx#A3.12'
SET @InternalLinkDescription = 'FAQ - Comparing Car And Public Transport'
SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @InternalLinkDescription)
	INSERT INTO [InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
	SELECT @InternalLinkID , @RelativeURL, @InternalLinkDescription
GO
------------------------------------------------------------

------------------------------------------------------------
-- Add the Resource Names and text
DECLARE @LinkResourceName varchar(100),
	@LinkResourceNameEN varchar(100),
	@LinkResourceNameCY varchar(100),
	@ResourceNameID INT,
	@ResourceID INT

-- Link 1
SET @LinkResourceName = 'JourneyEmissions.EstimateCarCO2EmissionsInfo'
SET @LinkResourceNameEN = 'Estimating my car�s CO2 emissions'
SET @LinkResourceNameCY = 'Amcangyfrif allyriadau CO2 fy nghar'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-- Link 2
SET @LinkResourceName = 'JourneyEmissions.AboutCarCO2Emissions'
SET @LinkResourceNameEN = 'About car CO2 emissions'
SET @LinkResourceNameCY = 'Ynglyn ag allyriadau CO2 car'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY

-- Link 3
SET @LinkResourceName = 'JourneyEmissions.EstimatingPublicTransportCO2'
SET @LinkResourceNameEN = 'Estimating public transport CO2'
SET @LinkResourceNameCY = 'Amcangyfrif CO2 trafnidiaeth gyhoeddus'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 4
SET @LinkResourceName = 'JourneyEmissions.CO2FromDifferentTransport'
SET @LinkResourceNameEN = 'About CO2 from different sorts of transport'
SET @LinkResourceNameCY = 'Ynglyn � CO2 o wahanol fathau o drafnidiaeth'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY



-- Link 5
SET @LinkResourceName = 'JourneyEmissions.ComparingCarAndPublicTransport'
SET @LinkResourceNameEN = 'Comparing car and public transport CO2'
SET @LinkResourceNameCY = 'Cymharu CO2 car a thrafnidiaeth gyhoeddus'

SET @ResourceNameID = (select MAX(ResourceNameId) from dbo.ResourceName) + 1
SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1

--insert into ResourceName table
IF NOT EXISTS(SELECT * FROM [ResourceName] WHERE [ResourceName] = @LinkResourceName) 
	INSERT INTO [ResourceName] ([ResourceNameId], [ResourceName]) 
	SELECT @ResourceNameID , @LinkResourceName

--insert into Resource table 
IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([Text] = @LinkResourceNameEN))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID, @ResourceNameID, 'en-GB', @LinkResourceNameEN

IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = @LinkResourceNameCY))
	INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
	SELECT @ResourceID + 1, @ResourceNameID, 'cy-GB', @LinkResourceNameCY


GO
------------------------------------------------------------

------------------------------------------------------------
--insert into SuggestionLink table
DECLARE @LinkCategoryID INT, 
	@LinkPriority INT,
	@SuggestionLinkID INT,
	@ResourceNameID INT,
	@InternalExternalLinkID INT,
	@LinkResourceName varchar(100),
	@InternalLinkDescription varchar(500)

-- Link 1
SET @LinkResourceName = 'JourneyEmissions.EstimateCarCO2EmissionsInfo'
SET @InternalLinkDescription = 'FAQ - Estimate Car CO2 Emissions Info Link'
SET @LinkCategoryID = 1
SET @LinkPriority = 320
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1

-- Link 2
SET @LinkResourceName = 'JourneyEmissions.AboutCarCO2Emissions'
SET @InternalLinkDescription = 'FAQ - About Car CO2 Emissions'
SET @LinkCategoryID = 1
SET @LinkPriority = 330
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1


-- Link 3
SET @LinkResourceName = 'JourneyEmissions.EstimatingPublicTransportCO2'
SET @InternalLinkDescription = 'FAQ - Estimating Public Transport CO2'
SET @LinkCategoryID = 1
SET @LinkPriority = 340
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1


-- Link 4
SET @LinkResourceName = 'JourneyEmissions.CO2FromDifferentTransport'
SET @InternalLinkDescription = 'FAQ - CO2 From Different Transport'
SET @LinkCategoryID = 1
SET @LinkPriority = 350
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1

-- Link 5
SET @LinkResourceName = 'JourneyEmissions.ComparingCarAndPublicTransport'
SET @InternalLinkDescription = 'FAQ - Comparing Car And Public Transport'
SET @LinkCategoryID = 1
SET @LinkPriority = 360
SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from dbo.SuggestionLink) + 1
SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @LinkResourceName)
SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @InternalLinkDescription)

IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
	SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, 'Internal', 1

GO
------------------------------------------------------------


------------------------------------------------------------
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'JourneyEmissionsCompareInfo'
SET @ContextDescription = 'Information links for the PT Journey Emissions page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'JourneyEmissions.EstimateCarCO2EmissionsInfo'
SET @LinkCategoryID = 1
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID


-- Link 2
SET @LinkResourceName = 'JourneyEmissions.AboutCarCO2Emissions'
SET @LinkCategoryID = 1
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID

-- Link 3
SET @LinkResourceName = 'JourneyEmissions.EstimatingPublicTransportCO2'
SET @LinkCategoryID = 1
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID

-- Link 4
SET @LinkResourceName = 'JourneyEmissions.CO2FromDifferentTransport'
SET @LinkCategoryID = 1
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID

-- Link 5
SET @LinkResourceName = 'JourneyEmissions.ComparingCarAndPublicTransport'
SET @LinkCategoryID = 1
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID

GO
------------------------------------------------------------



------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 574
SET @ScriptDesc = 'Journey emissions informatiom links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------