-- *************************************************************************************
-- NAME 		: DUP0496_CO2MaxMilesPerGallon_Update.sql
-- DESCRIPTION 		: Updating MaxMilesPerGallon property to 150
--                      : 
-- *************************************************************************************

------------------------
-- Properties Table
------------------------

USE [PermanentPortal]
GO

--CarCosting.MaxConsumptionMilesPerGallon


IF EXISTS (SELECT * FROM Properties WHERE pName = 'CarCosting.MaxConsumptionMilesPerGallon')
  BEGIN
    DELETE FROM Properties WHERE pName = 'CarCosting.MaxConsumptionMilesPerGallon' AND AID='Web'
  END

INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('CarCosting.MaxConsumptionMilesPerGallon', '150', 'Web', 'UserPortal', 0)

GO

------------------------
-- Change Log 
------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 496)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Updating MaxMilesPerGallon property to 150'
    WHERE ScriptNumber = 496
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (496, getDate(), 'Inserted MaxMilesPerGallon property to 150' )
  END
GO