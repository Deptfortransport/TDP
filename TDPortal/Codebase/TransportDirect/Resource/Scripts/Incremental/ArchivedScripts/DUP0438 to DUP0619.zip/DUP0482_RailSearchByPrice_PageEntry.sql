-- ***********************************************
-- NAME 		: DUP0482_RailSearchByPrice_PageEntry.sql
-- DESCRIPTION 		: Addded page entry event type for Rail Search by price page
-- ************************************************

-- INSERT PAGE ENTRY EVENTS
USE Reporting
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindTrainCostInput') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'FindTrainCostInput', 'Find Train Cost Input' FROM PageEntryType
GO



-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 482
SET @ScriptDesc = 'Addded page entry event type for Rail Search by price page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO