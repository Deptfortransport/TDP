-- ************************************************************
-- NAME 	: DUP0603_AddJMD265DatafeedSettings.sql
-- DESCRIPTION 	: Add settings to PermanentPortal for jmd265
-- ************************************************************

USE PermanentPortal
GO

DELETE FROM FTP_CONFIGURATION WHERE DATA_FEED = 'jmd265'
GO

INSERT INTO FTP_CONFIGURATION (FTP_CLIENT, DATA_FEED, IP_ADDRESS, USERNAME, PASSWORD, LOCAL_DIR, REMOTE_DIR, FILENAME_FILTER, MISSING_FEED_COUNTER, MISSING_FEED_THRESHOLD, DATA_FEED_DATETIME, DATA_FEED_FILENAME, REMOVE_FILES)
VALUES (1, 'jmd265', 'LocalHost', 'TDP28Nov', 'sI1732#3-', 'D:/Gateway/dat/Incoming/jmd265', '../jmd265', '*.zip', 0, 1, CONVERT(DATETIME, '01/01/2008', 105), '', 1)
GO

DELETE FROM IMPORT_CONFIGURATION WHERE DATA_FEED = 'jmd265'
GO

INSERT INTO IMPORT_CONFIGURATION (DATA_FEED, IMPORT_CLASS, CLASS_ARCHIVE, IMPORT_UTILITY, PARAMETERS1, PARAMETERS2, PROCESSING_DIR)
VALUES ('jmd265', 'TransportDirect.UserPortal.LocationService.AttractionsAliasImporter', 'D:/Gateway/bin/td.userportal.locationservice.dll', '', '', '', 'D:/Gateway/dat/Processing/jmd265')
GO

DELETE FROM Properties WHERE pname IN ('datagateway.sqlimport.attractionalias.Name', 
					'datagateway.sqlimport.attractionalias.feedname',
					'datagateway.sqlimport.attractionalias.database',
					'datagateway.sqlimport.attractionalias.schemea',
					'datagateway.sqlimport.attractionalias.storedprocedure',
					'datagateway.sqlimport.attractionalias.xmlnamespace',
					'datagateway.sqlimport.attractionalias.xmlnamespacexsi',
					'datagateway.sqlimport.attractionalias.xmlschemalocation',
					'GAZ_StagingDB')


INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('GAZ_StagingDB', 'Server=D03;Initial Catalog=GAZ_Staging;Trusted_Connection=true;', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.Name', 'attractionalias', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.feedname', 'jmd265', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.database', 'GAZ_StagingDB', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.schemea', 'D:\Gateway\bin\xml\AttractionAlias.xsd', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.storedprocedure', 'ImportAttractionAliasData', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.xmlnamespace', 'http://www.transportdirect.info/AttractionAlias', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.xmlnamespacexsi', 'http://www.w3.org/2001/XMLSchema-instance', '', 'DataGateway', 0)

INSERT INTO Properties (pName, pValue, AID, GID, PArtnerId)
VALUES ('datagateway.sqlimport.attractionalias.xmlschemalocation', 'http://www.transportdirect.info/AttractionAlias.xsd', '', 'DataGateway', 0)


-- =============================================  
-- CHANGE LOG
-- =============================================  
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 603
SET @ScriptDesc = 'Add settings to PermanentPortal for jmd265'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-- =============================================  