-- ************************************************************
-- NAME 	: DUP0509_Feedback_StoredProcedures_Update.sql
-- DESCRIPTION 	: Updates and Creates stored procedures to retrieve
--		  feedback and delete feedback records:
-- 			GetSessionData
--			GetUserFeedbackOptions
--			UpdateUserFeedbackToDelete
--			DeleteUserFeedback
-- ************************************************************
--

USE [TDUSerInfo]
GO

------------------------------------------
-- Delete existing procedures
------------------------------------------

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'GetSessionData' )
BEGIN
    DROP PROCEDURE [GetSessionData]
END
GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'GetUserFeedbackOptions' )
BEGIN
    DROP PROCEDURE [GetUserFeedbackOptions]
END
GO


IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'UpdateUserFeedbackToDelete' )
BEGIN
    DROP PROCEDURE [UpdateUserFeedbackToDelete]
END
GO


IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'DeleteUserFeedback' )
BEGIN
    DROP PROCEDURE [DeleteUserFeedback]
END
GO


------------------------------------------
-- Update/Create new stored procedures
------------------------------------------

-- Need to add this datatype to the database
EXECUTE sp_addtype tTextPtr, 'VARBINARY(16)'
GO

-- GetSessionData
-- Retrieves session data from TDUserInfo.UserFeedbackSessionData
-- This sp is similar to that in ASPState (GetDeferredData)
CREATE PROCEDURE [dbo].[GetSessionData] 
(
	@FeedbackId int,
	@SessionId varchar(32), 
	@KeyId char(48) 
)
AS
DECLARE @textptr AS tTextPtr
DECLARE @length AS INT

-- Test for an entry UserFeedbackSessionData
IF EXISTS (SELECT SessionID FROM [dbo].[UserFeedbackSessionData] WHERE FeedbackId = @FeedbackId AND SessionId = @SessionId AND KeyId = @KeyId)
BEGIN
    SELECT
        @textptr = TEXTPTR(SessionItemLong),
        @length = DATALENGTH(SessionItemLong)
    FROM TDUserInfo..UserFeedbackSessionData
    WHERE FeedbackId = @FeedbackId
	  AND SessionId = @SessionId
          AND KeyId = @KeyId
   
     IF @length IS NOT NULL 
	BEGIN
	        READTEXT TDUserInfo..UserFeedbackSessionData.SessionItemLong @textptr 0 @length
	END

    RETURN 0

END
  ELSE
BEGIN
    RETURN -1
END

GO


-- GetUserFeedbackOptions
-- Retrieves Feedback options selected from TDUserInfo.UserFeedbackClassification
CREATE PROCEDURE [dbo].[GetUserFeedbackOptions] 
(
	@FeedbackId int
)
AS
BEGIN
	SELECT 
		[FeedbackId],
		[FeedbackTypeId],
		[Details],
		[Email],
		[DeleteFlag]
	FROM
		[UserFeedbackClassification]
	WHERE
		[FeedbackId] = @FeedbackId
END
GO


-- UpdateUserFeedbackToDelete
-- Updates UserFeedback, UserFeedbackClassification, and UserFeedbackSessionData for deletion
-- for the supplied FeedbackId
CREATE PROCEDURE [dbo].[UpdateUserFeedbackToDelete]
(
	@FeedbackId int,
	@DeleteFlag bit
)
AS
	DECLARE @localized_string_UnableToCarryOutAction AS nvarchar(256)
	
	IF EXISTS (SELECT * FROM [UserFeedbackClassification] WHERE [FeedbackId] = @FeedbackId)
	    SET @localized_string_UnableToCarryOutAction = 'Unable to update records for deletion' + CAST(@FeedbackId AS varchar(50)) + ' in UserFeedbackClassification table'
	    BEGIN
		UPDATE [UserFeedbackClassification]
		SET [DeleteFlag] = @DeleteFlag
		WHERE [FeedbackId] = @FeedbackId
	    END
	
	IF EXISTS (SELECT * FROM [UserFeedbackSessionData] WHERE [FeedbackId] = @FeedbackId)
	    SET @localized_string_UnableToCarryOutAction = 'Unable to update records for deletion' + CAST(@FeedbackId AS varchar(50)) + ' in UserFeedbackSessionData table'
	    BEGIN
		UPDATE [UserFeedbackSessionData]
		SET [DeleteFlag] = @DeleteFlag
		WHERE [FeedbackId] = @FeedbackId
	    END
	
	IF EXISTS (SELECT * FROM [UserFeedback] WHERE [FeedbackId] = @FeedbackId)
	    SET @localized_string_UnableToCarryOutAction = 'Unable to update record for deletion' + CAST(@FeedbackId AS varchar(50)) + ' in UserFeedback table'
	    BEGIN
		UPDATE [UserFeedback]
		SET [DeleteFlag] = @DeleteFlag
		WHERE [FeedbackId] = @FeedbackId
	    END

    IF @@error <> 0
    BEGIN
        raiserror (@localized_string_UnableToCarryOutAction, 1,1)
        RETURN -1
    END
    ELSE
    BEGIN
	RETURN @@rowcount
    END
GO


-- DeleteUserFeedback
-- Deletes all User Feedback rows marked for deletion
-- and those that are in the "In progress" status which are over an hour old
CREATE PROCEDURE [dbo].[DeleteUserFeedback]
AS

DELETE FROM UserFeedbackClassification
WHERE     (DeleteFlag = 1) OR
                      (FeedbackId IN
                          (SELECT DISTINCT UserFeedbackClassification.FeedbackId AS Expr1
                            FROM          UserFeedbackClassification INNER JOIN
                                                   UserFeedback ON UserFeedbackClassification.FeedbackId = UserFeedback.FeedbackId
                            WHERE      (UserFeedback.FeedbackStatus = 'In progress' AND TimeLogged < GETDATE() - 1 )))

DELETE FROM UserFeedbackSessionData
WHERE     (DeleteFlag = 1) OR
                      (FeedbackId IN
                          (SELECT DISTINCT UserFeedbackSessionData.FeedbackId AS Expr1
                            FROM          UserFeedbackSessionData INNER JOIN
                                                   UserFeedback ON UserFeedbackSessionData.FeedbackId = UserFeedback.FeedbackId
                            WHERE      (UserFeedback.FeedbackStatus = 'In progress' AND TimeLogged < GETDATE() - 1 )))


DELETE FROM UserFeedback
WHERE     (DeleteFlag = 1) OR
                      (TimeLogged < GETDATE() - 1) AND (FeedbackStatus = 'In progress')

RETURN 0
GO


-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 509
SET @ScriptDesc = 'Updated User Feedback Get session information stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO