-- ***********************************************
-- NAME 		: DUP0511_Feedback_InternalLink.sql
-- DESCRIPTION 		: Updates the Internal Link to point to the new feedback page
-- ************************************************

USE [TransientPortal]
GO

----------------------------------------------------------------
-- Update internal link
----------------------------------------------------------------

UPDATE [InternalLink]
SET RelativeURL = 'ContactUs/FeedbackPage.aspx'
WHERE RelativeURL = 'ContactUs/FeedbackInitialPage.aspx'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 511
SET @ScriptDesc = 'Updated FeedbackPage Internal Link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
