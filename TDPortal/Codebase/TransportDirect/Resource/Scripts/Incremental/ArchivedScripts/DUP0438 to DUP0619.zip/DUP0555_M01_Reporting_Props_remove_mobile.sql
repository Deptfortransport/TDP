-- *************************************************************************************
-- NAME 		: DUP0555_M01_Reporting_Props_remove_mobile.sql
-- DESCRIPTION 		: Removes the mobile reports from the ReportingProperties database
--			  and moves the last report to reuse its id number
-- Run On Server	: M01
-- *************************************************************************************


USE [ReportProperties]
GO

IF EXISTS (SELECT * FROM ReportProperties WHERE reportNumber = '20' and propertykey = 'Title' and value = 'Mobile Weekly Report')
  BEGIN

    DELETE FROM ReportProperties WHERE reportNumber = '20'

    Update ReportProperties SET reportNumber = '20' WHERE reportNumber = '26'

  END

GO

