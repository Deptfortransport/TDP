-- ***********************************************
-- NAME 	: 		  DUP0448_EES_PartnerRemovalIncReporting.sql
-- DESCRIPTION :	  Remove partners for enhancedexposed services
-- ************************************************

-- Remove the partner from the reporting table
USE [Reporting]
GO

BEGIN
	DELETE FROM Partner 
		WHERE PartnerID = nnn
END
GO

-- Remove the partner from the allowed list of services
USE [PermanentPortal]

BEGIN
	DELETE FROM PartnerAllowedServices 
		WHERE PartnerID = nnn
END

-- Remove the partner from the partner table
BEGIN
	DELETE FROM Partner
WHERE PartnerID = nnn
END

GO


-- Change Log
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 448
SET @ScriptDesc = 'Removes partner id, web service permissions and reporting entries'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO