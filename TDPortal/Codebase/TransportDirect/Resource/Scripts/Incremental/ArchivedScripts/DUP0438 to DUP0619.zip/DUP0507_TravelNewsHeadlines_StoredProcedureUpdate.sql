-- ************************************************************
-- NAME 	: DUP0507_TravelNewsHeadlines_StoredProcedureUpdate.sql
-- DESCRIPTION 	: Adds the Where Clause of IncidentStatus Is Open to the TravelNewsHeadlines SP
-- Date		: 12-Jan-2007
-- ************************************************************


USE TransientPortal
GO

ALTER PROCEDURE dbo.TravelNewsHeadlines
AS
SET NOCOUNT ON


SELECT
	TN.UID,
	TN.SeverityLevel,
	TN.HeadlineText,
	TN.SeverityLevel,
	TN.ModeOfTransport,
	TN.Regions,
	DateDiff(mi, TN.StartDateTime, GetDate()) StartToNowMinDiff
FROM TravelNews TN
	
WHERE TN.SeverityLevel < 4
  AND TN.SeverityLevel <> 1
  AND StartDateTime <=getdate() 
  AND ExpiryDateTime >=getdate()
  AND TN.IncidentStatus ='O'
        AND EXISTS (SELECT * FROM TravelNewsDataSource TNDS1
				INNER JOIN TravelNewsDataSources TNDSS
				ON TNDS1.DataSourceId = TNDSS.DataSourceId
				WHERE TNDS1.UID = TN.UID AND TNDSS.Trusted = 1)
ORDER BY SeverityLevel ASC, StartDateTime DESC

GO

-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 507
SET @ScriptDesc = 'Adds the Where Clause of IncidentStatus Is Open to the TravelNewsHeadlines SP'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO