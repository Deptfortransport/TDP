-- ***********************************************
-- NAME        : DUP0532_Airport_Operators_Stored_Procedure.sql
-- DESCRIPTION : Creates the Local Zonal airport operators
-- ************************************************

USE AirRouteMatrix
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLocalZonalAirportOperators]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[GetLocalZonalAirportOperators]
GO

CREATE PROCEDURE dbo.GetLocalZonalAirportOperators	
AS
BEGIN
	Select A.AirportNaptan, A.OperatorCode, Operators.[Name] AS OperatorName
from 
	( SELECT DISTINCT OriginCode AS AirportNaptan, OperatorCode
		FROM         FlightRoutes
		UNION
		SELECT DISTINCT DestinationCode, OperatorCode
		FROM         FlightRoutes ) A
	INNER JOIN  Operators
	ON Operators.[Code] = A.OperatorCode
	order BY OperatorName
END

GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 532)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Creates the Local Zonal airport operators'
	WHERE ScriptNumber = 532
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (532, (getDate()), 'Creates the Local Zonal airport operators')
GO