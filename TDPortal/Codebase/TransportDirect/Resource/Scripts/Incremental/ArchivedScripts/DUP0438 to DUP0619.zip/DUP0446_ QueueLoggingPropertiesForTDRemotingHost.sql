-- ************************************************************
-- NAME 	: DUP0446_ QueueLoggingPropertiesForTDRemotingHost.sql
-- DESCRIPTION 	: Adds the Queue1 logging property for tdremotinghost
-- ************************************************************
-- *** THIS SCRIPT NEEDS UPDATING FOR ACP TO INCLUDE ALL AP Servers ***

USE PermanentPortal
go

-- Do not forget to delete any properties that will be reintroduced by this script. 

-- CUSTOM EVENT Logging for TDRemotingHost 

-- EES

DELETE FROM properties WHERE pname = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO

DELETE FROM properties WHERE pname = 'Logging.Event.Custom.EnhancedExposedServiceStartEvent.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.EnhancedExposedServiceStartEvent.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO
-- END EES

-- EXP

DELETE FROM properties WHERE pname = 'Logging.Event.Custom.EXP.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.EXP.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO
-- END EXP

-- GATE

DELETE FROM properties WHERE pname = 'Logging.Event.Custom.GATE.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.GATE.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)

-- END GATE 

-- GAZ 
DELETE FROM properties WHERE pname = 'Logging.Event.Custom.GAZ.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0

GO
INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.GAZ.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO
-- END GAZ

-- JourneyRequest 
GO
DELETE FROM properties WHERE pname = 'Logging.Event.Custom.JOURNEYREQUEST.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.JOURNEYREQUEST.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO
-- END JourneyRequest


-- JourneyRequestverbose 
GO
DELETE FROM properties WHERE pname = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO
-- END JourneyRequestverbose

-- JourneyResults
GO
DELETE FROM properties WHERE pname = 'Logging.Event.Custom.JOURNEYRESULTS.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO
INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.JOURNEYRESULTS.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO
-- END JourneyResults

-- JourneyResultsverbose 
GO
DELETE FROM properties WHERE pname = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers' AND
		AID ='TDRemotingHost' AND 
		GID ='TDRemotingHost' AND
		PartnerId = 0
GO
INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers','FILE1 Queue1','TDRemotingHost','TDRemotingHost', 0)
GO
-- END JourneyResultsverbose


-- create new receiverqueue source for appservers.
DELETE FROM properties where pname = 'Receiver.Queue.SourceQueueAP01.Path' AND aid = 'EventReceiverGroup' AND gid = 'ReportDataProvider' AND PartnerId = 0
GO
DELETE FROM properties where pname = 'Receiver.Queue.SourceQueueAP02.Path' AND aid = 'EventReceiverGroup' AND gid = 'ReportDataProvider' AND PartnerId = 0
GO
DELETE FROM properties where pname = 'Receiver.Queue.SourceQueueAP03.Path' AND aid = 'EventReceiverGroup' AND gid = 'ReportDataProvider' AND PartnerId = 0
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Receiver.Queue.SourceQueueAP01.Path','FormatName:DIRECT=OS:AP01\Private$\TDPrimaryQueue','EventReceiverGroup','ReportDataProvider', 0)
GO
INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Receiver.Queue.SourceQueueAP02.Path','FormatName:DIRECT=OS:AP02\Private$\TDPrimaryQueue','EventReceiverGroup','ReportDataProvider', 0)
GO
INSERT INTO properties (pName, pValue, AID, GID, PartnerId) 
VALUES ('Receiver.Queue.SourceQueueAP03.Path','FormatName:DIRECT=OS:AP03\Private$\TDPrimaryQueue','EventReceiverGroup','ReportDataProvider', 0)
GO

-- add queues to eventrecver group
-- *** THIS NEEDS UPDATING FOR ACP TO INCLUDE ALL AP Servers ***
GO

UPDATE properties
SET pValue = pValue + ' SourceQueueAP01'
WHERE pName = 'Receiver.Queue'
AND AID = 'EventReceiverGroup'
AND GID = 'ReportDataProvider'
AND PartnerID = 0

GO

----------------
-- Change Log --
----------------
use PermanentPortal

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 446)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'QueueLoggingPropertiesForTDRemotingHost'
    WHERE ScriptNumber = 446
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (446, getDate(), 'QueueLoggingPropertiesForTDRemotingHost' )
  END
GO