-- *************************************************************************************
-- NAME 		: DUP0491_CO2PageEntry_PrintableJourneyEmissions.sql
-- DESCRIPTION 		: Adds Printable Journey Emissions page
-- *************************************************************************************

USE [Reporting]
GO


------------------------
-- Printable Journey Emissions page entry
------------------------

-- JourneyEmissions.LowMpg
IF EXISTS (SELECT * FROM PageEntryType WHERE PETCode = 'PrintableJourneyEmissions')
  BEGIN
    DELETE FROM PageEntryType WHERE PETCode  = 'PrintableJourneyEmissions'
  END

INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'PrintableJourneyEmissions', 'Journey emissions' FROM PageEntryType

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 491
SET @ScriptDesc = 'Added Printable Journey Emissions page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO