-- ************************************************************
-- NAME 	: DUP0601_UpdateDeferredDataSprocsForDotNet2.sql
-- DESCRIPTION 	: Updates DeferredData Sprocs ForDotNet2
-- ************************************************************

USE ASPState

-- =======================================================
-- Synchronization Script for: [dbo].[usp_GetDeferredData]
-- =======================================================
Print 'Synchronization Script for: [dbo].[usp_GetDeferredData]'
GO
-- Dropping the procedure
DROP PROCEDURE [dbo].[usp_GetDeferredData]
GO


CREATE PROCEDURE dbo.usp_GetDeferredData ( @SessionID nvarchar(88), 
					   					   @KeyID char(48) )
AS
DECLARE @textptr AS tTextPtr
DECLARE @length AS INT
DECLARE @TempSessionID tSessionId

-- Test for an entry in ASPState..ASPStateTempSessions.SessionID Like the Session ID passed in @SessionID
IF EXISTS (SELECT SessionID FROM ASPState..ASPStateTempSessions ats WHERE ats.SessionID = @SessionID)
BEGIN
	
    SELECT @TempSessionID = SessionID FROM ASPState..ASPStateTempSessions WHERE SessionID = @SessionID

    SELECT
        @textptr = TEXTPTR(SessionItemLong),
        @length = DATALENGTH(SessionItemLong)
    FROM AspState..DeferredData
    WHERE SessionID = @TempSessionID
          AND KeyID = @KeyID
   
     IF @length IS NOT NULL 
	BEGIN
	        READTEXT ASPState..DeferredData.SessionItemLong @textptr 0 @length
	END

    RETURN 0

END
ELSE
BEGIN
    RETURN -1
END
GO

-- =======================================================
-- Synchronization Script for: [dbo].[usp_SaveDeferredData]
-- =======================================================
Print 'Synchronization Script for: [dbo].[usp_SaveDeferredData]'
GO

-- Dropping the procedure
DROP PROCEDURE [dbo].[usp_SaveDeferredData]
GO

CREATE PROCEDURE dbo.usp_SaveDeferredData ( @SessionID nvarchar(88), 
					   						@KeyID char(48), 
					    					@SessionItem tSessionItemLong )
AS
DECLARE @TempSessionID tSessionId

-- Test for an entry in ASPStateTempSessions.SessionID Like the Session ID passed in @SessionID
IF EXISTS (SELECT SessionID FROM ASPState..ASPStateTempSessions ats WHERE ats.SessionID = @SessionID )

BEGIN

	-- Test for required Table
	IF EXISTS (SELECT * 
		     FROM INFORMATION_SCHEMA.TABLES 
	      	    WHERE TABLE_NAME = 'DeferredData')
		
	BEGIN -- Table exists so we append or update
	
		SELECT @TempSessionID = SessionID FROM ASPState..ASPStateTempSessions WHERE SessionID = @SessionID
		 
		-- Test for an existing entry
		IF EXISTS (SELECT SessionID FROM DeferredData 
	        	    WHERE SessionID = @TempSessionID 
			      AND KeyID = @KeyID)
	
		BEGIN -- UPDATE an existing entry
	
			UPDATE DeferredData
			   SET SessionItemLong = @SessionItem
	        	 WHERE SessionID = @TempSessionID 
			   AND KeyID = @KeyID
	
		END
		ELSE
		BEGIN -- APPEND a new record
	
			INSERT INTO ASPState..DeferredData (SessionID, KeyID, SessionItemLong)
			     VALUES(@TempSessionID, @KeyID, @SessionItem)
	
		END
	END
	ELSE
	BEGIN -- Table does not exists so we build it
		
		-- TODO: Log the fact that the table was missing
	
		-- Re-create the table 
		CREATE TABLE [DeferredData] (	[SessionId] [nvarchar] (88) COLLATE Latin1_General_CI_AS NOT NULL ,
						[KeyID] [char] (48) COLLATE Latin1_General_CI_AS NOT NULL ,
						[SessionItemLong] [image] NULL ,
						PRIMARY KEY  CLUSTERED ( [SessionId] )  ON [PRIMARY] ,
						CONSTRAINT [U_DeferredData] UNIQUE  NONCLUSTERED ( [KeyID], [SessionId] )  ON [PRIMARY] ,
						CONSTRAINT [FK_DeferredData_ASPStateTempSessions] FOREIGN KEY ( [SessionId] ) 
							REFERENCES [ASPStateTempSessions] ( [SessionId] ) ON DELETE CASCADE 
					    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
	
		-- Now try again
		EXEC ASPState..usp_SaveDeferredData @SessionID, @KeyID, @SessionItem
	
	END
END
GO


-- =======================================================
-- Synchronization Script for: [dbo].[usp_UpdateDeferredData]
-- =======================================================
Print 'Synchronization Script for: [dbo].[usp_UpdateDeferredData]'
GO


drop procedure [dbo].[usp_UpdateDeferredData]
GO

CREATE PROCEDURE dbo.usp_UpdateDeferredData ( @CurrSessionID nvarchar(88), @OldSessionID nvarchar(88) )
AS
    
/* 
***********************************************************************************************************
   NAME 	: usp_UpdateDeferredData
   AUTHOR 	: John Frank
   DATE CREATED : 29-Jan-2007
   DESCRIPTION 	: Stored procedure for Page Landing from Word 2003

***********************************************************************************************************
*/


IF EXISTS (SELECT 1 FROM DeferredData WHERE SessionId = @OldSessionID)
BEGIN

    --Delete all rows with new curr session
    DELETE FROM DeferredData WHERE SessionId = @CurrSessionID

    --Insert for curr session using rows with old session
    INSERT INTO DeferredData (SessionId, KeyID, SessionItemLong)
    (SELECT @CurrSessionID, KeyID, SessionItemLong FROM DeferredData WHERE SessionId = @OldSessionID)

    RETURN 0

END
ELSE
BEGIN
    RETURN -1
END
GO



