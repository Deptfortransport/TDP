-- ************************************************************
-- NAME 	: DUP0458_CarParking_MinimumDataImportStoredProcedure.sql
-- DESCRIPTION 	: Takes XML data string and inserts the data into the 
--                CarParking data structure.
-- ************************************************************

USE TransientPortal

-- Check for existance of the procedure and if it exists drop it.
IF EXISTS (SELECT * FROM information_schema.routines WHERE specific_name = 'ImportCarParkingData')
  BEGIN
   DROP PROCEDURE dbo.ImportCarParkingData
  END

GO

-- Create new stored procedure
CREATE PROCEDURE dbo.ImportCarParkingData (@XML text) AS

	SET NOCOUNT ON

	DECLARE @DocID int
	DECLARE @XMLPathData varchar(50)

	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/'

		-- Start Transaction
		BEGIN TRANSACTION
		DELETE FROM [dbo].[CarParking] 
		DELETE FROM [dbo].[CarParkingAdditionalData] 
		DELETE FROM [dbo].[CarParkingOperator] 
		DELETE FROM [dbo].[CarParkingTrafficNewsRegion]
		DELETE FROM [dbo].[CarParkingAccessPoints]
		DELETE FROM [dbo].[CarParkingNPTGAdminDistrict]
		DELETE FROM [dbo].[CarParkingParkAndRideScheme]
		DELETE FROM [dbo].[CarParkingLinkedNaPTANS] 
		DELETE FROM [dbo].[CarParkingCarParkType] 
		DELETE FROM [dbo].[CarParkingNPTGLocality]
		DELETE FROM [dbo].[CarParkingPaymentType] 
		DELETE FROM [dbo].[CarParkingPaymentMethods] 
		DELETE FROM [dbo].[CarParkingOpeningTimes]
		DELETE FROM [dbo].[CarParkingFacilities] 
		DELETE FROM [dbo].[CarParkingAttractions] 
		DELETE FROM [dbo].[CarParkingFacilitiesType] 
		DELETE FROM [dbo].[CarParkingAttractionType]
		DELETE FROM [dbo].[CarParkingCarParkChargeType] 
		DELETE FROM [dbo].[CarParkingSpaceAvailability] 
		DELETE FROM [dbo].[CarParkingCarParkCharges] 
		DELETE FROM [dbo].[CarParkingCarParkConcessions] 	
		DELETE FROM [dbo].[CarParkingCalendar]
		DELETE FROM [dbo].[CarParkingCarParkSpace] 
		DELETE FROM [dbo].[CarParkingSpaceType]
 
		----------------------------------------------------
		-- Reference Data Tables
		----------------------------------------------------

		-- Car Park Access Points
		INSERT INTO CarParkingAccessPoints (GeocodeType, Easting, Northing, StreetName, BarrierInOperation)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/AccessPoints', 2)
		WITH
		(
			GeocodeType varchar(10),
			Easting varchar(6),
			Northing varchar(6),
			StreetName varchar(100),
			BarrierInOperation varchar(3)
		)
			
			
		-- Car Park Operator
		INSERT INTO CarParkingOperator (OperatorCode, OperatorName, OperatorURL, OperatorTsAndCs, OperatorEmail)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/CarParkOperator', 2)
		WITH
		(
			OperatorCode varchar(50),
			OperatorName varchar(100),
			OperatorURL varchar(2048),
			OperatorTsAndCs varchar(2048),
			OperatorEmail varchar(100)
		)

		
		-- Traffic News Region
		INSERT INTO CarParkingTrafficNewsRegion (RegionName)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/TrafficNewsRegion', 2)
		WITH
		(
			RegionName varchar (100)
		)


		-- Car Park Attraction Type
		INSERT INTO CarParkingAttractionType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/Attractions', 2)
		WITH	
		(
			AttractionTypeCode int,
			AttractionTypeDescription varchar(50)
		)


		-- Car Park Facilties Type
		INSERT INTO CarParkingFacilitiesType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/Facilities', 2)
		WITH
		(
			FacilityTypeCode varchar(100),
			FacilityTypeDescription varchar(100)
		)

		
		-- Car Park Type
		INSERT INTO CarParkingCarParkType (TypeCode, Description)
		SELECT DISTINCT * FROM OPENXML (@DocID, '/CarParkDataImport/CarPark/CarParkAdditionalData/CarParkType', 2)
		WITH
		(
			TypeCode varchar(50),
			TypeDescription varchar(100)
		)


		-- Park and Ride Scheme
		INSERT INTO CarParkingParkAndRideScheme (Location, SchemeUrl, Comments, LocationEasting, LocationNorthing, TransferFrequency, TransferFrom, TransferTo)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/ParkAndRideScheme' ,2)
		WITH
		(
			Location varchar(100),
			SchemeURL varchar(2048),
			Comments varchar(200),
			LocationEasting varchar(6),
			LocationNorthing varchar(6),
			TransferFrequency varchar(100),
			TransferFrom varchar(250),
			TransferTo varchar(250)
		)


		-- NPTG Admin District
		INSERT INTO CarParkingNPTGAdminDistrict (AdminAreaCode, DistrictCode)
		SELECT DISTINCT * FROM OPENXML (@DocId, '/CarParkDataImport/CarPark/NPTGAdminDistrict' ,2)
		WITH
		(
			AdminAreaCode varchar(50),
			DistrictCode varchar(50)
		)

		
		-- Car Parking Table
		INSERT INTO CarParking (
			Reference,
			OperatorId,
			AccessPointsMapId,
			AccessPointsEntranceId,
			AccessPointsExitId,			
			TrafficNewsRegionId,
			ParkAndRideSchemeId,
			NPTGAdminDistrictId,
			Name,
			Location,
			Address,
			Postcode,
			Notes,
			Telephone,
			Url,
			MinCost,
			ParkAndRide,
			StayType,
			PlanningPoint,
			DateRecordLastUpdated,
			WEUDate,
			WEFDate)
		SELECT  X.CarParkRef,
			(SELECT Id FROM CarParkingOperator WHERE operatorcode = x.operatorcode) AS OperatorId,
			(SELECT Id FROM CarParkingAccessPoints WHERE northing = x.mapaccesspointnorthing AND easting = x.mapaccesspointeasting and geocodetype = 'Map') AS AccessPointsMapId,
			(SELECT Id FROM CarParkingAccessPoints WHERE northing = x.entranceaccesspointnorthing AND easting = x.entranceaccesspointeasting and geocodetype = 'Entrance') AS AccessPointsEntranceId,
			(SELECT Id FROM CarParkingAccessPoints WHERE northing = x.exitaccesspointnorthing AND easting = x.exitaccesspointeasting and geocodetype = 'Exit') AS AccessPointsExitId,
			(SELECT Id FROM CarParkingTrafficNewsRegion WHERE regionname = x.trafficnewsregionname) AS RegionId,
			(SELECT Id FROM CarParkingParkAndRideScheme WHERE location = x.ParkAndRideLocation) AS ParkAndRideId,
			(SELECT Id FROM CarParkingNPTGAdminDistrict WHERE adminareacode = x.nptgareacode) as NPTGAdminDistrictId,
			X.CarParkName,
			X.Location,
			X.Address,
			X.PostCode,
			X.Notes,
			X.Telephone,
			X.Url,
			X.MinCostPence,
			X.IsParkAndRide,
			X.StayType,
			X.PlanningPoint,
			X.DateRecordLastUpdated,
			X.WEUDate,
			X.WEFDate	
		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark', 2)
		WITH (	
			CarParkRef varchar(50),
			CarParkName varchar(50),
			Location varchar(50),
			Address varchar(100),
			Postcode varchar(8),
			Notes varchar(250), 
			Telephone varchar(11),
			URL varchar(2048),	
			MinCostPence int,
			IsParkAndRide char(5),
			StayType varchar(10),
			PlanningPoint char(5),
			DateRecordLastUpdated datetime,
			WEUDate datetime,
			WEFDate datetime,
			OperatorCode varchar(100) 'CarParkOperator/OperatorCode',
			EntranceGeoCodeType varchar(10) 'AccessPoints[GeocodeType="Entrance"]/GeocodeType', 
			EntranceAccessPointNorthing varchar(6) 'AccessPoints[GeocodeType="Entrance"]/Northing', 
			EntranceAccessPointEasting varchar(6) 'AccessPoints[GeocodeType="Entrance"]/Easting', 
			MapGeoCodeType varchar(10) 'AccessPoints[GeocodeType="Map"]/GeocodeType', 
			MapAccessPointNorthing varchar(6) 'AccessPoints[GeocodeType="Map"]/Northing', 
			MapAccessPointEasting varchar(6) 'AccessPoints[GeocodeType="Map"]/Easting', 
			ExitGeoCodeType varchar(10) 'AccessPoints[GeocodeType="Exit"]/GeocodeType', 
			ExitAccessPointNorthing varchar(6) 'AccessPoints[GeocodeType="Exit"]/Northing', 
			ExitAccessPointEasting varchar(6) 'AccessPoints[GeocodeType="Exit"]/Easting', 
			TrafficNewsRegionName varchar(100) 'TrafficNewsRegion/RegionName',
			ParkAndRideLocation varchar(100) 'ParkAndRideScheme/Location',
			NPTGAreaCode varchar(5) 'NPTGAdminDistrict/AdminAreaCode'
			) X


		-- Car Park Calendar Elements
		INSERT INTO CarParkingCalendar (
			Start,
			[End],
			Days,
			PublicHols)
		SELECT  X.CalendarStartDate,
			X.CalendarEndDate,
			X.Days,
			X.PublicHolidays
		FROM	
		OPENXML (@docId, '//Calendar', 2)
		WITH (	
			CalendarStartDate datetime,
			CalendarEndDate datetime,
			Days varchar(7),
			PublicHolidays varchar(8)
			) X


		-- Linked NaPTANs
		INSERT INTO CarParkingLinkedNaPTANs (
			StopPointType,
			StopCode,
			InterchangeTime,
			InterchangeMode)
		SELECT  X.StopPointType,
			X.StopCode,
			X.InterchangeTime,
			X.InterchangeMode
 		FROM	
		OPENXML (@docId, '/CarParkDataImport/CarPark/CarParkAdditionalData/LinkedNaPTANs', 2)
		WITH (	
			StopPointType varchar(50),
			StopCode varchar(20),
			InterchangeTime int,
			InterchangeMode varchar(100)
			) X

		COMMIT TRANSACTION
GO

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 458)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Added/Updated import stored procedure for CarParking.'
	WHERE ScriptNumber = 458
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (458, (getDate()), 'Added new import stored procedures for CarParking')
GO