-- ***********************************************
-- NAME 		: DUP0586_DepartureBoard_ExternalLinks.sql
-- DESCRIPTION 		: sql to add the Departure board links to the External links table
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [TransientPortal]
GO
-------------------------------------------------------------------------
-- ADD LINKS
-------------------------------------------------------------------------

-- Train
EXEC AddExternalLink 'DepartureBoard.Train.1', 'http://www.nationalrail.co.uk/ldb/', 'http://www.nationalrail.co.uk/ldb/', 'Departure Board - National Rail'

-- London
EXEC AddExternalLink 'DepartureBoard.London.1', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/tube/default.html', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/tube/default.html', 'Departure Board - TfL'
EXEC AddExternalLink 'DepartureBoard.London.2', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/buses/default.html', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/buses/default.html', 'Departure Board - Bus'
EXEC AddExternalLink 'DepartureBoard.London.3', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/trams/default.html', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/trams/default.html', 'Departure Board - Tram'
EXEC AddExternalLink 'DepartureBoard.London.4', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/dlr/default.html', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/dlr/default.html', 'Departure Board - DLR'
EXEC AddExternalLink 'DepartureBoard.London.5', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/river/default.html', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/river/default.html', 'Departure Board - Thames Riverboat'
EXEC AddExternalLink 'DepartureBoard.London.6', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/tube/default.html', 'http://www.tfl.gov.uk/tfl/livetravelnews/realtime/tube/default.html', 'Departure Board - Tube'
EXEC AddExternalLink 'DepartureBoard.London.7', 'http://www.tfl.gov.uk/tfl/livetravelnews/departureboards/', 'http://www.tfl.gov.uk/tfl/livetravelnews/departureboards/', 'Departure Board - '
EXEC AddExternalLink 'DepartureBoard.London.8', 'http://journeyplanner.tfl.gov.uk/im/RD-T.html', 'http://journeyplanner.tfl.gov.uk/im/RD-T.html', 'Departure Board - '

-- Bus
EXEC AddExternalLink 'DepartureBoard.Bus.1', 'http://www.transportforlancashire.com/bus/index.asp', 'http://www.transportforlancashire.com/bus/index.asp', 'Departure Board - Transport for Lancashire'
EXEC AddExternalLink 'DepartureBoard.Bus.2', 'http://www.acislive.com/', 'http://www.acislive.com/', 'Departure Board - Acis Live'
EXEC AddExternalLink 'DepartureBoard.Bus.3', 'http://www.star-trak.co.uk/', 'http://www.star-trak.co.uk/', 'Departure Board - Star Trak'
EXEC AddExternalLink 'DepartureBoard.Bus.4', 'http://www.citytransport.org.uk/eMerge.html', 'http://www.citytransport.org.uk/eMerge.html', 'Departure Board - City Transport'
EXEC AddExternalLink 'DepartureBoard.Bus.5', 'http://www.help2travel.co.uk/mattisse/all_buses.do', 'http://www.help2travel.co.uk/mattisse/all_buses.do', 'Departure Board - Help2Travel'

GO

-------------------------------------------------------------------------
-- Update display text for each link
-------------------------------------------------------------------------

-- Train
UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.nationalrail.co.uk/ldb/'
WHERE [ID] = 'DepartureBoard.Train.1'
GO

-- London 
UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.tfl.gov.uk/tfl/livetravelnews/realtime/ tube/default.html'
WHERE [ID] = 'DepartureBoard.London.1'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.tfl.gov.uk/tfl/livetravelnews/realtime/ buses/default.html'
WHERE [ID] = 'DepartureBoard.London.2'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.tfl.gov.uk/tfl/livetravelnews/realtime/ trams/default.html'
WHERE [ID] = 'DepartureBoard.London.3'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.tfl.gov.uk/tfl/livetravelnews/realtime/ dlr/default.html'
WHERE [ID] = 'DepartureBoard.London.4'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.tfl.gov.uk/tfl/livetravelnews/realtime/ river/default.html'
WHERE [ID] = 'DepartureBoard.London.5'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.tfl.gov.uk/tfl/livetravelnews/realtime/ tube/default.html'
WHERE [ID] = 'DepartureBoard.London.6'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'www.tfl.gov.uk/tfl/livetravelnews/ departureboards/'
WHERE [ID] = 'DepartureBoard.London.7'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'http://journeyplanner.tfl.gov.uk/im/RD -T.html'
WHERE [ID] = 'DepartureBoard.London.8'
GO

-- Bus
UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'http://www.transportforlancashire.com/bus/ index.asp'
WHERE [ID] = 'DepartureBoard.Bus.1'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'http://www.acislive.com/'
WHERE [ID] = 'DepartureBoard.Bus.2'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'http://www.star-trak.co.uk/'
WHERE [ID] = 'DepartureBoard.Bus.3'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'http://www.citytransport.org.uk/eMerge.html'
WHERE [ID] = 'DepartureBoard.Bus.4'

UPDATE [dbo].[ExternalLinks]
SET [LinkText] = 'http://www.help2travel.co.uk/mattisse/ all_buses.do'
WHERE [ID] = 'DepartureBoard.Bus.5'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 586
SET @ScriptDesc = 'Add Departure board links to external links table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------