-- ***********************************************************************************************
-- NAME 	: DUP0472_NewFindATrainPage.sql
-- DESCRIPTION 	: Updates CMS content on the Find a Train Page and adds new context 
--		  for the page ExpandableMenu
-- ***********************************************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0472_NewFindATrainPage.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:57:58   mmodi
--Initial revision.
--
--   Rev 1.0   Nov 08 2007 12:41:24   mturner
--Initial revision.
--
--   Rev 1.1   Nov 16 2006 19:50:34   dsawe
--added for modifying links in relatedLinksControl 
--Resolution for 4220: Rail Search by Price
--
-- Rev 1.1 Nov 16 2006 17:12:12 dsawe
-- Resolution for 4220: Rail Search by Price ( arranging relatedlinkscontrol in required order)

-- Rev 1.0   Oct 23 2006 15:42:16   kjosling
--Initial revision.
--Resolution for 4220: Rail Search by Price

USE [TransientPortal]
GO

-- ***********************************************************************************************
-- Add new ExpandableMenu context for FindTrainInput page. Wire up to existing links
-- ***********************************************************************************************

IF NOT EXISTS (SELECT * FROM Context WHERE ContextId = '9' AND Name = 'FindTrainInput')

	INSERT INTO [Context] ([ContextId], [Name], [Description])
	SELECT 9, 'FindTrainInput', 'Suggestions for Find A Train input page'

	INSERT INTO [SUGGESTIONLINK] ([SUGGESTIONLINKID], [LINKCATEGORYID], [PRIORITY], [RESOURCENAMEID],            
        [EXTERNALINTERNALLINKID], [EXTERNALINTERNALLINKTYPE], [ISROOT])
	SELECT 58, 6, 25, 2, 2, 'Internal', 0
	UNION
	SELECT 59, 6, 35, 21, 21, 'Internal', 0
	UNION
	SELECT 60, 6, 45, 17, 17, 'Internal', 0
	UNION
	SELECT 61, 6, 55, 16, 16, 'Internal', 0
	UNION
	SELECT 62, 6, 65, 18, 18, 'Internal', 0
	UNION
	SELECT 63, 6, 75, 25, 25, 'Internal', 0
	UNION
	SELECT 64, 6, 85, 3, 3, 'Internal', 0
	

	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT 59, 9, 58
	UNION	
	SELECT 60, 9, 59
	UNION
	SELECT 61, 9, 60
	UNION
	SELECT 62, 9, 61
	UNION
	SELECT 63, 9, 62
	UNION
	SELECT 64, 9, 63
	UNION
	SELECT 65, 9, 64
GO

----------------
-- Change Log --
----------------
USE [PermanentPortal]
GO

DECLARE @ChangeNumber int
DECLARE @ChangeText varchar(200)

SET @ChangeNumber = 472
SET @ChangeText = 'New related links for Find A Train input page'


IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ChangeNumber)

BEGIN
  UPDATE [dbo].[ChangeCatalogue]
  SET ChangeDate = getDate(), Summary = @ChangeText
  WHERE ScriptNumber = @ChangeNumber
END

ELSE

BEGIN
  INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
  VALUES (@ChangeNumber, getDate(), @ChangeText)
END

GO