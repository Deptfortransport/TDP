-- *************************************************************************************
-- NAME 		: DUP0490_CO2ExternalLink_SaveFuel.sql
-- DESCRIPTION 		: Adds How can i save fuel link to External Links table
-- *************************************************************************************

USE [TransientPortal]
GO


------------------------
-- Speedo Scales - Low and High Mpg
------------------------

-- JourneyEmissions.LowMpg
IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.HowCanISaveFuel')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.HowCanISaveFuel'
  END

INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, LinkText)
VALUES ('JourneyEmissions.HowCanISaveFuel', 'http://www.google.co.uk', 'http://www.google.co.uk', '1', 'How can I save Fuel', NULL, NULL, NULL)

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 490
SET @ScriptDesc = 'Added How can i save fuel link to External Links table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO