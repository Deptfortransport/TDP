-- ***********************************************
-- NAME 		: DUP0528_CO2_PT_Properties_Update.sql
-- DESCRIPTION 		: Properties update for journey emission distance factors
-- ************************************************

----------------------------------------
-- Update Properties
----------------------------------------

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.AirDistanceFactor')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.AirDistanceFactor'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.AirDistanceFactor', '1.09', 'Web', 'UserPortal', 0)
GO


IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Small')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Small'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.Distance.Air.Small', '70', 'Web', 'UserPortal', 0)
GO


IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Medium')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Air.Medium'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.Distance.Air.Medium', '480', 'Web', 'UserPortal', 0)
GO

----------------------------------------
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 528
SET @ScriptDesc = 'Updates to journey emission distance properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO