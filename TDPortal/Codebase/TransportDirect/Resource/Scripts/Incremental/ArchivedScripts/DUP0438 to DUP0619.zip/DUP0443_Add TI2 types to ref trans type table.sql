-- ***********************************************
-- AUTHOR      	: John Frank
-- NAME 	: DUP0443_Add TI2 types to ref trans type table.sql
-- DESCRIPTION 	: Adds the types for the TI2 traveline injected transactions to the
--                ReferenceTransactionType table
-- Additional Steps Required : None
-- ************************************************

USE Reporting

DECLARE @idnum INT

Select @idnum=max(RTTID)FROM dbo.ReferenceTransactionType
SET @idnum = @idnum + 1


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'Check1')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'Check1', 'TL Test', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'CheckNE')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'CheckNE', 'TL NE Test', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'Scotland')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'Scotland', 'TL Scotland', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'NorthWest')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'NorthWest', 'TL NorthWest', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'SouthEast')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'SouthEast', 'TL SouthEast', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'Wales')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'Wales', 'TL Wales', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'Yorkshire')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'Yorkshire', 'TL Yorkshire', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'NationalExpress')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'NationalExpress', 'TL NationalExpress', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'WestMidlands')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'WestMidlands', 'TL WestMidlands', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'SouthWest')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'SouthWest', 'TL SouthWest', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'EastMidlands')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'EastMidlands', 'TL EastMidlands', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'NorthEast')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'NorthEast', 'TL NorthEast', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END


IF NOT EXISTS (SELECT * FROM ReferenceTransactionType WHERE RTTCode = 'EastAnglia')
BEGIN

  INSERT INTO ReferenceTransactionType (RTTID, RTTCode, RTTDescription, RTTCreditInclude, RTTSLAInclude, RTTMaxMsDuration, RTTTarget, RTTThreshold)
  VALUES (@idnum, 'EastAnglia', 'TL EastAnglia', 0, 0, 0, 95, 90)

  SET @idnum = @idnum + 1

END

