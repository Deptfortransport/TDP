-- ***********************************************
-- Name :        DUP0566_CreateNewAtosAdditionalData_Objects.sql
-- DESCRIPTION : Creates the AtosAddtionalData Database, tables and stored procedures.
-- NB: Please check file paths specified below - they will need changing when this script is run at BBP Test/DR.
-- ************************************************


-----------------------------------------------
-- Create the Database
-----------------------------------------------

USE master
GO

IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'AtosAdditionalData')
	DROP DATABASE [AtosAdditionalData]
GO

CREATE DATABASE AtosAdditionalData ON (NAME = N'AtosAdditionalData', FILENAME = N'D:\Microsoft SQL Server\MSSQL\Data\AtosAdditionalData.mdf' , SIZE = 4, FILEGROWTH = 10%) LOG ON (NAME = N'AtosAdditionalData_log', FILENAME = N'L:\Logs\AtosAdditionalData_log.LDF' , FILEGROWTH = 10%)
 COLLATE SQL_Latin1_General_CP1_CI_AS
GO

USE AtosAdditionalData
GO

-- --------------------------------------------------------------------------------------------
-- SET OPTIONS --
-- --------------------------------------------------------------------------------------------


exec sp_dboption N'AtosAdditionalData ', N'autoclose', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'bulkcopy', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'trunc. log', N'true'
GO

exec sp_dboption N'AtosAdditionalData ', N'torn page detection', N'true'
GO

exec sp_dboption N'AtosAdditionalData ', N'read only', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'dbo use', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'single', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'autoshrink', N'true'
GO

exec sp_dboption N'AtosAdditionalData ', N'ANSI null default', N'true'
GO

exec sp_dboption N'AtosAdditionalData ', N'recursive triggers', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'ANSI nulls', N'true'
GO

exec sp_dboption N'AtosAdditionalData ', N'concat null yields null', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'cursor close on commit', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'default to local cursor', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'quoted identifier', N'false'
GO

exec sp_dboption N'AtosAdditionalData ', N'ANSI warnings', N'true'
GO

exec sp_dboption N'AtosAdditionalData ', N'auto create statistics', N'true'
GO

exec sp_dboption N'AtosAdditionalData ', N'auto update statistics', N'true'
GO

if( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) )
	exec sp_dboption N'AtosAdditionalData ', N'db chaining', N'false'
GO


-- --------------------------------------------------------------------------------------------
-- GRANT PERMISSIONS --
-- --------------------------------------------------------------------------------------------

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE name = N'DFTSIW\ASPUSER')
	EXEC sp_grantdbaccess N'DFTSIW\ASPUSER', N'DFTSIW\ASPUSER'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE NAME = N'BBPDFTW\ASPUSER')
	EXEC sp_grantdbaccess N'BBPDFTW\ASPUSER', N'BBPDFTW\ASPUSER'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE NAME = N'ACPDFTW\ASPUSER')
	EXEC sp_grantdbaccess N'ACPDFTW\ASPUSER', N'ACPDFTW\ASPUSER'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE name = N'DFTSIS\ASPUSER_S')
	EXEC sp_grantdbaccess N'DFTSIS\ASPUSER_S', N'DFTSIS\ASPUSER_S'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE NAME = N'BBPDFTS\ASPUSER_S')
	EXEC sp_grantdbaccess N'BBPDFTS\ASPUSER_S', N'BBPDFTS\ASPUSER_S'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE NAME = N'ACPDFTS\ASPUSER_S')
	EXEC sp_grantdbaccess N'ACPDFTS\ASPUSER_S', N'ACPDFTS\ASPUSER_S'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE name = N'DFTSIS\-service-tng')
	EXEC sp_grantdbaccess N'DFTSIS\-service-tng', N'DFTSIS\-service-tng'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE NAME = N'BBPDFTS\-service-tng')
	EXEC sp_grantdbaccess N'BBPDFTS\-service-tng', N'BBPDFTS\-service-tng'
GO

IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE NAME = N'ACPDFTS\-service-tng')
	EXEC sp_grantdbaccess N'ACPDFTS\-service-tng', N'ACPDFTS\-service-tng'
GO

EXEC sp_addrolemember N'db_datareader', N'DFTSIW\ASPUSER'
GO

EXEC sp_addrolemember N'db_datareader', N'BBPDFTW\ASPUSER'
GO

EXEC sp_addrolemember N'db_datareader', N'ACPDFTW\ASPUSER'
GO

EXEC sp_addrolemember N'db_datawriter', N'DFTSIW\ASPUSER'
GO

EXEC sp_addrolemember N'db_datawriter', N'BBPDFTW\ASPUSER'
GO

EXEC sp_addrolemember N'db_datawriter', N'ACPDFTW\ASPUSER'
GO

USE AtosAdditionalData
GO


-----------------------------------------------
-- Create Taxi_Operators
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects 
where id = object_id(N'dbo.Taxi_Operators') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE dbo.Taxi_Operators (
	[NaptanCode] [Varchar] (12) NOT NULL,
	[DestinationName] [Varchar] (255) NOT NULL,
	[TraintaxiLink] [Integer] NOT NULL,
	[CommentLine] [Varchar] (500),
	[AccessibilityText] [Varchar] (500),
	[Firm1Name] [Varchar] (255),
	[Firm2Name] [Varchar] (255),
	[Firm3Name] [Varchar] (255),
	[Firm4Name] [Varchar] (255),
	[Firm1Phone] [Varchar] (20),
	[Firm2Phone] [Varchar] (20),
	[Firm3Phone] [Varchar] (20),
	[Firm4Phone] [Varchar] (20),
	[Firm1Accessibility] [Char] (1),
	[Firm2Accessibility] [Char] (1),
	[Firm3Accessibility] [Char] (1),
	[Firm4Accessibility] [Char] (1),
	[GOTO1Name] [Varchar] (255),
	[GOTO2Name] [Varchar] (255),
	[GOTO3Name] [Varchar] (255),
	[GOTO4Name] [Varchar] (255),
	[GOTO1Link] [Integer],
	[GOTO2Link] [Integer],
	[GOTO3Link] [Integer],
	[GOTO4Link] [Integer],
	[Copyright] [Varchar] (255),
	[Type] [Varchar] (12) NOT NULL,
	[Source] [Varchar] (12) NOT NULL,
	[Version] [Integer] NOT NULL ) 
END
GO

-----------------------------------------------
-- Create NaPTAN_Logical_Group
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects 
where id = object_id(N'dbo.NaPTAN_Logical_Group') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [NaPTAN_Logical_Group] (
	[AtcoCode] [varchar] (12) NOT NULL ,
	[LogicalID] [varchar] (12) NOT NULL ,
	[Version] [integer] )
END
GO

---------------------------------------
-- Add Rows to ChangeNotification Table
---------------------------------------

USE [PermanentPortal]
GO


IF EXISTS (SELECT * FROM ChangeNotification WHERE [Table] = 'TaxiOperators')
  BEGIN
    DELETE FROM ChangeNotification WHERE [Table] = 'TaxiOperators'
  END

INSERT INTO ChangeNotification ([version], [Table])
VALUES (0, 'TaxiOperators')


IF EXISTS (SELECT * FROM ChangeNotification WHERE [Table] = 'NaPTAN_Logical_Group')
  BEGIN
    DELETE FROM ChangeNotification WHERE [Table] = 'NaPTAN_Logical_Group'
  END

INSERT INTO ChangeNotification ([version], [Table])
VALUES (0, 'NaPTAN_Logical_Group')

GO

-------------------------------------------
-- Add MergeTaxiOperatorData Stored Procedure
-------------------------------------------

USE AtosAdditionalData
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[MergeTaxiOperatorData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[MergeTaxiOperatorData]
GO

-- procedure that merges Taxi Operator data in with "real" NaPTANs for 9000 codes
CREATE  PROCEDURE dbo.MergeTaxiOperatorData
AS 

SET NOCOUNT ON 

	
-- Start Transaction
BEGIN TRANSACTION
	
	-- Delete any previously mapped rows for this version of the data
	DELETE FROM dbo.Taxi_Operators 
	WHERE	Taxi_Operators.Type = 'Mapped' AND Taxi_Operators.Version =
			(SELECT     Version
			FROM          PermanentPortal.Dbo.ChangeNotification
			WHERE      [TABLE] = 'TaxiOperators')
			
	IF @@ERROR<>0
		GOTO ERR_HANDLER

	-- Merge in the new data from the NaPTAN_Lookup table - flag it as "Mapped"
	-- to distinguish it from data which has come in directly from a TrainTaxi feed
	INSERT INTO dbo.Taxi_Operators 
	(NaptanCode, DestinationName, TraintaxiLink, CommentLine, AccessibilityText, 
	Firm1Name, Firm2Name, Firm3Name, Firm4Name, 
	Firm1Phone, Firm2Phone, Firm3Phone, Firm4Phone, 
	Firm1Accessibility, Firm2Accessibility, Firm3Accessibility, Firm4Accessibility, 
	GOTO1Name, GOTO2Name, GOTO3Name, GOTO4Name, 
	GOTO1Link, GOTO2Link, GOTO3Link, GOTO4Link, 
	Copyright, Type, Source, Version)
	SELECT  
	NaPTAN_Logical_Group.ATCOCode, Taxi_Operators.DestinationName, Taxi_Operators.TraintaxiLink, 
	Taxi_Operators.CommentLine, Taxi_Operators.AccessibilityText, 
	Taxi_Operators.Firm1Name, Taxi_Operators.Firm2Name, Taxi_Operators.Firm3Name, Taxi_Operators.Firm4Name, 
	Taxi_Operators.Firm1Phone, Taxi_Operators.Firm2Phone, Taxi_Operators.Firm3Phone, Taxi_Operators.Firm4Phone, 
	Taxi_Operators.Firm1Accessibility, Taxi_Operators.Firm2Accessibility, 
	Taxi_Operators.Firm3Accessibility, Taxi_Operators.Firm4Accessibility, 
	Taxi_Operators.GOTO1Name, Taxi_Operators.GOTO2Name, Taxi_Operators.GOTO3Name, Taxi_Operators.GOTO4Name, 
	Taxi_Operators.GOTO1Link, Taxi_Operators.GOTO2Link, Taxi_Operators.GOTO3Link, Taxi_Operators.GOTO4Link, 
	Taxi_Operators.Copyright, 'Mapped', Taxi_Operators.Source, Taxi_Operators.Version
	FROM         
	Taxi_Operators INNER JOIN NaPTAN_Logical_Group ON Taxi_Operators.NaptanCode = NaPTAN_Logical_Group.LogicalID
	WHERE     (Taxi_Operators.Version =
	                          (SELECT     Version
	                            FROM          PermanentPortal.Dbo.ChangeNotification
	                            WHERE      [TABLE] = 'TaxiOperators')) 
	AND (NaPTAN_Logical_Group.Version =
	                          (SELECT     Version
	                            FROM          PermanentPortal.Dbo.ChangeNotification
	                            WHERE      [TABLE] = 'NaPTAN_Logical_Group'))
	AND (Taxi_Operators.NaptanCode <> NaPTAN_Logical_Group.AtcoCode)
	
	IF @@ERROR<>0
		GOTO ERR_HANDLER
		
	
	
	COMMIT TRANSACTION
	RETURN 0
		
		
ERR_HANDLER:
	ROLLBACK TRANSACTION
	RETURN 1
	
GO


GRANT EXECUTE ON [MergeTaxiOperatorData] TO [DFTSIW\ASPUSER]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [BBPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [ACPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [DFTSIS\ASPUSER_S]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [BBPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [ACPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [DFTSIS\-service-tng]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [BBPDFTS\-service-tng]
GO
GRANT EXECUTE ON [MergeTaxiOperatorData] TO [ACPDFTS\-service-tng]
GO

-------------------------------------------
-- Add ImportTrainTaxiData Stored Procedure
-------------------------------------------

USE AtosAdditionalData
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportTrainTaxiData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ImportTrainTaxiData]
GO


CREATE    PROCEDURE dbo.ImportTrainTaxiData (@XML text) AS

	SET NOCOUNT ON

	DECLARE @DocID int
	DECLARE @RetCode int
	DECLARE @XMLPathData varchar(50)

	DECLARE @LatestTaxiOperatorsVersion int

	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/'


	--Get Next Version number
	SET @LatestTaxiOperatorsVersion = 
	(SELECT Version + 1 FROM PermanentPortal.Dbo.ChangeNotification WHERE [Table] = 'TaxiOperators')

	-- Start Transaction
	BEGIN TRANSACTION

	----------------------------------------------------
	-- Insert Into Data Table
	----------------------------------------------------

		INSERT INTO Taxi_Operators
			(
			NaptanCode,
			DestinationName, 
			TraintaxiLink, 
			CommentLine, 
			AccessibilityText, 
			Firm1Name, 
			Firm2Name, 
			Firm3Name, 
			Firm4Name, 
			Firm1Phone, 
			Firm2Phone, 
			Firm3Phone, 
			Firm4Phone, 
			Firm1Accessibility, 
			Firm2Accessibility, 
			Firm3Accessibility, 
			Firm4Accessibility, 
			GOTO1Name, 
			GOTO2Name, 		
			GOTO3Name, 
			GOTO4Name, 
			GOTO1Link, 
			GOTO2Link, 
			GOTO3Link, 
			GOTO4Link, 
			Copyright, 
			Type, 
			Source, 
			Version
		)
		SELECT  
			XmlDoc.NaPTANcode,
			XmlDoc.destinationname,
			XmlDoc.traintaxilink,
			XmlDoc.commentline,
			XmlDoc.accessibilitytext,
			XmlDoc.firm1name,
			XmlDoc.firm2name,
			XmlDoc.firm3name,
			XmlDoc.firm4name,
			XmlDoc.firm1phone,
			XmlDoc.firm2phone,
			XmlDoc.firm3phone,
			XmlDoc.firm4phone,
			XmlDoc.firm1accessibility,
			XmlDoc.firm2accessibility,
			XmlDoc.firm3accessibility,
			XmlDoc.firm4accessibility,
			XmlDoc.GOTO1name,
			XmlDoc.GOTO2name,
			XmlDoc.GOTO3name,
			XmlDoc.GOTO4name,
			XmlDoc.GOTO1link,
			XmlDoc.GOTO2link,
			XmlDoc.GOTO3link,
			XmlDoc.GOTO4link,
			XmlDoc.copyright,
			'Actual',
			'TrainTaxi',
			@LatestTaxiOperatorsVersion

		FROM
		OPENXML (@DocID, 'FMPXMLRESULT/Row',2)
		WITH
			(NaPTANcode Varchar(12),
			destinationname Varchar(255),
			traintaxilink Integer,
			commentline Varchar(500),
			accessibilitytext Varchar(500),
			firm1name Varchar(255),
			firm2name Varchar(255),
			firm3name Varchar(255),
			firm4name Varchar(255),
			firm1phone Varchar(20),
			firm2phone Varchar(20),
			firm3phone Varchar(20),
			firm4phone Varchar(20),
			firm1accessibility Char(1),
			firm2accessibility Char(1),
			firm3accessibility Char(1),
			firm4accessibility Char(1),
			GOTO1name Varchar(255),
			GOTO2name Varchar(255),
			GOTO3name Varchar(255),
			GOTO4name Varchar(255),
			GOTO1link Integer,
			GOTO2link Integer,
			GOTO3link Integer,
			GOTO4link Integer,
			copyright Varchar(255)) XmlDoc


	IF @@ERROR<>0
		GOTO ERR_HANDLER


	--Housekeep old data
	DELETE FROM Taxi_Operators WHERE Version < (@LatestTaxiOperatorsVersion - 2 )
	
	IF @@ERROR<>0
		GOTO ERR_HANDLER

	--Update Change Notification Version number
	UPDATE PermanentPortal.Dbo.ChangeNotification SET Version = @LatestTaxiOperatorsVersion
	WHERE [Table] = 'TaxiOperators'
	
	IF @@ERROR<>0
		GOTO ERR_HANDLER

	--Merge in the latest NaPTAN lookup data
	EXEC @RetCode = MergeTaxiOperatorData
	IF @RetCode <> 0
		GOTO ERR_HANDLER
	
	EXEC sp_xml_removedocument @DocID
	
	COMMIT TRANSACTION
	RETURN 0
	

ERR_HANDLER:
	EXEC sp_xml_removedocument @DocID
	ROLLBACK TRANSACTION
	RETURN 1
GO

GRANT EXECUTE ON [ImportTrainTaxiData] TO [DFTSIW\ASPUSER]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [BBPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [ACPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [DFTSIS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [BBPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [ACPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [DFTSIS\-service-tng]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [BBPDFTS\-service-tng]
GO
GRANT EXECUTE ON [ImportTrainTaxiData] TO [ACPDFTS\-service-tng]
GO

-------------------------------------------
-- Add ImportCoachNaptanLookupData Stored Procedure
-------------------------------------------

USE AtosAdditionalData
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportCoachNaptanLookupData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ImportCoachNaptanLookupData]
GO


CREATE    PROCEDURE dbo.ImportCoachNaptanLookupData (@XML text) AS

	SET NOCOUNT ON

	DECLARE @DocID int
	DECLARE @RetCode int
	DECLARE @XMLPathData varchar(50)

	DECLARE @LatestNaPTAN_Logical_GroupVersion int

	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/'
	
	-- Start Transaction
	BEGIN TRANSACTION

	----------------------------------------------------
	-- Insert Into Data Table
	----------------------------------------------------
	
		--Get Next Version number
		SET @LatestNaPTAN_Logical_GroupVersion = 
		(SELECT Version + 1 FROM PermanentPortal.Dbo.ChangeNotification WHERE [Table] = 'NaPTAN_Logical_Group')

		INSERT INTO NaPTAN_Logical_Group
			(
			AtcoCode, 
			LogicalID, 
			Version
			)
		SELECT DISTINCT  
			XmlDoc.ATCOCode,
			XmlDoc.LogicalID,
			@LatestNaPTAN_Logical_GroupVersion
		FROM
		OPENXML (@DocID, 'CoachNaPTANLookups/NaPTAN',2)
		WITH
			(ATCOCode Varchar(12),
			LogicalID Varchar(12)
			) XmlDoc

	IF @@ERROR<>0
		GOTO ERR_HANDLER
		
	--Housekeep old data
	DELETE FROM NaPTAN_Logical_Group WHERE Version < (@LatestNaPTAN_Logical_GroupVersion - 2 )

	IF @@ERROR<>0
		GOTO ERR_HANDLER
		
	--Update Change Notification Version number
	UPDATE PermanentPortal.Dbo.ChangeNotification SET Version = @LatestNaPTAN_Logical_GroupVersion
	WHERE [Table] = 'NaPTAN_Logical_Group'

	IF @@ERROR<>0
		GOTO ERR_HANDLER

	--Merge in the latest NaPTAN lookup data
	EXEC @RetCode = MergeTaxiOperatorData
	IF @RetCode <> 0
		GOTO ERR_HANDLER
	
	EXEC sp_xml_removedocument @DocID
	
	COMMIT TRANSACTION
	RETURN 0
	

ERR_HANDLER:
	EXEC sp_xml_removedocument @DocID
	ROLLBACK TRANSACTION
	RETURN 1

GO

GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [DFTSIW\ASPUSER]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [BBPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [ACPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [DFTSIS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [BBPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [ACPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [DFTSIS\-service-tng]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [BBPDFTS\-service-tng]
GO
GRANT EXECUTE ON [ImportCoachNaptanLookupData] TO [ACPDFTS\-service-tng]
GO

-------------------------------------------
-- Add usp_GetTrainTaxiData Stored Procedure
-------------------------------------------

USE AtosAdditionalData
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_GetTrainTaxiData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_GetTrainTaxiData]
GO


-- create usp_GetTrainTaxiData stored procedure
/*
Returns latest version data row from the Taxi_Operators table for the supplied 
NaPTAN Code.  
*/
CREATE PROCEDURE dbo.usp_GetTrainTaxiData
 @Naptan varchar(12)
AS
BEGIN

DECLARE @GOTO1Link int, @GOTO2Link int, @GOTO3Link int, @GOTO4Link int
DECLARE @RequestedNaptan varchar(12)
DECLARE @TrainTaxiVersion int

--Store actual NaPTAN that was requested
SET @RequestedNaptan = @Naptan

--Get latest version for use in queries
SET @TrainTaxiVersion = (SELECT Version FROM PermanentPortal.Dbo.ChangeNotification WHERE [Table] = 'TaxiOperators')

--Manipulate Airport NaPTAN to use the overall airport record for multi terminal or single terminal airports, if required.
IF @Naptan LIKE '9200___'
	IF NOT EXISTS(SELECT NaptanCode FROM Taxi_Operators WHERE Taxi_Operators.NaptanCode = @Naptan)
		IF EXISTS(SELECT NaptanCode FROM Taxi_Operators WHERE Taxi_Operators.NaptanCode = @Naptan + '0')
			-- Use the overall airport record for a multi terminal airport - ends in "0"
			SET @Naptan =  @Naptan + '0'
		ELSE
			-- Use the overall airport record for a single terminal airport - ends in "1"
			SET @Naptan =  @Naptan + '1'

--Get the GOTO Links
SELECT
@GOTO1Link = GOTO1Link, @GOTO2Link = GOTO2Link, @GOTO3Link = GOTO3Link, @GOTO4Link = GOTO4Link
FROM
	Taxi_Operators
WHERE
	Taxi_Operators.NaptanCode = @Naptan
	AND Taxi_Operators.Version = @TrainTaxiVersion

--Now get the Traintaxi record and associated goto link records
--Only get top 1 so we dont get duplicates if we have both types
--Return the NaPTAN code as the one actually passed in
SELECT TOP 1
@RequestedNaptan, DestinationName, TraintaxiLink, CommentLine, AccessibilityText, 
Firm1Name, Firm2Name, Firm3Name, Firm4Name, 
Firm1Phone, Firm2Phone, Firm3Phone, Firm4Phone, 
Firm1Accessibility, Firm2Accessibility, Firm3Accessibility, Firm4Accessibility, 
GOTO1Name, GOTO2Name, GOTO3Name, GOTO4Name, GOTO1Link, GOTO2Link, GOTO3Link, GOTO4Link, 
Copyright, Type, Source, Version
FROM
	Taxi_Operators
WHERE
	Taxi_Operators.NaptanCode = @Naptan
	AND Taxi_Operators.Version = @TrainTaxiVersion
UNION 
SELECT
NaptanCode, DestinationName, TraintaxiLink, CommentLine, AccessibilityText, 
Firm1Name, Firm2Name, Firm3Name, Firm4Name, 
Firm1Phone, Firm2Phone, Firm3Phone, Firm4Phone, 
Firm1Accessibility, Firm2Accessibility, Firm3Accessibility, Firm4Accessibility, 
GOTO1Name, GOTO2Name, GOTO3Name, GOTO4Name, GOTO1Link, GOTO2Link, GOTO3Link, GOTO4Link, 
Copyright, Type, Source, Version
FROM
	Taxi_Operators
WHERE
	Taxi_Operators.TraintaxiLink IN (@GOTO1Link, @GOTO2Link, @GOTO3Link, @GOTO4Link)
	AND Taxi_Operators.Version = @TrainTaxiVersion
	AND Taxi_Operators.Type = 'Actual'
END
GO


GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [DFTSIW\ASPUSER]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [BBPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [ACPDFTW\ASPUSER]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [DFTSIS\ASPUSER_S]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [BBPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [ACPDFTS\ASPUSER_S]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [DFTSIS\-service-tng]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [BBPDFTS\-service-tng]
GO
GRANT EXECUTE ON [usp_GetTrainTaxiData] TO [ACPDFTS\-service-tng]
GO


-------------------------------------------------
-- Update the ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 566)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Added AtosAdditionalData DB and Objects'
	WHERE ScriptNumber = 566
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (566, (getDate()), 'Added AtosAdditionalData DB and Objects')
GO
