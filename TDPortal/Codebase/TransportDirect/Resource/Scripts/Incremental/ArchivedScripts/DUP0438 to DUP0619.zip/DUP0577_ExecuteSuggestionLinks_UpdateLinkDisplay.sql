-- ***********************************************
-- NAME 		: DUP0577_ExecuteSuggestionLinks_UpdateLinkDisplay
-- DESCRIPTION 		: Update C02 Emmissions (Suggestion Links).
--			: Change link from "About CO2 from different sorts of transport" to
--			: "About bus and and coach journeys"
-- AUTHOR		: Neil Rankin
-- ************************************************


-- EXEC UpdateSuggestionLinkDisplayText
-- StringLinkResourceName		varchar(100), 	-- ResourceName of suggestion link must be known
-- StringLinkResourceNameEN	varchar(100), 	-- New display text, English
-- StringLinkResourceNameCY	varchar(100)	-- New display text, Welsh

USE TransientPortal
GO


EXEC UpdateSuggestionLinkDisplayText
	'JourneyEmissions.CO2FromDifferentTransport',
	'About bus and and coach journeys', 
	'Dybio am siwrneiau bws a choets'
GO

------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 577
SET @ScriptDesc = 'Update C02 Emmissions (Suggestion Links) UpdateLinkDisplay'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------