-- ************************************************************
-- NAME 	: DUP0536_Update_LocalZonalPhase2&3_Import_SP.sql
-- DESCRIPTION 	: Updates the zonal service import data to import Opertor urls and admin district urls
-- ************************************************************

USE [TransientPortal]
GO

---------------------------------------------------------------------
-- Update ZonalServiceImportTask
----------------------------------------------------------------------

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


ALTER    PROCEDURE dbo.ZonalServiceImportTask
(
	@XML text
)
AS

SET NOCOUNT ON
SET XACT_ABORT ON

DECLARE @DocID int, @RowCount int, @XMLPathData varchar(50), @DefaultSortNumber int 
DECLARE @NaPTANCode varchar(12), @ZonalServiceURL varchar(500), @LinkTextDesc varchar(200)
DECLARE @WithEffectFromDate varchar(10), @WithEffectToDate varchar(10), @ExternalLinksID varchar(500)

DECLARE @RegionId varchar(20), @OperatorCode varchar(20), @ModeId varchar(20)
DECLARE	@OperatorURL varchar(500), @OperatorLinkDescription varchar(200)
DECLARE	@OperatorFaresZoneURL varchar(500), @OperatorFaresLinkDescription varchar(200)
DECLARE	@OperatorMapURL varchar(500), @OperatorMapLinkDescription varchar(200)
DECLARE @ExternalLinksOperatorID varchar (500), @ExternalLinksFaresZoneID varchar (500), @ExternalLinksMapID varchar (500)

DECLARE @AdminAreaId varchar(20), @DistrictId varchar(20)
DECLARE @AdminFaresZoneURL varchar(500), @AdminFaresLinkDescription varchar (200)

 
-- Loading xml document 
EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
-- set the node 
SET @XMLPathData =  '/zonalservices/PlusBus'

BEGIN TRANSACTION

	--delete all zonal services data
	if EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'dbo.ZonalStop') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		SELECT DISTINCT ExternalLinkID into #tempZonalStop FROM ZonalStop

		IF OBJECT_ID('tempdb..#tempZonalStop') IS NOT NULL 
		BEGIN
			--delete zonal services data
			DELETE FROM ZonalStop	

			--finally delete temp table
	    		DROP TABLE #tempZonalStop
		END
	END


	--delete all zonal operator links data
	if EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'dbo.ZonalOperatorLinks') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		SELECT DISTINCT OperatorLinkId, OperatorFaresLinkId, OperatorMapLinkId into #tempZonalOperatorLinks FROM ZonalOperatorLinks

		IF OBJECT_ID('tempdb..#tempZonalOperatorLinks') IS NOT NULL 
		BEGIN
			--delete zonal services operator data
			DELETE FROM ZonalOperatorLinks	

			--finally delete temp table
	    		DROP TABLE #tempZonalOperatorLinks
		END
	END


	--delete all zone admin district data
	if EXISTS (SELECT * FROM dbo.sysobjects where id = object_id(N'dbo.ZonalAdminDistrictLinks') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		SELECT DISTINCT AdminAreaFaresLinkId into #tempZonalAdminDistrictLinks FROM ZonalAdminDistrictLinks

		IF OBJECT_ID('tempdb..#tempZonalAdminDistrictLinks') IS NOT NULL 
		BEGIN
			--delete zonal services admin district data
			DELETE FROM ZonalAdminDistrictLinks	

			--finally delete temp table
	    		DROP TABLE #tempZonalAdminDistrictLinks
		END
	END


	--use a cursor to insert data because we are inserting into more than one table
	--Insert into tables
	DECLARE cursorZonal CURSOR FOR
		SELECT 
			X.NaPTANCode, 
			X.ZonalServiceURL, 		
			X.HyperlinkDescription,		
			X.WithEffectFromDate, 
			X.WithEffectToDate
		FROM
		OPENXML (@DocID, @XMLPathData, 2)
		WITH
		(	
			NaPTANCode varchar(12) ,
			ZonalServiceURL varchar(500) ,				
			HyperlinkDescription varchar(200),
			WithEffectFromDate varchar(10),
			WithEffectToDate varchar(10)
		) X 
	
	OPEN cursorZonal

	FETCH NEXT FROM cursorZonal INTO 
		@NaPTANCode, @ZonalServiceURL, @LinkTextDesc, @WithEffectFromDate, @WithEffectToDate

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	WHILE @@FETCH_STATUS = 0
	BEGIN
		if @NaPTANCode <> ''
		begin

		SELECT @ExternalLinksID = NEWID()

		INSERT INTO ExternalLinks ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
		VALUES(@ExternalLinksID, 
				@ZonalServiceURL, 
				@ZonalServiceURL, 
				CONVERT(datetime, @WithEffectFromDate, 103),
				CONVERT(datetime, @WithEffectToDate, 103),
				@LinkTextDesc, 
				'Added by Zonal Import - Plus')

		INSERT INTO ZonalStop (Naptan, ExternalLinkID)
		VALUES(@NaPTANCode,	@ExternalLinksID)

		end

		-- This is executed as long as the previous fetch succeeds.
		FETCH NEXT FROM cursorZonal INTO 
			@NaPTANCode, @ZonalServiceURL, @LinkTextDesc, @WithEffectFromDate, @WithEffectToDate
	END
	
	CLOSE cursorZonal
	DEALLOCATE cursorZonal 




	--use a cursor to insert data because we are inserting into more than one table
	--Insert into tables
	DECLARE cursorZonalOperator CURSOR FOR
		SELECT 
			X.RegionId, 
			X.OperatorCode, 		
			X.ModeId,
			X.OperatorURL,
			X.OperatorLinkDescription,
			X.OperatorFaresZoneURL,
			X.OperatorFaresLinkDescription,
			X.OperatorMapURL,
			X.OperatorMapLinkDescription,
			X.WithEffectFromDate, 
			X.WithEffectToDate
		FROM
		OPENXML (@DocID, @XMLPathData, 2)
		WITH
		(	
			RegionId varchar(20),
			OperatorCode varchar(20),	
			ModeId varchar(20),
			OperatorURL varchar(500),
			OperatorLinkDescription varchar(200),
			OperatorFaresZoneURL varchar(500),
			OperatorFaresLinkDescription varchar(200),
			OperatorMapURL varchar(500),
			OperatorMapLinkDescription varchar(200),
			WithEffectFromDate varchar(10),
			WithEffectToDate varchar(10)
		) X 
	
	OPEN cursorZonalOperator

	FETCH NEXT FROM cursorZonalOperator INTO 
		@RegionId, @OperatorCode, @ModeId, 
		@OperatorURL, @OperatorLinkDescription,
		@OperatorFaresZoneURL, @OperatorFaresLinkDescription,
		@OperatorMapURL, @OperatorMapLinkDescription,
		@WithEffectFromDate, @WithEffectToDate

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @ExternalLinksOperatorID = NULL 
		SET @ExternalLinksFaresZoneID = NULL
		SET @ExternalLinksMapID = NULL

		if @RegionId <> ''
		begin

			if @OperatorURL <> ''
			begin
				SELECT @ExternalLinksOperatorID = NEWID()
				INSERT INTO ExternalLinks ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
				VALUES(		@ExternalLinksOperatorID, 
						@OperatorURL, 
						@OperatorURL, 
						CONVERT(datetime, @WithEffectFromDate, 103),
						CONVERT(datetime, @WithEffectToDate, 103),
						@OperatorLinkDescription, 
						'Added by Zonal Import - Operator')
			end

			if @OperatorFaresZoneURL <> ''
			begin
				SELECT @ExternalLinksFaresZoneID = NEWID()
				INSERT INTO ExternalLinks ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
				VALUES(		@ExternalLinksFaresZoneID, 
						@OperatorFaresZoneURL, 
						@OperatorFaresZoneURL, 
						CONVERT(datetime, @WithEffectFromDate, 103),
						CONVERT(datetime, @WithEffectToDate, 103),
						@OperatorFaresLinkDescription, 
						'Added by Zonal Import - Operator - Fare')
			end

			if @OperatorMapURL <> ''
			begin
				SELECT @ExternalLinksMapID = NEWID()
				INSERT INTO ExternalLinks ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
				VALUES(		@ExternalLinksMapID, 
						@OperatorMapURL, 
						@OperatorMapURL, 
						CONVERT(datetime, @WithEffectFromDate, 103),
						CONVERT(datetime, @WithEffectToDate, 103),
						@OperatorMapLinkDescription, 
						'Added by Zonal Import - Operator - Map')
			end

		INSERT INTO ZonalOperatorLinks (RegionId, OperatorCode, ModeId, OperatorLinkId, OperatorFaresLinkId, OperatorMapLinkId)
		VALUES(		@RegionId, @OperatorCode, @ModeId,
				@ExternalLinksOperatorID, @ExternalLinksFaresZoneID, @ExternalLinksMapID)

		end

		-- This is executed as long as the previous fetch succeeds.
		FETCH NEXT FROM cursorZonalOperator INTO 
			@RegionId, @OperatorCode, @ModeId, 
			@OperatorURL, @OperatorLinkDescription,
			@OperatorFaresZoneURL, @OperatorFaresLinkDescription,
			@OperatorMapURL, @OperatorMapLinkDescription,
			@WithEffectFromDate, @WithEffectToDate
	END
	
	CLOSE cursorZonalOperator
	DEALLOCATE cursorZonalOperator



	--use a cursor to insert data because we are inserting into more than one table
	--Insert into tables
	DECLARE cursorZonalAdmin CURSOR FOR
		SELECT 
			X.AdminAreaId, 
			X.DistrictId, 		
			X.AdminFaresZoneURL,
			X.AdminFaresLinkDescription,
			X.WithEffectFromDate,
			X.WithEffectToDate
		FROM
		OPENXML (@DocID, @XMLPathData, 2)
		WITH
		(	
			AdminAreaId varchar(20) ,
			DistrictId varchar(20) ,				
			AdminFaresZoneURL varchar(500) ,				
			AdminFaresLinkDescription varchar(200),
			WithEffectFromDate varchar(10),
			WithEffectToDate varchar(10)
		) X 
	
	OPEN cursorZonalAdmin

	FETCH NEXT FROM cursorZonalAdmin INTO 
		@AdminAreaId, @DistrictId, @AdminFaresZoneURL, @AdminFaresLinkDescription, @WithEffectFromDate, @WithEffectToDate

	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	WHILE @@FETCH_STATUS = 0
	BEGIN

		if @AdminAreaId <> ''
		begin

		SELECT @ExternalLinksID = NEWID()

		INSERT INTO ExternalLinks ([Id], URL, TestURL, StartDate, EndDate, LinkText, [Description])
		VALUES(		@ExternalLinksID, 
				@AdminFaresZoneURL, 
				@AdminFaresZoneURL, 
				CONVERT(datetime, @WithEffectFromDate, 103),
				CONVERT(datetime, @WithEffectToDate, 103),
				@AdminFaresLinkDescription, 
				'Added by Zonal Import - Admin District')

		INSERT INTO ZonalAdminDistrictLinks (AdminAreaId, DistrictId, AdminAreaFaresLinkId)
		VALUES(@AdminAreaId, @DistrictId, @ExternalLinksID)

		end

		-- This is executed as long as the previous fetch succeeds.
		FETCH NEXT FROM cursorZonalAdmin INTO 
			@AdminAreaId, @DistrictId, @AdminFaresZoneURL, @AdminFaresLinkDescription, @WithEffectFromDate, @WithEffectToDate
	END
	
	CLOSE cursorZonalAdmin
	DEALLOCATE cursorZonalAdmin 





	-- Remove xml doc from memorry
	EXEC sp_xml_removedocument @DocID

	IF @@ERROR<>0
		ROLLBACK TRANSACTION
	ELSE
	BEGIN
		COMMIT TRANSACTION		
		
		UPDATE ChangeNotification
		SET Version = Version + 1
		WHERE [Table] = 'ZonalStop'
	END



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 536
SET @ScriptDesc = 'Updated again ZonalServiceImportTask stored procedure for Operator and Admin District zonal data'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO