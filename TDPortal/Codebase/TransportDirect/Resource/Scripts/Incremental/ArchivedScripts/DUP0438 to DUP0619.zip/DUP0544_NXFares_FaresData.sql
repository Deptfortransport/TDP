-- ***********************************************
-- NAME	       : DUP0544_NXFares_FaresData.sql
-- DESCRIPTION : Adds the new NX Fares ticket types data
-- ************************************************

USE [PermanentPortal]

TRUNCATE TABLE [CoachFares]
INSERT INTO [CoachFares]([FareTypeCode], [Description], [Amendable], [Refundable], [RestrictionPriority], [Action]) 
select 'FLX', 'Flexible', 1,  1, 1, 'IN'
union select 'ANR', 'Amendable', 1, 0, 2, 'IN'
union select 'RNA', 'Refundable', 0, 1, 3, 'IN'
union select 'RST', 'Restricted', 0, 0, 4, 'IN'



-------------------------------------------------
-- Update the ChangeCatalogue
-------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 544
SET @ScriptDesc = 'Added new NX Fares ticket types data'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO