-- ***********************************************
-- NAME 		: DUP0460_FindCarParkSetup_Update.sql
-- DESCRIPTION 		: Updated car park intial search radius value and
-- 			: page entry events
-- ************************************************

USE PermanentPortal
GO


-- UPDATE FIND CAR PARK PROPERTY
UPDATE Properties
SET pValue = '16092'
WHERE pName = 'FindNearestCarParks.InitialRadius'
GO


-- INSERT PAGE ENTRY EVENTS
USE Reporting
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindCarParkResults') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'FindCarParkResults', 'Nearest car park results for a location' FROM PageEntryType
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindCarParkMap') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription) 
SELECT MAX(PETID)+1, 'FindCarParkMap', 'Nearest car parks map for a location' FROM PageEntryType 
GO

IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableCarParkMap') 
INSERT INTO PageEntryType(PETID, PETCode, PETDescription) 
SELECT MAX(PETID)+1, 'PrintableCarParkMap', 'Printable car park results map page' FROM PageEntryType 
GO


-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 460
SET @ScriptDesc = 'Updated find car park intial search radius and page entry events'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO