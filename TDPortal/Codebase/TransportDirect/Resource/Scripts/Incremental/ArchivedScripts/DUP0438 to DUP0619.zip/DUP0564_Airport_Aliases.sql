-- ***********************************************
-- NAME 		: DUP0564_Airport_Aliases.sql
-- DESCRIPTION 		: Inserts Aliases for a number of airports that are often know by alternate names.
-- ************************************************

Use GAZ
GO

UPDATE gazadmin.ExchangeAlias SET Aliasname = 'Turnhouse Airport'
WHERE Naptan = '9200EDI' AND Aliasname = 'Edinburgh' AND record_type = 'A'
 
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ABZ','Dyce Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BEB','Balivanich Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BHX','Birmingham Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BLK','Blackpool Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BOH','Bournemouth Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BRR','North Bay Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BRS','Bristol Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CAL','Machrihanish Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CBG','Cambridge Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CVT','Baginton Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CWL','Cardiff Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200DCS','Robin Hood Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200DND','Dundee Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200EMA','Nottingham East Midlands Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ESH','Brighton Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200EXT','Exeter Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200GLA','Glasgow Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200GLO','Gloucester Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ILY','Glenegedal Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200INV','Dalcross Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ISC','St Mary''s Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200KOI','Kirkwall Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LBA','Bradford Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LEQ','St Just Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LGW','Gatwick Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LHR','Heathrow Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LPL','John Lennon Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LTN','Luton Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LWK','Tingwall Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LYX','Lydd Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200MAN','Manchester Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200MME','Tees Valley Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200MSE','Manston Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200NCL','Newcastle Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200NQY','St Mawgan Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200NWI','Norwich Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200OXF','Kidlington Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200PIK','Prestwick Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200PLH','Plymouth Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SEN','Southend Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SOU','Southampton Eastleigh Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200STN','Stansted Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SWS','Fairwood Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SZD','Sheffield Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200TSO','Tresco Airport','A')
GO

Use GAZ_Staging
GO

UPDATE gazadmin.ExchangeAlias SET Aliasname = 'Turnhouse Airport'
WHERE Naptan = '9200EDI' AND Aliasname = 'Edinburgh' AND record_type = 'A'

INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ABZ','Dyce Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BEB','Balivanich Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BHX','Birmingham Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BLK','Blackpool Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BOH','Bournemouth Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BRR','North Bay Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200BRS','Bristol Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CAL','Machrihanish Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CBG','Cambridge Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CVT','Baginton Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200CWL','Cardiff Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200DCS','Robin Hood Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200DND','Dundee Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200EMA','Nottingham East Midlands Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ESH','Brighton Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200EXT','Exeter Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200GLA','Glasgow Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200GLO','Gloucester Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ILY','Glenegedal Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200INV','Dalcross Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200ISC','St Mary''s Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200KOI','Kirkwall Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LBA','Bradford Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LEQ','St Just Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LGW','Gatwick Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LHR','Heathrow Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LPL','John Lennon Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LTN','Luton Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LWK','Tingwall Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200LYX','Lydd Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200MAN','Manchester Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200MME','Tees Valley Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200MSE','Manston Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200NCL','Newcastle Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200NQY','St Mawgan Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200NWI','Norwich Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200OXF','Kidlington Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200PIK','Prestwick Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200PLH','Plymouth Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SEN','Southend Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SOU','Southampton Eastleigh Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200STN','Stansted Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SWS','Fairwood Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200SZD','Sheffield Airport','A')
INSERT INTO gazadmin.ExchangeAlias (Naptan, Aliasname, record_type) VALUES ('9200TSO','Tresco Airport','A')
GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 564
SET @ScriptDesc = 'Inserts Airport Aliases'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO