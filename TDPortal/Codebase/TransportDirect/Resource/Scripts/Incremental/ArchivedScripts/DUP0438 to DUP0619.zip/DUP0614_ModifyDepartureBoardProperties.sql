-- ***********************************************
-- NAME 		: DUP0614_ModifyDepartureBoardProperties.sql
-- DESCRIPTION 		: sql to add FirstToday,FirstTomorrow,LastToday & LastTomorrow options to Enhanced Exposed Services
--	
-- ************************************************

USE [PermanentPortal]
GO

--------------------------------------------------------------------------------------
-- DELETE DROPDOWN ITEM IF ALREADY THERE - MAY HAVE BEEN ADDED WITH INCORRECT SPELLING
--------------------------------------------------------------------------------------

DELETE FROM [PermanentPortal].[dbo].[DropDownLists]
WHERE ([DataSet] = 'MobileTimeRequestDrop') and ([SortOrder] > 4 )
GO

----------------------------------------
-- INSERT DROPDOWN ITEM
----------------------------------------

--insert into DropDownLists table 
IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'LastToday'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'LastToday', 'LastToday', 0, 5, 0)
GO

IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'LastTomorrow'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'LastTomorrow', 'LastTomorrow', 0, 6, 0)
GO

IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'FirstToday'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'FirstToday', 'FirstToday', 0, 7, 0)
GO

IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'FirstTomorrow'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'FirstTomorrow', 'FirstTomorrow', 0, 8, 0)
GO


--------------------------------------------------------------------------------------
-- Set Past Time Window to 24hrs so we will return historic data for requests in past
--------------------------------------------------------------------------------------
UPDATE [PermanentPortal].[dbo].[properties]
SET [pValue]= '1440'
WHERE [pName] = 'DepartureBoardService.PastTimeWindow'


----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 614
SET @ScriptDesc = 'sql to amend FirstToday,FirstTomorrow,LastToday,LastTomorrow & PastTimeWindow options in Enhanced Exposed Services'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO