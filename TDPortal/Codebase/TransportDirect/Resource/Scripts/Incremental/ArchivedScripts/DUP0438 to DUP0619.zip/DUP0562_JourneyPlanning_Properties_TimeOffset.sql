-- ***********************************************
-- NAME 		: DUP0562_JourneyPlanning_Properties_TimeOffset.sql
-- DESCRIPTION 		: Adds a new property that specifies a number of minutes. We will allow users to plan journeys for this 
--			  far in the past.
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE PROPERTIES
----------------------------------------

-- NUMBER OF CAR PARKS 
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyPlanningOffset')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyPlanningOffset'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyPlanningOffset', '90', 'Web', 'UserPortal', 0)

GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 562
SET @ScriptDesc = 'Added new JourneyPlanningOffset property'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO