-- *************************************************************************************
-- NAME 			: DUP0451_UpdateRTTIPropsV6.sql
-- DESCRIPTION 		: Update RTTI Schema to V6
-- *************************************************************************************
USE PermanentPortal
GO

UPDATE Properties
SET pValue = '<?xml version="1.0" ?> 
<Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="------" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">
<StationReq>
<ByCRS crs="---" /> 
</StationReq>
</Eport>' 
WHERE pName = 'DepartureBoardService.RTTIManager.RequestTemplate.StationRequestByCRS' 
	AND AID= 'ExposedServices'
	AND GID= 'UserPortal'
	AND PartnerId ='0'


UPDATE Properties
SET pValue = '<?xml version="1.0"?>
<Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="-----" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">
<TrainReq>
<ByRID rid="-----" /> 
</TrainReq>
</Eport>'
WHERE pName = 'DepartureBoardService.RTTIManager.RequestTemplate.TrainRequestByRID'
	AND AID= 'ExposedServices'
	AND GID= 'UserPortal'
	AND PartnerId ='0'

UPDATE Properties
SET pValue = '<?xml version="1.0" ?> 
<Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="-----" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">
<TripReq>
<ByCRS main="---" interest="-----" time="-----" secondary="---" dur="120"/> 
</TripReq>
</Eport>'
WHERE pName = 'DepartureBoardService.RTTIManager.RequestTemplate.TripRequestByCRS'
	AND AID= 'ExposedServices'
	AND GID= 'UserPortal'
	AND PartnerId ='0'

UPDATE Properties
SET pValue = 'http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd'
WHERE pName = 'DepartureBoardService.RTTIManager.SchemaNamespace'
	AND AID= 'ExposedServices'
	AND GID= 'UserPortal'
	AND PartnerId ='0'



----------------
-- Change Log --
----------------
use PermanentPortal
go

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 451)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Update RTTI Schema to V6'
    WHERE ScriptNumber = 451
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (451, getDate(), 'Update RTTI Schema to V6' )
  END
GO