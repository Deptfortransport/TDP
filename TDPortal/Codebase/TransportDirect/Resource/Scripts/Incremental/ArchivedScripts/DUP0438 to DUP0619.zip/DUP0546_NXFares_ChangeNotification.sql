-- ************************************************************
-- NAME 	: DUP0546_NXFares_ChangeNotification.sql
-- DESCRIPTION 	: Creates entry for CoachFares table in
--		  ChangeNotificationTable to ensure that updates are automatically propagated
-- ************************************************************

------------------------------
-- ChangeNotification Table
-----------------------------

USE [PermanentPortal]
GO

--------------------------------------------------

IF EXISTS (SELECT * FROM ChangeNotification WHERE [Table] = 'CoachFares')
  BEGIN
    DELETE FROM ChangeNotification WHERE [Table] = 'CoachFares'
  END

INSERT INTO ChangeNotification ([version], [Table])
VALUES (1, 'CoachFares')

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 546
SET @ScriptDesc = 'Added CoachFares to Change Notification table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO