-- ************************************************************
-- NAME 	: DUP0506_Feedback_StoredProcedures_GetSession.sql
-- DESCRIPTION 	: Creates stored procedures to obtain
--		  Session data needed for the User Feedback table
-- ************************************************************
--

USE [TDUSerInfo]
GO

------------------------------------------
-- Delete existing procedures
------------------------------------------

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'GetSessionCreatedDateTime' )
BEGIN
    DROP PROCEDURE [GetSessionCreatedDateTime]
END
GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'GetSessionExpiryDateTime' )
BEGIN
    DROP PROCEDURE [GetSessionExpiryDateTime]
END
GO

IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TDUserInfo' 
              AND ROUTINE_NAME = 'AddSessionData' )
BEGIN
    DROP PROCEDURE [AddSessionData]
END
GO


------------------------------------------
-- Create new stored procedures
------------------------------------------

-- GetSessionCreatedDateTime
CREATE PROCEDURE [dbo].[GetSessionCreatedDateTime]
(
	@SessionId varchar(50),
	@Created datetime OUTPUT
)
AS
BEGIN
	SELECT @SessionId = RTRIM(@SessionId) + '%'
	SET @Created = (SELECT	[Created]
			FROM	ASPState.dbo.ASPStateTempSessions
			WHERE	[SessionId] LIKE @SessionId)
END
GO


-- GetSessionExpiryDateTime
CREATE PROCEDURE [dbo].[GetSessionExpiryDateTime]
(
	@SessionId varchar(50),
	@Expires datetime OUTPUT
)
AS
BEGIN
	SELECT @SessionId = RTRIM(@SessionId) + '%'
	SET @Expires = (SELECT	[Expires]
			FROM	ASPState.dbo.ASPStateTempSessions
			WHERE	[SessionId] LIKE @SessionId)
END
GO


-- GetSessionData
CREATE PROCEDURE [dbo].[AddSessionData]
(
	@FeedbackId varchar(50),
	@SessionId varchar(50)
)
AS
BEGIN
	SELECT @SessionId = RTRIM(@SessionId) + '%'

	INSERT INTO UserFeedbackSessionData
	(
		FeedbackId,
		SessionId,
		KeyId,
		SessionItemLong,
		DeleteFlag
	)
	SELECT
		@FeedbackId AS Expr1,
		SessionId,
		KeyId,
		SessionItemLong,
		0 AS Expr2
	FROM
		ASPState.dbo.DeferredData
	WHERE
		SessionId LIKE @SessionId
END
GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 506
SET @ScriptDesc = 'Added User Feedback Get session information stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO