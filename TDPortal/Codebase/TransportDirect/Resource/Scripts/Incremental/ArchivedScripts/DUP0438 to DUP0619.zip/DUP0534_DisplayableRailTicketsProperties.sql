-- ***********************************************
-- NAME :        DUP0534_DisplayableRailTicketsProperties
-- DESCRIPTION : Create seperate displayable rail tickets properties for Microsite and Portal
-- ************************************************

USE PermanentPortal

DELETE FROM properties
WHERE pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query'

INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
VALUES ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query','SELECT KeyName, Value, Category FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''','Microsite','','0')

INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
VALUES ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query','SELECT KeyName, Value, Category, TicketGroup FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''','TDRemotingHost','TDRemotingHost','0')

INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
VALUES ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query','SELECT KeyName, Value, Category, TicketGroup FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''','Web','','0')

-------------------------------------------------
-- Update the ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 534)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Displayable rail tickets properties for Microsite and Portal'
	WHERE ScriptNumber = 534
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (534, (getDate()), 'Displayable rail tickets properties for Microsite and Portal')
GO
