-- ***********************************************
-- NAME 	: 		  DUP0447_EES_PartnerSubscriptionRemoval.sql
-- DESCRIPTION :	  Remove partner password and permissions  
--					  for enhancedexposed services
-- ************************************************

-- Remove the partner from the allowed list of services
USE [PermanentPortal]

BEGIN
	DELETE FROM PartnerAllowedServices 
		WHERE PartnerID = nnn
END

-- Remove the partner password from the partner table
BEGIN
	UPDATE Partner
		SET PartnerPassword = NULL
	WHERE PartnerId = nnn
END
GO

-- Change Log
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 447
SET @ScriptDesc = 'Removes partner password and service permissions for web services'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO