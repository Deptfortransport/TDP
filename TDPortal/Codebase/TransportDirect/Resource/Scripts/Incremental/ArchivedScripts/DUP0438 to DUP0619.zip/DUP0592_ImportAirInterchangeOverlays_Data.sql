-- ***********************************************
-- NAME 		: DUP0592_ImportAirInterchangeOverlays_Data
-- DESCRIPTION 		: Create data for the AirInterchangeOverlays process
--			: 
-- AUTHOR		: Steve Craddock
-- ************************************************

Use PermanentPortal
go
--insert into AirInterchangeOverlays values

insert into AirInterchangeOverlays values
(1,5,'Barra North Bay Airport','9200BRR1','NaPTAN','UKOS',69450,805950,NULL,NULL,NULL,'Barra North Bay Airport','9200BRR1','NaPTAN','UKOS',69450,805950,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(2,5,'Eday Airport','9200EOI1','NaPTAN','UKOS',356150,1034250,NULL,NULL,NULL,'Eday Airport','9200EOI1','NaPTAN','UKOS',356150,1034250,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(3,5,'Fair Isle Airport','9200FIE1','NaPTAN','UKOS',421120,1072220,NULL,NULL,NULL,'Fair Isle Airport','9200FIE1','NaPTAN','UKOS',421120,1072220,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(4,5,'Foula Airport','9200FOA1','NaPTAN','UKOS',397030,1137650,NULL,NULL,NULL,'Foula Airport','9200FOA1','NaPTAN','UKOS',397030,1137650,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(5,5,'North Ronaldsay Airport','9200NRL1','NaPTAN','UKOS',375550,1053650,NULL,NULL,NULL,'North Ronaldsay Airport','9200NRL1','NaPTAN','UKOS',375550,1053650,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(6,5,'Papa Stour Airport','9200PSV1','NaPTAN','UKOS',417275,1159780,NULL,NULL,NULL,'Papa Stour Airport','9200PSV1','NaPTAN','UKOS',417275,1159780,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(7,5,'Papa Westray Airport','9200PPW1','NaPTAN','UKOS',348950,1052050,NULL,NULL,NULL,'Papa Westray Airport','9200PPW1','NaPTAN','UKOS',348950,1052050,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(8,5,'Sanday Airport','9200NDY1','NaPTAN','UKOS',367310,1040810,NULL,NULL,NULL,'Sanday Airport','9200NDY1','NaPTAN','UKOS',367310,1040810,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(9,5,'Stronsay Airport','9200SOY1','NaPTAN','UKOS',363480,1029860,NULL,NULL,NULL,'Stronsay Airport','9200SOY1','NaPTAN','UKOS',363480,1029860,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(10,5,'Unst Airport','9200UNT1','NaPTAN','UKOS',462750,1207650,NULL,NULL,NULL,'Unst Airport','9200UNT1','NaPTAN','UKOS',462750,1207650,NULL,NULL,NULL)

insert into AirInterchangeOverlays values
(11,5,'Westray Airport','9200WRY1','NaPTAN','UKOS',345980,1052030,NULL,NULL,NULL,'Westray Airport','9200WRY1','NaPTAN','UKOS',345980,1052030,NULL,NULL,NULL)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 592
SET @ScriptDesc = 'Create data for the AirInterchangeOverlays process'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------