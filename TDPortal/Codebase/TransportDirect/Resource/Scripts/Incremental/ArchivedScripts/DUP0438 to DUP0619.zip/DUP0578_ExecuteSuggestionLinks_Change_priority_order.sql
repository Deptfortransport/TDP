-- ***********************************************
-- NAME 		: DUP0578_ExecuteSuggestionLinks_Change_priority_order
-- DESCRIPTION 		: Update C02 Emmissions (Suggestion Links).
--			: Change priority order of links
-- AUTHOR		: Neil Rankin
-- ************************************************



USE TransientPortal
GO


	DECLARE @StringLinkResourceName		varchar(100),
		@LinkCategoryName 		varchar(100),
		@LinkPriority			INT


	DECLARE @ResourceNameID INT,
		@SuggestionLinkID INT,
		@LinkCategoryID INT

		SET @StringLinkResourceName	= 'JourneyEmissions.ComparingCarAndPublicTransport'
		SET @LinkCategoryName 		= 'General'
		SET @LinkPriority		= 345

		SET @LinkCategoryID = (select LinkCategoryID from [dbo].[LinkCategory] where [Name] = @LinkCategoryName)
		SET @ResourceNameID = (select ResourceNameId from [dbo].[ResourceName] where [ResourceName] = @StringLinkResourceName)
		SET @SuggestionLinkID = (SELECT MAX(SuggestionLinkID) FROM [dbo].[SuggestionLink] WHERE [LinkCategoryId] = @LinkCategoryID
					AND [ResourceNameID] = @ResourceNameID)


		UPDATE [dbo].[SuggestionLink]
		SET [Priority] = @LinkPriority
		WHERE [SuggestionLinkId] = @SuggestionLinkID

GO

------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 578
SET @ScriptDesc = 'Change priority order of links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------