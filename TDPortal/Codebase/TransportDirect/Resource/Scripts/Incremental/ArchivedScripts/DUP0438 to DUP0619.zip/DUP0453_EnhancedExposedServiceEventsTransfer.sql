-- ***********************************************
-- NAME :        DUP0453_EnhancedExposedServiceEventsTransfer.sql
-- DESCRIPTION : Correct transfer stored procedure so accumulates date/time correctly.
-- ************************************************

use ReportStagingDB
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferEnhancedExposedServicesEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[TransferEnhancedExposedServicesEvents]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO


-- Create Stored Procedure to aggregate data and move it to Reporting DB

CREATE PROCEDURE TransferEnhancedExposedServicesEvents

	@Date varchar(10)

AS

SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

DELETE FROM ReportServer.Reporting.dbo.EnhancedExposedServiceEvents
	WHERE CONVERT(varchar(10), [EESEDate], 121) = @Date

INSERT INTO ReportServer.Reporting.dbo.EnhancedExposedServiceEvents

(
	[EESEDate],
	[EESEHour],
	[EESEHourQuarter],
	[EESEWeekday],
	EESEEESTID,
	EESEEEOTID,
	EESEPartnerId,
	EESECallSuccessful,
	EESEAverageDuration,
	[EESECount]
)

SELECT 

	CAST(CONVERT(Varchar(10), EES1.EESEEventTime,121) AS datetime) AS EESDate,
	DATEPART(hour, EES1.EESEEventTime) AS EESHour,
	CAST(DATEPART(minute, EES1.EESEEventTime) / 15 AS smallint) AS EESHourQuarter,
	DATEPART(weekday, EES1.EESEEventTime) AS EESWeekDay,
	ESSType.EESTID As EnhancedExposedServicesID,
	ESOType.EEOTID As EnhancedExposedOperationID,
	EES1.EESEPartnerId As PartnerId ,
	EES1.EESECallSuccessful As CallSuccessful,
	AVG(CAST(DATEDIFF(millisecond, EES1.EESEEventTime, EES2.EESEEventTime) AS decimal(18, 0))) AS EESAvMsDuration,
	COUNT(*) AS EESCount

FROM  EnhancedExposedServiceEvent EES1 INNER JOIN
	EnhancedExposedServiceEvent EES2 ON EES1.EESEInternalTransactionId = EES2.EESEInternalTransactionId
	AND EES1.EESEPartnerId = EES2.EESEPartnerId
	AND  EES1.EESEExternalTransactionId = EES2.EESEExternalTransactionId
	AND EES1.EESEServiceType = EES2.EESEServiceType 

LEFT OUTER JOIN
ReportServer.Reporting.dbo.EnhancedExposedServicesType ESSType 
	ON EES1.EESEServiceType = ESSType.EESTType

LEFT OUTER JOIN
ReportServer.Reporting.dbo.EnhancedExposedOperationType ESOType 
	ON EES1.EESEOperationType = ESOType.EEOTType

	WHERE     (EES1.EESEIsStartEvent = 1) AND (EES2.EESEIsStartEvent = 0)
	AND  CONVERT(varchar(10), EES1.EESEEventTime, 121) = @Date

GROUP BY 
	CAST(CONVERT(Varchar(10), EES1.EESEEventTime,121) AS datetime),
	DATEPART(hour, EES1.EESEEventTime),
	CAST(DATEPART(minute, EES1.EESEEventTime) / 15 AS smallint) ,
	DATEPART(weekday, EES1.EESEEventTime) ,
	ESSType.EESTID,
	ESOType.EEOTID,
	EES1.EESEPartnerId,
	EES1.EESECallSuccessful



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO






----------------------------------
-- Update the ChangeCatalogue
----------------------------------

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 453)
BEGIN
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = getDate(),
		Summary = 'Correct EnhancedExposedServiceEventstransfer stored procedure so accumulates date/time correctly.'
	WHERE ScriptNumber = 453
END
ELSE
BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		453,
		getDate(),
		'Correct EnhancedExposedServiceEventstransfer stored procedure so accumulates date/time correctly.'
	)
END
GO