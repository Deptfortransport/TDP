-- ************************************************************
-- NAME 	: DUP0467_CarParking_SwitchOFF.sql
-- DESCRIPTION 	: Turns car parking functionality off
--		: (All car parking incremental scripts must have been run)
--
-- IMPORTANT    : THIS SCRIPT REQUIRES A DEPLOYMENT DECISION
--		:
-- 		: If car parking functionality is to be 
--		: switched OFF, uncomment all the sql code and run.
--		:
--		: To make uncommenting easier, do a global replace 
--		: for:  --++
-- ************************************************************

------------------------------------------
-- SET CAR PARK SWITCH TO FALSE
------------------------------------------

--++USE PermanentPortal
--++GO

--++UPDATE [properties]
--++SET pValue = 'False'
--++WHERE pName = 'CarParkingAvailable'
--++GO


------------------------------------------
-- DELETE FIND NEAREST CAR PARK EXPANDABLE MENU LINK
------------------------------------------

--++USE TransientPortal
--++GO

--++DECLARE @ResourceNameID INT,
--++	@SuggestionLinkID INT,
--++	@ContextSuggestionLinkID INT

--++SET @ResourceNameID = (SELECT ResourceNameId FROM dbo.ResourceName WHERE ResourceName = 'FindNearestCarPark')
--++SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM dbo.SuggestionLink 
--++					WHERE LinkCategoryId = 4
--++					AND ResourceNameID = @ResourceNameID)
--++SET @ContextSuggestionLinkID = (SELECT ContextSuggestionLinkId FROM dbo.ContextSuggestionLink 
--++					WHERE ContextId = 3
--++					AND SuggestionLinkID = @SuggestionLinkID)


--delete from ContextSuggestionLink table
--++DELETE FROM [ContextSuggestionLink] 
--++WHERE ContextSuggestionLinkId =  @ContextSuggestionLinkId
--++GO


------------------------------------------
-- DELETE FIND NEAREST CAR PARK SUGGESTION LINKS ON FIND CAR ROUTE INPUT
------------------------------------------

--++USE TransientPortal
--++GO

--++DECLARE @ResourceNameID INT,
--++	@SuggestionLinkID INT,
--++	@ContextSuggestionLinkID INT

--++SET @ResourceNameID = (SELECT ResourceNameId FROM dbo.ResourceName WHERE ResourceName = 'FindNearestCarPark')
--++SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM dbo.SuggestionLink 
--++					WHERE LinkCategoryId = 1
--++					AND ResourceNameID = @ResourceNameID)
--++SET @ContextSuggestionLinkID = (SELECT ContextSuggestionLinkId FROM dbo.ContextSuggestionLink 
--++					WHERE ContextId = 2
--++					AND SuggestionLinkID = @SuggestionLinkID)

--delete from ContextSuggestionLink table
--++DELETE FROM [ContextSuggestionLink] 
--++WHERE ContextSuggestionLinkId =  @ContextSuggestionLinkId

--++GO


------------------------------------------
-- DELETE DROPDOWN ITEM
------------------------------------------

--++USE PermanentPortal
--++GO

--shift the TrafficLevels entry up one
--++UPDATE [DropDownLists] 
--++SET SortOrder = 4 
--++WHERE ResourceID = 'TrafficLevels' 
--++GO

--delete CarPark from DropDownLists table for FindAPlaceControl
--++DELETE FROM [DropDownLists]
--++WHERE DataSet = 'FindLocationShowOptions' 
--++AND ResourceID = 'CarPark'

--++GO


------------------------------------------
-- UPDATE CHANGE CATALOGUE
------------------------------------------

--++USE PermanentPortal
--++GO

--++IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 467)
--++	UPDATE dbo.ChangeCatalogue
--++	SET
--++		ChangeDate = (getDate()),
--++		Summary = 'Car parking has been turned off - expandable link, mini find a place dropdown, and car route suggestion link all deleted'
--++	WHERE ScriptNumber = 467
--++ELSE
--++	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
--++		VALUES (467, (getDate()), 'Car parking has been turned off - expandable link, mini find a place dropdown, and car route suggestion link all deleted')
--++GO
