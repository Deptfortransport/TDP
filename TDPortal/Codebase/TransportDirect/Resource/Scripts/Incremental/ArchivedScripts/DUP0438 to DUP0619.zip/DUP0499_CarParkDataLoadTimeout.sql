-- ***********************************************
-- NAME 		: DUP0499_CarParkDataLoadTimeout.sql
-- DESCRIPTION 		: New property for the timeout value when running in a car park feed.
-- ************************************************

USE PermanentPortal

IF EXISTS (SELECT * FROM properties WHERE pname = 'datagateway.sqlimport.carparking.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway')
  BEGIN

    UPDATE properties SET pvalue = '3000' 
	WHERE pName = 'datagateway.sqlimport.carparking.sqlcommandtimeout' AND AID = '' AND GID = 'DataGateway' AND PartnerId = 0

  END
ELSE
  BEGIN

    INSERT INTO properties (pname, pvalue, AID, GID, PartnerId)
    VALUES ('datagateway.sqlimport.carparking.sqlcommandtimeout','3000','','DataGateway',0)

  END
GO

-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 499
SET @ScriptDesc = 'New property for the timeout value when running in a car park feed'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO