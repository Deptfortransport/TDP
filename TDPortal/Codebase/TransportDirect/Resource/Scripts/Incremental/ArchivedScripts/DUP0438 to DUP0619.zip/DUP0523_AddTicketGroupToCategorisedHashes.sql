-- ***********************************************
-- NAME :        DUP0523_AddTicketGroupToCategorisedHashes
-- DESCRIPTION : Add TicketGroup column to CategorisedHashes 
--               table and update query string
-- ************************************************

USE PermanentPortal
GO

------------------------------------------------------------
-- Modify the CatergorisedHashes table
------------------------------------------------------------
IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[CategorisedHashes]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[CategorisedHashes]
GO

CREATE TABLE [dbo].[CategorisedHashes] (
	[DataSet] [varchar] (200) NOT NULL ,
[KeyName] [varchar] (200) NOT NULL,
[Value] [varchar] (200) NOT NULL,
[Category] [varchar] (200) NOT NULL,
[TicketGroup] [varchar] (200) NOT NULL DEFAULT 'NoGroup') 
GO



--ALTER TABLE CategorisedHashes
--ADD [TicketGroup] [varchar] (50) DEFAULT 'NoGroup'
--GO

------------------------------------------------------------
-- Updated Query String
------------------------------------------------------------

USE PermanentPortal

IF EXISTS (SELECT * FROM Properties WHERE pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query')
  BEGIN
    DELETE FROM Properties WHERE pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query'
  END

INSERT INTO Properties 
VALUES('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query','SELECT KeyName, Value, Category, TicketGroup FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''','DataServices','UserPortal', '0');

GO

----------------------------------
-- Update the ChangeCatalogue
----------------------------------

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 523)
BEGIN
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = getDate(),
		Summary = 'Updated the CategorisedHashes table to add an extra column for TicketGroup and updated the Query String to access it.'
	WHERE ScriptNumber = 523
END
ELSE
BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		523,
		getDate(),
		'Updated the CategorisedHashes table to add an extra column for TicketGroup and updated the Query String to access it.'
	)
END
GO
