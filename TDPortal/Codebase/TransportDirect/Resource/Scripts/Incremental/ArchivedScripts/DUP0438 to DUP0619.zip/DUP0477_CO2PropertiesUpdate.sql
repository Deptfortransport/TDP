-- *************************************************************************************
-- NAME 		: DUP0477_CO2PropertiesUpdate.sql
-- DESCRIPTION 		: Controls the availability of rail search by
--                      : price.
-- *************************************************************************************

------------------------
-- Properties Table
------------------------

USE [PermanentPortal]
GO

-- CarCosting.MaxCO2PerKm
IF EXISTS (SELECT * FROM Properties WHERE pName = 'CarCosting.MaxCO2PerKm')
  BEGIN
    DELETE FROM Properties WHERE pName = 'CarCosting.MaxCO2PerKm' AND AID='Web'
  END

INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('CarCosting.MaxCO2PerKm', '600', 'Web', 'UserPortal', 0)

GO

-- CarCosting.MaxFuelCost
IF EXISTS (SELECT * FROM Properties WHERE pName = 'CarCosting.MaxFuelCost')
  BEGIN
    DELETE FROM Properties WHERE pName = 'CarCosting.MaxFuelCost' AND AID='Web'
  END

INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('CarCosting.MaxFuelCost', '300', 'Web', 'UserPortal', 0)

GO

-- CarCosting.MaxConsumptionLitresPer100Km
IF EXISTS (SELECT * FROM Properties WHERE pName = 'CarCosting.MaxConsumptionLitresPer100Km')
  BEGIN
    DELETE FROM Properties WHERE pName = 'CarCosting.MaxConsumptionLitresPer100Km' AND AID='Web'
  END

INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('CarCosting.MaxConsumptionLitresPer100Km', '45', 'Web', 'UserPortal', 0)

GO

-- CarCosting.MinFuelConsumption
IF EXISTS (SELECT * FROM Properties WHERE pName = 'CarCosting.MinFuelConsumption')
  BEGIN
    DELETE FROM Properties WHERE pName = 'CarCosting.MinFuelConsumption' AND AID='Web'
  END

INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('CarCosting.MinFuelConsumption', '5', 'Web', 'UserPortal', 0)	

GO


------------------------
-- Change Log 
------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 477)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'CO2 Properties added and updated'
    WHERE ScriptNumber = 477
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (477, getDate(), 'CO2 Properties added and updated' )
  END
GO