-- ***********************************************
-- NAME 	: 		  DUD0445_EES_PartnerSubscriptionSetup.sql
-- DESCRIPTION :	  add new partners for enhancedexposed services
-- ************************************************

USE [PermanentPortal]
GO

-- get the last partner id number and increment for new addition

-- Insert the new partner
IF NOT EXISTS (SELECT * FROM Partner WHERE PartnerId=nnn)  
BEGIN
	INSERT INTO Partner(PartnerId, HostName, PartnerName, Channel, PartnerPassword)
				VALUES (nnn, 'xxxxxx', 'xxxxxx', 'xxxxxx', 'xxxxxxxxxx') -- eg ('109', 'Lauren', 'Lauren', 'Lauren', 'jlkjlkjll3=')
END 

-- all possible allowed services are listed below. Only include those which are required for this partner 
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_DepartureBoard_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_TravelNews_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_CodeHandler_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_TaxiInformation_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_FindNearest_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE'%TransportDirect_EnhancedExposedServices_JourneyPlannerSynchronous_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_JourneyPlanner_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_OpenJourneyPlanner_V1%')
INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
	SELECT nnn, (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType LIKE '%TransportDirect_EnhancedExposedServices_TestWebService%')

GO

-- add the new partner to the reporting table. This entry should match with PermanentPortal.Partner table minus password column 
USE [Reporting]
GO

BEGIN
	INSERT INTO Partner(PartnerId, HostName, PartnerName, Channel)
		VALUES  (nnn, 'xxxxxx', 'xxxxxx', 'xxxxxx') -- eg ('109', 'Lauren', 'Lauren', 'Lauren')
END 
GO


-- Change Log
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 445
SET @ScriptDesc = 'Adds partner id and service permission for web services'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO