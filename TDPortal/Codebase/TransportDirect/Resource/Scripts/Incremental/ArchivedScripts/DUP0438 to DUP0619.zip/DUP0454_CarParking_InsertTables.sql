-- ************************************************************
-- NAME 	: DUP0454_CarParking_InsertTables.sql
-- DESCRIPTION 	: Creates Car Parking objects in transient
--                portal database.
-- ************************************************************

USE TransientPortal
GO

-----------------------------------------------
-- Create CarParkingOperator table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOperator') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingOperator (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[OperatorCode] [varchar] (50) NULL,
		[OperatorName] [varchar] (100) NULL,
		[OperatorURL] [varchar] (2048) NULL,
		[OperatorTsAndCs] [varchar] (2048) NULL,
		[OperatorEmail] [varchar] (100) NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingOperator ADD CONSTRAINT
		PK_CarParkingOperator PRIMARY KEY CLUSTERED ( Id ) 

END
GO


-----------------------------------------------
-- Create CarParkingTrafficNewsRegion
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingTrafficNewsRegion') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingTrafficNewsRegion (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[RegionName] [varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingTrafficNewsRegion ADD CONSTRAINT
		PK_CarParkingTrafficNewsRegion PRIMARY KEY CLUSTERED ( Id ) 

END
GO

-----------------------------------------------
-- Create CarParkingAccessPoints table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAccessPoints') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAccessPoints (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[GeocodeType] [varchar] (10) NOT NULL,
		[Easting] [varchar] (6) NOT NULL,
		[Northing] [varchar] (6) NOT NULL,
		[StreetName] [varchar] (100) NULL,
		[BarrierInOperation] [char] (3) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingAccessPoints ADD CONSTRAINT
		PK_CarParkingAccessPoints PRIMARY KEY CLUSTERED ( Id ) 

END
GO

-----------------------------------------------
-- Create CarParkingParkAndRideScheme
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingParkAndRideScheme') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingParkAndRideScheme (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Location] [varchar] (100) NULL,
		[SchemeURL] [varchar] (2048) NULL,
		[Comments] [varchar] (200) NULL,
		[LocationEasting] [varchar] (6) NULL,
		[LocationNorthing] [varchar] (6) NULL,
		[TransferFrequency] [varchar] (100) NULL,
		[TransferFrom] [varchar] (250) NULL,
		[TransferTo] [varchar] (250) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingParkAndRideScheme ADD CONSTRAINT
		PK_CarParkingParkAndRideScheme PRIMARY KEY CLUSTERED ( Id ) 

END
GO

-----------------------------------------------
-- Create CarParkingNPTGAdminDistrict
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGAdminDistrict') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingNPTGAdminDistrict (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[AdminAreaCode] [varchar] (50) NULL,
		[DistrictCode] [varchar] (50) NULL

	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingNPTGAdminDistrict ADD CONSTRAINT
		PK_CarParkingNPTGAdminDistrict PRIMARY KEY CLUSTERED ( Id ) 


END
GO

-----------------------------------------------
-- Create CarParkingCarParkType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkType (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[TypeCode] [varchar] (50) NULL,
		[Description] [varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkType ADD CONSTRAINT
		PK_CarParkingCarParkType PRIMARY KEY CLUSTERED ( Id )

END
GO

-----------------------------------------------
-- Create CarParkingLinkedNaptans
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingLinkedNaPTANS') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingLinkedNaPTANS (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[StopPointType] [varchar] (50) NULL,
		[StopCode] [varchar] (20) NULL,
		[InterchangeTime] [int] NULL,
		[InterchangeMode] [varchar] (50) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingLinkedNaPTANS ADD CONSTRAINT
		PK_CarParkingLinkedNaPTANS PRIMARY KEY CLUSTERED ( Id )

END
GO

-----------------------------------------------
-- Create CarParkingNPTGLocality
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingNPTGLocality') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingNPTGLocality (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[NationalGazeteerId] [varchar] (100) NULL,
		[Easting] [varchar] (100) NULL,
		[Northing] [varchar] (100) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingNPTGLocality ADD CONSTRAINT
		PK_CarParkingNPTGLocality PRIMARY KEY CLUSTERED ( Id )


END
GO

-----------------------------------------------
-- Create CarParkingCalendar table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCalendar') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCalendar (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Start] [datetime] NULL,
		[End] [datetime] NULL,
		[Days] [varchar] (7) NULL,
		[PublicHols] [varchar] (8) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCalendar ADD CONSTRAINT
		PK_CarParkingCalendar PRIMARY KEY CLUSTERED ( Id )

END
GO




		
-----------------------------------------------
-- Create CarParkingOpeningTimes table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingOpeningTimes') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingOpeningTimes (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[CalendarId] [int] NOT NULL,
		[DayType] [varchar] (50) NOT NULL,
		[OpensAt] [int] NOT NULL,
		[LastEntranceAt] [int] NOT NULL,
		[ClosesAt] [int] NOT NULL,
		[MaxStaysDays] [int] NULL,
		[MaxStayMinutes] [int] NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingOpeningTimes ADD CONSTRAINT
		PK_CarParkingOpeningTimes PRIMARY KEY CLUSTERED ( Id ) 

	ALTER TABLE dbo.CarParkingOpeningTimes ADD CONSTRAINT
		FK_CarParkingCalendar_OpeningTimes FOREIGN KEY ( CalendarId )
		REFERENCES dbo.CarParkingCalendar ( Id )

END
GO
		
	
-----------------------------------------------
-- Create CarParkingPaymentMethods
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentMethods') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN		
	CREATE TABLE dbo.CarParkingPaymentMethods (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Code] [varchar] (50),
		[Description] [varchar] (100),
		[ChangeAvailable] [char] (1) DEFAULT 'N' NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingPaymentMethods ADD CONSTRAINT
		PK_CarParkingPaymentMethods PRIMARY KEY CLUSTERED ( Id ) 

END
GO


-----------------------------------------------
-- Create CarParkingPaymentType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingPaymentType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingPaymentType (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[Type] [varchar] (50) NULL,
		[TypeCode] [varchar] (50) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingPaymentType ADD CONSTRAINT
		PK_CarParkingPaymentType PRIMARY KEY CLUSTERED ( Id ) 


END
GO


----------------------------------------------
-- Create CarParkAttractionType
----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractionType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAttractionType (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[TypeCode] [int] NOT NULL,
		[Description] [varchar] (50) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingAttractionType ADD CONSTRAINT
		PK_CarParkingAttractionType PRIMARY KEY CLUSTERED ( Id )

END
GO

-----------------------------------------------
-- Create CarParkingAttractions
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAttractions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAttractions (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[TypeId] [int] NOT NULL,
		[Name] [varchar] (50) NULL,
		[WalkingDistance] [varchar] (6) NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingAttractions ADD CONSTRAINT
		PK_CarParkingAttractions PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingAttractions ADD CONSTRAINT
		FK_CarParkingAttractions_CarParkingAttractionType FOREIGN KEY ( TypeId )
		REFERENCES dbo.CarParkingAttractionType ( Id )

END
GO

-----------------------------------------------
-- Create CarParkingFacilitiesType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilitiesType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingFacilitiesType (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[TypeCode] [varchar] (100) NOT NULL,
		[Description] [varchar] (100) NOT NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingFacilitiesType ADD CONSTRAINT
		PK_CarParkingFacilitiesType PRIMARY KEY CLUSTERED ( Id )
END
GO


-----------------------------------------------
-- Create CarParkingFacilities
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingFacilities') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingFacilities (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[FacilitiesTypeId] [int] NOT NULL,
		[Name] [varchar] (100) NULL,
		[Location] [varchar] (100) NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingFacilities ADD CONSTRAINT
		PK_CarParkingFacilities PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingFacilities ADD CONSTRAINT
		FK_CarParkingFacilitiesType_CarParkingFacilities FOREIGN KEY ( FacilitiesTypeId )
		REFERENCES dbo.CarParkingFacilitiesType ( Id )

END
GO


-----------------------------------------------
-- Create CarParkingSpaceType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingSpaceType (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[TypeCode] [varchar] (50) NOT NULL,
		[Description] [varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingSpaceType ADD CONSTRAINT
		PK_CarParkingCarParkSpaceType PRIMARY KEY CLUSTERED ( Id )

END
GO


-----------------------------------------------
-- Create CarParkingCarParkSpace
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkSpace') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkSpace (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[SpaceTypeId] [int] NOT NULL,
		[NumberOfSpaces] [varchar] (50) NOT NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkSpace ADD CONSTRAINT
		PK_CarParkingCarParkSpace PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingCarParkSpace ADD CONSTRAINT
		FK_CarParkingSpace_CarParkingSpaceType FOREIGN KEY ( SpaceTypeId )
		REFERENCES dbo.CarParkingSpaceType ( Id )


END
GO


-----------------------------------------------
-- Create CarParkingSpaceTypeAvailability
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingSpaceAvailability') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingSpaceAvailability (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[SpaceId] [int] NOT NULL,
		[CalendarId] [int] NOT NULL,
		[AvailabilityDayType] [varchar] (50) NOT NULL,
		[StartTime] [int] NOT NULL,
		[EndTime] [int] NULL,
		[PercentageAvailability] [int] NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingSpaceAvailability ADD CONSTRAINT
		PK_CarParkingSpaceTypeAvailability PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingSpaceAvailability ADD CONSTRAINT
		FK_CarParkingSpaceAvailability_CarParkingSpaceType FOREIGN KEY ( SpaceId )
		REFERENCES dbo.CarParkingCarParkSpace ( Id )

	ALTER TABLE dbo.CarParkingSpaceAvailability ADD CONSTRAINT
		FK_CarParkingAvailability_CarParkingCalendar FOREIGN KEY ( CalendarId )
		REFERENCES dbo.CarParkingCalendar ( Id )

END
GO

-----------------------------------------------
-- Create CarParkingCarParkCharges
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkCharges') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkCharges (
		[Id] [int] IDENTITY (1,1) NOT NULL,	
		[SpaceId] [int] NOT NULL,
		[CalendarId] [int] NOT NULL,
		[DayType] [varchar] (50) NOT NULL,
		[StartTime] [int] NOT NULL,
		[EndTime] [int] NOT NULL,
		[TimeRangeDays] [int] NOT NULL,
		[TimeRangeMinutes] [int] NOT NULL,
		[Comments] [varchar] (200) NULL,
		[ChargeAmount] [int] NOT NULL,
		[ChargeDayEndTime] [varchar] (10) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkCharges ADD CONSTRAINT
		PK_CarParkingCarParkCharges PRIMARY KEY CLUSTERED ( Id )

	ALTER TABLE dbo.CarParkingCarParkCharges ADD CONSTRAINT
		FK_CarParkingSpace_CarParkingCarParkCharges FOREIGN KEY ( SpaceId )
		REFERENCES dbo.CarParkingCarParkSpace ( Id )

	ALTER TABLE dbo.CarParkingCarParkCharges ADD CONSTRAINT 
		FK_CarParkingCalendar_CarParkCharges FOREIGN KEY ( CalendarId )
		REFERENCES dbo.CarParkingCalendar ( Id )

END
GO

-----------------------------------------------
-- Create CarParkingCarParkChargeType
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkChargeType') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkChargeType (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[ChargeType] [varchar] (50) NOT NULL,
		[ChargeDescription] [varchar] (100) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkChargeType ADD CONSTRAINT
		PK_CarParkingCarChargeType PRIMARY KEY CLUSTERED ( Id )


END
GO

-----------------------------------------------
-- Create CarParkingCarParkConcessions
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingCarParkConcessions') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingCarParkConcessions (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[Code] [varchar] (50) NOT NULL,
		[Description] [varchar] (200) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParkingCarParkConcessions ADD CONSTRAINT
		PK_CarParkingCarParkConcessions PRIMARY KEY CLUSTERED ( Id )


END
GO


-----------------------------------------------
-- Create CarParkingAdditionalData table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParkingAdditionalData') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParkingAdditionalData (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[TypeId] [int] NOT NULL,
		[LinkedNaPTANsId] [int] NULL,
		[NPTGLocalityId] [int] NULL,
		[AttractionsId] [int] NULL,
		[FacilitiesId] [int] NULL,
		[SpacesId] [int] NULL,
		[PaymentMethodId] [int] NULL,
		[PaymentTypeId] [int] NULL,
		[OpeningTimesId] [int] NULL,
		[ClosingDate] [int] NOT NULL,
		[ReopeningDate] [int] NOT NULL,
		[MaximumHeight] [int] NULL,
		[MaximumWidth] [int] NULL,
		[PMSPA] [char] (1) DEFAULT 'N' NOT NULL,
		[EmergencyNumber] [int] NOT NULL,
		[EmailAddressOfCarPark] [varchar] (100) NULL,
		[CCTVAvailable] [char] (1) DEFAULT 'N' NOT NULL,
		[Staffed] [char] (1) DEFAULT 'N' NOT NULL,
		[Patrolled] [char] (1) DEFAULT 'N' NOT NULL,
		[VehicleRestrictions] [varchar] (150) NULL,
		[LiftsAvailable] [char] (1) DEFAULT 'N' NOT NULL,
		[AdvancedReservationsAvailable] [char] (1) DEFAULT 'N' NOT NULL,
		[SeasonTicketsAvailable] [char] (1) DEFAULT 'N' NOT NULL
	) ON [PRIMARY]

	-- Primary Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		PK_CarParkingAdditionalData PRIMARY KEY CLUSTERED ( Id ) 

	-- CarParkingType Foreign Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingType FOREIGN KEY ( TypeID )
		REFERENCES dbo.CarParkingCarParkType ( Id )

	-- CarParkingLinkedNaptans Foreign Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingLinkedNaPTANs FOREIGN KEY ( LinkedNaPTANsId )
		REFERENCES dbo.CarParkingLinkedNaPTANs ( Id )

	-- CarParkingNPTGLocality Foreign Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT	
		FK_CarParkingAdditionalData_CarParkingNPTGLocality FOREIGN KEY ( NPTGLocalityId )
		REFERENCES dbo.CarParkingNPTGLocality ( Id )

	-- CarParkingAttractions Foreign Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingAttracions FOREIGN KEY ( AttractionsId )
		REFERENCES dbo.CarParkingAttractions ( Id )

	-- CarParkingFacilities Foreign Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingFacilities FOREIGN KEY ( FacilitiesId )
		REFERENCES dbo.CarParkingFacilities ( Id )

	-- CarParkingSpace Foreign Key
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingSpace FOREIGN KEY ( SpacesId )
		REFERENCES dbo.CarParkingCarParkSpace ( Id )

	-- CarParkingOpeningTimes
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingOpeningTimes FOREIGN KEY ( OpeningTimesId )
		REFERENCES dbo.CarParkingOpeningTimes( Id )

	-- CarParkPaymentMethods
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingPaymentMethods FOREIGN KEY ( PaymentMethodId )
		REFERENCES dbo.CarParkingPaymentMethods ( Id )

	-- CarParkingPaymentType
	ALTER TABLE dbo.CarParkingAdditionalData ADD CONSTRAINT
		FK_CarParkingAdditionalData_CarParkingPaymentType FOREIGN KEY ( PaymentTypeId )
		REFERENCES dbo.CarParkingPaymentType ( Id )

END
GO


-----------------------------------------------
-- Create CarParking table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CarParking') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CarParking (
		[Id] [int] IDENTITY (1,1) NOT NULL,
		[AdditionalDataId] [int] NULL,
		[Reference] [varchar] (50) NOT NULL,	
		[OperatorId] [int] NOT NULL,
		[AccessPointsMapId] [int] NULL,
		[AccessPointsEntranceId] [int] NULL,
		[AccessPointsExitId] [int] NULL,
		[TrafficNewsRegionId] [int] NOT NULL,
		[ParkAndRideSchemeId] [int],
		[NPTGAdminDistrictId] [int],
		[Name] [varchar] (50) NULL,
		[Location] [varchar] (50) NULL,
		[Address] [varchar] (100) NULL,
		[Postcode] [varchar] (8) NULL,
		[Notes] [varchar] (250) NULL,
		[Telephone] [varchar] (11) NULL,
		[Url] [varchar] (2048) NULL,
		[MinCost] [int] NULL,
		[ParkAndRide] [varchar] (5) NULL,
		[StayType] [varchar] (10) NULL,
		[PlanningPoint] [varchar] (5) DEFAULT 'N' NOT NULL,
		[DateRecordLastUpdated] [datetime] DEFAULT 0 NOT NULL,
		[WEUDate] [datetime] NULL,
		[WEFDate] [datetime] NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		PK_CarParking PRIMARY KEY CLUSTERED ( Id ) 

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingAdditionalData FOREIGN KEY ( AdditionalDataId)
		REFERENCES dbo.CarParkingAdditionalData ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingOperator FOREIGN KEY ( OperatorId )
		REFERENCES dbo.CarParkingOperator ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingTrafficNewsRegion FOREIGN KEY ( TrafficNewsRegionId )
		REFERENCES dbo.CarParkingTrafficNewsRegion ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingAccessPointsMap FOREIGN KEY ( AccessPointsMapId )
		REFERENCES dbo.CarParkingAccessPoints ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingAccessPointsEntrance FOREIGN KEY ( AccessPointsEntranceId )
		REFERENCES dbo.CarParkingAccessPoints ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingAccessPointsExit FOREIGN KEY ( AccessPointsExitId )
		REFERENCES dbo.CarParkingAccessPoints ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingParkAndRideScheme FOREIGN KEY ( ParkAndRideSchemeId )
		REFERENCES dbo.CarParkingParkAndRideScheme ( Id )

	ALTER TABLE dbo.CarParking ADD CONSTRAINT
		FK_CarParking_CarParkingNPTGAdminAndDistrict FOREIGN KEY ( NPTGAdminDistrictId )
		REFERENCES dbo.CarParkingNPTGAdminDistrict ( Id )

END
GO

-------------------------------------------------
-- Updates to FTP_CONFIGURATION
-------------------------------------------------

USE PermanentPortal
GO

DECLARE @feed_name [varchar](6)
SET @feed_name = 'etd565'


DELETE FROM ftp_configuration WHERE data_feed = @feed_name

INSERT INTO ftp_configuration (ftp_client, data_feed, ip_address, username, password, local_dir, remote_dir, filename_filter, missing_feed_counter, missing_feed_threshold, data_feed_datetime, data_feed_filename, remove_files)
VALUES ('1', @feed_name, 'Localhost', 'TDP28NOV', 'sI1732#3-', 'C:/Gateway/dat/Incoming/' + @feed_name, '../' + @feed_name, '*.zip', 0, 1, '01/01/2006', '', 1)

GO

-------------------------------------------------
-- Updates to IMPORT_CONFIGURATION
-------------------------------------------------

USE PermanentPortal
GO

DECLARE @feed_name [varchar](6)
SET @feed_name = 'etd565'


DELETE FROM import_configuration WHERE data_feed = @feed_name

INSERT INTO import_configuration (data_feed, import_class, class_archive, import_utility, parameters1, parameters2, processing_dir)
VALUES (@feed_name, 'TransportDirect.UserPortal.LocationService.CarParkingImportTask', 'td.userportal.locationservice.dll', '', '', '', 'C:/Gateway/dat/Processing/' + @feed_name)

GO

-------------------------------------------------
-- Updates to Properties Table
-------------------------------------------------

USE PermanentPortal
GO

DECLARE @feed_name [varchar](6)
SET @feed_name = 'etd565'


DELETE FROM properties WHERE pName like '%datagateway.sqlimport.carparking%'

INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.database', 'TransientPortalDB', '', 'DataGateway' ,0)
INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.feedname', @feed_name, '', 'DataGateway' ,0)
INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.Name', 'carparking', '', 'DataGateway' ,0)
INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.schemea', 'c:\gateway\xml\carparking.xsd', '', 'DataGateway' ,0)
INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.storedprocedure', 'ImportCarParkingData', '', 'DataGateway' ,0)
INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.xmlnamespace', 'http://www.transportdirect.info/carparking', '', 'DataGateway' ,0)
INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.xmlnamespacexsi', 'http://www.w3.org/2001/XMLSchema-instance', '', 'DataGateway' ,0)
INSERT INTO properties VALUES ('datagateway.sqlimport.carparking.xmlschemalocation','http://www.transportdirect.info/CarPark.xsd', '', 'DataGateway' ,0)

GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 454)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Added/Updated tables for Car Parking.'
	WHERE ScriptNumber = 454
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (454, (getDate()), 'Added new tables for Car Parking')
GO