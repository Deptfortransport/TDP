-- ************************************************************
-- NAME 	: DUP0484_CO2Table_CarParkFuelFactor.sql
-- DESCRIPTION 	: Creates Car Cost Fuel Factor table used to 
-- 		  store values used in CO2 Emissions calculations
-- ************************************************************

USE [PermanentPortal]
GO

------------------------------------------
-- Delete existing table
------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[CarCostFuelFactor]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[CarCostFuelFactor]
GO


------------------------------------------
-- Create table
------------------------------------------

CREATE TABLE [dbo].[CarCostFuelFactor] (
	[FuelType] [varchar] (10) NOT NULL ,
	[Factor] [int] NULL 
) ON [PRIMARY]
GO


------------------------------------------
-- Set FuelType as the Primary Key
------------------------------------------

ALTER TABLE [dbo].[CarCostFuelFactor] ADD 
	CONSTRAINT [PK_CarCostFuelFactor] PRIMARY KEY  CLUSTERED 
	(
		[FuelType]
	)  ON [PRIMARY] 
GO


-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 484
SET @ScriptDesc = 'Added CarCostFuelFactor table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO