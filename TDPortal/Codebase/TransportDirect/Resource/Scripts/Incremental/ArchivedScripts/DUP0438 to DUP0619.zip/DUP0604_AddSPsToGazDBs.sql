-- ************************************************************
-- NAME 	: DUP0604_AddSPsToGazDBs.sql
-- DESCRIPTION 	: Add new stored procedures to the GAZ DBs for jmd265
-- ************************************************************

USE GAZ_Staging
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportAttractionAliasData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
drop procedure [dbo].[ImportAttractionAliasData]
END
GO

---------------------------------
-- AttractionAlias Import Task --
---------------------------------

CREATE PROCEDURE ImportAttractionAliasData
(
	@XML text
)
/*
Takes a text parameter containing XML data  and loads it into the dft_places table
*/
AS
DECLARE @DocumentID int, @XMLPathData varchar(50), @XMLVersion int, @GAZVersion int, @GazStagVersion int

-- Load the XML document and set the node
SET @XMLPathData =  '/attractionalias/Alias'

EXEC sp_xml_preparedocument @DocumentID OUTPUT, @XML

SELECT @XMLVersion=MIN(X.a19)
FROM OPENXML (@DocumentID, @XMLPathData, 2)
		WITH
		(	
			a19 int
		) X

SELECT @GAZVersion=MIN(Version) FROM GAZ.gazadmin.dft_places
SELECT @GazStagVersion=MIN(Version) FROM gazadmin.dft_places

IF @XMLVersion > @GazStagVersion and @XMLVersion > @GAZVersion
BEGIN
	BEGIN TRANSACTION

		-- deleting from dft_places 
		DELETE FROM gazadmin.dft_places
	
		--now insert data into the dft_places table
		SET IDENTITY_INSERT gazadmin.dft_places ON
	
		INSERT INTO gazadmin.dft_places ([internal_id], [Supplier_Reference_no], [Common_record_no], [Toid], [Toid_Version], [Name],
					[Address_detail], [Street_name], [Locality], [Postcode], [classification_code], [Easting],
					[Northing], [Provenance], [Date_of_supply], [Positional_accuracy_code], [supplier_link],
					[valid_from], [valid_to], [Version])
		SELECT 
				X.a0,
				X.a1,
				X.a2,
				X.a3,
				X.a4,
				X.a5,
				X.a6,
				X.a7,
				X.a8,
				X.a9,
				X.a10,
				X.a11,
				X.a12,
				X.a13,
				X.a14,
				X.a15,
				X.a16,
				X.a17,
				X.a18,
				X.a19
			FROM OPENXML (@DocumentID, @XMLPathData, 2)
			WITH
			(	
				a0 int,
				a1 varchar(15),
				a2 varchar(15),
				a3 varchar(18),
				a4 smallint,
				a5 varchar(100),
				a6 varchar(100),
				a7 varchar(100),
				a8 varchar(100),
				a9 varchar(9),
				a10 varchar(10),
				a11 numeric(9,0),
				a12 numeric(9,0),
				a13 varchar(50),
				a14 smalldatetime,
				a15 smallint,
				a16 varchar(50),
				a17 smalldatetime,
				a18 smalldatetime,
				a19 int
			) X
	
	COMMIT TRANSACTION

	SET IDENTITY_INSERT gazadmin.dft_places OFF
END
ELSE IF @GazVersion > @GazStagVersion
BEGIN
	SET IDENTITY_INSERT gazadmin.dft_places ON

	BEGIN TRANSACTION

		-- deleting from dft_places 
		DELETE FROM gazadmin.dft_places

		-- copy gaz dft_places into gaz_stagings
		INSERT INTO gazadmin.dft_places ([internal_id], [Supplier_Reference_no], [Common_record_no], [Toid], [Toid_Version], [Name],
					[Address_detail], [Street_name], [Locality], [Postcode], [classification_code], [Easting],
					[Northing], [Provenance], [Date_of_supply], [Positional_accuracy_code], [supplier_link],
					[valid_from], [valid_to], [Version])
		SELECT [internal_id], [Supplier_Reference_no], [Common_record_no], [Toid], [Toid_Version], [Name],
					[Address_detail], [Street_name], [Locality], [Postcode], [classification_code], [Easting],
					[Northing], [Provenance], [Date_of_supply], [Positional_accuracy_code], [supplier_link],
					[valid_from], [valid_to], [Version]
		FROM GAZ.gazadmin.dft_places

	COMMIT TRANSACTION

	SET IDENTITY_INSERT gazadmin.dft_places OFF

END

-- Remove xml doc from memory
EXEC sp_xml_removedocument @DocumentID

GO

-----------------

USE GAZ
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportAttractionAliasData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
drop procedure [dbo].[ImportAttractionAliasData]
END
GO

---------------------------------
-- AttractionAlias Import Task --
---------------------------------

CREATE PROCEDURE ImportAttractionAliasData
(
	@XML text
)
/*
Takes a text parameter containing XML data  and loads it into the dft_places table
*/
AS
DECLARE @DocumentID int, @XMLPathData varchar(50), @XMLVersion int, @GAZVersion int, @GazStagVersion int

-- Load the XML document and set the node
SET @XMLPathData =  '/attractionalias/Alias'

EXEC sp_xml_preparedocument @DocumentID OUTPUT, @XML

SELECT @XMLVersion=MIN(X.a19)
FROM OPENXML (@DocumentID, @XMLPathData, 2)
		WITH
		(	
			a19 int
		) X

SELECT @GAZVersion=MIN(Version) FROM GAZ.gazadmin.dft_places
SELECT @GazStagVersion=MIN(Version) FROM gazadmin.dft_places

IF @XMLVersion > @GazStagVersion and @XMLVersion > @GAZVersion
BEGIN
	BEGIN TRANSACTION

		-- deleting from dft_places 
		DELETE FROM gazadmin.dft_places
	
		--now insert data into the dft_places table
		SET IDENTITY_INSERT gazadmin.dft_places ON
	
		INSERT INTO gazadmin.dft_places ([internal_id], [Supplier_Reference_no], [Common_record_no], [Toid], [Toid_Version], [Name],
					[Address_detail], [Street_name], [Locality], [Postcode], [classification_code], [Easting],
					[Northing], [Provenance], [Date_of_supply], [Positional_accuracy_code], [supplier_link],
					[valid_from], [valid_to], [Version])
		SELECT 
				X.a0,
				X.a1,
				X.a2,
				X.a3,
				X.a4,
				X.a5,
				X.a6,
				X.a7,
				X.a8,
				X.a9,
				X.a10,
				X.a11,
				X.a12,
				X.a13,
				X.a14,
				X.a15,
				X.a16,
				X.a17,
				X.a18,
				X.a19
			FROM OPENXML (@DocumentID, @XMLPathData, 2)
			WITH
			(	
				a0 int,
				a1 varchar(15),
				a2 varchar(15),
				a3 varchar(18),
				a4 smallint,
				a5 varchar(100),
				a6 varchar(100),
				a7 varchar(100),
				a8 varchar(100),
				a9 varchar(9),
				a10 varchar(10),
				a11 numeric(9,0),
				a12 numeric(9,0),
				a13 varchar(50),
				a14 smalldatetime,
				a15 smallint,
				a16 varchar(50),
				a17 smalldatetime,
				a18 smalldatetime,
				a19 int
			) X
	
	COMMIT TRANSACTION

	SET IDENTITY_INSERT gazadmin.dft_places OFF
END
ELSE IF @GazVersion > @GazStagVersion
BEGIN
	SET IDENTITY_INSERT gazadmin.dft_places ON

	BEGIN TRANSACTION

		-- deleting from dft_places 
		DELETE FROM gazadmin.dft_places

		-- copy gaz dft_places into gaz_stagings
		INSERT INTO gazadmin.dft_places ([internal_id], [Supplier_Reference_no], [Common_record_no], [Toid], [Toid_Version], [Name],
					[Address_detail], [Street_name], [Locality], [Postcode], [classification_code], [Easting],
					[Northing], [Provenance], [Date_of_supply], [Positional_accuracy_code], [supplier_link],
					[valid_from], [valid_to], [Version])
		SELECT [internal_id], [Supplier_Reference_no], [Common_record_no], [Toid], [Toid_Version], [Name],
					[Address_detail], [Street_name], [Locality], [Postcode], [classification_code], [Easting],
					[Northing], [Provenance], [Date_of_supply], [Positional_accuracy_code], [supplier_link],
					[valid_from], [valid_to], [Version]
		FROM GAZ.gazadmin.dft_places

	COMMIT TRANSACTION

	SET IDENTITY_INSERT gazadmin.dft_places OFF

END

-- Remove xml doc from memory
EXEC sp_xml_removedocument @DocumentID

GO

-- =============================================  
-- CHANGE LOG
-- =============================================  
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 604
SET @ScriptDesc = 'Add new stored procedures to the GAZ DBs for jmd265'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-- =============================================  