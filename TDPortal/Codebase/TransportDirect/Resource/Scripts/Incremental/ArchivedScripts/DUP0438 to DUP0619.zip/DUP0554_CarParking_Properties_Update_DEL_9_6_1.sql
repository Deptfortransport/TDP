-- ***********************************************
-- NAME 		: DUP0556_CarParking_Properties_Update.sql
-- DESCRIPTION 		: Updates the properties for Car Parking used in Find nearest car parks
--			  - Number of car parks returned to 50
--			  - Change to initial search radius
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE FIND CAR PARK PROPERTIES
----------------------------------------

-- NUMBER OF CAR PARKS 
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.NumberCarParksReturned')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.NumberCarParksReturned'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.NumberCarParksReturned', '50', 'Web', 'UserPortal', 0)


-- REMOVE EXISTING RADIUS
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.InitialRadius')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.InitialRadius'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.InitialRadius', '3218', 'Web', 'UserPortal', 0)


IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.MaximumRadius')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.MaximumRadius'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.MaximumRadius', '3219', 'Web', 'UserPortal', 0)

GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 556
SET @ScriptDesc = 'Updates for Find nearest car park properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO