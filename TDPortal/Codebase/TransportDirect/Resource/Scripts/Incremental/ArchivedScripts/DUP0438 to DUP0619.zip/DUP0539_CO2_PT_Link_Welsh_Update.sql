-- ***********************************************
-- NAME 		: DUP0539_CO2_PT_Link_Welsh_Update.sql
-- DESCRIPTION 		: Update for CO2 PT expandable link name to Welsh text
-- ************************************************

USE [TransientPortal]
GO

IF EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([Text] = 'cy Check journey CO2'))
UPDATE [dbo].[Resource]
SET [Text] = 'Mesur CO2 y siwrnai '
WHERE [Text] = 'cy Check journey CO2' AND [Culture] = 'cy-GB'

GO


---------------------------------------- 	
-- CHANGE CATALOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 539
SET @ScriptDesc = 'Updated CO2 link name to welsh text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO