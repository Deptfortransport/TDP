-- ***********************************************
-- NAME 	: DUP0542_DeleteUserProfile_SP.sql
-- DESCRIPTION 	: Creates the usp_DeleteUserProfileStoredProcedure.
-- ************************************************
-- 
-- Security permissions must be updated in this script.

-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0542_DeleteUserProfile_SP.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:58:14   mmodi
--Initial revision.
--
--   Rev 1.0   Nov 08 2007 12:41:50   mturner
--Initial revision.
--
--   Rev 1.2   Jun 21 2007 14:46:58   mturner
--Fixed problem with script check ing for the existence of the wrong stored proc before the drop.
--
--Changed name of the stored proc ASPUSER is given rights to to be the correct stored proc.
--
--   Rev 1.1   May 21 2007 10:11:54   Pscott
--Post code review changes
--
--   Rev 1.0   May 09 2007 10:23:16   Pscott
--Initial revision.


/****** Use database ******/
use [TDUserInfo]
GO

/****** Drop stored procedures and tables ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_DeleteUserProfile]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_DeleteUserProfile]


/****** Create stored procedures and tables ******/

SET QUOTED_IDENTIFIER ON 
SET ANSI_NULLS ON 
GO

-- Create the DeleteUserProfile stored procedure

CREATE PROCEDURE dbo.usp_DeleteUserProfile
	(
	@userID varchar(36)
	)
AS
	-- Test to see if there is an existing entry in the PrefsAndFav
	IF EXISTS (	SELECT UserID FROM TDUserInfo..ProfileData WHERE UserID = @userID )
		BEGIN -- There is an existing entry, so update it
			delete from TDUserInfo..ProfileData
			WHERE UserID = @userID
			
			RETURN 0
			
		END
	RETURN 1
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Update Permissions	
-- comment out as appropriate.

----------------------------------------------------------------

GRANT EXECUTE ON [DeleteUserProfile] TO [ACPDFTW\ASPUSER]

GO


/****** Use database ******/
use [PermanentPortal]
GO
----------------
-- Change Log --
----------------
IF EXISTS (SELECT * FROM [ChangeCatalogue] WHERE ScriptNumber = 542)
  BEGIN
    UPDATE [ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Delete User Profile SP created'
    WHERE ScriptNumber = 0542
  END
ELSE
  BEGIN
    INSERT INTO [ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (0542, getDate(), 'Delete User Profile SP created' )
  END
GO