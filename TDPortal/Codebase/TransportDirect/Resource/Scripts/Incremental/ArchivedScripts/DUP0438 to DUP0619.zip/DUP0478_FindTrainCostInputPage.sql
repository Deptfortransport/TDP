-- ***********************************************************************************************
-- NAME 	: DUP0478_FindTrainCostInputPage.sql
-- DESCRIPTION 	: Updates CMS content on the FindTrainCostInputPage and adds new links 
--		  for the alternate links
-- ***********************************************************************************************
-- $Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/ArchivedScripts/DUP0478_FindTrainCostInputPage.sql-arc  $
--
--   Rev 1.0   Dec 15 2008 10:58:00   mmodi
--Initial revision.
--
--   Rev 1.0   Nov 08 2007 12:41:26   mturner
--Initial revision.
--
--   Rev 1.1   Nov 16 2006 19:48:58   dsawe
--added for modifying links in relatedLinksControl 
--Resolution for 4220: Rail Search by Price
--
-- Rev 1.1 Nov 16 2006 17:12:12 dsawe
-- Resolution for 4220: Rail Search by Price ( arranging relatedlinkscontrol in required order)

--  Rev 1.0   Nov 14 2006 15:42:16   dsawe
--Initial revision.
--Resolution for 4220: Rail Search by Price

USE [TransientPortal]
GO

-- ***********************************************************************************************
-- Add new ExpandableMenu context for FindTrainCostInput page. Wire up to existing links
-- ***********************************************************************************************

IF NOT EXISTS (SELECT * FROM Context WHERE ContextId = '10' AND Name = 'FindTrainCostInput')

	INSERT INTO [Context] ([ContextId], [Name], [Description])
	SELECT 10, 'FindTrainCostInput', 'Suggestions for Find A Train Cost input page'	

	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT 66, 10, 58
	UNION	
	SELECT 67, 10, 59
	UNION
	SELECT 68, 10, 60
	UNION
	SELECT 69, 10, 61
	UNION
	SELECT 70, 10, 62
	UNION
	SELECT 71, 10, 63
	UNION
	SELECT 72, 10, 64

	
GO

----------------
-- Change Log --
----------------
USE [PermanentPortal]
GO

DECLARE @ChangeNumber int
DECLARE @ChangeText varchar(200)

SET @ChangeNumber = 478
SET @ChangeText = 'New related links for Find A Train Cost input page'


IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ChangeNumber)

BEGIN
  UPDATE [dbo].[ChangeCatalogue]
  SET ChangeDate = getDate(), Summary = @ChangeText
  WHERE ScriptNumber = @ChangeNumber
END

ELSE

BEGIN
  INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
  VALUES (@ChangeNumber, getDate(), @ChangeText)
END

GO