-- ***********************************************
-- NAME 		: DUP0598_Alter_SessionId_Column_for_DotNet2.0.sql
-- DESCRIPTION 		: Alters the sessionid column type from varchar(50) to
--			: nvarchar(88) for the .NET 2.0 Upgrade
-- AUTHOR		: Jonathan Roberts
-- ************************************************

USE [ReportStagingDB]
GO

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'LoginEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE LoginEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'MapEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE MapEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'OperationalEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE OperationalEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'PageEntryEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE PageEntryEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'ReferenceTransactionEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE ReferenceTransactionEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'RetailerHandoffEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE RetailerHandoffEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'UserFeedbackEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE UserFeedbackEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'UserPreferenceSaveEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE UserPreferenceSaveEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'JourneyPlanRequestVerboseEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE JourneyPlanRequestVerboseEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'JourneyPlanResultsVerboseEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE JourneyPlanResultsVerboseEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'DataGatewayEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE DataGatewayEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'GazetteerEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE GazetteerEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'InternalRequestEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE InternalRequestEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'JourneyPlanRequestEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE JourneyPlanRequestEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'JourneyPlanResultsEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE JourneyPlanResultsEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'JourneyWebRequestEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE JourneyWebRequestEvent
          ALTER COLUMN SessionId nvarchar(88)
END

IF NOT EXISTS (SELECT 1
                 FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'LandingPageEvent'
                  AND COLUMN_NAME = N'SessionId'
                  AND CHARACTER_MAXIMUM_LENGTH = 88)
BEGIN
    ALTER TABLE LandingPageEvent
          ALTER COLUMN SessionId nvarchar(88)
END

------------------------------------------------------------
-- CHANGE LOG
USE [ReportStagingDB]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 598
SET @ScriptDesc = 'Update tables for DOT NET 2'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------