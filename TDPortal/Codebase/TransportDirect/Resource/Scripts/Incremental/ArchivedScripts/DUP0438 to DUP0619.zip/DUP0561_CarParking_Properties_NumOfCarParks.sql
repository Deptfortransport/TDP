-- ***********************************************
-- NAME 		: DUP0561_CarParking_Properties_NumOfCarParks.sql
-- DESCRIPTION 		: Updates the properties for Car Parking used in Find nearest car parks
--			  - Number of car parks returned to 50
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE FIND CAR PARK PROPERTIES
----------------------------------------

-- NUMBER OF CAR PARKS 
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.NumberCarParksReturned')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.NumberCarParksReturned'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.NumberCarParksReturned', '50', 'Web', 'UserPortal', 0)


-- SECOND RADIUS DISTANCE
IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Initial')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Initial'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.Radius2.Initial', '8046', 'Web', 'UserPortal', 0)


IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Maximum')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'FindNearestCarParks.Radius2.Maximum'
  END

INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('FindNearestCarParks.Radius2.Maximum', '8047', 'Web', 'UserPortal', 0)


GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 561
SET @ScriptDesc = 'Updates for Find nearest car park properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO