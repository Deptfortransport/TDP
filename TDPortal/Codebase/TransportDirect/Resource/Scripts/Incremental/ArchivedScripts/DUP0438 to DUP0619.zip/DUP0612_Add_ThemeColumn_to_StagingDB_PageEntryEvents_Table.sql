-- ***********************************************
-- NAME 		: DUP0612_Add_ThemeColumn to StagingDB_PageEntryEvent_Table.sql
-- DESCRIPTION 		: Add Theme column to PageEntryEvent table
--					 
-- AUTHOR		: ps
-- ************************************************


USE [ReportStagingDB]
GO

------------------------------------------------------------
-- TABLE MODIFICATIONS
------------------------------------------------------------


ALTER TABLE PageEntryEvent
ADD [ThemeID] [Int] DEFAULT 0
GO
------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 612
SET @ScriptDesc = 'Add Theme column to PageEntryEvent table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------