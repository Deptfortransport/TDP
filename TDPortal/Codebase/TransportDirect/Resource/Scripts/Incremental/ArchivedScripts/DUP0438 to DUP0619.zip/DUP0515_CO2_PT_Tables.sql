-- ************************************************************
-- NAME 	: DUP0515_CO2_PT_Tables.sql
-- DESCRIPTION 	: Creates the JourneyEmissionsFactor table
--  		: used to store the emission factors for public transport modes
-- ************************************************************

USE [PermanentPortal]
GO

------------------------------------------
-- Delete existing tables
------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[JourneyEmissionsFactor]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[JourneyEmissionsFactor]
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[LightRailSystemCode]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[LightRailSystemCode]
GO


------------------------------------------
-- Create table: JourneyEmissionsFactor
------------------------------------------

CREATE TABLE [dbo].[JourneyEmissionsFactor] (
	[FactorType] [varchar] (50) NOT NULL ,
	[FactorValue] [int] NULL
) ON [PRIMARY]
GO


------------------------------------------
-- Set the Primary Key
------------------------------------------

ALTER TABLE [dbo].[JourneyEmissionsFactor] ADD 
	CONSTRAINT [PK_JourneyEmissionsFactor] PRIMARY KEY  CLUSTERED 
	(
		[FactorType]
	)  ON [PRIMARY] 
GO


------------------------------------------
-- Create table: LightRail
------------------------------------------

CREATE TABLE [dbo].[LightRailSystemCode] (
	[TOCCode] [varchar] (10) NOT NULL ,
	[Service] [varchar] (50) NULL,
	[Mode] [varchar] (20) NULL,
	[SystemCode] [varchar] (10) NULL
) ON [PRIMARY]
GO


------------------------------------------
-- Set the Primary Key
------------------------------------------

ALTER TABLE [dbo].[LightRailSystemCode] ADD 
	CONSTRAINT [PK_LightRailSystemCode] PRIMARY KEY  CLUSTERED 
	(
		[TOCCode]
	)  ON [PRIMARY] 
GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 515
SET @ScriptDesc = 'Added JourneyEmissionsFactor table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO