-- ***********************************************
-- NAME :        DUP0457_UpdateRailOperatorCodes
-- DESCRIPTION : Remove Wessex Trains (WE) from the Rail operators 
--               tables in the transient portal DB.
-- ************************************************

USE TransientPortal
GO

Delete from dbo.OperatorLinks where OperatorCode = 'WE'

Delete from dbo.ServiceOperations where OperatorCode = 'WE'

Delete from dbo.ServiceOperators where OperatorCode = 'WE'



----------------------------------
-- Update the ChangeCatalogue
----------------------------------

USE PermanentPortal
IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 457)
BEGIN
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = getDate(),
		Summary = 'Remove Wessex Trains (WE) from the Rail operators tables in the transient portal DB.'
	WHERE ScriptNumber = 457
END
ELSE
BEGIN
	INSERT INTO dbo.ChangeCatalogue
	(
		ScriptNumber,
		ChangeDate,
		Summary
	)
	VALUES
	(
		457,
		getDate(),
		'Remove Wessex Trains (WE) from the Rail operators tables in the transient portal DB.'
	)
END
GO