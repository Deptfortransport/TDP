-- ************************************************************
-- NAME 	: DUP0493_CO2ChangeNotificationTableEntry.sql
-- DESCRIPTION 	: Creates entry for CarCostFuelFactor table in
--		  ChangeNotificationTable to ensure that updates are automatically propagated
-- ************************************************************

------------------------------
--changeNotification Table
-----------------------------

USE [PermanentPortal]
GO

--------------------------------------------------

IF EXISTS (SELECT * FROM ChangeNotification WHERE [Table] = 'CarCostFuelFactor')
  BEGIN
    DELETE FROM ChangeNotification WHERE [Table] = 'CarCostFuelFactor'
  END

INSERT INTO ChangeNotification ([version], [Table])
VALUES (1, 'CarCostFuelFactor')

GO
