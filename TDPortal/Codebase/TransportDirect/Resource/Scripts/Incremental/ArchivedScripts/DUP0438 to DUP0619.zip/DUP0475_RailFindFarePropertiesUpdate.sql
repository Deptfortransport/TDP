-- *************************************************************************************
-- NAME 		: DUP0475_RailFindFarePropertiesUpdate.sql
-- DESCRIPTION 		: Controls the availability of rail search by
--                      : price.
-- *************************************************************************************

------------------------
-- Properties Table
------------------------

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM Properties WHERE pName = 'FindAFareAvailable.Rail')
  BEGIN
    DELETE FROM Properties WHERE pName = 'FindAFareAvailable.Rail'
  END


INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('FindAFareAvailable.Rail', 'True', 'Web', '', 0)

GO

------------------------
-- Change Log 
------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = 475)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = 'Rail Find Fare Properties Update'
    WHERE ScriptNumber = 475
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (475, getDate(), 'Rail Find Fare Properties Update' )
  END
GO