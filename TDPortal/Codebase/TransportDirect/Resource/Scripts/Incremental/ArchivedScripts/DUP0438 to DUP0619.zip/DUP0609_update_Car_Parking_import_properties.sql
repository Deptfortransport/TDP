-- ***********************************************
-- NAME 		: DUP0609_update_Car_Parking_import_properties.sql
-- DESCRIPTION 		: Update importer setting for new ESRI importer and batchfile
--					 
-- AUTHOR		: SC
-- ************************************************


USE PermanentPortal
GO

Update IMPORT_CONFIGURATION
set PARAMETERS1 = 'D:\gateway\bat\etd565_TDP_Maps_import.bat'
where DATA_FEED = 'etd565'

GO

------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 609
SET @ScriptDesc = 'Update Car Parking import properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------