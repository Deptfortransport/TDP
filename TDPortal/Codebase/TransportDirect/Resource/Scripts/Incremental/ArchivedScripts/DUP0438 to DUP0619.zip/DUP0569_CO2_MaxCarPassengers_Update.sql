-- ***********************************************
-- NAME 		: DUP0569_CO2_MaxCarPassengers_Update.sql
-- DESCRIPTION 		: Properties update allowing different max passenger numbers for different size cars 
-- ************************************************

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxNumberOfCarPassengers')
  BEGIN
    DELETE FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxNumberOfCarPassengers'
  END

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxNumberOfCarPassengers.Small')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MaxNumberOfCarPassengers.Small', '5', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxNumberOfCarPassengers.Medium')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MaxNumberOfCarPassengers.Medium', '7', 'Web', 'UserPortal', 0)
GO

IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.MaxNumberOfCarPassengers.Large')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MaxNumberOfCarPassengers.Large', '7', 'Web', 'UserPortal', 0)
GO
