-- ***********************************************
-- NAME 		: DUP0611_Add_Partner_column_to_Reporting_PageEntryEvents_Table.sql
-- DESCRIPTION 		: Add Partner column to PageEntryEvents table
--					 
-- AUTHOR		: ps
-- ************************************************


USE [Reporting]
GO

------------------------------------------------------------
-- TABLE MODIFICATIONS
------------------------------------------------------------


ALTER TABLE PageEntryEvents
ADD [PEEPartnerID] [Int] DEFAULT 0
GO

----------------------------------------------------------

-- allocate partner to partnerid column based on suffix in the page entry type code

UPDATE PageEntryEvents
   SET PEEPartnerId = P.PartnerId
  FROM PageEntryEvents PEE
 INNER JOIN PageEntryType PET
         ON PET.PETID = PEE.PEEPETID
 INNER JOIN Partner P
         ON P.PartnerName = Substring (PET.PETCode, CharIndex('_', PET.PETCode) + 1, Len(P.PartnerName)) 

GO
----------------------------------------------------------

-- allocate new generic page entry id based on first part of current page entry id and the suffix in the page entry type code

UPDATE PageEntryEvents
   SET PEEPETID = PET2.PETID
  FROM PageEntryEvents PEE
 INNER JOIN PageEntryType PET1
         ON PET1.PETID = PEE.PEEPETID
        AND (
                PET1.PETCode LIKE '%/_BBC' ESCAPE '/'
             OR PET1.PETCode LIKE '%/_TransportDirect' ESCAPE '/'
             OR PET1.PETCode LIKE '%/_VisitBritain' ESCAPE '/'
             OR PET1.PETCode LIKE '%/_GNER' ESCAPE '/'
             OR PET1.PETCode LIKE '%/_DirectGov' ESCAPE '/'
            )
 INNER JOIN PageEntryType PET2
         ON PET2.PETCode = Substring (PET1.PETCode, 1, CharIndex('_', PET1.PETCode) - 1)

GO



-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)
SET @ScriptNumber = 611

SET @ScriptDesc = 'Add Theme column to PageEntryEvents table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------