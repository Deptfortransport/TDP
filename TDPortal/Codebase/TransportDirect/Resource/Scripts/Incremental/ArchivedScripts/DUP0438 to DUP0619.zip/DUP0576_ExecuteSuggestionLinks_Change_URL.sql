-- ***********************************************
-- NAME 		: DUP0576_ExecuteSuggestionLinks_Change_URL
-- DESCRIPTION 		: Update C02 Emmissions (Suggestion Links).
--			: Change to point at FAQ ("TransportDirect/en/Help/HelpCarbon") rather than
--			: FAQ ("TransportDirect/en/Help/HelpCosts") which have been removed.
-- AUTHOR		: Neil Rankin
-- ************************************************



-- EXEC UpdateSuggestionLinkURL
-- StringLinkURLOld    	varchar(100),		-- Existing link. Relative url if Internal, Absolute if External 						link
-- StringLinkURLNew    	varchar(100),		-- New link. Relative url if Internal, Absolute if External link
-- StringLinkDescription    	varchar(500),		-- Provide description if updating, otherwise leave blank
-- IsInternalLink		bit			-- 1 for Internal link, 0 for External

USE TransientPortal
GO

EXEC UpdateSuggestionLinkURL
	'Help/HelpCosts.aspx#A3.8', 
	'Help/HelpCarbon.aspx#A9.1', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCosts.aspx#A3.9', 
	'Help/HelpCarbon.aspx#A9.2', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCosts.aspx#A3.10', 
	'Help/HelpCarbon.aspx#A9.3', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCosts.aspx#A3.11', 
	'Help/HelpCarbon.aspx#A9.5', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCosts.aspx#A3.12', 
	'Help/HelpCarbon.aspx#A9.4', 
	'', 
	1

GO

------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 576
SET @ScriptDesc = 'Update C02 Emmissions (Suggestion Links)'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------