-- ***********************************************
-- NAME 		: DUP0575_ExecuteSuggestionLinks_StoredProcedures
-- DESCRIPTION 		: Stored Procedures to help with inserting/removing SuggestionLinks.
--			: Suggestion Links include the Left hand navigation links, Related links, and Suggestion Links
-- AUTHOR		: Mitesh Modi
-- ************************************************


-- ========================================================================================== 
-- Create the AddInternalLink storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddInternalLink'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddInternalLink] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddInternalLink
-- =============================================  
ALTER PROCEDURE [dbo].[AddInternalLink]
		@StringLinkURL    	  varchar(100),
		@StringLinkDescription    varchar(500)
AS    
BEGIN

	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)   

	DECLARE @InternalLinkID	INT

	SET NOCOUNT OFF

	IF NOT EXISTS(SELECT * FROM [InternalLink] WHERE [Description] = @StringLinkDescription)
		BEGIN
			SET @localString_UnableToCarryOutAction = 'Unable to insert new record ' + @StringLinkDescription + ' in Internal Links table'

			SET @InternalLinkID = (select MAX(InternalLinkId) from dbo.InternalLink) + 1

			INSERT INTO [dbo].[InternalLink] ([InternalLinkId], [RelativeURL] , [Description])
			SELECT @InternalLinkID , @StringLinkURL, @StringLinkDescription
		END
	ELSE
		BEGIN
			SET @localString_UnableToCarryOutAction = 'Unable to update record ' + @StringLinkDescription + ' in Internal Links table'

			UPDATE [dbo].[InternalLink]
			SET [RelativeURL] = @StringLinkURL
			WHERE [Description] = @StringLinkDescription		
		END


	IF @@error <> 0
    		BEGIN
		        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
		        RETURN -1
		END

END    

GO




-- ========================================================================================== 
-- Create the AddExternalLinkToSuggestionLink storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddExternalLinkToSuggestionLink'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddExternalLinkToSuggestionLink] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddExternalLinkToSuggestionLink
-- =============================================  
ALTER PROCEDURE [dbo].[AddExternalLinkToSuggestionLink]
		@StringExternalLinkID	varchar(500)
AS    
BEGIN

	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)   

	SET NOCOUNT OFF

	IF NOT EXISTS(SELECT * FROM [ExternalSuggestionLink] WHERE [ExternalLinkID] = @StringExternalLinkID)
		BEGIN
			SET @localString_UnableToCarryOutAction = 'Unable to add external link id ' + @StringExternalLinkID + ' to ExternalSuggestionLink'
			INSERT INTO [ExternalSuggestionLink] ([ExternalLinkID])
			VALUES (@StringExternalLinkID)
		END
	
	IF @@error <> 0
    		BEGIN
		        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
		        RETURN -1
		END

END    

GO




-- ========================================================================================== 
-- Create the AddResource storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddResource'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddResource] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddResource (resource name and display text)
-- =============================================  
ALTER PROCEDURE [dbo].[AddResource]    
		@StringLinkResourceName		varchar(100),
		@StringLinkResourceNameEN	varchar(100),
		@StringLinkResourceNameCY	varchar(100)
AS    
BEGIN

	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)   

	DECLARE @ResourceNameID INT,
		@ResourceID INT


	--insert into ResourceName table
	IF NOT EXISTS(SELECT * FROM [dbo].[ResourceName] WHERE [ResourceName] = @StringLinkResourceName) 
		BEGIN
			SET @ResourceNameID = (select MAX(ResourceNameId) from [dbo].[ResourceName]) + 1

			INSERT INTO [dbo].[ResourceName] ([ResourceNameId], [ResourceName]) 
			SELECT @ResourceNameID , @StringLinkResourceName
		END
	ELSE
		BEGIN
			SET @ResourceNameID = (select ResourceNameId from [dbo].[ResourceName] where [ResourceName] = @StringLinkResourceName)

			UPDATE [dbo].[ResourceName]
			SET [ResourceName] = @StringLinkResourceName
			WHERE [ResourceNameId] = @ResourceNameID
		END

	
	IF @@error <> 0
    		BEGIN
			SET @localString_UnableToCarryOutAction = 'Unable to add record' + @StringLinkResourceName + ' in ResourceName table'
			
		        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
		        RETURN -1
		END
	ELSE
		BEGIN	 
			--insert the display text into Resource table, or update only if display text provided
			-- English
			IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'en-GB') AND ([ResourceNameID] = @ResourceNameID))
			BEGIN
				SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1
				INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
				SELECT @ResourceID, @ResourceNameID, 'en-GB', @StringLinkResourceNameEN
			END
			ELSE
			BEGIN
				IF (@StringLinkResourceNameEN <> '')
				BEGIN
					SET @ResourceID = (select ResourceID from [dbo].[Resource] WHERE ([Culture] = 'en-GB') AND ([ResourceNameID] = @ResourceNameID))
					UPDATE [dbo].[Resource]
					SET [Text] = @StringLinkResourceNameEN
					WHERE [ResourceID] = @ResourceID
				END
			END		

			-- Welsh
			IF NOT EXISTS(SELECT * FROM [Resource] WHERE ([Culture] = 'cy-GB') AND ([ResourceNameID] = @ResourceNameID))
			BEGIN
				SET @ResourceID = (select MAX(ResourceId)from dbo.Resource) + 1
				INSERT INTO [Resource] ([ResourceId], [ResourceNameId], [Culture], [Text])
				SELECT @ResourceID, @ResourceNameID, 'cy-GB', @StringLinkResourceNameCY
			END
			ELSE
			BEGIN
				IF (@StringLinkResourceNameCY <> '')
				BEGIN
					SET @ResourceID = (select ResourceID from [dbo].[Resource] WHERE ([Culture] = 'cy-GB') AND ([ResourceNameID] = @ResourceNameID))
					UPDATE [dbo].[Resource]
					SET [Text] = @StringLinkResourceNameCY
					WHERE [ResourceID] = @ResourceID
				END
			END
		END

END

GO






-- ========================================================================================== 
-- Create the AddSuggestionLink storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddSuggestionLink'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddSuggestionLink] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddSuggestionLink (adds the link bringing together the url and display text)
-- =============================================  
ALTER PROCEDURE [dbo].[AddSuggestionLink]    
		@StringLinkResourceName	varchar(100),
		@StringLinkDescription	varchar(500),
		@LinkCategoryName 	varchar(100),
		@LinkPriority 		INT,
		@InternalLinkFlag	bit,
		@IsRoot			bit,
		@ExternalLinkID		varchar(500)
AS    
BEGIN

	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)  

	DECLARE @SuggestionLinkID INT,
		@LinkCategoryID INT, 
		@ResourceNameID INT,
		@InternalExternalLinkID INT,
		@StringInternalExternal varchar (10)


	-- Get the ID's needed for a new suggestion link record
	SET @LinkCategoryID = (select LinkCategoryID from [dbo].[LinkCategory] where [Name] = @LinkCategoryName)
	SET @ResourceNameID = (select ResourceNameID from [dbo].[ResourceName] where ResourceName = @StringLinkResourceName)

	IF (@InternalLinkFlag = 1)
	BEGIN
		SET @InternalExternalLinkID = (select InternalLinkID from [dbo].[InternalLink] where [Description] = @StringLinkDescription)
		SET @StringInternalExternal = 'Internal'
	END
	ELSE
	BEGIN
		SET @InternalExternalLinkID = (select ExternalSuggestionLinkID from [dbo].[ExternalSuggestionLink] where ExternalLinkID = @ExternalLinkID)
		SET @StringInternalExternal = 'External'
	END


	SET @SuggestionLinkID = (select MAX(SuggestionLinkId) from [dbo].[SuggestionLink]) + 1

	IF NOT EXISTS(SELECT * FROM [SuggestionLink] WHERE ([LinkCategoryId] = @LinkCategoryID) AND ([Priority] = @LinkPriority))
	BEGIN
		INSERT INTO [SuggestionLink] ([SuggestionLinkId], [LinkCategoryId], [Priority], [ResourceNameId], [ExternalInternalLinkId], [ExternalInternalLinkType], [IsRoot])
		SELECT @SuggestionLinkID, @LinkCategoryID, @LinkPriority, @ResourceNameID, @InternalExternalLinkID, @StringInternalExternal, @IsRoot
	END
	ELSE
	BEGIN
		SET @localString_UnableToCarryOutAction = 'Unable to add suggestion link with Link Category: ' + @LinkCategoryName 
			+ ', and Link Priority: ' + Cast( @LinkPriority as varchar(10) ) + '. Already exists in SuggestionLink table'
	        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
	        RETURN -1
	END
	
	IF @@error <> 0
    		BEGIN
			SET @localString_UnableToCarryOutAction = 'Unable to add record ' + @StringLinkResourceName + ' to SuggestionLink table'

		        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
		        RETURN -1
		END

END

GO






-- ========================================================================================== 
-- Create the AddContext storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddContext'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddContext] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddContext 
-- =============================================  
ALTER PROCEDURE [dbo].[AddContext]    
		@StringContextName		varchar(100),
		@StringContextDescription	varchar(500)
AS    
BEGIN
	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)   

	DECLARE @ContextId INT

	-- Add the context only if provided
	IF (@StringContextName <> '')
	BEGIN

		IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @StringContextName)
			BEGIN
				SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

				INSERT INTO [Context] ([ContextId], [Name], [Description])
				SELECT @ContextId, @StringContextName, @StringContextDescription 
			END
		ELSE
			BEGIN
				SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @StringContextName)
			
				IF (@StringContextDescription <> '')
					BEGIN
						UPDATE [dbo].[Context]
						SET [Description] = @StringContextDescription
						WHERE [ContextId] = @ContextId
					END
			END

		IF @@error <> 0
   			BEGIN
				SET @localString_UnableToCarryOutAction = 'Unable to update context ' + @StringContextName + ' in Context table'
			        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
			        RETURN -1
			END
	END

END

GO







-- ========================================================================================== 
-- Create the AddContextSuggestionLink storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddContextSuggestionLink'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddContextSuggestionLink] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddContextSuggestionLink 
-- =============================================  
ALTER PROCEDURE [dbo].[AddContextSuggestionLink]    
		@StringLinkResourceName		varchar(100),
		@LinkCategoryName 		varchar(100),
		@StringContextName		varchar(100)

AS    
BEGIN
	DECLARE @localString_UnableToCarryOutAction AS nvarchar(256)   

	DECLARE @ResourceNameID INT,
		@SuggestionLinkID INT,
		@LinkCategoryID INT,
		@ContextId INT,
		@ContextSuggestionLinkID INT
	
	-- only add to the table if context name provided
	IF (@StringContextName <> '')
	BEGIN

		-- set values needed for a new context suggestion link
		SET @LinkCategoryID = (select LinkCategoryID from [dbo].[LinkCategory] where [Name] = @LinkCategoryName)
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @StringContextName)

		SET @ResourceNameID = (select ResourceNameId from [dbo].[ResourceName] where [ResourceName] = @StringLinkResourceName)
		SET @SuggestionLinkID = (SELECT MAX(SuggestionLinkID) FROM [dbo].[SuggestionLink] WHERE [LinkCategoryId] = @LinkCategoryID
					AND [ResourceNameID] = @ResourceNameID)

		--insert into ContextSuggestionLink table
		IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
			BEGIN
				SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

				INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
				SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID
			END
		ELSE
			BEGIN
				SET @localString_UnableToCarryOutAction = 'Unable to add context suggestion link, already exists for Context: ' + @LinkCategoryName 
					+ ', and Suggestion Link: ' + CAST(@SuggestionLinkID as varchar(10))
				RAISERROR (@localString_UnableToCarryOutAction, 1,1)
			        RETURN -1
			END

		IF @@error <> 0
	   		BEGIN
				SET @localString_UnableToCarryOutAction = 'Unable to add context suggestion link ' + @StringLinkResourceName + ' in table'
			        RAISERROR (@localString_UnableToCarryOutAction, 1,1)
		        	RETURN -1
			END
	
	END

END

GO





-- ========================================================================================== 
-- Create the AddInternalSuggestionLink storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddInternalSuggestionLink'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddInternalSuggestionLink] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddInternalSuggestionLink - wrapper stored procedure to call the appropriate add suggestion
--						link stored procedures in order
-- =============================================  
ALTER PROCEDURE [dbo].[AddInternalSuggestionLink]    
		@StringLinkURL    	  	varchar(100),	-- Relative internal link URL
		@StringLinkDescription    	varchar(500),	-- Description of internal link. Ensure this is a unique internal link description
		@StringLinkResourceName		varchar(100),  	-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
		@StringLinkResourceNameEN 	varchar(100),	-- English display text. Populate only if adding new ResourceName or updating existing display text
		@StringLinkResourceNameCY	varchar(100),	-- Welsh display text. Populate only if adding new ResourceName or updating existing display text
		@LinkCategoryName 		varchar(100),  	-- Use 'General' if not a left hand navigation link
		@LinkPriority 			int,		-- Priority must be unique for the selected CategoryName this link is for
		@IsRoot				bit,		-- Set to 1 if to be used as a Suggestion/Related Link
		@StringContextName		varchar(100),	-- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
		@StringContextDescription	varchar(500)	-- Populate only if adding a new ContextName, or updating description
AS    
BEGIN
	DECLARE @InternalLinkFlag bit

	SET @InternalLinkFlag = 1

	-- Execute the stored procedures to add suggestion link
	EXEC AddInternalLink @StringLinkURL, @StringLinkDescription 

	EXEC AddResource @StringLinkResourceName, @StringLinkResourceNameEN, @StringLinkResourceNameCY 

	EXEC AddSuggestionLink @StringLinkResourceName, @StringLinkDescription, @LinkCategoryName, @LinkPriority, 
				@InternalLinkFlag, @IsRoot, ''

	EXEC AddContext @StringContextName, @StringContextDescription 

	EXEC AddContextSuggestionLink @StringLinkResourceName, @LinkCategoryName, @StringContextName 

END

GO





-- ========================================================================================== 
-- Create the AddExternalSuggestionLink storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'AddExternalSuggestionLink'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[AddExternalSuggestionLink] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: AddExternalSuggestionLink - wrapper stored procedure to call the appropriate add suggestion
--						link stored procedures in order
-- =============================================  
ALTER PROCEDURE [dbo].[AddExternalSuggestionLink]
		@StringExternalLinkID		varchar(500),  	-- ID for ExternalLink table
		@StringLinkURL    	  	varchar(500),
		@StringTestURL    	  	varchar(500),
		@StringLinkDescription    	varchar(500),
		@StringLinkResourceName		varchar(100),  	-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
		@StringLinkResourceNameEN 	varchar(100),	-- English display text. Populate only if adding new ResourceName or updating existing display text
		@StringLinkResourceNameCY	varchar(100),	-- Welsh display text. Populate only if adding new ResourceName or updating existing display text
		@LinkCategoryName 		varchar(100),  	-- Use 'General' if not a left hand navigation link
		@LinkPriority 			int,		-- Priority must be unique for the selected CategoryName this link is for
		@IsRoot				bit,		-- Set to 1 if to be used as a Suggestion/Related Link
		@StringContextName		varchar(100),	-- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
		@StringContextDescription	varchar(500)	-- Populate only if adding a new ContextName, or updating description
AS    
BEGIN
	DECLARE @InternalLinkFlag bit

	SET @InternalLinkFlag = 0

	-- Execute the stored procedures to add suggestion link
	EXEC AddExternalLink @StringExternalLinkID, @StringLinkURL, @StringTestURL, @StringLinkDescription

	EXEC AddExternalLinkToSuggestionLink @StringExternalLinkID
	
	EXEC AddResource @StringLinkResourceName, @StringLinkResourceNameEN, @StringLinkResourceNameCY 

	EXEC AddSuggestionLink @StringLinkResourceName, @StringLinkDescription, @LinkCategoryName, @LinkPriority, 
				@InternalLinkFlag, @IsRoot, @StringExternalLinkID 

	EXEC AddContext @StringContextName, @StringContextDescription 

	EXEC AddContextSuggestionLink @StringLinkResourceName, @LinkCategoryName, @StringContextName 

END

GO





-- ========================================================================================== 
-- Create the RemoveSuggestionLink storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'RemoveSuggestionLink'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[RemoveSuggestionLink] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: RemoveSuggestionLink - stored procedure to remove the ContextSuggestionLink and the SuggestionLink.
--				     - this does not remove the internal/external link record or associated ResourceName record
-- =============================================  
ALTER PROCEDURE [dbo].[RemoveSuggestionLink]
		@StringLinkResourceName		varchar(100),
		@LinkCategoryName 		varchar(100),
		@StringContextName		varchar(100)
AS    
BEGIN
		DECLARE @ResourceNameID INT,
			@LinkCategoryID INT,
			@ContextId INT
	
	-- set values needed to remove suggestion link
	SET @LinkCategoryID = (select LinkCategoryID from [dbo].[LinkCategory] where [Name] = @LinkCategoryName)
	SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @StringContextName)

	SET @ResourceNameID = (select ResourceNameId from [dbo].[ResourceName] where [ResourceName] = @StringLinkResourceName)


	-- Remove from the ContextSuggestionLink table first
	DELETE FROM [ContextSuggestionLink] WHERE [SuggestionLinkId] IN 
		(SELECT [SuggestionLinkID] FROM [dbo].[SuggestionLink] WHERE [LinkCategoryId] = @LinkCategoryID
				AND [ResourceNameID] = @ResourceNameID )

	-- Remove from the SuggestionLink table
	DELETE FROM [SuggestionLink] WHERE [LinkCategoryId] = @LinkCategoryID AND [ResourceNameID] = @ResourceNameID
END

GO





-- ========================================================================================== 
-- Create the UpdateSuggestionLinkDisplayText storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'UpdateSuggestionLinkDisplayText'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[UpdateSuggestionLinkDisplayText] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: UpdateSuggestionLinkDisplayText - updates the display text of a suggestion link url
-- =============================================  
ALTER PROCEDURE [dbo].[UpdateSuggestionLinkDisplayText]
		@StringLinkResourceName		varchar(100), 	-- ResourceName of suggestion link must be known
		@StringLinkResourceNameEN	varchar(100), 	-- New display text, English
		@StringLinkResourceNameCY	varchar(100)	-- New display text, Welsh
AS    
BEGIN

	EXEC AddResource @StringLinkResourceName, @StringLinkResourceNameEN, @StringLinkResourceNameCY 

END

GO



-- ========================================================================================== 
-- Create the UpdateSuggestionLinkURL storedprocedure
-- ========================================================================================== 

USE [TransientPortal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'UpdateSuggestionLinkURL'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[UpdateSuggestionLinkURL] AS BEGIN SET NOCOUNT ON END')
	END
GO

-- =============================================  
-- Description: UpdateSuggestionLinkURL - updates the url of a suggestion link
-- =============================================  
ALTER PROCEDURE [dbo].[UpdateSuggestionLinkURL]
		@StringLinkURLOld    	  varchar(100),		-- Existing link. Relative url if Internal, Absolute if External link
		@StringLinkURLNew    	  varchar(100),		-- New link. Relative url if Internal, Absolute if External link
		@StringLinkDescription    varchar(500),		-- Provide description if updating, otherwise leave blank
		@IsInternalLink		  bit			-- 1 for Internal link, 0 for External
AS    
BEGIN
	IF (@IsInternalLink = 1)
		BEGIN
			IF (@StringLinkDescription <> '')
				BEGIN
					UPDATE 	[dbo].[InternalLink]
					SET 	[Description] = @StringLinkDescription
					WHERE 	[RelativeURL] = @StringLinkURLOld
				END

			UPDATE 	[dbo].[InternalLink]
			SET 	[RelativeURL] = @StringLinkURLNew
			WHERE 	[RelativeURL] = @StringLinkURLOld
		END
	ELSE
		BEGIN
			IF (@StringLinkDescription <> '')
				BEGIN
					UPDATE 	[dbo].[ExternalLinks]
					SET 	[Description] = @StringLinkDescription
					WHERE 	[URL] = @StringLinkURLOld
				END

			UPDATE 	[dbo].[ExternalLinks]
			SET 	[URL] = @StringLinkURLNew
			WHERE 	[URL] = @StringLinkURLOld			
		END

END

GO


------------------------------------------------------------
-- ADD PERMISSIONS TO ALL THE STORED PROCEDURES
GRANT  EXECUTE  ON [dbo].[AddInternalLink]  			TO [???]	-- Helper stored proc called by a stored proc
GRANT  EXECUTE  ON [dbo].[AddExternalLinkToSuggestionLink]  	TO [???]	-- Helper stored proc called by a stored proc
GRANT  EXECUTE  ON [dbo].[AddResource]  			TO [???]	-- Helper stored proc called by a stored proc
GRANT  EXECUTE  ON [dbo].[AddSuggestionLink]  			TO [???]	-- Helper stored proc called by a stored proc
GRANT  EXECUTE  ON [dbo].[AddContext]  				TO [???]	-- Helper stored proc called by a stored proc
GRANT  EXECUTE  ON [dbo].[AddContextSuggestionLink]  		TO [???]	-- Helper stored proc called by a stored proc
GRANT  EXECUTE  ON [dbo].[AddInternalSuggestionLink]  		TO [???]	-- Stored proc called by a sql script
GRANT  EXECUTE  ON [dbo].[AddExternalSuggestionLink]  		TO [???]	-- Stored proc called by a sql script
GRANT  EXECUTE  ON [dbo].[RemoveSuggestionLink]  		TO [???]	-- Stored proc called by a sql script
GRANT  EXECUTE  ON [dbo].[UpdateSuggestionLinkDisplayText]  	TO [???]	-- Stored proc called by a sql script
GRANT  EXECUTE  ON [dbo].[UpdateSuggestionLinkURL]  		TO [???]	-- Stored proc called by a sql script

GO
------------------------------------------------------------


------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 575
SET @ScriptDesc = 'Suggestion links, variou helper stored procedures added'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------