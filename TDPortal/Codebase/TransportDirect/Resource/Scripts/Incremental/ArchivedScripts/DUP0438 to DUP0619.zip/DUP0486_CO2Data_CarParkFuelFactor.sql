-- *************************************************************************************
-- NAME 		: DUP0486_CO2Data_CarParkFuelFactor.sql
-- DESCRIPTION 		: Adds the Car Cost Fuel Factors
-- *************************************************************************************

------------------------
-- CarCostFuelFactors Table
------------------------

USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Insert petrol fuel factor
----------------------------------------------------------------
IF EXISTS (SELECT * FROM CarCostFuelFactor WHERE fueltype = 'petrol')
  BEGIN
    DELETE FROM CarCostFuelFactor WHERE fueltype = 'petrol'
  END

INSERT INTO CarCostFuelFactor (fueltype, factor)
VALUES ('petrol', '234')

GO

----------------------------------------------------------------
-- Insert diesel fuel factor
----------------------------------------------------------------
IF EXISTS (SELECT * FROM CarCostFuelFactor WHERE fueltype = 'diesel')
  BEGIN
    DELETE FROM CarCostFuelFactor WHERE fueltype = 'diesel'
  END

INSERT INTO CarCostFuelFactor (fueltype, factor)
VALUES ('diesel', '264')

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 486
SET @ScriptDesc = 'Added CarCostFuelFactor data values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO