-- ***********************************************
-- Name :        DUP0570_CreateExternalSuggestionLinksTable.sql
-- DESCRIPTION : Creates the External links database table
-- ************************************************

USE [TransientPortal]
GO

-----------------------------------------------
-- Drop the table
-----------------------------------------------
IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[ExternalSuggestionLink]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[ExternalSuggestionLink]
GO

-----------------------------------------------
-- Create the table
-----------------------------------------------

CREATE TABLE [dbo].[ExternalSuggestionLink] (
	[ExternalSuggestionLinkID] [int] IDENTITY (1, 1) NOT NULL ,
	[ExternalLinkID] [varchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ExternalSuggestionLink] ADD 
	CONSTRAINT [PK_ExternalSuggestionLink] PRIMARY KEY  CLUSTERED 
	(
		[ExternalSuggestionLinkID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ExternalSuggestionLink] ADD 
	CONSTRAINT [FK_ExternalSuggestionLink_ExternalLinks] FOREIGN KEY 
	(
		[ExternalLinkID]
	) REFERENCES [dbo].[ExternalLinks] (
		[Id]
	)
GO


-----------------------------------------------
-- Update Suggestion Link table to allow External link type
-----------------------------------------------
ALTER TABLE [dbo].[SuggestionLink] DROP
	CONSTRAINT  [CK_ExternalInternalLinkType]
GO

ALTER TABLE [dbo].[SuggestionLink] ADD 
	CONSTRAINT [CK_ExternalInternalLinkType] CHECK ([ExternalInternalLinkType] = 'Internal' or [ExternalInternalLinkType] = 'External')
GO

-------------------------------------------------
-- Update the ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 570
SET @ScriptDesc = 'Creates the ExternalSuggestionLink table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO