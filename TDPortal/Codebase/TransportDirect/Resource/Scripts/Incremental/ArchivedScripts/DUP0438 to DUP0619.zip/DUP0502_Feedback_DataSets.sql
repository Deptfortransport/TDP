-- ***********************************************
-- NAME 		: DUP0502_Feedback_DataSets.sql
-- DESCRIPTION 		: Adds the datasets required for the Feedback page controls
-- ************************************************

USE PermanentPortal
GO

----------------------------------------------------------------
-- Delete appropriate datasets before adding
----------------------------------------------------------------
DELETE FROM DropDownLists WHERE DataSet = 'UserFeedbackType'
DELETE FROM DropDownLists WHERE DataSet = 'UserFeedbackJourneyConfirm'
DELETE FROM DropDownLists WHERE DataSet = 'UserFeedbackJourneyResult'
DELETE FROM DropDownLists WHERE DataSet = 'UserFeedbackOtherOptions'
DELETE FROM DropDownLists WHERE DataSet = 'UserFeedbackSearchType'
GO

DELETE FROM properties WHERE pName LIKE 'TransportDirect.UserPortal.DataServices.UserFeedbackType.%' AND PartnerId = 0
DELETE FROM properties WHERE pName LIKE 'TransportDirect.UserPortal.DataServices.UserFeedbackJourneyConfirm.%' AND PartnerId = 0
DELETE FROM properties WHERE pName LIKE 'TransportDirect.UserPortal.DataServices.UserFeedbackJourneyResult.%' AND PartnerId = 0
DELETE FROM properties WHERE pName LIKE 'TransportDirect.UserPortal.DataServices.UserFeedbackOtherOptions.%' AND PartnerId = 0
DELETE FROM properties WHERE pName LIKE 'TransportDirect.UserPortal.DataServices.UserFeedbackSearchType.%' AND PartnerId = 0
GO

DELETE FROM DataSet WHERE DataSet = 'UserFeedbackType' AND PartnerId = 0
DELETE FROM DataSet WHERE DataSet = 'UserFeedbackJourneyConfirm' AND PartnerId = 0
DELETE FROM DataSet WHERE DataSet = 'UserFeedbackJourneyResult' AND PartnerId = 0
DELETE FROM DataSet WHERE DataSet = 'UserFeedbackOtherOptions' AND PartnerId = 0
DELETE FROM DataSet WHERE DataSet = 'UserFeedbackSearchType' AND PartnerId = 0
GO

----------------------------------------------------------------
-- Create Data Set types
----------------------------------------------------------------
INSERT INTO DataSet (DataSet, PartnerId) VALUES ('UserFeedbackType', 0)
INSERT INTO DataSet (DataSet, PartnerId) VALUES ('UserFeedbackJourneyConfirm', 0)
INSERT INTO DataSet (DataSet, PartnerId) VALUES ('UserFeedbackJourneyResult', 0)
INSERT INTO DataSet (DataSet, PartnerId) VALUES ('UserFeedbackOtherOptions', 0)
INSERT INTO DataSet (DataSet, PartnerId) VALUES ('UserFeedbackSearchType', 0)
GO


----------------------------------------------------------------
-- Add data sets to properties list
----------------------------------------------------------------
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackType.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''UserFeedbackType'' AND PartnerId = 0 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackType.db', 'DefaultDB', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackType.type', '3', 'DataServices', 'UserPortal', 0)
GO


INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackJourneyConfirm.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''UserFeedbackJourneyConfirm'' AND PartnerId = 0 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackJourneyConfirm.db', 'DefaultDB', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackJourneyConfirm.type', '3', 'DataServices', 'UserPortal', 0)
GO


INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackJourneyResult.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''UserFeedbackJourneyResult'' AND PartnerId = 0 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackJourneyResult.db', 'DefaultDB', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackJourneyResult.type', '3', 'DataServices', 'UserPortal', 0)
GO


INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackOtherOptions.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''UserFeedbackOtherOptions'' AND PartnerId = 0 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackOtherOptions.db', 'DefaultDB', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackOtherOptions.type', '3', 'DataServices', 'UserPortal', 0)
GO

INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackSearchType.query', 'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''UserFeedbackSearchType'' AND PartnerId = 0 ORDER BY SortOrder', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackSearchType.db', 'DefaultDB', 'DataServices', 'UserPortal', 0)
INSERT INTO properties (pName, pValue, AID, GID, PartnerId)
  VALUES ('TransportDirect.UserPortal.DataServices.UserFeedbackSearchType.type', '3', 'DataServices', 'UserPortal', 0)
GO

----------------------------------------------------------------
-- Create the items in the data sets
----------------------------------------------------------------
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackType', 'Report a problem', '1', 0, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackType', 'Make a suggestion', '2', 0, 2, 0)
GO

INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackJourneyConfirm', 'Yes', '11', 0, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackJourneyConfirm', 'No', '12', 0, 2, 0)
GO

INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackJourneyResult', 'I didn�t get any results', '21', 0, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackJourneyResult', 'I had a problem with the results', '22', 0, 2, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackJourneyResult', 'Other', '23', 0, 3, 0)
GO

INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackOtherOptions', 'Accessibility', '31', 0, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackOtherOptions', 'A map', '32', 0, 2, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackOtherOptions', 'Another journey', '33', 0, 3, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackOtherOptions', 'Finding places', '34', 0, 4, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackOtherOptions', 'Fares and tickets', '35', 0, 5, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackOtherOptions', 'Live travel information', '36', 0, 6, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackOtherOptions', 'Other', '37', 0, 7, 0)
GO

INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Door-to-door', '41', 0, 1, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Find a train', '42', 0, 2, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Find a flight', '43', 0, 3, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Find a car route', '44', 0, 4, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Find a coach', '45', 0, 5, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Find a bus', '46', 0, 6, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'City-to-city', '47', 0, 7, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Day trip planner', '48', 0, 8, 0)
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId) VALUES ('UserFeedbackSearchType', 'Plan to park and ride', '49', 0, 9, 0)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 502
SET @ScriptDesc = 'Added the Feedback data sets'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
