-- ***********************************************
-- NAME 		: DUP0580_AddRailReplacementBusServiceOperationsRecords.sql
-- DESCRIPTION 		: Adds Rail Replacement Bus service operations records for all rail
--			  operators - so that the hyperlinks still appear in journey results.
-- ************************************************

USE [TransientPortal]
GO

---------------------------------------------------------------------------------------------------------------
-- Add records based on rail mode ones already there, only where railreplacementbus one not already present.
---------------------------------------------------------------------------------------------------------------

INSERT INTO serviceoperations (OperatorCode, ModeId)
	SELECT OperatorCode, 'RailReplacementBus'
	FROM serviceoperations so1
	WHERE ModeId = 'Rail'
	AND NOT Exists (SELECT *
	FROM serviceoperations so2
	WHERE ModeId = 'RailReplacementBus'
	AND so1.OperatorCode = so2.OperatorCode)

INSERT INTO operatorlinks (OperatorCode, ModeId, OperatorLinkId)
	SELECT OperatorCode, 'RailReplacementBus', OperatorLinkId
	FROM operatorlinks ol1
	WHERE ModeId = 'Rail'
	AND NOT Exists (SELECT *
	FROM operatorlinks ol2
	WHERE ModeId = 'RailReplacementBus'
	AND ol1.OperatorCode = ol2.OperatorCode)

GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 580
SET @ScriptDesc = 'Add Rail Replacement Bus Service Operations Records'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO