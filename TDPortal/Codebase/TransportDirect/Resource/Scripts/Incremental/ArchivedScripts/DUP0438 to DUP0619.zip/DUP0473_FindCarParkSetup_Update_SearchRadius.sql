-- ***********************************************
-- NAME 		: DUP0473_FindCarParkSetup_Update_SearchRadius.sql
-- DESCRIPTION 		: Update to car park search radius
-- ************************************************

USE PermanentPortal
GO


-- UPDATE FIND CAR PARK PROPERTY

IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.InitialRadius')
  BEGIN
	UPDATE Properties
	SET pValue = '8046'
	WHERE pName = 'FindNearestCarParks.InitialRadius'
  END
ELSE
  BEGIN
	INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
	VALUES ('FindNearestCarParks.InitialRadius', '8046', '<DEFAULT>', '<DEFAULT>', 0)
  END
GO

IF EXISTS(SELECT * FROM [properties] WHERE [pName] = 'FindNearestCarParks.MaximumRadius')
  BEGIN
	UPDATE Properties
	SET pValue = '8047'
	WHERE pName = 'FindNearestCarParks.MaximumRadius'
  END
ELSE
  BEGIN
	INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
	VALUES ('FindNearestCarParks.MaximumRadius', '8047', '<DEFAULT>', '<DEFAULT>', 0)
  END
GO


-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 473
SET @ScriptDesc = 'Updated find car park search radius to 8km'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO