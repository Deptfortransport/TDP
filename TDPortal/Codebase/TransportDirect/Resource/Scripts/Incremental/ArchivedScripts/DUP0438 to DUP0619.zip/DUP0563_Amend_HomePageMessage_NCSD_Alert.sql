-- ***********************************************
-- NAME 		: DUP0563_Amend_HomePageMessage_NCSD_Alert.sql
-- DESCRIPTION 		: Updates the Coach Planning HomePageMessage Text.
--
-- ************************************************

USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE TEXT
----------------------------------------

UPDATE HomePageMessage SET ValueEN = '<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</td></tr>'
WHERE Description = 'NCSD'

UPDATE HomePageMessage SET ValueCY = '<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</td></tr>'
WHERE Description = 'NCSD'

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 563
SET @ScriptDesc = 'Updates the Coach Planning HomePageMessage Text.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO