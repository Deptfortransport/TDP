-- ***********************************************
-- NAME		: DUP0464_CarParkingVisibilitySwitch.sql
-- DESCRIPTION 	: Adds new visibility switch property 
--                for CarParking.
-- ***********************************************

USE PermanentPortal


-- DESCRIPTION : Add new properties table entry. Value of property will be 
--               checked in car parking pages to determine whether or not 
--               to display car parking functionality


INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('CarParkingAvailable', 'True', '<DEFAULT>', '<DEFAULT>', 0)

GO


-- Change Log

  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (464, getDate(), 'Added new car parking visiblity switch to Properties' )
  END
GO

