-- ************************************************************
-- NAME 	: DUP0545_NXFares_StoredProcedures.sql
-- DESCRIPTION 	: Creates new stored procedure GetCoachFares,
--              : deleting if it exists
-- ************************************************************

USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Check for existance of the procedure and if it exists drop it
----------------------------------------------------------------
IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'PermanentPortal' 
              AND ROUTINE_NAME = 'GetCoachFares' )
BEGIN
    DROP PROCEDURE [GetCoachFares]
END

GO

---------------------------------------------------------------
-- Create new SP
----------------------------------------------------------------

CREATE PROCEDURE [dbo].[GetCoachFares]
AS
	SELECT	[FareTypeCode],
		[Description],
		[Amendable],
		[Refundable],
		[RestrictionPriority],
		[Action]
	FROM 	[CoachFares]
GO

GRANT  EXECUTE  ON [dbo].[GetCoachFares]  TO [???]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 545
SET @ScriptDesc = 'Added GetCoachFares stored procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO