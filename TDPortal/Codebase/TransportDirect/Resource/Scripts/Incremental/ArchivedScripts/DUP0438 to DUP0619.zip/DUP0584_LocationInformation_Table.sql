-- ***********************************************
-- NAME 		: DUP0584_LocationInformation_Table.sql
-- DESCRIPTION 		: sql to setup the Airport Links import (Location Information) tables
--			: and add to Change notification table
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [TransientPortal]
GO
-------------------------------------------------------------------------
-- CREATE TABLE
-------------------------------------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects 
WHERE ID = object_id(N'dbo.LocationInformation') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[LocationInformation] (
	[LocationInformationID] [int] IDENTITY (1, 1) NOT NULL ,
	[Naptan] [varchar] (12) NOT NULL ,
	[ExternalLinkID] [varchar] (500) NOT NULL,
	[LinkType] [varchar] (20) NOT NULL 
) ON [PRIMARY]
END
GO

ALTER TABLE [dbo].[LocationInformation] WITH NOCHECK ADD 
	CONSTRAINT [PK_LocationInformation] PRIMARY KEY  CLUSTERED 
	(
		[LocationInformationID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[LocationInformation] ADD 
	CONSTRAINT [UQ_LocationInformation] UNIQUE  NONCLUSTERED 
	(
		[ExternalLinkID],
		[Naptan]
	)  ON [PRIMARY] 
GO


-------------------------------------------------------------------------
-- ADD TABLE TO ChangeNotification TABLE
-------------------------------------------------------------------------

USE [TransientPortal]
GO


IF EXISTS (SELECT * FROM ChangeNotification WHERE [Table] = 'LocationInformation')
  BEGIN
    DELETE FROM ChangeNotification WHERE [Table] = 'LocationInformation'
  END

INSERT INTO ChangeNotification ([version], [Table])
VALUES (0, 'LocationInformation')

GO


-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 584
SET @ScriptDesc = 'Create LocationInformation table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------