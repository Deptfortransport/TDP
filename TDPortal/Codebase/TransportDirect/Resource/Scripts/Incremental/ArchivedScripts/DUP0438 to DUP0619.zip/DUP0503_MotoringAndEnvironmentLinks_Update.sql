-- *************************************************************************************
-- NAME 		: DUP0503_MotoringAndEnvironmentLinks_Update.sql
-- DESCRIPTION 		: Updating MotoringAndEnvironment link in External Links table (vantive 4522058)
-- Added by		: Darshan Sawe
-- Date 		: 11/Jan/2007
-- *************************************************************************************

USE [TransientPortal]
GO


------------------------
-- Related Links
------------------------


IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.MotoringAndEnvironment')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.MotoringAndEnvironment'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.MotoringAndEnvironment', 'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R', 'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R', '1', 'Motoring and Environment', NULL, NULL, NULL)

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 503
SET @ScriptDesc = 'Updating MotoringAndEnvironment link in External Links table (vantive 4522058)'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO