-- *************************************************************************************
-- NAME 		: DUP0481_RailCostResultsScrollPoint.sql
-- DESCRIPTION 		: Updates scroll point settings for rail search by cost results
-- *************************************************************************************

USE [PermanentPortal]
GO

-- Remove Existing Properties
DELETE FROM Properties WHERE pName = 'FindSummaryResultControl.Scrollpoint.RailCost'
DELETE FROM Properties WHERE pName = 'FindSummaryResultControl.FixedHeight.RailCost'

-- Scroll Points
INSERT INTO Properties (pName, pValue, AID, GID, PartnerId) VALUES ('FindSummaryResultControl.Scrollpoint.RailCost', '10', 'Web', 'UserPortal', 0)
INSERT INTO Properties (pName, pValue, AID, GID, PartnerId) VALUES ('FindSummaryResultControl.Scrollpoint.RailCost', '10', 'Microsite', 'UserPortal', 0)

-- Fixed Height Keys
INSERT INTO Properties (pName, pValue, AID, GID, PartnerId) VALUES ('FindSummaryResultControl.FixedHeight.RailCost', '200px', 'Web', 'UserPortal', 0)
INSERT INTO Properties (pName, pValue, AID, GID, PartnerId) VALUES ('FindSummaryResultControl.FixedHeight.RailCost', '200px', 'Microsite', 'UserPortal', 0)

GO

-- Change Catalogue

USE [PermanentPortal]

DELETE ChangeCatalogue WHERE ScriptNumber = 481
INSERT INTO ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
VALUES (481, GETDATE(), 'RailCostResultsScrollPoint')

GO