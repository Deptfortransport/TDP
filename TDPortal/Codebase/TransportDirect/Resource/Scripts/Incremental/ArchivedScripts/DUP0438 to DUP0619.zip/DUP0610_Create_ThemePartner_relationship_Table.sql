-- ***********************************************
-- NAME 		: DUP0610_Create_ThemePartner_relationship_Table.sql
-- DESCRIPTION 		: create new Theme-Partner translation table
--					 
-- AUTHOR		: ps
-- ************************************************


USE [Reporting]
GO


if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ThemePartner]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
CREATE TABLE [dbo].[ThemePartner] (
	[ThemeId] [int] NOT NULL ,
	[PartnerId] [int] NOT NULL ,
) ON [PRIMARY] 
GO

GO

------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 610
SET @ScriptDesc = 'Create Theme-Partner relationship table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------