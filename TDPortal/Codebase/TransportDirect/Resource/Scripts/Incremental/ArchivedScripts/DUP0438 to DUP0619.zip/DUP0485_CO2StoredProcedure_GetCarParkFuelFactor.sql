-- ************************************************************
-- NAME 	: DUP0485_CO2StoredProcedure_GetCarParkFuelFactor.sql 
-- DESCRIPTION 	: Deletes previous stored procedure to obtain
--		  Car Cost Fuel Factors and creates new stored procedure
-- ************************************************************

USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Check for existance of the procedure and if it exists drop it
----------------------------------------------------------------
IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'PermanentPortal' 
              AND ROUTINE_NAME = 'GetCarCostFuelFactor' )
BEGIN
    DROP PROCEDURE GetCarCostFuelFactor
END

GO

----------------------------------------------------------------
-- Create new SP
----------------------------------------------------------------
CREATE PROCEDURE dbo.GetCarCostFuelFactor
AS
	SELECT	fueltype,
		factor
	FROM 	CarCostFuelFactor
	ORDER BY fueltype
GO

GRANT  EXECUTE  ON [dbo].[GetCarCostFuelFactor]  TO [???????????????]
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 485
SET @ScriptDesc = 'Added GetCarCostFuelFactor stored procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO