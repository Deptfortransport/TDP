-- *************************************************************************************
-- NAME 		: DUP0518_CO2_PT_LightRailSystemsData.sql
-- DESCRIPTION 		: Adds the LightRail system codes data to LightrailSystemCode
-- *************************************************************************************


USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Insert light rail codes
----------------------------------------------------------------
IF EXISTS (SELECT * FROM LightRailSystemCode WHERE [TOCCode] = 'C5')
  BEGIN
    DELETE FROM LightRailSystemCode WHERE [TOCCode] = 'C5'
  END

INSERT INTO LightRailSystemCode (TOCCode, Service, Mode, SystemCode)
VALUES ('C5', 'LUL between Amersham and Baker street', 'Underground', 'LU')

GO

IF EXISTS (SELECT * FROM LightRailSystemCode WHERE [TOCCode] = 'C3')
  BEGIN
    DELETE FROM LightRailSystemCode WHERE [TOCCode] = 'C3'
  END

INSERT INTO LightRailSystemCode (TOCCode, Service, Mode, SystemCode)
VALUES ('C3', 'Newcastle Metro', 'Metro', 'TW')

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 518
SET @ScriptDesc = 'Added lightrail system code data values'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO