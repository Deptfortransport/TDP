-- ***********************************************
-- NAME 		: DUP0500_iFrames_PageEntry.sql
-- DESCRIPTION 		: Addded page entry event type for Landing pages of iFrames functionality
-- ************************************************

-- INSERT PAGE ENTRY EVENTS
USE Reporting
GO

--------------------------------------------
------JourneyLandingPage Page Entry
--------------------------------------------

IF EXISTS (SELECT * FROM PageEntryType WHERE PETCode = 'JourneyLandingPage')
  BEGIN
    DELETE FROM PageEntryType WHERE PETCode  = 'JourneyLandingPage'
  END

INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'JourneyLandingPage', 'JourneyLandingPage for journeyplanning iFrame' FROM PageEntryType

GO

--------------------------------------------
------LocationLandingPage Page Entry
--------------------------------------------
IF EXISTS (SELECT * FROM PageEntryType WHERE PETCode = 'LocationLandingPage')
  BEGIN
    DELETE FROM PageEntryType WHERE PETCode  = 'LocationLandingPage'
  END

INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
SELECT MAX(PETID)+1, 'LocationLandingPage', 'LocationLandingPage for findaplace iFrame' FROM PageEntryType

GO


-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 500
SET @ScriptDesc = 'Addded page entry event type for Landing pages for iFrames'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO