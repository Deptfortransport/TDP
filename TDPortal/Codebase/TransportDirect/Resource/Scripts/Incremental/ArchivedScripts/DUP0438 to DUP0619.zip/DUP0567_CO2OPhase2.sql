-- *************************************************************************************
-- NAME 		: DUP0567_CO2Phase2.sql
-- DESCRIPTION 		: Updates the transport modes emission factors to include a distance 
--			  value for deciding to use Bus or Coach journeys.
-- *************************************************************************************


USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Update Emission Factors
----------------------------------------------------------------
IF EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE [FactorType] = 'BusCoachDistance')
  BEGIN
    DELETE FROM JourneyEmissionsFactor WHERE [FactorType] = 'BusCoachDistance'
  END

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue)
VALUES ('BusCoachDistance', '30000')

GO


IF NOT EXISTS(SELECT * FROM [properties] WHERE [pName] = 'JourneyEmissions.Distance.Coach')
INSERT INTO properties(pName, pValue, AID, GID, PartnerId)
VALUES ('JourneyEmissions.MinDistance.Coach', '30', 'Web', 'UserPortal', 0)
Go

----------------------------------------------------------------
-- Update DropDownLists for Extend Journey
----------------------------------------------------------------


-- ExtensionResultsViews dropdown
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder) VALUES ('ExtensionResultsViews', 'RefineCheckC02', 'RefineCheckC02', 0, 5)
GO


-- FullItineraryExtendPermitted dropdown
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder) VALUES ('FullItineraryExtendPermitted', 'RefineCheckC02', 'RefineCheckC02', 0, 6)


-- FullItineraryExtendNotPermitted dropdown
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder) VALUES ('FullItineraryExtendNotPermitted', 'RefineCheckC02', 'RefineCheckC02', 0, 5)


-- ItinerarySegmentsExtendPermitted dropdown
INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder) VALUES ('ItinerarySegmentsExtendPermitted', 'RefineCheckC02', 'RefineCheckC02', 0, 8)
GO