-- ***********************************************
-- NAME 		: DUP0608AddFirstlastDropDownOptions.sql
-- DESCRIPTION 		: sql to add FirstToday,FirstTomorrow,LastToday & LastTomorrow options to Enhanced Exposed Services
--	
-- ************************************************


----------------------------------------
-- INSERT DROPDOWN ITEM
----------------------------------------
USE [PermanentPortal]
GO

--insert into DropDownLists table 
IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'LastToday'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'LastToday', 'LastToday', 0, 5, 0)
GO

IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'LastTomorrow'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'LastTommorow', 'LastTommorrow', 0, 6, 0)
GO

IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'FirstToday'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'FirstToday', 'FirstToday', 0, 7, 0)
GO

IF NOT EXISTS(SELECT * FROM [DropDownLists] WHERE ([DataSet] = 'MobileTimeRequestDrop') AND ([ResourceID] = 'FirstTommorrow'))
INSERT INTO DropDownLists(DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId)
VALUES ('MobileTimeRequestDrop', 'FirstTomorrow', 'FirstTomorrow', 0, 8, 0)
GO






----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 608
SET @ScriptDesc = 'sql to add FirstToday,FirstTomorrow,LastToday & LastTomorrow options to Enhanced Exposed Services'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO