-- ***********************************************
-- NAME 		: DUP0593_SuggestionLinks_Change_URL
-- DESCRIPTION 		: Update C02 Emmissions (Suggestion Links).
--			: Change to point at new FAQ order CCN425
-- AUTHOR		: Neil Rankin
-- ************************************************



-- EXEC UpdateSuggestionLinkURL
-- StringLinkURLOld    	varchar(100),		-- Existing link. Relative url if Internal, Absolute if External 						link
-- StringLinkURLNew    	varchar(100),		-- New link. Relative url if Internal, Absolute if External link
-- StringLinkDescription    	varchar(500),		-- Provide description if updating, otherwise leave blank
-- IsInternalLink		bit			-- 1 for Internal link, 0 for External

USE TransientPortal
GO

EXEC UpdateSuggestionLinkURL
	'Help/HelpCarbon.aspx#A9.1', 
	'Help/HelpCarbon.aspx#A12.1', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCarbon.aspx#A9.2', 
	'Help/HelpCarbon.aspx#A12.2', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCarbon.aspx#A9.3', 
	'Help/HelpCarbon.aspx#A12.3', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCarbon.aspx#A9.5', 
	'Help/HelpCarbon.aspx#A12.5', 
	'', 
	1


EXEC UpdateSuggestionLinkURL
	'Help/HelpCarbon.aspx#A9.4', 
	'Help/HelpCarbon.aspx#A12.4', 
	'', 
	1

GO

------------------------------------------------------------
-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 593
SET @ScriptDesc = 'Update FAQ C02 Emmissions (Suggestion Links)'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------