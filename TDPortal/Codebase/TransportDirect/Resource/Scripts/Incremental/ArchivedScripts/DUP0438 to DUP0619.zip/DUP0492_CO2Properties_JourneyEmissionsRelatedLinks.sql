-- *************************************************************************************
-- NAME 		: DUP0492_CO2Properties_JourneyEmissionsRelatedLinks.sql
-- DESCRIPTION 		: Adds Related links to External Links table
-- Added by		: Darshan Sawe
-- Date 		: 26/Nov/2006
-- *************************************************************************************

USE [TransientPortal]
GO


------------------------
-- Related Links
------------------------

IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.OffsetCarbonEmissions')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.OffsetCarbonEmissions'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, LinkText)
VALUES ('JourneyEmissions.OffsetCarbonEmissions', 'http://www.targetneutral.com', 'http://www.targetneutral.com', '1', 'Offset Carbon Emissions', NULL, NULL, NULL)





 
IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.CompareFuelEfficiency')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.CompareFuelEfficiency'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.CompareFuelEfficiency', 'http://www.vcacarfueldata.org.uk/search/search.asp', 'http://www.vcacarfueldata.org.uk/search/search.asp', '1', 'Compare Fuel Efficiency', NULL, NULL, NULL)






IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.FuelSavingTips')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.FuelSavingTips'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.FuelSavingTips', 'http://www.aatrust.com/files/reports/220606_Fuel_Tips.pdf', 'http://www.aatrust.com/files/reports/220606_Fuel_Tips.pdf', '1', 'Fuel Saving tips', NULL, NULL, NULL)






IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.MotoringAndEnvironment')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.MotoringAndEnvironment'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.MotoringAndEnvironment', 'http://www.direct.gov.uk/Motoring/OwningAVehicle/AdviceOnKeepingYourVehicle/AdviceOnKeepingYourVehicleArticles/fs/en?CONTENT_ID=4022065&chk=sMxJKK', 'http://www.direct.gov.uk/Motoring/OwningAVehicle/AdviceOnKeepingYourVehicle/AdviceOnKeepingYourVehicleArticles/fs/en?CONTENT_ID=4022065&chk=sMxJKK', '1', 'Motoring and Environment', NULL, NULL, NULL)





IF EXISTS (SELECT * FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.Flying')
  BEGIN
    DELETE FROM ExternalLinks WHERE [Id] = 'JourneyEmissions.Flying'
  END
INSERT INTO ExternalLinks ([Id], URL, TestURL, Valid, [Description], StartDate, EndDate, [LinkText])
VALUES ('JourneyEmissions.Flying', 'http://aquanota.co.uk/lmn/carbon/', 'http://aquanota.co.uk/lmn/carbon/', '1', 'Flying', NULL, NULL, NULL)



GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 492
SET @ScriptDesc = 'Added Journey Emission Related links to External Links table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO