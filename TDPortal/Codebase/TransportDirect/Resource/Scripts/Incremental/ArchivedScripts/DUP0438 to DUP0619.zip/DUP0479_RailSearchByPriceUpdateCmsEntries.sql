-- *************************************************************************************
-- NAME 		: DUP0479_RailSearchByPriceUpdateCmsEntries.sql
-- DESCRIPTION 		: Updates the CMS Text Entries table with the required place holder
--                      : definitions for Rail Search by Price.
-- *************************************************************************************

USE [TransientPortal]
GO

-- Information Placeholders that are shared with the Home Pages
-- and the Mini Homes Pages

-- Find Train Input TDInformationHtmlPlaceholderDefinition (EN)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/en/JourneyPlanning' AND Posting = 'FindTrainInput' AND PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/en/JourneyPlanning', 'FindTrainInput', 'TDInformationHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')
  END


-- Find Train Input TDInformationHtmlPlaceholderDefinition (CY)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/cy/JourneyPlanning' AND Posting = 'FindTrainInput' AND PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/cy/JourneyPlanning', 'FindTrainInput', 'TDInformationHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')    
  END


-- Find Train Cost Input TDInformationHtmlPlaceholderDefinition (EN)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/en/JourneyPlanning' AND Posting = 'FindTrainCostInput' AND PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/en/JourneyPlanning', 'FindTrainCostInput', 'TDInformationHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')       
  END



-- Find Train Cost Input TDInformationHtmlPlaceholderDefinition (CY)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/cy/JourneyPlanning' AND Posting = 'FindTrainCostInput' AND PlaceHolder = 'TDInformationHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/cy/JourneyPlanning', 'FindTrainCostInput', 'TDInformationHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')       
  END



-- Promotional Place Holders that are shared across the Find Train (Cost)
-- input pages only.

-- Find Train Input TDFindTrainPromoHtmlPlaceholderDefinition (EN)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/en/JourneyPlanning' AND Posting = 'FindTrainInput' AND PlaceHolder = 'TDFindTrainPromoHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/en/JourneyPlanning', 'FindTrainInput', 'TDFindTrainPromoHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')       
  END


-- Find Train Input TDFindTrainPromoHtmlPlaceholderDefinition (CY)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/cy/JourneyPlanning' AND Posting = 'FindTrainInput' AND PlaceHolder = 'TDFindTrainPromoHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/cy/JourneyPlanning', 'FindTrainInput', 'TDFindTrainPromoHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')           
  END


-- Find Train Cost Input TDFindTrainPromoHtmlPlaceholderDefinition (EN)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/en/JourneyPlanning' AND Posting = 'FindTrainCostInput' AND PlaceHolder = 'TDFindTrainPromoHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/en/JourneyPlanning', 'FindTrainCostInput', 'TDFindTrainPromoHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')           
  END


-- Find Train Cost Input TDFindTrainPromoHtmlPlaceholderDefinition (CY)
IF NOT EXISTS (SELECT * FROM CmsTextEntries WHERE Channel = '/Channels/TransportDirect/cy/JourneyPlanning' AND Posting = 'FindTrainCostInput' AND PlaceHolder = 'TDFindTrainPromoHtmlPlaceholderDefinition')
  BEGIN
    INSERT INTO CmsTextEntries (Channel, Posting, PlaceHolder, [Text]) VALUES ('/Channels/TransportDirect/cy/JourneyPlanning', 'FindTrainCostInput', 'TDFindTrainPromoHtmlPlaceholderDefinition', '<h1>NOT POPULATED</h1>')           
  END

GO

-- Change Catalogue

USE [PermanentPortal]

DELETE ChangeCatalogue WHERE ScriptNumber = 479
INSERT INTO ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
VALUES (479, GETDATE(), 'RailSearchByPriceUpdateCmsEntries')

GO
