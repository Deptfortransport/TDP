-- *************************************************************************************
-- NAME 		: DUP0606_CO2LandingPageService.sql
-- DESCRIPTION 		: CO2 Landing Addition
-- DATE                 : 24-JAN-2008
-- *************************************************************************************

------------------------
-- Properties Table
------------------------

USE [Reporting]
GO

IF EXISTS (SELECT * FROM [LandingPageService] WHERE [LPSCode] = 'CO2LandingPage')
  BEGIN
     DELETE FROM [LandingPageService] WHERE [LPSCode] = 'CO2LandingPage'
  END
INSERT INTO LandingPageService (LPSID, [LPSCode], [LPSDescription])
SELECT MAX(LPSID)+1, 'CO2LandingPage', 'CO2LandingPage' FROM LandingPageService

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 606
SET @ScriptDesc = 'CO2 Landing Addition'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO