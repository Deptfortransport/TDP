-- *************************************************************************************
-- NAME 		: DUP0489_CO2Properties_SpeedoScaleMPGs.sql
-- DESCRIPTION 		: Adds Journey Emissions Speedo Scale low and high mpgs used
--			: to calculate the Max and Min scales
-- *************************************************************************************

USE [PermanentPortal]
GO


------------------------
-- Speedo Scales - Low and High Mpg
------------------------

-- JourneyEmissions.LowMpg
IF EXISTS (SELECT * FROM Properties WHERE pName = 'JourneyEmissions.LowMpg')
  BEGIN
    DELETE FROM Properties WHERE pName = 'JourneyEmissions.LowMpg' AND AID='Web'
  END

INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('JourneyEmissions.LowMpg', '15', 'Web', 'UserPortal', 0)

GO

-- JourneyEmissions.HighMpg
IF EXISTS (SELECT * FROM Properties WHERE pName = 'JourneyEmissions.HighMpg')
  BEGIN
    DELETE FROM Properties WHERE pName = 'JourneyEmissions.HighMpg' AND AID='Web'
  END

INSERT INTO Properties (pName, pValue, AID, GID, PartnerID)
VALUES ('JourneyEmissions.HighMpg', '80', 'Web', 'UserPortal', 0)

GO

------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 489
SET @ScriptDesc = 'Added Speedo Scale low and high mpgs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
