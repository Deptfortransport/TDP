-- ***********************************************
-- NAME 		: DUP0616_ModifyRttiSchemaLocationProperty.sql
-- DESCRIPTION 		: Modify RttiSchemaLocation Property in readiness for Exposed Services Decommissioning
--	
-- ************************************************

USE [PermanentPortal]
GO

--------------------------------------------------------------------------------------
-- Modify RttiSchemaLocation Property in readiness for Exposed Services Decommissioning
--------------------------------------------------------------------------------------
UPDATE [PermanentPortal].[dbo].[properties]
SET [pValue]= 'D:\Inetpub\wwwroot\enhancedexposedservices\Schema\rttiEPTSchema.xsd'
WHERE [pName] = 'DepartureBoardService.RTTIManager.SchemaLocation'


----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 616
SET @ScriptDesc = 'Modified RttiSchemaLocation Property in readiness for Exposed Services Decommissioning'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO