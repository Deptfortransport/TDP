-- ************************************************************
-- NAME 	: DUP0522_SP_for_Word2003_Page_landing.sql
-- DESCRIPTION 	: Creates Stored procedure usp_UpdateDeferredData
-- ************************************************************

USE ASPState
GO


IF EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'ASPState' 
              AND ROUTINE_NAME = 'usp_UpdateDeferredData' )
BEGIN
    DROP PROCEDURE [usp_UpdateDeferredData]
END
GO

CREATE PROCEDURE dbo.usp_UpdateDeferredData ( @CurrSessionID varchar(32), @OldSessionID varchar(32) )
AS
    
/* 
***********************************************************************************************************
   NAME 	: usp_UpdateDeferredData
   AUTHOR 	: John Frank
   DATE CREATED : 29-Jan-2007
   DESCRIPTION 	: Stored procedure for Page Landing from Word 2003

***********************************************************************************************************
*/


IF EXISTS (SELECT 1 FROM DeferredData WHERE SessionId = @OldSessionID)
BEGIN

    --Delete all rows with new curr session
    DELETE FROM DeferredData WHERE SessionId = @CurrSessionID

    --Insert for curr session using rows with old session
    INSERT INTO DeferredData (SessionId, KeyID, SessionItemLong)
    (SELECT @CurrSessionID, KeyID, SessionItemLong FROM DeferredData WHERE SessionId = @OldSessionID)

    RETURN 0

END
ELSE
BEGIN
    RETURN -1
END


GO

------------------------------------------
-- UPDATE CHANGE CATALOGUE
------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 522
SET @ScriptDesc = 'Stored Procedure to copy session data across during a Word2003 page landing'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO