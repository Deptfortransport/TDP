-- ***********************************************
-- NAME 		: DUP1805_CreateStagingToExtractSP.sql
-- DESCRIPTION 	: Script to create stored proc to copy staging data to disaster recovery extract db
-- AUTHOR		: Phil Scott
-- DATE			: 25 Mar 2011
-- ************************************************

USE [DRExtractDB]
GO
/****** Object:  StoredProcedure [dbo].[TransferStagingToExtract]    Script Date: 05/25/2011 14:08:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[TransferStagingToExtract]
	@FromDateTime varchar(19), 
	@ToDateTime varchar(19)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

/******************************************************************/
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[CyclePlannerRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[CyclePlannerRequestEvent]
           ([CyclePlannerRequestId]
           ,[Cycle]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [CyclePlannerRequestId]
      ,[Cycle]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[CyclePlannerRequestEvent] 
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[CyclePlannerResultEvent]

INSERT INTO [DRExtractDB].[dbo].[CyclePlannerResultEvent]
           ([CyclePlannerRequestId]
           ,[ResponseCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [CyclePlannerRequestId]
      ,[ResponseCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[CyclePlannerResultEvent] 
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[DataGatewayEvent]

INSERT INTO [DRExtractDB].[dbo].[DataGatewayEvent]
           ([FeedId]
           ,[SessionId]
           ,[FileName]
           ,[TimeStarted]
           ,[TimeFinished]
           ,[SuccessFlag]
           ,[ErrorCode]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [FeedId]
      ,[SessionId]
      ,[FileName]
      ,[TimeStarted]
      ,[TimeFinished]
      ,[SuccessFlag]
      ,[ErrorCode]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[DataGatewayEvent]
   WHERE [TimeStarted] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeStarted] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeStarted]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[EBCCalculationEvent]

INSERT INTO [DRExtractDB].[dbo].[EBCCalculationEvent]
           ([Submitted]
           ,[SessionId]
           ,[TimeLogged]
           ,[Success])
SELECT [Submitted]
      ,[SessionId]
      ,[TimeLogged]
      ,[Success]
  FROM [ReportStagingDB].[dbo].[EBCCalculationEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[EnhancedExposedServiceEvent]

INSERT INTO [DRExtractDB].[dbo].[EnhancedExposedServiceEvent]
           ([EESEPartnerId]
           ,[EESEInternalTransactionId]
           ,[EESEExternalTransactionId]
           ,[EESEServiceType]
           ,[EESEOperationType]
           ,[EESEEventTime]
           ,[EESEIsStartEvent]
           ,[EESECallSuccessful]
           ,[TimeLogged])
SELECT [EESEPartnerId]
      ,[EESEInternalTransactionId]
      ,[EESEExternalTransactionId]
      ,[EESEServiceType]
      ,[EESEOperationType]
      ,[EESEEventTime]
      ,[EESEIsStartEvent]
      ,[EESECallSuccessful]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[EnhancedExposedServiceEvent]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[ExposedServicesEvent]

INSERT INTO [DRExtractDB].[dbo].[ExposedServicesEvent]
           ([Submitted]
           ,[Token]
           ,[Category]
           ,[Successful]
           ,[TimeLogged])
SELECT [Submitted]
      ,[Token]
      ,[Category]
      ,[Successful]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[ExposedServicesEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[GazetteerEvent]

INSERT INTO [DRExtractDB].[dbo].[GazetteerEvent]
           ([EventCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged]
           ,[Submitted])
SELECT [EventCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
      ,[Submitted]
  FROM [ReportStagingDB].[dbo].[GazetteerEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[GradientProfileEvent]

INSERT INTO [DRExtractDB].[dbo].[GradientProfileEvent]
           ([DisplayCategory]
           ,[Submitted]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [DisplayCategory]
      ,[Submitted]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[GradientProfileEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[InternalRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[InternalRequestEvent]
           ([InternalRequestId]
           ,[SessionId]
           ,[Submitted]
           ,[InternalRequestType]
           ,[Success]
           ,[RefTransaction]
           ,[TimeLogged]
           ,[FunctionType])
SELECT [InternalRequestId]
      ,[SessionId]
      ,[Submitted]
      ,[InternalRequestType]
      ,[Success]
      ,[RefTransaction]
      ,[TimeLogged]
      ,[FunctionType]
  FROM [ReportStagingDB].[dbo].[InternalRequestEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[InternationalPlannerEvent]

INSERT INTO [DRExtractDB].[dbo].[InternationalPlannerEvent]
           ([InternationalPlannerType]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [InternationalPlannerType]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[InternationalPlannerEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[InternationalPlannerRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[InternationalPlannerRequestEvent]
           ([InternationalPlannerRequestId]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [InternationalPlannerRequestId]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[InternationalPlannerRequestEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[InternationalPlannerResultEvent]

INSERT INTO [DRExtractDB].[dbo].[InternationalPlannerResultEvent]
           ([InternationalPlannerRequestId]
           ,[ResponseCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [InternationalPlannerRequestId]
      ,[ResponseCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[InternationalPlannerResultEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[JourneyPlanRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[JourneyPlanRequestEvent]
           ([JourneyPlanRequestId]
           ,[Air]
           ,[Bus]
           ,[Car]
           ,[Coach]
           ,[Cycle]
           ,[Drt]
           ,[Ferry]
           ,[Metro]
           ,[Rail]
           ,[Taxi]
           ,[Tram]
           ,[Underground]
           ,[Walk]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[Air]
      ,[Bus]
      ,[Car]
      ,[Coach]
      ,[Cycle]
      ,[Drt]
      ,[Ferry]
      ,[Metro]
      ,[Rail]
      ,[Taxi]
      ,[Tram]
      ,[Underground]
      ,[Walk]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[JourneyPlanRequestEvent]
 WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[JourneyPlanRequestVerboseEvent]

INSERT INTO [DRExtractDB].[dbo].[JourneyPlanRequestVerboseEvent]
           ([JourneyPlanRequestId]
           ,[JourneyRequestData]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[JourneyRequestData]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[JourneyPlanRequestVerboseEvent]
 WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[JourneyPlanResultsEvent]

INSERT INTO [DRExtractDB].[dbo].[JourneyPlanResultsEvent]
           ([JourneyPlanRequestId]
           ,[ResponseCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[ResponseCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[JourneyPlanResultsEvent]
 WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[JourneyPlanResultsVerboseEvent]

INSERT INTO [DRExtractDB].[dbo].[JourneyPlanResultsVerboseEvent]
           ([JourneyPlanRequestId]
           ,[JourneyResultsData]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[JourneyResultsData]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[JourneyPlanResultsVerboseEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[JourneyWebRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[JourneyWebRequestEvent]
           ([JourneyWebRequestId]
           ,[SessionId]
           ,[Submitted]
           ,[RegionCode]
           ,[Success]
           ,[RefTransaction]
           ,[TimeLogged]
           ,[RequestType])
SELECT [JourneyWebRequestId]
      ,[SessionId]
      ,[Submitted]
      ,[RegionCode]
      ,[Success]
      ,[RefTransaction]
      ,[TimeLogged]
      ,[RequestType]
  FROM [ReportStagingDB].[dbo].[JourneyWebRequestEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[LandingPageEvent]

INSERT INTO [DRExtractDB].[dbo].[LandingPageEvent]
           ([LPPCode]
           ,[LPSCode]
           ,[TimeLogged]
           ,[SessionId]
           ,[UserLoggedOn])
SELECT [LPPCode]
      ,[LPSCode]
      ,[TimeLogged]
      ,[SessionId]
      ,[UserLoggedOn]
  FROM [ReportStagingDB].[dbo].[LandingPageEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[LocationRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[LocationRequestEvent]
           ([JourneyPlanRequestId]
           ,[PrepositionCategory]
           ,[AdminAreaCode]
           ,[RegionCode]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[PrepositionCategory]
      ,[AdminAreaCode]
      ,[RegionCode]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[LocationRequestEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[LoginEvent]

INSERT INTO [DRExtractDB].[dbo].[LoginEvent]
           ([SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[LoginEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[MapAPIEvent]

INSERT INTO [DRExtractDB].[dbo].[MapAPIEvent]
           ([CommandCategory]
           ,[Submitted]
           ,[SessionId]
           ,[TimeLogged])
SELECT [CommandCategory]
      ,[Submitted]
      ,[SessionId]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[MapAPIEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[MapEvent]

INSERT INTO [DRExtractDB].[dbo].[MapEvent]
           ([CommandCategory]
           ,[Submitted]
           ,[DisplayCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [CommandCategory]
      ,[Submitted]
      ,[DisplayCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[MapEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]


/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[OperationalEvent]

INSERT INTO [DRExtractDB].[dbo].[OperationalEvent]
           ([SessionId]
           ,[Message]
           ,[MachineName]
           ,[AssemblyName]
           ,[MethodName]
           ,[TypeName]
           ,[Level]
           ,[Category]
           ,[Target]
           ,[TimeLogged])
SELECT [SessionId]
      ,[Message]
      ,[MachineName]
      ,[AssemblyName]
      ,[MethodName]
      ,[TypeName]
      ,[Level]
      ,[Category]
      ,[Target]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[OperationalEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[PageEntryEvent]

INSERT INTO [DRExtractDB].[dbo].[PageEntryEvent]
           ([Page]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged]
           ,[ThemeID])
SELECT [Page]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
      ,[ThemeID]
  FROM [ReportStagingDB].[dbo].[PageEntryEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[ReferenceTransactionEvent]

INSERT INTO [DRExtractDB].[dbo].[ReferenceTransactionEvent]
           ([Submitted]
           ,[EventType]
           ,[ServiceLevelAgreement]
           ,[SessionId]
           ,[TimeLogged]
           ,[Successful]
           ,[MachineName])
SELECT [Submitted]
      ,[EventType]
      ,[ServiceLevelAgreement]
      ,[SessionId]
      ,[TimeLogged]
      ,[Successful]
      ,[MachineName]
  FROM [ReportStagingDB].[dbo].[ReferenceTransactionEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[RepeatVisitorEvent]

INSERT INTO [DRExtractDB].[dbo].[RepeatVisitorEvent]
           ([RepeatVistorType]
           ,[LastVisited]
           ,[SessionIdOld]
           ,[SessionIdNew]
           ,[DomainName]
           ,[UserAgent]
           ,[ThemeId]
           ,[TimeLogged])
SELECT 
       [RepeatVistorType]
      ,[LastVisited]
      ,[SessionIdOld]
      ,[SessionIdNew]
      ,[DomainName]
      ,[UserAgent]
      ,[ThemeId]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[RepeatVisitorEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]


/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[RetailerHandoffEvent]

INSERT INTO [DRExtractDB].[dbo].[RetailerHandoffEvent]
           ([RetailerId]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT 
       [RetailerId]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[RetailerHandoffEvent]
    WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[RTTIEvent]

INSERT INTO [DRExtractDB].[dbo].[RTTIEvent]
           ([StartTime]
           ,[FinishTime]
           ,[DataRecievedSucessfully]
           ,[TimeLogged])
 SELECT 
       [StartTime]
      ,[FinishTime]
      ,[DataRecievedSucessfully]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[RTTIEvent]
  WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
  order by [StartTime]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[RTTIInternalEvent]

INSERT INTO [DRExtractDB].[dbo].[RTTIInternalEvent]
           ([StartTime]
           ,[EndTime]
           ,[NumberOfRetries]
           ,[Successful]
           ,[TimeLogged])
     SELECT 
       [StartTime]
      ,[EndTime]
      ,[NumberOfRetries]
      ,[Successful]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[RTTIInternalEvent]
   WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [StartTime]

/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[StopEventRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[StopEventRequestEvent]
           ([Submitted]
           ,[RequestId]
           ,[RequestType]
           ,[Successful]
           ,[TimeLogged])
   SELECT 
       [Submitted]
      ,[RequestId]
      ,[RequestType]
      ,[Successful]
      ,[TimeLogged]
   FROM [ReportStagingDB].[dbo].[StopEventRequestEvent]
    WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]


/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[UserFeedbackEvent]

INSERT INTO [DRExtractDB].[dbo].[UserFeedbackEvent]
           ([SessionId]
           ,[SubmittedTime]
           ,[FeedbackType]
           ,[AcknowledgedTime]
           ,[AcknowledgmentSent]
           ,[UserLoggedOn]
           ,[TimeLogged])
    SELECT
       [SessionId]
      ,[SubmittedTime]
      ,[FeedbackType]
      ,[AcknowledgedTime]
      ,[AcknowledgmentSent]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[UserFeedbackEvent]
  WHERE [SubmittedTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [SubmittedTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [SubmittedTime]
  
/******************************************************************/

TRUNCATE TABLE [DRExtractDB].[dbo].[UserPreferenceSaveEvent]

INSERT INTO [DRExtractDB].[dbo].[UserPreferenceSaveEvent]
           ([EventCategory]
           ,[SessionId]
           ,[TimeLogged])
  SELECT 
       [EventCategory]
      ,[SessionId]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[UserPreferenceSaveEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
  
/******************************************************************/
TRUNCATE TABLE DRExtractDB.dbo.WorkloadEvent

INSERT INTO [DRExtractDB].[dbo].[WorkloadEvent]
           ([Requested]
           ,[TimeLogged]
           ,[NumberRequested]
           ,[PartnerId])
SELECT 
       [Requested]
      ,[TimeLogged]
      ,[NumberRequested]
      ,[PartnerId]
  FROM [ReportStagingDB].[dbo].[WorkloadEvent]
  WHERE Requested >= CONVERT(datetime, @FromDateTime, 120)
  and Requested <= CONVERT(datetime, @ToDateTime, 120)
    order by Requested




/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[RetailerHandoffEvent]

INSERT INTO [DRExtractDB].[dbo].[RetailerHandoffEvent]
           ([RetailerId]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT 
       [RetailerId]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[RetailerHandoffEvent]
    WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]


/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[RTTIEvent]
 
INSERT INTO [DRExtractDB].[dbo].[RTTIEvent]
           ([StartTime]
           ,[FinishTime]
           ,[DataRecievedSucessfully]
           ,[TimeLogged])
 SELECT 
       [StartTime]
      ,[FinishTime]
      ,[DataRecievedSucessfully]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[RTTIEvent]
  WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
  order by [StartTime]


/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[RTTIInternalEvent]

INSERT INTO [DRExtractDB].[dbo].[RTTIInternalEvent]
           ([StartTime]
           ,[EndTime]
           ,[NumberOfRetries]
           ,[Successful]
           ,[TimeLogged])
     SELECT 
       [StartTime]
      ,[EndTime]
      ,[NumberOfRetries]
      ,[Successful]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[RTTIInternalEvent]
   WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [StartTime]


/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[StopEventRequestEvent]

INSERT INTO [DRExtractDB].[dbo].[StopEventRequestEvent]
           ([Submitted]
           ,[RequestId]
           ,[RequestType]
           ,[Successful]
           ,[TimeLogged])
   SELECT 
       [Submitted]
      ,[RequestId]
      ,[RequestType]
      ,[Successful]
      ,[TimeLogged]
   FROM [ReportStagingDB].[dbo].[StopEventRequestEvent]
    WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]

/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[UserFeedbackEvent]

INSERT INTO [DRExtractDB].[dbo].[UserFeedbackEvent]
           ([SessionId]
           ,[SubmittedTime]
           ,[FeedbackType]
           ,[AcknowledgedTime]
           ,[AcknowledgmentSent]
           ,[UserLoggedOn]
           ,[TimeLogged])
    SELECT
       [SessionId]
      ,[SubmittedTime]
      ,[FeedbackType]
      ,[AcknowledgedTime]
      ,[AcknowledgmentSent]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[UserFeedbackEvent]
  WHERE [SubmittedTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [SubmittedTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [SubmittedTime]
  
/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[UserPreferenceSaveEvent]

INSERT INTO [DRExtractDB].[dbo].[UserPreferenceSaveEvent]
           ([EventCategory]
           ,[SessionId]
           ,[TimeLogged])
  SELECT 
       [EventCategory]
      ,[SessionId]
      ,[TimeLogged]
  FROM [ReportStagingDB].[dbo].[UserPreferenceSaveEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
 

 
/******************************************************************/
TRUNCATE TABLE [DRExtractDB].[dbo].[WorkloadEvent]

INSERT INTO [DRExtractDB].[dbo].[WorkloadEvent]
           ([Requested]
           ,[TimeLogged]
           ,[NumberRequested]
           ,[PartnerId])
SELECT 
       [Requested]
      ,[TimeLogged]
      ,[NumberRequested]
      ,[PartnerId]
  FROM [ReportStagingDB].[dbo].[WorkloadEvent]
  WHERE Requested >= CONVERT(datetime, @FromDateTime, 120)
  and Requested <= CONVERT(datetime, @ToDateTime, 120)
    order by Requested
