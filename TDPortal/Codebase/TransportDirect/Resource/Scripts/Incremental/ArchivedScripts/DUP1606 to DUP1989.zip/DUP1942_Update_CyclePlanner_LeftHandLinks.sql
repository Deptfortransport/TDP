-- ***********************************************
-- NAME           : DUP1942_Update_CyclePlanner_LeftHandLinks.sql
-- DESCRIPTION    : Script to update Cycle left hand link 
-- AUTHOR         : Phil Scott
-- DATE           : 08 Dec 2012
-- ***********************************************

USE [TransientPortal] 

EXECUTE UpdateSuggestionLinkURL 
		   'http://www.direct.gov.uk/en/Nl1/Newsroom/DG_181913'
		  ,'http://businesscycle.org.uk/?source=c2w'
		  ,'Cycle planner - Cycle to work url'
		  ,0
		  
EXECUTE UpdateSuggestionLinkURL 
		   'http://www.bikeforall.net/content/cycling_to_school.php'
		  ,'http://www.gov.uk/safe-walking-cycling-routes-school'
		  ,'Cycle planner - Cycle to school url'
		  ,0

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1942
SET @ScriptDesc = 'DUP1942_Update_CyclePlanner_LeftHandLinks'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO