-- ***********************************************
-- NAME 		: DUP1839_RealTimeCar_ReportStaging_StoredProcedures_RealTimeRoadEvent.sql
-- DESCRIPTION 	: Script to add stored procedures to create RealTimeRoadEvent
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 Sep 2011
-- ************************************************

USE [ReportStagingDB]
GO


-- ****IMPORTANT****
-- If running this script in the Production environment, please uncomment the lines with value "ReportServer.", and comment out the line below it.
-- There are 2 instances of this in the script.

----------------------------------------------------------------
-- Create AddRealTimeRoadEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddRealTimeRoadEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddRealTimeRoadEvent
        (
			 @RealTimeRoadType varchar(50),
			 @RealTimeFound bit,
			 @Submitted datetime,
			 @SessionId varchar(50), 
			 @TimeLogged datetime,
			 @Successful bit)
			AS
			BEGIN 
				SET NOCOUNT ON 
			END
		')

END
GO


----------------------------------------------------------------
-- Update AddRealTimeRoadEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE AddRealTimeRoadEvent (@RealTimeRoadType varchar(50),
			 @RealTimeFound bit,
			 @Submitted datetime,
			 @SessionId varchar(50), 
			 @TimeLogged datetime,
			 @Successful bit)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into RealTimeRoadEvent  Table'

    Insert into RealTimeRoadEvent (RealTimeRoadType, RealTimeFound, Submitted, SessionId, TimeLogged, Success)
    Values (@RealTimeRoadType, @RealTimeFound, @Submitted, @SessionId, @TimeLogged, @Successful)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Create TransferRealTimeRoadEvents stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferRealTimeRoadEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE TransferRealTimeRoadEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferRealTimeRoadEvents stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE TransferRealTimeRoadEvents
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

--DELETE FROM [ReportServer].[Reporting].[dbo].[RealTimeRoadEvent]
DELETE FROM [Reporting].[dbo].[RealTimeRoadEvents]
WHERE CONVERT(varchar(10), RTRDate, 121) = @Date

--INSERT INTO [ReportServer].[Reporting].[dbo].[RealTimeRoadEvents]
INSERT INTO [Reporting].[dbo].[RealTimeRoadEvents]
(
	RTRDate,
	RTRHour,
	RTRHourQuarter,
	RTRWeekDay,
	RTRRTRTID,
	RTRCount,
	RTRAvMsDuration
)
SELECT 
	CAST(CONVERT(varchar(10), RTRE.Submitted, 121) AS datetime) AS RTRDate,
	DATEPART(hour, RTRE.Submitted) AS RTRHour,
	CAST(DATEPART(minute, RTRE.Submitted) / 15 AS smallint) AS RTRHourQuarter,
	DATEPART(weekday, RTRE.Submitted) AS RTRWeekDay,
	RTRET.RTRTID AS RTRRTRTID,
	COUNT(*) AS RTRCount,
	AVG(CAST(DATEDIFF(millisecond, RTRE.Submitted, RTRE.TimeLogged) AS decimal(18, 0))) AS RTRAvMsDuration

  FROM RealTimeRoadEvent RTRE
  --LEFT OUTER JOIN ReportServer.Reporting.dbo.RealTimeRoadEventType RTRET ON RTRE.RealTimeRoadType = RTRET.RTRTCode
  LEFT OUTER JOIN Reporting.dbo.RealTimeRoadEventType RTRET ON RTRE.RealTimeRoadType = RTRET.RTRTCode
  WHERE CONVERT(varchar(10), RTRE.Submitted, 121) = @Date
  GROUP BY
	CAST(CONVERT(varchar(10), RTRE.Submitted, 121) AS datetime),
	DATEPART(hour, RTRE.Submitted),
	CAST(DATEPART(minute, RTRE.Submitted) / 15 AS smallint),
	DATEPART(weekday, RTRE.Submitted),
	RTRET.RTRTID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1839
SET @ScriptDesc = 'Add ReportStaging stored procedures for RealTimeRoadEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO