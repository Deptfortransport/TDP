-- ***********************************************
-- NAME 		: DUP1862_CyclePlanner_Algorithm_Properties_Update.sql
-- DESCRIPTION 	: Script to update all Cycle Planner algorithm properties
-- AUTHOR		: Mitesh Modi   (amended paths PS)
-- DATE			: 7 Feb 2012
-- ************************************************

-------------------------------------------------------------------------------------
--********************************** WARNING **************************************--
-------------------------------------------------------------------------------------
--	THIS IS ONLY FOR DEV                                                           --
--  IF RUN IN OTHER ENVIRONMENTS, SEE WARNING BELOW                                --
-------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------
--********************************** WARNING **************************************--
-------------------------------------------------------------------------------------
--	PATH TO THE CYCLE PLANNER FUNCTION DLLS ARE BASED ON DEV ENVIRONMENT		   --
--  PLEASE UPDATE THE PATH IN PROPERTIES TO REFLECT CORRECT PATHS 
--  ACCORDING TO THE SITEST/BBP/ACP ENVIRONMENT THE SCRIPT RUN ON			       --
-------------------------------------------------------------------------------------

USE [PermanentPortal]
GO

-- Clear all existing Penalty Function properties
DELETE FROM [dbo].[properties]
WHERE  pName LIKE 'CyclePlanner.PlannerControl.PenaltyFunction.%'

-- Insert new Penalty Function properties for each of the required aid and gid
DECLARE @AID_Web varchar(50) = 'Web'
DECLARE @AID_RHost varchar(50) = 'TDRemotingHost'
DECLARE @AID_EES varchar(50) = 'EnhancedExposedServices'

DECLARE @GID_UPortal varchar(50) = 'UserPortal'
DECLARE @GID_RHost varchar(50) = 'TDRemotingHost'

-----------------------------------------------------------
-- Mandatory
-----------------------------------------------------------
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Folder', 'D:\TransportDirect\Services\CycleHost', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Folder', 'D:\TransportDirect\Services\CycleHost', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Folder', 'D:\TransportDirect\Services\CycleHost', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Location', 'D:\TransportDirect\Services\CycleHost\td.cp.CyclePenaltyFunctions.v3.dll', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Location', 'D:\TransportDirect\Services\CycleHost\td.cp.CyclePenaltyFunctions.v3.dll', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Location', 'D:\TransportDirect\Services\CycleHost\td.cp.CyclePenaltyFunctions.v3.dll', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_EES, @GID_UPortal, 0, 1)

-----------------------------------------------------------
-- Algorithms 
-----------------------------------------------------------
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Default', 'QuietestV913', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Default', 'QuietestV913', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Default', 'QuietestV913', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', @AID_EES, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_RHost, @GID_RHost, 0, 1)
INSERT INTO [properties] VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', @AID_EES, @GID_UPortal, 0, 1)


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1862
SET @ScriptDesc = 'Script to add/update Cycle Planner algorithm properties (ATO687)'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO