-- ***********************************************
-- NAME 		: DUP1969_GISQueryEvent_ReportStaging_StoredProcedures.sql
-- DESCRIPTION 	: Script to add stored procedures to create GISQueryEvent
-- AUTHOR		: Mitesh Modi
-- DATE			: 14 Jan 2013
-- ************************************************

USE [ReportStagingDB]
GO


-- ****IMPORTANT****
-- If running this script in the Production environment, please uncomment the lines with value "ReportServer.", and comment out the line below it.
-- There are 2 instances of this in the script.

----------------------------------------------------------------
-- Create AddGISQueryEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddGISQueryEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddGISQueryEvent
        (
			 @GISQueryType varchar(50),
			 @Submitted datetime,
			 @TimeLogged datetime)
			AS
			BEGIN 
				SET NOCOUNT ON 
			END
		')

END
GO


----------------------------------------------------------------
-- Update AddGISQueryEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE AddGISQueryEvent (
			 @GISQueryType varchar(50),
			 @Submitted datetime,
			 @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into GISQueryEvent Table'

    Insert into GISQueryEvent (GISQueryType, Submitted, TimeLogged)
    Values (@GISQueryType, @Submitted, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Create TransferGISQueryEvents stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferGISQueryEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE TransferGISQueryEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferGISQueryEvents stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE TransferGISQueryEvents
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

--DELETE FROM [ReportServer].[Reporting].[dbo].[GISQueryEvent]
DELETE FROM [Reporting].[dbo].[GISQueryEvents]
WHERE CONVERT(varchar(10), GQEDate, 121) = @Date

--INSERT INTO [ReportServer].[Reporting].[dbo].[GISQueryEvents]
INSERT INTO [Reporting].[dbo].[GISQueryEvents]
(
	GQEDate,
	GQEHour,
	GQEHourQuarter,
	GQEWeekDay,
	GQEGQETID,
	GQECount,
	GQEAvMsDuration
)
SELECT 
	CAST(CONVERT(varchar(10), GQE.Submitted, 121) AS datetime) AS GQEDate,
	DATEPART(hour, GQE.Submitted) AS GQEHour,
	CAST(DATEPART(minute, GQE.Submitted) / 15 AS smallint) AS GQEHourQuarter,
	DATEPART(weekday, GQE.Submitted) AS GQEWeekDay,
	GQET.GQETID AS GQEGQETID,
	COUNT(*) AS GQECount,
	AVG(CAST(DATEDIFF(millisecond, GQE.Submitted, GQE.TimeLogged) AS decimal(18, 0))) AS GQEAvMsDuration

  FROM GISQueryEvent GQE
  --LEFT OUTER JOIN ReportServer.Reporting.dbo.GISQueryEventType GQET ON GQE.GISQueryType = GQET.GQETCode
  LEFT OUTER JOIN Reporting.dbo.GISQueryEventType GQET ON GQE.GISQueryType = GQET.GQETCode
  WHERE CONVERT(varchar(10), GQE.Submitted, 121) = @Date
  GROUP BY
	CAST(CONVERT(varchar(10), GQE.Submitted, 121) AS datetime),
	DATEPART(hour, GQE.Submitted),
	CAST(DATEPART(minute, GQE.Submitted) / 15 AS smallint),
	DATEPART(weekday, GQE.Submitted),
	GQET.GQETID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- Grant permissions - will only work for relevant users as only they
-- will exist
GRANT  EXECUTE  ON [dbo].[AddGISQueryEvent]  TO [BBPTDPSIW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddGISQueryEvent]  TO [BBPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddGISQueryEvent]  TO [ACPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddGISQueryEvent]  TO [BBPTDPSIS\aspuser]
GRANT  EXECUTE  ON [dbo].[AddGISQueryEvent]  TO [BBPTDPS\aspuser]
GRANT  EXECUTE  ON [dbo].[AddGISQueryEvent]  TO [ACPTDPS\aspuser]

GRANT  EXECUTE  ON [dbo].[TransferGISQueryEvents]  TO [BBPTDPSIS\aspuser]
GRANT  EXECUTE  ON [dbo].[TransferGISQueryEvents]  TO [BBPTDPS\aspuser]
GRANT  EXECUTE  ON [dbo].[TransferGISQueryEvents]  TO [ACPTDPS\aspuser]

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1969
SET @ScriptDesc = 'Add ReportStaging stored procedures for GISQueryEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO