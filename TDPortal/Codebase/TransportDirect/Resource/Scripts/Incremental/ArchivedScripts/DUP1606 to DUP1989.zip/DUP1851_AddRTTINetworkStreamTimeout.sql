-- ***********************************************
-- NAME          : DUP1851_AddRTTINetworkStreamTimeout.sql
-- DESCRIPTION   : Script to add a timeout for the RTTIManager SocketClient NetworkStream object
--				   To prevent it waiting indefinately & hanging
--				   Initially set to 30,000 to match DepartureBoardService.StopEventManager.CJPTimeout
-- AUTHOR        : Richard Broddle
-- DATE          : 03 January 2012
-- ************************************************

USE [PermanentPortal]
GO

-- Web
IF not exists 
	(select top 1 * from properties 
	 where pName = 'DepartureBoardService.RTTIManager.NetworkStreamTimeout' and ThemeId = 1 and AID = 'Web')
BEGIN
	INSERT INTO properties VALUES ('DepartureBoardService.RTTIManager.NetworkStreamTimeout', '30000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = '30000'
	where pname = 'DepartureBoardService.RTTIManager.NetworkStreamTimeout' and ThemeId = 1 and AID = 'Web'
END

GO

-- ExposedServices
IF not exists 
	(select top 1 * from properties 
	 where pName = 'DepartureBoardService.RTTIManager.NetworkStreamTimeout' and ThemeId = 1 and AID = 'ExposedServices')
BEGIN
	INSERT INTO properties VALUES ('DepartureBoardService.RTTIManager.NetworkStreamTimeout', '30000', 'ExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = '30000'
	where pname = 'DepartureBoardService.RTTIManager.NetworkStreamTimeout' and ThemeId = 1 and AID = 'ExposedServices'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1851
SET @ScriptDesc = 'Add RTTI NetworkStream Read / Write Timeout'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO