-- ***********************************************
-- NAME          : DUP1878_BatchJourneyProcessingReportingUpdates.sql
-- DESCRIPTION   : Script to update some batch items
-- AUTHOR        : David Lane
-- DATE          : 29 February 2012
-- ************************************************

USE [Reporting]
GO

IF NOT EXISTS (SELECT TOP 1 * FROM LandingPagePartner WHERE LPPID = 67)
BEGIN
	INSERT INTO [Reporting].[dbo].[LandingPagePartner]
			   ([LPPID]
			   ,[LPPCode]
			   ,[LPPDescription])
		 VALUES
			   (67
			   ,'BatchJP'
			   ,'BatchJourneyPlanner')
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1878
SET @ScriptDesc = 'Batch Journey Processing Reporting Updates'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO