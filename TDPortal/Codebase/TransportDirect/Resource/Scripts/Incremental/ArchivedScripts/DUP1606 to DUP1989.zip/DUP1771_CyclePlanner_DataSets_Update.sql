-- ***********************************************
-- NAME 		: DUP1771_CyclePlanner_DataSets_Update.sql
-- DESCRIPTION 	: Script to update Data sets for cycle planner
-- AUTHOR		: Amit Patel
-- DATE			: 25 Nov 2010
-- ************************************************

----------------------------------------------------------------------------------
-- CycleJourneyType dropdown list dataset changed to reflect new algorithm DLLs
---------------------------------------------------------------------------------

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM DropDownLists WHERE DataSet = 'CycleJourneyType')
	BEGIN 
		DELETE DropDownLists
		WHERE DataSet = 'CycleJourneyType'
	END

IF NOT EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'CycleJourneyType')
    BEGIN

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleJourneyType', 'Quietest', 'QuietestV913', 1, 1, 0, 1)
        
        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleJourneyType', 'Quickest', 'QuickestV913', 0, 2, 0, 1)

        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('CycleJourneyType', 'Recreational', 'RecreationalV913', 0, 3, 0, 1)

	END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1771
SET @ScriptDesc = 'Update Cycle Datasets for cycle planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO