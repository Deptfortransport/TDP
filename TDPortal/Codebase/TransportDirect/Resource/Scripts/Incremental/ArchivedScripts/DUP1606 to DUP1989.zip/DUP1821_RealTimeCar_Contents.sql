-- ***********************************************
-- NAME           : DUP1821_RealTimeCar_Contents.sql
-- DESCRIPTION    : Script to add real time car content
-- AUTHOR         : Amit Patel
-- DATE           : 23 Aug 2011
-- ***********************************************

USE [Content] 

EXEC AddtblContent
1, 1, 'langStrings', 'CarCostingDetails.highTrafficSymbol'
,'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.jpg" align="middle" alt="Road queue sign" />'
,'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.jpg" align="middle" alt="cy Road queue sign" />'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.Image.ToolTip'
,'Click for incident details'
,'cy Click for incident details'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.Loading.ImageUrl'
,'/Web2/App_Themes/TransportDirect/images/gifs/ajax-loader.gif'
,'/Web2/App_Themes/TransportDirect/images/gifs/ajax-loader.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.PlannedIncident.Title'
,'RoadWorks'
,'RoadWorks'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.PlannedIncident.Image.ImageUrl'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Incident.gif'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Incident.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.PlannedIncident.Image.AlternateText'
,'Planned Incident'
,'cy Planned Incident'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.PlannedIncident.Image.ToolTip'
,'Roadworks may impact your journey here'
,'cy Roadworks may impact your journey here'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.UnplannedIncident.Title'
,'RoadIncident'
,'RoadIncident'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.UnplannedIncident.Image.ImageUrl'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/MajorIncident.gif'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/MajorIncident.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.UnplannedIncident.Image.AlternateText'
,'Unplanned Incident'
,'cy Unplanned Incident'

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNewsIncidentPopupControl.RoadIncident.UnplannedIncident.Image.ToolTip'
,'Road incident may impact your journey here'
,'cy Road incident may impact your journey here'

EXEC AddtblContent
1, 1, 'langStrings', 'CarAllDetailsControl.AvoidClosedRoadsMessage.Text'
,'There are closed roads on your planned journey.'
,'cy There are closed roads on your planned journey.'


EXEC AddtblContent
1, 1, 'langStrings', 'CarAllDetailsControl.ReplanAvoidClosedRoads.Text'
,'Click here to replan to avoid closures'
,'cy Click here to replan to avoid closures'


EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.RouteAffectedByClosures'
,'Sorry all journeys on this route are affected by road closures'
,'cy Sorry all journeys on this route are affected by road closures'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.RouteAffectedByClosures'
,'Sorry all journeys on this route are affected by road closures'
,'cy Sorry all journeys on this route are affected by road closures'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlannerOutput.JourneyWebNoRoadResultsForAvoidToids'
,'Sorry all journeys on this route are affected by road closures'
,'cy Sorry all journeys on this route are affected by road closures'

EXEC AddtblContent
1, 1, 'JourneyPlannerService', 'JourneyPlannerOutput.JourneyWebNoRoadResultsForAvoidToids'
,'Sorry all journeys on this route are affected by road closures'
,'cy Sorry all journeys on this route are affected by road closures'


EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsControl.highTrafficSymbol.ImageUrl'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.gif'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.gif'


EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsControl.highTrafficSymbol.ToolTip'
,'High traffic levels likely on this road'
,'cy High traffic levels likely on this road'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsControl.highTrafficSymbol.PopupTitle'
,'High traffic levels'
,'cy High traffic levels'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsControl.highTrafficSymbol.PopupContent'
,'High traffic levels likely on this road, see map of the journey.'
,'cy High traffic levels likely on this road, see map of the journey.'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyTypeControl.JourneyType.AvoidClosedRoads.Text'
,'{0} journey for a {1} sized {2} car avoiding closed roads'
,'cy {0} journey for a {1} sized {2} car avoiding closed roads'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1821
SET @ScriptDesc = 'Script to add real time car content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO