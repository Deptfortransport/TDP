-- *************************************************************************************
-- NAME 		: DUP1722_Add_MachineName_Column_to_ReferenceTransactionEvents_Table.sql
-- DESCRIPTION 		: Add_MachineName_Column_to_ReferenceTransactionEvents_Table
-- *************************************************************************************
USE [Reporting]
GO

----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('ReferenceTransactionEvents')
						AND syscolumns.name = 'RTEMachineName')
ALTER TABLE ReferenceTransactionEvents ADD RTEMachineName VARCHAR(50) NULL


GO


-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)
SET @ScriptNumber = 1722

SET @ScriptDesc = 'Add_MachineName_Column_to_ReferenceTransactionEvents_Table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-----------------------------------------