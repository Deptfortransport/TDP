-- ***********************************************
-- NAME           : DUP1829_RealTimeCar_Contents_HighTrafficSymbol.sql
-- DESCRIPTION    : Script to add real time car content
-- AUTHOR         : Amit Patel
-- DATE           : 23 Aug 2011
-- ***********************************************

USE [Content] 
GO

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsControl.highTrafficSymbol.ImageUrl'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.jpg'
,'/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.jpg'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1829
SET @ScriptDesc = 'Script to add real time car content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO