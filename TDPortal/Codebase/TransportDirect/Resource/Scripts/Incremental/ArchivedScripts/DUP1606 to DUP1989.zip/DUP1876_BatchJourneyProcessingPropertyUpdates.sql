-- ***********************************************
-- NAME          : DUP1876_BatchJourneyProcessing.sql
-- DESCRIPTION   : Script to update properties values
-- AUTHOR        : David Lane
-- DATE          : 23 February 2012
-- ************************************************


USE PermanentPortal

-- Properties for the website
DECLARE @AID NVARCHAR(50) = 'Web'
DECLARE @GID NVARCHAR(50) = 'UserPortal'

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerDB' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchJourneyPlannerDB' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerDB' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchJourneyPlannerDB', 'Server=.;Initial Catalog=BatchJourneyPlanner;Trusted_Connection=true;', @AID, @GID, 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerMaxLines' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchJourneyPlannerMaxLines' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerMaxLines' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchJourneyPlannerMaxLines', '500', @AID, @GID, 0, 1)
	END
END


-- Properties for the batch service
SET @AID = 'BatchJourneyPlannerService'
SET @GID = 'UserPortal'

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerDB' 
	AND AID = @AID
	AND GID = @GID
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerDB', 'Server=.;Initial Catalog=BatchJourneyPlanner;Trusted_Connection=true;', @AID, @GID, 0, 1)
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingServiceEnabled' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingServiceEnabled' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingServiceEnabled' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingServiceEnabled', 'true', @AID, @GID, 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingPeakStartTime' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingPeakStartTime' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingPeakStartTime' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingPeakStartTime', '00:01', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingPeakEndTime' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingPeakEndTime' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingPeakEndTime' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingPeakEndTime', '23:59', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingInWindowIntervalSeconds' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingInWindowIntervalSeconds' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingInWindowIntervalSeconds' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingInWindowIntervalSeconds', '10', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingOutWindowIntervalSeconds' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingOutWindowIntervalSeconds' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingOutWindowIntervalSeconds' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingOutWindowIntervalSeconds', '20', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingInWindowConcurrentRequests' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingInWindowConcurrentRequests' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingInWindowConcurrentRequests' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingInWindowConcurrentRequests', '3', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingOutWindowConcurrentRequests' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingOutWindowConcurrentRequests' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingOutWindowConcurrentRequests' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingOutWindowConcurrentRequests', '1', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindowCount' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingWindowCount' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindowCount' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingWindowCount', '2', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow1Start' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingWindow1Start' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow1Start' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingWindow1Start', '00:01', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow1End' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingWindow1End' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow1End' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingWindow1End', '23:00', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow2Start' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingWindow2Start' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow2Start' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingWindow2Start', '23:30', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow2End' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingWindow2End' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow2End' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingWindow2End', '23:30', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingRunningDays' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchProcessingRunningDays' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingRunningDays' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchProcessingRunningDays', 'Sunday;Monday;Tuesday;Wednesday;Thursday;Friday;Saturday', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END

IF EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerAvailable' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	UPDATE properties SET AID = @AID, GID = @GID
	WHERE pName = 'BatchJourneyPlannerAvailable' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1
END
ELSE
BEGIN
	IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerAvailable' 
		AND AID = @AID
		AND GID = @GID
		AND PartnerId = 0
		AND ThemeId = 1)
	BEGIN
		INSERT INTO properties values ('BatchJourneyPlannerAvailable', 'true', '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
END


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1876
SET @ScriptDesc = 'Batch Journey Processing properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO