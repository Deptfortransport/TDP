-- ***********************************************
-- NAME 		: DUP1779_Add_MyTrainTicket.sql
-- DESCRIPTION 		: Script to add MyTrainTicket to the list of online retailers for Rail tickets.
-- AUTHOR		: Mark Turner
-- DATE			: 11 Jan 11
-- ************************************************


USE [PermanentPortal]
GO

-------------------------------
-- Add to dbo.Retailers
-------------------------------

IF EXISTS (SELECT * FROM [dbo].[Retailers] WHERE RetailerID = 'MTT')
  BEGIN
    UPDATE [dbo].[Retailers]
    SET Name = 'MyTrainTicket', WebsiteURL = 'http://www.mytrainticket.co.uk', HandoffURL = 'http://ticketing.mytrainticket.co.uk/transportdirect/', 
		PhoneNumber = '0845 1280 480', DisplayURL = 'http://www.mytrainticket.co.uk', IconURL = '/Web/images/gifs/SoftContent/mtt_lg.gif', 
		AllowsMTH = 'N', SmallIconUrl = '/Web/images/gifs/SoftContent/mtt_sm.gif'
    WHERE RetailerID = 'MTT'
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[Retailers] (RetailerId, Name, WebsiteURL, HandoffURL, PhoneNumber, DisplayURL, IconURL, AllowsMTH, SmallIconUrl)
    VALUES ('MTT', 'MyTrainTicket', 'http://www.mytrainticket.co.uk', 'http://ticketing.mytrainticket.co.uk/transportdirect/', '0845 1280 480',
	 'http://www.mytrainticket.co.uk', '/Web/images/gifs/SoftContent/mtt_lg.gif', 'N', '/Web/images/gifs/SoftContent/mtt_sm.gif')
  END
GO


-------------------------------
-- Add to dbo.RetailerLookup
-------------------------------

IF EXISTS (SELECT * FROM [dbo].[RetailerLookup] WHERE RetailerID = 'MTT')
  BEGIN
    UPDATE [dbo].[RetailerLookup]
    SET OperatorCode = 'NONE', Mode = 'Rail', PartnerId = 0, ThemeID = 1
    WHERE RetailerID = 'MTT'
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[RetailerLookup] (OperatorCode, Mode, RetailerId, PartnerId, ThemeId)
    VALUES ('NONE','Rail','MTT',0,1)
  END
GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1779
SET @ScriptDesc = 'Add MyTrainTicket to list of online retailers'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO