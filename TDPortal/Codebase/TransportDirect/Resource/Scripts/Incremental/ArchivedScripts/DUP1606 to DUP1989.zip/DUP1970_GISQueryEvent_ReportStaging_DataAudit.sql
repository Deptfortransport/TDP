-- ***********************************************
-- NAME 		: DUP1970_GISQueryEvent_ReportStaging_DataAudit.sql
-- DESCRIPTION 	: Added report staging data audit entries for GISQueryEvents
-- AUTHOR		: Mitesh Modi
-- DATE			: 14 Jan 2013
-- ************************************************

USE [ReportStagingDB]
GO

-- Add new data types for reporting

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataType] 
WHERE [RSDTName] = 'TransferGISQueryEvents') 
	INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataType] ([RSDTID],[RSDTName])
		 VALUES (36,'TransferGISQueryEvents')
GO

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataAudit]
WHERE [RSDTID] = 36) 
	BEGIN
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (36,1,'20130101 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (36,2,'20130101 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (36,3,'20130101 01:00:00')
	END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1970
SET @ScriptDesc = 'Added report staging data audit entries for GISQueryEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO