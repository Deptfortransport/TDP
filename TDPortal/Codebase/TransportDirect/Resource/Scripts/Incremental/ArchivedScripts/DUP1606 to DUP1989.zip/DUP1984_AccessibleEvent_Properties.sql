-- ***********************************************
-- NAME 		: DUP1984_AccessibleEvent_Properties.sql
-- DESCRIPTION 	: Script to add AccessibleEvent logging properties
-- AUTHOR		: David Lane
-- DATE			: 18 Jan 2013
-- ************************************************

--************************** NOTE ***********************************
-- Update publishers i.e. 'FILE1' according to SITEST/BBP/ACP
----********************************************************************

USE [PermanentPortal]
GO

---------------------------------------------------------------------
-- LOGGING PROPERTIES

-- Define the custom log event
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.ACCESSIBLE.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.ACCESSIBLE.Assembly' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.ACCESSIBLE.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.ACCESSIBLE.Name' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Name', 'AccessibleEvent', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Name', 'AccessibleEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Name', 'AccessibleEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Name', 'AccessibleEvent', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Name', 'AccessibleEvent', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Name', 'AccessibleEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Name', 'AccessibleEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.ACCESSIBLE.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.ACCESSIBLE.Publishers' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Publishers', 'FILE1', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Publishers', 'FILE1', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.ACCESSIBLE.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.ACCESSIBLE.Trace' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Trace', 'On', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Trace', 'Off', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Trace', 'Off', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Trace', 'Off', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.ACCESSIBLE.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END

-- Add the custom event to the defined list
IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and pValue LIKE '%ACCESSIBLE%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' ACCESSIBLE' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'Web')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'Web'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and pValue LIKE '%ACCESSIBLE%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' ACCESSIBLE' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'TDRemotingHost')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'TDRemotingHost'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and pValue LIKE '%ACCESSIBLE%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' ACCESSIBLE' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EnhancedExposedServices')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EnhancedExposedServices'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'BatchJourneyPlanner' and pValue LIKE '%ACCESSIBLE%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' ACCESSIBLE' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlanner')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlanner'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'BatchJourneyPlannerService' and pValue LIKE '%ACCESSIBLE%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' ACCESSIBLE' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlannerService')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlannerService'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and pValue LIKE '%ACCESSIBLE%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' ACCESSIBLE' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName = 'Logging.Event.Custom' and AID = 'EventReceiver')
	WHERE pName = 'Logging.Event.Custom' and AID = 'EventReceiver'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and pValue LIKE '%ACCESSIBLE%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' ACCESSIBLE' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EventReceiverGroup')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EventReceiverGroup'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1984
SET @ScriptDesc = 'AccessibleEvent properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO