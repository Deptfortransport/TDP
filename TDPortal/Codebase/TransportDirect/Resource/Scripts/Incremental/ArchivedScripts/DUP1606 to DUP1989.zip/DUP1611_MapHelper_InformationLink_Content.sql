-- ***********************************************
-- NAME 		: DUP1611_MapHelper_InformationLink_Content.sql
-- DESCRIPTION 	: Script to add stop, car & walkit information link html content
-- AUTHOR		: Amit Patel
-- DATE			: 09 Mar 2010
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'MapHelper.CarParkInformationLink'
, '<a href="javascript: ESRIUKTDPAPI.showCarParkInformation(\''{0}\'');">For more information about this car park click here</a>'
, '<a href="javascript: ESRIUKTDPAPI.showCarParkInformation(\''{0}\'');">For more information about this car park click here</a>'

EXEC AddtblContent
1, 1, 'langStrings', 'MapHelper.StopInformationLink'
, '<a href="javascript: ESRIUKTDPAPI.showStopsInformation(\''{0}\'');">For more information about this stop click here</a>'
, '<a href="javascript: ESRIUKTDPAPI.showStopsInformation(\''{0}\'');">For more information about this stop click here</a>'

EXEC AddtblContent
1, 1, 'langStrings', 'MapHelper.StopInformationLink.SpecificStop'
, '<div class="mapInfoWindow_InformationLink"><a href="javascript: ESRIUKTDPAPI.showStopsInformation(\''{0}\'');">For more information about {1} click here</a></div>'
, '<div class="mapInfoWindow_InformationLink"><a href="javascript: ESRIUKTDPAPI.showStopsInformation(\''{0}\'');">For more information about {1} click here</a></div>'

EXEC AddtblContent
1, 1, 'langStrings', 'MapHelper.InformationLink.External'
, '<div class="mapInfoWindow_InformationLink"><a href="{0}" target="_blank">{1} {2}</a></div>'
, '<div class="mapInfoWindow_InformationLink"><a href="{0}" target="_blank">{1} {2}</a></div>'

EXEC AddtblContent
1, 1, 'langStrings', 'MapHelper.WalkitLink'
, '<a href="{0}" target="_blank">Get directions for the walk {1}</a>'
, '<a href="{0}" target="_blank">Get directions for the walk {1}</a>'

EXEC AddtblContent
1, 1, 'langStrings', 'MapHelper.WalkitLink.Text'
, 'Get directions for the walk'
, 'Get directions for the walk'


Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1611
SET @ScriptDesc = 'Script to add stop, car & walkit information link html content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO