-- ***********************************************
-- NAME 		: DUP1955_AccessibleLocation_DropDownData.sql
-- DESCRIPTION 	: Accessibility options dropdownlists
-- AUTHOR		: David Lane
-- DATE			: 08 Nov 12
-- ************************************************

USE [PermanentPortal]
GO

-- Tidy up
DELETE FROM [DropDownLists]
WHERE DataSet = 'AccessibleOptionsRadio'

-- Accessible options radio data list
IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleOptionsRadio' AND ResourceID = 'Wheelchair')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleOptionsRadio', 'Wheelchair', 1, 0, 1, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleOptionsRadio' AND ResourceID = 'WheelchairAndAssistance')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleOptionsRadio', 'WheelchairAndAssistance', 2, 0, 2, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleOptionsRadio' AND ResourceID = 'Assistance')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleOptionsRadio', 'Assistance', 3, 0, 3, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleOptionsRadio' AND ResourceID = 'NoRequirement')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleOptionsRadio', 'NoRequirement', 4, 1, 4, 0, 1)
END

GO

-- Tidy up
DELETE FROM [DropDownLists]
WHERE DataSet = 'AccessibleTransportTypes'

-- Accessible options radio data list
IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleTransportTypes' AND ResourceID = 'Rail')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleTransportTypes', 'Rail', 'Rail', 0, 1, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleTransportTypes' AND ResourceID = 'Bus')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleTransportTypes', 'Bus', 'Bus', 1, 2, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleTransportTypes' AND ResourceID = 'Underground')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleTransportTypes', 'Underground', 'Underground', 0, 3, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleTransportTypes' AND ResourceID = 'LightRail')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleTransportTypes', 'LightRail', 'LightRail', 1, 4, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleTransportTypes' AND ResourceID = 'Ferry')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleTransportTypes', 'Ferry', 'Ferry', 0, 5, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleTransportTypes' AND ResourceID = 'DLR')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleTransportTypes', 'DLR', 'DLR', 1, 6, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM DropDownLists WHERE DataSet = 'AccessibleTransportTypes' AND ResourceID = 'Locality')
BEGIN
	INSERT INTO DropDownLists values ('AccessibleTransportTypes', 'Locality', 'Locality', 1, 7, 0, 1)
END

GO  

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1955
SET @ScriptDesc = 'Acccessibility options drop down list data'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO