-- ***********************************************
-- NAME           : DUP1745_Remove_AboutUs_WhatNext_LeftHandLink.sql
-- DESCRIPTION    : Script to remove 'what next' left hand link on about us page
-- AUTHOR         : Amit Patel
-- DATE           : 16 Sept 2010
-- ***********************************************

USE [TransientPortal] 

EXEC RemoveSuggestionLink 'AboutUs.WhatNext','AboutUs','AboutUsMenu'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1745
SET @ScriptDesc = 'Script to remove ''what next'' left hand link on about us page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO