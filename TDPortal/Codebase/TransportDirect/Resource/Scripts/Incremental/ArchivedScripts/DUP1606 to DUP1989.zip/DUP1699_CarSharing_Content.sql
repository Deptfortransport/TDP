-- ***********************************************
-- NAME 		: DUP1699_CarSharing_Content.sql
-- DESCRIPTION 	: Population of content in content database
-- AUTHOR		: Richard Hopkins
-- DATE         : 4 May 2010
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE Content
GO

-- Delete all records first
DELETE FROM [dbo].[tblContent]
WHERE ControlName like 'CarSharing.%'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'CarSharing.CarSharingLink', '~/staticwithoutprint.aspx?id=_web2_about_relatedsites#CarSharing', '~/staticwithoutprint.aspx?id=_web2_about_relatedsites#CarSharing'

EXEC AddtblContent
1, 1, 'langStrings', 'CarSharing.CarSharingLink.Text', 'Find out about car sharing', 'Find out about car sharing'

EXEC AddtblContent
1, 1, 'langStrings', 'CarSharing.CarSharingLogo', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/car_sharing.gif" alt ="Find out about car sharing" />', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/car_sharing.gif" alt ="Find out about car sharing" />'

----------------------------------------------------------------
----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1699
SET @ScriptDesc = 'Script to create entries in the Content DB for Car Sharing'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO