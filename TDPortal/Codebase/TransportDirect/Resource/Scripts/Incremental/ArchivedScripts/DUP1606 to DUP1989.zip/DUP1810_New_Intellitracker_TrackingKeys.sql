-- ***********************************************
-- NAME 		: DUP1810_Intellitracker_TrackingKeys.sql
-- DESCRIPTION 	: Script to add Tracking keys for Intellitracker
-- AUTHOR		: Phil Scott
-- DATE			: 09 Jun 2011
-- ************************************************

USE [Content]
GO


-----------------------------------------------------------------------------------------
-- Cycle Journey Details Page Trakcing keys
-----------------------------------------------------------------------------------------
	

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'OutwardTime'
	,'CY03'
	,'Outward journey time selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'ReturnTime'
	,'CY04'
	,'Return journey time selected by user' 

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'OutwardTime'
	,'JD15'
	,'Outward journey time selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'ReturnTime'
	,'JD16'
	,'Return journey time selected by user'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1810
SET @ScriptDesc = 'Script to add New Tracking keys for Intellitracker'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END