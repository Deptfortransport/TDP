-- ***********************************************
-- NAME 		: DUP1826_NX_Route60_Fare_Display_Update.sql
-- DESCRIPTION  : Change to CoachFares.NationalExpress.Route60.AppendString to make it 
--                more obvious that these fares are for the over 60's only.
-- AUTHOR		: Rich Broddle
-- DATE			: 26 Aug 2011
-- ************************************************

USE [PermanentPortal]
GO

IF not exists ( select top 1 * from properties 
	where pName = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'Web')
BEGIN
	insert into properties values ('CoachFares.NationalExpress.Route60.AppendString',
				'Route 60 (over 60''s only) - ','Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Route 60 (over 60''s only) - ' 
		where pname = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'Web'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('CoachFares.NationalExpress.Route60.AppendString',
				'Route 60 (over 60''s only) - ','TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Route 60 (over 60''s only) - ' 
		where pname = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDRemotingHost'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDPlannerHost')
BEGIN
	insert into properties values ('CoachFares.NationalExpress.Route60.AppendString',
				'Route 60 (over 60''s only) - ','TDPlannerHost', 'TDPlannerHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Route 60 (over 60''s only) - ' 
		where pname = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDPlannerHost'
END


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1826
SET @ScriptDesc = 'Change to CoachFares.NationalExpress.Route60.AppendString'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO