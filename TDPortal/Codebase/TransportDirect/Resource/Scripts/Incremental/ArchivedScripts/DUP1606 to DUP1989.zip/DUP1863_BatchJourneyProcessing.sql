-- ***********************************************
-- NAME          : DUP1863_BatchJourneyProcessing.sql
-- DESCRIPTION   : Script to add text items for the batch journey planning page
-- AUTHOR        : David Lane
-- DATE          : 05 January 2012
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.AppendPageTitle',
	'Batch Journey Planning |',
	'Batch Journey Planning |'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.PageTitle',
	'Batch Journey Planner',
	'Batch Journey Planner'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ImageUrl',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.AlreadyApproved',
	'Already an approved user of the batch journey planner?',
	'Already an approved user of the batch journey planner?'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WhatIs',
	'What is the batch Journey Planner?',
	'What is the batch Journey Planner?'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HowRegister',
	'How do I apply to be a user of the Batch Journey Planner?',
	'How do I apply to be a user of the Batch Journey Planner?'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegdAs',
	'You have registered with Transport Direct with the following email address: <strong>{0}</strong>',
	'You have registered with Transport Direct with the following email address: <strong>{0}</strong>'
	
-- help
EXEC Content.dbo.AddtblContent 1, 2, '_web2_help_helpbatchjourneyplanner', 'Page', 
	'Batch Journey Planner Help | Transport Direct',
	'Batch Journey Planner Help | Transport Direct'

EXEC Content.dbo.AddtblContent 1, 2, '_web2_help_helpbatchjourneyplanner', 'Page', 
	'/Web2/staticnoprint.aspx',
	'/Web2/staticnoprint.aspx'

EXEC Content.dbo.AddtblContent 1, 2, '_web2_help_helpbatchjourneyplanner', 'QueryString', 
	'staticnoprint',
	'staticnoprint'

EXEC Content.dbo.AddtblContent 1, 2, '_web2_help_helpbatchjourneyplanner', 'Channel', 
	'/Channels/TransportDirect/Help/HelpBatchJourneyPlanner',
	'/Channels/TransportDirect/Help/HelpBatchJourneyPlanner'

EXEC Content.dbo.AddtblContent 1, 1, 'langstrings', 'HomeTipsTools.imageBatchJourneyPlanner.ImageUrl', 
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif'

EXEC Content.dbo.AddtblContent 1, 1, 'langstrings', 'HomeTipsTools.imageBatchJourneyPlannerSkipLink.AlternateText', 
	'Skip to Batch Journey Planner',
	'Skip to Batch Journey Planner'

EXEC Content.dbo.AddtblContent 1, 1, 'langstrings', 'HomeTipsTools.imageBatchJourneyPlanner.AlternateText', 
	'Batch Journey Planner',
	'Batch Journey Planner'

EXEC Content.dbo.AddtblContent 1, 1, 'langstrings', 'HomeTipsTools.lblBatchJourneyPlanner', 
	'Batch Journey Planner',
	'Batch Journey Planner'


EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.FirstName',
	'First Name<strong>*</strong>:',
	'First Name<strong>*</strong>:'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LastName',
	'Last Name<strong>*</strong>:',
	'Last Name<strong>*</strong>:'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Phone',
	'Phone number<strong>*</strong>:',
	'Phone number<strong>*</strong>:'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ProposedUse',
	'Please outline your proposed use of the batch journey planner<strong>*</strong>',
	'Please outline your proposed use of the batch journey planner<strong>*</strong>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Mandatory',
	'<strong>*</strong> indicates the field is mandatory',
	'<strong>*</strong> indicates the field is mandatory'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.EmailsText',
	'<br>You should receive an email confirming your request for registration then another confirming when your registration has been activated. This should take no more than two working days.',
	'<br>You should receive an email confirming your request for registration then another confirming when your registration has been activated. This should take no more than two working days.'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.MoreInfo',
	'<br>For more information about the batch journey planner, please read the <a href="TODO">Batch journey planner - Frequently Asked Questions</a>',
	'<br>For more information about the batch journey planner, please read the <a href="TODO">Batch journey planner - Frequently Asked Questions</a>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.UKMap',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Map_UKRegionMap.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Map_UKRegionMap.gif'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WhatIs.SC',
	'It is an automated service providing detailed directions or statistics for a large number of journeys. See <a href="/Wbe2/BatchJourneyPlanner/BatchJourneyPlanner">brochure</a> and <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">FAQ</a> for details.',
	'It is an automated service providing detailed directions or statistics for a large number of journeys. See <a href="/Wbe2/BatchJourneyPlanner/BatchJourneyPlanner">brochure</a> and <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">FAQ</a> for details.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.AlreadyApproved.SC',
	'Please <a href="/Web2/LoginRegister.aspx">log in</a> then continue to the <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx">Registered User Options Page</a>',
	'Please <a href="/Web2/LoginRegister.aspx">log in</a> then continue to the <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx">Registered User Options Page</a>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HowRegister.SC',
	'Please <a href="/Web2/LoginRegister.aspx">log in/register</a> then complete the form below and indicate that you agree to our terms and conditions.  You will receive an email confirming receipt of your request, then another when your batch user account has been activated.  This should take no more than two working days.',
	'Please <a href="/Web2/LoginRegister.aspx">log in/register</a> then complete the form below and indicate that you agree to our terms and conditions.  You will receive an email confirming receipt of your request, then another when your batch user account has been activated.  This should take no more than two working days.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Terms',
	'PLACEHOLDER FOR DFT SOFT CONTENT - Terms and conditions blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah',
	'PLACEHOLDER FOR DFT SOFT CONTENT - Terms and conditions blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah <br/> blah blah blah'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ChkTerms',
	'Accept Terms and Conditions',
	'Accept Terms and Conditions'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Welcome',
	'<p>&nbsp;</p>Welcome to the batch journey planner. Please use the template provided to create request files to upload requests.<p>&nbsp;</p>',
	'<p>&nbsp;</p>Welcome to the batch journey planner. Please use the template provided to create request files to upload requests.<p>&nbsp;</p>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Upload',
	'New Request',
	'New Request'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.UploadInstructions',
	'<p>&nbsp;</p>To request journey plans or statistics for a new set of journeys, first create your journeys file in CSV, then choose from the options below before uploading it.  See the <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.pdf">User Guide</a> for detailed instructions.<p>&nbsp;</p>',
	'<p>&nbsp;</p>To request journey plans or statistics for a new set of journeys, first create your journeys file in CSV, then choose from the options below before uploading it.  See the <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.pdf">User Guide</a> for detailed instructions.<p>&nbsp;</p>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Output',
	'Please choose the output required',
	'Please choose the output required'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckStats',
	'Journey statistics',
	'Journey statistics'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckDetails',
	'Journey plans *',
	'Journey plans *'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Types',
	'Please choose the journey types you require',
	'Please choose the journey types you require'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckPublic',
	'Public transport',
	'Public transport'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckCar',
	'Car',
	'Car'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckCycle',
	'Cycle',
	'Cycle'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Format',
	'* Should your output format be',
	'* Should your output format be'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Tick',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Tick.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Tick.gif'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ArrowDown',
	'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/arrowdown.gif" alt="Descending" />',
	'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/arrowdown.gif" alt="Descending" />'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ArrowUp',
	'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/arrowup.gif" alt="Ascending" />',
	'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/arrowup.gif" alt="Ascending" />'
	
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Template',
	'How to use the Batch Journey Planner',
	'How to use the Batch Journey Planner'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.TemplateDesc',
	'<p>&nbsp;</p>1 - Read the User Guide<br/>
	2 - Download the CSV template file and populate it with your set of journeys<br/>
	3 - Upload the CSV file using the "New request" form<br/>
	4 - Collect your results when they appear in the table below<br/>',
	'<p>&nbsp;</p>1 - Read the User Guide<br/>
	2 - Download the CSV template file and populate it with your set of journeys<br/>
	3 - Upload the CSV file using the "New request" form<br/>
	4 - Collect your results when they appear in the table below<br/>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LinkTemplate',
	'<p>&nbsp;</p><a target="_child" href="/Web2/BatchJourneyPlanner/Template.csv">CSV template file.</a>',
	'<p>&nbsp;</p><a target="_child" href="/Web2/BatchJourneyPlanner/Template.csv">CSV template file.</a>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LinkTemplateDesc',
	'<p>&nbsp;</p><a target="_child" href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.pdf">Batch Journey Planner user guide.</a>',
	'<p>&nbsp;</p><a target="_child" href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.pdf">Batch Journey Planner user guide.</a>'


EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NotLoggedIn',
	'<p>&nbsp;</p>You must be logged in to use this service. Please login by clicking Login / Register on the menu tab bar<p>&nbsp;</p>',
	'<p>&nbsp;</p>You must be logged in to use this service. Please login by clicking Login / Register on the menu tab bar<p>&nbsp;</p>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegistrationPending',
	'<p>&nbsp;</p>You have registered for batch journey planning however your registration has yet to be approved. Please wait to be contacted.<p>&nbsp;</p>',
	'<p>&nbsp;</p>You have registered for batch journey planning however your registration has yet to be approved. Please wait to be contacted.<p>&nbsp;</p>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegistrationSuspended',
	'<p>&nbsp;</p>You have registered for batch journey planning however your registration has been suspended. You may not use the batch journey planner.<p>&nbsp;</p>',
	'<p>&nbsp;</p>You have registered for batch journey planning however your registration has been suspended. You may not use the batch journey planner.<p>&nbsp;</p>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegButton',
	'Register',
	'Register'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoFirstName',
	'<p>&nbsp;</p>Please enter your first name',
	'<p>&nbsp;</p>Please enter your first name'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoLastName',
	'<p>&nbsp;</p>Please enter your last name',
	'<p>&nbsp;</p>Please enter your last name'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoPhone',
	'<p>&nbsp;</p>Please enter a valid phone number - this can include numbers, spaces, "(", ")" and "+"',
	'<p>&nbsp;</p>Please enter a valid phone number - this can include numbers, spaces, "(", ")" and "+"'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoUsage',
	'<p>&nbsp;</p>Please enter a usage reason',
	'<p>&nbsp;</p>Please enter a usage reason'
 
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.BadRecaptcha',
	'<p>&nbsp;</p>Please enter the words displayed',
	'<p>&nbsp;</p>Please enter the words displayed'
 
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoTerms',
	'<p>&nbsp;</p>Please accept the terms and conditions',
	'<p>&nbsp;</p>Please accept the terms and conditions'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Confirmation',
	'<p>&nbsp;</p>Thank you for applying to use the batch journey planner. We will be in touch soon.<p>&nbsp;&</p><a href="/Web2/Home.aspx">Return to Transport Direct homepage</a>',
	'<p>&nbsp;</p>Thank you for applying to use the batch journey planner. We will be in touch soon.<p>&nbsp;&</p><a href="/Web2/Home.aspx">Return to Transport Direct homepage</a>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.EmailFrom',
	'batchjourneyplanner@transportdirect.info',
	'batchjourneyplanner@transportdirect.info'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegEmailBody',
	'Dear {0} {1},\r\n\r\nThank you for requesting access to the Transport Direct Batch Journey Planner. You gave us the following reason for requiring access: "{2}". Your request is being processed; we will confirm the results of your application within 10 working days. We will be in touch shortly to advise whether your request for access to the batch journey planner has been successful or not.\r\nYour company name is {3}\r\n\r\nWe regret that we cannot enter into correspondence through this e-mail address. If you wish to contact Transport Direct, please do so via the "Contact us" link.\r\n\r\nYours sincerely,\r\nTom Herring\r\nBusiness Service Manager\r\nTransport Direct',
	'Dear {0} {1},\r\n\r\nThank you for requesting access to the Transport Direct Batch Journey Planner. You gave us the following reason for requiring access: "{2}". Your request is being processed; we will confirm the results of your application within 10 working days. We will be in touch shortly to advise whether your request for access to the batch journey planner has been successful or not.\r\nYour company name is {3}\r\n\r\nWe regret that we cannot enter into correspondence through this e-mail address. If you wish to contact Transport Direct, please do so via the "Contact us" link.\r\n\r\nYours sincerely,\r\nTom Herring\r\nBusiness Service Manager\r\nTransport Direct'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegEmailTitle',
	'Transport Direct New Batch User Request',
	'Transport Direct New Batch User Request'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.DftEmailBody',
	'Dear Tom,\r\n\r\nA user has registered for access to the batch journey planner with the following details:\r\n\r\nFirst Name: {0}\r\nLast Name: {1}\r\nCompany: {2}\r\nPhone: {3}\r\nEmail: {4}\r\nProposed use: {5}\r\n\r\nRequest Date: {6}\r\n\r\nThis email has been automatically generated by Transport Direct so please do not reply to this email.',
	'Dear Tom,\r\n\r\nA user has registered for access to the batch journey planner with the following details:\r\n\r\nFirst Name: {0}\r\nLast Name: {1}\r\nCompany: {2}\r\nPhone: {3}\r\nEmail: {4}\r\nProposed use: {5}\r\n\r\nRequest Date: {6}\r\n\r\nThis email has been automatically generated by Transport Direct so please do not reply to this email.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.DftEmailTitle',
	'New Batch User Request',
	'New Batch User Request'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.DftEmailAddress',
	'TODO@dft.gov.uk',
	'TODO@dft.gov.uk'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ButtonLoadFile',
	'Load file',
	'Load file'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WrongFileType',
	'<p>&nbsp;</p>You may only upload .csv files. Please select a .csv file to upload.',
	'<p>&nbsp;</p>You may only upload .csv files. Please select a .csv file to upload.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoFileSelected',
	'<p>&nbsp;</p>Please select a file before clicking upload.',
	'<p>&nbsp;</p>Please select a file before clicking upload.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.FileUploadFailed',
	'<p>&nbsp;</p>Sorry the file you selected could not be uploaded.',
	'<p>&nbsp;</p>Sorry the file you selected could not be uploaded.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.EmptyFile',
	'<p>&nbsp;</p>Sorry the file you selected was empty and cannot be processed.',
	'<p>&nbsp;</p>Sorry the file you selected was empty and cannot be processed.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WrongHeader',
	'<p>&nbsp;</p>Sorry the file you selected had incorrect headers, the first line should read "RequestID,OriginType,Origin,DestinationType,Destination,OutwardDate,OutwardTime,OutwardArrDep,ReturnDate,ReturnTime,ReturnArrDep".',
	'<p>&nbsp;</p>Sorry the file you selected had incorrect headers, the first line should read "RequestID,OriginType,Origin,DestinationType,Destination,OutwardDate,OutwardTime,OutwardArrDep,ReturnDate,ReturnTime,ReturnArrDep".'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.StatsDetails',
	'<p>&nbsp;</p>Please choose at least one of journey statistics and journey details.',
	'<p>&nbsp;</p>Please choose at least one of journey statistics and journey details.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.PtCarCycle',
	'<p>&nbsp;</p>Please choose at least one of public transport, car and cycle.',
	'<p>&nbsp;</p>Please choose at least one of public transport, car and cycle.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.XmlRtf',
	'<p>&nbsp;</p>Please choose either RTF or XML.',
	'<p>&nbsp;</p>Please choose either RTF or XML.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.MaxFileLength',
	'<p>&nbsp;</p>The maximum number of request lines has been exceeded. Please try a smaller file.',
	'<p>&nbsp;</p>The maximum number of request lines has been exceeded. Please try a smaller file.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.UploadSuccess',
	'<p>&nbsp;</p>Request {0} has been successfully uploaded to the Batch Journey Planner and placed in the queue to be processed. Your request is {1} in the queue to be processed.',
	'<p>&nbsp;</p>Request {0} has been successfully uploaded to the Batch Journey Planner and placed in the queue to be processed. Your request is {1} in the queue to be processed.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ResultsLabel',
	'<p>&nbsp;</p>Please select the results file you wish to download.',
	'<p>&nbsp;</p>Please select the results file you wish to download.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.BatchTableLabel',
	'Recent batch activity for {0}',
	'Recent batch activity for {0}'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderRequestId',
	'Request ID',
	'Request ID'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderSubmitted',
	'Submitted',
	'Submitted'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderPublicTransport',
	'Public Transport',
	'Public Transport'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderCar',
	'Car',
	'Car'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderCycle',
	'Cycle',
	'Cycle'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberRequests',
	'Number of requests',
	'Number of requests'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberResults',
	'Number of results',
	'Number of results'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderValidationErrors',
	'Validation errors',
	'Validation errors'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberNoResults',
	'No results',
	'No results'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderDateComplete',
	'Date complete',
	'Date complete'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderStatus',
	'Status',
	'Status'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderSelect',
	'Select',
	'Select'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ButtonReload',
	'Reload',
	'Reload'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ButtonDownload',
	'Download',
	'Download'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LabelFaq',
	'For more information about the batch journey planner, please read the <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">Batch Journey Planner - Frequently Asked Questions"</a>',
	'For more information about the batch journey planner, please read the <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">Batch Journey Planner - Frequently Asked Questions"</a>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.Title',
	'Batch Journey Planner User Administration',
	'Batch Journey Planner User Administration'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.Title',
	'Batch Journey Planner User Administration',
	'Batch Journey Planner User Administration'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.ImageUrl',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.UsersTableLabel',
	'Transport Direct Batch Users',
	'Transport Direct Batch Users'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.HeaderUser',
	'User',
	'User'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.HeaderStatusChange',
	'Status Change<br/>date / time',
	'Status Change<br/>date / time'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.HeaderLastUpload',
	'Last file upload<br/>date / time',
	'Last file upload<br/>date / time'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.HeaderStatus',
	'Status',
	'Status'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.HeaderSelect',
	'Select',
	'Select'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.NotLoggedIn',
	'Please login to Transport Direct before using this page',
	'Please login to Transport Direct before using this page'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.SelectUser',
	'Please select a user before attempting an operation',
	'Please select a user before attempting an operation'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.ButtonReload',
	'Reload table',
	'Reload table'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.ButtonSuspend',
	'Suspend user',
	'Suspend user'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.ButtonActivate',
	'Activate user',
	'Activate user'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.UserSuspended',
	'{0} is now suspended',
	'{0} is now suspended'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.UserActivated',
	'{0} is now active',
	'{0} is now active'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.UserAlreadySuspended',
	'{0} is already suspended',
	'{0} is already suspended'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.UserAlreadyActivated',
	'{0} is already active',
	'{0} is already active'





-- Properties
USE PermanentPortal

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerDB' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerDB', 'Server=.;Initial Catalog=BatchJourneyPlanner;Trusted_Connection=true;', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerMaxLines' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerMaxLines', '500', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingServiceEnabled' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingServiceEnabled', 'true', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingPeakStartTime' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingPeakStartTime', '00:01', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingPeakEndTime' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingPeakEndTime', '23:59', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingInWindowIntervalSeconds' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingInWindowIntervalSeconds', '10', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingOutWindowIntervalSeconds' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingOutWindowIntervalSeconds', '20', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingInWindowConcurrentRequests' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingInWindowConcurrentRequests', '3', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingOutWindowConcurrentRequests' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingOutWindowConcurrentRequests', '1', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindowCount' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingWindowCount', '2', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow1Start' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingWindow1Start', '00:01', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow1End' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingWindow1End', '23:00', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow2Start' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingWindow2Start', '23:30', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingWindow2End' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingWindow2End', '23:30', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingRunningDays' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingRunningDays', 'Sunday;Monday;Tuesday;Wednesday;Thursday;Friday;Saturday', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerAvailable' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerAvailable', 'true', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

	
-- Add left hand menu items.
DECLARE @RC int
DECLARE @StringLinkURL varchar(100)
DECLARE @StringLinkDescription varchar(500)
DECLARE @StringLinkResourceName varchar(100)
DECLARE @StringLinkResourceNameEN varchar(100)
DECLARE @StringLinkResourceNameCY varchar(100)
DECLARE @LinkCategoryName varchar(100)
DECLARE @LinkPriority int
DECLARE @IsRoot bit
DECLARE @IsSubRootLink bit
DECLARE @StringContextName varchar(100)
DECLARE @StringContextDescription varchar(500)
DECLARE @ThemeId int

-- Set parameter values here.
SET @StringLinkURL = 'BatchJourneyPlanner/BatchJourneyPlanner.aspx'
SET @StringLinkDescription = 'Batch Journey Planner Page'
SET @StringLinkResourceName = 'BatchJourneyPlanner'
SET @StringLinkResourceNameEN = 'Batch journey planner'
SET @StringLinkResourceNameCY = 'Batch journey planner'
SET @LinkCategoryName = 'Tips and tools'
SET @LinkPriority = 5065
SET @IsRoot = 0
SET @IsSubRootLink = 0
SET @StringContextName = 'HomePageMenuTipsAndTools'
SET @StringContextDescription = 'Links for expandable menu on the Tips and Tools pages.'
SET @ThemeId = 1

EXECUTE @RC = [TransientPortal].[dbo].[AddInternalSuggestionLink] 
   @StringLinkURL
  ,@StringLinkDescription
  ,@StringLinkResourceName
  ,@StringLinkResourceNameEN
  ,@StringLinkResourceNameCY
  ,@LinkCategoryName
  ,@LinkPriority
  ,@IsRoot
  ,@IsSubRootLink
  ,@StringContextName
  ,@StringContextDescription
  ,@ThemeId


SET @LinkPriority = 66
SET @StringContextName = 'HomePageMenu'
SET @StringContextDescription = 'Links for expandable menu on the Home Page/mini homepages.'

EXECUTE @RC = [TransientPortal].[dbo].[AddInternalSuggestionLink] 
   @StringLinkURL
  ,@StringLinkDescription
  ,@StringLinkResourceName
  ,@StringLinkResourceNameEN
  ,@StringLinkResourceNameCY
  ,@LinkCategoryName
  ,@LinkPriority
  ,@IsRoot
  ,@IsSubRootLink
  ,@StringContextName
  ,@StringContextDescription
  ,@ThemeId

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1863
SET @ScriptDesc = 'Batch Journey Processing text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO