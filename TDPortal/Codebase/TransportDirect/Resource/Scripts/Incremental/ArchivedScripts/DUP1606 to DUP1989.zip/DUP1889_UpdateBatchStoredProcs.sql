-- ***********************************************
-- NAME           : DUP1889_UpdateBatchGetBatchStoredProcs
-- DESCRIPTION    : Script to modify Batch stored procs
-- DATE           : 14/05/2012
-- Author         : D Lane
-- ***********************************************


USE BatchJourneyPlanner
GO

ALTER PROCEDURE [dbo].[GetBatchSummary]
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT DetailsDeletedDateTime,
		BatchStatusId,
		[ReportParameters.IncludeJourneyStatistics],
		[ReportParameters.IncludeJourneyDetails],
		[ReportParameters.IncludePublicTransport],
		[ReportParameters.IncludeCar],
		[ReportParameters.IncludeCycle],
		[ReportParameters.ConvertToRtf]
		,QueuedDateTime
		,CompletedDateTime
		,NumberOfRequests
		,NumberOfSuccessfulResults
		,NumberOfUnsuccessfulRequests
		,NumberOfInvalidRequests
		,dbo.PadBatchId(BatchId)
	FROM BatchRequestSummary
	WHERE BatchId = @BatchId;
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UpdateBatchSummaryDownloadRequestInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UpdateBatchSummaryDownloadRequestInfo]
GO
CREATE PROCEDURE [dbo].[UpdateBatchSummaryDownloadRequestInfo] 
(
	@BatchId int
) 
AS
BEGIN
	-- Update the batch summary table with this download request
	DECLARE @DownloadAttempts INT
	
	IF EXISTS(SELECT 1 FROM BatchRequestSummary WHERE BatchId = @BatchId AND NumberOfResultsDownloadAttempts IS NULL)
	BEGIN
		SET @DownloadAttempts = 1
	END
	ELSE
	BEGIN
		SELECT @DownloadAttempts = NumberOfResultsDownloadAttempts + 1
		FROM BatchRequestSummary
		WHERE BatchId = @BatchId
	END
	
	UPDATE BatchRequestSummary
	SET LastResultDownloadRequestDateTime = GETDATE(),
	NumberOfResultsDownloadAttempts = @DownloadAttempts
	WHERE BatchId = @BatchId
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1889
SET @ScriptDesc = 'DUP1889_UpdateBatchGetBatchStoredProcs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

