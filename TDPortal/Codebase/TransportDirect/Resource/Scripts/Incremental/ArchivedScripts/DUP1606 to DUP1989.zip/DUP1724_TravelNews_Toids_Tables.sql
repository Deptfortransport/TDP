-- ****************************************************************
-- NAME 		: DUP1724_TravelNews_Toids_Tables.sql
-- DESCRIPTION 	: Creates the tables required for Travel News updates to include Toids
-- AUTHOR		: Mitesh Modi
-- DATE			: 24 June 2010
-- ****************************************************************

-- ************************************************
-- ****************  IMPORTANT  *******************
-- 
-- Please read Del10.12 Build Release Note before executing this script:
--		CCN0582 - Real Time Information in Car Prototype 	
--
-- ************************************************

USE [TransientPortal]
GO

-----------------------------------------------
-- TravelNewsToid Table
-----------------------------------------------

-- Drop Existing TravelNewsToid Table

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TravelNewsToid]') AND type in (N'U'))
BEGIN
	DROP TABLE [dbo].[TravelNewsToid]
END
GO


-- Create TravelNewsToid table
IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[TravelNewsToid]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[TravelNewsToid](
		[TOID] [varchar](25) NOT NULL,
		[UID] [varchar](25) NOT NULL,
		[StartDateTime] [datetime] NOT NULL,
		[ExpiryDateTime] [datetime] NOT NULL,
		[DayMask] [varchar](14) NULL,
		[DailyStartTime] [time](7) NULL,
		[DailyEndTime] [time](7) NULL,
		CONSTRAINT [PK_TravelNewsToid] PRIMARY KEY CLUSTERED 
		(
			[TOID] ASC,
			[UID]  ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1724
SET @ScriptDesc = 'Create table TravelNewsToid'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO