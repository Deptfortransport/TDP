-- ***********************************************
-- NAME 		: DUP1807_RefTransactionEvent_MachineName_Change_1.sql
-- DESCRIPTION 	: Script to create temp reftrans table to allow changes to keys on live table
-- AUTHOR		: Phil Scott
-- DATE			: 07 Jun 2011 
-- ************************************************
USE [ReportStagingDB]
GO

/****** Object:  Table [dbo].[TEmpReferenceTransactionEvent]    Script Date: 06/03/2011 10:07:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TEmpReferenceTransactionEvent]') AND type in (N'U'))
DROP TABLE [dbo].[TEmpReferenceTransactionEvent]
GO

USE [ReportStagingDB]
GO

/****** Object:  TTEmpReferenceTransactionEventable [dbo].[TEmpReferenceTransactionEvent]    Script Date: 06/03/2011 10:07:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TEmpReferenceTransactionEvent](
	[Submitted] [datetime] NOT NULL,
	[EventType] [varchar](50) NOT NULL,
	[ServiceLevelAgreement] [bit] NULL,
	[SessionId] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL,
	[Successful] [bit] NULL,
	[MachineName] [varchar](50) NOT NULL DEFAULT 'SiteConfidence',
 CONSTRAINT [PK_TEmpReferenceTransactionEvent] PRIMARY KEY NONCLUSTERED 
(
	[Submitted] ASC,
	[EventType] ASC,
	[MachineName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

INSERT INTO [ReportStagingDB].[dbo].[TEmpReferenceTransactionEvent]
           ([Submitted]
           ,[EventType]
           ,[ServiceLevelAgreement]
           ,[SessionId]
           ,[TimeLogged]
           ,[Successful]
           ,[MachineName])
SELECT [Submitted]
      ,[EventType]
      ,[ServiceLevelAgreement]
      ,[SessionId]
      ,[TimeLogged]
      ,[Successful]
      ,ISNULL([MachineName],'SiteConfidence') [MachineName]
  FROM [ReportStagingDB].[dbo].[ReferenceTransactionEvent]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1807
SET @ScriptDesc = 'Script to create temp reftrans table to allow changes to keys on live table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO