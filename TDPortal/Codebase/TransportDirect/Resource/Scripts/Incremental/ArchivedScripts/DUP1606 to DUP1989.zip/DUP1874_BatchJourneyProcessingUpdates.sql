-- ***********************************************
-- NAME          : DUP1874_BatchJourneyProcessingUpdates.sql
-- DESCRIPTION   : Script to update some bathc items
-- AUTHOR        : David Lane
-- DATE          : 23 February 2012
-- ************************************************

USE [Content]

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LinkTemplateDesc',
	'<p>&nbsp;</p><a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">Batch Journey Planner user guide.</a>',
	'<p>&nbsp;</p><a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">Batch Journey Planner user guide.</a>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WhatIs.SC',
	'It is an automated service providing detailed directions or statistics for a large number of journeys. See <a target="_child" href="/Web2/Downloads/BatchJourneyPlannerBrochure.pdf">brochure</a> and <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">FAQ</a> for details.',
	'It is an automated service providing detailed directions or statistics for a large number of journeys. See <a target="_child" href="/Web2/Downloads/BatchJourneyPlannerBrochure.pdf">brochure</a> and <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">FAQ</a> for details.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.UploadInstructions',
	'<p>&nbsp;</p>To request journey plans or statistics for a new set of journeys, first create your journeys file in CSV, then choose from the options below before uploading it.  See the <a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">User Guide</a> for detailed instructions.<p>&nbsp;</p>',
	'<p>&nbsp;</p>To request journey plans or statistics for a new set of journeys, first create your journeys file in CSV, then choose from the options below before uploading it.  See the <a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">User Guide</a> for detailed instructions.<p>&nbsp;</p>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NotLoggedIn',
	'<p>&nbsp;</p>You must be logged in to use this service. Please log in by clicking Login / Register on the menu tab bar<p>&nbsp;</p>',
	'<p>&nbsp;</p>You must be logged in to use this service. Please log in by clicking Login / Register on the menu tab bar<p>&nbsp;</p>'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoFileSelected',
	'<p>&nbsp;</p>Please browse to your CSV file before clicking "Load file".',
	'<p>&nbsp;</p>Please browse to your CSV file before clicking "Load file".'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Output',
	'Output required',
	'Output required'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Types',
	'Journey type(s) required',
	'Journey type(s) required'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LabelFaq',
	'For more information about the batch journey planner, please read the <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">Batch Journey Planner - Frequently Asked Questions</a>',
	'For more information about the batch journey planner, please read the <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">Batch Journey Planner - Frequently Asked Questions</a>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoDetailRows',
	'<p>&nbsp;</p>Sorry the file you selected did not contain any requests.',
	'<p>&nbsp;</p>Sorry the file you selected did not contain any requests.'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegEmailBody',
	'Dear {0} {1},
	
Thank you for requesting access to the Transport Direct Batch Journey Planner. You gave us the following reason for requiring access: "{2}". Your request is being processed; we will confirm the results of your application within 10 working days. We will be in touch shortly to advise whether your request for access to the batch journey planner has been successful or not.

We regret that we cannot enter into correspondence through this e-mail address. If you wish to contact Transport Direct, please do so via the "Contact us" link.

Yours sincerely,
Tom Herring
Business Service Manager
Transport Direct',
	'Dear {0} {1},
	
Thank you for requesting access to the Transport Direct Batch Journey Planner. You gave us the following reason for requiring access: "{2}". Your request is being processed; we will confirm the results of your application within 10 working days. We will be in touch shortly to advise whether your request for access to the batch journey planner has been successful or not.

We regret that we cannot enter into correspondence through this e-mail address. If you wish to contact Transport Direct, please do so via the "Contact us" link.

Yours sincerely,
Tom Herring
Business Service Manager
Transport Direct'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.DftEmailBody',
	'Dear Tom,
	
A user has registered for access to the batch journey planner with the following details:

First Name: {0}
Last Name: {1}
Phone: {3}
Email: {4}
Proposed use: {5}

Request Date: {6}

This email has been automatically generated by Transport Direct so please do not reply to this email.',
	'Dear Tom,
	
A user has registered for access to the batch journey planner with the following details:

First Name: {0}
Last Name: {1}
Phone: {3}
Email: {4}
Proposed use: {5}

Request Date: {6}

This email has been automatically generated by Transport Direct so please do not reply to this email.'



USE [BatchJourneyPlanner]
GO


ALTER PROCEDURE [dbo].[GetBatchSummary]
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT DetailsDeletedDateTime,
		BatchStatusId,
		[ReportParameters.IncludeJourneyStatistics],
		[ReportParameters.IncludeJourneyDetails],
		[ReportParameters.IncludePublicTransport],
		[ReportParameters.IncludeCar],
		[ReportParameters.IncludeCycle],
		[ReportParameters.ConvertToRtf]
		,QueuedDateTime
		,CompletedDateTime
		,NumberOfRequests
		,NumberOfSuccessfulResults
		,NumberOfUnsuccessfulRequests
		,NumberOfInvalidRequests
	FROM BatchRequestSummary
	WHERE BatchId = @BatchId;
END
GO


ALTER PROCEDURE dbo.AddBatchRequest
(
	@EmailAddress nvarchar(250),
	@IncludeJourneyStatistics bit,
	@IncludeJourneyDetails bit,
	@IncludePublicTransport bit,
	@IncludeCar bit,
	@IncludeCycle bit,
	@ConvertToRtf bit,
	@BatchDetails xml
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Get the user id
	DECLARE @UserId int
	SELECT @UserId = UserId
	FROM RegisteredUser
	WHERE @EmailAddress = EmailAddress
	
	-- Add a record to batch request
	DECLARE @Date datetime
	SELECT @Date = GETDATE()
	
	INSERT INTO [BatchJourneyPlanner].[dbo].[BatchRequestSummary]
           ([UserId]
           ,[QueuedDateTime]
           ,[BatchStatusId]
           ,[ReportParameters.IncludeJourneyStatistics]
           ,[ReportParameters.IncludeJourneyDetails]
           ,[ReportParameters.IncludePublicTransport]
           ,[ReportParameters.IncludeCar]
           ,[ReportParameters.IncludeCycle]
           ,[ReportParameters.ConvertToRtf])
     VALUES
           (@UserId
           ,@Date
           ,1 -- Pending
           ,@IncludeJourneyStatistics
           ,@IncludeJourneyDetails
           ,@IncludePublicTransport
           ,@IncludeCar
           ,@IncludeCycle
           ,@ConvertToRtf)	
	
	DECLARE @BatchId int
	SELECT @BatchId = @@IDENTITY
	
	-- Add the batch detail records
	DECLARE @userSuppliedUniqueId nvarchar(100)
	DECLARE @originType char(1)
	DECLARE @origin nvarchar(100)
	DECLARE @destinationType char(1)
	DECLARE @destination nvarchar(100)
	DECLARE @outwardDate nvarchar(6)
	DECLARE @outwardTimeAsString nvarchar(5)
	DECLARE @outwardArrDep char(1)
	DECLARE @returnDate nvarchar(6)
	DECLARE @returnTimeAsString nvarchar(5)
	DECLARE @returnArrDep char(1)
	DECLARE @detailStatus char(1)
	
	DECLARE Cursor_Details CURSOR STATIC FORWARD_ONLY READ_ONLY FOR 
	SELECT   
		tab.col.value('UserSuppliedUniqueId[1]','NVARCHAR(100)'),
		tab.col.value('OriginType[1]','CHAR(1)'),
		tab.col.value('Origin[1]','NVARCHAR(100)'),
		tab.col.value('DestinationType[1]','CHAR(1)'),
		tab.col.value('Destination[1]','NVARCHAR(100)'),
		tab.col.value('OutwardDate[1]','NVARCHAR(6)'),
		tab.col.value('OutwardTime[1]','NVARCHAR(5)'),
		tab.col.value('OutwardArrDep[1]','CHAR(1)'),
		tab.col.value('ReturnDate[1]','NVARCHAR(6)'),
		tab.col.value('ReturnTime[1]','NVARCHAR(5)'),
		tab.col.value('ReturnArrDep[1]','CHAR(1)')
	FROM @BatchDetails.nodes('//DetailRecord') tab(col) 
	
	OPEN Cursor_Details
	FETCH NEXT FROM Cursor_Details INTO
		@userSuppliedUniqueId,
		@originType,
		@origin,
		@destinationType,
		@destination,
		@outwardDate,
		@outwardTimeAsString,
		@outwardArrDep,
		@returnDate,
		@returnTimeAsString,
		@returnArrDep
		
	DECLARE @lines int
	SELECT @lines = 0
	DECLARE @invalidLines int
	SELECT @invalidLines = 0
	DECLARE @badRows int
	SELECT @badRows = 0
	
	WHILE 0 = @@FETCH_STATUS
	BEGIN
		-- Insert the detail row
		SELECT @lines = @lines + 1
		
		-- if necessary prepend a zero to the time
		IF (LEN(@outwardTimeAsString) = 3)
			SET @outwardTimeAsString = '0' + @outwardTimeAsString
			
		-- Convert outward time 
		SET @outwardTimeAsString = LEFT(@outwardTimeAsString, 2) + ':' + RIGHT(@outwardTimeAsString, 2)
		
		-- Catch errors
		BEGIN TRY		
			-- check for return journey
			IF (LEN(@returnDate) > 0 AND LEN(@returnTimeAsString) > 0 AND LEN(@returnArrDep) > 0)
			BEGIN
				-- if necessary prepend a zero to the time
				IF (LEN(@returnTimeAsString) = 3)
					SET @returnTimeAsString = '0' + @returnTimeAsString

				-- Convert return time 
				SET @returnTimeAsString = LEFT(@returnTimeAsString, 2) + ':' + RIGHT(@returnTimeAsString, 2)
				
				INSERT INTO BatchRequestDetail
				   ([BatchId]
				   ,[BatchDetailStatusId]
				   ,[UserSuppliedUniqueId]
				   ,[JourneyParameters.OriginType]
				   ,[JourneyParameters.Origin]
				   ,[JourneyParameters.DestinationType]
				   ,[JourneyParameters.Destination]
				   ,[JourneyParameters.OutwardDate]
				   ,[JourneyParameters.OutwardTime]
				   ,[JourneyParameters.OutwardArrDep]
				   ,[JourneyParameters.ReturnDate]
				   ,[JourneyParameters.ReturnTime]
				   ,[JourneyParameters.ReturnArrDep]
				   ,[SubmittedDateTime])
				VALUES
				   (@BatchId
				   ,@detailStatus
				   ,@userSuppliedUniqueId
				   ,@originType
				   ,@origin
				   ,@destinationType
				   ,@destination
				   ,@outwardDate
				   ,@outwardTimeAsString
				   ,@outwardArrDep
				   ,@returnDate
				   ,@returnTimeAsString
				   ,@returnArrDep
				   ,@Date)
			END
			ELSE
			BEGIN
				INSERT INTO BatchRequestDetail
				   ([BatchId]
				   ,[BatchDetailStatusId]
				   ,[UserSuppliedUniqueId]
				   ,[JourneyParameters.OriginType]
				   ,[JourneyParameters.Origin]
				   ,[JourneyParameters.DestinationType]
				   ,[JourneyParameters.Destination]
				   ,[JourneyParameters.OutwardDate]
				   ,[JourneyParameters.OutwardTime]
				   ,[JourneyParameters.OutwardArrDep]
				   ,[JourneyParameters.ReturnDate]
				   ,[JourneyParameters.ReturnTime]
				   ,[JourneyParameters.ReturnArrDep]
				   ,[SubmittedDateTime])
				VALUES
				   (@BatchId
				   ,NULL
				   ,@userSuppliedUniqueId
				   ,@originType
				   ,@origin
				   ,@destinationType
				   ,@destination
				   ,@outwardDate
				   ,@outwardTimeAsString
				   ,@outwardArrDep
				   ,null
				   ,null
				   ,null
				   ,@Date)
			END
		END TRY
		BEGIN CATCH
			SELECT @badRows = @badRows + 1
			
			-- Insert a batch detail record
			INSERT INTO BatchRequestDetail
				   ([BatchId]
				   ,[BatchDetailStatusId]
				   ,[UserSuppliedUniqueId]
				   ,[ErrorMessages])
			 VALUES
				   (@BatchId
				   ,4 -- validation error
				   ,@userSuppliedUniqueId
				   ,'Journey details could not be processed')
		END CATCH

		FETCH NEXT FROM Cursor_Details INTO
			@userSuppliedUniqueId,
			@originType,
			@origin,
			@destinationType,
			@destination,
			@outwardDate,
			@outwardTimeAsString,
			@outwardArrDep,
			@returnDate,
			@returnTimeAsString,
			@returnArrDep
	END
	
	CLOSE Cursor_Details
	DEALLOCATE Cursor_Details

	-- Update the summary with the number of lines.
	UPDATE BatchRequestSummary
		SET NumberOfRequests = @lines,
			NumberOfInvalidRequests = @badRows
		WHERE BatchId = @BatchId
		
	-- return the batch id and queued position
	DECLARE @PaddedBatchId nvarchar(50)
	SELECT @PaddedBatchId = BatchJourneyPlanner.dbo.PadBatchId(@BatchId)
	
	DECLARE @Position int
	SELECT @Position = COUNT(*) + 1
		FROM BatchRequestSummary
		WHERE BatchId < @BatchId
		AND BatchStatusId < 3 -- ie queued or in progress
		
	DECLARE @ReturnPosition nvarchar(20)
	SELECT @ReturnPosition = CONVERT(nvarchar(20), @Position)
	SELECT @ReturnPosition = @ReturnPosition + 
		CASE
			WHEN LEN(@ReturnPosition) > 1 AND (LEFT(RIGHT(@ReturnPosition, 2), 1) = '1') THEN 'th'
			WHEN RIGHT(@Position, 1) = '1' THEN 'st'
			WHEN RIGHT(@Position, 1) = '2' THEN 'nd'
			WHEN RIGHT(@Position, 1) = '3' THEN 'rd'
			ELSE  'th'
		END
		
	SELECT @PaddedBatchId, @ReturnPosition
	RETURN 0
END
GO


ALTER PROCEDURE dbo.GetBatchResults
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Output the results
	SELECT [UserSuppliedUniqueId]			-- 0
		,[ErrorMessages]					-- 1
		,[PublicJourneyResultSummary]		-- 2
		,[PublicJourneyResultDetails]		-- 3
		,[CarJourneyResultSummary]			-- 4
		,[CarJourneyResultDetails]			-- 5
		,[CycleJourneyResultSummary]		-- 6
		,[CycleJourneyResultDetails]		-- 7
		,[PublicOutwardJourneyStatus]		-- 8
		,[PublicReturnJourneyStatus]		-- 9
		,[CarOutwardJourneyStatus]			-- 10
		,[CarReturnJourneyStatus]			-- 11
		,[CycleOutwardJourneyStatus]		-- 12
		,[CycleReturnJourneyStatus]			-- 13
		,[JourneyParameters.Origin]			-- 14
		,[JourneyParameters.Destination]	-- 15
		,[JourneyParameters.OutwardDate]	-- 16
		,[JourneyParameters.OutwardTime]	-- 17
		,[JourneyParameters.OutwardArrDep]  -- 18
		,[JourneyParameters.ReturnDate]		-- 19
		,[JourneyParameters.ReturnTime]		-- 20
		,[JourneyParameters.ReturnArrDep]	-- 21
		,[BatchDetailStatusId]				-- 22
	FROM [BatchJourneyPlanner].[dbo].[BatchRequestDetail]
	WHERE BatchId = @BatchId
	
END
GO


CREATE PROCEDURE [dbo].[GetEmailAddressForBatch]
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT EmailAddress
	FROM RegisteredUser ru
	INNER JOIN BatchRequestSummary bs
	ON ru.UserId = bs.UserId
	WHERE bs.BatchId = @BatchId
	
END
GO


ALTER PROCEDURE [dbo].[GetBatchRequestDetailsForProcessing]
(
	@ProcessorId nvarchar(50),
	@NumberRequests int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Check for a batch this processor is already doing
	DECLARE @BatchId int
	DECLARE @Date datetime
	SET @Date = GETDATE()
	
	IF (NOT EXISTS (SELECT BatchId FROM BatchRequestSummary WHERE ProcessorId = @ProcessorId))
	BEGIN
		-- Get a new batch if there is one available
		IF (EXISTS (SELECT BatchId FROM BatchRequestSummary WHERE ProcessorId IS NULL AND BatchStatusId = 1))
		BEGIN
			SELECT @BatchId = BatchId 
				FROM BatchRequestSummary 
				WHERE ProcessorId IS NULL 
				AND BatchStatusId = 1
				ORDER BY QueuedDateTime DESC
				
			UPDATE BatchRequestSummary
				SET ProcessorId = @ProcessorId,
				BatchStatusId = 2
				WHERE BatchId = @BatchId
		END
		ELSE
		BEGIN
			-- No requests available
			RETURN 0
		END
	END
	ELSE
	BEGIN
		SELECT @BatchId = BatchId
		FROM BatchRequestSummary
		WHERE ProcessorId = @ProcessorId
	END

	-- See if the batch is complete
	DECLARE @Count int
	SELECT @Count = COUNT(*)
	FROM BatchRequestDetail
	WHERE (BatchDetailStatusId IS NULL -- Pending
	OR BatchDetailStatusId = 1) -- in progress
	AND BatchId = @BatchId
		
	IF (@Count = 0)
	BEGIN
		-- Finish off this batch and update the summary record
		SET @Date = GETDATE()
		
		UPDATE BatchRequestSummary
			SET CompletedDateTime = @Date,
			NumberOfSuccessfulResults = (SELECT COUNT(*) FROM BatchRequestDetail WHERE BatchDetailStatusId = 2 AND BatchId = @BatchId),
			NumberOfUnsuccessfulRequests = (SELECT COUNT(*) FROM BatchRequestDetail WHERE BatchDetailStatusId = 3 AND BatchId = @BatchId),
			BatchStatusId = 3,
			ProcessorId = null
		WHERE BatchId = @BatchId
		
		RETURN @BatchId
	END
	ELSE
	BEGIN
		-- Check if batch has stalled
		SELECT @Count = COUNT(*)
		FROM BatchRequestDetail
		WHERE BatchDetailStatusId IS NULL
		AND BatchId = @BatchId
		
		IF (@Count = 0)
		BEGIN
			-- resset the stalled records
			UPDATE BatchRequestDetail
			SET BatchDetailStatusId = NULL
			WHERE BatchDetailStatusId = 1
			AND BatchId = @BatchId
		END
	END

	-- Get detail records and preferences
	SELECT TOP (@NumberRequests) 
		bd.RequestId,									--0
		bs.[ReportParameters.IncludeJourneyStatistics],	--1
		bs.[ReportParameters.IncludeJourneyDetails],	--2
		bs.[ReportParameters.IncludePublicTransport],	--3
		bs.[ReportParameters.IncludeCar],				--4
		bs.[ReportParameters.IncludeCycle],				--5
		bs.[ReportParameters.ConvertToRtf],				--6
		bd.UserSuppliedUniqueId,						--7
		bd.[JourneyParameters.OriginType],				--8
		bd.[JourneyParameters.Origin],					--9
		bd.[JourneyParameters.DestinationType],			--10
		bd.[JourneyParameters.Destination],				--11
		bd.[JourneyParameters.OutwardDate],				--12
		bd.[JourneyParameters.OutwardTime],				--13
		bd.[JourneyParameters.OutwardArrDep],			--14
		bd.[JourneyParameters.ReturnDate],				--15
		bd.[JourneyParameters.ReturnTime],				--16
		bd.[JourneyParameters.ReturnArrDep]				--17
	FROM BatchRequestSummary bs
	INNER JOIN BatchRequestDetail bd
		ON bs.BatchId = bd.BatchId
	WHERE bd.BatchId = @BatchId
	AND bd.BatchDetailStatusId IS NULL -- Pending
	ORDER BY bd.RequestId ASC
	
	-- Update the status and submitted date
	UPDATE BatchRequestDetail
		SET BatchDetailStatusId = 1, -- Submitted
			SubmittedDateTime = @Date
	WHERE RequestId IN (SELECT TOP (@NumberRequests) RequestId
						FROM BatchRequestDetail bd
						WHERE bd.BatchId = @BatchId
						AND bd.BatchDetailStatusId IS NULL
						ORDER BY bd.RequestId ASC)
	
	RETURN 0
END
GO


-- Properties
USE PermanentPortal

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerUseProxy' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerUseProxy', 'false', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerProxyUrl' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerProxyUrl', 'http://proxy:8080', '<DEFAULT>', '<DEFAULT>', 0, 1)
END

-- =============================================
-- Batch event logging properties
-- =============================================
DECLARE @AID varchar(50) = 'BatchJourneyPlanner'
DECLARE @GID varchar(50) = 'UserPortal'

-- Email publisher
IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Custom' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Custom', 
	'EMAIL', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Custom.EMAIL.Name' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Custom.EMAIL.Name', 
	'CustomEmailPublisher', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Custom.EMAIL.Sender' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Custom.EMAIL.Sender', 
	'noreply@transportdirect.info', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Custom.EMAIL.SMTPServer' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Custom.EMAIL.SMTPServer', 
	'localhost', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Custom.EMAIL.WorkingDir' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Custom.EMAIL.WorkingDir', 
	'C:\\Temp', @AID, @GID, 0, 1)
END

-- CustomEmail events
IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EMAIL.Assembly' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EMAIL.Assembly', 
	'td.common.logging', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EMAIL.Name' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EMAIL.Name', 
	'CustomEmailEvent', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EMAIL.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EMAIL.Publishers', 
	'EMAIL', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EMAIL.Trace' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EMAIL.Trace', 
	'On', @AID, @GID, 0, 1)
END

-- Gazeteer events
IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Assembly' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.GAZ.Assembly', 
	'td.reportdataprovider.tdpcustomevents', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Name' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.GAZ.Name', 
	'GazetteerEvent', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.GAZ.Publishers', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Trace' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.GAZ.Trace', 
	'On', @AID, @GID, 0, 1)
END

-- Publishers
IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Default' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Default', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Console' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Console', 
	'', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Email' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Email', 
	'', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.EventLog' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.EventLog', 
	'EVENTLOG1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.File' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.File', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Queue' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Queue', 
	'QUEUE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.EventLog.EVENTLOG1.Name' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.EventLog.EVENTLOG1.Name', 
	'Application', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.EventLog.EVENTLOG1.Source' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.EventLog.EVENTLOG1.Source', 
	@AID, @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.EventLog.EVENTLOG1.Machine' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.EventLog.EVENTLOG1.Machine', 
	'.', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.File.FILE1.Directory' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.File.FILE1.Directory', 
	'C:\TDPortal', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.File.FILE1.Rotation' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.File.FILE1.Rotation', 
	'20000', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Queue.QUEUE1.Path' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Queue.QUEUE1.Path', 
	'.\Private$\TDPrimaryQueue', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Queue.QUEUE1.Delivery' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Queue.QUEUE1.Delivery', 
	'Recoverable', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Publisher.Queue.QUEUE1.Priority' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Publisher.Queue.QUEUE1.Priority', 
	'Normal', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Operational.TraceLevel' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Operational.TraceLevel', 
	'Warning', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Operational.Verbose.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Operational.Verbose.Publishers', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Operational.Info.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Operational.Info.Publishers', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Operational.Warning.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Operational.Warning.Publishers', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Operational.Error.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Operational.Error.Publishers', 
	'FILE1 EVENTLOG1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.Trace' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.Trace', 
	'On', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom', 
	'EnhancedExposedServiceStartEvent EnhancedExposedServiceFinishEvent GAZ EMAIL', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Assembly' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Assembly', 
	'td.reportdataprovider.tdpcustomevents', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Name' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Name', 
	'EnhancedExposedServiceFinishEvent', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Publishers', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Trace' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Trace', 
	'On', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceStartEvent.Assembly' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceStartEvent.Assembly', 
	'td.reportdataprovider.tdpcustomevents', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceStartEvent.Name' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceStartEvent.Name', 
	'EnhancedExposedServiceStartEvent', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceStartEvent.Publishers' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceStartEvent.Publishers', 
	'FILE1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceStartEvent.Trace' 
	AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('Logging.Event.Custom.EnhancedExposedServiceStartEvent.Trace', 
	'On', @AID, @GID, 0, 1)
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1874
SET @ScriptDesc = 'Batch Journey Processing Updates'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO