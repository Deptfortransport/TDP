-- ***********************************************
-- NAME          : DUP1864_BatchJourneyProcessing.sql
-- DESCRIPTION   : Script to add recaptcha flag and text correction
-- AUTHOR        : David Lane
-- DATE          : 10 February 2012
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Confirmation',
	'<p>&nbsp;</p>Thank you for applying to use the batch journey planner. We will be in touch soon.<p>&nbsp;</p><a href="/Web2/Home.aspx">Return to Transport Direct homepage</a>',
	'<p>&nbsp;</p>Thank you for applying to use the batch journey planner. We will be in touch soon.<p>&nbsp;</p><a href="/Web2/Home.aspx">Return to Transport Direct homepage</a>'


-- Properties
USE PermanentPortal

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerUseRecaptcha' 
	AND AID = '<DEFAULT>'
	AND GID = '<DEFAULT>'
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerUseRecaptcha', 'false', '<DEFAULT>', '<DEFAULT>', 0, 1)
END


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1864
SET @ScriptDesc = 'Batch Journey Processing Again'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO