-- ***********************************************
-- NAME           : DUP1854_CreateGetFuelRetailerSitesSP
-- DESCRIPTION    : Script to Add Fuel Genie CreateGetFuelRetailerSitesSP stored Proc
-- DATE           : 12/01/2012
-- ***********************************************

USE [TransientPortal]
GO
/****** Object:  StoredProcedure [dbo].[GetFuelRetailerSites]    Script Date: 12/20/2011 13:54:06 ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------
-- Create the stored procedures
-----------------------------------------------------------------------

Create PROCEDURE [dbo].[GetFuelRetailerSites]
(	
	@searchEasting  int, 
    @searchNorthing int,
    @searchType varchar,
    @searchFlag varchar,
    @searchRadius float
)
as
	
       
IF (@searchType = 'F' and @searchFlag = 'E')
    BEGIN
        SELECT TOP(5) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite = 'Y' 
        and A.Easting >= @searchEasting - (@searchRadius/0.000621371192)
        and A.Easting <= @searchEasting + (@searchRadius/0.000621371192)
        and A.Northing >= @searchNorthing -(@searchRadius/0.000621371192)
        and A.Northing <= @searchNorthing + (@searchRadius/0.000621371192)
        and NOT((A.Easting = @searchEasting) and (A.Northing = @searchNorthing))
        and ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) <= @searchRadius
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF(@searchType = 'F' and @searchFlag = 'I')
    BEGIN
        SELECT TOP(5) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite = 'Y' 
        and A.Easting >= @searchEasting - (@searchRadius/0.000621371192)
        and A.Easting <= @searchEasting + (@searchRadius/0.000621371192)
        and A.Northing >= @searchNorthing -(@searchRadius/0.000621371192)
        and A.Northing <= @searchNorthing + (@searchRadius/0.000621371192)
        and ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) <= @searchRadius
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF (@searchType = 'N' and @searchFlag = 'E')
    BEGIN
        SELECT TOP(5) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite = 'N' 
        and A.Easting >= @searchEasting - (@searchRadius/0.000621371192)
        and A.Easting <= @searchEasting + (@searchRadius/0.000621371192)
        and A.Northing >= @searchNorthing -(@searchRadius/0.000621371192)
        and A.Northing <= @searchNorthing + (@searchRadius/0.000621371192)
        and NOT((A.Easting = @searchEasting) and (A.Northing = @searchNorthing))
        and ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) <= @searchRadius
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))

    END
ELSE IF(@searchType = 'N' and @searchFlag = 'I')
    BEGIN
        SELECT TOP(5) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite = 'N' 
        and A.Easting >= @searchEasting - (@searchRadius/0.000621371192)
        and A.Easting <= @searchEasting + (@searchRadius/0.000621371192)
        and A.Northing >= @searchNorthing -(@searchRadius/0.000621371192)
        and A.Northing <= @searchNorthing + (@searchRadius/0.000621371192)
        and ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) <= @searchRadius
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF (@searchType = 'A' and @searchFlag = 'E')
    BEGIN
        SELECT TOP(5) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where A.Easting >= @searchEasting - (@searchRadius/0.000621371192)
        and A.Easting <= @searchEasting + (@searchRadius/0.000621371192)
        and A.Northing >= @searchNorthing -(@searchRadius/0.000621371192)
        and A.Northing <= @searchNorthing + (@searchRadius/0.000621371192)
        and NOT((A.Easting = @searchEasting) and (A.Northing = @searchNorthing))
        and ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) <= @searchRadius
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF(@searchType = 'A' and @searchFlag = 'I')
    BEGIN
        SELECT TOP(5) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where A.Easting >= @searchEasting - (@searchRadius/0.000621371192)
        and A.Easting <= @searchEasting + (@searchRadius/0.000621371192)
        and A.Northing >= @searchNorthing -(@searchRadius/0.000621371192)
        and A.Northing <= @searchNorthing + (@searchRadius/0.000621371192)
        and ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) <= @searchRadius
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END

   GO    
------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1854
SET @ScriptDesc = 'DUP1854_CreateGetFuelRetailerSitesSP'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
