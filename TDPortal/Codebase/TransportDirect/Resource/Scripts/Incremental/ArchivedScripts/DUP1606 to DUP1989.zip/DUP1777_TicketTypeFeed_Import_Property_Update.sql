-- ***********************************************
-- NAME 		: DUP1777_TicketTypeFeed_Import_Property_Update.sql
-- DESCRIPTION 		: Script to correct source property for TicketTypeFeed XML Import IF123
-- AUTHOR		: Rich Broddle
-- DATE			: 05/01/2011
-- ************************************************

USE [PermanentPortal]
GO

--------------------------------------------------------------------------
-- Source property for TicketTypeFeed XML Import IF123
--------------------------------------------------------------------------
UPDATE [PermanentPortal].[dbo].[properties]
   SET [pValue] = 'http://internal.nationalrail.co.uk/ticketTypeDescriptions.xml'
      ,[AID] = 'TicketTypeFeed'
      ,[GID] = 'TicketTypeFeed'
      ,[PartnerId] = 0
      ,[ThemeId] = 1
 WHERE [pName] = 'TicketTypeFeed.XMLFeedSource'
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)
DECLARE @VersionInfo VARCHAR(24)

SET @VersionInfo = '$Revision:   1.0  $'
SET @ScriptNumber = 1777
SET @ScriptDesc = 'Script to correct source property for TicketTypeFeed XML Import IF123'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc, VersionInfo = @VersionInfo
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary, VersionInfo)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc, @VersionInfo)
  END
GO