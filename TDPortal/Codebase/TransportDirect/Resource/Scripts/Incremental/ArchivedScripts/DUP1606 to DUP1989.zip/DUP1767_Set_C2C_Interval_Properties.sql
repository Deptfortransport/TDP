-- ***********************************************
-- NAME 		: DUP1767_Set_C2C_Interval_Properties.sql
-- DESCRIPTION 		: Script to upcate C2C interval properties
-- AUTHOR		: Mark Turner
-- DATE			: 23 Nov 10
-- ************************************************


USE [PermanentPortal]
GO

-------------------------------
-- Update for Web
-------------------------------
IF not exists 
	(
		select  * from properties 
		where pName = 'CityToCity.PublicJourney.Interval'
		and AID = 'Web'
		and GID = 'UserPortal'
	)
BEGIN
	insert into properties values ('CityToCity.PublicJourney.Interval', '24', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'CityToCity.PublicJourney.Interval'
	and AID = 'Web' 
	and GID = 'UserPortal' 
END

-------------------------------
-- Update for TDRemoting Host
-------------------------------
IF not exists 
	(
		select  * from properties 
		where pName = 'CityToCity.PublicJourney.Interval'
		and AID = 'TDRemotingHost'
		and GID = 'TDRemotingHost'
	)
BEGIN
	insert into properties values ('CityToCity.PublicJourney.Interval', '24', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'CityToCity.PublicJourney.Interval'
	and AID = 'TDRemotingHost' 
	and GID = 'TDRemotingHost' 
END

-------------------------------
-- Update for TDPlanner Host
-------------------------------
IF not exists 
	(
		select  * from properties 
		where pName = 'CityToCity.PublicJourney.Interval'
		and AID = 'TDPlannerHost'
		and GID = 'TDPlannerHost'
	)
BEGIN
	insert into properties values ('CityToCity.PublicJourney.Interval', '24', 'TDPlannerHost', 'TDPlannerHost', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'CityToCity.PublicJourney.Interval'
	and AID = 'TDPlannerHost' 
	and GID = 'TDPlannerHost' 
END



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1767
SET @ScriptDesc = 'Upcate C2C interval properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO