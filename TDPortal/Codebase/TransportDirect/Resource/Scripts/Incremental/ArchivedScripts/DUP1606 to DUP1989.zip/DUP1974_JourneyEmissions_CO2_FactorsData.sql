-- *************************************************************************************
-- NAME 		: DUP1974_JourneyEmissions_CO2_FactorsData.sql
-- DESCRIPTION 	: Journey emission factors update, added telecabine
-- AUTHOR		: Mitesh Modi
-- DATE			: 21 Jan 13
-- *************************************************************************************

USE [PermanentPortal]
GO

----------------------------------------------------------------
-- Update Emission Factors
----------------------------------------------------------------
DELETE FROM JourneyEmissionsFactor
GO

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('AirDefault', '1714')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('AirLarge', '1714')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('AirSmall', '1714')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('AirMedium', '1714')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('BusDefault', '1339')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('CoachDefault', '0300')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('FerryDefault', '1152')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('LightRailDefault', '0768')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('LightRailDL', '0792')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('LightRailCR', '0471')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('LightRailLU', '0741')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('LightRailMA', '0425')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('LightRailML', '0425')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('LightRailTW', '1261')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('RailDefault', '0534')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('TelecabineDefault', '0792')

INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('AirIntl', '0982')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('CoachIntl', '0400')
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('RailIntl', '0110')

-- Not sure why this is in this table, but should leave it in
INSERT INTO JourneyEmissionsFactor (FactorType, FactorValue) VALUES ('BusCoachDistance', '30000')


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1974
SET @ScriptDesc = 'Journey emission factors update, added telecabine'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO