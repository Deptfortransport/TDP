-- *************************************************************************************
-- NAME 		: DUP1723_TransferReferenceTransactionEvent_SP.sql
-- DESCRIPTION 		: Transfer Reference TransactionEvent SP
-- *************************************************************************************


USE [ReportStagingDB]
GO

/****** Object:  StoredProcedure [dbo].[TransferReferenceTransactionEvents]    Script Date: 06/24/2010 12:57:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TransferReferenceTransactionEvents]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[TransferReferenceTransactionEvents]
GO

USE [ReportStagingDB]
GO

/****** Object:  StoredProcedure [dbo].[TransferReferenceTransactionEvents]    Script Date: 06/24/2010 12:57:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ---------------------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[TransferReferenceTransactionEvents]
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

DELETE FROM ReportServer.Reporting.dbo.ReferenceTransactionEvents
WHERE CONVERT(varchar(10), RTEDate, 121) = @Date

INSERT INTO ReportServer.Reporting.dbo.ReferenceTransactionEvents
(
	RTEDate,
	RTEHour,
	RTEMinute,
	RTEWeekDay,
	RTERTTID,
	RTESuccessful,
	RTEOverran,
	RTEMsDuration,
	RTEMachineName
)
SELECT
	CAST(CONVERT(varchar(10), RTE.Submitted, 121) AS datetime) AS RTEDate,
	DATEPART(hour, RTE.Submitted) AS RTEHour,
	DATEPART(minute, RTE.Submitted) AS RTEMinute,
	DATEPART(weekday, RTE.Submitted) AS RTEWeekDay,
	RTT.RTTID AS RTERTTID,
	RTE.Successful AS RTESuccessful,
	CASE WHEN DATEDIFF(millisecond, RTE.Submitted, RTE.TimeLogged) <= RTT.RTTMaxMsDuration THEN 0 ELSE 1 END AS RTEOverran,
	DATEDIFF(millisecond, RTE.Submitted, RTE.TimeLogged) AS RTEMsDuration,
	RTE.MachineName AS RTEMAchineName
FROM ReferenceTransactionEvent RTE
LEFT OUTER JOIN ReportServer.Reporting.dbo.ReferenceTransactionType RTT ON RTE.EventType = RTT.RTTCode
WHERE CONVERT(varchar(10), RTE.Submitted, 121) = @Date

GO



-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)
SET @ScriptNumber = 1723

SET @ScriptDesc = 'Transfer Reference TransactionEvent SP'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-----------------------------------------