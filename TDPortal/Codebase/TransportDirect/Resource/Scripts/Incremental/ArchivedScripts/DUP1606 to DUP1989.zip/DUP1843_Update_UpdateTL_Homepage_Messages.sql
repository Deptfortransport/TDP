-- *************************************************************************************
-- NAME 		: DUP1843_Update_UpdateTL_Homepage_Messages.sql
-- DESCRIPTION  	: WAI - updating homepage messages only added during a previous DUP (1768)
-- AUTHOR		: David Lane
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [PermanentPortal]
GO

-------------------------------------------------------------------------------------
-- Update "SouthWest" message
-------------------------------------------------------------------------------------
UPDATE [PermanentPortal].[dbo].[HomePageMessage] 
SET valueEN = '<tr><td class="VertAlignTop"><img class="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt=" " border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br> We are working to fix this problem, which will be resolved shortly.</font><br/></td></tr>',
valueCY = '<tr><td class="VertAlignTop"><img class="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt=" " border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br> We are working to fix this problem, which will be resolved shortly.</font><br/></td></tr>'
WHERE Description = 'SouthWest'


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1843
SET @ScriptDesc = 'Update_UpdateTL_Homepage_Messages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO