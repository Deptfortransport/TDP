-- ***********************************************
-- NAME 		: DUP1902_CycleWalkLinks_Properties_2.sql
-- DESCRIPTION 	: Script to add properties for display
--				  and configuration of the CycleWalkLinks control
-- AUTHOR		: David Lane
-- DATE			: 04 Sep 2012
-- ************************************************


USE [PermanentPortal]
GO

DECLARE @AID varchar(50) = 'Web'
DECLARE @GID varchar(50) = 'UserPortal'

IF EXISTS(SELECT * FROM properties WHERE pName = 'CycleWalkLinks.WalkitControlBaseUrl' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
	UPDATE [properties] SET pValue = 'http://www.walkit.com/walkit_pipe.php?referid=k3ksj8kd49kjdfjsem8j3dl1o&' WHERE pName = 'CycleWalkLinks.WalkitControlBaseUrl' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1
ELSE
	INSERT INTO [properties] VALUES ('CycleWalkLinks.WalkitControlBaseUrl', 'http://www.walkit.com/walkit_pipe.php?referid=k3ksj8kd49kjdfjsem8j3dl1o&', @AID, @GID, 0, 1)

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1919
SET @ScriptDesc = 'Script to add properties for the CycleWalkLinks control'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO