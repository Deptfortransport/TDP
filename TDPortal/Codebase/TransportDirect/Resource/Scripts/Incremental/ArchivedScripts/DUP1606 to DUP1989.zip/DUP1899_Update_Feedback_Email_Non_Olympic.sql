-- ***********************************************
-- NAME 		: DUP1899_Update_Feedback_Email_Non_Olympic.sql
-- DESCRIPTION 	: Script to amend the feedback email.
-- AUTHOR		: David Lane
-- DATE			: 13 July 2012
-- ************************************************

USE [Content]
GO

EXEC AddtblContent 
1,1,'langstrings','FeedbackInitialPage.AcknowledgementComment','Dear sir/madam,

Thank you for providing feedback to Transport Direct.  We trust you will understand that we are unable to enter into detailed correspondence in response to your message.  However, every comment and suggestion we receive is taken forward for investigation and action as appropriate.  Please be aware that it can take some time to correct reported errors, especially since much of our data is supplied by third parties.  Nevertheless, all data errors are passed on to our suppliers and together we aim to resolve all of the issues you report.

Please see below for advice on some frequently received feedback topics.

Thanks for using Transport Direct and for taking the trouble to contact us.

Charlene Goodman
Feedback Manager
Transport Direct

--------------------------------------------------------------

RUNNING OF PUBLIC TRANSPORT SERVICES
Transport Direct is not responsible for the operation of public transport; therefore we are unable to help with issues relating to the operation of bus or rail services.  For matters such as this, including enquiries about lost property, or comments about the conduct of members of staff of a transport operator, you should contact the relevant transport operator directly.

TICKETS
If you require information about rail or coach tickets purchased using a link on Transport Direct, you should contact the relevant retail partner directly.

SUGGESTIONS
Suggestions on improvements to the usability and functionality of the system, and on extensions to the range of services offered, are always appreciated.  Although it may take time to see such suggestions implemented, your views form an important part of our future plans for the Transport Direct service.',
'Diolch ichi am roi adborth i Transport Direct. Gallwn eich sicrhau y bydd ymchwil a chamau priodol yn cael eu cymryd o ganlyniad i bob sylw ac awgrym a wneir.  Hyderwn y byddwch yn deall na allwn ohebu&''n fanwl &#212; chi wrth ymateb i&''ch neges.    Dylech fod yn ymwybodol y gall y broses o wneud newidiadau angenrheidiol i gywiro gwallau a riportiwyd gymryd cryn amser, yn arbennig pan fo data trydydd parti dan sylw (darparwyd llawer o&''n data gan drydydd part''on). Er hynny, anfonir yr holl wallau data ymlaen i&''n cyflenwyr a chyda&''n gilydd rydym yn amcanu i ddatrys yr holl faterion yr ydych yn eu riportio.    Nid yw Transport Direct yn gyfrifol am weithrediad cludiant cyhoeddus; felly yn anffodus ni allwn helpu &#212; materion sy&''n gysylltiedig &#212; gwasanaethau bysiau neu drenau. Yn achos materion o''r fath, gan gynnwys ymholiadau ynghylch eiddo coll, neu sylwadau am ymddygiad aelodau staff gweithredwr cludiant, dylech gysylltu''n uniongyrchol &#212;''r gweithredwr cludiant perthnasol.    Os oes arnoch angen gwybodaeth am docynnau tr&#219;n neu goets a brynwyd o un o''n cyfleusterau manwerthu cysylltiedig, dylech gysylltu''n uniongyrchol &#212;''r partner manwerthu perthnasol.    Mae awgrymiadau ar sut i wella defnyddioldeb ac ymarferoldeb y system, ac ar sut i ymestyn amrediad y gwasanaethau a gynigir, bob amser yn cael eu gwerthfawrogi. Er y gall gymryd amser i weld awgrymiadau o''r fath yn cael eu gweithredu, mae eich barn yn gyfrifol am ran bwysig o''n cynlluniau i''r dyfodol ar gyfer Porthol Transport Direct.    Unwaith eto diolch am fynd i drafferth i roi adborth inni. Mae''n ddrwg gennym na allwn ohebu &#212; chi drwy''r cyfeiriad e-bost hwn. Os bydd gennych sylwadau yn y dyfodol a fyddai''n bosibl ichi barhau i ddefnyddio''r system adborth ar y Porthol.    Yn gywir  Charlene Goodman  Rheolwr Adborth  Transport Direct'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1899
SET @ScriptDesc = 'Script to amend feedback email.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO