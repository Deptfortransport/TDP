-- ****************************************************************
-- NAME 		: DUP1903_AddCycleCalorieCounterDatabaseObjects.sql
-- DESCRIPTION 	: Creates table and stored procedure required to store & retrieve
--				  MET values for calculating calories burnt during cycle journeys.
-- AUTHOR		: Rich Broddle
-- DATE			: 20 Aug 2012
-- ****************************************************************

USE [TransientPortal]
GO

-----------------------------------------------
-- CycleMetValues Table
-----------------------------------------------

-- Drop Existing CycleMetValues Table

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CycleMetValues]') AND type in (N'U'))
BEGIN
	DROP TABLE [dbo].[CycleMetValues]
END
GO

-- Create CycleMetValues table
IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[CycleMetValues]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[CycleMetValues](
		[MetValue] decimal(9,3) NOT NULL,
		[MinSpeed] decimal(9,3) NOT NULL,
		[MaxSpeed] decimal(9,3) NOT NULL,
		[Description] varchar(200)
	)
END

GO

-----------------------------------------------
-- CycleMetValues Data
-----------------------------------------------

INSERT INTO [TransientPortal].[dbo].[CycleMetValues] ([MetValue],[MinSpeed],[MaxSpeed],[Description]) 
VALUES (	4,0,9.9,'code 01010 - bicycling, <10 mph, leisure, to work or for pleasure')
INSERT INTO [TransientPortal].[dbo].[CycleMetValues] ([MetValue],[MinSpeed],[MaxSpeed],[Description]) 
VALUES (6.8,10,11.9,'code 01020 - bicycling, 10-11.9 mph, slow, light effort')
INSERT INTO [TransientPortal].[dbo].[CycleMetValues] ([MetValue],[MinSpeed],[MaxSpeed],[Description]) 
VALUES (8,12,13.9,'code 01030 - bicycling, 12-13.9 mph,leisure, moderate effort')
INSERT INTO [TransientPortal].[dbo].[CycleMetValues] ([MetValue],[MinSpeed],[MaxSpeed],[Description]) 
VALUES (10,14,15.9,'code 01040 - bicycling, 14-15.9 mph, racing or leisure, fast, vigorous effort')
INSERT INTO [TransientPortal].[dbo].[CycleMetValues] ([MetValue],[MinSpeed],[MaxSpeed],[Description]) 
VALUES (12,16,20,'code 01050 - bicycling, 16-19 mph, racing/not drafting or >19 mph drafting, very fast, racing general')
INSERT INTO [TransientPortal].[dbo].[CycleMetValues] ([MetValue],[MinSpeed],[MaxSpeed],[Description]) 
VALUES (15.8,20.1,200,'code 01060 - bicycling, >20 mph, racing, not drafting')

GO

-----------------------------------------------
-- GetCycleMetValues Stored Procedure
-----------------------------------------------

IF NOT EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'TransientPortal' 
              AND ROUTINE_NAME = 'GetCycleMetValues' )
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetCycleMetValues] AS BEGIN SET NOCOUNT ON END')
	END
GO

ALTER PROCEDURE [dbo].[GetCycleMetValues]
AS
BEGIN
	SELECT	[MetValue],
		[MinSpeed],
		[MaxSpeed]
	FROM 	[CycleMetValues]
	ORDER BY [MetValue]

END
GO

-- Grant permissions - will only work for relevant users as only they
-- will exist
GRANT  EXECUTE  ON [dbo].[GetCycleMetValues]  TO [BBPTDPSIW\aspuser]
GRANT  EXECUTE  ON [dbo].[GetCycleMetValues]  TO [BBPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[GetCycleMetValues]  TO [ACPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[GetCycleMetValues]  TO [BBPTDPSIS\aspuser]
GRANT  EXECUTE  ON [dbo].[GetCycleMetValues]  TO [BBPTDPS\aspuser]
GRANT  EXECUTE  ON [dbo].[GetCycleMetValues]  TO [ACPTDPS\aspuser]
GO


----------------------------------------------------------------
-- Calorie counter properties
----------------------------------------------------------------

--on/off switch

USE [PermanentPortal]
GO

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.IncludeCalorieCount' AND AID = 'Web')
BEGIN
	insert into properties values ('CyclePlanner.IncludeCalorieCount','true',
				'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'true' 
		where pname = 'CyclePlanner.IncludeCalorieCount' AND AID = 'Web'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.IncludeCalorieCount' AND AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('CyclePlanner.IncludeCalorieCount','true',
				'TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'true' 
		where pname = 'CyclePlanner.IncludeCalorieCount' AND AID = 'TDRemotingHost'
END

GO

--default weight for calcs (grams)

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'Web')
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.CalorieCountDefaultWeight','64000',
				'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = '64000' 
		where pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'Web'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.CalorieCountDefaultWeight','64000',
				'TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = '64000' 
		where pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'TDRemotingHost'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1903
SET @ScriptDesc = 'Create table, stored procedure & properties for cycle calorie calculations'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO