-- ***********************************************
-- NAME 		: DUP1714_DropDownGaz_DataGateway_StoredProcedures.sql
-- DESCRIPTION 	: Script to add DropDownGaz Alias data import stored procedures
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Jun 2010
-- ************************************************

----------------------------------------
-- NOTE YOU WILL GET SOME ERRORS WHEN RUNNING THIS SCRIPT AS IT WILL ATTEMPT
-- TO GRANT PERMISSIONS TO THE STORED PROCEDURE TO ASPUSER AND -SERVICE-NSM USERS FOR ALL 
-- THREE PRODUCTION ENVIRONMENTS. THIS SHOULD NOT MATTER AS THE GRANTS SHOULD SUCCEED FOR
-- THE USERS APPROPRIATE TO THE ENVIRONMENT
----------------------------------------

USE [AtosAdditionalData]
GO

-------------------------------------------
-- Add ImportDropDownAliasData Stored Procedure
-------------------------------------------


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportDropDownAliasData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ImportDropDownAliasData]
GO

CREATE PROCEDURE dbo.ImportDropDownAliasData (@XML text) AS

	SET NOCOUNT OFF

	DECLARE @DocID int
	DECLARE @RetCode int
	DECLARE @XMLPathData varchar(50)

	DECLARE @LockStatus bit
	DECLARE @DropDownType varchar(10)
	
	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/dropdownalias/Alias'
	
	-- Start Import Transaction
	BEGIN TRANSACTION
	
		----------------------------------------------------
		-- Check if its OK to start import
		----------------------------------------------------
		SET @DropDownType = 'Rail'
		
		EXEC SetServerSynchStatusLock @DropDownType
		
		IF @@ERROR<>0
		BEGIN
			EXEC sp_xml_removedocument @DocID
			ROLLBACK TRANSACTION
			GOTO ERR_LOCK_HANDLER
		END
		
		----------------------------------------------------
		-- Clear Down Data Table
		----------------------------------------------------
	
		DELETE FROM [AtosAdditionalData].[dbo].[StopAlias]
				
		IF @@ERROR<>0
		BEGIN
			EXEC sp_xml_removedocument @DocID
			ROLLBACK TRANSACTION
			GOTO ERR_HANDLER
		END

		----------------------------------------------------
		-- Insert Into Data Tables
		----------------------------------------------------
	
		INSERT INTO [AtosAdditionalData].[dbo].[StopAlias] (
				StopNaptan, 
				StopType, 
				AliasName)
		SELECT DISTINCT 
				XmlDoc.StopNaPTAN, 
				XmlDoc.StopType, 
				XmlDoc.AliasName
		FROM OPENXML (@DocID, @XMLPathData, 2)
		WITH (
				StopNaPTAN Varchar(12), 
				StopType Varchar(3), 
				AliasName Varchar(100)) XmlDoc
		
		IF @@ERROR<>0
		BEGIN
			EXEC sp_xml_removedocument @DocID
			ROLLBACK TRANSACTION
			GOTO ERR_HANDLER
		END

		----------------------------------------------------
		-- Transfer data to the DropDownStop display table
		----------------------------------------------------

		-- 2 indicates this transfer is for Alias name stops (1 is for NPTG Naptans, 3 is for All)
		EXEC TransferDropDownDataRail 2 

		
		----------------------------------------------------
		-- Update Change Notification Version number
		----------------------------------------------------
		
		-- 1 indicates the change notification for Data should be triggered (2 is for Sync notification)
		EXEC UpdateChangeNotification 'Rail', 1
		
		
		IF @@ERROR<>0
		BEGIN
			EXEC sp_xml_removedocument @DocID
			ROLLBACK TRANSACTION
			GOTO ERR_HANDLER
		END
			

		EXEC sp_xml_removedocument @DocID
		
	
	COMMIT TRANSACTION
	RETURN 0
	
	

	ERR_LOCK_HANDLER:
		RAISERROR(
		'ImportDropDownAliasData - Import status row lock is engaged, unable to continue with data import.', 
		16, -- Severity
		1)   -- State


	ERR_HANDLER:
		RETURN 1



GO

GRANT EXECUTE ON [ImportDropDownAliasData] TO [NETWORK SERVICE]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [BBPTDPSIW\ASPUSER]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [BBPTDPW\ASPUSER]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [ACPTDPW\ASPUSER]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [BBPTDPSIS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [BBPTDPS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [ACPTDPS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [BBPTDPSIS\-service-nsm]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [BBPTDPS\-service-nsm]
GO
GRANT EXECUTE ON [ImportDropDownAliasData] TO [ACPTDPS\-service-nsm]
GO



-------------------------------------------
-- Add TransferDropDownDataRail Stored Procedure
-------------------------------------------

-- Create
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferDropDownDataRail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE TransferDropDownDataRail
			@DataLoadType int  -- 1 = Naptan, 2 = Alias, 3 = All
        AS

    ')
END

GO

-- Update
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE TransferDropDownDataRail
	@DataLoadType int  -- 1 = Naptan, 2 = Alias, 3 = All
AS
BEGIN
	DECLARE @DropDownType varchar(10)
	
	SET @DropDownType = 'Rail'
	
	-- Transfer all rail data
	IF @DataLoadType IN (1, 3)
	BEGIN
		-- Clear out existing rail data being used
		DELETE FROM DropDownStop WHERE IsAlias = 0 AND DropDownType = @DropDownType
	
		-- Add all stations (removing any " from start and end of the name)
		INSERT INTO DropDownStop
			 SELECT @DropDownType,
					SUBSTRING(LTRIM(RTRIM([Station Name])),2,LEN(LTRIM(RTRIM([Station Name])))-2), 
				    NULL,
					SUBSTRING(LTRIM(RTRIM(NaPTAN)),2,LEN(LTRIM(RTRIM([NaPTAN])))-2), 
					SUBSTRING(LTRIM(RTRIM([CRS CODE])),2,LEN(LTRIM(RTRIM([CRS CODE])))-2), 
					0, 
					0
			   FROM NPTG_RailExchanges
			   
		
		-- Add all group stations (removing any " from start and end of the name)
		INSERT INTO DropDownStop
			 SELECT @DropDownType, [Name], NULL, Naptans, NULL,1,0 
			   FROM (
			   
					SELECT  SUBSTRING(LTRIM(RTRIM([Name])),2,LEN(LTRIM(RTRIM([Name])))-2) as [Name], 
							Naptans = REPLACE( 
									( 
										SELECT SUBSTRING(LTRIM(RTRIM(NaPTAN)),2,LEN(LTRIM(RTRIM([NaPTAN])))-2) as [data()] 
										  FROM NPTG_RailExchanges rex
										 WHERE rex.[Group ID] = gr.[Group ID] 
									  ORDER BY [Group ID]
								  FOR XML PATH ('') 
									),  
							' ', ',') 
					  FROM  NPTG_ExchangeGroups gr
				INNER JOIN 
						    (SELECT [Group ID], 
								    COUNT(*) NaptanCount 
							   FROM NPTG_RailExchanges 
						   GROUP BY [Group ID]) cr 
						 
						ON cr.[Group ID] = gr.[Group ID] 
						
					 WHERE NaptanCount > 1) groupStations
					 
			  WHERE LEN(Naptans)>0

	END

	
	-- Transfer all alias data for rail
	IF @DataLoadType IN (2,3)
	BEGIN
		-- Clear out existing rail alias data being used
		DELETE FROM DropDownStop WHERE IsAlias = 1 AND DropDownType = @DropDownType
	
		-- Add all alias names (removing any " from start and end of the name)
		INSERT INTO DropDownStop
			 SELECT	@DropDownType,
					rex.StationName, 
					AliasName,
					rex.NaPTAN, 
					rex.CRSCode, 
					0, 
					1
			  FROM	StopAlias
		INNER JOIN
					(SELECT SUBSTRING(LTRIM(RTRIM([Station Name])),2,LEN(LTRIM(RTRIM([Station Name])))-2) as StationName,
							SUBSTRING(LTRIM(RTRIM([CRS Code])),2,LEN(LTRIM(RTRIM([CRS Code])))-2) as CRSCode,
							SUBSTRING(LTRIM(RTRIM(NaPTAN)),2,LEN(LTRIM(RTRIM([NaPTAN])))-2) as NaPTAN
					   FROM	NPTG_RailExchanges) rex 
				   
				ON StopAlias.StopNaptan = rex.NaPTAN
		
	END
	
END

GO


GRANT EXECUTE ON [TransferDropDownDataRail] TO [NETWORK SERVICE]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [BBPTDPSIW\ASPUSER]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [BBPTDPW\ASPUSER]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [ACPTDPW\ASPUSER]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [BBPTDPSIS\ASPUSER_S]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [BBPTDPS\ASPUSER_S]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [ACPTDPS\ASPUSER_S]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [BBPTDPSIS\-service-nsm]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [BBPTDPS\-service-nsm]
GO
GRANT EXECUTE ON [TransferDropDownDataRail] TO [ACPTDPS\-service-nsm]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1714
SET @ScriptDesc = 'Added DataGateway ImportDropDownAliasData stored procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO