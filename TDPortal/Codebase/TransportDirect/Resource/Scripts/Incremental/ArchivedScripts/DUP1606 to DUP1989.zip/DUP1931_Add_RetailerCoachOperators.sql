-- ***********************************************
-- NAME 		: DUP1931_Add_RetailerCoachOperators.sql
-- DESCRIPTION 	: Script to update retail coach operators
-- AUTHOR		: Mitesh Modi
-- DATE			: 30 Oct 12
-- ************************************************

USE [PermanentPortal]
GO

-------------------------------
-- Add to dbo.Retailers
-------------------------------

-- NEX should exist, we just want to add the new coach operator codes
IF NOT EXISTS (SELECT * FROM [dbo].[Retailers] WHERE RetailerID = 'NEX')
  BEGIN
    INSERT INTO [dbo].[Retailers] (RetailerId, Name, WebsiteURL, HandoffURL, PhoneNumber, DisplayURL, IconURL, AllowsMTH, SmallIconUrl)
    VALUES ('NEX', 'National Express', 'http://www.nationalexpress.com', 'http://www.nationalexpress.com/tdlive.cfm', '08705 80 80 80',
	 'www.nationalexpress.com', '/Web/images/gifs/SoftContent/NationalExpress.gif', 'N', '/Web/images/gifs/SoftContent/NationalExpress_small.gif')
  END
GO


-------------------------------
-- Add to dbo.RetailerLookup
-------------------------------

IF NOT EXISTS (SELECT * FROM [dbo].[RetailerLookup] 
					   WHERE RetailerID = 'NEX' AND Mode = 'Coach' AND OperatorCode = 'nrc-9')
  BEGIN
    INSERT INTO [dbo].[RetailerLookup] (OperatorCode, Mode, RetailerId, PartnerId, ThemeId)
    VALUES ('nrc-9','Coach','NEX',0,1)
  END
  
IF NOT EXISTS (SELECT * FROM [dbo].[RetailerLookup] 
					   WHERE RetailerID = 'NEX' AND Mode = 'Coach' AND OperatorCode = 'nrc-238')
  BEGIN
    INSERT INTO [dbo].[RetailerLookup] (OperatorCode, Mode, RetailerId, PartnerId, ThemeId)
    VALUES ('nrc-238','Coach','NEX',0,1)
  END

IF NOT EXISTS (SELECT * FROM [dbo].[RetailerLookup] 
					   WHERE RetailerID = 'NEX' AND Mode = 'Coach' AND OperatorCode = 'nrc-99028')
  BEGIN
    INSERT INTO [dbo].[RetailerLookup] (OperatorCode, Mode, RetailerId, PartnerId, ThemeId)
    VALUES ('nrc-99028','Coach','NEX',0,1)
  END

IF NOT EXISTS (SELECT * FROM [dbo].[RetailerLookup] 
					   WHERE RetailerID = 'NEX' AND Mode = 'Coach' AND OperatorCode = 'NXP')
  BEGIN
    INSERT INTO [dbo].[RetailerLookup] (OperatorCode, Mode, RetailerId, PartnerId, ThemeId)
    VALUES ('NXP','Coach','NEX',0,1)
  END
GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1931
SET @ScriptDesc = 'Update NationalExpress coach operators to list of online retailers'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO