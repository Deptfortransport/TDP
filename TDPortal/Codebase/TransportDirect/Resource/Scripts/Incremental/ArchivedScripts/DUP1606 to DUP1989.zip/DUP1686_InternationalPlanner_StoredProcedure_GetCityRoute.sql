-- ***********************************************
-- NAME 		: DUP1686_InternationalPlanner_StoredProcedure_GetCityRoute.sql
-- DESCRIPTION 	: Script to create a get city route stored procedures for the International planner database
-- AUTHOR		: Mitesh Modi
-- DATE			: 21 Apr 2010
-- ************************************************

USE [InternationalData]
GO

-------------------------------------------------------------
-- *********			   WARNING					  *******
-- Please ensure appropriate permissions are added to the stored procedures, all will 
-- need ASPUSER execute at a minimum.

-- This script adds the following stored procedures:
-- GetInternationalCityRoute

-------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalCityRoute stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalCityRoute]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalCityRoute
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalCityRoute stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalCityRoute] 
As
    SET NOCOUNT ON

	-- Script to return all the International City to City route combinatios
	
	SELECT IC1.CityId as DeparturetCityId,
		   IC2.CityId  as ArrivalCityId
	FROM CountryJourney CJ
	
	INNER JOIN InternationalCity IC1
	ON IC1.CityCountryCode = CJ.DepartureCountryCode
	
	INNER JOIN InternationalCity IC2
	ON IC2.CityCountryCode = CJ.ArrivalCountryCode
	
	ORDER by DeparturetCityId
	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1686
SET @ScriptDesc = 'Add InternationalData database GetInternationalCityRoute stored procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO