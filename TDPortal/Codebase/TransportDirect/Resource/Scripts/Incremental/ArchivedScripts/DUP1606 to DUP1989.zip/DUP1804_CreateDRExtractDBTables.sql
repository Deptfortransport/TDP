-- ***********************************************
-- NAME 		: DUP1804_CreateDRExtractDBTables.sql
-- DESCRIPTION 	: Script to create DB and tables for reporting disaster recovery
-- AUTHOR		: Phil Scott
-- DATE			: 23 Mar 2011
-- ************************************************


USE [master]
GO

/**########################vvv SI-TEST Environment vvv####################################### **/
/**CREATE DATABASE [DRExtractDB] ON  PRIMARY 
( NAME = N'DRExtractDB', FILENAME = N'H:\MSSQL10.MSSQLSERVER\MSSQL\DATA\DRExtractDB_Data.mdf' , SIZE = 2432KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'DRExtractDB_log', FILENAME = N'L:\MSSQL10.MSSQLSERVER\MSSQL\Logs\DRExtractDB_Log.LDF' , SIZE = 4504KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
**/
/**########################^^^ SI-TEST Environment ^^^####################################### **/



/**########################^^^ DR-TEST Environment ^^^####################################### **/
/****** 
CREATE DATABASE [DRExtractDB] ON  PRIMARY 
( NAME = N'DRExtractDB_New', FILENAME = N'H:\MSSQL10.MSSQLSERVER\MSSQL\DATA\DRExtractDB.mdf' , SIZE = 2432KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'DRExtractDB_New_log', FILENAME = N'L:\MSSQL10.MSSQLSERVER\MSSQL\Logs\DRExtractDB_log.LDF' , SIZE = 504KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
GO
*********/
/**########################^^^ DR-TEST Environment ^^^####################################### **/


/**########################vvv ACP LIVE Environment vvv####################################### **/
/**
CREATE DATABASE [DRExtractDB] ON  PRIMARY 
( NAME = N'DRExtractDB_New', FILENAME = N'H:\MSSQL10.MSSQLSERVER\MSSQL\DATA\DRExtractDB.mdf' , SIZE = 2432KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10% )
 LOG ON 
( NAME = N'DRExtractDB_New_log', FILENAME = N'L:\MSSQL10.MSSQLSERVER\MSSQL\Logs\DRExtractDB_Log.LDF' , SIZE = 504KB , MAXSIZE = 2048GB , FILEGROWTH = 10% ), 
GO
**/
/**########################^^^ ACP LIVE Environment ^^^####################################### **/



/**########################vvv DEV Environment vvv####################################### **/
CREATE DATABASE [DRExtractDB] ON  PRIMARY 
( NAME = N'RDRExtractDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\DRExtractDB.mdf' , SIZE = 2432KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'DRExtractDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\DRExtractDB_log.LDF' , SIZE = 504KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
GO
/**########################^^^ DEV Environment ^^^####################################### **/




ALTER DATABASE [DRExtractDB] SET COMPATIBILITY_LEVEL = 80
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [DRExtractDB].[dbo].[sp_fulltext_database] @action = 'disable'
end
GO

ALTER DATABASE [DRExtractDB] SET ANSI_NULL_DEFAULT ON 
GO

ALTER DATABASE [DRExtractDB] SET ANSI_NULLS ON 
GO

ALTER DATABASE [DRExtractDB] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [DRExtractDB] SET ANSI_WARNINGS ON 
GO

ALTER DATABASE [DRExtractDB] SET ARITHABORT OFF 
GO

ALTER DATABASE [DRExtractDB] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [DRExtractDB] SET AUTO_CREATE_STATISTICS ON 
GO

ALTER DATABASE [DRExtractDB] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [DRExtractDB] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [DRExtractDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [DRExtractDB] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [DRExtractDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [DRExtractDB] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [DRExtractDB] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [DRExtractDB] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [DRExtractDB] SET  DISABLE_BROKER 
GO

ALTER DATABASE [DRExtractDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [DRExtractDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [DRExtractDB] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [DRExtractDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [DRExtractDB] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [DRExtractDB] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [DRExtractDB] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [DRExtractDB] SET  READ_WRITE 
GO

ALTER DATABASE [DRExtractDB] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [DRExtractDB] SET  MULTI_USER 
GO

ALTER DATABASE [DRExtractDB] SET PAGE_VERIFY TORN_PAGE_DETECTION  
GO

ALTER DATABASE [DRExtractDB] SET DB_CHAINING OFF 
GO






USE [DRExtractDB]
GO

/*1************************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[CyclePlannerRequestEvent]    Script Date: 05/20/2011 11:27:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CyclePlannerRequestEvent]') AND type in (N'U'))
DROP TABLE [dbo].[CyclePlannerRequestEvent]
GO

/****** Object:  Table [dbo].[CyclePlannerRequestEvent]    Script Date: 05/20/2011 11:27:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CyclePlannerRequestEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CyclePlannerRequestId] [varchar](50) NULL,
	[Cycle] [bit] NULL,
	[SessionId] [varchar](50) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO


/*2************************************************************************************************************************************/
/************************************************************************************************************************************/

/****** Object:  Table [dbo].[CyclePlannerResultEvent]    Script Date: 05/20/2011 11:31:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CyclePlannerResultEvent]') AND type in (N'U'))
DROP TABLE [dbo].[CyclePlannerResultEvent]
GO

/****** Object:  Table [dbo].[CyclePlannerResultEvent]    Script Date: 05/20/2011 11:31:05 ******/

CREATE TABLE [dbo].[CyclePlannerResultEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CyclePlannerRequestId] [varchar](50) NULL,
	[ResponseCategory] [varchar](50) NULL,
	[SessionId] [varchar](50) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO


/*3************************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[DataGatewayEvent]    Script Date: 05/20/2011 11:33:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DataGatewayEvent]') AND type in (N'U'))
DROP TABLE [dbo].[DataGatewayEvent]
GO

/****** Object:  Table [dbo].[DataGatewayEvent]    Script Date: 05/20/2011 11:33:20 ******/

CREATE TABLE [dbo].[DataGatewayEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FeedId] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[FileName] [varchar](100) NULL,
	[TimeStarted] [datetime] NULL,
	[TimeFinished] [datetime] NULL,
	[SuccessFlag] [bit] NULL,
	[ErrorCode] [int] NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*4************************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[EBCCalculationEvent]    Script Date: 05/20/2011 11:33:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EBCCalculationEvent]') AND type in (N'U'))
DROP TABLE [dbo].[EBCCalculationEvent]
GO

/****** Object:  Table [dbo].[EBCCalculationEvent]    Script Date: 05/20/2011 11:33:58 ******/
CREATE TABLE [dbo].[EBCCalculationEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Submitted] [datetime] NULL,
	[SessionId] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL,
	[Success] [bit] NULL
) ON [PRIMARY]

GO


IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF__EnhancedE__TimeL__7A672E12]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[EnhancedExposedServiceEvent] DROP CONSTRAINT [DF__EnhancedE__TimeL__7A672E12]
END

GO


/*5************************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[EnhancedExposedServiceEvent]    Script Date: 05/20/2011 11:35:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EnhancedExposedServiceEvent]') AND type in (N'U'))
DROP TABLE [dbo].[EnhancedExposedServiceEvent]
GO

/****** Object:  Table [dbo].[EnhancedExposedServiceEvent]    Script Date: 05/20/2011 11:35:06 ******/
CREATE TABLE [dbo].[EnhancedExposedServiceEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EESEPartnerId] [smallint] NOT NULL,
	[EESEInternalTransactionId] [varchar](40) NOT NULL,
	[EESEExternalTransactionId] [varchar](100) NOT NULL,
	[EESEServiceType] [varchar](200) NOT NULL,
	[EESEOperationType] [varchar](100) NOT NULL,
	[EESEEventTime] [datetime] NOT NULL,
	[EESEIsStartEvent] [bit] NOT NULL,
	[EESECallSuccessful] [bit] NOT NULL,
	[TimeLogged] [datetime] NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[EnhancedExposedServiceEvent] ADD  DEFAULT (getdate()) FOR [TimeLogged]
GO

/*6************************************************************************************************************************************/
/************************************************************************************************************************************/

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ExposedServicesEvent_Successful]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[ExposedServicesEvent] DROP CONSTRAINT [DF_ExposedServicesEvent_Successful]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ExposedServicesEvent_TimeLogged]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[ExposedServicesEvent] DROP CONSTRAINT [DF_ExposedServicesEvent_TimeLogged]
END

GO
/****** Object:  Table [dbo].[ExposedServicesEvent]    Script Date: 05/20/2011 11:36:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExposedServicesEvent]') AND type in (N'U'))
DROP TABLE [dbo].[ExposedServicesEvent]
GO


/*7************************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[ExposedServicesEvent]    Script Date: 05/20/2011 11:36:01 ******/
CREATE TABLE [dbo].[ExposedServicesEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Submitted] [datetime] NULL,
	[Token] [varchar](50) NULL,
	[Category] [varchar](50) NULL,
	[Successful] [bit] NOT NULL,
	[TimeLogged] [datetime] NOT NULL
) ON [PRIMARY]

GO


ALTER TABLE [dbo].[ExposedServicesEvent] ADD  CONSTRAINT [DF_ExposedServicesEvent_Successful]  DEFAULT ((0)) FOR [Successful]
GO

ALTER TABLE [dbo].[ExposedServicesEvent] ADD  CONSTRAINT [DF_ExposedServicesEvent_TimeLogged]  DEFAULT (getdate()) FOR [TimeLogged]
GO

/*8************************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[GazetteerEvent]    Script Date: 05/20/2011 11:36:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GazetteerEvent]') AND type in (N'U'))
DROP TABLE [dbo].[GazetteerEvent]
GO


/****** Object:  Table [dbo].[GazetteerEvent]    Script Date: 05/20/2011 11:36:38 ******/
CREATE TABLE [dbo].[GazetteerEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EventCategory] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL,
	[Submitted] [datetime] NULL
) ON [PRIMARY]

GO

/*9**********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[GradientProfileEvent]    Script Date: 05/20/2011 11:37:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GradientProfileEvent]') AND type in (N'U'))
DROP TABLE [dbo].[GradientProfileEvent]
GO

/****** Object:  Table [dbo].[GradientProfileEvent]    Script Date: 05/20/2011 11:37:45 ******/
CREATE TABLE [dbo].[GradientProfileEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[DisplayCategory] [varchar](50) NULL,
	[Submitted] [datetime] NULL,
	[SessionId] [varchar](50) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*10***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[InternalRequestEvent]    Script Date: 05/20/2011 11:39:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InternalRequestEvent]') AND type in (N'U'))
DROP TABLE [dbo].[InternalRequestEvent]
GO

/****** Object:  Table [dbo].[InternalRequestEvent]    Script Date: 05/20/2011 11:39:23 ******/
CREATE TABLE [dbo].[InternalRequestEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[InternalRequestId] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[Submitted] [datetime] NULL,
	[InternalRequestType] [varchar](50) NULL,
	[Success] [bit] NULL,
	[RefTransaction] [bit] NULL,
	[TimeLogged] [datetime] NULL,
	[FunctionType] [char](2) NOT NULL
) ON [PRIMARY]

GO

/*11***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[InternationalPlannerEvent]    Script Date: 05/20/2011 11:40:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InternationalPlannerEvent]') AND type in (N'U'))
DROP TABLE [dbo].[InternationalPlannerEvent]
GO

/****** Object:  Table [dbo].[InternationalPlannerEvent]    Script Date: 05/20/2011 11:40:53 ******/
CREATE TABLE [dbo].[InternationalPlannerEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[InternationalPlannerType] [varchar](50) NULL,
	[SessionId] [varchar](50) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO


/*12***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[InternationalPlannerRequestEvent]    Script Date: 05/20/2011 11:41:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InternationalPlannerRequestEvent]') AND type in (N'U'))
DROP TABLE [dbo].[InternationalPlannerRequestEvent]
GO

/****** Object:  Table [dbo].[InternationalPlannerRequestEvent]    Script Date: 05/20/2011 11:41:53 ******/
CREATE TABLE [dbo].[InternationalPlannerRequestEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[InternationalPlannerRequestId] [varchar](50) NULL,
	[SessionId] [varchar](50) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*13***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[InternationalPlannerResultEvent]    Script Date: 05/20/2011 11:42:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InternationalPlannerResultEvent]') AND type in (N'U'))
DROP TABLE [dbo].[InternationalPlannerResultEvent]
GO
/****** Object:  Table [dbo].[InternationalPlannerResultEvent]    Script Date: 05/20/2011 11:42:15 ******/
CREATE TABLE [dbo].[InternationalPlannerResultEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[InternationalPlannerRequestId] [varchar](50) NULL,
	[ResponseCategory] [varchar](50) NULL,
	[SessionId] [varchar](50) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*14***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[JourneyPlanRequestEvent]    Script Date: 05/20/2011 11:46:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JourneyPlanRequestEvent]') AND type in (N'U'))
DROP TABLE [dbo].[JourneyPlanRequestEvent]
GO

/****** Object:  Table [dbo].[JourneyPlanRequestEvent]    Script Date: 05/20/2011 11:46:05 ******/
CREATE TABLE [dbo].[JourneyPlanRequestEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JourneyPlanRequestId] [varchar](50) NULL,
	[Air] [bit] NULL,
	[Bus] [bit] NULL,
	[Car] [bit] NULL,
	[Coach] [bit] NULL,
	[Cycle] [bit] NULL,
	[Drt] [bit] NULL,
	[Ferry] [bit] NULL,
	[Metro] [bit] NULL,
	[Rail] [bit] NULL,
	[Taxi] [bit] NULL,
	[Tram] [bit] NULL,
	[Underground] [bit] NULL,
	[Walk] [bit] NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*15***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[JourneyPlanRequestVerboseEvent]    Script Date: 05/20/2011 11:46:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JourneyPlanRequestVerboseEvent]') AND type in (N'U'))
DROP TABLE [dbo].[JourneyPlanRequestVerboseEvent]
/****** Object:  Table [dbo].[JourneyPlanRequestVerboseEvent]    Script Date: 05/20/2011 11:46:34 ******/
CREATE TABLE [dbo].[JourneyPlanRequestVerboseEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JourneyPlanRequestId] [varchar](50) NULL,
	[JourneyRequestData] [text] NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/*16***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[JourneyPlanResultsEvent]    Script Date: 05/20/2011 11:47:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JourneyPlanResultsEvent]') AND type in (N'U'))
DROP TABLE [dbo].[JourneyPlanResultsEvent]
GO
/****** Object:  Table [dbo].[JourneyPlanResultsEvent]    Script Date: 05/20/2011 11:47:15 ******/
CREATE TABLE [dbo].[JourneyPlanResultsEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JourneyPlanRequestId] [varchar](50) NULL,
	[ResponseCategory] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*17***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[JourneyPlanResultsVerboseEvent]    Script Date: 05/20/2011 11:47:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JourneyPlanResultsVerboseEvent]') AND type in (N'U'))
DROP TABLE [dbo].[JourneyPlanResultsVerboseEvent]
GO
/****** Object:  Table [dbo].[JourneyPlanResultsVerboseEvent]    Script Date: 05/20/2011 11:47:38 ******/
CREATE TABLE [dbo].[JourneyPlanResultsVerboseEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JourneyPlanRequestId] [varchar](50) NULL,
	[JourneyResultsData] [text] NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/*18***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[JourneyWebRequestEvent]    Script Date: 05/20/2011 11:48:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JourneyWebRequestEvent]') AND type in (N'U'))
DROP TABLE [dbo].[JourneyWebRequestEvent]
GO
/****** Object:  Table [dbo].[JourneyWebRequestEvent]    Script Date: 05/20/2011 11:48:39 ******/
CREATE TABLE [dbo].[JourneyWebRequestEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JourneyWebRequestId] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[Submitted] [datetime] NULL,
	[RegionCode] [varchar](50) NULL,
	[Success] [bit] NULL,
	[RefTransaction] [bit] NULL,
	[TimeLogged] [datetime] NULL,
	[RequestType] [varchar](50) NOT NULL
) ON [PRIMARY]

GO

/*19***********************************************************************************************************************************/
/****** Object:  Table [dbo].[LandingPageEvent]    Script Date: 05/20/2011 11:49:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LandingPageEvent]') AND type in (N'U'))
DROP TABLE [dbo].[LandingPageEvent]
GO

/****** Object:  Table [dbo].[LandingPageEvent]    Script Date: 05/20/2011 11:49:39 ******/
CREATE TABLE [dbo].[LandingPageEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[LPPCode] [varchar](50) NOT NULL,
	[LPSCode] [varchar](50) NOT NULL,
	[TimeLogged] [datetime] NOT NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL
) ON [PRIMARY]

GO

/*20***********************************************************************************************************************************/
/****** Object:  Table [dbo].[LocationRequestEvent]    Script Date: 05/20/2011 11:50:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LocationRequestEvent]') AND type in (N'U'))
DROP TABLE [dbo].[LocationRequestEvent]
GO

/****** Object:  Table [dbo].[LocationRequestEvent]    Script Date: 05/20/2011 11:50:05 ******/
CREATE TABLE [dbo].[LocationRequestEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JourneyPlanRequestId] [varchar](50) NULL,
	[PrepositionCategory] [varchar](50) NULL,
	[AdminAreaCode] [varchar](50) NULL,
	[RegionCode] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/************************************************************************************************************************************/
/*21***********************************************************************************************************************************/
/****** Object:  Table [dbo].[RetailerHandoffEvent]    Script Date: 05/20/2011 11:57:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RetailerHandoffEvent]') AND type in (N'U'))
DROP TABLE [dbo].[RetailerHandoffEvent]
GO

/****** Object:  Table [dbo].[RetailerHandoffEvent]    Script Date: 05/20/2011 11:57:58 ******/
CREATE TABLE [dbo].[RetailerHandoffEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[RetailerId] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*22***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[ReferenceTransactionEvent]    Script Date: 05/20/2011 11:55:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReferenceTransactionEvent]') AND type in (N'U'))
DROP TABLE [dbo].[ReferenceTransactionEvent]
GO

/****** Object:  Table [dbo].[ReferenceTransactionEvent]    Script Date: 05/20/2011 11:55:52 ******/
CREATE TABLE [dbo].[ReferenceTransactionEvent](
	[Submitted] [datetime] NOT NULL,
	[EventType] [varchar](50) NOT NULL,
	[ServiceLevelAgreement] [bit] NULL,
	[SessionId] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL,
	[Successful] [bit] NULL,
	[MachineName] [varchar](50) NULL,
 CONSTRAINT [PK_ReferenceTransactionEvent] PRIMARY KEY NONCLUSTERED 
(
	[Submitted] ASC,
	[EventType] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/*23***********************************************************************************************************************************/
/************************************************************************************************************************************/

/****** Object:  Table [dbo].[UserFeedbackEvent]    Script Date: 05/20/2011 12:53:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserFeedbackEvent]') AND type in (N'U'))
DROP TABLE [dbo].[UserFeedbackEvent]
GO
/****** Object:  Table [dbo].[UserFeedbackEvent]    Script Date: 05/20/2011 12:53:39 ******/
CREATE TABLE [dbo].[UserFeedbackEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SessionId] [nvarchar](88) NULL,
	[SubmittedTime] [datetime] NULL,
	[FeedbackType] [varchar](50) NULL,
	[AcknowledgedTime] [datetime] NULL,
	[AcknowledgmentSent] [bit] NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL,
 CONSTRAINT [PK_UserFeedbackEvent] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/************************************************************************************************************************************/
/*24***********************************************************************************************************************************/
/****** Object:  Table [dbo].[OperationalEvent]    Script Date: 05/20/2011 11:53:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OperationalEvent]') AND type in (N'U'))
DROP TABLE [dbo].[OperationalEvent]
GO

/****** Object:  Table [dbo].[OperationalEvent]    Script Date: 05/20/2011 11:53:00 ******/
CREATE TABLE [dbo].[OperationalEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SessionId] [nvarchar](88) NULL,
	[Message] [varchar](1500) NULL,
	[MachineName] [varchar](50) NULL,
	[AssemblyName] [varchar](50) NULL,
	[MethodName] [varchar](50) NULL,
	[TypeName] [varchar](50) NULL,
	[Level] [varchar](50) NULL,
	[Category] [varchar](50) NULL,
	[Target] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*25***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[MapAPIEvent]    Script Date: 05/20/2011 11:51:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MapAPIEvent]') AND type in (N'U'))
DROP TABLE [dbo].[MapAPIEvent]
GO
/****** Object:  Table [dbo].[MapAPIEvent]    Script Date: 05/20/2011 11:51:33 ******/
CREATE TABLE [dbo].[MapAPIEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CommandCategory] [varchar](50) NULL,
	[Submitted] [datetime] NULL,
	[SessionId] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*26***********************************************************************************************************************************/
/************************************************************************************************************************************/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WorkloadEvent]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[WorkloadEvent] DROP CONSTRAINT [DF_WorkloadEvent]
END

GO
/****** Object:  Table [dbo].[WorkloadEvent]    Script Date: 05/20/2011 12:54:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WorkloadEvent]') AND type in (N'U'))
DROP TABLE [dbo].[WorkloadEvent]
GO

/****** Object:  Table [dbo].[WorkloadEvent]    Script Date: 05/20/2011 12:54:41 ******/
CREATE TABLE [dbo].[WorkloadEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Requested] [datetime] NULL,
	[TimeLogged] [datetime] NULL,
	[NumberRequested] [int] NOT NULL,
	[PartnerId] [int] NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[WorkloadEvent] ADD  CONSTRAINT [DF_WorkloadEvent]  DEFAULT ((0)) FOR [PartnerId]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_RTTIInternalEvent_TimeLogged]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[RTTIInternalEvent] DROP CONSTRAINT [DF_RTTIInternalEvent_TimeLogged]
END

GO

/*27***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[RTTIInternalEvent]    Script Date: 05/20/2011 11:58:48 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RTTIInternalEvent]') AND type in (N'U'))
DROP TABLE [dbo].[RTTIInternalEvent]
GO

/****** Object:  Table [dbo].[RTTIInternalEvent]    Script Date: 05/20/2011 11:58:48 ******/
CREATE TABLE [dbo].[RTTIInternalEvent](
	[InternalEventID] [int] IDENTITY(1,1) NOT NULL,
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NOT NULL,
	[NumberOfRetries] [int] NOT NULL,
	[Successful] [bit] NOT NULL,
	[TimeLogged] [datetime] NOT NULL,
 CONSTRAINT [PK_RTTIInternalEvent] PRIMARY KEY CLUSTERED 
(
	[InternalEventID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[RTTIInternalEvent] ADD  CONSTRAINT [DF_RTTIInternalEvent_TimeLogged]  DEFAULT (getdate()) FOR [TimeLogged]
GO

/*28***********************************************************************************************************************************/
/************************************************************************************************************************************/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF__PageEntry__Theme__7D439ABD]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[PageEntryEvent] DROP CONSTRAINT [DF__PageEntry__Theme__7D439ABD]
END

GO

/****** Object:  Table [dbo].[PageEntryEvent]    Script Date: 05/20/2011 11:54:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PageEntryEvent]') AND type in (N'U'))
DROP TABLE [dbo].[PageEntryEvent]
GO

/****** Object:  Table [dbo].[PageEntryEvent]    Script Date: 05/20/2011 11:54:32 ******/
CREATE TABLE [dbo].[PageEntryEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Page] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL,
	[ThemeID] [int] NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[PageEntryEvent] ADD  DEFAULT ((0)) FOR [ThemeID]
GO

/*29***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[LoginEvent]    Script Date: 05/20/2011 11:50:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LoginEvent]') AND type in (N'U'))
DROP TABLE [dbo].[LoginEvent]
GO

/****** Object:  Table [dbo].[LoginEvent]    Script Date: 05/20/2011 11:50:54 ******/
CREATE TABLE [dbo].[LoginEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*30***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[RepeatVisitorEvent]    Script Date: 05/20/2011 11:56:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepeatVisitorEvent]') AND type in (N'U'))
DROP TABLE [dbo].[RepeatVisitorEvent]
GO


/****** Object:  Table [dbo].[RepeatVisitorEvent]    Script Date: 05/20/2011 11:56:26 ******/
CREATE TABLE [dbo].[RepeatVisitorEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[RepeatVistorType] [varchar](20) NULL,
	[LastVisited] [datetime] NULL,
	[SessionIdOld] [varchar](50) NULL,
	[SessionIdNew] [varchar](50) NULL,
	[DomainName] [varchar](100) NULL,
	[UserAgent] [varchar](200) NULL,
	[ThemeId] [int] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*31***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[MapEvent]    Script Date: 05/20/2011 11:52:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MapEvent]') AND type in (N'U'))
DROP TABLE [dbo].[MapEvent]
GO
/****** Object:  Table [dbo].[MapEvent]    Script Date: 05/20/2011 11:52:21 ******/
CREATE TABLE [dbo].[MapEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CommandCategory] [varchar](50) NULL,
	[Submitted] [datetime] NULL,
	[DisplayCategory] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO

/*32***********************************************************************************************************************************/
/************************************************************************************************************************************/
/****** Object:  Table [dbo].[UserPreferenceSaveEvent]    Script Date: 05/20/2011 12:54:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserPreferenceSaveEvent]') AND type in (N'U'))
DROP TABLE [dbo].[UserPreferenceSaveEvent]
GO

/****** Object:  Table [dbo].[UserPreferenceSaveEvent]    Script Date: 05/20/2011 12:54:08 ******/
CREATE TABLE [dbo].[UserPreferenceSaveEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EventCategory] [varchar](50) NULL,
	[SessionId] [nvarchar](88) NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO


/*33***********************************************************************************************************************************/
/************************************************************************************************************************************/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_StopEventRequestEvent_Successful]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StopEventRequestEvent] DROP CONSTRAINT [DF_StopEventRequestEvent_Successful]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_StopEventRequestEvent_TimeLogged]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[StopEventRequestEvent] DROP CONSTRAINT [DF_StopEventRequestEvent_TimeLogged]
END

GO


/****** Object:  Table [dbo].[StopEventRequestEvent]    Script Date: 05/20/2011 11:59:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StopEventRequestEvent]') AND type in (N'U'))
DROP TABLE [dbo].[StopEventRequestEvent]
GO

/****** Object:  Table [dbo].[StopEventRequestEvent]    Script Date: 05/20/2011 11:59:28 ******/
CREATE TABLE [dbo].[StopEventRequestEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Submitted] [datetime] NULL,
	[RequestId] [varchar](50) NULL,
	[RequestType] [varchar](50) NULL,
	[Successful] [bit] NOT NULL,
	[TimeLogged] [datetime] NOT NULL
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[StopEventRequestEvent] ADD  CONSTRAINT [DF_StopEventRequestEvent_Successful]  DEFAULT ((0)) FOR [Successful]
GO

ALTER TABLE [dbo].[StopEventRequestEvent] ADD  CONSTRAINT [DF_StopEventRequestEvent_TimeLogged]  DEFAULT (getdate()) FOR [TimeLogged]
GO

/*34***********************************************************************************************************************************/
/************************************************************************************************************************************/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_RTTIEvent_DataRecievedSucessfully]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[RTTIEvent] DROP CONSTRAINT [DF_RTTIEvent_DataRecievedSucessfully]
END

GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_RTTIEvent_TimeLogged]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[RTTIEvent] DROP CONSTRAINT [DF_RTTIEvent_TimeLogged]
END

GO

/****** Object:  Table [dbo].[RTTIEvent]    Script Date: 05/20/2011 11:58:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RTTIEvent]') AND type in (N'U'))
DROP TABLE [dbo].[RTTIEvent]
GO
/****** Object:  Table [dbo].[RTTIEvent]    Script Date: 05/20/2011 11:58:22 ******/
CREATE TABLE [dbo].[RTTIEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StartTime] [datetime] NULL,
	[FinishTime] [datetime] NULL,
	[DataRecievedSucessfully] [bit] NOT NULL,
	[TimeLogged] [datetime] NOT NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[RTTIEvent] ADD  CONSTRAINT [DF_RTTIEvent_DataRecievedSucessfully]  DEFAULT ((0)) FOR [DataRecievedSucessfully]
GO

ALTER TABLE [dbo].[RTTIEvent] ADD  CONSTRAINT [DF_RTTIEvent_TimeLogged]  DEFAULT (getdate()) FOR [TimeLogged]
GO
/************************************************************************************************************************************/



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1804
SET @ScriptDesc = 'DUP1804_CreateDRExtractDBTables.sql  Script to create DB and tables for reporting disaster recovery'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO