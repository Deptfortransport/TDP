-- ***********************************************
-- NAME 		: DUP1963_AccessibleOperator_DataImport_Properties.sql
-- DESCRIPTION 	: Script to update data import properties for Accessible operator
-- AUTHOR		: Mitesh Modi
-- DATE			: 06 Dec 2012
-- ************************************************


-- ****************** IMPORTANT **************************
-- Please change the @gatewayPath value path to be as required for 
-- the environment
-- *******************************************************

USE [PermanentPortal]
GO

DECLARE @gatewayPath varchar(30) = 'C:\Gateway\xml'

-- Clear all existing properties
DELETE FROM [dbo].[properties]
WHERE  pName LIKE 'datagateway.sqlimport.AccessibleOperatorData%'

-- AID and GID
DECLARE @AID varchar(50) = ''
DECLARE @GID varchar(50) = 'DataGateway'

-- Accessible Operator Data
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.database', @AID, @GID, 0, 1, N'TransientPortalDB')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.feedname', @AID, @GID, 0, 1, N'wsa980')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.Name', @AID, @GID, 0, 1, N'AccessibleOperatorData')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.schemea', @AID, @GID, 0, 1, @gatewayPath + N'\AccessibleOperators.xsd')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.sqlcommandtimeout', @AID, @GID, 0, 1, N'3000')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.storedprocedure', @AID, @GID, 0, 1, N'ImportAccessibleOperatorData')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.xmlnamespace', @AID, @GID, 0, 1, N'http://www.transportdirect.info/AccessibleOperators')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleOperatorData.xmlnamespacexsi', @AID, @GID, 0, 1, N'http://www.w3.org/2001/XMLSchema-instance')

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1963
SET @ScriptDesc = 'Script to update data import properties for Accessible operator'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO