-- ***********************************************
-- NAME 		: DUP1735_UpdateAirInterchangeOverlay.sql
-- DESCRIPTION 		: Script to add an airport to the AirInterchangeOverlay Table
-- AUTHOR		: Mark Turner
-- DATE			: 23 July 2010
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from AirInterchangeOverlays where ID = 14)
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[AirInterchangeOverlays]
           ([ID],[TotalTime],[FromName],[FromNodeID],[FromNodeTypeID]
           ,[FromGridType],[FromEasting],[FromNorthing],[FromBay]
           ,[FromOperatorCode],[FromOperatorName],[ToName]
           ,[ToNodeID],[ToNodeTypeID],[ToGridType],[ToEasting]
           ,[ToNorthing],[ToBay],[ToOperatorCode],[ToOperatorName])
     VALUES
           (14,5,'Campbeltown Machrihanish Airport','9200CAL1',
           'NaPTAN','UKOS',168406,621997,
			NULL,NULL,NULL,
           'Campbeltown Machrihanish Airport','9200CAL1',
           'NaPTAN','UKOS',168406,621997,
			NULL,NULL,NULL)
END

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1735
SET @ScriptDesc = 'Script to add an airport to the AirInterchangeOverlay Table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO