-- ***********************************************
-- NAME 		: DUP1676_Reporting_Partners_Update.sql
-- DESCRIPTION 	: Script to add Reporting partners on production
-- AUTHOR		: Amit Patel
-- DATE			: 15 APR 2010
-- ************************************************

-- ************************* NOTE ************************************
-- PLEASE UPDATE THE FOLLOWING SCRIPT TO RUN AGAINST THE PRODUCTION
-- IF REQUIRED
-- *******************************************************************

USE [Reporting]  
GO

-- Add the Partner - AOCycle -- Cycle white label test partner site
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =200 and PartnerName = 'AOCycle')BEGIN
 INSERT INTO Partner VALUES (200,'aocycle.transportdirect.info','AOCycle','AOCycle')
END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1676
SET @ScriptDesc = 'Script to add Reporting partners'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO