-- ****************************************************************
-- NAME 		: DUP1924_CycleCalorieCounterPropertiesUpdate.sql
-- DESCRIPTION 	: Updates default weight property for cycle calorie counter.
-- AUTHOR		: Rich Broddle
-- DATE			: 10 Sept 2012
-- ****************************************************************

----------------------------------------------------------------
-- Calorie counter properties
----------------------------------------------------------------

USE [PermanentPortal]
GO

--default weight for calcs (grams)

IF exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'Web')
BEGIN
	update properties set pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeightGrams'
		where pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'Web'
END

IF exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'TDRemotingHost')
BEGIN
	update properties set pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeightGrams'
		where pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'TDRemotingHost'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1924
SET @ScriptDesc = 'Update default weight property name for cycle calorie calculations'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO