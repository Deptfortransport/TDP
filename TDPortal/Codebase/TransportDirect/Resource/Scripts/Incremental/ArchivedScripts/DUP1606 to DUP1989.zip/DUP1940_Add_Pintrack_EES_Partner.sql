-- ***********************************************
-- AUTHOR      	: Phil Scott
-- Title        : DUP1940_Add_Pintrack_EES_Partner
-- DESCRIPTION 	: Adds Pintrack to EES
-- SOURCE 	: TDP Apps Support
-- ************************************************
--
--  ** WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  
--  ** WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  
--  **
--  **
--  **  ENSURE YOU RUN THE CORRECT CRYPTO KEY the default PROD key is ok for SI-TEST/DR-TEST/LIVE but will not work on DEV Machines
--  **
--  **
--  ** WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  
--  ** WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  WARNING ***** WARNING *******  

use permanentportal
go
-- "EESTID","Desc"



declare @partnerid int
declare @hostname varchar(25)
declare @Partnername varchar(25)
declare @Channel varchar(25)
declare @PartnerPassword varchar(100)


set @partnerid = 141
set @hostname = 'PINTRACK'
set @Partnername = 'PINTRACK'
set @Channel = 'EES' 

--**********************************************************************************************************************************************
--** **  PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY
-- P1NTR4CK# = crypt@YjLOEPr0PKxp5jxD7cdATTwxX+v0ZXexIKcDJSZ8wTo=

set @PartnerPassword = 'YjLOEPr0PKxp5jxD7cdATTwxX+v0ZXexIKcDJSZ8wTo='
 
--** ** PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY PRODKEY
--**********************************************************************************************************************************************



--**********************************************************************************************************************************************
-- DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY

-- P1NTR4CK# = crypt@L4JctT525I83GrS2BJFB93eyj3lui5n+fBr6JGvXlJk=
-- set @PartnerPassword = 'crypt@L4JctT525I83GrS2BJFB93eyj3lui5n+fBr6JGvXlJk='

-- DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY DEVKEY
--**********************************************************************************************************************************************




IF EXISTS (SELECT * FROM [PermanentPortal].[dbo].Partner WHERE partnerid = @partnerid)
  BEGIN
    UPDATE [PermanentPortal].[dbo].Partner
    SET HostName = @hostname, PartnerName = @PartnerName,Channel = @channel,PartnerPassword= @PartnerPassword
    WHERE partnerid = @partnerid
  END
ELSE
  BEGIN
    insert into Partner values (@partnerid, @hostname, @Partnername, @Channel, @PartnerPassword)
  END


-- 1,CodeHandler_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 1)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,1)
  END

-- 2,DepartureBoard_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 2)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,2)
  END
-- 3,FindNearest_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 3)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,3)
  END
-- 4,JourneyPlanner_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 4)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,4)
  END
-- 5,JourneyPlannerSynchronous_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 5)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,5)
  END
-- 6,TaxiInformation_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 6)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,6)
  END
-- 7,TestWebService
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 7)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,7)
  END
-- 8,TravelNews_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 8)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,8)
  END
-- 9,OpenJourneyPlanner_V1
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 9)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,9)
  END
-- 10,
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 10)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,10)
  END
-- 11,
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 11)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,11)
  END
-- 12,
  IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].PartnerAllowedServices WHERE partnerid = @partnerid and eestid = 12)
  BEGIN
    insert into PartnerAllowedServices (partnerid, EESTID ) values (@partnerid,12)
  END
go

-- Update M01 database as well
-- Use Reporting
-- insert into Partner values (142, 'PINTRACK', 'PINTRACK', 'EES')
-- go




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1940
SET @ScriptDesc = 'DUP1940_Add_Pintrack_EES_Partner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO








