-- ************************************************************
-- NAME 		: DUP1744_CCZone_ExternalLinks_Update.sql
-- DESCRIPTION 	: Updates external links to include TfL Congestion zone URL
-- AUTHOR		: Richard Broddle
-- DATE         : 7 September 2010
-- ************************************************************


USE [TransientPortal]
GO

EXEC AddExternalLink 'TfLCongestionLink', 'www.tfl.gov.uk/roadusers/congestioncharging/', 'www.tfl.gov.uk/roadusers/congestioncharging/', 'TfL Congestion Charge Zone', 'www.tfl.gov.uk/roadusers/congestioncharging/'


UPDATE dbo.ChangeNotification SET
		[Version] = [Version] + 1
		Where [Table] like '%ExternalLinks%'
GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1744
SET @ScriptDesc = 'Updates external links to include TfL Congestion zone URL'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
