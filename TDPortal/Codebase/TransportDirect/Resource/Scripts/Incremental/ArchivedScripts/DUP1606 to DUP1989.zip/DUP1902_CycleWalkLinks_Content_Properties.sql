-- ***********************************************
-- NAME 		: DUP1902_CycleWalkLinks_Content_Properties.sql
-- DESCRIPTION 	: Script to add content and properties for display
--				  and configuration of the CycleWalkLinks control
-- AUTHOR		: David Lane
-- DATE			: 07 Aug 2012
-- ************************************************


USE [Reporting]
GO

-- Add new page entry event for reporting
IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'CycleLinkClicked') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'CycleLinkClicked', 'Cycle link clicked' FROM PageEntryType
GO


USE [PermanentPortal]
GO

DECLARE @AID varchar(50) = 'Web'
DECLARE @GID varchar(50) = 'UserPortal'

IF EXISTS(SELECT * FROM properties WHERE pName = 'CycleWalkLinks.MaxWalkDistance' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
	UPDATE [properties] SET pValue = '3000' WHERE pName = 'CycleWalkLinks.MaxWalkDistance' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1
ELSE
	INSERT INTO [properties] VALUES ('CycleWalkLinks.MaxWalkDistance', '3000', @AID, @GID, 0, 1)

IF EXISTS(SELECT * FROM properties WHERE pName = 'CycleWalkLinks.MaxCycleDistance' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
	UPDATE [properties] SET pValue = '12000' WHERE pName = 'CycleWalkLinks.MaxCycleDistance' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1
ELSE
	INSERT INTO [properties] VALUES ('CycleWalkLinks.MaxCycleDistance', '12000', @AID, @GID, 0, 1)

IF EXISTS(SELECT * FROM properties WHERE pName = 'CycleWalkLinks.WalkitControlBaseUrl' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
	UPDATE [properties] SET pValue = 'http://www.walkit.com/walkit_pipe.php?referid=d8wka9ad03cwwookkk4s4ko8w&' WHERE pName = 'CycleWalkLinks.WalkitControlBaseUrl' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1
ELSE
	INSERT INTO [properties] VALUES ('CycleWalkLinks.WalkitControlBaseUrl', 'http://www.walkit.com/walkit_pipe.php?referid=d8wka9ad03cwwookkk4s4ko8w&', @AID, @GID, 0, 1)

GO

USE Content
GO

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkerImage', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/walk.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/walk.gif'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.CyclerImage', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/cycler.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/cycler.gif'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkitImage', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/walkit.jpg', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/walkit.jpg'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.CyclePlanImage', '/Web2/App_Themes/TransportDirect/images/gifs/journeyplanning/cyclejourney.gif', '/Web2/App_Themes/TransportDirect/images/gifs/journeyplanning/cyclejourney.gif'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkText', 'Your journey is a distance of about {0} miles. To find out about the walking route please click the walkit icon.', 'Your journey is a distance of about {0} miles. To find out about the walking route please click the walkit icon.'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.CycleText', 'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon.', 'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon.'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkCycleText', 'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon or to find out about walking please click the walkit icon.', 'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon or to find out about walking please click the walkit icon.'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkTextSingleMile', 'Your journey is a distance of about {0} mile. To find out about the walking route please click the walkit icon.', 'Your journey is a distance of about {0} miles. To find out about the walking route please click the walkit icon.'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.CycleTextSingleMile', 'Your journey is a distance of about {0} mile. To find out about the cycle route please click the cycle icon.', 'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon.'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkCycleTextSingleMile', 'Your journey is a distance of about {0} mile. To find out about the cycle route please click the cycle icon or to find out about walking please click the walkit icon.', 'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon or to find out about walking please click the walkit icon.'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkitAltText', 'Walk route (opens in new window)', 'Walk route (opens in new window)'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.WalkitTooltip', 'Walk route (opens in new window)', 'Walk route (opens in new window)'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.CycleAltText', 'Plan cycle journey', 'Plan cycle journey'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.CycleTooltip', 'Plan cycle journey', 'Plan cycle journey'

EXEC AddtblContent 
1,1,'langstrings','CycleWalkLinks.ModalPopupWarning', '<div class="popupHeader">    <img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation.gif" alt="Warning" title="Warning"/>    <span class="popupheaderText">Warning</span>  </div>  <div class="popupContent">    <p class="bold">When planning your cycle journey Transport Direct will not retain details of your door to door journey.</p>    <p>If you wish to continue please select next, if not then please select cancel.<p>    <p>You can retain details of your door to door journey for reference by clicking on ''printer friendly'' before you plan your cycle journey.</p>    <br/>  </div>', '<div class="popupHeader">    <img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation.gif" alt="Warning" title="Warning"/>    <span class="popupheaderText">Warning</span>  </div>  <div class="popupContent">    <p class="bold">When planning your cycle journey Transport Direct will not retain details of your door to door journey.</p>    <p>If you wish to continue please select next, if not then please select cancel.<p>    <p>You can retain details of your door to door journey for reference by clicking on ''printer friendly'' before you plan your cycle journey.</p>    <br/>  </div>'



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1902
SET @ScriptDesc = 'Script to add content and properties for the CycleWalkLinks control'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO