-- ***********************************************
-- NAME          : DUP1630_CyclePlanSameAreaOnly_Properties.sql
-- DESCRIPTION   : Script to ensure that cycle planning is only performed within individual areas
-- AUTHOR        : Richard Hopkins
-- DATE          : 23 March 2010
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'CyclePlanner.Planner.PointValidation.PlanSameAreaOnly' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('CyclePlanner.Planner.PointValidation.PlanSameAreaOnly', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.Planner.PointValidation.PlanSameAreaOnly' and ThemeId = 1
END

GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1630
SET @ScriptDesc = 'Set CyclePlanner PlanSameAreaOnly to true'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO