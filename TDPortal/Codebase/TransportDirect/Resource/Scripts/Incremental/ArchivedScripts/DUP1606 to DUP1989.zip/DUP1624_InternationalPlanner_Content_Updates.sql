-- ***********************************************
-- NAME 		: DUP1624_InternationalPlanner_Content_Updates.sql
-- DESCRIPTION 	: Script to update International Planner Content
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Mar 2010
-- ************************************************

USE [Content]
GO

-- A code fix (IR5451) has been made to allow the display of the "local times" text to be shown in 
-- the Notes section below the results table, but in the meantime temporary text is appended 
-- to the end of the info text above the results table, "All times quoted are local." 
--EXEC AddtblContent
--1, 1, 'langStrings', 'JourneyOverview.labelInstructions.Text',
--'To get journey details for each mode please select the more button. You can return to this summary table by pressing the back button. <br />All times quoted are local.',
--'I gael manylion siwrnai pob dull dewiswch y botwm mwy. You can return to this summary table by pressing the back button. <br />All times quoted are local.'


-- This script was not released in the patch and hence the temporary fix no longer applies as this
-- script will now be included in the next Full build. So reverting back to actual text needed.
-- This text should be reinserted after the above code fix has been released
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyOverview.labelInstructions.Text',
'To get journey details for each mode please select the more button. You can return to this summary table by pressing the back button.',
'I gael manylion siwrnai pob dull dewiswch y botwm mwy. You can return to this summary table by pressing the back button.'



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1624
SET @ScriptDesc = 'Script for temporary update to International planner content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO