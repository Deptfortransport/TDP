-- ***********************************************
-- NAME 		: DUP1647_LondonBusAccessibilityStatement_Properties.sql
-- DESCRIPTION 		: Script to add London bus service accessibility properties
-- AUTHOR		: Parvez Ghumra
-- DATE			: 26 March 2010
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'LegInstructionsControl.LondonBusAccessibilityLinkPrefix' and ThemeId = 1)
BEGIN
	insert into properties values ('LegInstructionsControl.LondonBusAccessibilityLinkPrefix', 'http://', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://'
	where pname = 'LegInstructionsControl.LondonBusAccessibilityLinkPrefix' and ThemeId = 1
END

GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1647
SET @ScriptDesc = 'Script to add London bus service accessibility link properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO