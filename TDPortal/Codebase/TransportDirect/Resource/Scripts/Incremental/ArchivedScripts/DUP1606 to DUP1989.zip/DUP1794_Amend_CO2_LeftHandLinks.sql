-- ***********************************************
-- NAME           : DUP1794_Remove_CO2_LeftHandLink.sql
-- DESCRIPTION    : Script to amend C02 left hand links
-- AUTHOR         : Neil Rankn
-- DATE           : 14 April 2011
-- ***********************************************

USE [TransientPortal] 
GO

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[UpdateSuggestionLinkURL]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[UpdateSuggestionLinkURL]
GO

-- =============================================  
-- Description: UpdateSuggestionLinkURL - updates the url of a suggestion link
-- =============================================  
CREATE PROCEDURE [dbo].[UpdateSuggestionLinkURL]
		@StringLinkURLOld    	  varchar(500),		-- Existing link. Relative url if Internal, Absolute if External link
		@StringLinkURLNew    	  varchar(500),		-- New link. Relative url if Internal, Absolute if External link
		@StringLinkDescription    varchar(200),		-- Provide description if updating, otherwise leave blank
		@IsInternalLink		  bit			-- 1 for Internal link, 0 for External
AS    
BEGIN
	IF (@IsInternalLink = 1)
		BEGIN
			IF (@StringLinkDescription <> '')
				BEGIN
					UPDATE 	[dbo].[InternalLink]
					SET 	[Description] = @StringLinkDescription
					WHERE 	[RelativeURL] = @StringLinkURLOld
				END

			UPDATE 	[dbo].[InternalLink]
			SET 	[RelativeURL] = @StringLinkURLNew
			WHERE 	[RelativeURL] = @StringLinkURLOld
		END
	ELSE
		BEGIN
			IF (@StringLinkDescription <> '')
				BEGIN
					UPDATE 	[dbo].[ExternalLinks]
					SET 	[Description] = @StringLinkDescription
					WHERE 	[URL] = @StringLinkURLOld
				END

			UPDATE 	[dbo].[ExternalLinks]
			SET 	[URL] = @StringLinkURLNew
			WHERE 	[URL] = @StringLinkURLOld			
		END

END

GO 

EXEC UpdateSuggestionLinkURL 'http://www.direct.gov.uk/EnvironmentAndGreenerLiving/GreenerTravel/GreenerTravelArticles/fs/en?CONTENT_ID=10040809&chk=jY6J/R','http://www.direct.gov.uk/en/Environmentandgreenerliving/Greenertravel/DG_064428','Motoring and Environment','0'

EXEC UpdateSuggestionLinkURL 'http://www.vcacarfueldata.org.uk/search/search.asp','http://carfueldata.direct.gov.uk/search-by-running-cost.aspx','Compare Fuel Efficiency','0'

EXEC UpdateSuggestionLinkURL 'http://www.naei.org.uk/index.php','http://naei.defra.gov.uk/index.php','Emissions of Air Pollutants in the UK','0'

EXEC UpdateSuggestionLinkURL 'http://www.rac.co.uk/web/know-how/hints-tips/fuel-consumption.htm','http://www.rac.co.uk/news-advice/','Fuel Saving Tips','0'

EXEC UpdateSuggestionLinkURL 'http://www.dft.gov.uk/ActOnCO2/','http://www.direct.gov.uk/en/Environmentandgreenerliving/Thewiderenvironment/index.htm','Act On CO2','0'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1794
SET @ScriptDesc = 'Script to amend C02 left hand links on CO2 page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO