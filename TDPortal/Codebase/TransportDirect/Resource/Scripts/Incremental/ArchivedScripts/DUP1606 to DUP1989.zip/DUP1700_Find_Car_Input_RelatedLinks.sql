-- ***********************************************
-- NAME 		: DUP1700_Find_Car_Input_RelatedLinks.sql
-- DESCRIPTION 	: Find Car Input page related links
-- AUTHOR		: Richard Hopkins
-- DATE         : 4 May 2010
-- ************************************************
USE TransientPortal
GO

-------------------------------------------------------------------------
-- Find Car Input Page Related Links
-------------------------------------------------------------------------
-- Top level root Related Links, will be used by all pages which display Related Links
-- Add to the context - so it displays on the pages
DECLARE @ContextName varchar(100),
	@ContextDescription varchar(500),
	@ContextId INT

SET @ContextName = 'RelatedLinksContextFindCarInput'
SET @ContextDescription = 'Related Link Context - Suggestions for Find Car Input Page'

-- Add the context
IF NOT EXISTS(SELECT * FROM [Context] WHERE [Name] = @ContextName)
	BEGIN
		SET @ContextId = (select MAX(ContextId) from [dbo].[Context]) + 1	

		INSERT INTO [Context] ([ContextId], [Name], [Description])
		SELECT @ContextId, @ContextName, @ContextDescription 
	END
ELSE
	BEGIN
		SET @ContextId = (select [ContextId] from [dbo].[Context] where [Name] = @ContextName)
	END


DECLARE @LinkResourceName varchar(100),
	@ResourceNameID INT,
	@SuggestionLinkID INT,
	@ContextSuggestionLinkID INT,
	@LinkCategoryID INT

--insert into ContextSuggestionLink table

-- Link 1
SET @LinkResourceName = 'RelatedLinks'
SELECT @LinkCategoryID =  LinkCategoryId FROM LinkCategory WHERE [Name]='Related links' 
SET @ResourceNameID = (SELECT ResourceNameId FROM [dbo].[ResourceName] WHERE ResourceName = @LinkResourceName)
SET @SuggestionLinkID = (SELECT SuggestionLinkID FROM [dbo].[SuggestionLink] 
				WHERE LinkCategoryId = @LinkCategoryID
				AND ResourceNameID = @ResourceNameID)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1

IF NOT EXISTS(SELECT * FROM [ContextSuggestionLink] WHERE ([SuggestionLinkId] = @SuggestionLinkID) AND ([ContextId] = @ContextId))
	INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId])
	SELECT @ContextSuggestionLinkId, @ContextId, @SuggestionLinkID


-- Related links for specific pages/contexts
EXEC AddInternalSuggestionLink 
	'staticwithoutprint.aspx?id=_web2_about_relatedsites#CarSharing',
	'Find out about car sharing',
	'FindOutAboutCarSharing',
	'Find out about car sharing',
	'Find out about car sharing',
	'Related links',
	1135,
	0,
	0,
	'RelatedLinksContextFindCarInput',
	'Related Link Context - Suggestions for Find Car Input Page',
	1
GO



-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1700
SET @ScriptDesc = 'Added Find Car Input page related links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
------------------------------------------------------------