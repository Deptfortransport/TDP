-- ***********************************************
-- NAME           : DUP1852_OverideContentChanges.sql
-- DESCRIPTION    : Script to remove overide christmas shopping
-- AUTHOR         : Phil Scott
-- DATE           : 05/01/2012
-- ***********************************************


USE [Content] 
GO

-- For safety - tidy up old entries getting rid of old entries containing the christmas shopping text

delete from [Content].[dbo].[tblContentOverride] 
where ControlName like 'TDAdditionalInformationHtmlPlaceholderDefinition' 
and PropertyName like '/Channels/TransportDirect/Home' 
and ThemeId = 1

go



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1852
SET @ScriptDesc = 'DUP 1852 Overide Content Changes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
GO