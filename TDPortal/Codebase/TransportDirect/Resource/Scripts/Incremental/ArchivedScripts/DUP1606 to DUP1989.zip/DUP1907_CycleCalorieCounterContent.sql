-- ****************************************************************
-- NAME 		: DUP1907_CycleCalorieCounterContent.sql
-- DESCRIPTION 	: Creates content for display of calorie count in 
--				  cycle journey results
-- AUTHOR		: Rich Broddle
-- DATE			: 20 Aug 2012
-- ****************************************************************


USE [Content] 


EXEC AddtblContent
1, 1,'langStrings','CyclePlanner.CycleSummaryControl.labelCalorieCount.Text' 
,'Total calories used (approx): {0} calories' 
,'Total calories used (approx): {0} calories' 


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1907
SET @ScriptDesc = 'Create content for cycle calorie display'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO