-- ***********************************************
-- NAME 		: DUP1628_Add_Coach_Operator_Codes.sql
-- DESCRIPTION 	: Adds new operator codes required to CoachOperatorCodes
-- AUTHOR		: Rich Broddle
-- DATE			: 24 Sept 2012
-- ************************************************

USE [PermanentPortal]
GO

IF NOT EXISTS (SELECT * FROM [dbo].[CoachOperatorCodes] WHERE CJPOperatorCode = '*FK')
  BEGIN
    INSERT INTO [dbo].[CoachOperatorCodes] (CJPOperatorCode,TDOperatorCode)
    VALUES ('*FK','NX')
  END
GO
IF NOT EXISTS (SELECT * FROM [dbo].[CoachOperatorCodes] WHERE CJPOperatorCode = '*SH')
  BEGIN
    INSERT INTO [dbo].[CoachOperatorCodes] (CJPOperatorCode,TDOperatorCode)
    VALUES ('*SH','NX')
  END
GO
IF NOT EXISTS (SELECT * FROM [dbo].[CoachOperatorCodes] WHERE CJPOperatorCode = 'nrc-238')
  BEGIN
    INSERT INTO [dbo].[CoachOperatorCodes] (CJPOperatorCode,TDOperatorCode)
    VALUES ('nrc-238','NX')
  END
GO
IF NOT EXISTS (SELECT * FROM [dbo].[CoachOperatorCodes] WHERE CJPOperatorCode = 'nrc-9')
  BEGIN
    INSERT INTO [dbo].[CoachOperatorCodes] (CJPOperatorCode,TDOperatorCode)
    VALUES ('nrc-9','NX')
  END
GO
IF NOT EXISTS (SELECT * FROM [dbo].[CoachOperatorCodes] WHERE CJPOperatorCode = 'nrc-99028')
  BEGIN
    INSERT INTO [dbo].[CoachOperatorCodes] (CJPOperatorCode,TDOperatorCode)
    VALUES ('nrc-99028','NX')
  END
GO
IF NOT EXISTS (SELECT * FROM [dbo].[CoachOperatorCodes] WHERE CJPOperatorCode = 'NXP')
  BEGIN
    INSERT INTO [dbo].[CoachOperatorCodes] (CJPOperatorCode,TDOperatorCode)
    VALUES ('NXP','NX')
  END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1928
SET @ScriptDesc = 'Adds new operator codes to CoachOperatorCodes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO