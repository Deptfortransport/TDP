-- ***********************************************
-- NAME 		: DUP1751_CyclePlanner_EES_Partner_Settings.sql
-- DESCRIPTION 	: Script to add Cycle Planner EES Type and partner settings
-- AUTHOR		: Amit Patel
-- DATE			: 27 Sep 2008
-- ************************************************

USE [PermanentPortal]
GO

DECLARE @EESTTypeId int

IF NOT EXISTS(SELECT * FROM [EnhancedExposedServicesType]
				WHERE EESTType ='TransportDirect_EnhancedExposedServices_CycleJourneyPlannerSynchronous_V1')
BEGIN
INSERT INTO [EnhancedExposedServicesType]
           ([EESTType]
           ,[EESTDescription])
     VALUES
           ('TransportDirect_EnhancedExposedServices_CycleJourneyPlannerSynchronous_V1'
           ,'TransportDirect_EnhancedExposedServices_CycleJourneyPlannerSynchronous_V1')
END

SELECT @EESTTypeId = EESTID FROM [EnhancedExposedServicesType]
				WHERE EESTType ='TransportDirect_EnhancedExposedServices_CycleJourneyPlannerSynchronous_V1'

IF NOT EXISTS(SELECT * FROM PartnerAllowedServices
				WHERE PartnerId = 101 and EESTID = @EESTTypeId)
BEGIN
INSERT INTO [PermanentPortal].[dbo].[PartnerAllowedServices]
           ([PartnerId]
           ,[EESTID])
     VALUES
           (101
           ,@EESTTypeId)
END


IF NOT EXISTS(SELECT * FROM [EnhancedExposedServicesType]
				WHERE EESTType ='TransportDirect_EnhancedExposedServices_GradientProfileService_V1')
BEGIN
INSERT INTO [PermanentPortal].[dbo].[EnhancedExposedServicesType]
           ([EESTType]
           ,[EESTDescription])
     VALUES
           ('TransportDirect_EnhancedExposedServices_GradientProfileService_V1'
           ,'TransportDirect_EnhancedExposedServices_GradientProfileService_V1')
END

SELECT @EESTTypeId = EESTID FROM [EnhancedExposedServicesType]
				WHERE EESTType ='TransportDirect_EnhancedExposedServices_GradientProfileService_V1'

IF NOT EXISTS(SELECT * FROM PartnerAllowedServices
				WHERE PartnerId = 101 and EESTID = @EESTTypeId)
BEGIN
INSERT INTO [PermanentPortal].[dbo].[PartnerAllowedServices]
           ([PartnerId]
           ,[EESTID])
     VALUES
           (101
           ,@EESTTypeId)
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1751
SET @ScriptDesc = 'Script to add Cycle Planner EES Type and partner settings'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO