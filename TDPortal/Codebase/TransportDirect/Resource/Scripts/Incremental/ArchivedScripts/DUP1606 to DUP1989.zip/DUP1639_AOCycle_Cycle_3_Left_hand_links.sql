-- ***********************************************
-- NAME 		: DUP1639_AOCycle_Cycle_3_Left_hand_links.sql
-- DESCRIPTION 	: Script to add all the left hand links for AOCycle Cycle Only partner theme
-- AUTHOR		: Amit Patel
-- DATE			: 26 Mar 2008
-- ************************************************

-- IMPORTANT: 
-- See script DUP0790_CreateDefaultPartnerMenuLinks.sql to generate the default list of links to add

-- ************************************************
-- NOTE: AOCycle partner setup purely for test purpose
-- ************************************************

USE [TransientPortal]
GO


-----------------------------------------------------
-- LINKS
-----------------------------------------------------

DECLARE @ThemeId INT
SET @ThemeId = 200

-- Clear all existing links for this Theme
DELETE FROM ContextSuggestionLink
WHERE     (ThemeId = @ThemeId)


EXEC AddContextSuggestionLink 'AboutUs','AboutUs','AboutUsMenu', @ThemeId
EXEC AddContextSuggestionLink 'AboutUs.Introduction','AboutUs','AboutUsMenu', @ThemeId
EXEC AddContextSuggestionLink 'AboutUs.EnablingIntelligentTravel','AboutUs','AboutUsMenu', @ThemeId
EXEC AddContextSuggestionLink 'AboutUs.WhoOperates','AboutUs','AboutUsMenu', @ThemeId
EXEC AddContextSuggestionLink 'AboutUs.WhoBuilds','AboutUs','AboutUsMenu', @ThemeId
EXEC AddContextSuggestionLink 'AboutUs.WhatNext','AboutUs','AboutUsMenu', @ThemeId
EXEC AddContextSuggestionLink 'TermsConditions','TermsAndPolicy','AccessibilityMenu', @ThemeId
EXEC AddContextSuggestionLink 'PrivacyPolicy','TermsAndPolicy','AccessibilityMenu', @ThemeId
EXEC AddContextSuggestionLink 'Accessibility','TermsAndPolicy','AccessibilityMenu', @ThemeId
EXEC AddContextSuggestionLink 'FAQ','FAQ','FAQMenu', @ThemeId
EXEC AddContextSuggestionLink 'FAQ.CO2Information','FAQ','FAQMenu', @ThemeId
EXEC AddContextSuggestionLink 'FAQ.CyclePlanning','FAQ','FAQMenu', @ThemeId

EXEC AddContextSuggestionLink 'FindAPlace','Find a place','HomePageMenuFindAPlace', @ThemeId

EXEC AddContextSuggestionLink 'LiveTravel','Live travel','HomePageMenuLiveTravel', @ThemeId

EXEC AddContextSuggestionLink 'PlanAJourney','Plan a journey','HomePageMenuPlanAJourney', @ThemeId

EXEC AddContextSuggestionLink 'TipsAndTools','Tips and tools','HomePageMenuTipsAndTools', @ThemeId

EXEC AddContextSuggestionLink 'ProvideFeedback','Tips and tools','HomePageMenuTipsAndTools', @ThemeId
EXEC AddContextSuggestionLink 'RelatedSites','Tips and tools','HomePageMenuTipsAndTools', @ThemeId
EXEC AddContextSuggestionLink 'HELPFAQ','Tips and tools','HomePageMenuTipsAndTools', @ThemeId
EXEC AddContextSuggestionLink 'Feedback','Provide Feedback','HomePageMenuTipsAndTools', @ThemeId
EXEC AddContextSuggestionLink 'ContactDetails','Provide Feedback','HomePageMenuTipsAndTools', @ThemeId

EXEC AddContextSuggestionLink 'HELPFAQ','General','HomePlanAJourney', @ThemeId
EXEC AddContextSuggestionLink 'PlanAJourneyHomepage','General','HomeTipsTools', @ThemeId
EXEC AddContextSuggestionLink 'PlanAJourneyHomepage','General','HomeTravelInfo', @ThemeId

EXEC AddContextSuggestionLink 'JourneyEmissions.OffsetCarbonEmissions','General','JourneyEmissionsCompare', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.CompareFuelEfficiency','General','JourneyEmissionsCompare', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.FuelSavingTips','General','JourneyEmissionsCompare', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.MotoringAndEnvironment','General','JourneyEmissionsCompare', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.Flying','General','JourneyEmissionsCompare', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.PT.AirPollutants','General','JourneyEmissionsCompare', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.ActOnCo2','General','JourneyEmissionsCompare', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.Co2Railway','General','JourneyEmissionsCompare', @ThemeId
--EXEC AddContextSuggestionLink 'JourneyEmissions.RelatedSitesCarSharing','General','JourneyEmissionsCompare', @ThemeId

EXEC AddContextSuggestionLink 'TermsConditions','TermsAndPolicy','PrivacyPolicyMenu', @ThemeId
EXEC AddContextSuggestionLink 'PrivacyPolicy','TermsAndPolicy','PrivacyPolicyMenu', @ThemeId

EXEC AddContextSuggestionLink 'Accessibility','TermsAndPolicy','PrivacyPolicyMenu', @ThemeId

EXEC AddContextSuggestionLink 'RelatedLinks','Related links','RelatedLinksContextJourneyEmissions', @ThemeId
EXEC AddContextSuggestionLink 'RelatedLinks','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.OffsetCarbonEmissions','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.CompareFuelEfficiency','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.FuelSavingTips','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.MotoringAndEnvironment','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.Flying','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.PT.AirPollutants','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.ActOnCo2','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId
EXEC AddContextSuggestionLink 'JourneyEmissions.Co2Railway','Related links','RelatedLinksContextJourneyEmissionsCompareJourney', @ThemeId

EXEC AddContextSuggestionLink 'RelatedSites','RelatedSites','RelatedSitesMenu', @ThemeId
EXEC AddContextSuggestionLink 'RelatedSites.NationalTransport','RelatedSites','RelatedSitesMenu', @ThemeId
EXEC AddContextSuggestionLink 'RelatedSites.LocalPublicTransport','RelatedSites','RelatedSitesMenu', @ThemeId
EXEC AddContextSuggestionLink 'RelatedSites.Motoring','RelatedSites','RelatedSitesMenu', @ThemeId
EXEC AddContextSuggestionLink 'RelatedSites.MotoringCosts','RelatedSites','RelatedSitesMenu', @ThemeId
--EXEC AddContextSuggestionLink 'RelatedSites.CarSharing','RelatedSites','RelatedSitesMenu', @ThemeId
EXEC AddContextSuggestionLink 'RelatedSites.Government','RelatedSites','RelatedSitesMenu', @ThemeId
EXEC AddContextSuggestionLink 'RelatedSites.TouristInfo','RelatedSites','RelatedSitesMenu', @ThemeId
EXEC AddContextSuggestionLink 'TermsConditions','TermsAndPolicy','TermsConditionsMenu', @ThemeId
EXEC AddContextSuggestionLink 'PrivacyPolicy','TermsAndPolicy','TermsConditionsMenu', @ThemeId
EXEC AddContextSuggestionLink 'Accessibility','TermsAndPolicy','TermsConditionsMenu', @ThemeId

EXEC AddContextSuggestionLink 'FindACycle','Plan a journey','HomePageMenu', @ThemeId
EXEC AddContextSuggestionLink 'RelatedLinks','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.CyclingEngland','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.CyclingScotland','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.CyclingWales','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.NationalCycleRoutes','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.CycleScheme','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.CycleSafety','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.CycleSchool','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.GPXDownload','Related Links','RelatedLinksContextFindCycleInput', @ThemeId
EXEC AddContextSuggestionLink 'CyclePlanner.Parking','Related Links','RelatedLinksContextFindCycleInput', @ThemeId


----------------------------------------------------------------------------------------------------
-- FAQ for cycle white label partners got 
--
----------------------------------------------------------------------------------------------------

-- FAQ - Estimate Car CO2 Emissions Info Link
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.EstimateCarCO2EmissionsInfo.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - Estimate Car CO2 Emissions Info Link'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.1')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.1'										-- Description of internal link.
			  ,'Cycle White Label FAQ - Estimate Car CO2 Emissions Info Link'	-- Full internal link URL
			  ,'JourneyEmissions.EstimateCarCO2EmissionsInfo.CycleWhiteLabel'
			  ,'Estimating my car''s CO2 emissions'								-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Amcangyfrif allyriadau CO2 fy nghar'							-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,400																-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,'JourneyEmissionsCompareInfo'									-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END
ELSE
BEGIN
	EXEC AddContextSuggestionLink 'JourneyEmissions.EstimateCarCO2EmissionsInfo.CycleWhiteLabel','General','JourneyEmissionsCompareInfo', @ThemeId
END


-- FAQ - About Car CO2 Emissions
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.AboutCarCO2Emissions.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - About Car CO2 Emissions'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.2')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.2'										-- Description of internal link.
			  ,'Cycle White Label FAQ - About Car CO2 Emissions'				-- Full internal link URL
			  ,'JourneyEmissions.AboutCarCO2Emissions.CycleWhiteLabel'			-- Resource name
			  ,'About car CO2 emissions'										-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Ynglyn ag allyriadau CO2 car'									-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,405																-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,'JourneyEmissionsCompareInfo'									-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END
ELSE
BEGIN
	EXEC AddContextSuggestionLink 'JourneyEmissions.AboutCarCO2Emissions.CycleWhiteLabel','General','JourneyEmissionsCompareInfo', @ThemeId
END


-- FAQ - Estimating Public Transport CO2
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.EstimatingPublicTransportCO2.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - Estimating Public Transport CO2'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.3')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.3'										-- Description of internal link.
			  ,'Cycle White Label FAQ - Estimating Public Transport CO2'		-- Full internal link URL
			  ,'JourneyEmissions.EstimatingPublicTransportCO2.CycleWhiteLabel'	-- Resource name
			  ,'Estimating public transport and air journey CO2'				-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Tr�n'															-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,410																-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,'JourneyEmissionsCompareInfo'									-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END
ELSE
BEGIN
	EXEC AddContextSuggestionLink 'JourneyEmissions.EstimatingPublicTransportCO2.CycleWhiteLabel','General','JourneyEmissionsCompareInfo', @ThemeId
END

-- FAQ - CO2 From Different Transport
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.CO2FromDifferentTransport.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - CO2 From Different Transport'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.5')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.5'										-- Description of internal link.
			  ,'Cycle White Label FAQ - CO2 From Different Transport'			-- Full internal link URL
			  ,'JourneyEmissions.CO2FromDifferentTransport.CycleWhiteLabel'		-- Resource name
			  ,'About bus and and coach journeys'								-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Dybio am siwrneiau bws a choets'								-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,415															-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,'JourneyEmissionsCompareInfo'									-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END
ELSE
BEGIN
	EXEC AddContextSuggestionLink 'JourneyEmissions.CO2FromDifferentTransport.CycleWhiteLabel','General','JourneyEmissionsCompareInfo', @ThemeId
END

-- FAQ - Comparing Car And Public Transport
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.ComparingCarAndPublicTransport.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - Comparing Car And Public Transport'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.4')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.4'										-- Description of internal link.
			  ,'Cycle White Label FAQ - Comparing Car And Public Transport'		-- Full internal link URL
			  ,'JourneyEmissions.ComparingCarAndPublicTransport.CycleWhiteLabel'-- Resource name
			  ,'Comparing car and public transport CO2'							-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Cymharu CO2 car a thrafnidiaeth gyhoeddus'						-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,420															-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,'JourneyEmissionsCompareInfo'									-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END
ELSE
BEGIN
	EXEC AddContextSuggestionLink 'JourneyEmissions.ComparingCarAndPublicTransport.CycleWhiteLabel','General','JourneyEmissionsCompareInfo', @ThemeId
END



DECLARE
	@StringResourceName		varchar(100),
	@StringResourceNameId		int,
	@StringLinkCategoryName		varchar(100),
	@StringLinkCategoryId		int,
	@SuggestionLinkId		int,
	@StringContextName		varchar(100),
	@StringContextId		int,
	@ContextSuggestionLinkID	int

------------------------------------------
-- Category
SET @StringLinkCategoryName = 'General'
SET @StringLinkCategoryId = (SELECT LinkCategoryId FROM LinkCategory WHERE [Name] = @StringLinkCategoryName)

SET @SuggestionLinkId = (SELECT top 1 SuggestionLinkId FROM SuggestionLink 
				WHERE ResourceNameId = @StringResourceNameId AND
					LinkCategoryId = @StringLinkCategoryId AND
					[ExternalInternalLinkType] like '%Internal%'
				ORDER BY Priority DESC)


------------------------------------------



--------------------------------------------------------------------
-- Manual insert - ensure correct Root links are used other the pages will show no menu
--------------------------------------------------------------------

--EXEC AddContextSuggestionLink 'Accessibility','TermsAndPolicy','AccessibilityMenu', @ThemeId
--EXEC AddContextSuggestionLink 'DataProviders','TermsAndPolicy','DataProvidersMenu', @ThemeId
--EXEC AddContextSuggestionLink 'PrivacyPolicy','TermsAndPolicy','PrivacyPolicyMenu', @ThemeId
--EXEC AddContextSuggestionLink 'TermsConditions','TermsAndPolicy','TermsConditionsMenu', @ThemeId

----------------------------------------
-- Resource
SET @StringResourceName = 'Accessibility'
SET @StringResourceNameId = (SELECT ResourceNameId FROM ResourceName WHERE [ResourceName] = @StringResourceName)

-- Category
SET @StringLinkCategoryName = 'TermsAndPolicy'
SET @StringLinkCategoryId = (SELECT LinkCategoryId FROM LinkCategory WHERE [Name] = @StringLinkCategoryName)

SET @SuggestionLinkId = (SELECT top 1 SuggestionLinkId FROM SuggestionLink 
				WHERE ResourceNameId = @StringResourceNameId AND
					LinkCategoryId = @StringLinkCategoryId AND
					[ExternalInternalLinkType] like '%Internal%'
				ORDER BY Priority ASC)

--EXEC AddContextSuggestionLink 'Accessibility','TermsAndPolicy','AccessibilityMenu', @ThemeId
SET @StringContextName = 'AccessibilityMenu'
SET @StringContextId = (SELECT ContextId FROM Context WHERE [Name] = @StringContextName)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId], [ThemeId])
SELECT @ContextSuggestionLinkId, @StringContextId, @SuggestionLinkID, @ThemeId


----------------------------------------
-- Resource
SET @StringResourceName = 'DataProviders'
SET @StringResourceNameId = (SELECT ResourceNameId FROM ResourceName WHERE [ResourceName] = @StringResourceName)

-- Category
SET @StringLinkCategoryName = 'TermsAndPolicy'
SET @StringLinkCategoryId = (SELECT LinkCategoryId FROM LinkCategory WHERE [Name] = @StringLinkCategoryName)

SET @SuggestionLinkId = (SELECT top 1 SuggestionLinkId FROM SuggestionLink 
				WHERE ResourceNameId = @StringResourceNameId AND
					LinkCategoryId = @StringLinkCategoryId AND
					[ExternalInternalLinkType] like '%Internal%'
				ORDER BY Priority ASC)

--EXEC AddContextSuggestionLink 'DataProviders','TermsAndPolicy','DataProvidersMenu', @ThemeId
SET @StringContextName = 'DataProvidersMenu'
SET @StringContextId = (SELECT ContextId FROM Context WHERE [Name] = @StringContextName)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId], [ThemeId])
SELECT @ContextSuggestionLinkId, @StringContextId, @SuggestionLinkID, @ThemeId


----------------------------------------
-- Resource
SET @StringResourceName = 'PrivacyPolicy'
SET @StringResourceNameId = (SELECT ResourceNameId FROM ResourceName WHERE [ResourceName] = @StringResourceName)

-- Category
SET @StringLinkCategoryName = 'TermsAndPolicy'
SET @StringLinkCategoryId = (SELECT LinkCategoryId FROM LinkCategory WHERE [Name] = @StringLinkCategoryName)

SET @SuggestionLinkId = (SELECT top 1 SuggestionLinkId FROM SuggestionLink 
				WHERE ResourceNameId = @StringResourceNameId AND
					LinkCategoryId = @StringLinkCategoryId AND
					[ExternalInternalLinkType] like '%Internal%'
				ORDER BY Priority ASC)

--EXEC AddContextSuggestionLink 'PrivacyPolicy','TermsAndPolicy','PrivacyPolicyMenu', @ThemeId
SET @StringContextName = 'PrivacyPolicyMenu'
SET @StringContextId = (SELECT ContextId FROM Context WHERE [Name] = @StringContextName)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId], [ThemeId])
SELECT @ContextSuggestionLinkId, @StringContextId, @SuggestionLinkID, @ThemeId


----------------------------------------
-- Resource
SET @StringResourceName = 'TermsConditions'
SET @StringResourceNameId = (SELECT ResourceNameId FROM ResourceName WHERE [ResourceName] = @StringResourceName)

-- Category
SET @StringLinkCategoryName = 'TermsAndPolicy'
SET @StringLinkCategoryId = (SELECT LinkCategoryId FROM LinkCategory WHERE [Name] = @StringLinkCategoryName)

SET @SuggestionLinkId = (SELECT top 1 SuggestionLinkId FROM SuggestionLink 
				WHERE ResourceNameId = @StringResourceNameId AND
					LinkCategoryId = @StringLinkCategoryId AND
					[ExternalInternalLinkType] like '%Internal%'
				ORDER BY Priority ASC)

--EXEC AddContextSuggestionLink 'TermsConditions','TermsAndPolicy','TermsConditionsMenu', @ThemeId
SET @StringContextName = 'TermsConditionsMenu'
SET @StringContextId = (SELECT ContextId FROM Context WHERE [Name] = @StringContextName)
SET @ContextSuggestionLinkID = (select MAX(ContextSuggestionLinkId) from [dbo].[ContextSuggestionLink]) + 1
INSERT INTO [ContextSuggestionLink] ([ContextSuggestionLinkId], [ContextId], [SuggestionLinkId], [ThemeId])
SELECT @ContextSuggestionLinkId, @StringContextId, @SuggestionLinkID, @ThemeId





GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1639
SET @ScriptDesc = 'Script to add all the left hand links for AOCycle Cycle Only partner theme'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
