-- ***********************************************
-- NAME 		: DUP1809_RefTransactionEvent_MachineName_Change_2.sql
-- DESCRIPTION 	: Script to drop and recreate reftrans table with new keys and import data back from temp table 
-- AUTHOR		: Phil Scott
-- DATE			: 07 Jun 2011 
-- ************************************************
USE [ReportStagingDB]
GO

/****** Object:  Table [dbo].[ReferenceTransactionEvent]    Script Date: 06/03/2011 10:07:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReferenceTransactionEvent]') AND type in (N'U'))
DROP TABLE [dbo].[ReferenceTransactionEvent]
GO

USE [ReportStagingDB]
GO

/****** Object:  ReferenceTransactionEventable [dbo].[ReferenceTransactionEvent]    Script Date: 06/03/2011 10:07:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ReferenceTransactionEvent](
	[Submitted] [datetime] NOT NULL,
	[EventType] [varchar](50) NOT NULL,
	[ServiceLevelAgreement] [bit] NULL,
	[SessionId] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL,
	[Successful] [bit] NULL,
	[MachineName] [varchar](50) NOT NULL DEFAULT 'SiteConfidence',
 CONSTRAINT [PK_ReferenceTransactionEvent] PRIMARY KEY NONCLUSTERED 
(
	[Submitted] ASC,
	[EventType] ASC,
	[MachineName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

INSERT INTO [ReportStagingDB].[dbo].[ReferenceTransactionEvent]
           ([Submitted]
           ,[EventType]
           ,[ServiceLevelAgreement]
           ,[SessionId]
           ,[TimeLogged]
           ,[Successful]
           ,[MachineName])
SELECT [Submitted]
      ,[EventType]
      ,[ServiceLevelAgreement]
      ,[SessionId]
      ,[TimeLogged]
      ,[Successful]
      ,ISNULL([MachineName],'SiteConfidence') [MachineName]
  FROM [ReportStagingDB].[dbo].[TEmpReferenceTransactionEvent]
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1809
SET @ScriptDesc = 'Script to drop and recreate reftrans table with new keys and import data back from temp table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO