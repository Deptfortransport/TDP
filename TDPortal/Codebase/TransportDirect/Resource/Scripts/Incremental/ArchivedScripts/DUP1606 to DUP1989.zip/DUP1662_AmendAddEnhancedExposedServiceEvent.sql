-- ***********************************************
-- NAME 		: DUP1662_AmendAddEnhancedExposedServiceEvent.sql
-- DESCRIPTION 		: amend stored proc AddEnhancedExposedServiceEvent.sql to use default information when not supplied
--					 
-- AUTHOR		: ps
-- ************************************************

USE [ReportStagingDB]
GO

/****** Object:  StoredProcedure [dbo].[AddEnhancedExposedServiceEvent]    Script Date: 04/14/2010 11:06:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Create stored procedure to log events in the ReportStaging DB

ALTER PROCEDURE [dbo].[AddEnhancedExposedServiceEvent]
	
	(
	@PartnerId SmallInt, 
	@InternalTransactionId Varchar(40), 
    @ExternalTransactionId Varchar(100)= 'default_value',
	@ServiceType varchar(200),
	@OperationType varchar(100),	
	@EventTime datetime,
	@IsStartEvent bit,
	@CallSuccessful bit
	) 
AS

BEGIN
	SET NOCOUNT OFF

	DECLARE @localized_string_UnableToInsert AS VARCHAR(256)
   	SET @localized_string_UnableToInsert = 'Unable to Insert a new record into EnhancedExposedServiceEvent Table'
	-- SET @ExternalTransactionId = ISNULL(@ExternalTransactionId,'NA')
	INSERT INTO EnhancedExposedServiceEvent (EESEPartnerId, EESEInternalTransactionId, EESEExternalTransactionId, EESEServiceType, EESEOperationType, EESEEventTime, EESEIsStartEvent, EESECallSuccessful)
	VALUES (@PartnerId, @InternalTransactionId, @ExternalTransactionId, @ServiceType, @OperationType, @EventTime, @IsStartEvent, @CallSuccessful)
		
	IF @@error <> 0
	    BEGIN
	        RAISERROR (@localized_string_UnableToInsert, 1,1)
		RETURN -1
	    END
	ELSE
	    RETURN @@rowcount

END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1662
SET @ScriptDesc = 'DUP1662_AmendAddEnhancedExposedServiceEvent'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
