-- ****************************************************************
-- NAME 		: DUP1906_CycleCalorieCounterProperties.sql
-- DESCRIPTION 	: Creates switch & default weight properties for
--				  Cycle calorie counter.
-- AUTHOR		: Rich Broddle
-- DATE			: 20 Aug 2012
-- ****************************************************************

----------------------------------------------------------------
-- Calorie counter properties
----------------------------------------------------------------

--on/off switch

USE [PermanentPortal]
GO

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.IncludeCalorieCount' AND AID = 'Web')
BEGIN
	insert into properties values ('CyclePlanner.IncludeCalorieCount','true',
				'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'true' 
		where pname = 'CyclePlanner.IncludeCalorieCount' AND AID = 'Web'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.IncludeCalorieCount' AND AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('CyclePlanner.IncludeCalorieCount','true',
				'TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'true' 
		where pname = 'CyclePlanner.IncludeCalorieCount' AND AID = 'TDRemotingHost'
END

GO

--default weight for calcs (grams)

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'Web')
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.CalorieCountDefaultWeight','64000',
				'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = '64000' 
		where pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'Web'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.CalorieCountDefaultWeight','64000',
				'TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = '64000' 
		where pname = 'CyclePlanner.PlannerControl.CalorieCountDefaultWeight' AND AID = 'TDRemotingHost'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1906
SET @ScriptDesc = 'Create properties for cycle calorie calculations'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO