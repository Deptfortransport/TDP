-- ***********************************************
-- NAME 		: DUP1770_CyclePlanner_Algorithm_Properties_Update.sql
-- DESCRIPTION 	: Script to update Cycle Planner algorithm properties (ATO687)
-- AUTHOR		: Amit Patel
-- DATE			: 25 Nov 2008
-- ************************************************


-------------------------------------------------------------------------------------
--********************************** WARNING **************************************--
-------------------------------------------------------------------------------------
--	PATH TO THE CYCLE PLANNER FUNCTION DLLS ARE BASED ON DEV ENVIRONMENT		   --
--  PLEASE UPDATE THE PATH IN PROPERTIES TO REFLECT CORRECT PATHS 
--  ACCORDING TO THE SITEST/BBP/ACP ENVIRONMENT THE SCRIPT RUN ON			       --
-------------------------------------------------------------------------------------

USE [PermanentPortal]
GO



-----------------------------------------------------------
-- Algorithm Quickest913 -- EES
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


-----------------------------------------------------------
-- Algorithm Quickest913 -- Web
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Dll'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV913.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



-----------------------------------------------------------
-- Algorithm QuietestV913 -- EES
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


-----------------------------------------------------------
-- Algorithm Quickest913 -- Web
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Dll'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV913.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-----------------------------------------------------------
-- Algorithm RecreationalV913 -- EES
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



-----------------------------------------------------------
-- Algorithm RecreationalV913 -- Web
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Dll'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV913.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


----------------------------------------------------------
-- Algorithm EasiestV815 -- EES
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END





-----------------------------------------------------------
-- Algorithm EasiestV913 -- Web
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Dll' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Dll', 'td.cp.CyclePenaltyFunctions.v3.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v3.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Dll'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.EasiestV815.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1770
SET @ScriptDesc = 'Script to add/update Cycle Planner algorithm properties (ATO687)'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO