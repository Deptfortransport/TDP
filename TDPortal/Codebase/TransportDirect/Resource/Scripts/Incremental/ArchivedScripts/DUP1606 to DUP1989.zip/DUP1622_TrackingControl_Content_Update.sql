-- ***********************************************
-- NAME 		: DUP1622_TrackingControl_Content_Update.sql
-- DESCRIPTION 		: Script to add Tracking user control content
-- AUTHOR		: Parvez Ghumra
-- DATE			: 16 Mar 2010
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'TrackingControl.TagContent', '<!-- Start of Intellitracker Tag -->
<script type="text/javascript"><!-- 
var pqry="iAddPAR";
var rqry="iREGQry";
var sqry="iSale";

var dt=window.document,nr=navigator,ina=nr.appName,sr="0&0",px=0,je=0,sv=10;
var sev=0/*@cc_on+@_jscript_version*10@*/; if(sev>=30){je=(nr.javaEnabled()?1:2);sv=(sev>=50?14:13);}else{sv=11};
var inav=nr.appVersion,iie=inav.indexOf(''MSIE ''),intp=(ina.indexOf(''Netscape'')>=0);
if(iie>0)inavi=parseInt(inav.substring(iie+5));else inavi=parseFloat(inav);
if(screen){px=(iie>0?screen.colorDepth:screen.pixelDepth);sr=screen.width+"&"+screen.height};
function irs(s,f,r){var p=s.indexOf(f);while(p>=0){s=s.substring(0,p)+r+s.substring(p+f.length,s.length);p=s.indexOf(f)}return s}
function cesc(s){if(s.length>0) return irs(irs(irs(irs(irs(s,''+'',''%2B''),''.'',''%2E''),''/'',''%2F''),''='',''%3D''),''&'',''%26'') ; else return s;}
function iesc(s){return cesc(escape(s));} 
function gpr(){
var pr='''', ipw=window, ipr=''window'', iwL='''', ipL='''';
while (ipL==iwL){
iw=ipw; pr=iw.document.referrer;
if(intp) break;if((''''+iw.parent.location)=='''')break;
iwL=(iw.document.location.protocol+''\/\/''+iw.document.location.hostname).toLowerCase();
ipL=pr.substring(0,iwL.length).toLowerCase();
ipr=ipr+''.parent''; ipw=eval(ipr); if (iw==ipw) break;}return pr;}
function itrc(){var nw=new Date(),ce=2,iul='''';
if (dt.cookie) ce=1;
else {var ex=new Date(nw.getTime()+1000); dt.cookie="itc=3; EXPIRES="+ex.toGMTString()+"; path=/";if (dt.cookie) ce=1;}		
if(inavi>=4) iul=iesc(iie>0&&nr.userLanguage?nr.userLanguage:nr.language);
var un=Math.round(Math.random()*2100000000);
il=isl+un+"&"+iesc(gpr())+"%20&"+cesc(pqry)+"%20&"+cesc(rqry)+"%20&"
+cesc(sqry)+"%20&"+ce+"&"+sr+"&"+px+"&"+je+"&"+sv+"&"+iul+"%20&"+nw.getTimezoneOffset()+"&"+iesc(idl)+"%20";
if(iie>0 && il.length>2045)il=il.substring(0,2045);
var iin=''itr1282'', iwri=true;
if(dt.images){if(!dt.images[iin])dt.write(''<div style="display:none"><i''+''mg name="''+iin+''" height="1" width="1" alt="IntelliTracker"/></div>'');
if(dt.images[iin]){dt.images[iin].src=il+''&0'';iwri=false;}}
if(iwri)dt.write(''<i''+''mg sr''+''c="''+il+''&0" height="1" width="1">'');}
var idl=window.location.href;var isl="http"+(idl.indexOf(''https:'')==0?''s'':'''')+"://tags.transportdirect.info/e/t3.dll?1282&";
itrc();
//--></script>

<script type="text/javascript"><!--
if(iie>0)dt.write("\<\!\-\-");
//--></script><noscript>
<div style="display:none"><img src=''http://tags.transportdirect.info/e/t3.dll?1282&amp;0&amp;%20&amp;iAddPAR&amp;iREGQry&amp;iSale&amp;0&amp;0&amp;0&amp;0&amp;0&amp;0&amp;%20&amp;1500&amp;%20&amp;0'' height="1" width="1" alt="IntelliTracker"/></div>
</noscript><!--//-->
<!-- End of Intellitracker Tag -->', '<!-- Start of Intellitracker Tag -->
<script type="text/javascript"><!-- 
var pqry="iAddPAR";
var rqry="iREGQry";
var sqry="iSale";

var dt=window.document,nr=navigator,ina=nr.appName,sr="0&0",px=0,je=0,sv=10;
var sev=0/*@cc_on+@_jscript_version*10@*/; if(sev>=30){je=(nr.javaEnabled()?1:2);sv=(sev>=50?14:13);}else{sv=11};
var inav=nr.appVersion,iie=inav.indexOf(''MSIE ''),intp=(ina.indexOf(''Netscape'')>=0);
if(iie>0)inavi=parseInt(inav.substring(iie+5));else inavi=parseFloat(inav);
if(screen){px=(iie>0?screen.colorDepth:screen.pixelDepth);sr=screen.width+"&"+screen.height};
function irs(s,f,r){var p=s.indexOf(f);while(p>=0){s=s.substring(0,p)+r+s.substring(p+f.length,s.length);p=s.indexOf(f)}return s}
function cesc(s){if(s.length>0) return irs(irs(irs(irs(irs(s,''+'',''%2B''),''.'',''%2E''),''/'',''%2F''),''='',''%3D''),''&'',''%26'') ; else return s;}
function iesc(s){return cesc(escape(s));} 
function gpr(){
var pr='''', ipw=window, ipr=''window'', iwL='''', ipL='''';
while (ipL==iwL){
iw=ipw; pr=iw.document.referrer;
if(intp) break;if((''''+iw.parent.location)=='''')break;
iwL=(iw.document.location.protocol+''\/\/''+iw.document.location.hostname).toLowerCase();
ipL=pr.substring(0,iwL.length).toLowerCase();
ipr=ipr+''.parent''; ipw=eval(ipr); if (iw==ipw) break;}return pr;}
function itrc(){var nw=new Date(),ce=2,iul='''';
if (dt.cookie) ce=1;
else {var ex=new Date(nw.getTime()+1000); dt.cookie="itc=3; EXPIRES="+ex.toGMTString()+"; path=/";if (dt.cookie) ce=1;}		
if(inavi>=4) iul=iesc(iie>0&&nr.userLanguage?nr.userLanguage:nr.language);
var un=Math.round(Math.random()*2100000000);
il=isl+un+"&"+iesc(gpr())+"%20&"+cesc(pqry)+"%20&"+cesc(rqry)+"%20&"
+cesc(sqry)+"%20&"+ce+"&"+sr+"&"+px+"&"+je+"&"+sv+"&"+iul+"%20&"+nw.getTimezoneOffset()+"&"+iesc(idl)+"%20";
if(iie>0 && il.length>2045)il=il.substring(0,2045);
var iin=''itr1282'', iwri=true;
if(dt.images){if(!dt.images[iin])dt.write(''<div style="display:none"><i''+''mg name="''+iin+''" height="1" width="1" alt="IntelliTracker"/></div>'');
if(dt.images[iin]){dt.images[iin].src=il+''&0'';iwri=false;}}
if(iwri)dt.write(''<i''+''mg sr''+''c="''+il+''&0" height="1" width="1">'');}
var idl=window.location.href;var isl="http"+(idl.indexOf(''https:'')==0?''s'':'''')+"://tags.transportdirect.info/e/t3.dll?1282&";
itrc();
//--></script>

<script type="text/javascript"><!--
if(iie>0)dt.write("\<\!\-\-");
//--></script><noscript>
<div style="display:none"><img src=''http://tags.transportdirect.info/e/t3.dll?1282&amp;0&amp;%20&amp;iAddPAR&amp;iREGQry&amp;iSale&amp;0&amp;0&amp;0&amp;0&amp;0&amp;0&amp;%20&amp;1500&amp;%20&amp;0'' height="1" width="1" alt="IntelliTracker"/></div>
</noscript><!--//-->
<!-- End of Intellitracker Tag -->'

Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1622
SET @ScriptDesc = 'Script to update Tracking user control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO