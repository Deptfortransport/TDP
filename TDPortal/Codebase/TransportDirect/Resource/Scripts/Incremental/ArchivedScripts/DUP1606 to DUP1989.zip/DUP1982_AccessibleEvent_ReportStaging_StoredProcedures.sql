-- ***********************************************
-- NAME 		: DUP1982_AccessibleEvent_ReportStaging_StoredProcedures.sql
-- DESCRIPTION 	: Script to add stored procedures to create AccessibleEvent
-- AUTHOR		: David Lane
-- DATE			: 18 Jan 2013
-- ************************************************

USE [ReportStagingDB]
GO


-- ****IMPORTANT****
-- If running this script in the Production environment, please uncomment the lines with value "ReportServer.", and comment out the line below it.
-- There are 2 instances of this in the script.

----------------------------------------------------------------
-- Create AddAccessibleEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddAccessibleEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddAccessibleEvent
        (
			 @AccessibleEventType varchar(50),
			 @Submitted datetime,
			 @TimeLogged datetime)
			AS
			BEGIN 
				SET NOCOUNT ON 
			END
		')

END
GO


----------------------------------------------------------------
-- Update AddGISQueryEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE AddAccessibleEvent (
			 @AccessibleEventType varchar(50),
			 @Submitted datetime,
			 @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into AccessibleEvent Table'

    Insert into AccessibleEvent (AccessibleType, Submitted, TimeLogged)
    Values (@AccessibleEventType, @Submitted, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Create TransferGISQueryEvents stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferAccessibleEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE TransferAccessibleEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferGISQueryEvents stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE TransferAccessibleEvents
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

DELETE FROM [Reporting].[dbo].[AccessibleEvents]
WHERE CONVERT(varchar(10), AEDate, 121) = @Date

INSERT INTO [Reporting].[dbo].[AccessibleEvents]
(
	AEDate,
	AEHour,
	AEHourQuarter,
	AEWeekDay,
	AETID,
	AECount
)
SELECT 
	CAST(CONVERT(varchar(10), AE.Submitted, 121) AS datetime) AS AEDate,
	DATEPART(hour, AE.Submitted) AS AEHour,
	CAST(DATEPART(minute, AE.Submitted) / 15 AS smallint) AS AEHourQuarter,
	DATEPART(weekday, AE.Submitted) AS AEWeekDay,
	AET.AETID AS AETID,
	COUNT(*) AS AECount

  FROM AccessibleEvent AE
  LEFT OUTER JOIN Reporting.dbo.AccessibleEventType AET ON AE.AccessibleType = AET.AETCode
  WHERE CONVERT(varchar(10), AE.Submitted, 121) = @Date
  GROUP BY
	CAST(CONVERT(varchar(10), AE.Submitted, 121) AS datetime),
	DATEPART(hour, AE.Submitted),
	CAST(DATEPART(minute, AE.Submitted) / 15 AS smallint),
	DATEPART(weekday, AE.Submitted),
	AET.AETID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- Grant permissions - will only work for relevant users as only they
-- will exist
GRANT  EXECUTE  ON [dbo].[AddAccessibleEvent]  TO [BBPTDPSIW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddAccessibleEvent]  TO [BBPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddAccessibleEvent]  TO [ACPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddAccessibleEvent]  TO [BBPTDPSIS\aspuser]
GRANT  EXECUTE  ON [dbo].[AddAccessibleEvent]  TO [BBPTDPS\aspuser]
GRANT  EXECUTE  ON [dbo].[AddAccessibleEvent]  TO [ACPTDPS\aspuser]

GRANT  EXECUTE  ON [dbo].[TransferAccessibleEvents]  TO [BBPTDPSIS\aspuser]
GRANT  EXECUTE  ON [dbo].[TransferAccessibleEvents]  TO [BBPTDPS\aspuser]
GRANT  EXECUTE  ON [dbo].[TransferAccessibleEvents]  TO [ACPTDPS\aspuser]

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1982
SET @ScriptDesc = 'Add ReportStaging stored procedures for AccessibleEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO