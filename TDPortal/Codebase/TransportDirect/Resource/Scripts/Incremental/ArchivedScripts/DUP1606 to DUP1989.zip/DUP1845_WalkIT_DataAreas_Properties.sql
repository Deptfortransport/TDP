-- ***********************************************
-- NAME          : DUP1845_WalkIT_DataAreas_Properties.sql
-- DESCRIPTION   : Script to add property to change WalkIT data areas check
-- AUTHOR        : Mark Turner
-- DATE          : 30 Nov 2011
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'WalkitControl.PlanSameAreaOnly')
BEGIN
	INSERT INTO properties VALUES ('WalkitControl.PlanSameAreaOnly', 'false', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'WalkitControl.PlanSameAreaOnly'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1845
SET @ScriptDesc = 'Script to add property to change WalkIT data areas check'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO