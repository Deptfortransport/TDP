-- ***********************************************
-- NAME 		: DUP1648_ServiceDetails_Spelling_Content_Update.sql
-- DESCRIPTION 	: Script to correct a spelling mistake on the Service Details page
-- AUTHOR		: Richard Hopkins
-- DATE			: 07 April 2010
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'ServiceDetails.serviceHeaderLabel.Text',
	'Service detail for stop {0}',
	'Service detail for stop {0}'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1648
SET @ScriptDesc = 'Script to correct a spelling mistake on the Service Details page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO