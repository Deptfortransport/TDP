-- ***********************************************
-- NAME           : DUP1909_LocationSuggest_Tables.sql
-- DESCRIPTION    : Script to create location auto suggest tables
-- AUTHOR         : Mitesh Modi
-- DATE           : 07 Aug 2012
-- ***********************************************

USE [AtosAdditionalData]
GO 

-- **************************************
-- SCRIPT NO LONGER REQUIRED, TDLocations TABLE IS NOW CREATED IN THE GAZ DATABASE 
-- AS PART OF THE ESRI DATA LOAD
-- **************************************

-- Drop existing table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TDLocations]') AND type in (N'U'))
BEGIN
	DROP TABLE [dbo].[TDLocations]
END
GO

---- Create table
--IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[TDLocations]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--BEGIN

--	CREATE TABLE [dbo].[TDLocations](
--		[ID]            INT           IDENTITY (1, 1) NOT NULL,
--		[DATASETID]     VARCHAR (50)  NOT NULL,
--		[ParentID]      VARCHAR (50)  NULL,
--		[Name]          VARCHAR (100) NOT NULL,
--		[DisplayName]   VARCHAR (100) NOT NULL,
--		[Type]          VARCHAR (20)  NOT NULL,
--		[Naptan]        VARCHAR (20)  NULL,
--		[LocalityID]    VARCHAR (20)  NULL,
--		[Easting]       FLOAT         NOT NULL,
--		[Northing]      FLOAT         NOT NULL,
--	    [NearestTOID]   VARCHAR (50)  NULL,
--		[NearestPointE] FLOAT         NULL,
--	    [NearestPointN] FLOAT         NULL,
--		[AdminAreaID]   INT           NULL,
--		[DistrictID]    INT           NULL
--	)
	
--END

---- Add primary key
--ALTER TABLE [dbo].[TDLocations]
--	ADD CONSTRAINT [PK_TDLocations]
--	PRIMARY KEY ([ID]) WITH (ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF);
	
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1909
SET @ScriptDesc = 'Script to create location auto suggest tables'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO