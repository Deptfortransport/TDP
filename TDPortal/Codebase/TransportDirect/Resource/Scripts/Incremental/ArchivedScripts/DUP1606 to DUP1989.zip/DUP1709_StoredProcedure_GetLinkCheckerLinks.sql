-- ***********************************************
-- NAME 		: DUPxxxx_StoredProcedure_GetLinkCheckerLinks.sql
-- DESCRIPTION 	: Script to create a stored procedure GetLinkCheckerLinks
--                for use by the LinkCheckerService
-- AUTHOR		: Richard Hopkins
-- DATE			: 21 May 2010
-- ************************************************

-------------------------------------------------------------


USE [TransientPortal]
GO

----------------------------------------------------------------
-- Create blank GetLinkCheckerLinks stored proc if none exists
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLinkCheckerLinks]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
		CREATE  PROCEDURE [dbo].[GetLinkCheckerLinks]
		AS
    ')

END
GO

---------------------------------------------------------------------
-- Update GetLinkCheckerLinks Proc
---------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO


ALTER PROCEDURE [dbo].[GetLinkCheckerLinks]
AS
	SELECT
		ExternalLinks.[Description] LinkSource,
		ExternalLinks.URL LinkURL,
		LinkCategory.[Name] CategoryName,
		Context.[Name] ContextName,
		Context.[Description] ContextDescription,
		Resource.[Text] ResourceString,
		ExternalLinks.Id LinkId,
		ContextSuggestionLink.ThemeId ThemeId,
		ExternalLinks.Valid IsValid,
		ExternalLinks.StartDate LinkStartDate,
		ExternalLinks.EndDate LinkEndDate
	FROM ExternalLinks
	LEFT OUTER JOIN ExternalSuggestionLink
		ON ExternalLinks.[Id] = ExternalSuggestionLink.ExternalLinkID
	LEFT OUTER JOIN SuggestionLink
		ON SuggestionLink.ExternalInternalLinkId = ExternalSuggestionLink.ExternalSuggestionLinkID
			AND SuggestionLink.ExternalInternalLinkType = 'External'
	LEFT OUTER JOIN ContextSuggestionLink
		ON SuggestionLink.SuggestionLinkId = ContextSuggestionLink.SuggestionLinkId
	LEFT OUTER JOIN Context
		ON ContextSuggestionLink.ContextId = Context.ContextId
	LEFT OUTER JOIN LinkCategory
		ON SuggestionLink.LinkCategoryId = LinkCategory.LinkCategoryId
	LEFT OUTER JOIN ResourceName
		ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
	LEFT OUTER JOIN Resource
		ON ResourceName.ResourceNameId = Resource.ResourceNameId
			AND Resource.Culture = 'en-GB'
ORDER BY ExternalLinks.[Description], ExternalLinks.URL, LinkCategory.[Name], Context.[Name], ContextSuggestionLink.ThemeId

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1709
SET @ScriptDesc = 'Add GetLinkCheckerLinks stored procedure for use by LinkCheckerService'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
