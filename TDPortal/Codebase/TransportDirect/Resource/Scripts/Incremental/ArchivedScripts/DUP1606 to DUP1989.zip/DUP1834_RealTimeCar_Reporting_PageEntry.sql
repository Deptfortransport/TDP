-- ***********************************************
-- NAME 		: DUP1834_RealTimeCar_Reporting_PageEntry.sql
-- DESCRIPTION 	: Added reporting page entry event type for Real Time Information in Car
-- AUTHOR		: Amit Patel
-- DATE			: 16 Sep 2011
-- ************************************************

USE [Reporting]
GO

-- Add new page entries for reporting
IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'TDWebService') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'TDWebService', 'TD Web Service' FROM PageEntryType
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1834
SET @ScriptDesc = 'Added reporting page entry event type for Real Time Information in Car'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO