-- ************************************************************
-- NAME 		: DUP1706_ExternalLinks_Update.sql
-- DESCRIPTION 	: Updates external links used by Live Departure Boards
-- AUTHOR		: Richard Hopkins
-- DATE         : 7 May 2010
-- ************************************************************


USE [TransientPortal]
GO
/****** Object:  StoredProcedure [dbo].[AddExternalLink]    Script Date: 05/05/2010 16:50:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
 
ALTER PROCEDURE [dbo].[AddExternalLink]
(	
	@LinkId varchar(500),	
	@URL varchar(500),
	@TestURL varchar(1000),
	@Description varchar(1000),
	@LinkText varchar(1000) = ''
)
As
    set nocount off

    declare @localized_string_UnableToCarryOutAction AS nvarchar(256)   

    IF EXISTS (SELECT * FROM ExternalLinks WHERE ID = @LinkId)
	  BEGIN
	    SET @localized_string_UnableToCarryOutAction = 'Unable to update record ' + CAST(@LinkID AS varchar(500)) + ' in External Links table'
	    IF @LinkText <> ''
	    BEGIN
		    UPDATE ExternalLinks
		    SET URL = @URL, 
			TestURL =@TestURL,
			Valid = 1,
			[Description] = @Description,
			LinkText = @LinkText
			WHERE ID = @LinkId
		END
	    ELSE
	    BEGIN
		    UPDATE ExternalLinks
		    SET URL = @URL, 
			TestURL =@TestURL,
			Valid = 1,
			[Description] = @Description
			WHERE ID = @LinkId
		END
	  END
	ELSE
	  BEGIN
	    SET @localized_string_UnableToCarryOutAction = 'Unable to insert a new record ' +  CAST(@LinkID AS varchar(500)) +  ' into External Links table'
	    IF @LinkText <> ''
	    BEGIN
		    INSERT INTO ExternalLinks ([Id],URL,TestURL, Valid, [Description], LinkText)
		    VALUES (@LinkID, @URL, @TestURL, 1, @Description, @LinkText )
		END
		ELSE
	    BEGIN
		    INSERT INTO ExternalLinks ([Id],URL,TestURL, Valid, [Description])
		    VALUES (@LinkID, @URL, @TestURL, 1, @Description )
		END
	  END

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToCarryOutAction, 1,1)
        return -1
    end
    else
    begin
	 return @@rowcount
    End


GO


USE TransientPortal
GO

EXEC AddExternalLink 'DepartureBoard.Train.1', 'http://www.nationalrail.co.uk/times_fares/ldb/', 'http://www.nationalrail.co.uk/times_fares/ldb/', 'Departure Board - National Rail', 'http://www.nationalrail.co.uk/times_fares/ldb/'

EXEC AddExternalLink 'DepartureBoard.Bus.2', 'http://www.acis.uk.com/ACIS-Live.aspx', 'http://www.acis.uk.com/ACIS-Live.aspx', 'Departure Board - Acis Live', 'http://www.acis.uk.com/ACIS-Live.aspx'


UPDATE dbo.ChangeNotification SET
		[Version] = [Version] + 1
		Where [Table] like '%ExternalLinks%'

GO

-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1706
SET @ScriptDesc = 'Updates external links used by Live Departure Boards'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
