-- ***********************************************
-- NAME 		: DUP1977_JourneyPlanRequestEvent_ReportStaging_Tables.sql
-- DESCRIPTION 	: Update table JourneyPlanRequestEvent with mode Telecabine
-- AUTHOR		: Mitesh Modi
-- DATE			: 22 Jan 13
-- ***********************************************

USE [ReportStagingDB]
GO

----------------------------------------------------------------
-- Create/Alter [JourneyPlanRequestEvent] table, it should already exist
----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JourneyPlanRequestEvent]') AND type in (N'U'))
BEGIN

	CREATE TABLE [dbo].[JourneyPlanRequestEvent](
		[Id] [bigint] IDENTITY(1,1) NOT NULL,
		[JourneyPlanRequestId] [varchar](50) NULL,
		[Air] [bit] NULL,
		[Bus] [bit] NULL,
		[Car] [bit] NULL,
		[Coach] [bit] NULL,
		[Cycle] [bit] NULL,
		[Drt] [bit] NULL,
		[Ferry] [bit] NULL,
		[Metro] [bit] NULL,
		[Rail] [bit] NULL,
		[Taxi] [bit] NULL,
		[Telecabine] [bit] NULL,
		[Tram] [bit] NULL,
		[Underground] [bit] NULL,
		[Walk] [bit] NULL,
		[SessionId] [varchar](50) NULL,
		[UserLoggedOn] [bit] NULL,
		[TimeLogged] [datetime] NULL
	) ON [PRIMARY]

END

ELSE
BEGIN
	if not exists(select * from sys.columns where Name = N'Telecabine' and Object_ID = Object_ID(N'JourneyPlanRequestEvent'))    
	begin
		-- Add telecabine column
		ALTER TABLE [dbo].[JourneyPlanRequestEvent] ADD [Telecabine] [bit] NULL
		CONSTRAINT AddTelecabine DEFAULT 0 WITH VALUES ;
	end
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1977
SET @ScriptDesc = 'Update table JourneyPlanRequestEvent with mode Telecabine'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
