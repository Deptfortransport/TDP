-- ***********************************************
-- NAME 		: DUP1956_AccessibleLocation_Reporting.sql
-- DESCRIPTION 	: Accessibility options - Reporting updates
-- AUTHOR		: Mitesh Modi
-- DATE			: 04 Jan 12
-- ************************************************

USE [Reporting]
GO

-- Page entry events
IF NOT EXISTS (SELECT TOP 1 * FROM [PageEntryType] WHERE [PETCode] = 'FindNearestAccessibleStop')
BEGIN
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindNearestAccessibleStop', 'Find nearest accessible stop' FROM PageEntryType
END

IF NOT EXISTS (SELECT TOP 1 * FROM [PageEntryType] WHERE [PETCode] = 'FindNearestAccessibleStopTransportClickAJAX')
BEGIN
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindNearestAccessibleStopTransportClickAJAX', 'Find nearest accessible stop transport click AJAX' FROM PageEntryType
END

IF NOT EXISTS (SELECT TOP 1 * FROM [PageEntryType] WHERE [PETCode] = 'FindNearestAccessibleStopMapClickAJAX')
BEGIN
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindNearestAccessibleStopMapClickAJAX', 'Find nearest accessible stop view map click AJAX' FROM PageEntryType
END

IF NOT EXISTS (SELECT TOP 1 * FROM [PageEntryType] WHERE [PETCode] = 'FindNearestAccessibleStopMapHideClickAJAX')
BEGIN
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindNearestAccessibleStopMapHideClickAJAX', 'Find nearest accessible stop hide map click AJAX' FROM PageEntryType
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1956
SET @ScriptDesc = 'Acccessibility options reporting upates'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO