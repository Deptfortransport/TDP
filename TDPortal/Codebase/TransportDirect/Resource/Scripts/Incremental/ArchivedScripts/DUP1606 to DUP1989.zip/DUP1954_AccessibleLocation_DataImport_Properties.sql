-- ***********************************************
-- NAME 		: DUP1954_AccessibleLocation_DataImport_Properties.sql
-- DESCRIPTION 	: Script to update data import properties for Accessible locations
-- AUTHOR		: Mitesh Modi
-- DATE			: 14 Nov 2012
-- ************************************************


-- ****************** IMPORTANT **************************
-- Please change the @gatewayPath value path to be as required for 
-- the environment
-- *******************************************************

USE [PermanentPortal]
GO

DECLARE @gatewayPath varchar(30) = 'C:\Gateway\xml'

-- Clear all existing properties
DELETE FROM [dbo].[properties]
WHERE  pName LIKE 'datagateway.sqlimport.AccessibleLocationsData%'

DELETE FROM [dbo].[properties]
WHERE  pName LIKE 'datagateway.sqlimport.AccessibleAdminAreasData%'

-- AID and GID
DECLARE @AID varchar(50) = ''
DECLARE @GID varchar(50) = 'DataGateway'

-- Accessible Locations Data
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.database', @AID, @GID, 0, 1, N'AtosAdditionalDataDB')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.feedname', @AID, @GID, 0, 1, N'mkw489')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.Name', @AID, @GID, 0, 1, N'AccessibleLocationsData')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.schemea', @AID, @GID, 0, 1, @gatewayPath + N'\AccessibleLocations.xsd')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.sqlcommandtimeout', @AID, @GID, 0, 1, N'3000')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.storedprocedure', @AID, @GID, 0, 1, N'ImportAccessibleLocationsData')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.xmlnamespace', @AID, @GID, 0, 1, N'http://www.transportdirect.info/AccessibleLocations')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleLocationsData.xmlnamespacexsi', @AID, @GID, 0, 1, N'http://www.w3.org/2001/XMLSchema-instance')

-- Accessible AdminAreas Data

INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.database', @AID, @GID, 0, 1, N'AtosAdditionalDataDB')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.feedname', @AID, @GID, 0, 1, N'sul834')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.Name', @AID, @GID, 0, 1, N'AccessibleAdminAreasData')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.schemea', @AID, @GID, 0, 1, @gatewayPath + N'\AccessibleAdminAreas.xsd')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.sqlcommandtimeout', @AID, @GID, 0, 1, N'3000')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.storedprocedure', @AID, @GID, 0, 1, N'ImportAccessibleAdminAreasData')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.xmlnamespace', @AID, @GID, 0, 1, N'http://www.transportdirect.info/AccessibleAdminAreas')
INSERT INTO [dbo].[properties] ([pName], [AID], [GID], [PartnerId], [ThemeId], [pValue]) VALUES (N'datagateway.sqlimport.AccessibleAdminAreasData.xmlnamespacexsi', @AID, @GID, 0, 1, N'http://www.w3.org/2001/XMLSchema-instance')

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1954
SET @ScriptDesc = 'Script to update data import properties for Accessible locations'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO