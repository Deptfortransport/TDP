-- ***********************************************
-- NAME           : DUP1947_DataNotification_StoredProc.sql
-- DESCRIPTION    : Script to add data notification helper stored procs
-- AUTHOR         : Mitesh Modi
-- DATE           : 06 Dec 2012
-- ***********************************************

-- The script adds the following stored procedures
-- [AtosAdditionalData].[dbo].[AddChangeNotificationTable]
-- [PermanentPortal].[dbo].[AddChangeNotificationTable]
-- [TransientPortal].[dbo].[AddChangeNotificationTable]

-- [PermanentPortal].[dbo].[AddDataNotificationGroup]
-- [PermanentPortal].[dbo].[AddDataNotificationDatabase]
-- [PermanentPortal].[dbo].[AddDataNotificationTable]

USE [AtosAdditionalData]
GO

-- ***********************************************
-- Create AddChangeNotificationTable stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddChangeNotificationTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddChangeNotificationTable
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[AddChangeNotificationTable]
(
	@changeNotifTable varchar(100),
	@version int
)
AS
BEGIN
    
    IF EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] like @changeNotifTable)
	BEGIN
		DELETE FROM [ChangeNotification] WHERE [Table] like @changeNotifTable
	END

	INSERT INTO [ChangeNotification]([Table], [Version])
	VALUES (@changeNotifTable, @version)
END
GO


USE [PermanentPortal]
GO

-- ***********************************************
-- Create AddChangeNotificationTable stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddChangeNotificationTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddChangeNotificationTable
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[AddChangeNotificationTable]
(
	@changeNotifTable varchar(100),
	@version int
)
AS
BEGIN
    
    IF EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] like @changeNotifTable)
	BEGIN
		DELETE FROM [ChangeNotification] WHERE [Table] like @changeNotifTable
	END

	INSERT INTO [ChangeNotification]([Table], [Version])
	VALUES (@changeNotifTable, @version)
END
GO


USE [TransientPortal]
GO

-- ***********************************************
-- Create AddChangeNotificationTable stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddChangeNotificationTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddChangeNotificationTable
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[AddChangeNotificationTable]
(
	@changeNotifTable varchar(100),
	@version int
)
AS
BEGIN
    
    IF EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] like @changeNotifTable)
	BEGIN
		DELETE FROM [ChangeNotification] WHERE [Table] like @changeNotifTable
	END

	INSERT INTO [ChangeNotification]([Table], [Version])
	VALUES (@changeNotifTable, @version)
END
GO



USE [PermanentPortal]
GO

-- ***********************************************
-- Create AddDataNotificationGroup stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDataNotificationGroup]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddDataNotificationGroup
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[AddDataNotificationGroup]
(
	@DataNotificationGroup varchar(100),
	@AID VARCHAR(20),
	@GID VARCHAR(20)
)
AS
BEGIN
    
    DECLARE @dataNotificationGroups VARCHAR(500)
    
	-- read existing groups value, this will be updated to include the new group (if it doesnt contain already)
	SET @dataNotificationGroups = ( select pValue 
									  from properties 
									 where pName = 'DataServices.DataNotification.Groups' 
									   and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)

	IF EXISTS (select top 1 * from properties 
				where pName = 'DataServices.DataNotification.Groups' 
				  and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)
	BEGIN
		-- This prevents adding the change notification group multiple 
		-- times if run more than once
		IF NOT EXISTS ( select top 1 * from properties 
						 where pvalue like '%' + @DataNotificationGroup + '%' 
						   and pName = 'DataServices.DataNotification.Groups' 
						   and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)
		BEGIN
    		update properties 
			   set pvalue = @dataNotificationGroups + ',' + @DataNotificationGroup
    		 where pName = 'DataServices.DataNotification.Groups' 
    		   and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1
		END
	END
    
    
END
GO

-- ***********************************************
-- Create AddDataNotificationDatabase stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDataNotificationDatabase]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddDataNotificationDatabase
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[AddDataNotificationDatabase]
(
	@DataNotificationGroup varchar(100),
	@DataNotificationDatabase varchar(100)
)
AS
BEGIN
    
    IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.' + @DataNotificationGroup + '.Database')
	BEGIN
		INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
		VALUES ('DataServices.DataNotification.' + @DataNotificationGroup + '.Database', @DataNotificationDatabase, '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
    ELSE
    BEGIN
		UPDATE properties 
		   SET pvalue = @DataNotificationDatabase
         WHERE pName = 'DataServices.DataNotification.' + @DataNotificationGroup + '.Database'
    END
    
END
GO


-- ***********************************************
-- Create AddDataNotificationTable stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddDataNotificationTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddDataNotificationTable
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[AddDataNotificationTable]
(
	@DataNotificationGroup varchar(100),
	@DataNotificationTable varchar(100)
)
AS
BEGIN
    
    IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.' + @DataNotificationGroup + '.Tables')
	BEGIN
		INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
		VALUES ('DataServices.DataNotification.' + @DataNotificationGroup + '.Tables', @DataNotificationTable, '<DEFAULT>', '<DEFAULT>', 0, 1)
	END
    ELSE
    BEGIN
		
		DECLARE @dataNotificationTables VARCHAR(500)
		
		-- read existing tables value, this will be updated to include the new table (if it doesnt contain already)
		SET @dataNotificationTables = (SELECT top 1 pValue 
		                                 FROM properties 
		                                WHERE [pName] = 'DataServices.DataNotification.' + @DataNotificationGroup + '.Tables')
		
		-- This prevents adding the change notification table to group multiple 
		-- times if run more than once
		IF NOT EXISTS ( select top 1 * from properties 
						 where [pName] = 'DataServices.DataNotification.' + @DataNotificationGroup + '.Tables'
						   and [pValue]like '%' + @DataNotificationTable + '%')
		BEGIN
    		UPDATE properties 
			   SET pvalue = @dataNotificationTables + ',' + @DataNotificationTable
    		 WHERE pName = 'DataServices.DataNotification.' + @DataNotificationGroup + '.Tables'
		END
		
    END
    
END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1947
SET @ScriptDesc = 'Script to add data notification helper stored procs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO