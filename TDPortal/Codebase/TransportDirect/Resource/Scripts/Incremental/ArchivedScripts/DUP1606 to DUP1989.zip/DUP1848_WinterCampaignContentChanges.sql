-- ***********************************************
-- NAME           : DUP1948_WinterCampaignContentChanges.sql
-- DESCRIPTION    : Script to add Winter Campaign content
-- AUTHOR         : Phil Scott
-- DATE           : 30/11/2011
-- ***********************************************

USE [Content] 
GO

EXEC AddContentOverride
'home', 1, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, 
'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://travel.london2012.com/ Web/Pages/JourneyPlannerInput.aspx">Heading to the Games? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://travel.london2012.com/SJPWeb/Pages/JourneyPlannerInput.aspx">
    <img title="Spectator Journey Planner" alt="Spectator Journey Planner" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/SJPLinkIcon.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Christmas shopping?
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCycle" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/finda_CarPark25.gif"
          border="0" />
        </td>
        <td class="txtseven">Follow this link for directions to a park &amp; ride
		site near you. <br/>
        <a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park &amp; ride.</a><br/><br/>
		Alternatively, <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
		has details of nearby car parks including prices, number of spaces and opening times.
      </tr>
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Driving home at Christmas? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>'
, 
'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://travel.london2012.com/ Web/Pages/JourneyPlannerInput.aspx">Heading to the Games? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://travel.london2012.com/SJPWeb/Pages/JourneyPlannerInput.aspx">
    <img title="Spectator Journey Planner" alt="Spectator Journey Planner" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/SJPLinkIcon.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Christmas shopping?
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCycle" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/finda_CarPark25.gif"
          border="0" />
        </td>
        <td class="txtseven">Follow this link for directions to a park &amp; ride
		site near you. <br/>
        <a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park &amp; ride.</a><br/><br/>
		Alternatively, <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
		has details of nearby car parks including prices, number of spaces and opening times.
      </tr>
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Driving home at Christmas? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>'
,'2011-11-30','2011-12-26'




GO



EXEC AddContentOverride
'home', 1, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, 
'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://travel.london2012.com/ Web/Pages/JourneyPlannerInput.aspx">Heading to the Games? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://travel.london2012.com/SJPWeb/Pages/JourneyPlannerInput.aspx">
    <img title="Spectator Journey Planner" alt="Spectator Journey Planner" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/SJPLinkIcon.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Christmas shopping?
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCycle" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/finda_CarPark25.gif"
          border="0" />
        </td>
        <td class="txtseven">Follow this link for directions to a park &amp; ride
		site near you. <br/>
        <a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park &amp; ride.</a><br/><br/>
		Alternatively, <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
		has details of nearby car parks including prices, number of spaces and opening times.
      </tr>
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>'
, 
'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://travel.london2012.com/ Web/Pages/JourneyPlannerInput.aspx">Heading to the Games? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://travel.london2012.com/SJPWeb/Pages/JourneyPlannerInput.aspx">
    <img title="Spectator Journey Planner" alt="Spectator Journey Planner" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/SJPLinkIcon.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Christmas shopping?
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCycle" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/finda_CarPark25.gif"
          border="0" />
        </td>
        <td class="txtseven">Follow this link for directions to a park &amp; ride
		site near you. <br/>
        <a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park &amp; ride.</a><br/><br/>
		Alternatively, <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
		has details of nearby car parks including prices, number of spaces and opening times.
      </tr>
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>'
,'2011-12-26','2012-03-30'




GO




-- DirectGov changes

EXEC AddContentOverride
'home', 5, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Driving home at Christmas? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Find schools and childcare in your area</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare"/>
</td>
<td class="txtseven" valign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br/><br/>
<a href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</a>
</td></tr></tbody></table></div>', 

'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Driving home at Christmas? <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Find schools and childcare in your area</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare"/>
</td>
<td class="txtseven" valign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br/><br/>
<a href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</a>
</td></tr></tbody></table></div>'
,'2011-11-30','2011-12-26'

-- DirectGov changes

EXEC AddContentOverride
'home', 5, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Find schools and childcare in your area</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare"/>
</td>
<td class="txtseven" valign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br/><br/>
<a href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</a>
</td></tr></tbody></table></div>', 

'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/winter2011">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/winter2011">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Find schools and childcare in your area</div>
<div class="clearboth" ></div>
</div>
<div class="Column3Content">
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">
<tbody>
<tr>
<td class="VertAlignTop">
<img src="/Web2/app_themes/directgov/images/gifs/partner/childcare.gif" alt="Schools and Childcare"/>
</td>
<td class="txtseven" valign="top">
Use a simple postcode search to get listings of primary and secondary schools, childcare and nurseries in your area. You can also access Ofsted reports and related information.
<br/><br/>
<a href="http://schoolsfinder.direct.gov.uk/" >
Search for schools and childcare</a>
</td></tr></tbody></table></div>'
,'2011-12-26','2012-03-30'



go





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1948
SET @ScriptDesc = 'Winter Campaign Content Changes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO