-- ****************************************************************
-- NAME 		: DUP1755_CategorisedHashes__Table_Update.sql
-- DESCRIPTION 	: Script to update CategorisedHashes table
-- AUTHOR		: Amit Patel
-- DATE			: 30 Sep 2010
-- ****************************************************************


USE [PermanentPortal] 
GO

IF NOT EXISTS (SELECT * FROM syscolumns
  WHERE id=object_id('CategorisedHashes') AND name='Data1')
    ALTER TABLE CategorisedHashes ADD Data1 varchar(50)





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1730
SET @ScriptDesc = 'Script to update CategorisedHashes table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO