-- ***********************************************
-- NAME 		: DUP1646_Car_Parks_And_Maps_Accessibility_Update.sql
-- DESCRIPTION 		: Script to update content for car accessibility labels and alt texts for maps
-- AUTHOR		: Parvez Ghumra
-- DATE			: 25 Mar 2010
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'FindStationResultsTable.HasDisabledSpacesTitle', 'Accessible Spaces', 'Lleoedd Hygyrch'

Go

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkResultsTable.commandSortByHasDisabledSpaces.AlternateText', 'Click to sort by accessible spaces', 'Cliciwch i drefnu yn �l lleoedd hygyrch'

Go

EXEC AddtblContent
1, 1, 'langStrings', 'CarParkInformationControl.NumberOfDisabledSpacesTitle', 'Number of Accessible Spaces:', 'Nifer y Lleoedd Hygyrch:'

EXEC AddtblContent
1, 1, 'langStrings', 'MapJourneyControl.MapAltText', 'This is a map of a journey from {ORIGIN} to {DESTINATION}', 'Dyma fap o daith o {ORIGIN} i {DESTINATION}'

EXEC AddtblContent
1, 1, 'langStrings', 'MapBasicControl.MapAltText', 'This is a map of the local area surrounding {STOPNAME}', 'Dyma fap o''r ardal leol o amgylch {STOPNAME}'

EXEC AddtblContent
1, 1, 'langStrings', 'MapFindControl.MapAltText', 'This is a map of the local area surrounding {LOCATION}', 'Dyma fap o''r ardal leol o amgylch {LOCATION}'

EXEC AddtblContent
1, 1, 'langStrings', 'MapInputControl.MapAltText', 'This is a map of the local area surrounding {LOCATION}', 'Dyma fap o''r ardal leol o amgylch {LOCATION}'

EXEC AddtblContent
1, 1, 'langStrings', 'MapNearestControl.MapAltText', 'This is a map of the local area surrounding {LOCATION}', 'Dyma fap o''r ardal leol o amgylch {LOCATION}'

EXEC AddtblContent
1, 1, 'langStrings', 'MapTravelNewsControl.MapAltText', 'This is a map showing locations of live travel news incidents', 'Dyma fap yn dangos lleoliadau digwyddiadau newyddion teithio byw'

Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1646
SET @ScriptDesc = 'Script to update content for car accessibility labels and alt texts for maps'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO