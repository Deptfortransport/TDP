-- ***********************************************
-- NAME 		: DUP1988_Accessible_Properties_Update.sql
-- DESCRIPTION 	: Script to update Accessible properties
-- AUTHOR		: David Lane
-- DATE			: 29 Jan 2013
-- ************************************************

USE [PermanentPortal]
GO

DECLARE @AID_W varchar(50) = 'Web'
DECLARE @AID_RM varchar(50) = 'TDRemotingHost'
DECLARE @GID_UP varchar(50) = 'UserPortal'
DECLARE @GID_RM varchar(50) = 'TDRemotingHost'

-- Accessible find nearest stops - search configuration
IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'AccessibleOptions.FindNearestLocations.Stops.SearchDistance.Metres' 
	AND AID = @AID_W AND GID = @GID_UP AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('AccessibleOptions.FindNearestLocations.Stops.SearchDistance.Metres', 
	'20000', @AID_W, @GID_UP, 0, 1)
END
ELSE
BEGIN
	UPDATE properties SET pValue = '20000'
	WHERE pName = 'AccessibleOptions.FindNearestLocations.Stops.SearchDistance.Metres'
	AND AID = @AID_W AND GID = @GID_UP AND PartnerId = 0 AND ThemeId = 1
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'AccessibleOptions.FindNearestLocations.Stops.SearchDistance.Metres' 
	AND AID = @AID_RM AND GID = @GID_RM AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('AccessibleOptions.FindNearestLocations.Stops.SearchDistance.Metres', 
	'20000', @AID_RM, @GID_RM, 0, 1)
END
ELSE
BEGIN
	UPDATE properties SET pValue = '20000'
	WHERE pName = 'AccessibleOptions.FindNearestLocations.Stops.SearchDistance.Metres'
	AND AID = @AID_RM AND GID = @GID_RM AND PartnerId = 0 AND ThemeId = 1
END


IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'AccessibleOptions.FindNearestLocations.Localities.SearchDistance.Metres' 
	AND AID = @AID_W AND GID = @GID_UP AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('AccessibleOptions.FindNearestLocations.Localities.SearchDistance.Metres', 
	'20000', @AID_W, @GID_UP, 0, 1)
END
ELSE
BEGIN
	UPDATE properties SET pValue = '20000'
	WHERE pName = 'AccessibleOptions.FindNearestLocations.Localities.SearchDistance.Metres'
	AND AID = @AID_W AND GID = @GID_UP AND PartnerId = 0 AND ThemeId = 1
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'AccessibleOptions.FindNearestLocations.Localities.SearchDistance.Metres' 
	AND AID = @AID_RM AND GID = @GID_RM AND PartnerId = 0 AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('AccessibleOptions.FindNearestLocations.Localities.SearchDistance.Metres', 
	'20000', @AID_RM, @GID_RM, 0, 1)
END
ELSE
BEGIN
	UPDATE properties SET pValue = '20000'
	WHERE pName = 'AccessibleOptions.FindNearestLocations.Localities.SearchDistance.Metres'
	AND AID = @AID_RM AND GID = @GID_RM AND PartnerId = 0 AND ThemeId = 1
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1988
SET @ScriptDesc = 'Accessible properties update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO