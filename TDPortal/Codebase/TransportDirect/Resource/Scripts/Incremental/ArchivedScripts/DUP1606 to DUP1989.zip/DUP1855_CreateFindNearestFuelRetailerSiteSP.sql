-- ***********************************************
-- NAME           : DUP1855_CreateFindNearestFuelRetailerSiteSP
-- DESCRIPTION    : Script to Add Fuel Genie Create FindNearestFuelRetailerSiteSP stored Proc
-- DATE           : 12/01/2012
-- ***********************************************




USE [TransientPortal]
GO
/****** Object:  StoredProcedure [dbo].[GetNearestFuelRetailer]    Script Date: 12/20/2011 11:05:46 ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------
-- Create the stored procedures
-----------------------------------------------------------------------

CREATE PROCEDURE [dbo].[GetNearestFuelRetailer]
(	
	@searchEasting  int, 
    @searchNorthing int,
    @searchType varchar,
    @searchFlag varchar
)
as
	
       
IF (@searchType = 'F' and @searchFlag = 'E')
    BEGIN
        SELECT TOP(1) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite = 'Y' 
        and NOT((A.Easting = @searchEasting) and (A.Northing = @searchNorthing))
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF(@searchType = 'F' and @searchFlag = 'I')
    BEGIN
        SELECT TOP(1) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite =  'Y'  
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF (@searchType = 'N' and @searchFlag = 'E')
    BEGIN
        SELECT TOP(1) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite = 'N'
        and NOT((A.Easting = @searchEasting) and (A.Northing = @searchNorthing))
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF(@searchType = 'N' and @searchFlag = 'I')
    BEGIN
        SELECT TOP(1) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where FuelGenieSite =  'N'  
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF (@searchType = 'A' and @searchFlag = 'E')
    BEGIN
        SELECT TOP(1) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        Where NOT((A.Easting = @searchEasting) and (A.Northing = @searchNorthing))
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END
ELSE IF(@searchType = 'A' and @searchFlag = 'I')
    BEGIN
        SELECT TOP(1) *,ROUND((SQRT(SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing)))*0.000621371192),2) as Miles 
        FROM FuelGenieSites A 
        ORDER BY SQUARE(ABS(@searchEasting - A.Easting)) + SQUARE(ABS(@searchNorthing- A.Northing))
    END

      GO 
------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1855
SET @ScriptDesc = 'DUP1855_CreateFindNearestFuelRetailerSiteSP'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
