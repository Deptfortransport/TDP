-- ***********************************************
-- NAME           : DUP1741_Substitute_BankHolidays.sql
-- DESCRIPTION    : Script to add substitute bank holidays in Bank Holidays table
-- AUTHOR         : Amit Patel
-- DATE           : 02 Sept 2010
-- ***********************************************

USE [Content]
GO

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2010-12-24 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2010-12-24 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2010-12-25 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2010-12-25 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2010-12-26 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2010-12-26 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2010-12-27 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2010-12-27 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2010-12-28 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2010-12-28 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2010-12-31 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2010-12-31 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2011-01-01 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2011-01-01 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2011-01-02 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2011-01-02 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2011-01-03 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2011-01-03 00:00:00.000',3)
END

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[BankHolidays] WHERE [Holiday] = '2011-01-04 00:00:00.000')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[BankHolidays]([Holiday],[Country])
			VALUES ('2011-01-04 00:00:00.000',2)
END
			


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1741
SET @ScriptDesc = 'Script to add substitute bank holidays in Bank Holidays table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO