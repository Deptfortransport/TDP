-- ***********************************************
-- NAME 		: DUP1749_CyclePlanner_EES_Properties.sql
-- DESCRIPTION 	: Script to add Cycle Planner properties for EES
-- AUTHOR		: Amit Patel
-- DATE			: 15 Sep 2008
-- ************************************************

USE [PermanentPortal]
GO

------------------------------------------------------
-- Cycle planner journey request include Toids
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.JourneyRequest.IncludeToids' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.JourneyRequest.IncludeToids', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.PlannerControl.JourneyRequest.IncludeToids'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner journey result settings include text
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeText' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeText', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeText'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner journey result settings include toids
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeToids' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeToids', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeToids'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner Log All Requests
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.LogAllRequests' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.LogAllRequests', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.PlannerControl.LogAllRequests'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner Log All Responses
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.LogAllResponses' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.LogAllResponses', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.PlannerControl.LogAllResponses'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner Log cycle planner failures
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.LogCyclePlannerFailures' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.LogCyclePlannerFailures', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.PlannerControl.LogCyclePlannerFailures'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner Log no journey responses
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.LogNoJourneyResponses' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.LogNoJourneyResponses', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.PlannerControl.LogNoJourneyResponses'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner Min Usertype logging
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.MinUserTypeLogging' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.MinUserTypeLogging', '1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '1'
	where pname = 'CyclePlanner.PlannerControl.MinUserTypeLogging'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner Time Out
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.TimeoutMillisecs' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.TimeoutMillisecs', '60000', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '60000'
	where pname = 'CyclePlanner.PlannerControl.TimeoutMillisecs'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner journey result settings
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.JourneyResultSetting.EastingNorthingSeperator' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.JourneyResultSetting.EastingNorthingSeperator', ',', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = ','
	where pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.EastingNorthingSeperator'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Point Separator
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.JourneyResultSetting.PointSeperator' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.JourneyResultSetting.PointSeperator', ' ', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = ' '
	where pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.PointSeperator'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Include Geometry
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeGeometry' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeGeometry', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeGeometry'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function location
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Location' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Location', 'C:\CyclePlanner\Services\RoadInterfaceHostingService\td.cp.CyclePenaltyFunctions.v2.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'C:\CyclePlanner\Services\RoadInterfaceHostingService\td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Location'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Dll', 'td.cp.CyclePenaltyFunctions.v2.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function folder
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Folder' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Folder', 'C:\CyclePlanner\Services\RoadInterfaceHostingService', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'C:\CyclePlanner\Services\RoadInterfaceHostingService'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Folder'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner default penalty function
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Default' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Default', 'QuietestV912', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'QuietestV912'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Default'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner user preferences number
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.TDUserPreference.NumberOfPreferences' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.TDUserPreference.NumberOfPreferences', '15', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '15'
	where pname = 'CyclePlanner.TDUserPreference.NumberOfPreferences'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


------------------------------------------------------
-- Cycle planner user preferences
delete from properties where pname like 'CyclePlanner.TDUserPreference.Preference%' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1

insert into properties values ('CyclePlanner.TDUserPreference.Preference0', '850', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference1', '11000', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference2', 'Congestion', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference3', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference4', 'Bicycle', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference5', '19', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference6', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference7', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference8', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference9', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference10', '', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference11', '', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference12', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference13', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('CyclePlanner.TDUserPreference.Preference14', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)


GO


------------------------------------------------------
-- Cycle planner Intermediate turn distance
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.CycleJourneyDetailsControl.ImmediateTurnDistance' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.CycleJourneyDetailsControl.ImmediateTurnDistance', '161', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '161'
	where pname = 'CyclePlanner.CycleJourneyDetailsControl.ImmediateTurnDistance'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle planner Additional Instruction Text
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.Display.AdditionalInstructionText' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.Display.AdditionalInstructionText', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.Display.AdditionalInstructionText'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- GradientProfiler Log All Requests
IF not exists (
	select top 1 * from properties 
	where pName = 'GradientProfiler.PlannerControl.LogAllRequests' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('GradientProfiler.PlannerControl.LogAllRequests', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'GradientProfiler.PlannerControl.LogAllRequests'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- GradientProfiler Log All Responses
IF not exists (
	select top 1 * from properties 
	where pName = 'GradientProfiler.PlannerControl.LogAllResponses' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('GradientProfiler.PlannerControl.LogAllResponses', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'GradientProfiler.PlannerControl.LogAllResponses'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- GradientProfiler Log planner failures
IF not exists (
	select top 1 * from properties 
	where pName = 'GradientProfiler.PlannerControl.LogFailures' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('GradientProfiler.PlannerControl.LogFailures', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'GradientProfiler.PlannerControl.LogFailures'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- GradientProfiler Resolution
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.Resolution.Metres' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.Resolution.Metres', '100', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '100'
	where pname = 'CyclePlanner.PlannerControl.Resolution.Metres'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- GradientProfiler Min Usertype logging
IF not exists (
	select top 1 * from properties 
	where pName = 'GradientProfiler.PlannerControl.MinUserTypeLogging' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('GradientProfiler.PlannerControl.MinUserTypeLogging', '1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '1'
	where pname = 'GradientProfiler.PlannerControl.MinUserTypeLogging'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- GradientProfiler Time Out
IF not exists (
	select top 1 * from properties 
	where pName = 'GradientProfiler.PlannerControl.TimeoutMillisecs' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('GradientProfiler.PlannerControl.TimeoutMillisecs', '60000', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '30000'
	where pname = 'GradientProfiler.PlannerControl.TimeoutMillisecs'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle Planner Max Cycling Speed
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.Planner.CyclingMaxSpeed.MetresPerHour' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.Planner.CyclingMaxSpeed.MetresPerHour', '28968', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '28968'
	where pname = 'CyclePlanner.Planner.CyclingMaxSpeed.MetresPerHour'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle Planner Min Cycling Speed
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.Planner.CyclingMinSpeed.MetresPerHour' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.Planner.CyclingMinSpeed.MetresPerHour', '9656', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '9656'
	where pname = 'CyclePlanner.Planner.CyclingMinSpeed.MetresPerHour'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle Planner Default Cycling Speed
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.Planner.CyclingDefaultSpeed.MetresPerHour' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.Planner.CyclingDefaultSpeed.MetresPerHour', '19312', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '19312'
	where pname = 'CyclePlanner.Planner.CyclingDefaultSpeed.MetresPerHour'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


------------------------------------------------------
-- Cycle Planner Max Journey Distance
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.Planner.MaxJourneyDistance.Metres' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.Planner.MaxJourneyDistance.Metres', '20000', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '20000'
	where pname = 'CyclePlanner.Planner.MaxJourneyDistance.Metres'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


------------------------------------------------------
-- Cycle Planner Point Validation Switch
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.Planner.PointValidation.Switch' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.Planner.PointValidation.Switch', 'false', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CyclePlanner.Planner.PointValidation.Switch'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle Planner Point Validation Plan Same Area Only
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.Planner.PointValidation.PlanSameAreaOnly' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.Planner.PointValidation.PlanSameAreaOnly', 'true', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CyclePlanner.Planner.PointValidation.PlanSameAreaOnly'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle Planner Web Service URL
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.WebService.URL' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.WebService.URL', 'http://uk005744/cycleplannerservice/service.asmx', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://uk005744/cycleplannerservice/service.asmx'
	where pname = 'CyclePlanner.WebService.URL'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Cycle Planner Web Service Timeout
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.WebService.TimeoutMillisecs' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.WebService.TimeoutMillisecs', '60000', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '30000'
	where pname = 'CyclePlanner.WebService.TimeoutMillisecs'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Gradient Profiler Web Service URL
IF not exists (
	select top 1 * from properties 
	where pName = 'GradientProfiler.WebService.URL' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('GradientProfiler.WebService.URL', 'http://jp/gradientprofilerservice/service.asmx', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://jp/gradientprofilerservice/service.asmx'
	where pname = 'GradientProfiler.WebService.URL'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Gradient Profiler Web Service Timeout
IF not exists (
	select top 1 * from properties 
	where pName = 'GradientProfiler.WebService.TimeoutMillisecs' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('GradientProfiler.WebService.TimeoutMillisecs', '60000', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '30000'
	where pname = 'GradientProfiler.WebService.TimeoutMillisecs'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- CoordinateConvertor WebService URL
IF not exists (
	select top 1 * from properties 
	where pName = 'CoordinateConvertor.WebService.URL' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CoordinateConvertor.WebService.URL', 'http://localhost/TDPWebServices/CoordinateConvertorService/CoordinateConvertor.asmx', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://localhost/TDPWebServices/CoordinateConvertorService/CoordinateConvertor.asmx'
	where pname = 'CoordinateConvertor.WebService.URL'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- CoordinateConvertor WebService Timeout
IF not exists (
	select top 1 * from properties 
	where pName = 'CoordinateConvertor.WebService.TimeoutMillisecs' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CoordinateConvertor.WebService.TimeoutMillisecs', '60000', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '60000'
	where pname = 'CoordinateConvertor.WebService.TimeoutMillisecs'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


------------------------------------------------------
-- Coordinate Convertor DataPath
IF not exists (
	select top 1 * from properties 
	where pName = 'Coordinate.Convertor.DataPath' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('Coordinate.Convertor.DataPath', 'C:\TDPortal\Codebase\build\Quest\', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'C:\TDPortal\Codebase\build\Quest\'
	where pname = 'Coordinate.Convertor.DataPath'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

------------------------------------------------------
-- Coordinate Convertor DataPath
IF not exists (
	select top 1 * from properties 
	where pName = 'Coordinate.Convertor.InitialiseString' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('Coordinate.Convertor.InitialiseString', 'GIQ.6.0', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'GIQ.6.0'
	where pname = 'Coordinate.Convertor.InitialiseString'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END




GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1749
SET @ScriptDesc = 'Cycle planner EES properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO