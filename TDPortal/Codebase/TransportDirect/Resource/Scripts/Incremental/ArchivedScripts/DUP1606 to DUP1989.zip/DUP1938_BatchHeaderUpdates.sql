-- ***********************************************
-- NAME 		: DUP1938_BatchHeaderUpdates.sql
-- DESCRIPTION 	: Batch header changes
-- AUTHOR		: David Lane
-- DATE			: 06 Nov 12
-- ************************************************

USE [Content]
GO

-------------------------------
-- Add to Content
-------------------------------

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberRequests',
	'Requests made',
	'Nifer o geisiadau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberResults',
	'Total successes',
	'Nifer o ganlyniadau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberPartials',
	'Partial failures',
	'Partial failures'
GO


  

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1938
SET @ScriptDesc = 'Batch header updates'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO