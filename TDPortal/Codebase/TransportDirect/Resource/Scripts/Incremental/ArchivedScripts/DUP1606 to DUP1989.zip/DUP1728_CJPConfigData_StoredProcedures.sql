-- ***********************************************
-- NAME 		: DUP1728_CJPConfigData_StoredProcedures.sql
-- DESCRIPTION 	: Script to add CJP config data importer stored procedures
-- AUTHOR		: Amit Patel
-- DATE			: 29 Jun 2010
-- ************************************************

-------------- WARNING ---------------- WARNING ------------------
--		 THIS SCRIPT ADDS THE FOLLOWING STORED PROCEDURES		--
--	     PLEASE GRANT PERMISSIONS TO :							--
--			    1 ImportCJPConfigData							--
--			    2 DeleteCJPConfigData							--
--			    3 ExportCJPConfigData							--
--			    4 GetDuplicateTiplocs							--
------------------------------------------------------------------

USE [TransientPortal] 
GO

-------------------------------------------
-- Add ImportCJPConfigData Stored Procedure
-------------------------------------------


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[ImportCJPConfigData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[ImportCJPConfigData]
GO

CREATE PROCEDURE dbo.ImportCJPConfigData (
	@FileName varchar(1000), 
	@XML text
	) 
	AS

	SET NOCOUNT OFF

	DECLARE @DocID int
	DECLARE @RetCode int
	DECLARE @XMLPathData varchar(50)

	DECLARE @PROPTable TABLE ([ID] [int] IDENTITY(1,1) NOT NULL,
							  [pName] [varchar](255) NOT NULL,
							  [pValue] [varchar](2000) NULL,
							  [AID] [varchar](50) NOT NULL,
							  [GID] [varchar](50) NOT NULL)
	
	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/lookup/property'
	DECLARE @Count int
	DECLARE @IsDifferent bit
	DECLARE @CurrentMatch varchar (255)
	
	-- Start Import Transaction
	BEGIN TRANSACTION
		----------------------------------------------------
		-- Insert Into Data Tables
		----------------------------------------------------
				
		INSERT INTO @PROPTable
			SELECT DISTINCT 
					XmlDoc.name,
					XmlDoc.value, 
					XmlDoc.GID, 
					XmlDoc.AID
					
			FROM OPENXML (@DocID, @XMLPathData, 1)
			WITH (
					name Varchar(255), 
					value Varchar(2000) 'text()',
					GID Varchar(50), 
					AID Varchar(50)) XmlDoc
					
		IF ((SELECT COUNT(*) FROM CJPConfigData) = 0)
			BEGIN
				INSERT INTO CJPConfigData
				SELECT pName, pValue, GID, AID, 0, 1, @FileName + ',', 0, NULL
					FROM @PROPTable
			END
		ELSE
			BEGIN
				
				-- Check for the existing values matches
				UPDATE CJPConfigData SET [ConfigFiles] = ISNULL([ConfigFiles],'') + @FileName + ','
					 WHERE pName = ANY (SELECT pName 
										FROM 
										(
											SELECT pName, pValue, AID, GID 
											FROM 
												CJPConfigData 
											INTERSECT 
											SELECT pName, pValue, AID, GID 
											FROM 
												@PROPTable) t)
				
				
					 
				
				-- Check for the existing values difference
				UPDATE CJPConfigData SET IsDifferent = 1,
					 [ConfigFiles] = ISNULL([ConfigFiles],'') + @FileName + ',',
					 [DifferentFiles] = ISNULL([DifferentFiles],'') + @FileName + ','
					 WHERE pName = ANY (SELECT pName 
										FROM 
										(
											SELECT pName, pValue, AID, GID 
											FROM 
												CJPConfigData 
											EXCEPT 
											SELECT pName, pValue, AID, GID 
											FROM 
												@PROPTable) t)

				-- Check for the new values and add them
				INSERT INTO CJPConfigData
					SELECT pName, pValue, GID, AID, 0, 1, @FileName, 1, NULL
						FROM @PROPTable propTable
						WHERE NOT EXISTS 
						(SELECT * 
							FROM 
								CJPConfigData ccd 
							WHERE ccd.pName = propTable.pName)
				
			END
		

		IF @@ERROR<>0
		BEGIN
			EXEC sp_xml_removedocument @DocID
			ROLLBACK TRANSACTION
			GOTO ERR_HANDLER
		END

		EXEC sp_xml_removedocument @DocID
		
	
	COMMIT TRANSACTION
	RETURN 0
	

	ERR_HANDLER:
		RETURN 1



GO

-------------------------------------------
-- Add DeleteCJPConfigData Stored Procedure
-------------------------------------------


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[DeleteCJPConfigData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[DeleteCJPConfigData]
GO

CREATE PROCEDURE dbo.DeleteCJPConfigData
AS
	TRUNCATE TABLE CJPConfigData

Go

-------------------------------------------
-- Add ExportCJPConfigData Stored Procedure
-------------------------------------------


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[ExportCJPConfigData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[ExportCJPConfigData]
GO

CREATE PROCEDURE dbo.ExportCJPConfigData
AS
	SELECT pName AS '@name', GID AS '@GID', AID AS '@AID', ISNULL(pValue,'') AS 'text()' FROM CJPConfigData FOR XML PATH ('property'), ROOT ('lookup') 

Go

-------------------------------------------
-- Add  GetDuplicateTiplocs Stored Procedure
-------------------------------------------


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[GetDuplicateTiplocs]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GetDuplicateTiplocs]
GO

CREATE PROCEDURE dbo.GetDuplicateTiplocs
AS
	SELECT pValue AS tiplocData FROM CJPConfigData WHERE pName LIKE 'CJP.DuplicateTIPLOC.[0-9]%' AND pValue IS NOT NULL

Go


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1728
SET @ScriptDesc = 'Added CJP config data importer stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO