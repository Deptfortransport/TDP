-- ***********************************************
-- NAME          : DUP1879_BatchJourneyProcessingUpdates.sql
-- DESCRIPTION   : Script to update some batch items
-- AUTHOR        : David Lane
-- DATE          : 08 March 2012
-- ************************************************

-- Properties
USE PermanentPortal

DECLARE @AID NVARCHAR(50) = 'BatchJourneyPlannerService'
DECLARE @GID NVARCHAR(50) = 'UserPortal'

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'CyclePlanner.WebService.TimeoutMillisecs' 
	AND AID = @AID
	AND GID = @GID
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('CyclePlanner.WebService.TimeoutMillisecs', '600000', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingOldResultExpiryDays' 
	AND AID = @AID
	AND GID = @GID
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingOldResultExpiryDays', '14', @AID, @GID, 0, 1)
END

SET @AID = 'Web'
SET @GID = 'UserPortal'

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchProcessingUIEnabled' 
	AND AID = @AID
	AND GID = @GID
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchProcessingUIEnabled', 'true', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT TOP 1 * FROM properties WHERE pName = 'BatchJourneyPlannerDBLongTimeout' 
	AND AID = @AID
	AND GID = @GID
	AND PartnerId = 0
	AND ThemeId = 1)
BEGIN
	INSERT INTO properties values ('BatchJourneyPlannerDBLongTimeout', 'Server=.;Initial Catalog=BatchJourneyPlanner;Trusted_Connection=true;Connect Timeout=60;', @AID, @GID, 0, 1)
END


-- Content updates
USE Content

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.AlreadyApproved.SC',
	'Please <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx?loginregister=true">log in</a> then continue to the <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx">Registered User Options Page</a>',
	'Please <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx?loginregister=true">log in</a> then continue to the <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx">Registered User Options Page</a>'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HowRegister.SC',
	'Please <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx?loginregister=true">log in/register</a> then complete the form below and indicate that you agree to our terms and conditions.  You will receive an email confirming receipt of your request, then another when your batch user account has been activated.  This should take no more than two working days.',
	'Please <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx?loginregister=true">log in/register</a> then complete the form below and indicate that you agree to our terms and conditions.  You will receive an email confirming receipt of your request, then another when your batch user account has been activated.  This should take no more than two working days.'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.DftEmailAddress',
	'tdportal.business@dft.gsi.gov.uk',
	'tdportal.business@dft.gsi.gov.uk'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.StatsDetails',
	'<p>&nbsp;</p>Please choose at least one output (journey statistics and/or journey plans).',
	'<p>&nbsp;</p>Please choose at least one output (journey statistics and/or journey plans).'

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WrongHeader',
	'<p>&nbsp;</p>Sorry the file you selected had incorrect headers, the first line should read "JourneyID,OriginType,Origin,DestinationType,Destination,OutwardDate,OutwardTime,OutwardArrDep,ReturnDate,ReturnTime,ReturnArrDep".',
	'<p>&nbsp;</p>Sorry the file you selected had incorrect headers, the first line should read "JourneyID,OriginType,Origin,DestinationType,Destination,OutwardDate,OutwardTime,OutwardArrDep,ReturnDate,ReturnTime,ReturnArrDep".'



-- Batch stored procs
USE BatchJourneyPlanner
GO

ALTER PROCEDURE [dbo].[GetBatchResults]
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Output the results
	SELECT [UserSuppliedUniqueId]			-- 0
		,[ErrorMessages]					-- 1
		,[PublicJourneyResultSummary]		-- 2
		,[PublicJourneyResultDetails]		-- 3
		,[CarJourneyResultSummary]			-- 4
		,[CarJourneyResultDetails]			-- 5
		,[CycleJourneyResultSummary]		-- 6
		,[CycleJourneyResultDetails]		-- 7
		,[PublicOutwardJourneyStatus]		-- 8
		,[PublicReturnJourneyStatus]		-- 9
		,[CarOutwardJourneyStatus]			-- 10
		,[CarReturnJourneyStatus]			-- 11
		,[CycleOutwardJourneyStatus]		-- 12
		,[CycleReturnJourneyStatus]			-- 13
		,[JourneyParameters.Origin]			-- 14
		,[JourneyParameters.Destination]	-- 15
		,[JourneyParameters.OutwardDate]	-- 16
		,[JourneyParameters.OutwardTime]	-- 17
		,[JourneyParameters.OutwardArrDep]  -- 18
		,[JourneyParameters.ReturnDate]		-- 19
		,[JourneyParameters.ReturnTime]		-- 20
		,[JourneyParameters.ReturnArrDep]	-- 21
		,[BatchDetailStatusId]				-- 22
		,[JourneyParameters.OriginType]		-- 23
		,[JourneyParameters.DestinationType]-- 24
	FROM [BatchJourneyPlanner].[dbo].[BatchRequestDetail]
	WHERE BatchId = @BatchId
	
END

GO

ALTER PROCEDURE [dbo].[AddBatchRequest]
(
	@EmailAddress nvarchar(250),
	@IncludeJourneyStatistics bit,
	@IncludeJourneyDetails bit,
	@IncludePublicTransport bit,
	@IncludeCar bit,
	@IncludeCycle bit,
	@ConvertToRtf bit,
	@BatchDetails xml
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Get the user id
	DECLARE @UserId int
	SELECT @UserId = UserId
	FROM RegisteredUser
	WHERE @EmailAddress = EmailAddress
	
	-- Add a record to batch request
	DECLARE @Date datetime
	SELECT @Date = GETDATE()
	
	INSERT INTO [BatchJourneyPlanner].[dbo].[BatchRequestSummary]
           ([UserId]
           ,[QueuedDateTime]
           ,[BatchStatusId]
           ,[ProcessorId]
           ,[ReportParameters.IncludeJourneyStatistics]
           ,[ReportParameters.IncludeJourneyDetails]
           ,[ReportParameters.IncludePublicTransport]
           ,[ReportParameters.IncludeCar]
           ,[ReportParameters.IncludeCycle]
           ,[ReportParameters.ConvertToRtf])
     VALUES
           (@UserId
           ,@Date
           ,1 -- Pending
           ,'Inserting' -- To avoid being picked up during the insert
           ,@IncludeJourneyStatistics
           ,@IncludeJourneyDetails
           ,@IncludePublicTransport
           ,@IncludeCar
           ,@IncludeCycle
           ,@ConvertToRtf)	
	
	DECLARE @BatchId int
	SELECT @BatchId = @@IDENTITY
	
	-- Add the batch detail records
	DECLARE @userSuppliedUniqueId nvarchar(100)
	DECLARE @originType char(1)
	DECLARE @origin nvarchar(100)
	DECLARE @destinationType char(1)
	DECLARE @destination nvarchar(100)
	DECLARE @outwardDate nvarchar(6)
	DECLARE @outwardTimeAsString nvarchar(5)
	DECLARE @outwardArrDep char(1)
	DECLARE @returnDate nvarchar(6)
	DECLARE @returnTimeAsString nvarchar(5)
	DECLARE @returnArrDep char(1)
	DECLARE @detailStatus char(1)
	
	DECLARE Cursor_Details CURSOR STATIC FORWARD_ONLY READ_ONLY FOR 
	SELECT   
		tab.col.value('UserSuppliedUniqueId[1]','NVARCHAR(100)'),
		tab.col.value('OriginType[1]','CHAR(1)'),
		tab.col.value('Origin[1]','NVARCHAR(100)'),
		tab.col.value('DestinationType[1]','CHAR(1)'),
		tab.col.value('Destination[1]','NVARCHAR(100)'),
		tab.col.value('OutwardDate[1]','NVARCHAR(6)'),
		tab.col.value('OutwardTime[1]','NVARCHAR(5)'),
		tab.col.value('OutwardArrDep[1]','CHAR(1)'),
		tab.col.value('ReturnDate[1]','NVARCHAR(6)'),
		tab.col.value('ReturnTime[1]','NVARCHAR(5)'),
		tab.col.value('ReturnArrDep[1]','CHAR(1)')
	FROM @BatchDetails.nodes('//DetailRecord') tab(col) 
	
	OPEN Cursor_Details
	FETCH NEXT FROM Cursor_Details INTO
		@userSuppliedUniqueId,
		@originType,
		@origin,
		@destinationType,
		@destination,
		@outwardDate,
		@outwardTimeAsString,
		@outwardArrDep,
		@returnDate,
		@returnTimeAsString,
		@returnArrDep
		
	DECLARE @lines int
	SELECT @lines = 0
	DECLARE @invalidLines int
	SELECT @invalidLines = 0
	DECLARE @badRows int
	SELECT @badRows = 0
	
	WHILE 0 = @@FETCH_STATUS
	BEGIN
		-- Insert the detail row
		SELECT @lines = @lines + 1
		
		-- if necessary prepend a zero to the time
		IF (LEN(@outwardTimeAsString) = 3)
			SET @outwardTimeAsString = '0' + @outwardTimeAsString
			
		-- Convert outward time 
		SET @outwardTimeAsString = LEFT(@outwardTimeAsString, 2) + ':' + RIGHT(@outwardTimeAsString, 2)
		
		-- Catch errors
		BEGIN TRY		
			-- check for return journey
			IF (LEN(@returnDate) > 0 AND LEN(@returnTimeAsString) > 0 AND LEN(@returnArrDep) > 0)
			BEGIN
				-- if necessary prepend a zero to the time
				IF (LEN(@returnTimeAsString) = 3)
					SET @returnTimeAsString = '0' + @returnTimeAsString

				-- Convert return time 
				SET @returnTimeAsString = LEFT(@returnTimeAsString, 2) + ':' + RIGHT(@returnTimeAsString, 2)
				
				INSERT INTO BatchRequestDetail
				   ([BatchId]
				   ,[BatchDetailStatusId]
				   ,[UserSuppliedUniqueId]
				   ,[JourneyParameters.OriginType]
				   ,[JourneyParameters.Origin]
				   ,[JourneyParameters.DestinationType]
				   ,[JourneyParameters.Destination]
				   ,[JourneyParameters.OutwardDate]
				   ,[JourneyParameters.OutwardTime]
				   ,[JourneyParameters.OutwardArrDep]
				   ,[JourneyParameters.ReturnDate]
				   ,[JourneyParameters.ReturnTime]
				   ,[JourneyParameters.ReturnArrDep]
				   ,[SubmittedDateTime])
				VALUES
				   (@BatchId
				   ,@detailStatus
				   ,@userSuppliedUniqueId
				   ,@originType
				   ,@origin
				   ,@destinationType
				   ,@destination
				   ,@outwardDate
				   ,@outwardTimeAsString
				   ,@outwardArrDep
				   ,@returnDate
				   ,@returnTimeAsString
				   ,@returnArrDep
				   ,@Date)
			END
			ELSE
			BEGIN
				INSERT INTO BatchRequestDetail
				   ([BatchId]
				   ,[BatchDetailStatusId]
				   ,[UserSuppliedUniqueId]
				   ,[JourneyParameters.OriginType]
				   ,[JourneyParameters.Origin]
				   ,[JourneyParameters.DestinationType]
				   ,[JourneyParameters.Destination]
				   ,[JourneyParameters.OutwardDate]
				   ,[JourneyParameters.OutwardTime]
				   ,[JourneyParameters.OutwardArrDep]
				   ,[JourneyParameters.ReturnDate]
				   ,[JourneyParameters.ReturnTime]
				   ,[JourneyParameters.ReturnArrDep]
				   ,[SubmittedDateTime])
				VALUES
				   (@BatchId
				   ,NULL
				   ,@userSuppliedUniqueId
				   ,@originType
				   ,@origin
				   ,@destinationType
				   ,@destination
				   ,@outwardDate
				   ,@outwardTimeAsString
				   ,@outwardArrDep
				   ,null
				   ,null
				   ,null
				   ,@Date)
			END
		END TRY
		BEGIN CATCH
			SELECT @badRows = @badRows + 1
			
			-- Insert a batch detail record
			INSERT INTO BatchRequestDetail
				   ([BatchId]
				   ,[BatchDetailStatusId]
				   ,[UserSuppliedUniqueId]
				   ,[ErrorMessages])
			 VALUES
				   (@BatchId
				   ,4 -- validation error
				   ,@userSuppliedUniqueId
				   ,'Journey details could not be processed')
		END CATCH

		FETCH NEXT FROM Cursor_Details INTO
			@userSuppliedUniqueId,
			@originType,
			@origin,
			@destinationType,
			@destination,
			@outwardDate,
			@outwardTimeAsString,
			@outwardArrDep,
			@returnDate,
			@returnTimeAsString,
			@returnArrDep
	END
	
	CLOSE Cursor_Details
	DEALLOCATE Cursor_Details

	-- Update the summary with the number of lines.
	UPDATE BatchRequestSummary
		SET NumberOfRequests = @lines,
			NumberOfInvalidRequests = @badRows
		WHERE BatchId = @BatchId
		
	-- return the batch id and queued position
	DECLARE @PaddedBatchId nvarchar(50)
	SELECT @PaddedBatchId = BatchJourneyPlanner.dbo.PadBatchId(@BatchId)
	
	DECLARE @Position int
	SELECT @Position = COUNT(*) + 1
		FROM BatchRequestSummary
		WHERE BatchId < @BatchId
		AND BatchStatusId < 3 -- ie queued or in progress
		
	DECLARE @ReturnPosition nvarchar(20)
	SELECT @ReturnPosition = CONVERT(nvarchar(20), @Position)
	SELECT @ReturnPosition = @ReturnPosition + 
		CASE
			WHEN LEN(@ReturnPosition) > 1 AND (LEFT(RIGHT(@ReturnPosition, 2), 1) = '1') THEN 'th'
			WHEN RIGHT(@Position, 1) = '1' THEN 'st'
			WHEN RIGHT(@Position, 1) = '2' THEN 'nd'
			WHEN RIGHT(@Position, 1) = '3' THEN 'rd'
			ELSE  'th'
		END
	
	-- Set the batch as available
	UPDATE BatchRequestSummary
	SET ProcessorId = NULL
	WHERE BatchId = @BatchId
	
	SELECT @PaddedBatchId, @ReturnPosition
	RETURN 0
END

GO

ALTER PROCEDURE [dbo].[UpdateBatchRequestDetail]
(
	@BatchDetailId int,
	@PublicJourneyResultSummary nvarchar(250),
	@PublicJourneyResultDetails xml,
	@PublicOutwardJourneyStatus int,
	@PublicReturnJourneyStatus int,
	@PublicJourneyErrorMessage nvarchar(200),
	@CarResultSummary nvarchar(250),
	@CarOutwardStatus int,
	@CarReturnStatus int,
	@CarErrorMessage nvarchar(200),
	@CycleResultSummary nvarchar(250),
	@CycleOutwardStatus int,
	@CycleReturnStatus int,
	@CycleErrorMessage nvarchar(200)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Update the detail record
	DECLARE @Date datetime
	SET @Date = GETDATE()
	
	DECLARE @DetailStatusId int
	SET @DetailStatusId = 2 -- complete
	
	DECLARE @ErrorMessage nvarchar(700)
	SELECT @ErrorMessage = ''
	
	IF (LEN(@PublicJourneyErrorMessage) > 0)
	BEGIN
		SELECT @ErrorMessage = @ErrorMessage + @PublicJourneyErrorMessage + ' '
		SET @DetailStatusId = 3 -- errored
	END
	
	IF (LEN(@CarErrorMessage) > 0)
	BEGIN
		SELECT @ErrorMessage = @ErrorMessage + @CarErrorMessage + ' '
		SET @DetailStatusId = 3 -- errored
	END
		
	IF (LEN(@CycleErrorMessage) > 0)
	BEGIN
		SELECT @ErrorMessage = @ErrorMessage + @CycleErrorMessage
		SET @DetailStatusId = 3 -- errored
	END
	
	IF (@PublicOutwardJourneyStatus = 3 OR @PublicOutwardJourneyStatus = 3 OR @CarOutwardStatus = 3 OR @CarReturnStatus = 3 OR @CycleOutwardStatus = 3 OR @CycleReturnStatus = 3)
	BEGIN
		SET @DetailStatusId = 3 -- errored
	END
		
	UPDATE BatchRequestDetail
	SET CompletedDateTime = @Date,
		PublicJourneyResultSummary = @PublicJourneyResultSummary,
		PublicJourneyResultDetails = @PublicJourneyResultDetails,
		PublicOutwardJourneyStatus = @PublicOutwardJourneyStatus,
		PublicReturnJourneyStatus = @PublicReturnJourneyStatus,
		CarJourneyResultSummary = @CarResultSummary,
		CarOutwardJourneyStatus = @CarOutwardStatus,
		CarReturnJourneyStatus = @CarReturnStatus,
		CycleJourneyResultSummary = @CycleResultSummary,
		CycleOutwardJourneyStatus = @CycleOutwardStatus,
		CycleReturnJourneyStatus = @CycleReturnStatus,
		ErrorMessages = @ErrorMessage,
		BatchDetailStatusId = @DetailStatusId
	WHERE RequestId = @BatchDetailId

END

GO

ALTER PROCEDURE [dbo].[DeleteBatchDetails]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Get the expiry age
	DECLARE @Days INT
	SELECT @Days = pValue
	FROM PermanentPortal..properties
	WHERE pName = 'BatchProcessingOldResultExpiryDays'
	
	-- Remove old completed batches
	DECLARE @Date datetime
	SELECT @Date = DATEADD(DAY, -@Days, GETDATE())
	 
	DELETE FROM BatchRequestDetail
	WHERE BatchId IN (SELECT BatchId
						FROM BatchRequestSummary
						WHERE CompletedDateTime < @Date)
						
	DELETE FROM BatchRequestSummary
	WHERE CompletedDateTime < @Date

	-- Remove old failed batches
	SELECT @Date = DATEADD(DAY, -10, GETDATE())
		
	DELETE FROM BatchRequestDetail
	WHERE BatchId IN (SELECT BatchId
						FROM BatchRequestSummary
						WHERE QueuedDateTime < @Date
						AND CompletedDateTime IS NULL)
						
	DELETE FROM BatchRequestSummary
	WHERE QueuedDateTime < @Date
	AND CompletedDateTime IS NULL

END

GO
-- Increase field sizes to allow for long URLs
ALTER TABLE dbo.BatchRequestDetail ALTER COLUMN PublicJourneyResultSummary NVARCHAR(400) ;
GO

ALTER TABLE dbo.BatchRequestDetail ALTER COLUMN CycleJourneyResultSummary NVARCHAR(400) ;
GO

-- Housekeeping job
USE [msdb]
GO

IF NOT EXISTS (SELECT TOP 1 * FROM msdb.dbo.sysjobs_view WHERE name = 'BatchHousekeeping') 
BEGIN

/****** Object:  Job [BatchHousekeeping]    Script Date: 03/15/2012 18:07:01 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 03/15/2012 18:07:01 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BatchHousekeeping', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Delete expired results and users that have been removed.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'NFHTDSUPPORT\dlane', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Remove deleted users]    Script Date: 03/15/2012 18:07:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Remove deleted users', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC RemoveDeletedUsers
', 
		@database_name=N'BatchJourneyPlanner', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Delete expired batch details]    Script Date: 03/15/2012 18:07:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete expired batch details', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [DeleteBatchDetails]', 
		@database_name=N'BatchJourneyPlanner', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'HousekeepingSchedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120315, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'5886ab7d-c29b-4877-bed5-311a674aa706'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1879
SET @ScriptDesc = 'Batch Journey Processing Updates'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO