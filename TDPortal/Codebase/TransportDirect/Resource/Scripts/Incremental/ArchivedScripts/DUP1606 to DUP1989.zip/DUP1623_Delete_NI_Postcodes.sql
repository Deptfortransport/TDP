-- ***********************************************
-- NAME 		: DUP1623_Delete_NI_Postocdes.sql
-- DESCRIPTION 		: Deletes Nothern Ireland Postcodes from the Gaz
-- AUTHOR		: Mark Turner
-- DATE			: 16 March 2010
-- ************************************************

USE [GAZ]
GO

DELETE FROM [gazadmin].[OSCODEPOINT]
WHERE COUNTRY_CODE = '152'
GO

USE [GAZ_Staging]
GO

DELETE FROM [gazadmin].[OSCODEPOINT]
WHERE COUNTRY_CODE = '152'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1623
SET @ScriptDesc = 'Deletes Nothern Irish Postcodes from the Gazetteer'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO