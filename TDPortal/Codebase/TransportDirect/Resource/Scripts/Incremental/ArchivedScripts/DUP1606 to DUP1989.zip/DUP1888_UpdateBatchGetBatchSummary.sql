-- ***********************************************
-- NAME           : DUP1888_UpdateBatchGetBatchSummary
-- DESCRIPTION    : Script to modify Batch stored proc
-- DATE           : 02/05/2012
-- Author         : D Lane
-- ***********************************************


USE BatchJourneyPlanner
GO

ALTER PROCEDURE [dbo].[GetBatchSummary]
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Update the batch summary table with this download request
	UPDATE BatchRequestSummary
	SET LastResultDownloadRequestDateTime = GETDATE()
	WHERE BatchId = @BatchId

	SELECT DetailsDeletedDateTime,
		BatchStatusId,
		[ReportParameters.IncludeJourneyStatistics],
		[ReportParameters.IncludeJourneyDetails],
		[ReportParameters.IncludePublicTransport],
		[ReportParameters.IncludeCar],
		[ReportParameters.IncludeCycle],
		[ReportParameters.ConvertToRtf]
		,QueuedDateTime
		,CompletedDateTime
		,NumberOfRequests
		,NumberOfSuccessfulResults
		,NumberOfUnsuccessfulRequests
		,NumberOfInvalidRequests
		,dbo.PadBatchId(BatchId)
	FROM BatchRequestSummary
	WHERE BatchId = @BatchId;
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1888
SET @ScriptDesc = 'DUP1888_UpdateBatchGetBatchSummary'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

