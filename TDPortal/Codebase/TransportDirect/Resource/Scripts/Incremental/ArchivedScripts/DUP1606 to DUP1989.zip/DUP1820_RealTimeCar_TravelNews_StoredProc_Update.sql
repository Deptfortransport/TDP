-- ***********************************************
-- NAME           : DUP1820_RealTimeCar_TravelNews_StoredProc_Update.sql
-- DESCRIPTION    : Script to update travel news database stored procedures necessary for Real Time Car
-- AUTHOR         : Amit Patel
-- DATE           : 18 Aug 2011
-- ***********************************************

-- ************************************************************************************************
-- THIS SCRIPT MUST BE AMENDED TO ASSIGN PERMISSIONS TO THE CORRECT USER
-- ************************************************************************************************

USE [TransientPortal]
GO

----------------------------------------------------------------
-- Create ImportTravelNews stored proc only if its already not present
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportTravelNews]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE ImportTravelNews 
			@XML text
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update ImportTravelNews stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[ImportTravelNews]
	@XML text
AS
SET NOCOUNT ON
SET XACT_ABORT ON

BEGIN TRANSACTION

DECLARE @DocID int
DECLARE @Version varchar(20)
DECLARE @RowCount int

EXEC sp_xml_preparedocument @DocID OUTPUT, @XML

SET @Version = NULL

SELECT TOP 1
	@Version = Version
FROM
OPENXML (@DocID, '/TrafficAndTravelNewsData', 2)
WITH
(
	Version varchar(50) '@version'
)

IF @Version IS NULL OR @Version <> 'IF00908'
BEGIN
	EXEC sp_xml_removedocument @DocID
	RAISERROR('The stored procedure ImportTravelNews did not recognise the given XML file version', 11, 1)
END
ELSE
BEGIN
	SET @RowCount = 0

	DELETE FROM TravelNewsDataSource
	DELETE FROM TravelNewsRegion
	DELETE FROM TravelNews
	DELETE FROM TravelNewsToid

	INSERT INTO TravelNews
	(
		[UID],
		SeverityLevel,
		PublicTransportOperator,
		ModeOfTransport,
		Location,
		IncidentType,
		HeadlineText,
		DetailText,
		IncidentStatus,
		Easting,
		Northing,
		ReportedDateTime,
		StartDateTime,
		LastModifiedDateTime,
		ClearedDateTime,
		ExpiryDateTime,
		PlannedIncident,
		RoadType,
		IncidentParent,
		CarriagewayDirection,
		RoadNumber,
		DayMask,
		DailyStartTime,
		DailyEndTime,
		ItemChangeStatus
	)
	SELECT DISTINCT
		X.[UID],
		TNS.SeverityID,
		X.PublicTransportOperator,
		X.ModeOfTransport,
		X.Location,
		X.IncidentType,
		X.HeadlineText,
		X.DetailText,
		X.IncidentStatus,
		X.Easting,
		X.Northing,
		X.ReportedDateTime,
		X.StartDateTime,
		X.LastModifiedDateTime,
		X.ClearedDateTime,
		X.ExpiryDateTime,
		CASE X.PlannedIncident WHEN 'true' THEN 1 ELSE 0 END,
		X.RoadType,
		X.IncidentParent,
		X.CarriagewayDirection,
		X.RoadNumber,
		X.DayMask,
		X.DailyStartTime,
		X.DailyEndTime,
		X.ItemChangeStatus
	FROM
	OPENXML (@DocID, '/TrafficAndTravelNewsData/Incident', 2)
	WITH
	(
		[UID] varchar(25) '@uid',
		SeverityLevel varchar(15) '@severity',
		PublicTransportOperator varchar(100) '@publicTransportOperator',
		ModeOfTransport varchar(50) '@modeOfTransport',
		Location varchar(100) '@location',
		IncidentType varchar(60) '@incidentType',
		HeadlineText varchar(150) '@headlineText',
		DetailText varchar(350) '@detailText',
		IncidentStatus varchar(1) '@incidentStatus',
		Easting decimal(18, 6) '@easting',
		Northing decimal(18, 6) '@northing',
		ReportedDateTime datetime '@reportedDatetime',
		StartDateTime datetime '@startDatetime',
		LastModifiedDateTime datetime '@lastModifiedDatetime',
		ClearedDateTime datetime '@clearedDatetime',
		ExpiryDateTime datetime '@expiryDatetime',
		PlannedIncident varchar(5) '@plannedIncident',
		RoadType varchar(10) '@roadType',
		IncidentParent varchar(25) '@parent_uid',
		CarriagewayDirection varchar(15) '@carriageway_direction',
		RoadNumber varchar(25) '@road_number',
		DayMask varchar(14) '@daymask',
		DailyStartTime time(7) '@daily_startDatetime',
		DailyEndTime time(7) '@daily_endDatetime',
		ItemChangeStatus varchar(9) '@incident_change_status'
	) X
	INNER JOIN TravelNewsSeverity TNS ON X.SeverityLevel = TNS.SeverityDescription

	SET @RowCount = @@ROWCOUNT

	-- Regions for Incident
	INSERT INTO TravelNewsRegion
	(
		[UID],
		RegionName
	)
	SELECT DISTINCT
		[UID],
		CASE RegionName WHEN 'East' THEN 'East Anglia' ELSE RegionName END
	FROM
	OPENXML (@DocID, '/TrafficAndTravelNewsData/Incident/Region', 2)
	WITH
	(
		UID varchar(25) '@uid',
		RegionName varchar(50) '@regionName'
	)

	IF @@ROWCOUNT = 0
		SET @RowCount = 0

	UPDATE TravelNews
	SET Regions = ISNULL(TNR.Regions, '-')
	FROM TravelNews TN
	LEFT OUTER JOIN fn_TravelNewsRegion() TNR ON TN.UID = TNR.UID COLLATE database_default

	IF @@ROWCOUNT = 0
		SET @RowCount = 0


	-- Data Sources for Incident
	INSERT INTO TravelNewsDataSource
	(
		UID,
		DataSourceId
	)
	SELECT DISTINCT
		UID,
		DataSourceId
	FROM
		OPENXML (@DocID, '/TrafficAndTravelNewsData/Incident/IncidentDataSource', 2)
		WITH
		(
			UID varchar(25) '../@uid',
			DataSourceId varchar(50) 'text()'
		)


	IF @@ROWCOUNT = 0
		SET @RowCount = 0
		
	-- Toids affected for Incident
	INSERT INTO TravelNewsToid (
		TOID, 
		[UID])
	SELECT DISTINCT
		X.TOID, 
		X.[UID]
	FROM
		OPENXML (@DocID, '/TrafficAndTravelNewsData/Incident/TOIDsAffected/TOIDAffected', 2)
		WITH
		(
			TOID varchar(25) 'text()',
			[UID] varchar(25) '../../@uid'
		) X

	EXEC sp_xml_removedocument @DocID
	

	IF @@ERROR<>0
	ROLLBACK TRANSACTION
	ELSE
	BEGIN
		COMMIT TRANSACTION		
		
		UPDATE ChangeNotification
		SET Version = Version + 1
		WHERE [Table] = 'TravelNewsImport'
	END
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


---------------------------------------------------------------
-- Create TravelNewsAll stored proc only if its already not present
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TravelNewsAll]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE TravelNewsAll 
			
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update TravelNewsAll stored proc
----------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[TravelNewsAll]
AS
SET NOCOUNT ON

SELECT
	TN.UID,
	TN.SeverityLevel,
	TNS.SeverityDescription,
	TN.PublicTransportOperator,
	ISNULL(TN.PublicTransportOperator, '-') Operator,
	TN.ModeOfTransport,
	TN.Regions,
	TN.Location,
	TN.Regions + ' (' + TN.Location + ')' RegionsLocation,
	TN.IncidentType,
	TN.HeadlineText,
	TN.DetailText,
	TN.IncidentStatus,
	TN.Easting,
	TN.Northing,
	TN.ReportedDateTime,
	TN.StartDateTime,
	DateDiff(mi, TN.StartDateTime, GetDate()) StartToNowMinDiff,
	TN.LastModifiedDateTime,
	TN.ClearedDateTime,
	TN.ExpiryDateTime,
	TN.PlannedIncident,
	TN.RoadType,
	TN.IncidentParent,
	TN.CarriagewayDirection,
	TN.RoadNumber,
	TN.DayMask,
	TN.DailyStartTime,
	TN.DailyEndTime,
	TN.ItemChangeStatus,
	dbo.IsTravelNewsItemActive(TN.DayMask,TN.DailyStartTime, TN.DailyEndTime,GETDATE()) IncidentActiveStatus,
	(SELECT TOID + ','

           FROM TravelNewsToid TNT

          WHERE TNT.[UID] = TN.[UID]

          ORDER BY TOID

            FOR XML PATH('')) as AffectedToids,
	Convert(Bit, Case WHEN TN.IncidentType = 'Closures/ blockages' THEN 1 ELSE 0 END) AS IsClosure
FROM (((TravelNews TN INNER JOIN TravelNewsSeverity TNS ON TN.SeverityLevel = TNS.SeverityID)
	 INNER JOIN TravelNewsDataSource TNDS1 ON TN.UID = TNDS1.UID)
	 INNER JOIN TravelNewsDataSources TNDSS ON TNDS1.DataSourceId = TNDSS.DataSourceId)
WHERE TNDSS.Trusted = 1
ORDER BY SeverityLevel ASC, StartDateTime DESC

GO

---------------------------------------------------------------
-- Create TravelNewsToids stored proc only if its already not present
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TravelNewsToids]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE TravelNewsToids 
			
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update TravelNewsToids stored proc
----------------------------------------------------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO


ALTER PROCEDURE [dbo].[TravelNewsToids]
	@TOIDs xml
AS
	SET NOCOUNT ON
	SET XACT_ABORT ON

	DECLARE @DocID int


	EXEC sp_xml_preparedocument @DocID OUTPUT, @TOIDs
	

	-- Find all toids which are affected by a travel news incident
	-- and which match the list supplied by the caller,
	-- and are valid for the requested journey date time
	SELECT DISTINCT
		TNT.UID
	FROM
	OPENXML (@DocID, '/TOIDs/TOID', 2) 
	WITH
	(
		TOID varchar(25) 'text()'
	) X 
	INNER JOIN TravelNewsToid TNT WITH (NOLOCK)
			ON X.TOID = TNT.TOID
	
	
	EXEC sp_xml_removedocument @DocID
	
GO
	
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1820
SET @ScriptDesc = 'Script to update travel news database stored procedures necessary for Real Time Car'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO