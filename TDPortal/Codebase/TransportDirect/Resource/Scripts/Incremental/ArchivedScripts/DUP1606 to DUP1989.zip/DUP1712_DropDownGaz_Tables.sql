-- ****************************************************************
-- NAME 		: DUP1712_DropDownGaz_Tables.sql
-- DESCRIPTION 	: Creates the tables required for dropdown gaz
-- AUTHOR		: Amit Patel
-- DATE			: 25 May 2010
-- ****************************************************************


USE [AtosAdditionalData] 
GO

-----------------------------------------------
-- ChangeNotification Table
-----------------------------------------------

-- Drop Existing  ChangeNotification Table

IF  EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ChangeNotification') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ChangeNotification]
END
GO



-- Create ChangeNotification table

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ChangeNotification') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[ChangeNotification](
		[Version] [int],
		[Table] [varchar](100)
	) ON [PRIMARY]

END
GO

-----------------------------------------------
-- StopAlias Table
-----------------------------------------------
-- Drop Existing StopAlias Table

IF  EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.StopAlias') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[StopAlias]
END
GO

-- Create StopAlias table

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.StopAlias') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[StopAlias](
		[StopNaptan] [varchar](12) NOT NULL,
		[StopType] [varchar](3) NOT NULL,
		[AliasName] [varchar] (100) NOT NULL
	) ON [PRIMARY]

END
GO


-----------------------------------------------
-- DropDownStop Table
-----------------------------------------------
-- Drop Existing DropDownStop Table

IF  EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.DropDownStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[DropDownStop]
END
GO


-- Create DropDownStop table

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.DropDownStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[DropDownStop](
		[DropDownType] [varchar](10) NOT NULL,	 -- Type of the drop down this data associates to
		[Name] [varchar](100) NOT NULL,			 -- Name for the stop which will be displayed in the textbox showing autosuggest		  
		[DisplayName] [varchar](100),			 -- Name which will apear in the dropdown
		[Naptans] [varchar](300) NOT NULL,		 -- Comma delimited NaPTAN values
		[ShortCode] [varchar] (100),		     -- Short code such as CRS
		[IsGroup] [bit] NOT NULL DEFAULT(0),	 -- If the stop representing a group of stops
		[IsAlias] [bit] NOT NULL DEFAULT(0)      -- If the current row entry is an alias added for actual stop
	) ON [PRIMARY]

END
GO


-----------------------------------------------
-- DropDownSyncStatus Table
-----------------------------------------------
-- Drop Existing DropDownSyncStatus Table

IF  EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.DropDownSyncStatus') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[DropDownSyncStatus]
END
GO


-- Create DropDownSyncStatus table

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.DropDownSyncStatus') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[DropDownSyncStatus](
		[DropDownType] [varchar](10) NOT NULL,
		[SequenceNumCurrent] [int] NOT NULL,
		[SequenceNumNew] [int] NOT NULL,
		[ServerSynchFileCreatedCount] [int] NOT NULL,
		[ServerSynchFileUsingCount] [int] NOT NULL,
		[UpdateLock] [bit] NOT NULL DEFAULT(0),
		[UpdateStartedDateTime] [datetime] default(Getdate()),
		[UpdateCompletedDateTime] [datetime] default (getdate())
	) ON [PRIMARY]

END
GO

ALTER TABLE [dbo].[DropDownSyncStatus] ADD 
	CONSTRAINT [PK_DropDownSyncStatus] PRIMARY KEY  CLUSTERED 
	(
		[DropDownType]
	)  ON [PRIMARY] 
GO



-----------------------------------------------
-- NPTG_ExchangeGroups Table
-----------------------------------------------
-- Drop Existing Table

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NPTG_ExchangeGroups]') AND type in (N'U'))
DROP TABLE [dbo].[NPTG_ExchangeGroups]
GO


-- Create table

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.NPTG_ExchangeGroups') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[NPTG_ExchangeGroups](
		[Group ID] [varchar](10) NULL,
		[Name] [varchar](100) NULL,
		[Easting] [varchar](10) NULL,
		[Northing] [varchar](10) NULL,
		[Date of Last Change] [varchar](30) NULL,
		[Date of Issue] [varchar](30) NULL,
		[Issue Version] [varchar](10) NULL
	) ON [PRIMARY]

END
GO


-----------------------------------------------
-- NPTG_RailExchanges Table
-----------------------------------------------
-- Drop Existing Table

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NPTG_RailExchanges]') AND type in (N'U'))
DROP TABLE [dbo].[NPTG_RailExchanges]
GO


-- Create table

IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NPTG_RailExchanges]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[NPTG_RailExchanges](
		[Exchange Point ID] [varchar](20) NULL,
		[Tiploc Code] [varchar](20) NULL,
		[CRS Code] [varchar](10) NULL,
		[Station Name] [varchar](100) NULL,
		[Easting] [varchar](10) NULL,
		[Northing] [varchar](10) NULL,
		[Date of Issue] [varchar](30) NULL,
		[Issue Version] [varchar](10) NULL,
		[NaPTAN] [varchar](20) NULL,
		[Group ID] [varchar](10) NULL
	) ON [PRIMARY]
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1712
SET @ScriptDesc = 'Creates tables for dropdown gaz'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO