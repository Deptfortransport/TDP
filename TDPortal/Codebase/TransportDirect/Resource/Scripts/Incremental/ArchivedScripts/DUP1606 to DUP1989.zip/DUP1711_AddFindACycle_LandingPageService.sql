-- ***********************************************
-- NAME 		: DUP1711_AddFindACycle_LandingPageService.sql
-- DESCRIPTION 	: Added LandingPageService entry for 'FindACycle'
-- AUTHOR		: Parvez Ghumra
-- DATE			: 14 June 2010
-- ************************************************


USE [Reporting]
GO

DECLARE @MaxID INT
SET @MaxID = (SELECT MAX(LPSID) FROM LandingPageService) + 1

-- Add new page entries for reporting
IF NOT EXISTS(SELECT * FROM [Reporting].[dbo].[LandingPageService] WHERE [LPSCode] = 'FindACycle') 

INSERT INTO [Reporting].[dbo].[LandingPageService]
           ([LPSID]
           ,[LPSCode]
           ,[LPSDescription])
     VALUES
           (@MaxID
           ,'FindACycle'
           ,'Find a Cycle Landing Page')
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1711
SET @ScriptDesc = 'Added LandingPageService entry for FindACycle'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO