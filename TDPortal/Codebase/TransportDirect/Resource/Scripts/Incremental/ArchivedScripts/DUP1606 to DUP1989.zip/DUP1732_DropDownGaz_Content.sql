-- ***********************************************
-- NAME 		: DUP1732_DropDownGaz_Content.sql
-- DESCRIPTION 	: Text postfix for the group rail stations 
-- AUTHOR		: Amit Patel
-- DATE         : 7 Jul 2010
-- ************************************************

-------------------------------------------------------------------------
-- Properties
-------------------------------------------------------------------------

USE Content
GO


EXEC AddtblContent
1, 1, 'langStrings', 'DropDownGaz.Rail.GroupStop.Suffix.Text', '(Main Rail Stations)', '(Main Rail Stations)'


----------------------------------------------------------------

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1732
SET @ScriptDesc = 'Text postfix for the group rail stations '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO