-- ***********************************************
-- NAME 		: DUP1921_Gazeteer_Properties_Update.sql
-- DESCRIPTION 	: Script to update properties for the Location service,
--				: correcting the part postcode gaz id for EES
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Sep 2012
-- ************************************************

USE [PermanentPortal]
GO

-- Environments have an invalid character at the end of the following pname, 
-- 'locationservice.partpostcodegazetteerid,' so update
UPDATE [dbo].[properties]
SET pName = 'locationservice.partpostcodegazetteerid'
WHERE pName like 'locationservice.partpostcodegazetteerid%'


-- The following is used to update Dev only for missing properties, 
-- these already exist on the environments so won't execute
DECLARE @AID_Web varchar(50) = 'Web'
DECLARE @AID_RHost varchar(50) = 'TDRemotingHost'
DECLARE @AID_EES varchar(50) = 'EnhancedExposedServices'

DECLARE @GID_UPortal varchar(50) = 'UserPortal'
DECLARE @GID_RHost varchar(50) = 'TDRemotingHost'

IF NOT EXISTS (SELECT TOP(1) * FROM [properties] 
	WHERE pName like 'locationservice.gazopsweburl' and AID = @AID_EES and GID = @GID_UPortal)
BEGIN

	DELETE FROM PermanentPortal.dbo.properties
	WHERE pName like 'locationservice.%'
	and AID = @AID_EES
	and GID = @GID_UPortal

	INSERT INTO [properties] VALUES ('locationservice.addressgazetteerid', 'ADDP1', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.addresspostcode.minscore', '20', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.allstations.minscore', '20', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.allstationsgazetteerid', 'ALLSTAT1', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.attractions.minscore', '20', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.attractionsgazetteerid', 'POINTX', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.codegazetteerid', 'CODEGAZ1', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('LocationService.FilterGivenNameTag', 'True', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.gazopsweburl', 'http://GAZOPS/GazopsWeb/GazopsWeb.asmx', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('LocationService.GivenNameTagFilterValues', 'Main Coach Stops|Main Rail / Coach|Main Rail Stations', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.locality.minscore', '20', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.localitygazetteerid', 'DRILL1', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstations.minscore', '20', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Airport', 'MAJSTAT4', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.AirportNoGroup', 'MAJSTAT8', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Coach', 'MAJSTAT2', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.CoachNoGroup', 'MAJSTAT6', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Rail', 'MAJSTAT3', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.RailNoGroup', 'MAJSTAT7', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Undetermined', 'MAJSTAT1', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.UndeterminedNoGroup', 'MAJSTAT5', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.maxreturnedrecords', '60', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.partpostcodegazetteerid', 'PCODE2', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.postcodegazetteerid', 'PCODE1', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.servername', 'GIS', @AID_EES, @GID_UPortal, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.servicename', 'tdparc93', @AID_EES, @GID_UPortal, 0, 1)

END

IF NOT EXISTS (SELECT TOP(1) * FROM [properties] 
	WHERE pName like 'locationservice.gazopsweburl' and AID = @AID_RHost and GID = @GID_RHost)
BEGIN

	DELETE FROM PermanentPortal.dbo.properties
	WHERE pName like 'locationservice.%'
	and AID = @AID_RHost
	and GID = @GID_RHost

	INSERT INTO [properties] VALUES ('locationservice.addressgazetteerid', 'ADDP1', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.addresspostcode.minscore', '20', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.allstations.minscore', '20', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.allstationsgazetteerid', 'ALLSTAT1', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.attractions.minscore', '20', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.attractionsgazetteerid', 'POINTX', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.codegazetteerid', 'CODEGAZ1', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('LocationService.FilterGivenNameTag', 'True', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.gazopsweburl', 'http://GAZOPS/GazopsWeb/GazopsWeb.asmx', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('LocationService.GivenNameTagFilterValues', 'Main Coach Stops|Main Rail / Coach|Main Rail Stations', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.locality.minscore', '20', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.localitygazetteerid', 'DRILL1', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstations.minscore', '20', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Airport', 'MAJSTAT4', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.AirportNoGroup', 'MAJSTAT8', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Coach', 'MAJSTAT2', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.CoachNoGroup', 'MAJSTAT6', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Rail', 'MAJSTAT3', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.RailNoGroup', 'MAJSTAT7', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.Undetermined', 'MAJSTAT1', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.majorstationsgazetteerid.UndeterminedNoGroup', 'MAJSTAT5', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.maxreturnedrecords', '60', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.partpostcodegazetteerid', 'PCODE2', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.postcodegazetteerid', 'PCODE1', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.servername', 'GIS', @AID_RHost, @GID_RHost, 0, 1)
	INSERT INTO [properties] VALUES ('locationservice.servicename', 'tdparc93', @AID_RHost, @GID_RHost, 0, 1)

END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1921
SET @ScriptDesc = 'Script to update properties for the Location service'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO