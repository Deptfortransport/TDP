-- *************************************************************************************
-- NAME 		: DUP1769_Update_TL_Reporting.sql
-- DESCRIPTION  	: Enhancements to TL reporting tables to reflect that
--			  MDV are taking over the South West Traveline
-- AUTHOR		: Neil Rankin
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Reporting]
GO

--------------
-- Add KPI15
--------------

IF NOT EXISTS (SELECT * FROM [Reporting].[dbo].[ReferenceTransactionType] WHERE [RTTCode] ='KPI15')
	BEGIN
	INSERT INTO [ReferenceTransactionType] values(79,'KPI15','Direct - SW','false','false',0,95.00000,90.00000,'Direct',0,10)
	END
GO

--------------
-- Add KPI16
--------------

IF NOT EXISTS (SELECT * FROM [Reporting].[dbo].[ReferenceTransactionType] WHERE [RTTCode] ='KPI16')
	BEGIN
	INSERT INTO [ReferenceTransactionType] values(80,'KPI16','Direct - SW','false','false',0,95.00000,90.00000,'Portal',0,10)
	END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1769
SET @ScriptDesc = 'Update_TL_Reporting'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO