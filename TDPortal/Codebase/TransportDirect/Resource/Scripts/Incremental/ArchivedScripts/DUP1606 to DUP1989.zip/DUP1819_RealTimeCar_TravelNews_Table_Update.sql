-- ***********************************************
-- NAME           : DUP1819_RealTimeCar_TravelNews_Table_Update.sql
-- DESCRIPTION    : Script to update travel news tables necessary for Real Time Car
-- AUTHOR         : Amit Patel
-- DATE           : 18 Aug 2011
-- ***********************************************

USE [TransientPortal] 
GO 


-----------------------------------------------
-- TravelNewsToid Table
-----------------------------------------------

-- Drop Existing TravelNewsToid Table

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TravelNewsToid]') AND type in (N'U'))
BEGIN
	DROP TABLE [dbo].[TravelNewsToid]
END
GO


-- Create TravelNewsToid table
IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[TravelNewsToid]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[TravelNewsToid](
		[TOID] [varchar](25) NOT NULL,
		[UID] [varchar](25) NOT NULL,
		CONSTRAINT [PK_TravelNewsToid] PRIMARY KEY CLUSTERED 
		(
			[TOID] ASC,
			[UID]  ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]
	
END

GO
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1819
SET @ScriptDesc = 'Script to update travel news tables necessary for Real Time Car'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO