-- ***********************************************
-- NAME 		: DUP1750_CyclePlanner_EES_EventLogging_Properties.sql
-- DESCRIPTION 	: Script to add Cycle Planner request/result event property values for EES
-- AUTHOR		: Amit Patel
-- DATE			: 15 Sep 2008
-- ************************************************

USE [PermanentPortal]
GO


-- ****** IMPORTANT ******
-- 1) Where indicated, please change the value 'FILE1' value below to 'QUEUE1' for the Production environments
-- ***********************

------------------------------------------------------
-- Update existing custom event properties to also mointor for CYCLEPLANNERREQUEST and CYCLEPLANNERRESULT events

DECLARE @LoggingEventCustom VARCHAR(500)


SET @LoggingEventCustom = ( select pValue from properties 
                            where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the events multiple times if the script is run more than once
    IF not exists ( select top 1 * from properties 
                    where pvalue like '%CYCLEPLANNERREQUEST CYCLEPLANNERRESULT GRADIENTPROFILEEVENT%' and pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @LoggingEventCustom + ' CYCLEPLANNERREQUEST CYCLEPLANNERRESULT GRADIENTPROFILEEVENT'
    	where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1
    END
END





------------------------------------------------------
-- Cycle planner request setup
delete from properties where pname like 'Logging.Event.Custom.CYCLEPLANNERREQUEST.%' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1

-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Assembly', 'td.userportal.cycleplannercontrol', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Name', 'CyclePlannerRequestEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)

------------------------------------------------------
-- Cycle planner result setup
delete from properties where pname like 'Logging.Event.Custom.CYCLEPLANNERRESULT.%' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1

-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERRESULT.Assembly', 'td.userportal.cycleplannercontrol', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERRESULT.Name', 'CyclePlannerResultEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERRESULT.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.CYCLEPLANNERRESULT.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)

------------------------------------------------------
-- Gradient Profile event setup
delete from properties where pname like 'Logging.Event.Custom.GRADIENTPROFILEEVENT.%' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1 

-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Assembly', 'td.userportal.cycleplannercontrol', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Name', 'GradientProfileEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.GRADIENTPROFILEEVENT.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1750
SET @ScriptDesc = 'Cycle planner request and result event properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO