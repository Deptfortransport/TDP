-- ***********************************************
-- NAME 			: DUP1824_RealTimeCar_ReportStaging_Tables_RealTimeRoadEvent.sql
-- DESCRIPTION 		: Script to add table for RealTimeRoadEvent
-- AUTHOR			: Amit Patel
-- DATE				: 22 Aug 2011
-- ***********************************************

USE [ReportStagingDB]
GO

----------------------------------------------------------------
-- Create EBCCalculationEvent table
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RealTimeRoadEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[RealTimeRoadEvent]
GO

CREATE TABLE [dbo].[RealTimeRoadEvent] (
	[Id] [bigint] IDENTITY (1, 1) NOT NULL ,
	[RealTimeRoadType] [varchar] (50) NULL ,
	[RealTimeFound] [bit] NULL,
	[Submitted] [datetime] NULL,
	[SessionId] [varchar] (50) NULL,
	[TimeLogged] [datetime] NULL,
	[Success] [bit] NULL 
) ON [PRIMARY]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1824
SET @ScriptDesc = 'Add ReportStaging tables for RealTimeRoadEvent'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
