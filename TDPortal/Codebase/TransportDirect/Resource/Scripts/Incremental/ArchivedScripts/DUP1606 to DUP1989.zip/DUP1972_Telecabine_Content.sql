-- ***********************************************
-- NAME 		: DUP1972_Telecabine_Content.sql
-- DESCRIPTION 	: Telecabine content
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Jan 13
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'DataServices.PublicTransportsCheck.Telecabine',
	'Cable car (London only)',
	'Car cebl (London only)'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'JourneyPlannerAmbiguity.labelTelecabine',
	'Cable car',
	'Cable car'

EXEC AddtblContent
	1, 1, 'langStrings', 'JourneyDetailsControl.imageTelecabineUrl',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/telecabine.png',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/telecabine.png'

EXEC AddtblContent
	1, 1, 'langStrings', 'TransportMode.Telecabine.ImageAlternateText',
	'Cable car',
	'Car cebl'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'TransportMode.Telecabine',
	'Cable car',
	'Car cebl'

EXEC AddtblContent
	1, 1, 'langStrings', 'TransportModeLowerCase.Telecabine',
	'cable car',
	'car cebl'

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1972
SET @ScriptDesc = 'Telecabine content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO