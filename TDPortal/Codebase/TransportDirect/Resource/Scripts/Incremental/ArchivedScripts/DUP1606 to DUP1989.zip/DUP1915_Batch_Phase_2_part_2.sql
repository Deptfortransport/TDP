-- ***********************************************
-- NAME 		: DUP1915_Batch_Phase_2_part_2.sql
-- DESCRIPTION 	: Script to update content for batch
-- AUTHOR		: David Lane
-- DATE			: 30 Aug 2012
-- ************************************************

USE Content
GO

EXEC AddtblContent 
1,1,'langstrings','BatchJourneyPlanner.ActivatedEmailBody', 'Placeholder - Activation email body', 'Placeholder - Activation email body'
GO

EXEC AddtblContent 
1,1,'langstrings','BatchJourneyPlanner.ActivatedEmailTitle', 'Placeholder - Activation email title', 'Placeholder - Activation email title'
GO

EXEC AddtblContent 
1,1,'langstrings','BatchJourneyPlanner.HeaderNumberPartials', 'Number of partial failures', 'Number of partial failures'
GO

EXEC AddtblContent 
1,1,'langstrings','BatchJourneyPlanner.ActivatedEmailBody', 'Dear Sir/Madam,

We have approved your recent request for access to the Transport Direct Batch Journey Planner.

To get started, please log into Transport Direct, then click the "Batch journey planner" link on the homepage (under "Tips and tools").  This will take you to the Batch Journey Planner input page, which also contains a link to the pdf User Guide.

We may contact you very occasionally for feedback about the Batch Journey Planner, but if you wish to send any comments or ask for assistance, please use the email address shown on the last page of the User Guide.

Thank you for your interest in Transport Direct and we hope that you find the Batch Journey Planner useful.  

Yours sincerely,

Tom Herring
Business Service Manager
Transport Direct', 'Dear Sir/Madam,

We have approved your recent request for access to the Transport Direct Batch Journey Planner.

To get started, please log into Transport Direct, then click the "Batch journey planner" link on the homepage (under "Tips and tools").  This will take you to the Batch Journey Planner input page, which also contains a link to the pdf User Guide.

We may contact you very occasionally for feedback about the Batch Journey Planner, but if you wish to send any comments or ask for assistance, please use the email address shown on the last page of the User Guide.

Thank you for your interest in Transport Direct and we hope that you find the Batch Journey Planner useful.  

Yours sincerely,

Tom Herring
Business Service Manager
Transport Direct'
GO

EXEC AddtblContent 
1,1,'langstrings','BatchJourneyPlanner.ActivatedEmailTitle', 'Transport Direct batch journey planner access request', 'Transport Direct batch journey planner access request'
GO


-- Stored procs
USE BatchJourneyPlanner
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[SetUserStatus]
(
	@EmailAddress nvarchar(250),
	@StatusId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Change the user's status
	UPDATE RegisteredUser
		SET UserStatusId = @StatusId,
		StatusChanged = GETDATE()
		WHERE EmailAddress = @EmailAddress

	RETURN 0
END
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1915
SET @ScriptDesc = 'Script to update content for batch'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO