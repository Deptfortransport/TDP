-- ***********************************************
-- NAME 		: DUP1784_UserFeedbackEvent_Properties_Update.sql
-- DESCRIPTION 		: Script to update Event Receiver properties
-- AUTHOR		: Mark Turner
-- DATE			: 02 Dec 2011
-- ************************************************

USE [PermanentPortal]
GO


IF not exists ( select top 1 * from properties where pName = 'Logging.Event.Custom' AND AID = 'EventReceiver')
BEGIN
	insert into properties values ('Logging.Event.Custom',
				'LOC GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE JOURNEYWEBREQUEST GATE REFERENCETRANSACTION WORKLOAD ROE INTERNALREQUEST RTTI EXP STOPEVENT MOBILEPAGE LANDING EnhancedExposedServiceStartEvent EnhancedExposedServiceFinishEvent RTTIInternal CYCLEPLANNERREQUEST CYCLEPLANNERRESULT GRADIENTPROFILEEVENT EBCCalculation MapAPI INTLPLANNERREQUEST INTLPLANNERRESULT INTLPLANNEREVENT USERFEEDBACK',
				'EventReceiver', 'ReportDataProvider', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'LOC GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE JOURNEYWEBREQUEST GATE REFERENCETRANSACTION WORKLOAD ROE INTERNALREQUEST RTTI EXP STOPEVENT MOBILEPAGE LANDING EnhancedExposedServiceStartEvent EnhancedExposedServiceFinishEvent RTTIInternal CYCLEPLANNERREQUEST CYCLEPLANNERRESULT GRADIENTPROFILEEVENT EBCCalculation MapAPI INTLPLANNERREQUEST INTLPLANNERRESULT INTLPLANNEREVENT USERFEEDBACK'
	where pname = 'Logging.Event.Custom'
	and AID = 'EventReceiver' 
END

IF not exists ( select top 1 * from properties where pName = 'Logging.Event.Custom' AND AID = 'EventReceiverGroup')
BEGIN
	insert into properties values ('Logging.Event.Custom',
				'LOC GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE JOURNEYWEBREQUEST GATE REFERENCETRANSACTION WORKLOAD ROE INTERNALREQUEST RTTI EXP STOPEVENT MOBILEPAGE LANDING EnhancedExposedServiceStartEvent EnhancedExposedServiceFinishEvent RTTIInternal CYCLEPLANNERREQUEST CYCLEPLANNERRESULT GRADIENTPROFILEEVENT EBCCalculation MapAPI INTLPLANNERREQUEST INTLPLANNERRESULT INTLPLANNEREVENT USERFEEDBACK',
				'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'LOC GAZ LOGIN MAP PAGE REPEATVISITOR RETAIL PREF JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE JOURNEYWEBREQUEST GATE REFERENCETRANSACTION WORKLOAD ROE INTERNALREQUEST RTTI EXP STOPEVENT MOBILEPAGE LANDING EnhancedExposedServiceStartEvent EnhancedExposedServiceFinishEvent RTTIInternal CYCLEPLANNERREQUEST CYCLEPLANNERRESULT GRADIENTPROFILEEVENT EBCCalculation MapAPI INTLPLANNERREQUEST INTLPLANNERRESULT INTLPLANNEREVENT USERFEEDBACK'
	where pname = 'Logging.Event.Custom'
	and AID = 'EventReceiverGroup' 
END

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1784
SET @ScriptDesc = 'Script to update Event Receiver properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO