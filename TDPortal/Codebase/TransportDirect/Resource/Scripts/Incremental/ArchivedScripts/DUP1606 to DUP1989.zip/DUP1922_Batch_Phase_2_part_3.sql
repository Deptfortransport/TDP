-- ***********************************************
-- NAME 		: DUP1922_Batch_Phase_2_part_3.sql
-- DESCRIPTION 	: Script to update content for batch
-- AUTHOR		: David Lane
-- DATE			: 30 Aug 2012
-- ************************************************

USE BatchJourneyPlanner
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO

-- GetUsers proc
ALTER PROCEDURE [dbo].[GetUsers]
(
	@Page int,
	@SortColumn nvarchar(100),
	@SortDirection nvarchar(5)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Paging (20 per page)
	DECLARE @StartRow int
	DECLARE @EndRow int
	SET @StartRow = 20 * (@Page - 1) + 1
	SET @EndRow = @StartRow + 19
	
	DECLARE @Total int
	SELECT @Total = COUNT(*)
		FROM RegisteredUser;
	
	-- Output the results
	WITH Results AS
	(SELECT [EmailAddress]
		,brs.QueuedDateTime
		,us.UserStatusDescription
		,ru.StatusChanged
		,ROW_NUMBER() OVER 
			(ORDER BY
				CASE WHEN @SortColumn = 'User' AND @SortDirection = 'asc' THEN EmailAddress END ASC,
				CASE WHEN @SortColumn = 'User' AND @SortDirection = 'desc' THEN EmailAddress END DESC,
				CASE WHEN @SortColumn = 'StatusChange' AND @SortDirection = 'asc' THEN ru.StatusChanged END ASC,
				CASE WHEN @SortColumn = 'StatusChange' AND @SortDirection = 'desc' THEN ru.StatusChanged END DESC,
				CASE WHEN @SortColumn = 'LastFileUpload' AND @SortDirection = 'asc' THEN brs.QueuedDateTime END ASC,
				CASE WHEN @SortColumn = 'LastFileUpload' AND @SortDirection = 'desc' THEN brs.QueuedDateTime END DESC,
				CASE WHEN @SortColumn = 'Status' AND @SortDirection = 'asc' THEN ru.UserStatusId END ASC, --EmailAddress,
				CASE WHEN @SortColumn = 'Status' AND @SortDirection = 'desc' THEN ru.UserStatusId END DESC --, EmailAddress
			) 
			AS RowNumber
	FROM [BatchJourneyPlanner].[dbo].[RegisteredUser] ru
	INNER JOIN [BatchJourneyPlanner].[dbo].[UserStatus] us
	ON ru.UserStatusId = us.UserStatusId
	LEFT JOIN [BatchJourneyPlanner].[dbo].[BatchRequestSummary] brs
	ON ru.UserId = brs.UserId
	AND brs.QueuedDateTime = (SELECT MAX(brs2.QueuedDateTime)
						FROM BatchJourneyPlanner.dbo.BatchRequestSummary brs2
						WHERE brs2.UserId = brs.UserId))

	SELECT * FROM Results
	WHERE RowNumber >= @StartRow
	AND RowNumber <= @EndRow
	ORDER BY RowNumber ASC
	
	RETURN @Total
END
GO

USE Content
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchUserAdmin.ImageUrl',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/Misc/Batch_lrg.gif'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1922
SET @ScriptDesc = 'Script to update content for batch'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO