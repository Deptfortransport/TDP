-- ***********************************************
-- NAME 		: DUP1932_WelshForBatch.sql
-- DESCRIPTION 	: Addition of welsh translations for batch
-- AUTHOR		: David Lane
-- DATE			: 30 Oct 12
-- ************************************************

USE [Content]
GO

-------------------------------
-- Add to Content
-------------------------------

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.AppendPageTitle',
	'Batch Journey Planning |',
	'Cynllunio Amldeithiau |'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.PageTitle',
	'Batch Journey Planner',
	'Cynllunydd Amldeithiau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.AlreadyApproved',
	'Already an approved user of the batch journey planner?',
	'Ydych chi eisoes yn ddefnyddiwr Cynllunydd Amldeithiau cymeradwy?'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WhatIs',
	'What is the batch Journey Planner?',
	'Beth yw''r Cynllunydd Amldeithiau?'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HowRegister',
	'How do I apply to be a user of the Batch Journey Planner?',
	'Sut ydw i''n gwneud cais am ddefnyddio''r Cynllunydd Amldeithiau?'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegdAs',
	'You have registered with Transport Direct with the following email address: <strong>{0}</strong>',
	'Rydych wedi defnyddio''r cyfeiriad e-bost canlynol i gofrestru � Transport Direct: <strong>{0}</strong>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.FirstName',
	'First Name<strong>*</strong>:',
	'Enw cyntaf<strong>*</strong>:'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LastName',
	'Last Name<strong>*</strong>:',
	'Cyfenw<strong>*</strong>:'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Phone',
	'Phone number<strong>*</strong>:',
	'Rhif ff�n<strong>*</strong>:'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ProposedUse',
	'Please outline your proposed use of the batch journey planner<strong>*</strong>',
	'Eglurwch yn fras i beth y byddwch yn defnyddio''r Cynllunydd Amldeithiau<strong>*</strong>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Mandatory',
	'<strong>*</strong> indicates the field is mandatory',
	'<strong>*</strong> mae''n nodi fod y maes yn orfodol'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.EmailsText',
	'<br>You should receive an email confirming your request for registration then another confirming when your registration has been activated. This should take no more than two working days.',
	'<br>Dylech dderbyn e-bost yn cadarnhau eich cais am gofrestru yna un arall yn cadarnhau pryd y bydd eich cofrestriad yn cael ei actifadu. Ni ddylai hyn gymryd mwy na dau ddiwrnod gwaith.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.MoreInfo',
	'<br>For more information about the batch journey planner, please read the <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">Batch journey planner - Frequently Asked Questions</a>',
	'<br>I gael rhagor o wybodaeth am y Cynllunydd Amldeithiau, darllenwch <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">''Cynllunydd Amldeithiau - Cwestiynau a Ofynnir yn Aml</a>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WhatIs.SC',
	'It is an automated service providing detailed directions or statistics for a large number of journeys. See <a target="_child" href="/Web2/Downloads/BatchJourneyPlannerBrochure.pdf">brochure</a> and <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">FAQ</a> for details.',
	'Mae hwn yn wasanaeth awtomataidd sy''n darparu cyfarwyddiadau manwl neu ystadegau ar gyfer nifer fawr o deithiau. Gweler llyfryn.pdf - Cynllunydd Amldeithiau am ragor o fanylion.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.AlreadyApproved.SC',
	'Please <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx?loginregister=true">log in</a> then continue to the <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx">Registered User Options Page</a>',
	'Mewngofnodwch yna ewch ymlaen i Dudalen Opsiynau Defnyddwyr Cofrestredig'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HowRegister.SC',
	'Please <a href="/Web2/BatchJourneyPlanner/BatchJourneyPlanner.aspx?loginregister=true">log in/register</a> then complete the form below and indicate that you agree to our terms and conditions.  You will receive an email confirming receipt of your request, then another when your batch user account has been activated.  This should take no more than two working days.',
	'Mewngofnodwch yna cwblhewch y ffurflen isod a nodwch eich bod yn cytuno �''n telerau a''n hamodau. Byddwch yn derbyn e-bost yn cadarnhau ein bod wedi derbyn eich cais, yna un arall pan fydd eich cyfrif defnyddiwr amldeithiau wedi ei actifadu.  Ni ddylai hyn gymryd mwy na dau ddiwrnod gwaith.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ChkTerms',
	'Accept Terms and Conditions',
	'Derbyn Telerau ac Amodau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Welcome',
	'<p>&nbsp;</p>Welcome to the batch journey planner. Please use the template provided to create request files to upload requests.<p>&nbsp;</p>',
	'<p>&nbsp;</p>Croeso i''r Cynllunydd Amldeithiau. Defnyddiwch y templed a ddarperir i greu ffeiliau cais i lwytho ceisiadau i fyny.<p>&nbsp;</p>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Upload',
	'New Request',
	'Cais newydd'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.UploadInstructions',
	'<p>&nbsp;</p>To request journey plans or statistics for a new set of journeys, first create your journeys file in CSV, then choose from the options below before uploading it.  See the <a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">User Guide</a> for detailed instructions.<p>&nbsp;</p>',
	'<p>&nbsp;</p>I wneud cais am gynlluniau teithiau neu ystadegau ar gyfer set newydd o deithiau, yn gyntaf dylech greu eich ffeil deithiau ar ffurf CSV, yna dewis o''r opsiynau isod cyn ei llwytho i fyny. <a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">Gweler cyfarwyddiadau manwl yn y Canllaw i Ddefnyddwyr.</a><p>&nbsp;</p>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Output',
	'Output required',
	'Angen allbwn'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckStats',
	'Journey statistics',
	'Ystadegau teithiau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckDetails',
	'Journey plans *',
	'Cynlluniau teithiau *'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Types',
	'Journey type(s) required',
	'Math(au) o deithiau sydd eu hangen'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckPublic',
	'Public transport',
	'Cludiant cyhoeddus'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckCar',
	'Car',
	'Car'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CheckCycle',
	'Cycle',
	'Beic'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Format',
	'* Should your output format be',
	'*A ddylai eich fformat allbwn fod yn'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Template',
	'How to use the Batch Journey Planner',
	'Sut i ddefnyddio''r Cynllunydd Amldeithiau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.TemplateDesc',
	'<p>&nbsp;</p>1 - Read the User Guide<br/>   2 - Download the CSV template file and populate it with your set of journeys<br/>   3 - Upload the CSV file using the "New request" form<br/>   4 - Collect your results when they appear in the table below<br/>',
	'<p>&nbsp;</p>1 - Darllenwch y Canllaw i Ddefnyddwyr<br/>   2 - Lawrlwythwch y ffeil templed CSV a''i llenwi �''ch set o deithiau<br/>   3 - Llwythwch y ffeil CSV i fyny gan ddefnyddio''r ffurflen "Cais newydd"<br/>  4 - Casglwch eich canlyniadau pan fyddant yn ymddangos yn y tabl isod<br/>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LinkTemplate',
	'<p>&nbsp;</p><a target="_child" href="/Web2/BatchJourneyPlanner/Template.csv">CSV template file</a>',
	'<p>&nbsp;</p><a target="_child" href="/Web2/BatchJourneyPlanner/Template.csv">Ffeil templed CSV</a>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LinkTemplateDesc',
	'<p>&nbsp;</p><a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">Batch Journey Planner user guide</a>',
	'<p>&nbsp;</p><a target="_child" href="/Web2/Downloads/BatchJourneyPlannerUserGuide.pdf">Cynllunydd Amldeithiau - Canllaw i Ddefnyddwyr</a>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NotLoggedIn',
	'<p>&nbsp;</p>You must be logged in to use this service. Please log in by clicking Login / Register on the menu tab bar<p>&nbsp;</p>',
	'<p>&nbsp;</p>Rhaid ichi fod wed mewngofnodi i ddefnyddio''r gwasanaeth hwn. Mewngofnodwch drwy glicio ar y tab Logio i Mewn / Cofrestru ar y ddewislen<p>&nbsp;</p>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegistrationPending',
	'<p>&nbsp;</p>You have registered for batch journey planning however your registration has yet to be approved. Please wait to be contacted.<p>&nbsp;</p>',
	'<p>&nbsp;</p>Rydych wedi cofrestru ar gyfer Cynllunio Amldeithiau, fodd bynnag nid yw eich cofrestriad wedi ei gymeradwyo eto. Disgwyliwch os gwelwch yn dda nes byddwn yn cysylltu � chi.<p>&nbsp;</p>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegistrationSuspended',
	'<p>&nbsp;</p>You have registered for batch journey planning however your registration has been suspended. You may not use the batch journey planner.<p>&nbsp;</p>',
	'<p>&nbsp;</p>Rydych wedi cofrestru ar gyfer Cynllunio Amldeithiau, fodd bynnag mae eich cofrestriad wedi ei ohirio. Ni allwch ddefnyddio''r Cynllunydd Amldeithiau.<p>&nbsp;</p>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegButton',
	'Register',
	'Mewnbynnwch '
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoFirstName',
	'<p>&nbsp;</p>Please enter your first name',
	'<p>&nbsp;</p>Mewnbynnwch eich enw cyntaf'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoLastName',
	'<p>&nbsp;</p>Please enter your last name',
	'<p>&nbsp;</p>Mewnbynnwch eich cyfenw'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoPhone',
	'<p>&nbsp;</p>Please enter a valid phone number - this can include numbers, spaces, "(", ")" and "+"',
	'<p>&nbsp;</p>Mewnbynnwch rif ff�n dilys - gall hwn gynnwys rhifau, bylchau, "(", ")" a "+"'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoUsage',
	'<p>&nbsp;</p>Please enter a usage reason',
	'<p>&nbsp;</p>Nodwch reswm dros ddefnyddio'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.BadRecaptcha',
	'<p>&nbsp;</p>Please enter the words displayed',
	'<p>&nbsp;</p>Mewnbynnwch y geiriau sy''n cael eu harddangos'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoTerms',
	'<p>&nbsp;</p>Please accept the terms and conditions',
	'<p>&nbsp;</p>Derbyniwch y telerau a''r amodau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Confirmation',
	'<p>&nbsp;</p>Thank you for applying to use the batch journey planner. We will be in touch soon.<p>&nbsp;</p><a href="/Web2/Home.aspx">Return to Transport Direct homepage</a>',
	'<p>&nbsp;</p>Diolch ichi am wneud cais i ddefnyddio''r Cynllunydd Amldeithiau. Byddwn yn cysylltu � chi yn fuan.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegEmailBody',
	'Dear {0} {1},

Thank you for requesting access to the Transport Direct Batch Journey Planner. You gave us the following reason for requiring access: "{2}". Your request is being processed; we will confirm the results of your application within 10 working days. We will be in touch shortly to advise whether your request for access to the batch journey planner has been successful or not.

We regret that we cannot enter into correspondence through this e-mail address. If you wish to contact Transport Direct, please do so via the "Contact us" link.

Yours sincerely,
Tom Herring
Business Service Manager
Transport Direct',
	'Annwyl {0} {1},

Diolch ichi am wneud cais am fynediad i Gynllunydd Amldeithiau Transport Direct. Rhoddwyd y rheswm canlynol gennych dros ofyn am fynediad: "{2}". Mae eich cais yn cael ei brosesu; byddwn yn cadarnhau canlyniadau eich cais o fewn 10 diwrnod gwaith. Byddwn yn cysylltu � chi yn fuan i roi gwybod ichi a yw eich cais am fynediad i''r cynllunydd amldeithiau wedi bod yn llwyddiannus ai peidio.

Mae''n ddrwg gennym na allwn ddefnyddio''r cyfeiriad e-bost hwn i ddibenion gohebu. Os hoffech gysylltu � Transport Direct, gwnewch hynny drwy''r ddolen "Cysylltwch � ni".

Yn gywir,
Tom Herring
Rheolwr Gwasanaeth Busnes
Transport Direct'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RegEmailTitle',
	'Transport Direct New Batch User Request',
	'Cais Defnyddiwr Newydd Cynllunydd Amldeithiau Transport Direct'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ButtonLoadFile',
	'Load file',
	'Llwytho ffeil'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WrongFileType',
	'<p>&nbsp;</p>You may only upload .csv files. Please select a .csv file to upload.',
	'<p>&nbsp;</p>Dim ond ffeiliau .csv y gellir eu llwytho i fyny. Dewiswch ffeil .csv i''w llwytho i fyny.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoFileSelected',
	'<p>&nbsp;</p>Please browse to your CSV file before clicking "Load file".',
	'<p>&nbsp;</p>Porwch i''ch ffeil CSV cyn clicio ar  "Llwytho ffeil".'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.FileUploadFailed',
	'<p>&nbsp;</p>Sorry the file you selected could not be uploaded.',
	'<p>&nbsp;</p>Yn anffodus nid oedd yn bosibl llwytho''r ffeil a ddewiswyd gennych.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.EmptyFile',
	'<p>&nbsp;</p>Sorry the file you selected was empty and cannot be processed.',
	'<p>&nbsp;</p>Yn anffodus roedd y ffeil a ddewiswyd gennych yn wag ac ni ellir ei phrosesu.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.WrongHeader',
	'<p>&nbsp;</p>Sorry the file you selected had incorrect headers, the first line should read "JourneyID,OriginType,Origin,DestinationType,Destination,OutwardDate,OutwardTime,OutwardArrDep,ReturnDate,ReturnTime,ReturnArrDep".',
	'<p>&nbsp;</p>Yn anffodus roedd penawdau''r ffeil a ddewiswyd gennych yn anghywir, dylai''r llinell gyntaf ddweud "JourneyID,OriginType,Origin,DestinationType,Destination,OutwardDate,OutwardTime,OutwardArrDep,ReturnDate,ReturnTime,ReturnArrDep".'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.StatsDetails',
	'<p>&nbsp;</p>Please choose at least one output (journey statistics and/or journey plans).',
	'<p>&nbsp;</p>Dewiswch o leiaf un allbwn (ystadegau taith a/neu gynlluniau taith).'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.PtCarCycle',
	'<p>&nbsp;</p>Please choose at least one of public transport, car and cycle.',
	'<p>&nbsp;</p>Dewiswch o leiaf un o''r canlynol, cludiant cyhoeddus, car a beicio.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.XmlRtf',
	'<p>&nbsp;</p>Please choose either RTF or XML.',
	'<p>&nbsp;</p>Dewiswch un ai RTF neu XML.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.MaxFileLength',
	'<p>&nbsp;</p>The maximum number of request lines has been exceeded. Please try a smaller file.',
	'<p>&nbsp;</p>Mae nifer llinellau''r cais yn fwy na''r nifer macsimwm. Rhowch gynnig ar ffeil sy''n llai o ran maint.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.UploadSuccess',
	'<p>&nbsp;</p>Request {0} has been successfully uploaded to the Batch Journey Planner and placed in the queue to be processed. Your request is {1} in the queue to be processed.',
	'<p>&nbsp;</p>Mae cais {0} wedi cael ei lwytho i fyny yn llwyddiannus i''r Cynllunydd Amldeithiau ac wedi ei osod yn y ciw i''w brosesu. Mae eich cais yn safle {1} yn y ciw i gael ei brosesu.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ResultsLabel',
	'<p>&nbsp;</p>Please select the results file you wish to download.',
	'<p>&nbsp;</p>Dewiswch y ffeil ganlyniadau y dymunwch ei lawrlwytho.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.BatchTableLabel',
	'Recent batch activity for {0}',
	'Gweithgarwch amldeithiau diweddar ar gyfer {0}'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderRequestId',
	'Request ID',
	'Cais am rif adnabod'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderSubmitted',
	'Submitted',
	'Cyflwynwyd ar'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderPublicTransport',
	'Public Transport',
	'Cludiant cyhoeddus'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderCar',
	'Car',
	'Car'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderCycle',
	'Cycle',
	'Beic'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberRequests',
	'Number of requests',
	'Nifer o geisiadau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberResults',
	'Number of results',
	'Nifer o ganlyniadau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderValidationErrors',
	'Validation errors',
	'Gwallau dilysu'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderNumberNoResults',
	'No results',
	'Dim canlyniadau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderDateComplete',
	'Date complete',
	'Dyddiad cwblhau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderStatus',
	'Status',
	'Statws'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.HeaderSelect',
	'Select',
	'Dewis'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ButtonReload',
	'Reload',
	'Ail-lwytho'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.ButtonDownload',
	'Download',
	'Lawrlwytho'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.LabelFaq',
	'For more information about the batch journey planner, please read the <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">Batch Journey Planner - Frequently Asked Questions</a>',
	'I gael rhagor o wybodaeth am y cynllunydd amldeithiau, <a href="/Web2/Help/HelpBatchJourneyPlanner.aspx">darllenwch y Cynllunydd Amldeithiau - Cwestiynau a Ofynnir yn Aml</a>'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoDetailRows',
	'<p>&nbsp;</p>Sorry the file you selected did not contain any requests.',
	'<p>&nbsp;</p>Yn anffodus nid oedd y ffeil a ddewiswyd gennych yn cynnwys unrhyw geisiadau.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'HomeTipsTools.imageBatchJourneyPlanner.AlternateText',
	'Batch Journey Planner',
	'Cynllunydd Amldeithiau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'HomeTipsTools.lblBatchJourneyPlanner',
	'Batch Journey Planner',
	'Cynllunydd Amldeithiaur'
GO



--- New content strings

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Previous',
	'Previous',
	'Blaenorol'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.Next',
	'Next',
	'Nesaf'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NavLabel',
	'Page {0} of {1}',
	'Tudalen {0} o {1}'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.BatchDisabled',
	'Sorry Batch Journey Planning is currently disabled and is not available for use',
	'Yn anffodus mae Cynllunio Amldeithiau wedi ei analluogi ar hyn o bryd ac ni ellir ei ddefnyddio'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.NoRowSelected',
	'Please select a row before clicking download.',
	'Dewiswch res cyn clicio ar lawrlwytho'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.CompletedOnly',
	'Only completed batches can be downloaded.',
	'Dim ond sypiau a gwblhawyd y gellir eu lawrlwytho.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.FailedBatch',
	'This batch did not complete successfully so cannot be downloaded.',
	'Ni chafodd y swp hwn ei gwblhau''n llwyddiannus felly ni ellir ei lawrlwytho.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.BatchDeleted',
	'The batch results have been deleted so cannot be downloaded.',
	'Mae canlyniadau''r swp wedi eu dileu felly ni ellir eu lawrlwytho.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'BatchJourneyPlanner.RetrievalFailure',
	'Sorry the batch results could not be retrieved.',
	'Yn anffodus nid oedd yn bosibl adalw canlyniadau''r swp.'
GO

-- Left hand links
USE TransientPortal

-- Update welsh for left hand links
EXECUTE [TransientPortal].[dbo].[AddResource] 
   'BatchJourneyPlanner'
  ,'Batch journey planner'
  ,'Cynllunydd amldeithiau'
  

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1932
SET @ScriptDesc = 'Welsh translations for batch'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO