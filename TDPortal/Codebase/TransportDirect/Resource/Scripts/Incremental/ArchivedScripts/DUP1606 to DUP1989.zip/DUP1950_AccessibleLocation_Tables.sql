-- ***********************************************
-- NAME           : DUP1950_AccessibleLocation_Tables.sql
-- DESCRIPTION    : Script to create accessible location tables
-- AUTHOR         : Mitesh Modi
-- DATE           : 14 Nov 2012
-- ***********************************************

USE [AtosAdditionalData]
GO 

-- **************************************
-- [AccessibleLocations]

-- Drop existing table (OK to drop, this is first time table is being created in TDP)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AccessibleLocations]') AND type in (N'U'))
BEGIN
	DROP TABLE [dbo].[AccessibleLocations]
END
GO

---- Create table
IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[AccessibleLocations]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[AccessibleLocations] (
		[StopNaPTAN]        VARCHAR (20)		NOT NULL,
		[StopName]          NVARCHAR (150)		NOT NULL,
		[StopAreaNaPTAN]    NVARCHAR (20)		NULL,
		[StopOperator]      NVARCHAR (8)		NULL,
		[WheelchairAccess]  BIT					NOT NULL,
		[AssistanceService] BIT					NOT NULL,
		[WEFDate]           DATE				NOT NULL,
		[WEUDate]           DATE				NOT NULL,
		[MOFRStartTime]     TIME (0)			NOT NULL,
		[MOFREndTime]       TIME (0)			NOT NULL,
		[SatStartTime]      TIME (0)			NOT NULL,
		[SatEndTime]        TIME (0)			NOT NULL,
		[SunStartTime]      TIME (0)			NOT NULL,
		[SunEndTime]        TIME (0)			NOT NULL,
		[StopCountry]		NVARCHAR(20)		NOT NULL,
		[AdministrativeAreaCode] INT	    	NOT NULL,
		[NPTGDistrictCode]  INT		    		NOT NULL,
		[StopType]			NVARCHAR(20)		NOT NULL
	);
END

-- Add primary key
ALTER TABLE [dbo].[AccessibleLocations]
    ADD CONSTRAINT [PK_AccessibleLocations]
    PRIMARY KEY CLUSTERED 
    (
		[StopNaptan] ASC
	)WITH (ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF);

-- **************************************
GO

-- **************************************
-- [AccessibleAdminAreas]

-- Drop existing table (OK to drop, this is first time table is being created in TDP)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AccessibleAdminAreas]') AND type in (N'U'))
BEGIN
	DROP TABLE [dbo].[AccessibleAdminAreas]
END
GO

-- Create table
IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[AccessibleAdminAreas]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[AccessibleAdminAreas]
	(
		[AdministrativeAreaCode]    VARCHAR (50) NOT NULL,
		[DistrictCode]              VARCHAR (50) NOT NULL,
		[StepFree]					BIT	NOT NULL,
		[Assistance]				BIT	NOT NULL
	)
END

-- Add primary key
ALTER TABLE [dbo].[AccessibleAdminAreas]
	ADD CONSTRAINT [PK_AccessibleAdminAreas]
	PRIMARY KEY CLUSTERED
	(
		[AdministrativeAreaCode]    ASC,
		[DistrictCode]              ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	
-- **************************************

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1950
SET @ScriptDesc = 'Script to create accessible location tables'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO