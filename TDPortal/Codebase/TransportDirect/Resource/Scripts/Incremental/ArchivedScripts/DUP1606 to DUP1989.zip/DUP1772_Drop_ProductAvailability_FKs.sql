-- ***********************************************
-- NAME 		: DUP1772_Drop_ProductAvailability_FKs.sql
-- DESCRIPTION  : Drop various ProductAvailability FKs as they are uneccessary and cause problems updating MDS ticket data
-- AUTHOR		: Rich Broddle
-- DATE			: 08-12-10
-- ************************************************


USE [ProductAvailability]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_UnavailableProducts_TicketCategory]') AND parent_object_id = OBJECT_ID(N'[dbo].[UnavailableProducts]'))
ALTER TABLE [dbo].[UnavailableProducts] DROP CONSTRAINT [FK_UnavailableProducts_TicketCategory]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ProductProfile_Category]') AND parent_object_id = OBJECT_ID(N'[dbo].[ProductProfile]'))
ALTER TABLE [dbo].[ProductProfile] DROP CONSTRAINT [FK_ProductProfile_Category]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ProductProfile_DayType]') AND parent_object_id = OBJECT_ID(N'[dbo].[ProductProfile]'))
ALTER TABLE [dbo].[ProductProfile] DROP CONSTRAINT [FK_ProductProfile_DayType]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ProductProfile_Probability]') AND parent_object_id = OBJECT_ID(N'[dbo].[ProductProfile]'))
ALTER TABLE [dbo].[ProductProfile] DROP CONSTRAINT [FK_ProductProfile_Probability]
GO

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1772
SET @ScriptDesc = 'Drop FK_UnavailableProducts_TicketCategory Constraint'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO