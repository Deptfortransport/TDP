-- ***********************************************
-- NAME 		: DUP1718_DropDownGaz_Properties_DataGateway.sql
-- DESCRIPTION 	: Script to add properties for DropDownGaz DataGateway properties
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Jun 2010
-- ************************************************

USE [PermanentPortal]
GO

-- ***************** WARNING ******************
-- Please check AID and GID values for DataGateway
--
-- Please ensure file path locations are correct: 
--			@XSDPath for property datagateway.sqlimport.dropdownalias.schemea
--
-- *********************************************


DECLARE @AID varchar(50), @GID varchar(50)
DECLARE @PropertyName varchar(100)
DECLARE @XSDPath varchar (100)

SET @AID = ''
SET @GID = 'DataGateway'

-- Update path if required
SET @XSDPath = 'C:\Gateway\xml\DropDownAlias.xsd'


SET @PropertyName = 'datagateway.sqlimport.dropdownalias.database'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, 'AtosAdditionalDataDB', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'AtosAdditionalDataDB'
	where pName = @PropertyName and AID = @AID and GID = @GID
END



SET @PropertyName = 'datagateway.sqlimport.dropdownalias.feedname'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, 'avf956', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'avf956'
	where pName = @PropertyName and AID = @AID and GID = @GID
END



SET @PropertyName = 'datagateway.sqlimport.dropdownalias.Name'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, 'dropdownalias', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'dropdownalias'
	where pName = @PropertyName and AID = @AID and GID = @GID
END



SET @PropertyName = 'datagateway.sqlimport.dropdownalias.schemea'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, @XSDPath, @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = @XSDPath
	where pName = @PropertyName and AID = @AID and GID = @GID
END



SET @PropertyName = 'datagateway.sqlimport.dropdownalias.sqlcommandtimeout'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, '120', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '120'
	where pName = @PropertyName and AID = @AID and GID = @GID
END




SET @PropertyName = 'datagateway.sqlimport.dropdownalias.storedprocedure'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, 'ImportDropDownAliasData', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'ImportDropDownAliasData'
	where pName = @PropertyName and AID = @AID and GID = @GID
END



SET @PropertyName = 'datagateway.sqlimport.dropdownalias.xmlnamespace'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, 'http://www.transportdirect.info/DropDownAlias', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://www.transportdirect.info/DropDownAlias'
	where pName = @PropertyName and AID = @AID and GID = @GID
END



SET @PropertyName = 'datagateway.sqlimport.dropdownalias.xmlnamespacexsi'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, 'http://www.w3.org/2001/XMLSchema-instance', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://www.w3.org/2001/XMLSchema-instance'
	where pName = @PropertyName and AID = @AID and GID = @GID
END




SET @PropertyName = 'datagateway.sqlimport.dropdownalias.xmlschemalocation'
IF not exists (select top 1 * from properties where pName = @PropertyName and AID = @AID and GID = @GID)
BEGIN
	insert into properties values (@PropertyName, 'http://www.transportdirect.info/DropDownAlias.xsd', @AID, @GID, 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://www.transportdirect.info/DropDownAlias.xsd'
	where pName = @PropertyName and AID = @AID and GID = @GID
END



GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1718
SET @ScriptDesc = 'Script to add properties for DropDownGaz DataGateway'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO