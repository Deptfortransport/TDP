-- ***********************************************
-- NAME           : DUP1959_AccessibleOperator_Tables.sql
-- DESCRIPTION    : Script to create accessible operator tables
-- AUTHOR         : Mitesh Modi
-- DATE           : 03 Dec 2012
-- ***********************************************

USE [TransientPortal]
GO

-- **************************************
-- [AccessibleOperators]

-- Drop existing table (OK to drop, this is first time table is being created in TDP)
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AccessibleOperators]') AND type in (N'U'))
	DROP TABLE [dbo].[AccessibleOperators]
GO

---- Create table
IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[AccessibleOperators]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[AccessibleOperators](
		[OperatorCode] [varchar](10) NOT NULL,
		[ServiceNumber] [varchar](10) NOT NULL,
		[Mode] [varchar](20) NOT NULL,
		[Region] [varchar](30) NOT NULL,
		[WEFDate] [date] NOT NULL,
		[WEUDate] [date] NOT NULL,
		[WheelchairBooking] [bit] NOT NULL,
		[AssistanceBooking] [bit] NOT NULL,
		[BookingUrl] [varchar](250) NULL,
		[BookingNumber] [varchar](50) NULL
	) ON [PRIMARY]
END
GO

-- Add primary key
ALTER TABLE [dbo].[AccessibleOperators]
    ADD CONSTRAINT [PK_AccessibleOperators]
    PRIMARY KEY CLUSTERED 
    (
		[OperatorCode] ASC,
		[ServiceNumber],
		[Mode],
		[Region],
		[WEFDate],
		[WEUDate]
	)WITH (ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF);

-- **************************************
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1959
SET @ScriptDesc = 'Script to create accessible operator tables'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO