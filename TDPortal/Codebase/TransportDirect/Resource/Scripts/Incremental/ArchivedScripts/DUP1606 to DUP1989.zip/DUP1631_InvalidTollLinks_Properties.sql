-- ***********************************************
-- NAME          : DUP1631_InvalidTollLinks_Properties.sql
-- DESCRIPTION   : Script to define the text for missing 
--		   Toll URLs (these are then ignored by the UI)
-- AUTHOR        : Mark Turner
-- DATE          : 25 March 2010
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'JourneyDetailsNullTollLink.Value' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('JourneyDetailsNullTollLink.Value', 'No URL has been set for this operator', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'No URL has been set for this operator'
	where pname = 'JourneyDetailsNullTollLink.Value' and ThemeId = 1
END

GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1630
SET @ScriptDesc = 'Set CyclePlanner PlanSameAreaOnly to true'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO