-- ***********************************************
-- NAME 		: DUP1653_Fares_TTBORegion_Property.sql
-- DESCRIPTION 	: Script to the TTBO region value used in fares pricing units
-- AUTHOR		: Mitesh Modi
-- DATE			: 08 Apr 2010
-- ************************************************

USE [PermanentPortal]
GO

-- Added for Web and TDRemotinghost
IF not exists (select top 1 * from properties where pName = 'PricingRetail.Domain.PricingUnitMergePolicy.TTBORegion' and AID = 'Web')
BEGIN
	insert into properties values (
		'PricingRetail.Domain.PricingUnitMergePolicy.TTBORegion', 
		'TT', 
		'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TT'
	where pname = 'PricingRetail.Domain.PricingUnitMergePolicy.TTBORegion' and AID = 'Web'
END


IF not exists (select top 1 * from properties where pName = 'PricingRetail.Domain.PricingUnitMergePolicy.TTBORegion' and AID = 'TDRemotingHost')
BEGIN
	insert into properties values (
		'PricingRetail.Domain.PricingUnitMergePolicy.TTBORegion', 
		'TT', 
		'TDRemotingHost ', 'TDRemotingHost ', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TT'
	where pname = 'PricingRetail.Domain.PricingUnitMergePolicy.TTBORegion' and AID = 'TDRemotingHost'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1653
SET @ScriptDesc = 'Script to add TTBO region value used in fares'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO