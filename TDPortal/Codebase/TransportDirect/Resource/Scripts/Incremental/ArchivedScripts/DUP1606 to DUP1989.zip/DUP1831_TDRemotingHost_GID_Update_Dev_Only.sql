-- ***********************************************
-- NAME 		: DUP1831_TDRemotingHost_GID_Update_Dev_Only.sql
-- DESCRIPTION 	: Script to update GID where AID is TDRemotingHost
-- AUTHOR		: Amit Patel
-- DATE			: 12 Sep 2011
-- ************************************************

-- ********* WARNING ****** WARNING ********** WARNING ***************

-- Please do not run this script on SITEST/BBP/ACP
-- This script is not meant to run on environments other than DEV

-- ********* WARNING ****** WARNING ********** WARNING ***************

USE [PermanentPortal]
GO

	DECLARE @tempProperties Table (
			[rowId] [int],
			[pName] [varchar](255) NOT NULL,
			[pValue] [varchar](2000) NOT NULL,
			[AID] [varchar](50) NOT NULL,
			[GID] [varchar](50) NOT NULL,
			[PartnerId] [int] NOT NULL,
			[ThemeId] [int] NOT NULL
		)
	
	INSERT INTO @tempProperties
		SELECT ROW_NUMBER() OVER(ORDER BY pName DESC), 
			pName, pValue, AID, GID, PartnerId, ThemeId 
		FROM properties 
		WHERE AID = 'TDRemotingHost' AND GID = 'UserPortal'

	-- Get the number of rows in the looping table
	DECLARE @RowCount INT
	SET @RowCount = (SELECT COUNT(rowId) FROM @tempProperties)

	-- Declare an iterator
	DECLARE @I INT
	-- Initialize the iterator
	SET @I = 1

	-- Loop through the rows of a table @myTable
	WHILE (@I <= @RowCount)
	BEGIN
			-- Declare variables to hold the data which we get after looping each record
			DECLARE @pName VARCHAR(255), @aid VARCHAR(50), @pId int, @tId int   
	       
			-- Get the data from table and set to variables
			SELECT  @pName = pName, @aid = AID, @pId = PartnerId, @tId = ThemeId FROM @tempProperties WHERE rowId = @I
	        
			IF NOT EXISTS(SELECT * FROM properties WHERE pName = @pName AND PartnerId = @pId AND ThemeId = @tId AND AID = @aid
														AND GID = 'TDRemotingHost')
			BEGIN
				UPDATE properties SET GID = 'TDRemotingHost'
						WHERE pName = @pName AND PartnerId = @pId AND ThemeId = @tId AND AID = @aid
			END
	        
			-- Increment the iterator
			SET @I = @I  + 1
	END

GO

-----------------------------------------------------------------
-- Properties
-----------------------------------------------------------------

------------------------------
-- Additional Data DB
------------------------------
IF exists (select top 1 * from properties where pName = 'AdditionalDataDB' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'AdditionalDataDB' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('AdditionalDataDB', 'data source=SID01; initial catalog=AdditionalData; user id=steve; password=password; persist security info=False', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END

------------------------------
-- Default Publisher
------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Publisher.Default' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Publisher.Default' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Publisher.Default', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


------------------------------
-- GATE event
------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GATE.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GATE.Assembly' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GATE.Assembly', 'td.reportdataprovider.tdpcustomevents', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GATE.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GATE.Name' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GATE.Name', 'DataGatewayEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GATE.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GATE.Publishers' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GATE.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GATE.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GATE.Trace' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GATE.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END

-------------------------------
-- JOURNEYREQUEST event
-------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Assembly' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Assembly', 'td.userportal.journeycontrol', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Name' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Name', 'JourneyPlanRequestEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Publishers' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Trace' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END

-------------------------------
-- JOURNEYREQUESTVERBOSE event
-------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Assembly' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Assembly', 'td.userportal.journeycontrol', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Name' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Name', 'JourneyPlanRequestVerboseEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Trace' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END

-------------------------------
-- JOURNEYRESULTS event
-------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Assembly' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Assembly', 'td.userportal.journeycontrol', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Name' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Name', 'JourneyPlanResultsEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Publishers' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Trace' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END

-------------------------------
-- JOURNEYRESULTSVERBOSE event
-------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Assembly' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Assembly', 'td.userportal.journeycontrol', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Name' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Name', 'JourneyPlanResultsVerboseEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Trace' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END

-------------------------------
-- EnhancedExposedServiceFinishEvent event
-------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Assembly' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Assembly', 'td.reportdataprovider.tdpcustomevents', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Name' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Name', 'EnhancedExposedServiceFinishEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Publishers' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Trace' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EnhancedExposedServiceFinishEvent.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END

-------------------------------
-- GAZ event
-------------------------------
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GAZ.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Assembly' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GAZ.Assembly', 'td.reportdataprovider.tdpcustomevents', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GAZ.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Name' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GAZ.Name', 'GazetteerEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GAZ.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Publishers' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GAZ.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GAZ.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GAZ.Trace' and ThemeId = 1 and AID = 'TDRemotingHost' AND GID= 'TDRemotingHost'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GAZ.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1831
SET @ScriptDesc = 'Script to update GID where AID is TDRemotingHost'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO