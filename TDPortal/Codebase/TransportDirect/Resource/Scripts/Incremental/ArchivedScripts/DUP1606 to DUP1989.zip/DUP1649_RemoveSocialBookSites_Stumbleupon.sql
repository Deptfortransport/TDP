-- ************************************************************
-- NAME         : DUP1649_RemoveSocialBookSites_Stumbleupon.sql
-- DESCRIPTION  : Remove Stumbleupon social book mark
-- AUTHOR		: Richard Hopkins
-- DATE			: 07 April 2010
-- ************************************************************

USE [TransientPortal]
GO

IF EXISTS (SELECT * FROM [dbo].[SocialBookMarks] WHERE SBMId = 4 AND SBMLandingPartnerCode = 'Supon')
	DELETE FROM [dbo].[SocialBookMarks] WHERE SBMId = 4 AND SBMLandingPartnerCode = 'Supon'

GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1649
SET @ScriptDesc = 'Remove Stumbleupon social book mark'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
