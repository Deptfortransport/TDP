-- *************************************************************************************
-- NAME 		: DUP1768_Update_UpdateTL_Homepage_Messages.sql
-- DESCRIPTION  	: Enhancements to traveline monitoring in line with fact that
--			  MDV are taking over the South West Traveline
-- AUTHOR		: Neil Rankin
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [PermanentPortal]
GO

-------------------------------------------------------------------------------------
-- Remove "SouthWest" from generic MRMD and add new "SouthWest" message
-------------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM [PermanentPortal].[dbo].[HomePageMessage] WHERE [Description] ='MRMD')
	BEGIN
	UPDATE [PermanentPortal].[dbo].[HomePageMessage]
	SET [valueEN]=
	'<tr><td class="VertAlignTop"><img class="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  West Midlands<br>  &bull;  Yorkshire<br>   &bull;  Wales<br>  &bull;  North West of England including Liverpool and Manchester<br> We are working to fix this problem, which will be resolved shortly.</font><br/></td></tr>'
	WHERE [Description]='MRMD'
	END
GO

UPDATE [PermanentPortal].[dbo].[HomePageMessage] SET [valueCY]=[valueEN] WHERE [Description] = 'MRMD'
GO

-------------------------------------------------------------------------------------
-- Add new "SouthWest" message
-------------------------------------------------------------------------------------

IF not exists (select * from [PermanentPortal].[dbo].[HomePageMessage] where SeqNo = 13 and Description = 'SouthWest')
BEGIN
	insert into [PermanentPortal].[dbo].[HomePageMessage] values ('13', 'SouthWest', '0', '0', Null, Null, '<tr><td class="VertAlignTop"><img class="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br> We are working to fix this problem, which will be resolved shortly.</font><br/></td></tr>', '<tr><td class="VertAlignTop"><img class="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br> We are working to fix this problem, which will be resolved shortly.</font><br/></td></tr>', '')
	END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1768
SET @ScriptDesc = 'Update_UpdateTL_Homepage_Messages'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO