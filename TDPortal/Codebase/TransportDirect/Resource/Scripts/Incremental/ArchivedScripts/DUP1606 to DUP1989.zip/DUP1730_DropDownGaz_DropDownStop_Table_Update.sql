-- ****************************************************************
-- NAME 		: DUP1730_DropDownGaz_DropDownStop_Table_Update.sql
-- DESCRIPTION 	: Script to update DropDownStop table for DropDownGaz
-- AUTHOR		: Amit Patel
-- DATE			: 25 May 2010
-- ****************************************************************


USE [AtosAdditionalData] 
GO


-----------------------------------------------
-- DropDownStop Table
-----------------------------------------------
-- Drop Existing DropDownStop Table

IF  EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.DropDownStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[DropDownStop]
END
GO

-- Create DropDownStop table

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.DropDownStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[DropDownStop](
		[DropDownType] [varchar](10) NOT NULL,	          -- Type of the drop down this data associates to
		[Name] [varchar](100) NOT NULL,					  -- Name for the stop which will be displayed in the textbox showing autosuggest		  
		[DisplayName] [varchar](100) NOT NULL default(''),-- Name which will apear in the dropdown
		[Naptans] [varchar](300) NOT NULL,				  -- Comma delimited NaPTAN values
		[ShortCode] [varchar] (100),					  -- Short code such as CRS
		[IsGroup] [bit] NOT NULL DEFAULT(0),			  -- If the stop representing a group of stops
		[IsAlias] [bit] NOT NULL DEFAULT(0)				  -- If the current row entry is an alias added for actual stop
	) ON [PRIMARY]

END
GO

ALTER TABLE [dbo].[DropDownStop] ADD 
	CONSTRAINT [PK_DropDownStop] PRIMARY KEY  CLUSTERED 
	(
		[DropDownType],
		[Name],
		[DisplayName],
		[Naptans]
	)  ON [PRIMARY] 
GO






----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1730
SET @ScriptDesc = 'Script to update DropDownStop table for DropDownGaz'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO