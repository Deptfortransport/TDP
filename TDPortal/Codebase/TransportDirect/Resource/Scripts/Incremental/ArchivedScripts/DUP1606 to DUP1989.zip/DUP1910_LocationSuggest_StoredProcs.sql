-- ***********************************************
-- NAME           : DUP1910_LocationSuggest_StoredProcs.sql
-- DESCRIPTION    : Script to add location autosuggest stored procedures
-- AUTHOR         : Mitesh Modi
-- DATE           : 07 Aug 2012
-- ***********************************************

-- ************************************************************************************************
-- THIS SCRIPT MUST BE AMENDED TO ASSIGN PERMISSIONS TO THE CORRECT USER
-- ************************************************************************************************

USE [AtosAdditionalData]
GO

-- Create function if needed
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GetGroupNaPTANs]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
	EXEC ('
		CREATE FUNCTION [dbo].[GetGroupNaPTANs]()
		RETURNS varchar(max)
		AS
		BEGIN
			DECLARE @NaPTANsInGroup varchar(max)
			return @NaPTANsInGroup
		END
	')
	
END
GO

-- Update function
ALTER FUNCTION [dbo].[GetGroupNaPTANs]
(
	@DATASETID nvarchar(50)
)
RETURNS varchar(max)
AS
BEGIN
	-- GetGroupNaPTANs function used by get locations for a group location
	
	-- Get the naptans for all the stations in the group
	DECLARE @NaPTANsInGroup varchar(max)

	SELECT    @NaPTANsInGroup = coalesce(@NaPTANsInGroup + ',', '') + StationInGroup.Naptan
	FROM [GAZ].[gazadmin].[TDLocations] GroupStation
	INNER JOIN [GAZ].[gazadmin].[TDLocations] StationInGroup
	on GroupStation.DATASETID = StationInGroup.ParentID
	WHERE GroupStation.DATASETID = @DATASETID

	return @NaPTANsInGroup
END
GO

-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLocations]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetLocations 	
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[GetLocations]
AS
BEGIN
	-- GetLocations strored proc to return all locations for building the auto-suggest javascript dataset

	SELECT
	   [DATASETID]
      ,[ParentID]
      ,[Name]
      ,[DisplayName]
      ,[Type]
      ,Case When [Type] <> 'EXCHANGE GROUP' THEN [Naptan] ELSE dbo.GetGroupNaPTANs([DATASETID]) END [Naptan]
      ,[LocalityID]
      ,[Easting]
      ,[Northing]
      ,[NearestTOID]
      ,[NearestPointE]
      ,[NearestPointN]
	  ,[AdminAreaID]
      ,[DistrictID]
	FROM [GAZ].[gazadmin].[TDLocations]
	WHERE [Type] NOT LIKE 'VENUEPOI'

END
GO

-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLocation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetLocation	
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[GetLocation]
(
	@id varchar(50)
)	
AS
BEGIN
	-- GetLocation stored proc to return a location for an id to resolve an alias location 
	-- being added to the auto-suggest javascript dataset,
	-- or to return details for a location when resolving from a selected auto-suggest 

	SELECT TOP(1)
	   [DATASETID]
      ,[ParentID]
      ,[Name]
      ,[DisplayName]
      ,[Type]
      ,Case When [Type] <> 'EXCHANGE GROUP' THEN [Naptan] ELSE dbo.GetGroupNaPTANs([DATASETID]) END [Naptan]
      ,[LocalityID]
      ,[Easting]
      ,[Northing]
      ,[NearestTOID]
      ,[NearestPointE]
      ,[NearestPointN]
	  ,[AdminAreaID]
      ,[DistrictID]
	FROM [GAZ].[gazadmin].[TDLocations]
	WHERE [Naptan] = @id 
	   OR [DATASETID] = @id 
	   OR [LocalityID] = @id
	   AND [Type] NOT LIKE 'VENUEPOI'
END
GO


-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetUnknownLocation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetUnknownLocation	
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[GetUnknownLocation]
	@searchstring varchar(100)
AS
BEGIN
	
		SELECT TOP(1) 
			 [DATASETID]
			,[ParentID]
			,[Name]
			,[DisplayName]
			,[Type]
			,Case When [Type] <> 'EXCHANGE GROUP' THEN [Naptan] ELSE dbo.GetGroupNaPTANs([DATASETID]) END [Naptan]
			,[LocalityID]
			,[Easting]
			,[Northing]
			,[NearestTOID]
			,[NearestPointE]
			,[NearestPointN]
			,[AdminAreaID]
			,[DistrictID]
		FROM [GAZ].[gazadmin].[TDLocations]
		WHERE DisplayName = @searchstring
		AND [Type] NOT LIKE 'VENUEPOI'
END
GO


-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAlternativeSuggestionList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetAlternativeSuggestionList
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[GetAlternativeSuggestionList]
(
	@searchstring varchar(100),
	@maxRecords int
)	
AS
BEGIN
	DECLARE @LikesFound int
	SELECT @LikesFound = COUNT(*) FROM [GAZ].[gazadmin].[TDLocations]
	WHERE [DisplayName] LIKE '%' + @searchstring + '%'
	
	If (@LikesFound < @maxRecords)
	BEGIN
		SELECT TOP(@maxRecords) 
				[DATASETID],[ParentID],[Name],[DisplayName],[Type],[Naptan],[LocalityID],[Easting],[Northing],[NearestTOID],[NearestPointE],[NearestPointN],[AdminAreaID],[DistrictID]
		FROM [GAZ].[gazadmin].[TDLocations]
		WHERE [DisplayName] LIKE '%' + @searchstring + '%' 
		UNION	
		SELECT TOP(@maxRecords - @LikesFound) 
				[DATASETID],[ParentID],[Name],[DisplayName],[Type],[Naptan],[LocalityID],[Easting],[Northing],[NearestTOID],[NearestPointE],[NearestPointN],[AdminAreaID],[DistrictID]
		FROM [GAZ].[gazadmin].[TDLocations]
		WHERE SOUNDEX (@searchstring) = SOUNDEX ([DisplayName])
	END
	ELSE
	BEGIN
		SELECT TOP(@maxRecords) 
				[DATASETID],[ParentID],[Name],[DisplayName],[Type],[Naptan],[LocalityID],[Easting],[Northing],[NearestTOID],[NearestPointE],[NearestPointN],[AdminAreaID],[DistrictID]
		FROM [GAZ].[gazadmin].[TDLocations]
		WHERE [DisplayName] LIKE '%' + @searchstring + '%' 
	END
END
GO


-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetLocationsVersion]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetLocationsVersion
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[GetLocationsVersion]
AS
BEGIN
	
	SELECT [Version] 
	  FROM [dbo].[ChangeNotification]
	 WHERE [Table] = 'LocationCache'
	  
END
GO

-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[UpdateLocationsVersion]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE UpdateLocationsVersion
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[UpdateLocationsVersion]
	@NotificationTable varchar(50),
	@Version int
AS
BEGIN
	
	IF EXISTS (SELECT * FROM ChangeNotification WHERE [Table] = @NotificationTable)
	  BEGIN
		
		UPDATE [AtosAdditionalData].[dbo].[ChangeNotification] 
		SET    [Version] = @Version
		WHERE  [Table] IN (@NotificationTable)
		
	  END
	ELSE
	  BEGIN
		
		RAISERROR(
		'UpdateChangeNotification - Unrecognised change notification table', 
		16, -- Severity
		1)   -- State
	  
	  END	
	  
END
GO
	
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1910
SET @ScriptDesc = 'Script to add location autosuggest stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO