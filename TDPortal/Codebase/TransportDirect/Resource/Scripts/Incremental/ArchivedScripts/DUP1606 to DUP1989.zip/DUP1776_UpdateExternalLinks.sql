-- ***********************************************
-- NAME 	 : DUP1776_UpdateExternalLinks.sql
-- DESCRIPTION 	 : Script to update external links
-- DATE		 : 22 Dec 2010
-- AUTHOR        : Phil Scott
-- ************************************************

use TransientPortal

GO

update [ExternalLinks]
set URL = 'http://www.lancashire.gov.uk/corporate/web/view.asp?siteid=4404&pageid=19915&e=e'
where Id like 'DepartureBoard.Bus.1'

update [ExternalLinks]
set TestURL = 'http://www.lancashire.gov.uk/corporate/web/view.asp?siteid=4404&pageid=19915&e=e'
where Id like 'DepartureBoard.Bus.1'


update [ExternalLinks]
set LinkText = 'http://www.lancashire.gov.uk/corporate/web/view.asp?siteid=4404&pageid=19915&e=e'
where Id like 'DepartureBoard.Bus.1'



update [ExternalLinks]
set URL = 'http://www.acis.uk.com/ACIS-Live.aspx'
where Id like 'DepartureBoard.Bus.2'

update [ExternalLinks]
set TestURL = 'http://www.acis.uk.com/ACIS-Live.aspx'
where Id like 'DepartureBoard.Bus.2'

update [ExternalLinks]
set LinkText = 'http://www.acis.uk.com/ACIS-Live.aspx'
where Id like 'DepartureBoard.Bus.2'


update [ExternalLinks]
set URL = 'http://www.atoc.org/clientfiles/File/publicationsdocuments/npsB3A7_tmp.pdf'
where Id like 'JourneyEmissions.Co2Railway'

update [ExternalLinks]
set TestURL = 'http://www.atoc.org/clientfiles/File/publicationsdocuments/npsB3A7_tmp.pdf'
where Id like 'JourneyEmissions.Co2Railway'

update [ExternalLinks]
set LinkText = 'http://www.atoc.org/clientfiles/File/publicationsdocuments/npsB3A7_tmp.pdf'
where Id like 'JourneyEmissions.Co2Railway'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1776
SET @ScriptDesc = 'Script to Update External Links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO