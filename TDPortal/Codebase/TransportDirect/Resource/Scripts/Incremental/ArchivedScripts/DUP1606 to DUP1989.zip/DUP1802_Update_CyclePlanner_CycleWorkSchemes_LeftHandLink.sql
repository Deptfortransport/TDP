-- ***********************************************
-- NAME           : DUP1802_Update_CyclePlanner_CycleWorkSchemes_LeftHandLink.sql
-- DESCRIPTION    : Script to update 'Find out about Cycle to Work Schemes' left hand link on about us page
-- AUTHOR         : Amit Patel
-- DATE           : 17 May 2011
-- ***********************************************

USE [TransientPortal] 

EXECUTE UpdateSuggestionLinkURL 
		   'http://www.cyclescheme.co.uk/'
		  ,'http://www.direct.gov.uk/en/Nl1/Newsroom/DG_181913'
		  ,'Cycle planner - Cycle schemes url'
		  ,0
		  
EXECUTE UpdateSuggestionLinkURL 
		   'http://dft.gov.uk/cyclingengland/'
		  ,'http://www.dft.gov.uk/pgr/sustainable/cycling/'
		  ,'Cycle planner - Cycle schemes url'
		  ,0

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1802
SET @ScriptDesc = 'Script to update ''Find out about Cycle to Work Schemes'' left hand link on about us page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO