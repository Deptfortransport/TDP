-- ***********************************************
-- NAME 		: DUP1635_Partners_Update.sql
-- DESCRIPTION 	: Script to add partners- BusinessLink, BusinessGateway, AOCycle
-- AUTHOR		: Amit Patel
-- DATE			: 29 Mar 2010
-- ************************************************

-- ************************************************
-- NOTE: AOCycle partner setup purely for test purpose
-- ************************************************



-----------------------------------------------------------------------
-- Theme 
-----------------------------------------------------------------------

USE [PermanentPortal] 
GO



-- Add the Partner - BusinessLink

IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId = 6 and PartnerName = 'BusinessLink'
)
BEGIN
	INSERT INTO Partner VALUES (6,'BusinessLink','BusinessLink','BusinessLink',NULL)
END

-- Add the Partner - BusinessGateway

IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId = 7 and PartnerName = 'BusinessGateway'
)
BEGIN
	INSERT INTO Partner VALUES (7,'BusinessGateway','BusinessGateway','BusinessGateway',NULL)
END

-- Add the Partner - AOCycle

IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId = 200 and PartnerName = 'AOCycle'
)
BEGIN
	INSERT INTO Partner VALUES (200,'AOCycle','AOCycle','AOCycle',NULL)
END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1635
SET @ScriptDesc = 'Script to add partners- BusinessLink, BusinessGateway, AOCycle'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO