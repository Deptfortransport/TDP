-- ***********************************************
-- NAME 		: DUP1638_AOCycle_Cycle_2_Properties_.sql
-- DESCRIPTION 	: Script to add cycle planner white label properties
-- AUTHOR		: Amit Patel
-- DATE			: 24 Mar 2010
-- ************************************************

-- ************************************************
-- NOTE: AOCycle partner setup purely for test purpose
-- ************************************************

USE [PermanentPortal]
GO

DECLARE @ThemeId int


SET @ThemeId = 200 -- Cycle planner and CO2 white labelling partners with be 200-299


---------------------------------------------------------------
-- property to hide/ show cycle planner pages header tab 
---------------------------------------------------------------

-- FindCycleInput page
IF not exists (select top 1 * from properties where pName = 'FindCycleInput.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FindCycleInput.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'FindCycleInput.HeaderTab.Visible' and ThemeId = @ThemeId
END

-- CycleJourneyDetails page
IF not exists (select top 1 * from properties where pName = 'CycleJourneyDetails.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'CycleJourneyDetails.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CycleJourneyDetails.HeaderTab.Visible' and ThemeId = @ThemeId
END



---------------------------------------------------------------
-- property to hide/ show header tab on Journey Summary page
---------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'CycleJourneySummary.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'CycleJourneySummary.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CycleJourneySummary.HeaderTab.Visible' and ThemeId = @ThemeId
END


---------------------------------------------------------------
-- property to hide/ show header tab on Journey Map page
---------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'CycleJourneyMap.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'CycleJourneyMap.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CycleJourneyMap.HeaderTab.Visible' and ThemeId = @ThemeId
END


---------------------------------------------------------------
-- property to hide/ show Co2 pages header tab 
---------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'JourneyEmissionsCompareJourney.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'JourneyEmissionsCompareJourney.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'JourneyEmissionsCompareJourney.HeaderTab.Visible' and ThemeId = @ThemeId
END



---------------------------------------------------------------
-- property to hide/ show transport direct powered by logo
---------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'PoweredByControl.ShowPoweredBy' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'PoweredByControl.ShowPoweredBy', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PoweredByControl.ShowPoweredBy' and ThemeId = @ThemeId
END

---------------------------------------------------------------
-- properties to hide/ show footer navigation links
---------------------------------------------------------------

-- Help link
IF not exists (select top 1 * from properties where pName = 'FooterControl.HelpLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.HelpLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.HelpLink.Visible' and ThemeId = @ThemeId
END

-- About link
IF not exists (select top 1 * from properties where pName = 'FooterControl.AboutLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.AboutLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.AboutLink.Visible' and ThemeId = @ThemeId
END

-- Contact Us link
IF not exists (select top 1 * from properties where pName = 'FooterControl.ContactUsLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.ContactUsLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.ContactUsLink.Visible' and ThemeId = @ThemeId
END

-- Site Map link
IF not exists (select top 1 * from properties where pName = 'FooterControl.SiteMapLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.SiteMapLink.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'FooterControl.SiteMapLink.Visible' and ThemeId = @ThemeId
END

-- Language Switch link
IF not exists (select top 1 * from properties where pName = 'FooterControl.LanguageSwitchLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.LanguageSwitchLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.LanguageSwitchLink.Visible' and ThemeId = @ThemeId
END

-- Related Sites link
IF not exists (select top 1 * from properties where pName = 'FooterControl.RelatedSitesLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.RelatedSitesLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.RelatedSitesLink.Visible' and ThemeId = @ThemeId
END

-- TermsConditions link
IF not exists (select top 1 * from properties where pName = 'FooterControl.TermsConditionsLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.TermsConditionsLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.TermsConditionsLink.Visible' and ThemeId = @ThemeId
END

-- Privacy Policy link
IF not exists (select top 1 * from properties where pName = 'FooterControl.PrivacyPolicyLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.PrivacyPolicyLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.PrivacyPolicyLink.Visible' and ThemeId = @ThemeId
END

-- Data Providers link
IF not exists (select top 1 * from properties where pName = 'FooterControl.DataProvidersLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.DataProvidersLink.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'FooterControl.DataProvidersLink.Visible' and ThemeId = @ThemeId
END

-- Accessibility link
IF not exists (select top 1 * from properties where pName = 'FooterControl.AccessibilityLink.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FooterControl.AccessibilityLink.Visible', 
		'true', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'FooterControl.AccessibilityLink.Visible' and ThemeId = @ThemeId
END

------------------------------------------------------------------------------------------
-- AmendSaveSend control 'Send to friend' and 'Save as a favourite journey' tabs visibility 
-------------------------------------------------------------------------------------------

-- 'Send to friend' tab visibility
IF not exists (select top 1 * from properties where pName = 'AmendSaveSendControl.SendEmail.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'AmendSaveSendControl.SendEmail.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'AmendSaveSendControl.SendEmail.Visible' and ThemeId = @ThemeId
END

-- 'Save as a favourite journey' tab visibility
IF not exists (select top 1 * from properties where pName = 'AmendSaveSendControl.SaveFavourite.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'AmendSaveSendControl.SaveFavourite.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'AmendSaveSendControl.SaveFavourite.Visible' and ThemeId = @ThemeId
END

------------------------------------------------------------------------------------------
-- Header control logo enabled/disabled. 
-------------------------------------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'HeaderControl.headerHomepageLink.Enabled' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'HeaderControl.headerHomepageLink.Enabled', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'HeaderControl.headerHomepageLink.Enabled' and ThemeId = @ThemeId
END

------------------------------------------------------------------------------------------
-- Wait page tip of the day message 
-------------------------------------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'WaitPage.tipOfDay.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'WaitPage.tipOfDay.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'WaitPage.tipOfDay.Visible' and ThemeId = @ThemeId
END

------------------------------------------------------------------------------------------
-- Wait page header tabs 
-------------------------------------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'WaitPage.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'WaitPage.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'WaitPage.HeaderTab.Visible' and ThemeId = @ThemeId
END


------------------------------------------------------------------------------------------
-- static pages header tabs
-------------------------------------------------------------------------------------------

IF not exists (select top 1 * from properties where pName = 'Links.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'Links.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'Links.HeaderTab.Visible' and ThemeId = @ThemeId
END

IF not exists (select top 1 * from properties where pName = 'Help.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'Help.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'Help.HeaderTab.Visible' and ThemeId = @ThemeId
END

IF not exists (select top 1 * from properties where pName = 'HelpFullJP.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'HelpFullJP.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'HelpFullJP.HeaderTab.Visible' and ThemeId = @ThemeId
END




------------------------------------------------------------------------------------------
-- Feedback page header tabs
-------------------------------------------------------------------------------------------

-- static default page
IF not exists (select top 1 * from properties where pName = 'FeedbackPage.HeaderTab.Visible' and ThemeId = @ThemeId)
BEGIN
	insert into properties values (
		'FeedbackPage.HeaderTab.Visible', 
		'false', 
		'Web', 
		'UserPortal', 0, @ThemeId)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'FeedbackPage.HeaderTab.Visible' and ThemeId = @ThemeId
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1638
SET @ScriptDesc = 'Script to add cycle planner white label properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO