-- ***********************************************
-- NAME 		: DUP1841_RealTimeCar_ReportingStaging_DataAudit.sql
-- DESCRIPTION 	: Added report staging data audit entries for Real Time Road Events
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Oct 2011
-- ************************************************

USE [ReportStagingDB]
GO

-- Add new data types for reporting

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataType] 
WHERE [RSDTName] = 'TransferRealTimeRoadEvents') 
	INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataType] ([RSDTID],[RSDTName])
		 VALUES (35,'TransferRealTimeRoadEvents')
GO

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataAudit]
WHERE [RSDTID] = 35) 
	BEGIN
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (35,1,'20111001 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (35,2,'20111001 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (35,3,'20111001 01:00:00')
	END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1841
SET @ScriptDesc = 'Added report staging data audit entries for Real Time Road Events'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO