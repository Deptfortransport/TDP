-- ***********************************************
-- NAME          : DUP1926_LocationSuggest_Reporting_Update.sql
-- DESCRIPTION   : Script to update Reporting gazetteer types for LocationSuggest 
-- AUTHOR        : Mitesh Modi
-- DATE          : 12 Sep 2012
-- ************************************************

USE [Reporting]
GO

-- Remove existing autosuggest values
DELETE FROM [GazetteerType] WHERE [GTCode] LIKE 'GazetteerAutoSuggest%'

-- Get the next id
DECLARE @gtid tinyint = (SELECT MAX([GTID]) FROM [GazetteerType])

-- Insert new gazetteer types
SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestAirport')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestAirport','AutoSuggest Airport')
END

SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestCoach')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestCoach','AutoSuggest Coach')
END

SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestFerry')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestFerry','AutoSuggest Ferry')
END

SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestRail')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestRail','AutoSuggest Rail')
END

SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestTMU')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestTMU','AutoSuggest TMU')
END

SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestGroup')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestGroup','AutoSuggest Group')
END

SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestLocality')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestLocality','AutoSuggest Locality')
END

SET @gtid = (@gtid + 1)
IF NOT EXISTS (SELECT TOP 1 * FROM [GazetteerType] WHERE [GTCode] = 'GazetteerAutoSuggestOther')
BEGIN
	INSERT INTO [Reporting].[dbo].[GazetteerType] ([GTID],[GTCode],[GTDescription])
		 VALUES (@gtid,'GazetteerAutoSuggestOther','AutoSuggest Other')
END


-- Page entry event
IF NOT EXISTS (SELECT TOP 1 * FROM [PageEntryType] WHERE [PETCode] = 'LocationMoreOptionsClicked')
BEGIN
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'LocationMoreOptionsClicked', 'Location more options clicked' FROM PageEntryType
END

GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1926
SET @ScriptDesc = 'Script to update Reporting gazetteer types and page entry for LocationSuggest'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO