-- ***********************************************
-- NAME 		: DUP1684_CyclePlanner_Content_Update.sql
-- DESCRIPTION 	: Script to update cycle planner content as per Doc MT01508
-- AUTHOR		: Amit Patel
-- DATE			: 20 Apr 2010
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 69, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput'
,'<div class="Column3Header">    <div class="txtsevenbbl">Cycle Planning</div>    <div class="clearboth"></div>  </div>  <div class="Column3Content">    <table cellspacing="0" cellpadding="2" width="100%" border="0">      <tbody>        <tr>          <td class="txtseven">This is the First version of Transport          Direct&#8217;s new cycle planner. We have worked with          Cycling England, Ordnance Survey and the relevant local          authorities to ensure that there is good quality          information on cycling in the following areas:           <ul class="listerdisc">            <li>              <strong>Aylesbury</strong>            </li>       <li>              <strong>Blackpool</strong>            </li>       <li>              <strong>Greater Bristol</strong>            </li>       <li>              <strong>Cambridge</strong>            </li>       <li>              <strong>Colchester</strong>            </li>       <li>              <strong>Darlington</strong>            </li>       <li>              <strong>Derby</strong>            </li>       <li>              <strong>Exeter</strong>            </li>       <li>              <strong>Lancaster</strong>            </li>       <li>              <strong>Greater Leicester</strong>            </li>       <li>              <strong>Leighton Buzzard</strong>            </li>       <li>              <strong>Greater Manchester</strong>            </li>       <li>              <strong>Merseyside</strong>            </li>       <li>              <strong>Oxford</strong>            </li>       <li>              <strong>Peterborough</strong>            </li>       <li>              <strong>Shrewsbury</strong>            </li>       <li>              <strong>Stoke-on-Trent</strong>            </li>       <li>              <strong>Worcester</strong>            </li>           </ul>          <br />We would really appreciate your feedback on this          initial version of the planner. Please click on "Contact          us" at the bottom of the page to let us know what you think          or report any problems.           <br />          <br />We will consider all feedback and will be improving          the planner over the coming weeks. Work is also ongoing to          provide cycle planning information in more areas - please          check again soon if your local area is not yet available.           <br /></td>        </tr>      </tbody>    </table>  </div>'
,'<div class="Column3Header">    <div class="txtsevenbbl">Trefnu Taith Feicio</div>    <div class="clearboth"></div>  </div>  <div class="Column3Content">    <table cellspacing="0" cellpadding="2" width="100%" border="0">      <tbody>        <tr>          <td class="txtseven">Dyma''r Fersiwn gyntaf o drefnwr          teithiau beicio newydd Transport Direct. Rydym wedi          gweithio gyda Cycling England, Arolwg Ordnans a''r          awdurdodau lleol perthnasol i sicrhau bod gwybodaeth o          ansawdd ar gael am feicio yn yr ardaloedd canlynol:           <ul class="listerdisc">            <li>              <strong>Aylesbury</strong>            </li>       <li>              <strong>Blackpool</strong>            </li>       <li>              <strong>Greater Bristol</strong>            </li>       <li>              <strong>Cambridge</strong>            </li>       <li>              <strong>Colchester</strong>            </li>       <li>              <strong>Darlington</strong>            </li>       <li>              <strong>Derby</strong>            </li>       <li>              <strong>Exeter</strong>            </li>       <li>              <strong>Lancaster</strong>            </li>       <li>              <strong>Greater Leicester</strong>            </li>       <li>              <strong>Leighton Buzzard</strong>            </li>       <li>              <strong>Greater Manchester</strong>            </li>       <li>              <strong>Merseyside</strong>            </li>       <li>              <strong>Oxford</strong>            </li>       <li>              <strong>Peterborough</strong>            </li>       <li>              <strong>Shrewsbury</strong>            </li>       <li>              <strong>Stoke-on-Trent</strong>            </li>       <li>              <strong>Worcester</strong>            </li>           </ul>          <br />Byddem yn wirioneddol yn gwerthfawrogi eich adborth          am y fersiwn wreiddiol hon o''r trefnwr. Cliciwch ar          ''Cysylltwch &#212; ni'' ar waelod y dudalen i roi gwybod          inni beth yw eich barn neu adrodd am unrhyw broblemau.           <br />          <br />Byddwn yn ystyried pob adborth ac yn gwella''r          trefnwr dros yr wythnosau nesaf. Mae gwaith yn parhau hefyd          i roi gwybodaeth i drefnu teithiau beicio mewn mwy o          ardaloedd - dewch yn''l eto cyn bo hir os nad yw eich          ardal leol ar gael eto.           <br />          <br /></td>        </tr>      </tbody>    </table>  </div>'


EXEC AddtblContent
1, 69, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput'
,'<div class="PageSoftContentContainer">    <div class="PageSoftContent">      <p>Click the Advanced Options button above to amend some of the      following options for your journey. Options include:</p>      <ul>        <li>Amend the maximum speed at which you would like to        travel</li>        <li>Choose to avoid unlit roads or walking with your bike</li>        <li>Select a location you would like your journey to go        via</li>      </ul>      <br />    </div>  </div>'
,'<div class="PageSoftContentContainer">    <div class="PageSoftContent">      <p>Cliciwch y botwm Opsiynau Manwl uchod i newid rhai o''r      opsiynau canlynol ar gyfer eich siwrnai. Mae opsiynau''n      cynnwys:</p>      <ul>        <li>Newid y cyflymder mwyaf yr hoffech deithio</li>        <li>Dewis osgoi ffyrdd heb eu goleuo cerdded gyda''ch beic</li>        <li>Dewis lleoliad yr hoffech i''ch siwrnai fynd drwyddo</li>      </ul>      <br />    </div>  </div>'

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1684
SET @ScriptDesc = 'Script to update cycle planner content as per Doc MT01508'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO