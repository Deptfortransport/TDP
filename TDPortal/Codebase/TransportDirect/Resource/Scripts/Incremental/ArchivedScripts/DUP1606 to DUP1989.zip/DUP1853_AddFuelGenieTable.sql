-- ***********************************************
-- NAME           : DUP1853_AddFuelGenieTable.sql
-- DESCRIPTION    : Script to Add Fuel Genie Table to transient data db
-- AUTHOR         : Phil Scott
-- DATE           : 12/01/2012
-- ***********************************************

USE [TransientPortal]
GO

/****** Object:  Table [dbo].[FuelGenieSites]    Script Date: 01/12/2012 11:23:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FuelGenieSites]') AND type in (N'U'))
DROP TABLE [dbo].[FuelGenieSites]
GO

USE [TransientPortal]
GO

/****** Object:  Table [dbo].[FuelGenieSites]    Script Date: 01/12/2012 11:23:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[FuelGenieSites](
	[PostCode] [varchar](10) NOT NULL,
	[FuelGenieSite] [varchar](1) NOT NULL,
	[Easting] [int] NOT NULL,
	[Northing] [int] NOT NULL,
	[Brand] [varchar](50) NULL,
	[SiteReference1] [varchar](100) NULL,
	[SiteReference2] [varchar](100) NULL,
	[SiteReference3] [varchar](100) NULL,
	[SiteReference4] [varchar](100) NULL,
 CONSTRAINT [PK_FuelGenieSites] PRIMARY KEY CLUSTERED 
(
	[PostCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1853
SET @ScriptDesc = 'DUP1853_AddFuelGenieTable'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
GO