-- ************************************************************
-- NAME         : DUP1665_Update_Welsh_LeftHandLinks.sql
-- DESCRIPTION  : Update Welsh translations of left hand links
-- AUTHOR	: Mark Turner
-- DATE		: 19 April 2010
-- ************************************************************

USE TransientPortal
GO

EXEC dbo.AddResource 'FAQ.SocialBookmarking','What is Social Bookmarking?','Beth yw Llyfrnodi Cymdeithasol?'
EXEC dbo.AddResource 'RealTimeTraffic','Real time traffic','Traffic amser real'
EXEC dbo.AddResource 'CyclePlanner.GPXDownload','Find out about GPX downloads','Darganfod gwybodaeth am lawrlwythiadau GPX'
EXEC dbo.AddResource 'CyclePlanner.Parking','Find out about cycle parking','Darganfod gwybodaeth am barcio beiciau'
EXEC dbo.AddResource 'CyclePlanner.CyclingScotland','Find out about cycling in Scotland','Darganfod gwybodaeth am feicio yn yr Alban'
EXEC dbo.AddResource 'CyclePlanner.CyclingEngland','Find out about cycling in England','Darganfod gwybodaeth am feicio yn Lloegr'
EXEC dbo.AddResource 'CyclePlanner.CyclingWales','Find out about cycling in Wales','Darganfod gwybodaeth am feicio yng Nghymru'
EXEC dbo.AddResource 'CyclePlanner.NationalCycleRoutes','Find out about National cycle routes','Darganfod gwybodaeth am Lwybrau Beicio Cenedlaethol'
EXEC dbo.AddResource 'CyclePlanner.CycleScheme','Find out about Bike to work schemes','Darganfod gwybodaeth am Gynlluniau Beicio i''r Gwaith'
EXEC dbo.AddResource 'CyclePlanner.CycleSafety','Find out about cycle safety','Darganfod gwybodaeth am ddiogelwch beicio'
EXEC dbo.AddResource 'CyclePlanner.CycleSchool','Find out about cycling to school','Darganfod gwybodaeth am feicio i''r ysgol'
EXEC dbo.AddResource 'FAQ.TouristInfo','Tourist Information','Gwybodaeth i Dwristiaid'
EXEC dbo.AddResource 'RelatedSites.TouristInfo','Tourist Information','Gwybodaeth i Dwristiaid'
EXEC dbo.AddResource 'FindNearestCarParkDriveTo','Drive to a car park','Gyrru i faes parcio'
GO


-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1665
SET @ScriptDesc = 'Update Welsh translations of left hand links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
