-- ***********************************************
-- NAME           : DUP1936_UPdatePromLinksSchedule2012
-- DESCRIPTION    : Script to modify sheduled Promo links in overrides table
-- DATE           : 01/11/2012
-- Author         : P Scott
-- ***********************************************



USE [Content]
GO








EXEC AddContentOverride 
'home', 1, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<div class="txtsevenbbl">Booking Christmas rail travel?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" alt="" title="" />
				</td> 
				<td class="txtseven">
					Is the price of your train ticket more important than your date of travel?  Search by price, rather than by date/time, with our  
					<a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx?cacheparam=0">Find cheaper rail fares</a>
					planner.
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Free webmaster tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" width="26">
					<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" />
				</td> 
				<td class="txtseven">
					Our pdf helpsheets give simple instructions on how to add Transport Direct features to your website.  Download the full set or try 
					<a target="_child" href="/Web2/Downloads/1a - link to Transport Direct with pre-set destination using postcode.pdf">
						Helpsheet 1a 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>.  
					<br/>
					<br/>
					<a target="_child" href="/Web2/Downloads/Transport_Direct_Helpsheets.zip">
						Transport Direct helpsheets (zip file) 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>
'
, 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<div class="txtsevenbbl">Booking Christmas rail travel?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" alt="" title="" />
				</td> 
				<td class="txtseven">
					Is the price of your train ticket more important than your date of travel?  Search by price, rather than by date/time, with our  
					<a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx?cacheparam=0">Find cheaper rail fares</a>
					planner.
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Free webmaster tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" width="26">
					<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" />
				</td> 
				<td class="txtseven">
					Our pdf helpsheets give simple instructions on how to add Transport Direct features to your website.  Download the full set or try 
					<a target="_child" href="/Web2/Downloads/1a - link to Transport Direct with pre-set destination using postcode.pdf">
						Helpsheet 1a 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>.  
					<br/>
					<br/>
					<a target="_child" href="/Web2/Downloads/Transport_Direct_Helpsheets.zip">
						Transport Direct helpsheets (zip file) 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>
'
,'2012-11-01','2012-11-30'



EXEC AddContentOverride 
'journeyplanning_findcarinput', 1, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarInput', 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
'
, 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
'
,'2012-11-01','2012-12-31'


EXEC AddContentOverride 
'journeyplanning_findcarinput', 5, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarInput', ' ',' '
,'2012-11-01','2012-12-31'



EXEC AddContentOverride 
'journeyplanning_home', 5, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/home', 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
'
, 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
'
,'2012-11-01','2012-12-31'


EXEC AddContentOverride 
'home', 1, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
<tr>
<div class="txtsevenbbl">Christmas shopping? / </div>  
<tr>
<div class="txtsevenbbl">Going to the sales?</div>  
</table>
</div>

<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/parking.gif" alt="Park and ride" title="Park and ride" />
				</td> 
				<td class="txtseven">
         		Get directions to a Park & Ride site near you. <br\>
					<a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park & ride</a>
					<br\>
                Alternatively, 
                <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
                 has details of nearby car parks, including prices, number of spaces and opening times.
				</td>
			</tr>
		</tbody>
	</table>
</div>


<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>




<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>
'
, 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
<tr>
<div class="txtsevenbbl">Christmas shopping? / </div>  
<tr>
<div class="txtsevenbbl">Going to the sales?</div>  
</table>
</div>

<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/parking.gif" alt="Park and ride" title="Park and ride" />
				</td> 
				<td class="txtseven">
         		Get directions to a Park & Ride site near you. <br\>
					<a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park & ride</a>
					<br\>
                Alternatively, 
                <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
                 has details of nearby car parks, including prices, number of spaces and opening times.
				</td>
			</tr>
		</tbody>
	</table>
</div>



<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>




<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>'
,'2012-12-01','2012-12-31'



EXEC AddContentOverride 
'home', 3, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<div class="txtsevenbbl">Booking Christmas rail travel?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" alt="" title="" />
				</td> 
				<td class="txtseven">
					Is the price of your train ticket more important than your date of travel?  Search by price, rather than by date/time, with our  
					<a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx?cacheparam=0">Find cheaper rail fares</a>
					planner.
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Free webmaster tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" width="26">
					<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" />
				</td> 
				<td class="txtseven">
					Our pdf helpsheets give simple instructions on how to add Transport Direct features to your website.  Download the full set or try 
					<a target="_child" href="/Web2/Downloads/1a - link to Transport Direct with pre-set destination using postcode.pdf">
						Helpsheet 1a 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>.  
					<br/>
					<br/>
					<a target="_child" href="/Web2/Downloads/Transport_Direct_Helpsheets.zip">
						Transport Direct helpsheets (zip file) 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>
'
, 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<div class="txtsevenbbl">Booking Christmas rail travel?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" alt="" title="" />
				</td> 
				<td class="txtseven">
					Is the price of your train ticket more important than your date of travel?  Search by price, rather than by date/time, with our  
					<a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx?cacheparam=0">Find cheaper rail fares</a>
					planner.
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">Free webmaster tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
	<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" width="26">
					<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" />
				</td> 
				<td class="txtseven">
					Our pdf helpsheets give simple instructions on how to add Transport Direct features to your website.  Download the full set or try 
					<a target="_child" href="/Web2/Downloads/1a - link to Transport Direct with pre-set destination using postcode.pdf">
						Helpsheet 1a 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>.  
					<br/>
					<br/>
					<a target="_child" href="/Web2/Downloads/Transport_Direct_Helpsheets.zip">
						Transport Direct helpsheets (zip file) 
						<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />
					</a>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>
'
,'2012-11-01','2012-11-30'



EXEC AddContentOverride 
'journeyplanning_findcarinput', 3, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCarInput', 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
'
, 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>
'
,'2012-11-01','2012-12-31'

EXEC AddContentOverride 
'home', 3, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home', 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
<tr>
<div class="txtsevenbbl">Christmas shopping? / </div>  
<tr>
<div class="txtsevenbbl">Going to the sales?</div>  
</table>
</div>

<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/parking.gif" alt="Park and ride" title="Park and ride" />
				</td> 
				<td class="txtseven">
         		Get directions to a Park & Ride site near you. <br\>
					<a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park & ride</a>
					<br\>
                Alternatively, 
                <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
                 has details of nearby car parks, including prices, number of spaces and opening times.
				</td>
			</tr>
		</tbody>
	</table>
</div>


<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>




<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>
'
, 
'
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">Winter Driving advice  <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoSJP" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
    <tr>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td class="SJPIconPadding"><a target="_child" href="http://www.highways.gov.uk/traffic-information/seasonal-advice/make-time-for-winter/">
    <img title="Highways Agency winter advice" alt="Highways Agency winter advice" 
    src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/green-TD.gif" /></a></td>  
    </tr>  
    </tbody>
  </table>
</div>

<div class="Column3Header">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%">
<tr>
<div class="txtsevenbbl">Christmas shopping? / </div>  
<tr>
<div class="txtsevenbbl">Going to the sales?</div>  
</table>
</div>

<div class="Column3Content">
	<table id="Table4" border="0" cellpadding="2" cellspacing="0" width="100%">
		<tbody>
			<tr>  
				<td class="txtseven" align="center" valign="top" >
					<img src="/web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/parking.gif" alt="Park and ride" title="Park and ride" />
				</td> 
				<td class="txtseven">
         		Get directions to a Park & Ride site near you. <br\>
					<a href="/Web2/JourneyPlanning/ParkAndRideInput.aspx">Plan to park & ride</a>
					<br\>
                Alternatively, 
                <a href="/Web2/JourneyPlanning/FindNearestLandingPage.aspx?ft=cp&id=PROMxms">Find a car park</a>
                 has details of nearby car parks, including prices, number of spaces and opening times.
				</td>
			</tr>
		</tbody>
	</table>
</div>


<div class="Column3Header">
<div class="txtsevenbbl">
 <a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Travel news on your Mobile</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoMobile" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt=" "
          src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/phone.gif"
          border="0" />
        </td>
        <td class="txtseven">See our 
        <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx?cacheparam=0">Mobile/PDA</a> page to find out how to access real-time road and rail travel on your handheld device.<br/><br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>




<div class="Column3Header">
<div class="txtsevenbbl">
  Follow Us
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
        </td>
        <td class="txtseven">Get the latest travel news alerts and find out about Transport Direct developments by connecting with us on Facebook and Twitter.
		<br/>
		<a target="_child" href="http://www.facebook.com/home.php/#!/174434289241225">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/facebook_logo_16.gif" alt="(opens in new window)" />
			Find us on Facebook
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>
		<br/>
		<a target="_child" href="http://www.twitter.com/tdinfo">
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/misc/twitter_bird_16_blue.gif" alt="(opens in new window)" />
			Follow us on Twitter
			<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />
		</a>  
		<br/>
		</td>
      </tr>
    </tbody>
  </table>
</div>'
,'2012-12-01','2012-12-31'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1936
SET @ScriptDesc = 'DUP1936_UPdatePromLinksSchedule2012'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

