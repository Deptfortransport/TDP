-- ***********************************************
-- NAME 		: DUP1708_Add_ChangeCatalogue_Version_Column.sql
-- DESCRIPTION 	: Adds version column to ChangeCatalogue table for use by content update scripts
-- ************************************************

USE [PermanentPortal]
GO

ALTER TABLE dbo.ChangeCatalogue ADD VersionInfo VARCHAR(24) NULL
GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)
DECLARE @Version VARCHAR(24)

SET @ScriptNumber = 10001
SET @ScriptDesc = 'Added version column to ChangeCatalogue table for use by content update scripts'
SET @Version = '$Revision:   1.3  $'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc, VersionInfo = @Version
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary, VersionInfo )
    VALUES (@ScriptNumber, getDate(), @ScriptDesc, @Version)
  END
GO