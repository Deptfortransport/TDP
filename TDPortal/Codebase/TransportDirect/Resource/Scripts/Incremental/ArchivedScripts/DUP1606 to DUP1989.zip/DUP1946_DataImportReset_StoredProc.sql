-- ***********************************************
-- NAME           : DUP1946_DataImportReset_StoredProc.sql
-- DESCRIPTION    : Script to reset the data import FTP configuration table
-- AUTHOR         : Mitesh Modi
-- DATE           : 14 Nov 2012
-- ***********************************************

-- ************************************************************************************************
-- Only to be run in Dev
-- ************************************************************************************************

USE [PermanentPortal]
GO

-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ResetDataFeedImport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE ResetDataFeedImport
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[ResetDataFeedImport]
AS
BEGIN
    -- Resets the last imported date time for all data feeds
	UPDATE [dbo].[FTP_CONFIGURATION]
       SET DATA_FEED_DATETIME = CAST('2000-01-01' AS DATETIME)
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1946
SET @ScriptDesc = 'Script to reset the data import FTP configuration table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO