-- ***********************************************
-- NAME           : DUP1801_Update_CyclePlanner_Bikeability_Contents.sql
-- DESCRIPTION    : Script to update Bikeability link and content on cycle result page
-- AUTHOR         : Amit Patel
-- DATE           : 17 May 2011
-- ***********************************************

USE [Content] 

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.hyperlinkCycleEngland.Text'
,'To find Bikeability training near you select this link'
,'To find Bikeability training near you select this link'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.imageCycleEngland.URL'
,'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleJourney.gif'
,'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/CycleJourney.gif'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1801
SET @ScriptDesc = 'Script to update Bikeability link and content on cycle result page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO