-- ***********************************************
-- NAME 		: DUP1774_Remove_LondonCZone_ExtraText.sql
-- DESCRIPTION 		: Script to switch off CCN0602 London CCzone Extra Text
-- AUTHOR		: Neil Rankin
-- DATE			: 16-12-10
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'CCN0602LondonCCzoneExtraTextVisible' and ThemeId = 1)
BEGIN
	insert into properties values ('CCN0602LondonCCzoneExtraTextVisible', 'false', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('CCN0602LondonCCzoneExtraTextVisible', 'false', 'TDRemotingHost ', 'TDRemotingHost ', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'CCN0602LondonCCzoneExtraTextVisible' and ThemeId = 1
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1774
SET @ScriptDesc = 'Script to switch off CCN0602 London CCzone Extra Text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO