-- ***********************************************
-- NAME             : DUP1632_InternationalPlanner_RelatedLinks.sql
-- DESCRIPTION      : Script to add the Related links to the International Planner Input page
-- AUTHOR           : Richard Hopkins
-- DATE             : 26 March 2010
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Remove any previously added Related Links added for the International planner

DECLARE @ContextId INT

IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindInternationalInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindInternationalInput')

	DELETE 
    FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END

GO


-- Delete the base links previously added to Suggestion Links for the Related links on the International input page 
-- Ensures the correct one is used for the RelatedLinksContextFindInternationalInput context when added
DELETE FROM    
	SuggestionLink       -- Get all suggestion links which are for the Related links category
WHERE   (LinkCategoryId =    -- and are for the InternationalPlanner related links resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Related links'))
AND     (ResourceNameId IN ( 
                            (SELECT     ResourceNameID
                             FROM       ResourceName
                             WHERE      ResourceName LIKE 'InternationalPlanner.%'))) -- All the InternationalPlanner link Resources start with this

GO

--------------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for EBC input page
-- CURRRENTLY NO RELATED LINKS ARE DEFINED SO NONE ARE ADDED

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextFindInternationalInput'
SET @ThemeId = 1


-- Add our new context for EBC input page related links
EXEC AddContext
    
    @ContextName,                            						-- Context
    'Related Link Context - Suggestions for International input Page'			-- Context description


-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


-- Add the actual links. ensure all our link names start with "InternationalPlanner."
EXEC AddExternalSuggestionLink

	'InternationalPlanner.VisitBelgium',				-- ID for ExternalLink table
	'http://visitbelgium.com',						 	-- Full external link URL
	'http://visitbelgium.com',							-- Full test external link URL
	'InternationalPlanner - VisitBelgium Link',		    -- Description of external link. Ensure this is a unique external link description   
	'InternationalPlanner.VisitBelgium',				-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'More information about visiting Belgium',			-- English display text. Populate only if adding new ResourceName or updating existing display text
	'More information about visiting Belgium',			-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
	'Related links',                                    -- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
	1800,						                        -- Priority must be unique for the selected CategoryName this link is for
	0,                                                  -- Set to 0 if to be used as a Suggestion/Related Link
	0,                                                  -- Set to 1 if it is a second level Root link
	@ContextName,                                       -- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',                                                 -- Populate only if adding a new ContextName, or updating description
	@ThemeId                                            -- Theme this link is added for, use 1 as default



EXEC AddExternalSuggestionLink

	'InternationalPlanner.VisitBritain',				-- ID for ExternalLink table
	'http://visitbritain.com',						 	-- Full external link URL
	'http://visitbritain.com',							-- Full test external link URL
	'InternationalPlanner - VisitBritain Link',		    -- Description of external link. Ensure this is a unique external link description   
	'InternationalPlanner.VisitBritain',				-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'More information about visiting Britain',			-- English display text. Populate only if adding new ResourceName or updating existing display text
	'More information about visiting Britain',			-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
	'Related links',                                    -- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
	1810,						                        -- Priority must be unique for the selected CategoryName this link is for
	0,                                                  -- Set to 0 if to be used as a Suggestion/Related Link
	0,                                                  -- Set to 1 if it is a second level Root link
	@ContextName,                                       -- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',                                                 -- Populate only if adding a new ContextName, or updating description
	@ThemeId                                            -- Theme this link is added for, use 1 as default



EXEC AddExternalSuggestionLink

	'InternationalPlanner.VisitFrance',					-- ID for ExternalLink table
	'http://francetourism.com',						 	-- Full external link URL
	'http://francetourism.com',							-- Full test external link URL
	'InternationalPlanner - VisitFrance Link',		    -- Description of external link. Ensure this is a unique external link description   
	'InternationalPlanner.VisitFrance',					-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'More information about visiting France',			-- English display text. Populate only if adding new ResourceName or updating existing display text
	'More information about visiting France',			-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
	'Related links',                                    -- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
	1820,						                        -- Priority must be unique for the selected CategoryName this link is for
	0,                                                  -- Set to 0 if to be used as a Suggestion/Related Link
	0,                                                  -- Set to 1 if it is a second level Root link
	@ContextName,                                       -- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',                                                 -- Populate only if adding a new ContextName, or updating description
	@ThemeId                                            -- Theme this link is added for, use 1 as default


GO



-- END
--------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1632
SET @ScriptDesc = 'InternationalPlanner - Related links left navigation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO