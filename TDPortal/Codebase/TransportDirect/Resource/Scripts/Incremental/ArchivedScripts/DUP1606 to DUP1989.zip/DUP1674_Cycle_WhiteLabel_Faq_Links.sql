-- *************************************************************************************
-- NAME 		: DUP1674_Cycle_WhiteLabel_FAQ_Links.sql
-- DESCRIPTION  : FAQ Context suggestion links added for Cycle white label partners
-- AUTHOR		: Amit Patel
-- *************************************************************************************


-- ********************************* NOTE **********************************************
-- CYCLE WHITE LABEL LINKS ARE ADDED AGAINST TRANSPORT DIRECT THEME WITH NO CONTEXT 
-- SPECIFIED. 
-- *************************************************************************************

USE [TransientPortal]
GO


DECLARE @ThemeId INT
SET @ThemeId = 1


----------------------------------------------------------------------------------------------------
-- FAQ for cycle white label partners only shows the CO2 information and Cycle planner faq.
-- These sections are renumbered to 1 and 2 respectively.
-- So Links added to show correct faq links on journey emissions page
----------------------------------------------------------------------------------------------------

-- FAQ - Estimate Car CO2 Emissions Info Link
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.EstimateCarCO2EmissionsInfo.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - Estimate Car CO2 Emissions Info Link'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.1')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.1'										-- Description of internal link.
			  ,'Cycle White Label FAQ - Estimate Car CO2 Emissions Info Link'	-- Full internal link URL
			  ,'JourneyEmissions.EstimateCarCO2EmissionsInfo.CycleWhiteLabel'
			  ,'Estimating my car''s CO2 emissions'								-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Amcangyfrif allyriadau CO2 fy nghar'							-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,400																-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,''																-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END

-- FAQ - About Car CO2 Emissions
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.AboutCarCO2Emissions.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - About Car CO2 Emissions'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.2')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.2'										-- Description of internal link.
			  ,'Cycle White Label FAQ - About Car CO2 Emissions'				-- Full internal link URL
			  ,'JourneyEmissions.AboutCarCO2Emissions.CycleWhiteLabel'			-- Resource name
			  ,'About car CO2 emissions'										-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Ynglyn ag allyriadau CO2 car'									-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,405																-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,''																-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END


-- FAQ - Estimating Public Transport CO2
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.EstimatingPublicTransportCO2.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - Estimating Public Transport CO2'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.3')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.3'										-- Description of internal link.
			  ,'Cycle White Label FAQ - Estimating Public Transport CO2'		-- Full internal link URL
			  ,'JourneyEmissions.EstimatingPublicTransportCO2.CycleWhiteLabel'	-- Resource name
			  ,'Estimating public transport and air journey CO2'				-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Tr�n'															-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,410																-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,''																-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END

-- FAQ - CO2 From Different Transport
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.CO2FromDifferentTransport.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - CO2 From Different Transport'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.5')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.5'										-- Description of internal link.
			  ,'Cycle White Label FAQ - CO2 From Different Transport'			-- Full internal link URL
			  ,'JourneyEmissions.CO2FromDifferentTransport.CycleWhiteLabel'		-- Resource name
			  ,'About bus and and coach journeys'								-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Dybio am siwrneiau bws a choets'								-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,415															-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,''																-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END


-- FAQ - Comparing Car And Public Transport
IF NOT EXISTS(
	SELECT SuggestionLinkId FROM SuggestionLink
		INNER JOIN InternalLink 
			ON SuggestionLink.ExternalInternalLinkId = InternalLink.InternalLinkId
			AND SuggestionLink.ExternalInternalLinkType = 'Internal'
		INNER JOIN ResourceName
			ON SuggestionLink.ResourceNameId = ResourceName.ResourceNameId
			
	WHERE ResourceName.ResourceName = 'JourneyEmissions.ComparingCarAndPublicTransport.CycleWhiteLabel'
	AND InternalLink.Description = 'Cycle White Label FAQ - Comparing Car And Public Transport'
	AND InternalLink.RelativeURL = 'Help/HelpCarbon.aspx#A1.4')
BEGIN
	EXECUTE AddInternalSuggestionLink
			   'Help/HelpCarbon.aspx#A1.4'										-- Description of internal link.
			  ,'Cycle White Label FAQ - Comparing Car And Public Transport'		-- Full internal link URL
			  ,'JourneyEmissions.ComparingCarAndPublicTransport.CycleWhiteLabel'-- Resource name
			  ,'Comparing car and public transport CO2'							-- English display text. Populate only if adding new ResourceName or updating existing display text
			  ,'Cymharu CO2 car a thrafnidiaeth gyhoeddus'						-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
			  ,'General'														-- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
			  ,420															-- Priority must be unique for the selected CategoryName this link is for
			  ,0																-- Set to 0 if to be used as a Suggestion/Related Link
			  ,0																-- Set to 1 if it is a second level Root link
			  ,''																-- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
			  ,''																-- Populate only if adding a new ContextName, or updating description
			  ,@ThemeId
			 
END


GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1640
SET @ScriptDesc = 'FAQ Context suggestion links added for Cycle white label partners'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
