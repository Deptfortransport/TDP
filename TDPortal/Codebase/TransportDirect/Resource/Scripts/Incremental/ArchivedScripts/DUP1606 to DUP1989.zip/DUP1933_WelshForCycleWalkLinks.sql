-- ***********************************************
-- NAME 		: DUP1933_WelshForCycleWalkLinks.sql
-- DESCRIPTION 	: Addition of welsh translations for cycle walk links
-- AUTHOR		: David Lane
-- DATE			: 31 Oct 12
-- ************************************************

USE [Content]
GO

-------------------------------
-- Add to Content
-------------------------------

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.WalkText',
	'Your journey is a distance of about {0} miles. To find out about the walking route please click the walkit icon.',
	'Mae eich taith tua {0} milltir o bellter. Er mwyn cael gwybodaeth am y llwybr cerdded cliciwch ar yr eicon walkit.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.CycleText',
	'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon.',
	'Mae eich taith tua {0} milltir o bellter. Er mwyn cael gwybodaeth am y llwybr beicio cliciwch ar yr eicon beicio.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.WalkCycleText',
	'Your journey is a distance of about {0} miles. To find out about the cycle route please click the cycle icon or to find out about walking please click the walkit icon.',
	'Mae eich taith tua {0} milltir o bellter. Er mwyn cael gwybodaeth am y llwybr beicio cliciwch ar yr eicon beicio neu er mwyn cael gwybodaeth am y llwybr cerdded cliciwch ar yr eicon walkit.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.WalkTextSingleMile',
	'Your journey is a distance of about {0} mile. To find out about the walking route please click the walkit icon.',
	'Mae eich taith tua {0} milltir o bellter. Er mwyn cael gwybodaeth am y llwybr cerdded cliciwch ar yr eicon walkit.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.CycleTextSingleMile',
	'Your journey is a distance of about {0} mile. To find out about the cycle route please click the cycle icon.',
	'Mae eich taith tua {0} milltir o bellter. Er mwyn cael gwybodaeth am y llwybr beicio cliciwch ar yr eicon beicio.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.WalkCycleTextSingleMile',
	'Your journey is a distance of about {0} mile. To find out about the cycle route please click the cycle icon or to find out about walking please click the walkit icon.',
	'Mae eich taith tua {0} milltir o bellter. Er mwyn cael gwybodaeth am y llwybr beicio cliciwch ar yr eicon beicio neu er mwyn cael gwybodaeth am y llwybr cerdded cliciwch ar yr eicon walkit.'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.WalkitAltText',
	'Walk route (opens in new window)',
	'Llwybr cerdded (agor mewn ffenestr newydd)'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.WalkitTooltip',
	'Walk route (opens in new window)',
	'Llwybr cerdded (agor mewn ffenestr newydd)'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.CycleAltText',
	'Plan cycle journey',
	'Cynllunio taith feicio'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.CycleTooltip',
	'Plan cycle journey',
	'Cynllunio taith feicio'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'CycleWalkLinks.ModalPopupWarning',
	'<div class="popupHeader">    <img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation.gif" alt="Warning" title="Warning"/>    <span class="popupheaderText">Warning</span>  </div>  <div class="popupContent">    <p class="bold">When planning your cycle journey Transport Direct will not retain details of your door to door journey.</p>    <p>If you wish to continue please select next, if not then please select cancel.<p>    <p>You can retain details of your door to door journey for reference by clicking on ''printer friendly'' before you plan your cycle journey.</p>    <br/>  </div>',
	'<div class="popupHeader">    <img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation.gif" alt="Rhybudd" title="Rhybudd"/>    <span class="popupheaderText">Rhybudd</span>  </div>  <div class="popupContent">    <p class="bold">Wrth gynllunio eich taith feicio ni fydd Transport Direct yn cadw manylion eich taith o ddrws i ddrws.</p>    <p>Os hoffech barhau dewiswch Nesaf, fel arall dewiswch Canslo.<p>    <p>Gallwch gadw manylion eich taith o ddrws i ddrws er mwyn cyfeirio atynt, drwy glicio ar ''hawdd ei argraffu'' cyn cynllunio eich taith feicio.</p>    <br/>  </div>'
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1933
SET @ScriptDesc = 'Welsh translations for cycle walk links'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO