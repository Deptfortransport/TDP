-- ***********************************************
-- NAME 		: DUP1813_New_Intellitracker_TrackingKeys_For_Cycle_Buttons.sql
-- DESCRIPTION 	: Script to add Tracking keys for Intellitracker for cycle show/hide map/detail view buttons
-- AUTHOR		: Amit Patel
-- DATE			: 28 Jul 2011
-- ************************************************

USE [Content]
GO

-------------------------------------------------------------------------------------------
-- Droping unique key index on Tracking key as the requirement of using the same JDnn keys
-- instead of CYnn keys where possible
-------------------------------------------------------------------------------------------

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UQ_tblTrackingKeys]'))
BEGIN
 ALTER TABLE tblTrackingKeys DROP CONSTRAINT UQ_tblTrackingKeys
END

-----------------------------------------------------------------------------------------
-- Cycle Journey Details Page Trakcing keys
-----------------------------------------------------------------------------------------


EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'OutwardDate'
	,'JD11'
	,'Outward journey date selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'ReturnDate'
	,'JD12'
	,'Return journey date selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'OutwardTime'
	,'JD15'
	,'Outward journey time selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'ReturnTime'
	,'JD16'
	,'Return journey time selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'buttonShowMapOutward'
	,'JD01'
	,'when show diagram button click for outward journey to show detail in diagram view'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'buttonHideMapOutward'
	,'JD03'
	,'when hide map button click for outward journey' 

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'buttonShowMapReturn'
	,'JD02'
	,'when show diagram button click for return journey to show detail in diagram view' 

EXECUTE dbo.AddPageTrackingKey
	'CycleJourneyDetails'
	,'buttonHideMapReturn'
	,'JD04'
	,'when hide map button click for return journey'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'OutwardDaysToDepart'
	,'JD17'
	,'Outward journey days to depart from current date'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'ReturnDaysToDepart'
	,'JD18'
	,'Return journey days to depart from current date' 
	
EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'OutwardDaysToDepart'
	,'JD17'
	,'Outward journey days to depart from current date'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'ReturnDaysToDepart'
	,'JD18'
	,'Return journey days to depart from current date' 

EXECUTE dbo.AddPageTrackingKey
	 'VisitPlannerResults'
	,'OutwardDate'
	,'JD11'
	,'visit planner result date selected by user' 
		
EXECUTE dbo.AddPageTrackingKey
	 'VisitPlannerResults'
	,'OutwardTime'
	,'JD15'
	,'Outward journey time' 

EXECUTE dbo.AddPageTrackingKey
	 'VisitPlannerResults'
	,'OutwardDaysToDepart'
	,'JD17'
	,'Outward journey days to depart from current date'
	
EXECUTE dbo.AddPageTrackingKey
	 'VisitPlannerResults'
	,'SummaryView'
	,'VPR01'
	,'Visit planner results summary is visible'
	
EXECUTE dbo.AddPageTrackingKey
	 'VisitPlannerResults'
	,'DiagramView'
	,'VPR02'
	,'Visit planner results diagram view is visible'

EXECUTE dbo.AddPageTrackingKey
	 'VisitPlannerResults'
	,'TableView'
	,'VPR03'
	,'Visit planner results table view is visible'

EXECUTE dbo.AddPageTrackingKey
	 'VisitPlannerResults'
	,'MapView'
	,'VPR04'
	,'Visit planner results map view is visible'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1813
SET @ScriptDesc = 'Script to add New Tracking keys for Intellitracker'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END