-- ****************************************************************
-- NAME 		: DUP1925_AddGetLatestFeedNameStoredProc.sql
-- DESCRIPTION 	: Creates GetLatestDataFeedFileName SPROC for use by 
-- 				  Gazetteer import process.
-- AUTHOR		: Rich Broddle
-- DATE			: 10 Sept 2012
-- ****************************************************************

USE [PermanentPortal]
GO

-----------------------------------------------
-- GetCycleMetValues Stored Procedure
-----------------------------------------------

IF NOT EXISTS (   SELECT * FROM INFORMATION_SCHEMA.ROUTINES
              WHERE SPECIFIC_CATALOG = 'PermanentPortal' 
              AND ROUTINE_NAME = 'GetLatestDataFeedFileName' )
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetLatestDataFeedFileName] AS BEGIN SET NOCOUNT ON END')
	END
GO

ALTER PROCEDURE [dbo].[GetLatestDataFeedFileName](
	@FeedName varchar(12) = NULL
)

AS
Begin

	SET NOCOUNT ON  
	SELECT     DATA_FEED_FILENAME 
	FROM         FTP_CONFIGURATION
	WHERE     (DATA_FEED = @FeedName )

End
GO

-- Grant permissions - will only work for relevant users as only they
-- will exist
GRANT  EXECUTE  ON [dbo].[GetLatestDataFeedFileName]  TO [BBPTDPSIS\siadmin]
GRANT  EXECUTE  ON [dbo].[GetLatestDataFeedFileName]  TO [BBPTDPS\siadmin]
GRANT  EXECUTE  ON [dbo].[GetLatestDataFeedFileName]  TO [ACPTDPS\siadmin]
GRANT  EXECUTE  ON [dbo].[GetLatestDataFeedFileName]  TO [BBPTDPSIS\-service-nsm]
GRANT  EXECUTE  ON [dbo].[GetLatestDataFeedFileName]  TO [BBPTDPS\-service-nsm]
GRANT  EXECUTE  ON [dbo].[GetLatestDataFeedFileName]  TO [ACPTDPS\-service-nsm]
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1925
SET @ScriptDesc = 'Create GetLatestDataFeedFileName SPROC'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO