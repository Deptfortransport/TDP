-- ***********************************************
-- NAME 		: DUP1973_Telecabine_DropDownData.sql
-- DESCRIPTION 	: Telecabine transport type dropdowndata update
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Jan 13
-- ************************************************

USE [PermanentPortal]
GO

-- Tidy up
DELETE FROM [DropDownLists]
WHERE DataSet = 'PublicTransportsCheck'

-- PublicTransportsCheck transport types checkbox list
INSERT INTO DropDownLists values ('PublicTransportsCheck', 'Train', 'Rail',		1, 1, 0, 1)
INSERT INTO DropDownLists values ('PublicTransportsCheck', 'Bus', 'Bus',		1, 2, 0, 1)
INSERT INTO DropDownLists values ('PublicTransportsCheck', 'Underground', 'Underground', 1,	3, 0, 1)
INSERT INTO DropDownLists values ('PublicTransportsCheck', 'Tram', 'Tram',		1, 4, 0, 1)
INSERT INTO DropDownLists values ('PublicTransportsCheck', 'Plane', 'Air',		1, 5, 0, 1)
INSERT INTO DropDownLists values ('PublicTransportsCheck', 'Telecabine', 'Telecabine', 1, 6, 0, 1)
INSERT INTO DropDownLists values ('PublicTransportsCheck', 'Ferry', 'Ferry',	1, 7, 0, 1)

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1973
SET @ScriptDesc = 'Telecabine transport type dropdowndata update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO