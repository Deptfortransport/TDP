-- ***********************************************
-- NAME 		: DUP1817_DPTAC_ExternalLink_Update.sql
-- DESCRIPTION 		: Script to DPTAC external links
-- AUTHOR		: Neil Rankin
-- DATE			: 18 August 2011
-- ************************************************


USE [TransientPortal]   
GO


EXEC AddExternalLink  'AccessibilityInformation.Air', 'http://www.direct.gov.uk/en/DisabledPeople/TravelHolidaysAndBreaks/GettingThere/DG_4017242','http://www.direct.gov.uk/en/DisabledPeople/TravelHolidaysAndBreaks/GettingThere/DG_4017242','DPTAC Going by air' 

EXEC AddExternalLink  'AccessibilityInformation.BeforeTravel', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','DPTAC Before you travel' 

EXEC AddExternalLink  'AccessibilityInformation.Bus', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Car', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','DPTAC Motoring' 

EXEC AddExternalLink  'AccessibilityInformation.Coach', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Drt', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Ferry', 'http://www.direct.gov.uk/en/TravelAndTransport/Publictransport/index.htm','http://www.direct.gov.uk/en/TravelAndTransport/Publictransport/index.htm','DPTAC Ferries' 

EXEC AddExternalLink  'AccessibilityInformation.Metro', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_4002764','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_4002764','DPTAC Light rapid transport systems' 

EXEC AddExternalLink  'AccessibilityInformation.Rail', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_4002764','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_4002764','DPTAC Going by rail' 

EXEC AddExternalLink  'AccessibilityInformation.RailReplacementBus', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/PublicAndCommunityTransport/DG_068407','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Taxi', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','DPTAC Taxis and private hire' 

EXEC AddExternalLink  'AccessibilityInformation.Tram', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','DPTAC Light rapid transport systems' 

EXEC AddExternalLink  'AccessibilityInformation.Underground', 'http://www.direct.gov.uk/en/TravelAndTransport/Publictransport/index.htm','http://www.direct.gov.uk/en/TravelAndTransport/Publictransport/index.htm','DPTAC Underground and subway systems' 

EXEC AddExternalLink  'DisabilityInformation', 'http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','http://www.direct.gov.uk/en/DisabledPeople/MotoringAndTransport/index.htm','Information for travellers with disabilities' 

GO

USE [Content]   
GO

EXEC AddtblContent
1, 1,'langStrings','JourneyAccessibilityLinksControl.labelInfoText',
'Click on any of the vehicle links below for information on general accessibility issues you might need to think about when taking this type of transport. A new window will open displaying the relevant page on the Directgov website.',
'Cliciwch y dolennau cludiant isod am wybodaeth am hygyrchedd ar y mathau o gludiant sy''n rhan o''ch siwrnai.  Bydd ffenestr newydd yn agor yn arddangos y dudalen berthnasol ar wefan Directgov.'

Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1817
SET @ScriptDesc = 'Script to update DPTAC external link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO