-- ***********************************************
-- NAME 		: DUP1753_CyclePlanner_EES_Type_Reporting.sql
-- DESCRIPTION 	: Script to add Cycle Planner EES Types for reporting
-- AUTHOR		: Amit Patel
-- DATE			: 27 Sep 2008
-- ************************************************

USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM [EnhancedExposedServicesType]
				WHERE [EESTType] ='TransportDirect_EnhancedExposedServices_CycleJourneyPlannerSynchronous_V1')
BEGIN
INSERT INTO [EnhancedExposedServicesType]
           ([EESTType]
           ,[EESTDescription])
     VALUES
           ('TransportDirect_EnhancedExposedServices_CycleJourneyPlannerSynchronous_V1'
           ,'EnhancedExposedServices CycleJourneyPlannerSynchronous_V1')
END


IF NOT EXISTS(SELECT * FROM [EnhancedExposedServicesType]
				WHERE [EESTType] ='TransportDirect_EnhancedExposedServices_GradientProfileService_V1')
BEGIN
INSERT INTO [EnhancedExposedServicesType]
           ([EESTType]
           ,[EESTDescription])
     VALUES
           ('TransportDirect_EnhancedExposedServices_GradientProfileService_V1'
           ,'EnhancedExposedServices GradientProfileService_V1')
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1753
SET @ScriptDesc = 'Script to add Cycle Planner EES Types for reporting'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO