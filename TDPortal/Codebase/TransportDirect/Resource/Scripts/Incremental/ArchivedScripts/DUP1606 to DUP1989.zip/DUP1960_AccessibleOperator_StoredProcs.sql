-- ***********************************************
-- NAME           : DUP1960_AccessibleOperator_StoredProcs.sql
-- DESCRIPTION    : Script to add accessible operator stored procedures
-- AUTHOR         : Mitesh Modi
-- DATE           : 03 Dec 2012
-- ***********************************************

-- ************************************************************************************************
-- THIS SCRIPT MUST BE AMENDED TO ASSIGN PERMISSIONS TO THE CORRECT USER.
-- SEE BOTTOM OF SCRIPT.
-- ************************************************************************************************

USE [TransientPortal]
GO

-- Create stored proc if needed
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAccessibleOperatorLinks]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetAccessibleOperatorLinks 	
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

-- Update stored proc
ALTER PROCEDURE [dbo].[GetAccessibleOperatorLinks]
AS
BEGIN
    -- GetAccessibleOperatorLinks strored proc to return accessible operators
	SELECT 
		 [OperatorCode]
		,[ServiceNumber]
		,[Mode]
		,[Region]
		,[WEFDate]
		,[WEUDate]
		,[WheelchairBooking]
		,[AssistanceBooking]
		,[BookingUrl]
		,[BookingNumber]
	FROM [dbo].[AccessibleOperators]
END
GO
	
	
-- Grant permissions - will only work for relevant users as only they
-- will exist
GRANT  EXECUTE  ON [dbo].[GetAccessibleOperatorLinks]  TO [BBPTDPSIW\aspuser]
GRANT  EXECUTE  ON [dbo].[GetAccessibleOperatorLinks]  TO [BBPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[GetAccessibleOperatorLinks]  TO [ACPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[GetAccessibleOperatorLinks]  TO [BBPTDPSIS\aspuser]
GRANT  EXECUTE  ON [dbo].[GetAccessibleOperatorLinks]  TO [BBPTDPS\aspuser]
GRANT  EXECUTE  ON [dbo].[GetAccessibleOperatorLinks]  TO [ACPTDPS\aspuser]

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1960
SET @ScriptDesc = 'Script to add accessible operator stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO