-- ***********************************************
-- NAME           : DUP1793_Remove_CyclePlanner_cycleParking_LeftHandLink.sql
-- DESCRIPTION    : Script to remove 'what next' left hand link on about us page
-- AUTHOR         : Amit Patel
-- DATE           : 04 April 2011
-- ***********************************************

USE [TransientPortal] 

EXEC RemoveSuggestionLink 'CyclePlanner.Parking','Related links','RelatedLinksContextFindCycleInput'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1793
SET @ScriptDesc = 'Script to remove ''Find out about cycle parking'' left hand link on Cycle Planner page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO