-- ***********************************************
-- NAME 		: DUP1934_DigitalTVLink.sql
-- DESCRIPTION 	: Fix to digital TV link
-- AUTHOR		: David Lane
-- DATE			: 31 Oct 12
-- ************************************************

USE [Content]
GO

-------------------------------
-- Add to Content
-------------------------------

EXEC AddtblContent
	1, 1, 'langStrings', 'HomeTipsTools.hrefDigiTv',
	'Tools/Home.aspx#DigiTvInfo',
	'Tools/Home.aspx#DigiTvInfo'
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1934
SET @ScriptDesc = 'Fix to digital TV link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO