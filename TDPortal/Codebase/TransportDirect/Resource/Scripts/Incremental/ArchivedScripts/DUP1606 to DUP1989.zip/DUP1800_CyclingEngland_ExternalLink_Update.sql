-- ***********************************************
-- NAME 		: DUP1800_CyclingEngland_ExternalLink_Update.sql
-- DESCRIPTION 	: Script to update CyclingEngland external link
-- AUTHOR		: Phil Scott
-- DATE			: 10 May 2011
-- ************************************************


USE [TransientPortal]   
GO


EXEC AddExternalLink  'CycleEngland', 'http://www.dft.gov.uk/bikeability/wp-content/uploads/Bikeability_Providers_05-05-11.pdf','http://www.dft.gov.uk/bikeability/wp-content/uploads/Bikeability_Providers_05-05-11.pdf','Cycle England bikeability url' 

EXEC AddExternalLink  'CyclePlanner.CyclingEngland', 'http://www.dft.gov.uk/pgr/sustainable/cycling/','http://www.dft.gov.uk/pgr/sustainable/cycling/','Cycle England homepage url' 




GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1800
SET @ScriptDesc = 'Script to update CyclingEngland external link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO