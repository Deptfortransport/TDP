-- ***********************************************
-- NAME 		: DUP1740_CCN0602_LondonCCzoneText_Property.sql
-- DESCRIPTION 	: Script to add property switch for CCN0602 London CCzone Extra Text
-- AUTHOR		: Rich Broddle
-- DATE			: 25-08-10
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'CCN0602LondonCCzoneExtraTextVisible' and ThemeId = 1)
BEGIN
	insert into properties values ('CCN0602LondonCCzoneExtraTextVisible', 'true', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('CCN0602LondonCCzoneExtraTextVisible', 'true', 'TDRemotingHost ', 'TDRemotingHost ', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'CCN0602LondonCCzoneExtraTextVisible' and ThemeId = 1
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1740
SET @ScriptDesc = 'Script to add property switch for CCN0602 London CCzone Extra Text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO