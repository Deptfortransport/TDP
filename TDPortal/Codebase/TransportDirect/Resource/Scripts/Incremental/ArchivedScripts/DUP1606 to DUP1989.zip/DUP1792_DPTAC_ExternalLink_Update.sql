-- ***********************************************
-- NAME 		: DUP1792_DPTAC_ExternalLink_Update.sql
-- DESCRIPTION 	: Script to update CyclingEngland external link
-- AUTHOR		: Neil Rankin
-- DATE			: 04 APR 2011
-- ************************************************


USE [TransientPortal]   
GO


EXEC AddExternalLink  'AccessibilityInformation.Air', 'http://dptac.independent.gov.uk/door-to-door/06/index.htm','http://dptac.independent.gov.uk/door-to-door/06/index.htm','DPTAC Going by air' 

EXEC AddExternalLink  'AccessibilityInformation.BeforeTravel', 'http://dptac.independent.gov.uk/door-to-door/03/index.htm','http://dptac.independent.gov.uk/door-to-door/03/index.htm','DPTAC Before you travel' 

EXEC AddExternalLink  'AccessibilityInformation.Bus', 'http://dptac.independent.gov.uk/door-to-door/04/03.htm','http://dptac.independent.gov.uk/door-to-door/04/03.htm','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Car', 'http://dptac.independent.gov.uk/door-to-door/04/02.htm','http://dptac.independent.gov.uk/door-to-door/04/02.htm','DPTAC Motoring' 

EXEC AddExternalLink  'AccessibilityInformation.Coach', 'http://dptac.independent.gov.uk/door-to-door/04/03.htm','http://dptac.independent.gov.uk/door-to-door/04/03.htm','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Drt', 'http://dptac.independent.gov.uk/door-to-door/04/03.htm','http://dptac.independent.gov.uk/door-to-door/04/03.htm','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Ferry', 'http://dptac.independent.gov.uk/door-to-door/07/index.htm#02','http://dptac.independent.gov.uk/door-to-door/07/index.htm#02','DPTAC Ferries' 

EXEC AddExternalLink  'AccessibilityInformation.Metro', 'http://dptac.independent.gov.uk/door-to-door/05/08.htm','http://dptac.independent.gov.uk/door-to-door/05/08.htm','DPTAC Light rapid transport systems' 

EXEC AddExternalLink  'AccessibilityInformation.Rail', 'http://dptac.independent.gov.uk/door-to-door/05/index.htm','http://dptac.independent.gov.uk/door-to-door/05/index.htm','DPTAC Going by rail' 

EXEC AddExternalLink  'AccessibilityInformation.RailReplacementBus', 'http://dptac.independent.gov.uk/door-to-door/04/03.htm','http://dptac.independent.gov.uk/door-to-door/04/03.htm','DPTAC Buses and coaches' 

EXEC AddExternalLink  'AccessibilityInformation.Taxi', 'http://dptac.independent.gov.uk/door-to-door/04/04.htm','http://dptac.independent.gov.uk/door-to-door/04/04.htm','DPTAC Taxis and private hire' 

EXEC AddExternalLink  'AccessibilityInformation.Tram', 'http://dptac.independent.gov.uk/door-to-door/05/08.htm','http://dptac.independent.gov.uk/door-to-door/05/08.htm','DPTAC Light rapid transport systems' 

EXEC AddExternalLink  'AccessibilityInformation.Underground', 'http://dptac.independent.gov.uk/door-to-door/05/07.htm','http://dptac.independent.gov.uk/door-to-door/05/07.htm','DPTAC Underground and subway systems' 

EXEC AddExternalLink  'DisabilityInformation', 'http://dptac.independent.gov.uk/door-to-door/03/index.htm','http://dptac.independent.gov.uk/door-to-door/03/index.htm','Information for travellers with disabilities' 



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1792
SET @ScriptDesc = 'Script to update DPTAC external link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO