-- ***********************************************
-- NAME 		: DUP1803_Intellitracker_TrackingKeys.sql
-- DESCRIPTION 	: Script to add Tracking keys for Intellitracker
-- AUTHOR		: Phil Scott
-- DATE			: 18 Mar 2011
-- ************************************************

USE [Content]
GO


-----------------------------------------------------------------------------------------
-- Cycle Journey Details Page Trakcing keys
-----------------------------------------------------------------------------------------
	

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'OutwardDate'
	,'CY01'
	,'Outward journey date selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'CycleJourneyDetails'
	,'ReturnDate'
	,'CY02'
	,'Return journey date selected by user' 


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1803
SET @ScriptDesc = 'Script to add Tracking keys for Intellitracker'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO