-- ***********************************************
-- NAME          : DUP1828_Kizoom_Domain_Properties.sql
-- DESCRIPTION   : Script to change urls due to kizoom domain change
-- AUTHOR        : Phil Scott
-- DATE          : 01 Sep 2011
-- ************************************************

USE [PermanentPortal]
GO

--*********************************************************************************************************************************************************
--*** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP 
--*** ACP *** ACP *** ACP *** ACP *** ACP *** ACP ***                                                             *** ACP *** ACP *** ACP *** ACP *** ACP 
--*** ACP *** ACP *** ACP *** ACP *** ACP *** ACP ***           CHANGES APPLICABLE TO ACP ONLY                    *** ACP *** ACP *** ACP *** ACP *** ACP 
--*** ACP *** ACP *** ACP *** ACP *** ACP *** ACP ***                                                             *** ACP *** ACP *** ACP *** ACP *** ACP 
--*** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP *** ACP 
--*********************************************************************************************************************************************************


IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL', 'http://tdti.prod.tpti.co.uk/en/deps/index', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.prod.tpti.co.uk/en/deps/index'
	where pname = 'TDOnTheMove.TDMobileUI.URL' and ThemeId = 1
END

GO

-- ************************************************

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.Arrival' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.Arrival', 'http://tdti.prod.tpti.co.uk/en/arrs/results?atCode={0}&mode={1}&time={2}&timeReqType=today', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.prod.tpti.co.uk/en/arrs/results?atCode={0}&mode={1}&time={2}&timeReqType=today'
	where pname = 'TDOnTheMove.TDMobileUI.URL.Arrival' and ThemeId = 1
END

GO

-- ************************************************

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.cy-GB' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.cy-GB', 'http://tdti.prod.tpti.co.uk/cy/deps/index', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.prod.tpti.co.uk/cy/deps/index'
	where pname = 'TDOnTheMove.TDMobileUI.URL.cy-GB' and ThemeId = 1
END

GO

-- ************************************************

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.Departure' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.Departure', 'http://tdti.prod.tpti.co.uk/en/deps/results?fromCode={0}&mode={1}&time={2}&timeReqType=today', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.prod.tpti.co.uk/en/deps/results?fromCode={0}&mode={1}&time={2}&timeReqType=today'
	where pname = 'TDOnTheMove.TDMobileUI.URL.Departure' and ThemeId = 1
END

GO

-- ************************************************
		

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.en-GB' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.en-GB', 'http://tdti.prod.tpti.co.uk/en/deps/index', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.prod.tpti.co.uk/en/deps/index'
	where pname = 'TDOnTheMove.TDMobileUI.URL.en-GB' and ThemeId = 1
END

GO

-- ************************************************


--*********************************************************************************************************************************************************
--*** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP 
--*** BBP *** BBP *** BBP *** BBP *** BBP *** BBP ***                                                             *** BBP *** BBP *** BBP *** BBP *** BBP
--*** BBP *** BBP *** BBP *** BBP *** BBP *** BBP ***           CHANGES APPLICABLE TO BBP ONLY                    *** BBP *** BBP *** BBP *** BBP *** BBP 
--*** BBP *** BBP *** BBP *** BBP *** BBP *** BBP ***                                                             *** BBP *** BBP *** BBP *** BBP *** BBP 
--*** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP *** BBP 
--*********************************************************************************************************************************************************
/*   AWAITING NEW URL

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL', 'http://tdti.staging.kizoom.com/en/deps/index', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.staging.kizoom.com/en/deps/index'
	where pname = 'TDOnTheMove.TDMobileUI.URL' and ThemeId = 1
END

GO

-- ************************************************

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.Arrival' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.Arrival', 'http://tdti.staging.kizoom.com/en/arrs/results?atCode={0}&mode={1}&time={2}&timeReqType=today', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.staging.kizoom.com/en/arrs/results?atCode={0}&mode={1}&time={2}&timeReqType=today'
	where pname = 'TDOnTheMove.TDMobileUI.URL.Arrival' and ThemeId = 1
END

GO

-- ************************************************

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.cy-GB' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.cy-GB', 'http://tdti.staging.kizoom.com/cy/deps/index', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'hhttp://tdti.staging.kizoom.com/cy/deps/index'
	where pname = 'TDOnTheMove.TDMobileUI.URL.cy-GB' and ThemeId = 1
END

GO

-- ************************************************	

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.Departure' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.Departure', 'http://tdti.staging.kizoom.com/en/deps/results?fromCode={0}&mode={1}&time={2}&timeReqType=today', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.staging.kizoom.com/en/deps/results?fromCode={0}&mode={1}&time={2}&timeReqType=today'
	where pname = 'TDOnTheMove.TDMobileUI.URL.Departure' and ThemeId = 1
END

GO

-- ************************************************
		
IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.en-GB' and ThemeId = 1)
BEGIN
	INSERT INTO properties VALUES ('TDOnTheMove.TDMobileUI.URL.en-GB', 'http://tdti.staging.kizoom.com/en/deps/index', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.staging.kizoom.com/en/deps/index'
	where pname = 'TDOnTheMove.TDMobileUI.URL.en-GB' and ThemeId = 1
END

GO

-- ************************************************
*/
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1828
SET @ScriptDesc = 'Script to change urls due to kizoom domain change'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO