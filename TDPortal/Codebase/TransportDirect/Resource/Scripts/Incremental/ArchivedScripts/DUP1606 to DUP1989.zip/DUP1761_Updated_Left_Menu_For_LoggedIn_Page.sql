-- *************************************************************************************
-- NAME 		: DUPxxxx_Updated_Left_Menu_For_LoggedIn_Page.sql
-- DESCRIPTION  : Added left menu for logged in page
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- This will set up menu for Login/Register page user Logged in state

USE [TransientPortal]
GO

-----------------------------------------------------------
-- Add Link Category for Login/Register

-- Adding Link Categories we want
DECLARE @LinkCategoryId INT
DECLARE @LinkPriority INT

-- Adding Link Category for Network Maps

SELECT @LinkCategoryId = Max(LinkCategoryId)+1 FROM LinkCategory

SELECT @LinkPriority = Max(Priority) + 10 FROM LinkCategory 

IF NOT EXISTS (SELECT TOP 1 * from LinkCategory WHERE [Name] = 'UserLoggedIn')
BEGIN
	INSERT INTO LinkCategory VALUES(@LinkCategoryId, @LinkPriority, 'UserLoggedIn', 'User Logged In menu')
END

GO

------------------------------------------------------------
-- Add/update the internal links we want
DECLARE @InternalLinkID INT,
	@RelativeURL varchar(100),
	@InternalLinkDescription varchar(500)


-- Update to Link 1 for the email address update link
SET @RelativeURL = 'LoginRegister.aspx?page=updateemail'
SET @InternalLinkDescription = 'Update email address link'

EXEC AddInternalLink  @RelativeURL, @InternalLinkDescription

-- Update to Link 2 for the delete account link
SET @RelativeURL = 'LoginRegister.aspx?page=deleteaccount'
SET @InternalLinkDescription = 'Delete Account link'

EXEC AddInternalLink  @RelativeURL, @InternalLinkDescription
	
-- Update to Link 3 for the log out link
SET @RelativeURL = 'LoginRegister.aspx?page=logout'
SET @InternalLinkDescription = 'Log out link'

EXEC AddInternalLink  @RelativeURL, @InternalLinkDescription

-- Add Link 4 for the user preferences link
SET @RelativeURL = 'LoginRegister.aspx?page=preferences'
SET @InternalLinkDescription = 'User Preferences link'

EXEC AddInternalLink  @RelativeURL, @InternalLinkDescription


GO

---------------------------------------------------------------
-- Delete the link for user preferences if its already exists
---------------------------------------------------------------
DELETE  -- Delete context suggestion link
FROM    ContextSuggestionLink
WHERE   (SuggestionLinkId IN
                            (SELECT    SuggestionLinkId    -- Get all suggestion links which are for the Plan a journey category
                             FROM          SuggestionLink   -- and use our the FindACycle resource (this is the Find Cycle Input page)
                             WHERE      (LinkCategoryId =
                                             (SELECT     LinkCategoryId
                                              FROM       LinkCategory
                                              WHERE      [name] = 'UserLoggedIn')
										 )
										 AND (ResourceNameId =
											  (SELECT     ResourceNameID
											   FROM       ResourceName
											   WHERE      ResourceName = 'UserLoggedIn.UserPreferences')
										 )
                             )
         )
		 AND (ContextId IN    -- And only for the Homepage or Plan a journey mini homepage
				(SELECT     ContextId
				 FROM       Context
				 WHERE      [Name] = 'HomePageMenuLoggedIn'))

DELETE  -- DELETE the suggestion link
	 FROM          SuggestionLink   
	 WHERE      (LinkCategoryId =
					 (SELECT     LinkCategoryId
					  FROM       LinkCategory
					  WHERE      [name] = 'UserLoggedIn')
				 )
				 AND (ResourceNameId =
					  (SELECT     ResourceNameID
					   FROM       ResourceName
					   WHERE      ResourceName = 'UserLoggedIn.UserPreferences')
				 )
				 AND Priority = 8805


------------------------------------------------------------
-- Left hand link for the User preferences
------------------------------------------------------------

-- This adds the actual link, and assigns it to the Home page
EXEC AddInternalSuggestionLink

	'LoginRegister.aspx?page=preferences',      -- Relative internal link URL
	'User Preferences link',                    -- Description of internal link. Ensure this is a unique internal link description
	'UserLoggedIn.UserPreferences',			    -- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Preferences',		                        -- English display text. Populate only if adding new ResourceName or updating existing display text
	'cy Preferences',	        	            -- Welsh display text. Populate only if adding new ResourceName or updating existing display text	
	'UserLoggedIn',				                -- Category Name (LinkCategory) -- Use 'General' if not a left hand navigation link
	8805,						                -- Priority must be unique for the selected CategoryName this link is for
	0,						                    -- Set to 0 if to be used as a Suggestion/Related Link
	0,						                    -- Set to 1 if it is a second level Root link
	'HomePageMenuLoggedIn',	                    -- Context Name (Context) -- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',						                    -- Populate only if adding a new ContextName, or updating description
	1						                    -- Theme this link is added for, use 1 as default

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 9999
SET @ScriptDesc = 'Added left menu for logeded in page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
