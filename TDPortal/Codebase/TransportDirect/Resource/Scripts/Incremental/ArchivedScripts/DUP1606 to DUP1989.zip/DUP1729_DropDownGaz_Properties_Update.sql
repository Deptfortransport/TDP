-- ***********************************************
-- NAME 		: DUP1729_DropDownGaz_Properties_Update.sql
-- DESCRIPTION 	: Script to update properties for DropDownGaz
-- AUTHOR		: Mitesh Modi
-- DATE			: 05 July 2010
-- ************************************************

-- ******************* NOTE *************************************************** 
-- PLEASE UPDATE THE @WebWorkerProcessesCount VALUE TO BE EQUAL TO THE NUMBER OF 
-- ONLINE WEB SERVER WORKER PROCESSES CURRENTLY BEING USED e.g. for 
--		Dev	   = 1 
--		SITest = 4 (2 web servers with 2 worker processes on each)
--		DRTest = 1
--		ACP	   = 8 (4 web servers with 2 worker processes on each)
-- ***************************************************************************


USE [PermanentPortal]
GO

DECLARE @WebWorkerProcessesCount int

-- Update number of web servers to be correct for environment
SET @WebWorkerProcessesCount = 1


-- Delete existing property because renaming to provide a more relevant name to what the property represents
IF exists (select top 1 * from properties where pName = 'DropDownGaz.WebServers.Count' and ThemeId = 1)
BEGIN
	delete properties where pName = 'DropDownGaz.WebServers.Count'
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.WebServer.WorkerProcesses.Count' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.WebServer.WorkerProcesses.Count', @WebWorkerProcessesCount, 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = @WebWorkerProcessesCount
	where pname = 'DropDownGaz.WebServer.WorkerProcesses.Count' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Characters.Minimum' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Characters.Minimum', '2', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '2'
	where pname = 'DropDownGaz.Characters.Minimum' and ThemeId = 1
END


GO


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1729
SET @ScriptDesc = 'Script to update properties for DropDownGaz'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO