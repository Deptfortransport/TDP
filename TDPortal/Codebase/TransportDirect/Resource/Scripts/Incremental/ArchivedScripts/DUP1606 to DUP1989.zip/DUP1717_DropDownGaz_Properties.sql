-- ***********************************************
-- NAME 		: DUP1717_DropDownGaz_Properties.sql
-- DESCRIPTION 	: Script to add properties for DropDownGaz
-- AUTHOR		: Amit Patel
-- DATE			: 04 Jun 2010
-- ************************************************

-- ******************* NOTE *************************************************** 
-- PLEASE UPDATE THE @WebServerCount VALUE TO BE EQUAL TO THE NUMBER OF 
-- WEB SERVERS WORKER PROCESSES CURRENTLY BEING USED e.g. for 
--		Dev	   = 1 
--		SITest = 2
--		DRTest = 1
--		ACP	   = 8 (4 web servers with 2 worker processes on each)
-- ***************************************************************************


USE [PermanentPortal]
GO

DECLARE @WebServerCount int

-- Update number of web servers to be correct for environment
SET @WebServerCount = 1


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Available' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Available', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'DropDownGaz.Available' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.FindTrainInput.Available' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.FindTrainInput.Available', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'DropDownGaz.FindTrainInput.Available' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.FindTrainCostInput.Available' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.FindTrainCostInput.Available', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'DropDownGaz.FindTrainCostInput.Available' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Rail.Data.Filename' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Rail.Data.Filename', 'RailStations_{0}_{1}', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'RailStations_{0}_{1}'
	where pname = 'DropDownGaz.Rail.Data.Filename' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Rail.Data.Fileparts' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Rail.Data.Fileparts', '3', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '3'
	where pname = 'DropDownGaz.Rail.Data.Fileparts' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Data.NumberOfVersionsToRetain' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Data.NumberOfVersionsToRetain', '3', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '3'
	where pname = 'DropDownGaz.Data.NumberOfVersionsToRetain' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Characters.Minimum' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Characters.Minimum', '1', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '1'
	where pname = 'DropDownGaz.Characters.Minimum' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.ShowNumberOfStations.Maximum' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.ShowNumberOfStations.Maximum', '20', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '20'
	where pname = 'DropDownGaz.ShowNumberOfStations.Maximum' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'DropDownGaz.WebServers.Count' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.WebServers.Count', @WebServerCount, 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = @WebServerCount
	where pname = 'DropDownGaz.WebServers.Count' and ThemeId = 1
END



-- TNG Monitoring alert strings (for both Web, and 
IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Alert.TNGMonitoring' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring', 'DDGAZ ERROR {0} ', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring', 'DDGAZ ERROR {0} ', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'DDGAZ ERROR {0} '
	where pname = 'DropDownGaz.Alert.TNGMonitoring' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Alert.TNGMonitoring.DataImportFailed' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring.DataImportFailed', 'DATA IMPORT FAILED', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring.DataImportFailed', 'DATA IMPORT FAILED', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'DATA IMPORT FAILED'
	where pname = 'DropDownGaz.Alert.TNGMonitoring.DataImportFailed' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Alert.TNGMonitoring.DataFileCreateFailed' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring.DataFileCreateFailed', 'DATA FILE CREATE FAILED', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring.DataFileCreateFailed', 'DATA FILE CREATE FAILED', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'DATA FILE CREATE FAILED'
	where pname = 'DropDownGaz.Alert.TNGMonitoring.DataFileCreateFailed' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'DropDownGaz.Alert.TNGMonitoring.DataFileMissing' and ThemeId = 1)
BEGIN
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring.DataFileMissing', 'DATA FILE MISSING', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('DropDownGaz.Alert.TNGMonitoring.DataFileMissing', 'DATA FILE MISSING', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'DATA FILE MISSING'
	where pname = 'DropDownGaz.Alert.TNGMonitoring.DataFileMissing' and ThemeId = 1
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1717
SET @ScriptDesc = 'Script to add properties for DropDownGaz'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO