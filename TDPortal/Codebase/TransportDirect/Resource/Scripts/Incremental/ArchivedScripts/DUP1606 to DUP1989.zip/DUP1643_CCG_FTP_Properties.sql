-- ***********************************************
-- NAME 		: DUP1643_CCG_FTP_Properties.sql
-- DESCRIPTION 	: Script to add CCG FTP Properties to FTP_Configuration table
-- DESCRIPTION 	: and IMPORT_Configuration table
-- AUTHOR		: Neil Rankin
-- DATE			: 30 March 2010
-- ************************************************

USE [PermanentPortal]
GO

---------------------------------------------------------------
-- Add CCG FTP Properties to FTP_Configuration table
---------------------------------------------------------------

IF not exists (select top 1 * from FTP_CONFIGURATION where DATA_FEED = 'sfa247')
BEGIN
	insert into FTP_CONFIGURATION values ('1', 'sfa247', 'LocalHost', 'TDP28Nov', 'sI1732#3-', 'D:/Gateway/dat/Incoming/sfa247', '/sfa247', '*.zip', 0, 1, '2003-01-01 00:00:00.000', '', 1)
END
GO
---------------------------------------------------------------
-- Add CCG FTP Properties to IMPORT_Configuration table
---------------------------------------------------------------

IF not exists (select top 1 * from IMPORT_CONFIGURATION where DATA_FEED = 'sfa247' and IMPORT_CLASS = 'TransportDirect.Datagateway.Framework.FileCopyTask')
BEGIN
	insert into IMPORT_CONFIGURATION values ('sfa247', 'TransportDirect.Datagateway.Framework.CommandLineImporter', 'D:/Gateway/bin/td.datagateway.framework.dll', 'D:/Gateway/bat/CCG_import.bat', '', '', 'D:/Gateway/dat/Processing/sfa247')
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1643
SET @ScriptDesc = 'Script to add CCG FTP Properties to FTP_Configuration table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO