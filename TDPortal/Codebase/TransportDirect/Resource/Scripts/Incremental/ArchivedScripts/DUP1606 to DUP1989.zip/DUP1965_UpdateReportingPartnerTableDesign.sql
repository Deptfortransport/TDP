-- ***********************************************
-- NAME           : DUP1965_UpdateReportingPartnerTableDesign
-- DESCRIPTION    : Script to modify Partner Table Design to add printing option
-- DATE           : 11/01/2013
-- Author         : P Scott
-- ***********************************************



USE [Reporting]
GO


      ALTER TABLE [Reporting].[dbo].[Partner] ADD Printable VARCHAR(1)
      




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1965
SET @ScriptDesc = 'DUP1965_UpdateReportingPartnerTableDesign'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

