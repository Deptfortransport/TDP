-- ***********************************************
-- NAME 		: DUP1978_JourneyPlanRequestEvent_ReportStaging_StoredProcedures.sql
-- DESCRIPTION 	: Updated AddJourneyPlanRequestEvent with mode Telecabine
-- AUTHOR		: Mitesh Modi
-- DATE			: 22 Jan 13
-- ************************************************

USE [ReportStagingDB]
GO

----------------------------------------------------------------
-- Create [AddJourneyPlanRequestEvent] stored proc, it should already exist
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddJourneyPlanRequestEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddJourneyPlanRequestEvent
		AS
		BEGIN 
			SET NOCOUNT ON 
		END
		')

END
GO

----------------------------------------------------------------
-- Update [AddJourneyPlanRequestEvent] stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[AddJourneyPlanRequestEvent] (
	@JourneyPlanRequestId varchar(50), 
	@Air bit, @Bus bit, @Car bit, @Coach bit, 
	@Cycle bit, @Drt bit, @Ferry bit, @Metro bit, 
	@Rail bit, @Taxi bit, @Telecabine bit,
	@Tram bit, @Underground bit, @Walk bit, 
	@SessionId varchar(50), @UserLoggedOn bit, @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into JourneyPlanRequestEvent Table'

    Insert into JourneyPlanRequestEvent (JourneyPlanRequestId, Air, Bus, Car, Coach, Cycle, Drt, Ferry, Metro, Rail, Taxi, Telecabine, Tram, Underground, Walk, SessionId, UserLoggedOn, TimeLogged)
    Values (@JourneyPlanRequestId, @Air, @Bus, @Car, @Coach, @Cycle, @Drt, @Ferry, @Metro, @Rail, @Taxi, @Telecabine, @Tram, @Underground, @Walk, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- Grant permissions - will only work for relevant users as only they
-- will exist
GRANT  EXECUTE  ON [dbo].[AddJourneyPlanRequestEvent]  TO [BBPTDPSIW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddJourneyPlanRequestEvent]  TO [BBPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddJourneyPlanRequestEvent]  TO [ACPTDPW\aspuser]
GRANT  EXECUTE  ON [dbo].[AddJourneyPlanRequestEvent]  TO [BBPTDPSIS\aspuser]
GRANT  EXECUTE  ON [dbo].[AddJourneyPlanRequestEvent]  TO [BBPTDPS\aspuser]
GRANT  EXECUTE  ON [dbo].[AddJourneyPlanRequestEvent]  TO [ACPTDPS\aspuser]

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1978
SET @ScriptDesc = 'Updated AddJourneyPlanRequestEvent with mode Telecabine'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO