-- ***********************************************
-- NAME 		: DUP1908_LocationSuggest_Properties.sql
-- DESCRIPTION 	: Script to add properties for Location AutoSuggest functionality
-- AUTHOR		: Mitesh Modi
-- DATE			: 06 Aug 2012
-- ************************************************

USE [PermanentPortal]
GO

-- Clear all existing properties
DELETE FROM [dbo].[properties]
WHERE  pName LIKE '%LocationSuggest.%'

DELETE FROM [dbo].[properties]
WHERE  pName LIKE 'LocationService.Cache.%'

-- AID and GID
DECLARE @AID_Web varchar(50) = 'Web'
DECLARE @GID_UPortal varchar(50) = 'UserPortal'

-- Location Suggest properties
INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.ScriptPath', '~/Scripts/TempScripts/', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.Script.Name.Default', 'Location_', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.Script.Name.FromToDrop', 'Location_', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.Script.Name.PTViaDrop', 'Location_NoGroupsNoLocalities_', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.Script.Name.FindCarLocationDrop', 'Location_NoGroups_', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.Script.Name.CarViaDrop', 'Location_NoGroups_', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.Script.Name.FindCycleLocationDrop', 'Location_NoGroups_', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('ScriptRepository.LocationSuggest.Script.Name.CycleViaLocationDrop', 'Location_NoGroups_', @AID_Web, @GID_UPortal, 0, 1)

-- Location Service - Cache 
INSERT INTO [properties] VALUES ('LocationService.Cache.LoadLocations', 'true', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('LocationService.Cache.LocationsVersionStoredProcedure', 'GetLocationsVersion', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('LocationService.Cache.LocationsDatabase', 'AtosAdditionalDataDB', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.LocationsStoredProcedure', 'GetLocations', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.LocationStoredProcedure', 'GetLocation', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.LocationUnknownStoredProcedure', 'GetUnknownLocation', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.LocationsAlternateStoredProcedure', 'GetAlternativeSuggestionList', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocations.InCache', 'true', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsLimit.Count.Max', '1000', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsShow.Count.Max', '20', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsShow.GroupStationsLimit.Count', '100', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsShow.RailStationsLimit.Count', '5', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsShow.CoachStationsLimit.Count', '2', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsShow.TramStationsLimit.Count', '5', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsShow.FerryStationsLimit.Count', '100', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SearchLocationsShow.AirportStationsLimit.Count', '100', @AID_Web, @GID_UPortal, 0, 1)

INSERT INTO [properties] VALUES ('LocationService.Cache.CommonWords', 'rail,station,stations,bus,airport,terminal,Coach,tramway,tramlink,dlr,subway,spt,steam,rly,underground,metrolink,tram,rhdr,supertram,metro', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SimilarityIndex.NoCommonWords.Min', '0.5', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SimilarityIndex.NoCommonWordsAndSpace.Min', '0.5', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SimilarityIndex.IndividualWords.Min', '0.65', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('LocationService.Cache.SimilarityIndex.ChildLocalityAtEnd', 'true', @AID_Web, @GID_UPortal, 0, 1)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1908
SET @ScriptDesc = 'Script to add properties for Location AutoSuggest functionality'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO