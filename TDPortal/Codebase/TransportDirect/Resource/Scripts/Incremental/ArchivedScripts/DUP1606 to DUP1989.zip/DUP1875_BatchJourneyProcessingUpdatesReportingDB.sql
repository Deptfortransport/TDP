-- ***********************************************
-- NAME          : DUP1875_BatchJourneyProcessingUpdatesReporting.sql
-- DESCRIPTION   : Script to update the Reporting.Partner table
-- AUTHOR        : David Lane
-- DATE          : 23 February 2012
-- ************************************************


USE Reporting

IF NOT EXISTS (SELECT TOP 1 * FROM Partner WHERE PartnerId = 300)
BEGIN
INSERT INTO [Reporting].[dbo].[Partner]
           ([PartnerId]
           ,[HostName]
           ,[PartnerName]
           ,[Channel])
     VALUES
           (300
           ,'BatchJourneyPlanner'
           ,'BatchJourneyPlanner'
           ,'BatchJourneyPlanner')
END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1875
SET @ScriptDesc = 'Batch Journey Processing Updates ReportingDB'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO