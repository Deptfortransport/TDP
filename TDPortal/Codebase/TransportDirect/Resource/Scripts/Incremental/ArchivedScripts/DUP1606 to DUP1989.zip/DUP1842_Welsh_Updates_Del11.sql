-- ***********************************************
-- NAME           : DUP1842_Welsh_Updates_Del11.sql
-- DESCRIPTION    : Script to add/update Welsh content
-- AUTHOR         : Rhys Godber
-- DATE           : 10 Oct 2011
-- ***********************************************

USE [Content] 


EXEC AddtblContent
1, 1,'langStrings','CarCostingDetials.highTrafficSymbol' 
,'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.jpg" align="middle" alt="Road queue sign" />' 
,'<img src="/Web2/App_Themes/TransportDirect/images/gifs/Misc/roadqueue.jpg" align="middle" alt="Arwydd ciw ar y ffordd" />' 

EXEC AddtblContent
1, 1 ,'langStrings','TravelNewsIncidentPopupControl.RoadIncident.Image.ToolTip' 
,'Click for incident details' 
,'Cliciwch er mwyn cael manylion am y digwyddiad'

EXEC AddtblContent
1, 1,'langStrings','TravelNewsIncidentPopupControl.RoadIncident.PlannedIncident.Title' 
,'RoadWorks' 
,'Gwaith ar y ffordd' 

EXEC AddtblContent
1, 1,'langStrings','TravelNewsIncidentPopupControl.RoadIncident.PlannedIncident.Image.AlternateText' 
,'Planned Incident' 
,'Digwyddiad wedi ei gynllunio' 

EXEC AddtblContent
1, 1,'langStrings','TravelNewsIncidentPopupControl.RoadIncident.PlannedIncident.Image.ToolTip' 
,'Roadworks may impact your journey here' 
,'Gallai gwaith ffordd effeithio ar eich taith yma' 

EXEC AddtblContent
1, 1,'langStrings','TravelNewsIncidentPopupControl.RoadIncident.UnplannedIncident.Title' 
,'RoadIncident' 
,'Digwyddiad ar y ffordd' 

EXEC AddtblContent
1, 1,'langStrings','TravelNewsIncidentPopupControl.RoadIncident.UnplannedIncident.Image.AlternateText' 
,'Unplanned Incident' 
,'Digwyddiad heb ei gynllunio' 

EXEC AddtblContent
1, 1,'langStrings','TravelNewsIncidentPopupControl.RoadIncident.UnplannedIncident.Image.ToolTip' 
,'Road incident may impact your journey here' 
,'Gallai digwyddiad ar y ffordd effeithio ar eich taith yma' 

EXEC AddtblContent
1, 1,'langStrings','CarAllDetailsControl.AvoidClosedRoadsMessage.Text' 
,'There are closed roads on your planned journey.' 
,'Mae ffyrdd wedi cau ar y daith yr ydych wedi ei chyynllunio'

EXEC AddtblContent
1, 1,'langStrings','CarAllDetailsControl.ReplanAvoidClosedRoads.Text' 
,'Click here to replan to avoid closures' 
,'Cliciwch yma i ailgynllunio er mwyn osgoi ffyrdd sydd wedi cau' 

EXEC AddtblContent
1, 1,'langStrings','ValidateAndRun.RouteAffectedByClosures'
,'Sorry all journeys on this route are affected by road closures' 
,'Ymddiheurwn - mae ffyrdd wedi cau yn effeithio ar bob taith ar y llwybr hwn' 

EXEC AddtblContent
1, 1,'langStrings','JourneyPlannerOutput.JourneyWebNoRoadResultsForAvoidToids' 
,'Sorry all journeys on this route are affected by road closures' 
,'Ymddiheurwn - mae ffyrdd wedi cau yn effeithio ar bob taith ar y llwybr hwn'

EXEC AddtblContent
1, 1,'langStrings','CarJourneyDetailsControl.highTrafficSymbol.ToolTip' 
,'High traffic levels likely on this road' 
,'Lefalau traffig uchel yn debygol ar y ffordd hon' 

EXEC AddtblContent
1, 1,'langStrings','CarJourneyDetailsControl.highTrafficSymbol.PopupTitle'
,'High traffic levels' 
,'Lefalau traffig uchel' 

EXEC AddtblContent
1, 1,'langStrings','CarJourneyDetailsControl.highTrafficSymbol.PopupContent' 
,'High traffic levels likely on this road, see map of the journey.' 
,'Lefalau traffig uchel yn debygol ar y ffordd hon, gweler map o''r daith' 

EXEC AddtblContent
1, 1,'langStrings','CarJourneyTypeControl.JourneyType.AvoidClosedRoads.Text' 
,'{0} journey for a {1} sized {2} car avoiding closed roads' 
,'Taith {0} ar gyfer car {1} {2} gan osgoi ffyrdd wedi cau' 



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1842
SET @ScriptDesc = 'Script to add/update Welsh content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO