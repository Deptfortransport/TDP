-- ***********************************************
-- NAME 		: DUP1756_DisplayableRailTickets_Properties_Update.sql
-- DESCRIPTION 	: Script to update 'DisplayableRailTickets' dataservices property
-- AUTHOR		: Amit Patel
-- DATE			: 30 Sep 2008
-- ************************************************

USE [PermanentPortal]
GO

-- Microsite
IF not exists (
	select top 1 * from properties 
	where pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query' 
		and AID = 'Microsite' 
		and GID = '' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query', 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''', 'Microsite', '', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets'''
	where pname = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query'
	and AID = 'Microsite' 
	and GID = '' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- tdRemotingHost
IF not exists (
	select top 1 * from properties 
	where pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query' 
		and AID = 'TDRemotingHost' 
		and GID = 'TDRemotingHost' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query', 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets'''
	where pname = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query'
	and AID = 'TDRemotingHost' 
	and GID = 'TDRemotingHost' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- tdPlannerHost
IF not exists (
	select top 1 * from properties 
	where pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query' 
		and AID = 'TDPlannerHost' 
		and GID = 'TDPlannerHost' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query', 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''', 'TDPlannerHost', 'TDPlannerHost', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets'''
	where pname = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query'
	and AID = 'TDPlannerHost' 
	and GID = 'TDPlannerHost' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web
IF not exists (
	select top 1 * from properties 
	where pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query' 
		and AID = 'Web' 
		and GID = '' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query', 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''', 'Web', '', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'SELECT KeyName, Value, Category, TicketGroup, Data1 FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets'''
	where pname = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query'
	and AID = 'Web' 
	and GID = '' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Query type
IF not exists (
	select top 1 * from properties 
	where pName = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.type' 
		and AID = '<DEFAULT>' 
		and GID = '<DEFAULT>' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.type', '6', '<DEFAULT>', '<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '6'
	where pname = 'TransportDirect.UserPortal.DataServices.DisplayableRailTickets.type'
	and AID = '<DEFAULT>' 
	and GID = '<DEFAULT>' 
	and PartnerId = 0 
	and ThemeId = 1
END




GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1749
SET @ScriptDesc = 'Script to update DisplayableRailTickets dataservices property'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO