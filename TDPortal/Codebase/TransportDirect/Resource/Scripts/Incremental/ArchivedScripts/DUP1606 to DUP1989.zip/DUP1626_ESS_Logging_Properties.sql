-- ***********************************************
-- NAME 		: DUP1626_ESS_Logging_Properties.sql
-- DESCRIPTION 	: Script to add ESS logging properties for Journey Planner
-- AUTHOR		: Amit Patel
-- DATE			: 19 Mar 2010
-- ************************************************


-- *********	WARNING		******

--	In Production publishers for JOURNEYREQUEST and JOURNEYRESULTS should be changed to Queue1

--	In Production publishers for JOURNEYREQUESTVERBOSE and JOURNEYRESULTSVERBOSE should be set to FILE1

-- *******************************


USE [PermanentPortal]
GO


---------------------------------------------------------------------
-- LOGGING PROPERTIES

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom.Trace' 
	and AID = 'EnhancedExposedServices'
	and GID = 'UserPortal'
	and PartnerId = 0
	and ThemeId = 1)
BEGIN
	insert into properties values ('Logging.Event.Custom.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-----------------------------
--  JOURNEYREQUEST
-----------------------------
-- Assembly
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Assembly', 'td.userportal.journeycontrol', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Name
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Name' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Name' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Name', 'JourneyPlanRequestEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Publisher
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Trace
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUEST.Trace' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUEST.Trace' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUEST.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Event list
IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and pValue LIKE '%JOURNEYREQUEST%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' JOURNEYREQUEST'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EnhancedExposedServices')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EnhancedExposedServices'
END

------------------------------
-- JOURNEYREQUESTVERBOSE
------------------------------
-- Assembly
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Assembly', 'td.userportal.journeycontrol', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Name
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Name' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Name' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Name', 'JourneyPlanRequestVerboseEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Publisher
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Trace
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Trace' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Trace' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Event list
IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and pValue LIKE '%JOURNEYREQUESTVERBOSE%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' JOURNEYREQUESTVERBOSE'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EnhancedExposedServices')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EnhancedExposedServices'
END

------------------------------
-- JOURNEYRESULTS
------------------------------

-- Assembly
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Assembly', 'td.userportal.journeycontrol', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Name
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Name' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Name' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Name', 'JourneyPlanResultsEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Publisher
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Trace
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTS.Trace' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTS.Trace' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTS.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Event list
IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and pValue LIKE '%JOURNEYRESULTS%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' JOURNEYRESULTS'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EnhancedExposedServices')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EnhancedExposedServices'
END

------------------------------
-- JOURNEYRESULTSVERBOSE
------------------------------

-- Assembly
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Assembly' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Assembly', 'td.userportal.journeycontrol', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Name
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Name' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Name' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Name', 'JourneyPlanResultsVerboseEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Publisher
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Trace
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Trace' and ThemeId = 1 and AID='EnhancedExposedServices')
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Trace' and ThemeId = 1 and AID='EnhancedExposedServices'
END
BEGIN
	insert into properties values ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Trace', 'On', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END

-- Event list
IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and pValue LIKE '%JOURNEYRESULTSVERBOSE%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' JOURNEYRESULTSVERBOSE'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EnhancedExposedServices')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EnhancedExposedServices'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1625
SET @ScriptDesc = 'ESS logging properties for Journey Planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO