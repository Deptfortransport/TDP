-- *************************************************************************************
-- NAME 		: DUP1782_Update_Retailers_Reporting.sql
-- DESCRIPTION  : Enhancements to reporting tables to reflect that
--			      MTT are being added as a retail partner
-- AUTHOR		: Mark Turner
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Reporting]
GO

---------------------------
-- Add RetailerHandoffType
---------------------------

IF NOT EXISTS (SELECT * FROM [Reporting].[dbo].[RetailerHandoffType] WHERE [RHTCode] ='MTT')
	BEGIN
	INSERT INTO [RetailerHandoffType] values((SELECT Max(RHTID)+1 FROM RetailerHandoffType),'MTT','My Train Ticket',1)
	END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1782
SET @ScriptDesc = 'Update_Retailers_Reporting'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO