-- ***********************************************
-- NAME 		: DUP1815_Discount_Cards_Updates.sql
-- DESCRIPTION 	: Updates to discount cards as requested by D Clegg & Chris P
-- AUTHOR		: Rich Broddle
-- DATE			: 29-07-11
--Updates to discount cards as requested by D Clegg & Chris P:
--Railcards:
--Disabled Adult Railcard - amend to Disabled Persons Railcard
--Family Railcard - amend to Family & Friends Railcard
--Young Persons Railcard - amend to 16-25 Railcard
--Coach Cards:
--National Express Student Coachcard - delete (incorporated in Young Person card)
--National Express Advantage50 Coachcard - delete (apparently obsolete)
-- ************************************************

USE [PermanentPortal]
GO

--Disabled Adult Railcard - amend to Disabled Persons Railcard
UPDATE [PermanentPortal].[dbo].[DiscountCards]
   SET [ResourceId] = 'Disabled Persons Railcard'
 WHERE [ResourceId] = 'Disabled Adult Railcard'
 
 --Family Railcard - amend to Family & Friends Railcard
UPDATE [PermanentPortal].[dbo].[DiscountCards]
   SET [ResourceId] = 'Family & Friends Railcard'
 WHERE [ResourceId] = 'Family Railcard'
 
  --Young Persons Railcard - amend to 16-25 Railcard
UPDATE [PermanentPortal].[dbo].[DiscountCards]
   SET [ResourceId] = '16-25 Railcard'
 WHERE [ResourceId] = 'Young Persons Railcard'
 
--National Express Student Coachcard - delete (incorporated in Young Person card)
--National Express Advantage50 Coachcard - delete (apparently obsolete)
DELETE [PermanentPortal].[dbo].[DiscountCards] 
WHERE [ResourceId] 
IN ('National Express Student Coachcard','National Express Advantage50 Coachcard')

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1815
SET @ScriptDesc = 'Updates to discount cards as requested by D Clegg & Chris P'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
