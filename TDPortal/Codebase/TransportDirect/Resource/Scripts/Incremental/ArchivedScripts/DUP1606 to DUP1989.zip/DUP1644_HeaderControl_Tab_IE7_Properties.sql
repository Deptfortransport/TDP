-- ***********************************************
-- NAME 		: DUP1644_HeaderControl_Tab_IE7_Properties.sql
-- DESCRIPTION 	: Script to add property to check if IE specific tab should display
-- AUTHOR		: Amit Patel
-- DATE			: 06 Apr 2010
-- ************************************************

USE [PermanentPortal]
GO

---------------------------------------------------------------------------------------------------------
-- TransportDirect
---------------------------------------------------------------------------------------------------------

-- for horizontal tab menu

IF not exists (select top 1 * from properties where pName = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 1)
BEGIN
	insert into properties values ('HeaderControl.CheckBrowser.IE7.TabVisible', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 1
END

-- for the header logo link
IF not exists (select top 1 * from properties where pName = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 1)
BEGIN
	insert into properties values ('HeaderControl.Homepage.IE7.LogoVisible', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 1
END

---------------------------------------------------------------------------------------------------------
-- DirectGov Theme: 5
---------------------------------------------------------------------------------------------------------

-- for horizontal tab menu

IF not exists (select top 1 * from properties where pName = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 5)
BEGIN
	insert into properties values ('HeaderControl.CheckBrowser.IE7.TabVisible', 'false', 'Web', 'UserPortal', 0, 5)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 5
END

-- for the header logo link
IF not exists (select top 1 * from properties where pName = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 5)
BEGIN
	insert into properties values ('HeaderControl.Homepage.IE7.LogoVisible', 'true', 'Web', 'UserPortal', 0, 5)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 5
END

---------------------------------------------------------------------------------------------------------
-- BBC Theme: 3
---------------------------------------------------------------------------------------------------------

-- for horizontal tab menu

IF not exists (select top 1 * from properties where pName = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 3)
BEGIN
	insert into properties values ('HeaderControl.CheckBrowser.IE7.TabVisible', 'false', 'Web', 'UserPortal', 0, 3)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 3
END

-- for the header logo link
IF not exists (select top 1 * from properties where pName = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 3)
BEGIN
	insert into properties values ('HeaderControl.Homepage.IE7.LogoVisible', 'true', 'Web', 'UserPortal', 0, 3)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 3
END

---------------------------------------------------------------------------------------------------------
-- VisitBritain Theme: 2
---------------------------------------------------------------------------------------------------------

-- for horizontal tab menu

IF not exists (select top 1 * from properties where pName = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 2)
BEGIN
	insert into properties values ('HeaderControl.CheckBrowser.IE7.TabVisible', 'true', 'Web', 'UserPortal', 0, 2)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 2
END

-- for the header logo link
IF not exists (select top 1 * from properties where pName = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 2)
BEGIN
	insert into properties values ('HeaderControl.Homepage.IE7.LogoVisible', 'true', 'Web', 'UserPortal', 0, 2)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 2
END

---------------------------------------------------------------------------------------------------------
-- BusinessLink Theme: 6
---------------------------------------------------------------------------------------------------------

-- for horizontal tab menu

IF not exists (select top 1 * from properties where pName = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 6)
BEGIN
	insert into properties values ('HeaderControl.CheckBrowser.IE7.TabVisible', 'false', 'Web', 'UserPortal', 0, 6)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 6
END

-- for the header logo link
IF not exists (select top 1 * from properties where pName = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 6)
BEGIN
	insert into properties values ('HeaderControl.Homepage.IE7.LogoVisible', 'true', 'Web', 'UserPortal', 0, 6)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 6
END

---------------------------------------------------------------------------------------------------------
-- BusinessGateway Theme: 7
---------------------------------------------------------------------------------------------------------

-- for horizontal tab menu

IF not exists (select top 1 * from properties where pName = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 7)
BEGIN
	insert into properties values ('HeaderControl.CheckBrowser.IE7.TabVisible', 'false', 'Web', 'UserPortal', 0, 7)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'false'
	where pname = 'HeaderControl.CheckBrowser.IE7.TabVisible' and ThemeId = 7
END

-- for the header logo link
IF not exists (select top 1 * from properties where pName = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 7)
BEGIN
	insert into properties values ('HeaderControl.Homepage.IE7.LogoVisible', 'true', 'Web', 'UserPortal', 0, 7)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'HeaderControl.Homepage.IE7.LogoVisible' and ThemeId = 7
END




GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1644
SET @ScriptDesc = 'Script to add property to check if IE specific tab should display'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO