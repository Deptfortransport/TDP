-- ***********************************************
-- NAME          : DUP1859_CoachFares_ChildFares_Properties.sql
-- DESCRIPTION   : Script to add propertys for Child Fare age ranges
-- AUTHOR        : Mark Turner
-- DATE          : 30 Nov 2011
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'PricingRetail.CoachFares.ChildAgeMin')
BEGIN
	INSERT INTO properties VALUES ('PricingRetail.CoachFares.ChildAgeMin', '3', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '3'
	where pname = 'PricingRetail.CoachFares.ChildAgeMin'
END

IF not exists (select top 1 * from properties where pName = 'PricingRetail.CoachFares.ChildAgeMax')
BEGIN
	INSERT INTO properties VALUES ('PricingRetail.CoachFares.ChildAgeMax', '15', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '15'
	where pname = 'PricingRetail.CoachFares.ChildAgeMax'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1859
SET @ScriptDesc = 'Script to add propertys for Child Fare age ranges'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO