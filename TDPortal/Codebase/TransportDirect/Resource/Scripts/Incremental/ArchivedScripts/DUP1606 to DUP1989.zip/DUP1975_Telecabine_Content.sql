-- ***********************************************
-- NAME 		: DUP1975_Telecabine_Content.sql
-- DESCRIPTION 	: Telecabine content
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Jan 13
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'DataServices.PublicTransportsCheck.Telecabine',
	'Cable car (within London only)',
	'Car cebl (within London only)'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'JourneyPlannerAmbiguity.labelTelecabine',
	'Cable car',
	'Cable car'

EXEC AddtblContent
	1, 1, 'langStrings', 'JourneyDetailsControl.imageTelecabineUrl',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/telecabine.png',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/telecabine.png'

EXEC AddtblContent
	1, 1, 'langStrings', 'TransportMode.Telecabine.ImageAlternateText',
	'Cable car',
	'Car cebl'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'TransportMode.Telecabine',
	'Cable car',
	'Car cebl'
EXEC AddtblContent
	1, 1, 'JourneyResults', 'TransportMode.Telecabine',
	'Cable car',
	'Car cebl'
EXEC AddtblContent
	1, 1, 'FaresAndTickets', 'TransportMode.Telecabine',
	'Cable car',
	'Car cebl'
EXEC AddtblContent
	1, 1, 'JourneyPlannerService', 'TransportMode.Telecabine',
	'Cable car',
	'Car cebl'

EXEC AddtblContent
	1, 1, 'langStrings', 'TransportModeLowerCase.Telecabine',
	'cable car',
	'car cebl'
EXEC AddtblContent
	1, 1, 'JourneyResults', 'TransportModeLowerCase.Telecabine',
	'cable car',
	'car cebl'
	
EXEC AddtblContent
	1, 1, 'VisitPlanner', 'TransportModesControl.imageTelecabineAltText',
	'Travel by cable car',
	'Teithio mewn car cebl'
EXEC AddtblContent
	1, 1, 'VisitPlanner', 'TransportModesControl.imageTelecabineURL',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/telecabine_sm.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/telecabine_sm.gif'
	

EXEC AddtblContent
	1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.Public',
	'Rail,Coach,Bus,Metro,Tram,Taxi,Air,Ferry,Telecabine,Walk,StartLocation,EndLocation,Change',
	'Rail,Coach,Bus,Metro,Tram,Taxi,Air,Ferry,Telecabine,Walk,StartLocation,EndLocation,Change'

EXEC AddtblContent
	1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.SpecificModes.Telecabine',
	'Telecabine',
	'Telecabine'

EXEC AddtblContent
	1, 1, 'langStrings', 'MapKeyControl.labelTelecabine',
	'Cable car',
	'Car cebl'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'MapKeyControl.labelTelecabine.Print',
	'Cable car',
	'Car cebl'

EXEC AddtblContent
	1, 1, 'langStrings', 'MapKeyControl.imageTelecabine',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/TelecabineKey.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/TelecabineKey.gif'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'MapKeyControl.imageTelecabine.Print',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/TelecabineKeyPrint.gif',
	'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/TelecabineKeyPrint.gif'
	
EXEC AddtblContent
	1, 1, 'langStrings', 'MapKeyControl.imageTelecabine.AlternateText',
	'Key for Cable car',
	'Bysell ar gyfer Car cebl '
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1975
SET @ScriptDesc = 'Telecabine content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO