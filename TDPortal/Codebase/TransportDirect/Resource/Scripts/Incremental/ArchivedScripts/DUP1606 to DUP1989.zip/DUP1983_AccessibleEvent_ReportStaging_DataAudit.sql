-- ***********************************************
-- NAME 		: DUP1983_AccessibleEvent_ReportStaging_DataAudit.sql
-- DESCRIPTION 	: Added report staging data audit entries for AccessibleEvents
-- AUTHOR		: David Lane
-- DATE			: 18 Jan 2013
-- ************************************************

USE [ReportStagingDB]
GO

-- Add new data types for reporting

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataType] 
WHERE [RSDTName] = 'TransferAccessibleEvents') 
	INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataType] ([RSDTID],[RSDTName])
		 VALUES (37,'TransferAccessibleEvents')
GO

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataAudit]
WHERE [RSDTID] = 37) 
	BEGIN
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (37,1,'20130101 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (37,2,'20130101 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (37,3,'20130101 01:00:00')
	END
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1983
SET @ScriptDesc = 'Added report staging data audit entries for AccessibleEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO