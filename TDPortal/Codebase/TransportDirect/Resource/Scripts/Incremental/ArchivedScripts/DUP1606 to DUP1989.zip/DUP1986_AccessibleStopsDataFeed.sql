-- ***********************************************
-- NAME 		: DUP1986_AccessibleStopsDataFeed.sql
-- DESCRIPTION 	: Accessibility stops data feed
-- AUTHOR		: David Lane
-- DATE			: 24 Dec 2013
-- ************************************************


-- NOTE - this script targets C:\Gateway (x4), this may need to be changed
-- to suit the target environment


USE PermanentPortal

IF EXISTS (SELECT 1 FROM PermanentPortal..FTP_CONFIGURATION WHERE DATA_FEED = 'iwa258')
BEGIN
	DELETE FROM PermanentPortal..FTP_CONFIGURATION WHERE DATA_FEED = 'iwa258'
END

INSERT INTO [PermanentPortal].[dbo].[FTP_CONFIGURATION]
           ([FTP_CLIENT]
           ,[DATA_FEED]
           ,[IP_ADDRESS]
           ,[USERNAME]
           ,[PASSWORD]
           ,[LOCAL_DIR]
           ,[REMOTE_DIR]
           ,[FILENAME_FILTER]
           ,[MISSING_FEED_COUNTER]
           ,[MISSING_FEED_THRESHOLD]
           ,[DATA_FEED_DATETIME]
           ,[DATA_FEED_FILENAME]
           ,[REMOVE_FILES])
     VALUES
           (1
           ,'iwa258'
           ,'localhost'
           ,'TDP28Nov'
           ,'sI1732#3-'
           ,'C:/Gateway/dat/Incoming/iwa258'
           ,'../iwa258'
           ,'*.zip'
           ,0
           ,1
           ,'1900-01-01 00:00:00.000'
           ,''
           ,1)
GO

IF EXISTS (SELECT 1 FROM PermanentPortal..IMPORT_CONFIGURATION WHERE DATA_FEED = 'iwa258')
BEGIN
	DELETE FROM PermanentPortal..IMPORT_CONFIGURATION WHERE DATA_FEED = 'iwa258'
END

INSERT INTO [PermanentPortal].[dbo].[IMPORT_CONFIGURATION]
           ([DATA_FEED]
           ,[IMPORT_CLASS]
           ,[CLASS_ARCHIVE]
           ,[IMPORT_UTILITY]
           ,[PARAMETERS1]
           ,[PARAMETERS2]
           ,[PROCESSING_DIR])
     VALUES
           ('iwa258'
           ,'TransportDirect.Datagateway.Framework.CommandLineImporter'
           ,'C:/Gateway/bin/td.datagateway.framework.dll'
           ,'C:/Gateway/bat/AccessibleStopsData.bat' 
           ,'' 
           ,'' 
           ,'C:/Gateway/dat/Processing/iwa258')
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1986
SET @ScriptDesc = 'Accessibile stops data feed'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO