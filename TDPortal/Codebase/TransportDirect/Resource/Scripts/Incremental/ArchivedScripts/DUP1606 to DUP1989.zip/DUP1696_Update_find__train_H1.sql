-- ***********************************************
-- NAME 		: DUP1696_Update_find__train_H1
-- DESCRIPTION 		: Update content for Search Engine Optimisation
-- AUTHOR		: Phil Scott
-- DATE			:30/04/2010
-- ************************************************

USE [Content]
GO




-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainInput.labelFindTrainTitle',
'Train times &amp; routes',
'Llwybrau ac amserlenni trenau'
Go 


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1696
SET @ScriptDesc = 'Update content for Search Engine Optimisation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO