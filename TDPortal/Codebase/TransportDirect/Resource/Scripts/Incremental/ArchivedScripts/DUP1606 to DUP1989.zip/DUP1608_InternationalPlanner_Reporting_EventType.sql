-- ***********************************************
-- NAME 		: DUP1608_InternationalPlanner_Reporting_EventType.sql
-- DESCRIPTION 	: Added InternationalPlannerType entry for 'ExtendInDoorToDoor'
-- AUTHOR		: Rich Broddle
-- DATE			: 09 March 2010
-- ************************************************


USE [Reporting]
GO

-- Add new page entries for reporting
IF NOT EXISTS(SELECT * FROM [Reporting].[dbo].[InternationalPlannerType] WHERE [IPTID] = 0) 

INSERT INTO [Reporting].[dbo].[InternationalPlannerType]
           ([IPTID]
           ,[IPTCode]
           ,[IPTDescription])
     VALUES
           (0,
           'ExtendInDoorToDoor'
           ,'ExtendInDoorToDoor')
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1608
SET @ScriptDesc = 'Added InternationalPlannerType entry for ExtendInDoorToDoor'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO