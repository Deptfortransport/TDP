-- ***********************************************
-- NAME 		: DUP1897_NX_Route60_Fare_Obsolescence.sql
-- DESCRIPTION  : Change to CoachFares.NationalExpress.Route60.AppendString to indicate
--                that these fares are no longer available, pending removal by NX.
-- AUTHOR		: Rich Broddle
-- DATE			: 17 July 2012
-- ************************************************

USE [PermanentPortal]
GO

IF not exists ( select top 1 * from properties 
	where pName = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'Web')
BEGIN
	insert into properties values ('CoachFares.NationalExpress.Route60.AppendString',
				'Route 60 (Sorry � not available) - ','Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Route 60 (Sorry � not available) - ' 
		where pname = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'Web'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('CoachFares.NationalExpress.Route60.AppendString',
				'Route 60 (Sorry � not available) - ','TDRemotingHost', 'TDRemotingHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Route 60 (Sorry � not available) - ' 
		where pname = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDRemotingHost'
END

IF not exists ( select top 1 * from properties 
	where pName = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDPlannerHost')
BEGIN
	insert into properties values ('CoachFares.NationalExpress.Route60.AppendString',
				'Route 60 (Sorry � not available) - ','TDPlannerHost', 'TDPlannerHost', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Route 60 (Sorry � not available) - ' 
		where pname = 'CoachFares.NationalExpress.Route60.AppendString' AND AID = 'TDPlannerHost'
END


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1897
SET @ScriptDesc = 'Further change to CoachFares.NationalExpress.Route60.AppendString'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO