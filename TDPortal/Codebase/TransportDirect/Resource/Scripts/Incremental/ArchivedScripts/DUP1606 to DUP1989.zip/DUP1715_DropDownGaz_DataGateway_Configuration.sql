-- ***********************************************
-- NAME 		: DUP1715_DropDownGaz_DataGateway_Configuration.sql
-- DESCRIPTION 	: Script to add DropDownGaz Alias feed Import and FTP configuration values for DataGateway properties
-- AUTHOR		: Mitesh Modi
-- DATE			: 07 Jun 2010
-- ************************************************

USE [PermanentPortal]
GO

-- ***************** WARNING ******************
-- Please ensure file path locations are correct for the Gateway folders:
--		@ProcessingPath
--		@IncomingPath
-- *********************************************

DECLARE @FeedName varchar(10)
DECLARE @ProcessingPath varchar(50)
DECLARE @IncomingPath varchar(50)

SET @FeedName = 'avf956'

-- Update paths if required
SET @ProcessingPath = 'C:/Gateway/dat/Processing/'
SET @IncomingPath = 'C:/Gateway/dat/Incoming/'

----------------------------------------
-- UPDATE FEED CONFIGURATION
----------------------------------------

IF EXISTS(SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = @FeedName)
  BEGIN
    DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = @FeedName
  END

INSERT INTO IMPORT_CONFIGURATION(DATA_FEED, IMPORT_CLASS, CLASS_ARCHIVE, IMPORT_UTILITY, PARAMETERS1, PARAMETERS2, PROCESSING_DIR)
VALUES (@FeedName,
		'TransportDirect.UserPortal.LocationService.DropDownLocationProvider.DropDownLocationImporter',
		'td.userportal.locationservice.dll',
		'',
		'',
		'',
		@ProcessingPath + @FeedName)



----------------------------------------
-- UPDATE FTP_CONFIGURATION
----------------------------------------
IF EXISTS (SELECT * FROM [dbo].[ftp_configuration] WHERE data_feed = @FeedName)
  BEGIN
    UPDATE
      [dbo].[ftp_configuration]
    SET
      ftp_client = 1,
      data_feed = @FeedName,
      ip_address = 'LocalHost',
      username = 'TDP28Nov',
      password = 'sI1732#3-',
      local_dir = @IncomingPath + @FeedName,
      remote_dir = '../' + @FeedName,
      filename_filter = '*.zip',
      missing_feed_counter = 0,
      missing_feed_threshold = 1,
      data_feed_datetime = '01/01/2003',
      data_feed_filename = '',
      remove_files = 1      
    WHERE
      data_feed = @FeedName
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ftp_configuration](ftp_client, data_feed, ip_address, username, password, local_dir,
     remote_dir,filename_filter,missing_feed_counter, missing_feed_threshold,data_feed_datetime,
     data_feed_filename,remove_files)
    VALUES (1, 
			@FeedName,
			'LocalHost',
			'TDP28Nov',
			'sI1732#3-',
			@IncomingPath + @FeedName,
			'../' + @FeedName,
			'*.zip',
			0,
			1,
			'01/01/2003',
			'',
			1)
  END
  
  
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1715
SET @ScriptDesc = 'Script to add DataGateway configuration values DropDownGaz'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO