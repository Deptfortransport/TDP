-- ***********************************************
-- NAME 		: DUP1900_SessionDebugLogging_Properties.sql
-- DESCRIPTION 	: Script to add property to for session debug logging, 
--				: to prevent verbose logs from containing too many entries
-- AUTHOR		: Mitesh Modi
-- DATE			: 19 Feb 2012
-- ************************************************

USE [PermanentPortal]
GO

-- Clear all existing properties
DELETE FROM [dbo].[properties]
WHERE  pName LIKE 'Session.Debug.Logging.Switch'

-- Insert new Penalty Function properties for each of the required aid and gid
DECLARE @AID_Web varchar(50) = 'Web'
DECLARE @AID_RHost varchar(50) = 'TDRemotingHost'

DECLARE @GID_UPortal varchar(50) = 'UserPortal'
DECLARE @GID_RHost varchar(50) = 'TDRemotingHost'

INSERT INTO [properties] VALUES ('Session.Debug.Logging.Switch', 'false', @AID_Web, @GID_UPortal, 0, 1)
INSERT INTO [properties] VALUES ('Session.Debug.Logging.Switch', 'false', @AID_RHost, @GID_RHost, 0, 1)


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1900
SET @ScriptDesc = 'Script to add session debug properties switch'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO