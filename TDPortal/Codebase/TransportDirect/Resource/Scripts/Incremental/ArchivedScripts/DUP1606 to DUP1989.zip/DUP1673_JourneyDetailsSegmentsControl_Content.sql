-- ***********************************************
-- NAME 		: DUP1673_JourneyDetailsSegmentsControl_Content.sql
-- DESCRIPTION 	: Script to add content for JourneyDetailsSegments control verticle line image
-- AUTHOR		: Amit Patel
-- DATE			: 09 Apr 2010
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyDetailsSegmentsControl.NodeLine'
,'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/linefill.gif'
,'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/linefill.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyDetailsSegmentsControl.NodeLine.AlternateText'
,'Connecting to'
,'cy Connecting to'


GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1673
SET @ScriptDesc = 'Script to add content for JourneyDetailsSegments control verticle line image'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO