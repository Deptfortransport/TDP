-- ***********************************************
-- NAME 			: DUP1625_JourneyResults_TrunkMode_RelatedLinks_Context.sql
-- DESCRIPTION 		: Script to add the Related link contexts to the Journey result pages for city to city journey
-- AUTHOR			: Amit Patel
-- DATE				: 18 Mar 2010
-- ***********************************************

USE [TransientPortal]
GO

----------------------------------------------------------------
-- Journey datail page related links for Trunk mode
----------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------
-- Remove any previously added Related Links added for the Trunk mode journey detail page

DECLARE @ContextId INT

IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextJourneyDetailsFindTrunkInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextJourneyDetailsFindTrunkInput')
	
	DELETE 
    FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
	
	
END

GO

-- Set up the Related Links for Journey details page for Trunk mode
-- CURRRENTLY NO RELATED LINKS ARE DEFINED SO NONE ARE ADDED

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextJourneyDetailsFindTrunkInput'
SET @ThemeId = 1


-- Add our new context for Journey details page for Trunk mode
EXEC AddContext
    
    @ContextName,                            												-- Context
    'Related Link Context - Suggestions for Journey Details page for Trunk mode'			-- Context description


-- Add the Related Links heading root url for our context
-- *WARNING* Only uncomment following lines when actual related link needs adding
--EXEC AddContextSuggestionLink

--	'RelatedLinks',		-- Resource name
--	'Related Links',	-- Link category
--	@ContextName,		-- Context
--	@ThemeId			-- Theme


-- Add the actual links. 
-- *WARNING* Following is added for test purpose and as a template to add real related link
--EXEC AddExternalSuggestionLink

--	'JourneyDetails.Trunk.TestLink',							-- ID for ExternalLink table
--	'http://www.transportdirect.info',						 	-- Full external link URL
--	'http://www.transportdirect.info',							-- Full test external link URL
--	'JourneyDetails - Trunk - Test Link',							-- Description of external link. Ensure this is a unique external link description   
--	'JourneyDetails.Trunk.TestLink',							-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
--	'JourneyDetails - Trunk - test link',							-- English display text. Populate only if adding new ResourceName or updating existing display text
--	'cy JourneyDetails - Trunk - test link',						-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
--	'Related links',                                            -- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
--	9500,						                                -- Priority must be unique for the selected CategoryName this link is for
--	0,                                                          -- Set to 0 if to be used as a Suggestion/Related Link
--	0,                                                          -- Set to 1 if it is a second level Root link
--	@ContextName,                                               -- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
--	'',                                                         -- Populate only if adding a new ContextName, or updating description
--	@ThemeId                                                    -- Theme this link is added for, use 1 as default

GO


----------------------------------------------------------------
-- Journey summary page related links for Trunk mode
----------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------
-- Remove any previously added Related Links added for the Trunk mode journey summary page

DECLARE @ContextId INT

IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextJourneySummaryFindTrunkInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextJourneySummaryFindTrunkInput')
	
	DELETE 
    FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
	
	
END

GO

-- Set up the Related Links for Journey summary page for Trunk mode
-- CURRRENTLY NO RELATED LINKS ARE DEFINED SO NONE ARE ADDED

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextJourneySummaryFindTrunkInput'
SET @ThemeId = 1


-- Add our new context for Journey summary page for Trunk mode
EXEC AddContext
    
    @ContextName,                            												-- Context
    'Related Link Context - Suggestions for Journey summary page for Trunk mode'			-- Context description

Go
--------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------------
-- Journey map page related links for Trunk mode
----------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------
-- Remove any previously added Related Links added for the Trunk mode journey map page

DECLARE @ContextId INT

IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextJourneyMapFindTrunkInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextJourneyMapFindTrunkInput')
	
	DELETE 
    FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
	
	
END

GO

-- Set up the Related Links for Journey map page for Trunk mode
-- CURRRENTLY NO RELATED LINKS ARE DEFINED SO NONE ARE ADDED

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextJourneyMapFindTrunkInput'
SET @ThemeId = 1


-- Add our new context for Journey map page for Trunk mode
EXEC AddContext
    
    @ContextName,                            												-- Context
    'Related Link Context - Suggestions for Journey map page for Trunk mode'				-- Context description

Go
--------------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------------------
-- Journey fares page related links for Trunk mode
----------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------
-- Remove any previously added Related Links added for the Trunk mode journey fares page

DECLARE @ContextId INT

IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextJourneyFaresFindTrunkInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextJourneyFaresFindTrunkInput')
	
	DELETE 
    FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
	
	
END

GO

-- Set up the Related Links for Journey fares page for Trunk mode
-- CURRRENTLY NO RELATED LINKS ARE DEFINED SO NONE ARE ADDED

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextJourneyFaresFindTrunkInput'
SET @ThemeId = 1


-- Add our new context for Journey fares page for Trunk mode
EXEC AddContext
    
    @ContextName,                            												-- Context
    'Related Link Context - Suggestions for Journey fares page for Trunk mode'			-- Context description

Go
--------------------------------------------------------------------------------------------------------------------------------


-- END
--------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1625
SET @ScriptDesc = 'Script to add the Related link contexts to the Journey Detail page for city to city journey'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO