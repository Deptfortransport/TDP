-- ***********************************************
-- NAME 		: DUP1775_ShowALL_Show10_Override_Timespan_Properties.sql
-- DESCRIPTION 	: Script to add properties to handle train, flight and city to city timespan override
-- AUTHOR		: Amit Patel
-- DATE			: 20 Dec 2010
-- ************************************************

USE [PermanentPortal]
GO

--------------------------------------------------------------------------
-- Property for train and flight to control the override
--------------------------------------------------------------------------
-- Web - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.OverrideTimespan' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.OverrideTimespan', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Train.OverrideTimespan'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.OverrideTimespan' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.OverrideTimespan', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Flight.OverrideTimespan'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - Trunk
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.OverrideTimespan' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.OverrideTimespan', 'true', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Trunk.OverrideTimespan'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.OverrideTimespan' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.OverrideTimespan', 'true', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Train.OverrideTimespan'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.OverrideTimespan' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.OverrideTimespan', 'true', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Flight.OverrideTimespan'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - Trunk
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.OverrideTimespan' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.OverrideTimespan', 'true', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Trunk.OverrideTimespan'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


-- TDPlannerHost - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.OverrideTimespan' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.OverrideTimespan', 'true', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Train.OverrideTimespan'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.OverrideTimespan' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.OverrideTimespan', 'true', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Flight.OverrideTimespan'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - Trunk
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.OverrideTimespan' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.OverrideTimespan', 'true', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'true'
	where pname = 'PublicJourney.Trunk.OverrideTimespan'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


--------------------------------------------------------------------------
-- Property for train and flight to control the start time
--------------------------------------------------------------------------
-- Web - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.StartTime' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.StartTime', '0100', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Train.StartTime'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.StartTime' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.StartTime', '0100', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Flight.StartTime'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - Trunk mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.StartTime' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.StartTime', '0100', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Trunk.StartTime'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - TrunkCostBased mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkCostBased.StartTime' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkCostBased.StartTime', '0100', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.TrunkCostBased.StartTime'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - TrunkStation mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkStation.StartTime' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkStation.StartTime', '0100', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.TrunkStation.StartTime'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost  - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.StartTime' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.StartTime', '0100', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Train.StartTime'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost  - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.StartTime' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.StartTime', '0100', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Flight.StartTime'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - Trunk mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.StartTime' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.StartTime', '0100', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Trunk.StartTime'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - TrunkCostBased mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkCostBased.StartTime' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkCostBased.StartTime', '0100', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.TrunkCostBased.StartTime'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - TrunkStation mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkStation.StartTime' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkStation.StartTime', '0100', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.TrunkStation.StartTime'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost  - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.StartTime' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.StartTime', '0100', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Train.StartTime'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost  - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.StartTime' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.StartTime', '0100', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Flight.StartTime'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - Trunk mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.StartTime' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.StartTime', '0100', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.Trunk.StartTime'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - TrunkCostBased mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkCostBased.StartTime' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkCostBased.StartTime', '0100', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.TrunkCostBased.StartTime'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - TrunkStation mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkStation.StartTime' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkStation.StartTime', '0100', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'PublicJourney.TrunkStation.StartTime'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

--------------------------------------------------------------------------
-- Property for train and flight to control the interval time
--------------------------------------------------------------------------
-- Web - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.Interval' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.Interval', '24', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Train.Interval'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.Interval' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.Interval', '24', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Flight.Interval'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - Trunk mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.Interval' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.Interval', '24', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Trunk.Interval'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - TrunkCostBased mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkCostBased.Interval' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkCostBased.Interval', '24', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.TrunkCostBased.Interval'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- Web - TrunkStation mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkStation.Interval' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkStation.Interval', '24', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.TrunkStation.Interval'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost  - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.Interval' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.Interval', '24', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Train.Interval'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost  - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.Interval' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.Interval', '24', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Flight.Interval'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - Trunk mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.Interval' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.Interval', '24', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Trunk.Interval'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - TrunkCostBased mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkCostBased.Interval' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkCostBased.Interval', '24', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.TrunkCostBased.Interval'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDRemotingHost - TrunkStation mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkStation.Interval' 
		and AID = 'TDRemotingHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkStation.Interval', '24', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.TrunkStation.Interval'
	and AID = 'TDRemotingHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost  - Train
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Train.Interval' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Train.Interval', '24', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Train.Interval'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost  - Flight
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Flight.Interval' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Flight.Interval', '24', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Flight.Interval'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - Trunk mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.Trunk.Interval' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.Trunk.Interval', '24', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.Trunk.Interval'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - TrunkCostBased mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkCostBased.Interval' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkCostBased.Interval', '24', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.TrunkCostBased.Interval'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-- TDPlannerHost - TrunkStation mode
IF not exists (
	select top 1 * from properties 
	where pName = 'PublicJourney.TrunkStation.Interval' 
		and AID = 'TDPlannerHost' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('PublicJourney.TrunkStation.Interval', '24', 'TDPlannerHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '24'
	where pname = 'PublicJourney.TrunkStation.Interval'
	and AID = 'TDPlannerHost' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1775
SET @ScriptDesc = 'Script to add properties to handle train, flight and city to city timespan override'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO