-- ***********************************************
-- NAME 		: DUP1707_Add_Car_Costing_Gateway_ Import.sql
-- DESCRIPTION 	: Adds or updates the feed properties for the vjs185 data feed
--				: and the associated import stored procedure	
-- ************************************************

----------------------------------------
-- NOTE YOU WILL GET SOME ERRORS WHEN RUNNING THIS SCRIPT AS IT WILL ATTEMPT
-- TO GRANT PERMISSIONS TO THE STORED PROCEDURE TO ASPUSER AND -SERVICE-NSM USERS FOR ALL 
-- THREE PRODUCTION ENVIRONMENTS. THIS SHOULD NOT MATTER AS THE GRANTS SHOULD SUCCEED FOR
-- THE USERS APPROPRIATE TO THE ENVIRONMENT
----------------------------------------


USE [PermanentPortal]
GO

----------------------------------------
-- UPDATE FEED CONFIGURATION
----------------------------------------

IF EXISTS(SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'vjs185')
  BEGIN
    DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'vjs185'
  END

INSERT INTO IMPORT_CONFIGURATION(DATA_FEED, IMPORT_CLASS, CLASS_ARCHIVE, IMPORT_UTILITY, PARAMETERS1, PARAMETERS2, PROCESSING_DIR)
VALUES ('vjs185','TransportDirect.UserPortal.JourneyControl.CarCostingImportTask','td.userportal.journeycontrol.dll','','','','D:/Gateway/dat/Processing/vjs185')


----------------------------------------
-- UPDATE FEED PROPERTIES
----------------------------------------

IF EXISTS(SELECT * FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.carcosting.database','datagateway.sqlimport.carcosting.feedname','datagateway.sqlimport.carcosting.Name',
     'datagateway.sqlimport.carcosting.schemea','datagateway.sqlimport.carcosting.sqlcommandtimeout','datagateway.sqlimport.carcosting.storedprocedure',
     'datagateway.sqlimport.carcosting.xmlnamespace','datagateway.sqlimport.carcosting.xmlnamespacexsi','datagateway.sqlimport.carcosting.xmlschemalocation'))
  BEGIN
    DELETE FROM [PROPERTIES] WHERE [PNAME] IN 
    ('datagateway.sqlimport.carcosting.database','datagateway.sqlimport.carcosting.feedname','datagateway.sqlimport.carcosting.Name',
     'datagateway.sqlimport.carcosting.schemea','datagateway.sqlimport.carcosting.sqlcommandtimeout','datagateway.sqlimport.carcosting.storedprocedure',
     'datagateway.sqlimport.carcosting.xmlnamespace','datagateway.sqlimport.carcosting.xmlnamespacexsi','datagateway.sqlimport.carcosting.xmlschemalocation')
  END

INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.database','DefaultDB','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.feedname','vjs185','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.Name','carcosting','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.schemea','D:\gateway\bin\xml\carcosting.xsd','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.sqlcommandtimeout','3000','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.storedprocedure','ImportCarCostingData','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.xmlnamespace','http://www.transportdirect.info/carcosting','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.xmlnamespacexsi','http://www.w3.org/2001/XMLSchema-instance','','DataGateway','0')
INSERT INTO PROPERTIES(PNAME, PVALUE, AID, GID, PARTNERID) 
VALUES ('datagateway.sqlimport.carcosting.xmlschemalocation','http://www.transportdirect.info/carcosting.xsd','','DataGateway','0')

----------------------------------------
-- UPDATE FTP_CONFIGURATION
----------------------------------------
IF EXISTS (SELECT * FROM [dbo].[ftp_configuration] WHERE data_feed = 'vjs185')
  BEGIN
    UPDATE
      [dbo].[ftp_configuration]
    SET
      ftp_client = 1,
      data_feed = 'vjs185',
      ip_address = 'LocalHost',
      username = 'TDP28Nov',
      password = 'sI1732#3-',
      local_dir = 'D:/Gateway/dat/Incoming/vjs185',
      remote_dir = '../vjs185',
      filename_filter = '*.zip',
      missing_feed_counter = 0,
      missing_feed_threshold = 1,
      data_feed_datetime = '01/01/2003',
      data_feed_filename = '',
      remove_files = 1      
    WHERE
      data_feed = 'vjs185'
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ftp_configuration](ftp_client, data_feed, ip_address, username, password, local_dir,
     remote_dir,filename_filter,missing_feed_counter, missing_feed_threshold,data_feed_datetime,
     data_feed_filename,remove_files)
    VALUES (1, 'vjs185','LocalHost','TDP28Nov','sI1732#3-','D:/Gateway/dat/Incoming/vjs185','../vjs185','*.zip',
	 0, 1, '01/01/2003','', 1)
  END
GO

-------------------------------------------
-- Add ImportCarCostingData Stored Procedure
-------------------------------------------

USE [PermanentPortal]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ImportCarCostingData]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ImportCarCostingData]
GO

CREATE    PROCEDURE dbo.ImportCarCostingData (@XML text) AS

	SET NOCOUNT ON

	DECLARE @DocID int
	DECLARE @RetCode int
	DECLARE @XMLPathData varchar(50)

	-- Load XML document
	EXEC sp_xml_preparedocument @DocID OUTPUT, @XML
	SET @XMLPathData = '/'
	
	-- Start Transaction
	BEGIN TRANSACTION
		
		----------------------------------------------------
		-- Clear Down Data Table
		----------------------------------------------------
	
		DELETE FROM [PermanentPortal].[dbo].[CarCostFuelCost]
		DELETE FROM [PermanentPortal].[dbo].[CarCostRunningCost]
		DELETE FROM [PermanentPortal].[dbo].[CarCostFuelConsumption]
		
		IF @@ERROR<>0
		GOTO ERR_HANDLER

		----------------------------------------------------
		-- Insert Into Data Tables
		----------------------------------------------------
	
		INSERT INTO CarCostFuelCost (FuelType,Cost)
		SELECT DISTINCT  XmlDoc.FuelType,XmlDoc.Cost
		FROM OPENXML (@DocID, 'CarCostings/CarCostFuelCost',1)
		WITH (FuelType Varchar(10),Cost int) XmlDoc
		
		INSERT INTO CarCostRunningCost (CarSize,FuelType,Cost)
		SELECT DISTINCT  XmlDoc.CarSize,XmlDoc.FuelType,XmlDoc.Cost
		FROM OPENXML (@DocID, 'CarCostings/CarCostRunningCost',1)
		WITH (CarSize Varchar(10),FuelType Varchar(10),Cost int) XmlDoc
		
		INSERT INTO CarCostFuelConsumption (CarSize,FuelType,Consumption)
		SELECT DISTINCT  XmlDoc.CarSize,XmlDoc.FuelType,XmlDoc.Consumption
		FROM OPENXML (@DocID, 'CarCostings/CarCostFuelConsumption',1)
		WITH (CarSize Varchar(10),FuelType Varchar(10),Consumption int) XmlDoc
		
		IF @@ERROR<>0
			GOTO ERR_HANDLER
			
		--Update Change Notification Version numbers
		UPDATE PermanentPortal.Dbo.ChangeNotification SET [Version] = [Version] + 1
		WHERE [Table] IN ('CarCostFuelCost','CarCostRunningCost','CarCostFuelConsumption')

		IF @@ERROR<>0
			GOTO ERR_HANDLER

		EXEC sp_xml_removedocument @DocID
			
	
	COMMIT TRANSACTION
	RETURN 0
	

ERR_HANDLER:
	EXEC sp_xml_removedocument @DocID
	ROLLBACK TRANSACTION
	RETURN 1

GO

GRANT EXECUTE ON [ImportCarCostingData] TO [NETWORK SERVICE]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [BBPTDPSIW\ASPUSER]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [BBPTDPW\ASPUSER]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [ACPTDPW\ASPUSER]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [BBPTDPSIS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [BBPTDPS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [ACPTDPS\ASPUSER_S]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [BBPTDPSIS\-service-nsm]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [BBPTDPS\-service-nsm]
GO
GRANT EXECUTE ON [ImportCarCostingData] TO [ACPTDPS\-service-nsm]
GO

----------------------------------------
-- CHANGE LOG
----------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1707
SET @ScriptDesc = 'Added Car Costing Gateway Import'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO