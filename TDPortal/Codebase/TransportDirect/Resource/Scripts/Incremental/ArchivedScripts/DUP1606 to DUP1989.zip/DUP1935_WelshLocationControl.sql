-- ***********************************************
-- NAME 		: DUP1935_WelshLocationControl.sql
-- DESCRIPTION 	: Welsh for the location control
-- AUTHOR		: David Lane
-- DATE			: 1 Nov 12
-- ************************************************

USE [Content]
GO

-------------------------------
-- Add to Content
-------------------------------

EXEC AddtblContent
	1, 1, 'langStrings', 'LocationControl.LocationInputDescription.Text',
	'Type in a location',
	'Teipiwch leoliad'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'LocationControl.LocationInputDescription.PTVia.Text',
	'Type in a location to travel via',
	'Teipiwch leoliad i deithio drwyddo'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'LocationControl.LocationInput.ToolTip',
	'Enter postcode, station/airport or town/district/village',
	'Mewnbynnwch y c�d post, gorsaf/maes awyr neu dref/ardal/pentref'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'LocationControl.LocationInput.PTVia.ToolTip',
	'Enter station/airport',
	'Nodwch yr orsaf/maes awyr'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'LocationControl.LocationInput.PlanAJourney.ToolTip',
	'Postcode, station/airport',
	'C�d post, gorsaf/maes awyr'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'LocationControl.AmbiguityReset.Text',
	'Clear',
	'Clirio'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'LocationControl.MoreOptions.Text',
	'More options',
	'Rhagor o opsiynau'
GO

EXEC AddtblContent
	1, 1, 'langStrings', 'PlanAJourneyControl.MoreOptions.ToolTip',
	'Click to view more door-to-door journey planning options',
	'Cliciwch i weld mwy o opsiynau cynllunio teithiau o ddrws i ddrws'
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1935
SET @ScriptDesc = 'Welsh for the location control'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO