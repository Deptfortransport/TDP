-- ***********************************************
-- NAME           : DUP1890_IncreaseUserIdLengthAndCallingSprocs
-- DESCRIPTION    : Script to modify user id length and associated sprocs
-- DATE           : 16/05/2012
-- Author         : D Lane
-- ***********************************************


USE TDUserInfo
GO

-- Increase the userid field length

-- remove the PK constraint
ALTER TABLE ProfileData
DROP CONSTRAINT PK_PrefsAndFaves
GO

-- increase column size
ALTER TABLE ProfileData
ALTER COLUMN UserId varchar(250) not null
GO

-- re-add PK constraint
ALTER TABLE ProfileData
ADD CONSTRAINT PK_PrefsAndFaves PRIMARY KEY CLUSTERED (UserID)
GO

-- update associated stored procs
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Alter the DeleteUserProfile stored procedure
ALTER PROCEDURE [dbo].[usp_DeleteUserProfile]
(
@userID varchar(250)
)
AS

-- Test to see if there is an existing entry in the PrefsAndFav
IF EXISTS (	SELECT UserID FROM TDUserInfo..ProfileData WHERE UserID = @userID )
	BEGIN -- There is an existing entry, so update it
		delete from TDUserInfo..ProfileData
		WHERE UserID = @userID
		
		RETURN 0
		
	END
RETURN 1
GO

-- Alter the ReadPreferences stored procedure
ALTER PROCEDURE [dbo].[usp_ReadUserProfile]
(
@userID varchar(250)
)
AS

DECLARE @textptr AS varbinary(16)
DECLARE @length AS INT

-- Get the deferred session item from the deferred data 
SELECT
	@textptr = TEXTPTR(DataItem),
	@length = DATALENGTH(DataItem)
FROM	TDUserInfo..ProfileData
WHERE	UserID = @userID

IF @length IS NOT NULL 
BEGIN
 READTEXT TDUserInfo..ProfileData.DataItem @textptr 0 @length
 RETURN 1
END
ELSE
BEGIN
    RETURN 0
END
GO

-- Alter the WriteUserProfile stored procedure
ALTER PROCEDURE [dbo].[usp_WriteUserProfile]
(
@userID varchar(250),
@dataItem image
)
AS

-- Test to see if there is an existing entry in the PrefsAndFav
IF EXISTS (	SELECT UserID FROM TDUserInfo..ProfileData WHERE UserID = @userID )
BEGIN -- There is an existing entry, so update it
	UPDATE TDUserInfo..ProfileData
	SET DataItem = @dataItem
	WHERE UserID = @userID
	
	RETURN 0
	
END
ELSE
BEGIN -- There is not an existing entry, so insert one
	INSERT INTO TDUserInfo..ProfileData (UserID, DataItem)
	VALUES(@userID, @dataItem)
	
	RETURN 1
END
	
RETURN 2
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1890
SET @ScriptDesc = 'DUP1890_IncreaseUserIdLengthAndCallingSprocs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

