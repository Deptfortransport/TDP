-- ***********************************************
-- NAME 		: DUP1682_Add_Coach_Operator_Code.sql
-- DESCRIPTION 	: Adds an operator code of *NX to CoachOperatorCodes
-- AUTHOR		: Mark Turner
-- DATE			: 21 April 2010
-- ************************************************

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [dbo].[CoachOperatorCodes] WHERE CJPOperatorCode = '*NX')
  BEGIN
    UPDATE [dbo].[CoachOperatorCodes]
    SET TDOperatorCode = 'NX'
    WHERE CJPOperatorCode = '*NX'
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[CoachOperatorCodes] (CJPOperatorCode,TDOperatorCode)
    VALUES ('*NX','NX')
  END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1682
SET @ScriptDesc = 'Adds an operator code of *NX to CoachOperatorCodes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO