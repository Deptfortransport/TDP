-- ***********************************************
-- NAME 		: DUP1766_GetAllRouteRestrictions_StoredProcedure.sql
-- DESCRIPTION 	: Script to create GetAllRouteRestrictions stored procedures for fares
-- AUTHOR		: Amit Patel
-- DATE			: 16 Nov 2010
-- ************************************************

USE [PermanentPortal] 
GO

-------------------------------------------------------------
-- *********			   WARNING					  *******
-- Please ensure appropriate permissions are added to the stored procedures, all will 
-- need ASPUSER execute at a minimum.

-- This script adds the following stored procedures:
-- GetAllRouteRestrictions

-------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- Create GetAllRouteRestrictions stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllRouteRestrictions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetAllRouteRestrictions
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetAllRouteRestrictions stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetAllRouteRestrictions] 
As
    SET NOCOUNT ON

	SELECT RouteCode, PortalDescription
	FROM dbo.RouteRestrictions	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1766
SET @ScriptDesc = 'Script to create GetAllRouteRestrictions stored procedures for fares'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO