-- ***********************************************
-- NAME 		: DUP1905_Batch_Phase_2.sql
-- DESCRIPTION 	: Script to update tables, procedures, content and properties for batch
-- AUTHOR		: David Lane
-- DATE			: 22 Aug 2012
-- ************************************************


USE BatchJourneyPlanner
GO

-- Change the batch detail table to have separate error messages for each journey
IF NOT EXISTS (SELECT * FROM sys.columns WHERE name = 'PublicOutwardErrorMessage' AND object_id = OBJECT_ID(N'BatchRequestDetail'))
BEGIN
	ALTER TABLE BatchRequestDetail
	ADD PublicOutwardErrorMessage NVARCHAR(200) 
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE name = 'CycleOutwardErrorMessage' AND object_id = OBJECT_ID(N'BatchRequestDetail'))
BEGIN
	ALTER TABLE BatchRequestDetail
	ADD CycleOutwardErrorMessage NVARCHAR(200) 
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE name = 'CarOutwardErrorMessage' AND object_id = OBJECT_ID(N'BatchRequestDetail'))
BEGIN
	ALTER TABLE BatchRequestDetail
	ADD CarOutwardErrorMessage NVARCHAR(200) 
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE name = 'PublicReturnErrorMessage' AND object_id = OBJECT_ID(N'BatchRequestDetail'))
BEGIN
	ALTER TABLE BatchRequestDetail
	ADD PublicReturnErrorMessage NVARCHAR(200) 
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE name = 'CycleReturnErrorMessage' AND object_id = OBJECT_ID(N'BatchRequestDetail'))
BEGIN
	ALTER TABLE BatchRequestDetail
	ADD CycleReturnErrorMessage NVARCHAR(200) 
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE name = 'CarReturnErrorMessage' AND object_id = OBJECT_ID(N'BatchRequestDetail'))
BEGIN
	ALTER TABLE BatchRequestDetail
	ADD CarReturnErrorMessage NVARCHAR(200) 
END

-- Is it possible to migrate errors for existing records??

-- Change the batch summary table to include partial successes
DECLARE @AddedColumn bit
SET @AddedColumn = 0

IF NOT EXISTS (SELECT * FROM sys.columns WHERE name = 'NumberOfPartialSuccesses' AND object_id = OBJECT_ID(N'BatchRequestSummary'))
BEGIN
	ALTER TABLE BatchRequestSummary
	ADD NumberOfPartialSuccesses INT NULL
	
	SET @AddedColumn = 1
END
GO

UPDATE BatchRequestSummary
SET NumberOfPartialSuccesses = 0
WHERE BatchStatusId IN (3, 4)

-- Add partial success status
IF NOT EXISTS (SELECT * FROM BatchDetailStatus WHERE BatchDetailStatusId = 5)
BEGIN
	INSERT INTO [BatchDetailStatus]
			   ([BatchDetailStatusId]
			   ,[BatchDetailStatusDescription])
		 VALUES
			   (5
			   ,'PartialSuccess')
END

-- UpdateBatchRequestDetail proc
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO

ALTER PROCEDURE [dbo].[UpdateBatchRequestDetail]
(
	@BatchDetailId int,
	@PublicJourneyResultSummary nvarchar(250),
	@PublicJourneyResultDetails xml,
	@PublicOutwardJourneyStatus int,
	@PublicReturnJourneyStatus int,
	@CarResultSummary nvarchar(250),
	@CarOutwardStatus int,
	@CarReturnStatus int,
	@CycleResultSummary nvarchar(250),
	@CycleOutwardStatus int,
	@CycleReturnStatus int,
	@PublicOutwardErrorMessage nvarchar(200),
	@CarOutwardErrorMessage nvarchar(200),
	@CycleOutwardErrorMessage nvarchar(200),
	@PublicReturnErrorMessage nvarchar(200),
	@CarReturnErrorMessage nvarchar(200),
	@CycleReturnErrorMessage nvarchar(200)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Update the detail record
	DECLARE @Date datetime
	SET @Date = GETDATE()
	
	DECLARE @DetailStatusId int
	SET @DetailStatusId = 2 -- complete

	IF ((@PublicOutwardJourneyStatus > 2) OR (@CarOutwardStatus > 2) OR (@CycleOutwardStatus > 2) OR (@PublicReturnJourneyStatus > 2) OR (@CarReturnStatus > 2) OR (@CycleReturnStatus > 2))
	BEGIN
		SET @DetailStatusId = 3 -- errored
	END
	
	IF (@DetailStatusId = 3)
	BEGIN
		IF ((@PublicOutwardJourneyStatus = 2) OR (@CycleOutwardStatus = 2) OR (@CarOutwardStatus = 2) OR (@PublicReturnJourneyStatus = 2) OR (@CarReturnStatus = 2) OR (@CycleReturnStatus = 2))
		BEGIN
			SET @DetailStatusId = 5 -- partial success
		END
	END
		
	UPDATE BatchRequestDetail
	SET CompletedDateTime = @Date,
		PublicJourneyResultSummary = @PublicJourneyResultSummary,
		PublicJourneyResultDetails = @PublicJourneyResultDetails,
		PublicOutwardJourneyStatus = @PublicOutwardJourneyStatus,
		PublicReturnJourneyStatus = @PublicReturnJourneyStatus,
		CarJourneyResultSummary = @CarResultSummary,
		CarOutwardJourneyStatus = @CarOutwardStatus,
		CarReturnJourneyStatus = @CarReturnStatus,
		CycleJourneyResultSummary = @CycleResultSummary,
		CycleOutwardJourneyStatus = @CycleOutwardStatus,
		CycleReturnJourneyStatus = @CycleReturnStatus,
		BatchDetailStatusId = @DetailStatusId,
		PublicOutwardErrorMessage = @PublicOutwardErrorMessage,
		CarOutwardErrorMessage = @CarOutwardErrorMessage,
		CycleOutwardErrorMessage = @CycleOutwardErrorMessage,
		PublicReturnErrorMessage = @PublicReturnErrorMessage,
		CarReturnErrorMessage = @CarReturnErrorMessage,
		CycleReturnErrorMessage = @CycleReturnErrorMessage
	WHERE RequestId = @BatchDetailId
END
GO

-- GetBatchRequestDetailsForProcessing proc
ALTER PROCEDURE [dbo].[GetBatchRequestDetailsForProcessing]
(
	@ProcessorId nvarchar(50),
	@NumberRequests int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Check for a batch this processor is already doing
	DECLARE @BatchId int
	DECLARE @Date datetime
	SET @Date = GETDATE()
	
	IF (NOT EXISTS (SELECT BatchId FROM BatchRequestSummary WHERE ProcessorId = @ProcessorId))
	BEGIN
		-- Get a new batch if there is one available
		IF (EXISTS (SELECT BatchId FROM BatchRequestSummary WHERE ProcessorId IS NULL AND BatchStatusId = 1))
		BEGIN
			SELECT @BatchId = BatchId 
				FROM BatchRequestSummary 
				WHERE ProcessorId IS NULL 
				AND BatchStatusId = 1
				ORDER BY QueuedDateTime DESC
				
			UPDATE BatchRequestSummary
				SET ProcessorId = @ProcessorId,
				BatchStatusId = 2
				WHERE BatchId = @BatchId
		END
		ELSE
		BEGIN
			-- No requests available
			RETURN 0
		END
	END
	ELSE
	BEGIN
		SELECT @BatchId = BatchId
		FROM BatchRequestSummary
		WHERE ProcessorId = @ProcessorId
	END

	-- See if the batch is complete
	DECLARE @Count int
	SELECT @Count = COUNT(*)
	FROM BatchRequestDetail
	WHERE (BatchDetailStatusId IS NULL -- Pending
	OR BatchDetailStatusId = 1) -- in progress
	AND BatchId = @BatchId
		
	IF (@Count = 0)
	BEGIN
		-- Finish off this batch and update the summary record
		SET @Date = GETDATE()
		
		UPDATE BatchRequestSummary
			SET CompletedDateTime = @Date,
			NumberOfSuccessfulResults = (SELECT COUNT(*) FROM BatchRequestDetail WHERE BatchDetailStatusId = 2 AND BatchId = @BatchId),
			NumberOfUnsuccessfulRequests = (SELECT COUNT(*) FROM BatchRequestDetail WHERE BatchDetailStatusId = 3 AND BatchId = @BatchId),
			NumberOfPartialSuccesses = (SELECT COUNT(*) FROM BatchRequestDetail WHERE BatchDetailStatusId = 5 AND BatchId = @BatchId),
			BatchStatusId = 3,
			ProcessorId = null
		WHERE BatchId = @BatchId
		
		RETURN @BatchId
	END
	ELSE
	BEGIN
		-- Check if batch has stalled
		SELECT @Count = COUNT(*)
		FROM BatchRequestDetail
		WHERE BatchDetailStatusId IS NULL
		AND BatchId = @BatchId
		
		IF (@Count = 0)
		BEGIN
			-- resset the stalled records
			UPDATE BatchRequestDetail
			SET BatchDetailStatusId = NULL
			WHERE BatchDetailStatusId = 1
			AND BatchId = @BatchId
		END
	END

	-- Get detail records and preferences
	SELECT TOP (@NumberRequests) 
		bd.RequestId,									--0
		bs.[ReportParameters.IncludeJourneyStatistics],	--1
		bs.[ReportParameters.IncludeJourneyDetails],	--2
		bs.[ReportParameters.IncludePublicTransport],	--3
		bs.[ReportParameters.IncludeCar],				--4
		bs.[ReportParameters.IncludeCycle],				--5
		bs.[ReportParameters.ConvertToRtf],				--6
		bd.UserSuppliedUniqueId,						--7
		bd.[JourneyParameters.OriginType],				--8
		bd.[JourneyParameters.Origin],					--9
		bd.[JourneyParameters.DestinationType],			--10
		bd.[JourneyParameters.Destination],				--11
		bd.[JourneyParameters.OutwardDate],				--12
		bd.[JourneyParameters.OutwardTime],				--13
		bd.[JourneyParameters.OutwardArrDep],			--14
		bd.[JourneyParameters.ReturnDate],				--15
		bd.[JourneyParameters.ReturnTime],				--16
		bd.[JourneyParameters.ReturnArrDep]				--17
	FROM BatchRequestSummary bs
	INNER JOIN BatchRequestDetail bd
		ON bs.BatchId = bd.BatchId
	WHERE bd.BatchId = @BatchId
	AND bd.BatchDetailStatusId IS NULL -- Pending
	ORDER BY bd.RequestId ASC
	
	-- Update the status and submitted date
	UPDATE BatchRequestDetail
		SET BatchDetailStatusId = 1, -- Submitted
			SubmittedDateTime = @Date
	WHERE RequestId IN (SELECT TOP (@NumberRequests) RequestId
						FROM BatchRequestDetail bd
						WHERE bd.BatchId = @BatchId
						AND bd.BatchDetailStatusId IS NULL
						ORDER BY bd.RequestId ASC)
	
	RETURN 0
END
GO

-- GetBatchRequestsForUser proc
ALTER PROCEDURE [dbo].[GetBatchRequestsForUser]
(
	@EmailAddress nvarchar(250),
	@Page int,
	@SortColumn nvarchar(100),
	@SortDirection nvarchar(5)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Get the user id
	DECLARE @UserId int
	SELECT @UserId = UserId
	FROM RegisteredUser
	WHERE @EmailAddress = EmailAddress
	
	-- Paging vars (20 per page)
	DECLARE @StartRow int
	DECLARE @EndRow int
	SET @StartRow = 20 * (@Page - 1) + 1
	SET @EndRow = @StartRow + 19
	
	DECLARE @Total int
	SELECT @Total = COUNT(*)
		FROM BatchRequestSummary
		WHERE UserId = @UserId;
	
	-- Get the user's batch requests
	WITH Results AS
	(SELECT BatchJourneyPlanner.dbo.PadBatchId(CONVERT(nvarchar(20), [BatchId])) AS BatchId
		,CASE WHEN [CompletedDateTime] = NULL THEN '' ELSE CONVERT(nvarchar(10), [CompletedDateTime], 104) END AS CompletedDateTime
		,CONVERT(nvarchar(10), [QueuedDateTime], 104) AS QueuedDateTime
		,[NumberOfRequests]
		,CASE WHEN brs.BatchStatusId != 3 THEN '' ELSE [NumberOfSuccessfulResults] END AS NumberOfSuccessfulResults
		,CASE WHEN brs.BatchStatusId != 3 THEN '' ELSE [NumberOfPartialSuccesses] END AS NumberOfPartialSuccesses
		,CASE WHEN brs.BatchStatusId != 3 THEN '' ELSE [NumberOfInvalidRequests] END AS NumberOfInvalidRequests
		,CASE WHEN brs.BatchStatusId != 3 THEN '' ELSE [NumberOfUnsuccessfulRequests] END AS NumberOfUnsuccessfulRequests
		,[BatchStatusDescription]
		,[ReportParameters.IncludePublicTransport]
		,[ReportParameters.IncludeCar]
		,[ReportParameters.IncludeCycle]
		,ROW_NUMBER() OVER
			(ORDER BY
				CASE WHEN @SortColumn = 'BatchId' AND @SortDirection = 'asc' THEN BatchId END ASC,
				CASE WHEN @SortColumn = 'BatchId' AND @SortDirection = 'desc' THEN BatchId END DESC,
				CASE WHEN @SortColumn = 'Submitted' AND @SortDirection = 'asc' THEN QueuedDateTime END ASC,
				CASE WHEN @SortColumn = 'Submitted' AND @SortDirection = 'desc' THEN QueuedDateTime END DESC,
				CASE WHEN @SortColumn = 'PublicTransport' AND @SortDirection = 'asc' THEN [ReportParameters.IncludePublicTransport] END ASC,
				CASE WHEN @SortColumn = 'PublicTransport' AND @SortDirection = 'desc' THEN [ReportParameters.IncludePublicTransport] END DESC,
				CASE WHEN @SortColumn = 'Car' AND @SortDirection = 'asc' THEN [ReportParameters.IncludeCar] END ASC,
				CASE WHEN @SortColumn = 'Car' AND @SortDirection = 'desc' THEN [ReportParameters.IncludeCar] END DESC,
				CASE WHEN @SortColumn = 'Cycle' AND @SortDirection = 'asc' THEN [ReportParameters.IncludeCycle] END ASC,
				CASE WHEN @SortColumn = 'Cycle' AND @SortDirection = 'desc' THEN [ReportParameters.IncludeCycle] END DESC,
				CASE WHEN @SortColumn = 'NumberRequests' AND @SortDirection = 'asc' THEN NumberOfRequests END ASC,
				CASE WHEN @SortColumn = 'NumberRequests' AND @SortDirection = 'desc' THEN NumberOfRequests END DESC,
				CASE WHEN @SortColumn = 'NumberResults' AND @SortDirection = 'asc' THEN NumberOfSuccessfulResults END ASC,
				CASE WHEN @SortColumn = 'NumberResults' AND @SortDirection = 'desc' THEN NumberOfSuccessfulResults END DESC,
				CASE WHEN @SortColumn = 'NumberPartials' AND @SortDirection = 'asc' THEN NumberOfPartialSuccesses END ASC,
				CASE WHEN @SortColumn = 'NumberPartials' AND @SortDirection = 'desc' THEN NumberOfPartialSuccesses END DESC,
				CASE WHEN @SortColumn = 'ValidationErrors' AND @SortDirection = 'asc' THEN NumberOfInvalidRequests END ASC,
				CASE WHEN @SortColumn = 'ValidationErrors' AND @SortDirection = 'desc' THEN NumberOfInvalidRequests END DESC,
				CASE WHEN @SortColumn = 'NoResults' AND @SortDirection = 'asc' THEN NumberOfUnsuccessfulRequests END ASC,
				CASE WHEN @SortColumn = 'NoResults' AND @SortDirection = 'desc' THEN NumberOfUnsuccessfulRequests END DESC,
				CASE WHEN @SortColumn = 'DateComplete' AND @SortDirection = 'asc' THEN CompletedDateTime END ASC,
				CASE WHEN @SortColumn = 'DateComplete' AND @SortDirection = 'desc' THEN CompletedDateTime END DESC,
				CASE WHEN @SortColumn = 'Status' AND @SortDirection = 'asc' THEN BatchStatusDescription END ASC,
				CASE WHEN @SortColumn = 'Status' AND @SortDirection = 'desc' THEN BatchStatusDescription END DESC)
		AS RowNumber
	FROM [BatchJourneyPlanner].[dbo].[BatchRequestSummary] brs
	INNER JOIN [BatchJourneyPlanner].[dbo].[BatchStatus] bs
	ON brs.BatchStatusId = bs.BatchStatusId
	WHERE UserId = @UserId)

	SELECT * FROM Results
	WHERE RowNumber >= @StartRow
	AND RowNumber <= @EndRow
	ORDER BY RowNumber ASC
	
	RETURN @Total	
END
GO

-- GetBatchResults proc
ALTER PROCEDURE [dbo].[GetBatchResults]
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Output the results
	SELECT [UserSuppliedUniqueId]			-- 0
		,[ErrorMessages]					-- 1
		,[PublicJourneyResultSummary]		-- 2
		,[PublicJourneyResultDetails]		-- 3
		,[CarJourneyResultSummary]			-- 4
		,[CarJourneyResultDetails]			-- 5
		,[CycleJourneyResultSummary]		-- 6
		,[CycleJourneyResultDetails]		-- 7
		,[PublicOutwardJourneyStatus]		-- 8
		,[PublicReturnJourneyStatus]		-- 9
		,[CarOutwardJourneyStatus]			-- 10
		,[CarReturnJourneyStatus]			-- 11
		,[CycleOutwardJourneyStatus]		-- 12
		,[CycleReturnJourneyStatus]			-- 13
		,[JourneyParameters.Origin]			-- 14
		,[JourneyParameters.Destination]	-- 15
		,[JourneyParameters.OutwardDate]	-- 16
		,[JourneyParameters.OutwardTime]	-- 17
		,[JourneyParameters.OutwardArrDep]  -- 18
		,[JourneyParameters.ReturnDate]		-- 19
		,[JourneyParameters.ReturnTime]		-- 20
		,[JourneyParameters.ReturnArrDep]	-- 21
		,[BatchDetailStatusId]				-- 22
		,[JourneyParameters.OriginType]		-- 23
		,[JourneyParameters.DestinationType]-- 24
		,[PublicOutwardErrorMessage]		-- 25
		,[CycleOutwardErrorMessage]			-- 26
		,[CarOutwardErrorMessage]			-- 27
		,[PublicReturnErrorMessage]			-- 28
		,[CycleReturnErrorMessage]			-- 29
		,[CarReturnErrorMessage]			-- 30
	FROM [BatchJourneyPlanner].[dbo].[BatchRequestDetail]
	WHERE BatchId = @BatchId
	
END
GO

-- GetBatchSummary proc
ALTER PROCEDURE [dbo].[GetBatchSummary]
(
	@BatchId int
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT DetailsDeletedDateTime,
		BatchStatusId,
		[ReportParameters.IncludeJourneyStatistics],
		[ReportParameters.IncludeJourneyDetails],
		[ReportParameters.IncludePublicTransport],
		[ReportParameters.IncludeCar],
		[ReportParameters.IncludeCycle],
		[ReportParameters.ConvertToRtf]
		,QueuedDateTime
		,CompletedDateTime
		,NumberOfRequests
		,NumberOfSuccessfulResults
		,NumberOfUnsuccessfulRequests
		,NumberOfInvalidRequests
		,dbo.PadBatchId(BatchId)
		,NumberOfPartialSuccesses
	FROM BatchRequestSummary
	WHERE BatchId = @BatchId;
END
GO

-- GetUsers proc
ALTER PROCEDURE [dbo].[GetUsers]
(
	@Page int,
	@SortColumn nvarchar(100),
	@SortDirection nvarchar(5)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Paging (20 per page)
	DECLARE @StartRow int
	DECLARE @EndRow int
	SET @StartRow = 20 * (@Page - 1) + 1
	SET @EndRow = @StartRow + 19
	
	DECLARE @Total int
	SELECT @Total = COUNT(*)
		FROM RegisteredUser;
	
	-- Output the results
	WITH Results AS
	(SELECT [EmailAddress]
		,brs.QueuedDateTime
		,us.UserStatusDescription
		,ru.StatusChanged
		,ROW_NUMBER() OVER 
			(ORDER BY
				CASE WHEN @SortColumn = 'User' AND @SortDirection = 'asc' THEN EmailAddress END ASC,
				CASE WHEN @SortColumn = 'User' AND @SortDirection = 'desc' THEN EmailAddress END DESC,
				CASE WHEN @SortColumn = 'StatusChange' AND @SortDirection = 'asc' THEN ru.StatusChanged END ASC,
				CASE WHEN @SortColumn = 'StatusChange' AND @SortDirection = 'desc' THEN ru.StatusChanged END DESC,
				CASE WHEN @SortColumn = 'LastFileUpload' AND @SortDirection = 'asc' THEN brs.QueuedDateTime END ASC,
				CASE WHEN @SortColumn = 'LastFileUpload' AND @SortDirection = 'desc' THEN brs.QueuedDateTime END DESC,
				CASE WHEN @SortColumn = 'Status' AND @SortDirection = 'asc' THEN ru.UserStatusId END ASC, EmailAddress,
				CASE WHEN @SortColumn = 'Status' AND @SortDirection = 'desc' THEN ru.UserStatusId END DESC, EmailAddress
			) 
			AS RowNumber
	FROM [BatchJourneyPlanner].[dbo].[RegisteredUser] ru
	INNER JOIN [BatchJourneyPlanner].[dbo].[UserStatus] us
	ON ru.UserStatusId = us.UserStatusId
	LEFT JOIN [BatchJourneyPlanner].[dbo].[BatchRequestSummary] brs
	ON ru.UserId = brs.UserId
	AND brs.QueuedDateTime = (SELECT MAX(brs2.QueuedDateTime)
						FROM BatchJourneyPlanner.dbo.BatchRequestSummary brs2
						WHERE brs2.UserId = brs.UserId))

	SELECT * FROM Results
	WHERE RowNumber >= @StartRow
	AND RowNumber <= @EndRow
	ORDER BY RowNumber ASC
	
	RETURN @Total
END
GO

-- AddNewUser proc
ALTER PROCEDURE [dbo].[AddNewUser]
(
	@EmailAddress nvarchar(250)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Create the user record
	INSERT INTO [BatchJourneyPlanner].[dbo].[RegisteredUser]
			   ([EmailAddress]
			   ,[UserStatusId]
			   ,[IncludeStatistics]
			   ,[IncludeDetails]
			   ,[PublicTransport]
			   ,[Car]
			   ,[Cycle]
			   ,[ResultsAsRtf]
			   ,[StatusChanged])
		 VALUES
			   (@EmailAddress
			   ,1
			   ,0
			   ,0
			   ,0
			   ,0
			   ,0
			   ,1
			   ,GETDATE())

    -- Return the user id
	SELECT @@IDENTITY
END
GO

-- GetUserPreferences proc
ALTER PROCEDURE [dbo].[GetUserPreferences]
(
	@EmailAddress nvarchar(250)
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Get the user id
	DECLARE @UserId int
	SELECT @UserId = UserId
	FROM RegisteredUser
	WHERE @EmailAddress = EmailAddress
	
	SELECT IncludeStatistics,
		IncludeDetails,
		PublicTransport,
		Car,
		Cycle,
		ResultsAsRtf
	FROM RegisteredUser
	WHERE UserId = @UserId

	RETURN 0	
END
GO

-- Make ResultsAsRtf the database default
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_RegisteredUser_ResultsAsRtf]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[RegisteredUser] DROP CONSTRAINT [DF_RegisteredUser_ResultsAsRtf]
END
GO
ALTER TABLE [dbo].[RegisteredUser] ADD  CONSTRAINT [DF_RegisteredUser_ResultsAsRtf]  DEFAULT ((1)) FOR [ResultsAsRtf]
GO



--USE [Reporting]
--GO

---- Add new page entry event for reporting
--IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'CycleLinkClicked') 
--	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
--	SELECT MAX(PETID)+1, 'CycleLinkClicked', 'Cycle link clicked' FROM PageEntryType
--GO


USE [PermanentPortal]
GO

DECLARE @AID varchar(50) = 'BatchJourneyPlanner'
DECLARE @GID varchar(50) = 'UserPortal'

IF EXISTS(SELECT * FROM properties WHERE pName = 'CyclePlanner.Planner.MaxJourneyDistance.Metres' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1)
	UPDATE [properties] SET pValue = '50000' WHERE pName = 'CyclePlanner.Planner.MaxJourneyDistance.Metres' AND AID = @AID AND GID = @GID AND PartnerId = 0 AND ThemeId = 1
ELSE
	INSERT INTO [properties] VALUES ('CyclePlanner.Planner.MaxJourneyDistance.Metres', '50000', @AID, @GID, 0, 1)
GO


USE Content
GO

EXEC AddtblContent 
1,1,'langstrings','BatchJourneyPlanner.HeaderNumberPartials', 'Number of partial results', 'Number of partial results'
GO

EXEC AddtblContent 
1,1,'langstrings','BatchJourneyPlanner.NoData', 'There are no current requests to display', 'There are no current requests to display'
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1905
SET @ScriptDesc = 'Script to update tables, procedures, content and properties for batch'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO