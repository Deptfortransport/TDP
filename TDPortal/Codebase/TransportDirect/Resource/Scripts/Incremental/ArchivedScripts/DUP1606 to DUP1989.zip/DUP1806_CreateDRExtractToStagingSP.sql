-- ***********************************************
-- NAME 		: DUP1806_CreateExtractToStagingSP.sql
-- DESCRIPTION 	: Script to create stored proc to copy disaster recovery extract db to staging db
-- AUTHOR		: Phil Scott
-- DATE			: 25 Mar 2011 
-- ************************************************

USE [ReportStagingDB]
GO
/****** Object:  StoredProcedure [dbo].[TransferStagingToExtract]    Script Date: 05/25/2011 14:08:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


Create PROCEDURE [dbo].[TransferExtractToStaging]
	@FromDateTime varchar(19), 
	@ToDateTime varchar(19)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

/******************************************************************/
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[CyclePlannerRequestEvent]
           ([CyclePlannerRequestId]
           ,[Cycle]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [CyclePlannerRequestId]
      ,[Cycle]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[CyclePlannerRequestEvent] 
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[CyclePlannerResultEvent]
           ([CyclePlannerRequestId]
           ,[ResponseCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [CyclePlannerRequestId]
      ,[ResponseCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[CyclePlannerResultEvent] 
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[DataGatewayEvent]
           ([FeedId]
           ,[SessionId]
           ,[FileName]
           ,[TimeStarted]
           ,[TimeFinished]
           ,[SuccessFlag]
           ,[ErrorCode]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [FeedId]
      ,[SessionId]
      ,[FileName]
      ,[TimeStarted]
      ,[TimeFinished]
      ,[SuccessFlag]
      ,[ErrorCode]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[DataGatewayEvent]
   WHERE [TimeStarted] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeStarted] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeStarted]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[EBCCalculationEvent]
           ([Submitted]
           ,[SessionId]
           ,[TimeLogged]
           ,[Success])
SELECT [Submitted]
      ,[SessionId]
      ,[TimeLogged]
      ,[Success]
  FROM [DRExtractDB].[dbo].[EBCCalculationEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[EnhancedExposedServiceEvent]
           ([EESEPartnerId]
           ,[EESEInternalTransactionId]
           ,[EESEExternalTransactionId]
           ,[EESEServiceType]
           ,[EESEOperationType]
           ,[EESEEventTime]
           ,[EESEIsStartEvent]
           ,[EESECallSuccessful]
           ,[TimeLogged])
SELECT [EESEPartnerId]
      ,[EESEInternalTransactionId]
      ,[EESEExternalTransactionId]
      ,[EESEServiceType]
      ,[EESEOperationType]
      ,[EESEEventTime]
      ,[EESEIsStartEvent]
      ,[EESECallSuccessful]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[EnhancedExposedServiceEvent]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[ExposedServicesEvent]
           ([Submitted]
           ,[Token]
           ,[Category]
           ,[Successful]
           ,[TimeLogged])
SELECT [Submitted]
      ,[Token]
      ,[Category]
      ,[Successful]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[ExposedServicesEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[GazetteerEvent]
           ([EventCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged]
           ,[Submitted])
SELECT [EventCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
      ,[Submitted]
  FROM [DRExtractDB].[dbo].[GazetteerEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[GradientProfileEvent]
           ([DisplayCategory]
           ,[Submitted]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [DisplayCategory]
      ,[Submitted]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[GradientProfileEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[InternalRequestEvent]
           ([InternalRequestId]
           ,[SessionId]
           ,[Submitted]
           ,[InternalRequestType]
           ,[Success]
           ,[RefTransaction]
           ,[TimeLogged]
           ,[FunctionType])
SELECT [InternalRequestId]
      ,[SessionId]
      ,[Submitted]
      ,[InternalRequestType]
      ,[Success]
      ,[RefTransaction]
      ,[TimeLogged]
      ,[FunctionType]
  FROM [DRExtractDB].[dbo].[InternalRequestEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[InternationalPlannerEvent]
           ([InternationalPlannerType]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [InternationalPlannerType]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[InternationalPlannerEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[InternationalPlannerRequestEvent]
           ([InternationalPlannerRequestId]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [InternationalPlannerRequestId]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[InternationalPlannerRequestEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[InternationalPlannerResultEvent]
           ([InternationalPlannerRequestId]
           ,[ResponseCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [InternationalPlannerRequestId]
      ,[ResponseCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[InternationalPlannerResultEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[JourneyPlanRequestEvent]
           ([JourneyPlanRequestId]
           ,[Air]
           ,[Bus]
           ,[Car]
           ,[Coach]
           ,[Cycle]
           ,[Drt]
           ,[Ferry]
           ,[Metro]
           ,[Rail]
           ,[Taxi]
           ,[Tram]
           ,[Underground]
           ,[Walk]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[Air]
      ,[Bus]
      ,[Car]
      ,[Coach]
      ,[Cycle]
      ,[Drt]
      ,[Ferry]
      ,[Metro]
      ,[Rail]
      ,[Taxi]
      ,[Tram]
      ,[Underground]
      ,[Walk]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[JourneyPlanRequestEvent]
 WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[JourneyPlanRequestVerboseEvent]
           ([JourneyPlanRequestId]
           ,[JourneyRequestData]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[JourneyRequestData]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[JourneyPlanRequestVerboseEvent]
 WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[JourneyPlanResultsEvent]
           ([JourneyPlanRequestId]
           ,[ResponseCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[ResponseCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[JourneyPlanResultsEvent]
 WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[JourneyPlanResultsVerboseEvent]
           ([JourneyPlanRequestId]
           ,[JourneyResultsData]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[JourneyResultsData]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[JourneyPlanResultsVerboseEvent]
   WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[JourneyWebRequestEvent]
           ([JourneyWebRequestId]
           ,[SessionId]
           ,[Submitted]
           ,[RegionCode]
           ,[Success]
           ,[RefTransaction]
           ,[TimeLogged]
           ,[RequestType])
SELECT [JourneyWebRequestId]
      ,[SessionId]
      ,[Submitted]
      ,[RegionCode]
      ,[Success]
      ,[RefTransaction]
      ,[TimeLogged]
      ,[RequestType]
  FROM [DRExtractDB].[dbo].[JourneyWebRequestEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[LandingPageEvent]
           ([LPPCode]
           ,[LPSCode]
           ,[TimeLogged]
           ,[SessionId]
           ,[UserLoggedOn])
SELECT [LPPCode]
      ,[LPSCode]
      ,[TimeLogged]
      ,[SessionId]
      ,[UserLoggedOn]
  FROM [DRExtractDB].[dbo].[LandingPageEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[LocationRequestEvent]
           ([JourneyPlanRequestId]
           ,[PrepositionCategory]
           ,[AdminAreaCode]
           ,[RegionCode]
           ,[TimeLogged])
SELECT [JourneyPlanRequestId]
      ,[PrepositionCategory]
      ,[AdminAreaCode]
      ,[RegionCode]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[LocationRequestEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[LoginEvent]
           ([SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[LoginEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[MapAPIEvent]
           ([CommandCategory]
           ,[Submitted]
           ,[SessionId]
           ,[TimeLogged])
SELECT [CommandCategory]
      ,[Submitted]
      ,[SessionId]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[MapAPIEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[MapEvent]
           ([CommandCategory]
           ,[Submitted]
           ,[DisplayCategory]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT [CommandCategory]
      ,[Submitted]
      ,[DisplayCategory]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[MapEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]


/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[OperationalEvent]
           ([SessionId]
           ,[Message]
           ,[MachineName]
           ,[AssemblyName]
           ,[MethodName]
           ,[TypeName]
           ,[Level]
           ,[Category]
           ,[Target]
           ,[TimeLogged])
SELECT [SessionId]
      ,[Message]
      ,[MachineName]
      ,[AssemblyName]
      ,[MethodName]
      ,[TypeName]
      ,[Level]
      ,[Category]
      ,[Target]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[OperationalEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/
INSERT INTO [ReportStagingDB].[dbo].[PageEntryEvent]
           ([Page]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged]
           ,[ThemeID])
SELECT [Page]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
      ,[ThemeID]
  FROM [DRExtractDB].[dbo].[PageEntryEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[ReferenceTransactionEvent]
           ([Submitted]
           ,[EventType]
           ,[ServiceLevelAgreement]
           ,[SessionId]
           ,[TimeLogged]
           ,[Successful]
           ,[MachineName])
SELECT [Submitted]
      ,[EventType]
      ,[ServiceLevelAgreement]
      ,[SessionId]
      ,[TimeLogged]
      ,[Successful]
      ,[MachineName]
  FROM [DRExtractDB].[dbo].[ReferenceTransactionEvent]
  WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]

/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[RepeatVisitorEvent]
           ([RepeatVistorType]
           ,[LastVisited]
           ,[SessionIdOld]
           ,[SessionIdNew]
           ,[DomainName]
           ,[UserAgent]
           ,[ThemeId]
           ,[TimeLogged])
SELECT 
       [RepeatVistorType]
      ,[LastVisited]
      ,[SessionIdOld]
      ,[SessionIdNew]
      ,[DomainName]
      ,[UserAgent]
      ,[ThemeId]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[RepeatVisitorEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120) 
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]


/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[RetailerHandoffEvent]
           ([RetailerId]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT 
       [RetailerId]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[RetailerHandoffEvent]
    WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]

/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[RTTIEvent]
           ([StartTime]
           ,[FinishTime]
           ,[DataRecievedSucessfully]
           ,[TimeLogged])
 SELECT 
       [StartTime]
      ,[FinishTime]
      ,[DataRecievedSucessfully]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[RTTIEvent]
  WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
  order by [StartTime]

/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[RTTIInternalEvent]
           ([StartTime]
           ,[EndTime]
           ,[NumberOfRetries]
           ,[Successful]
           ,[TimeLogged])
     SELECT 
       [StartTime]
      ,[EndTime]
      ,[NumberOfRetries]
      ,[Successful]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[RTTIInternalEvent]
   WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [StartTime]

/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[StopEventRequestEvent]
           ([Submitted]
           ,[RequestId]
           ,[RequestType]
           ,[Successful]
           ,[TimeLogged])
   SELECT 
       [Submitted]
      ,[RequestId]
      ,[RequestType]
      ,[Successful]
      ,[TimeLogged]
   FROM [DRExtractDB].[dbo].[StopEventRequestEvent]
    WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]


/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[UserFeedbackEvent]
           ([SessionId]
           ,[SubmittedTime]
           ,[FeedbackType]
           ,[AcknowledgedTime]
           ,[AcknowledgmentSent]
           ,[UserLoggedOn]
           ,[TimeLogged])
    SELECT
       [SessionId]
      ,[SubmittedTime]
      ,[FeedbackType]
      ,[AcknowledgedTime]
      ,[AcknowledgmentSent]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[UserFeedbackEvent]
  WHERE [SubmittedTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [SubmittedTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [SubmittedTime]
  
/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[UserPreferenceSaveEvent]
           ([EventCategory]
           ,[SessionId]
           ,[TimeLogged])
  SELECT 
       [EventCategory]
      ,[SessionId]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[UserPreferenceSaveEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
  
/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[WorkloadEvent]
           ([Requested]
           ,[TimeLogged]
           ,[NumberRequested]
           ,[PartnerId])
SELECT 
       [Requested]
      ,[TimeLogged]
      ,[NumberRequested]
      ,[PartnerId]
  FROM [DRExtractDB].[dbo].[WorkloadEvent]
  WHERE Requested >= CONVERT(datetime, @FromDateTime, 120)
  and Requested <= CONVERT(datetime, @ToDateTime, 120)
    order by Requested




/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[RetailerHandoffEvent]
           ([RetailerId]
           ,[SessionId]
           ,[UserLoggedOn]
           ,[TimeLogged])
SELECT 
       [RetailerId]
      ,[SessionId]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[RetailerHandoffEvent]
    WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]


/******************************************************************/
 
INSERT INTO [ReportStagingDB].[dbo].[RTTIEvent]
           ([StartTime]
           ,[FinishTime]
           ,[DataRecievedSucessfully]
           ,[TimeLogged])
 SELECT 
       [StartTime]
      ,[FinishTime]
      ,[DataRecievedSucessfully]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[RTTIEvent]
  WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
  order by [StartTime]


/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[RTTIInternalEvent]
           ([StartTime]
           ,[EndTime]
           ,[NumberOfRetries]
           ,[Successful]
           ,[TimeLogged])
     SELECT 
       [StartTime]
      ,[EndTime]
      ,[NumberOfRetries]
      ,[Successful]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[RTTIInternalEvent]
   WHERE [StartTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [StartTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [StartTime]


/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[StopEventRequestEvent]
           ([Submitted]
           ,[RequestId]
           ,[RequestType]
           ,[Successful]
           ,[TimeLogged])
   SELECT 
       [Submitted]
      ,[RequestId]
      ,[RequestType]
      ,[Successful]
      ,[TimeLogged]
   FROM [DRExtractDB].[dbo].[StopEventRequestEvent]
    WHERE [Submitted] >= CONVERT(datetime, @FromDateTime, 120)
  and [Submitted] <= CONVERT(datetime, @ToDateTime, 120)
    order by [Submitted]

/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[UserFeedbackEvent]
           ([SessionId]
           ,[SubmittedTime]
           ,[FeedbackType]
           ,[AcknowledgedTime]
           ,[AcknowledgmentSent]
           ,[UserLoggedOn]
           ,[TimeLogged])
    SELECT
       [SessionId]
      ,[SubmittedTime]
      ,[FeedbackType]
      ,[AcknowledgedTime]
      ,[AcknowledgmentSent]
      ,[UserLoggedOn]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[UserFeedbackEvent]
  WHERE [SubmittedTime] >= CONVERT(datetime, @FromDateTime, 120)
  and [SubmittedTime] <= CONVERT(datetime, @ToDateTime, 120)
    order by [SubmittedTime]
  
/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[UserPreferenceSaveEvent]
           ([EventCategory]
           ,[SessionId]
           ,[TimeLogged])
  SELECT 
       [EventCategory]
      ,[SessionId]
      ,[TimeLogged]
  FROM [DRExtractDB].[dbo].[UserPreferenceSaveEvent]
  WHERE [TimeLogged] >= CONVERT(datetime, @FromDateTime, 120)
  and [TimeLogged] <= CONVERT(datetime, @ToDateTime, 120)
  order by [TimeLogged]
 

 
/******************************************************************/

INSERT INTO [ReportStagingDB].[dbo].[WorkloadEvent]
           ([Requested]
           ,[TimeLogged]
           ,[NumberRequested]
           ,[PartnerId])
SELECT 
       [Requested]
      ,[TimeLogged]
      ,[NumberRequested]
      ,[PartnerId]
  FROM [DRExtractDB].[dbo].[WorkloadEvent]
  WHERE Requested >= CONVERT(datetime, @FromDateTime, 120)
  and Requested <= CONVERT(datetime, @ToDateTime, 120)
    order by Requested
