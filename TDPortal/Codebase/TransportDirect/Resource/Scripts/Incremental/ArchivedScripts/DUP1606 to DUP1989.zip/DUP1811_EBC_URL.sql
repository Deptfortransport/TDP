-- ***********************************************
-- NAME 	 		: DUP1811_EBC_URL.sql
-- DESCRIPTION		: Script to update EBC URL for Scotland
-- DATE				: 26 July 2011
-- AUTHOR			: Neil Rankin
-- ************************************************

use Content

GO

EXEC AddtblContent
1, 70,'TDFindEBCPromoHtmlPlaceholderDefinition','/Channels/TransportDirect/JourneyPlanning/FindEBCInput',
'<div class="Column3Header">  <div class="txtsevenbbl">    Freight Grants  </div>  <!-- Don''t remove spaces -->&#160;&#160;</div>  <div class="Column3Content">   <table cellspacing="0" cellpadding="2" width="100%" border="0">      <tbody>        <tr>          <td class="txtseven">     For more information on the freight mode shift grants available in      England, Scotland and Wales covering Freight Facilities Grants (FFG), Mode Shift     Revenue Support (MSRS) and the Waterborne Freight Grant (WFG) please use the links below.     <br />     <br />     <a href="http://www.dft.gov.uk/pgr/freight/" target="_blank">England - Department for Transport <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>     <br />     <br />        <a href="http://transportscotland.gov.uk/road/policy/freight" target="_blank">Scotland - Scottish Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>     <br />     <br />     <a href="http://wales.gov.uk/topics/transport/freight/ffg/" target="_blank">Wales - Welsh Assembly Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>    </td>     </tr>   </tbody>   </table>  </div>',
'<div class="Column3Header">  <div class="txtsevenbbl">    Freight Grants  </div>  <!-- Don''t remove spaces -->&#160;&#160;</div>  <div class="Column3Content">   <table cellspacing="0" cellpadding="2" width="100%" border="0">      <tbody>        <tr>          <td class="txtseven">     For more information on the freight mode shift grants available in      England, Scotland and Wales covering Freight Facilities Grants (FFG), Mode Shift     Revenue Support (MSRS) and the Waterborne Freight Grant (WFG) please use the links below.     <br />     <br />     <a href="http://www.dft.gov.uk/pgr/freight/" target="_blank">England - Department for Transport <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>     <br />     <br />        <a href="http://transportscotland.gov.uk/road/policy/freight" target="_blank">Scotland - Scottish Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>     <br />     <br />     <a href="http://wales.gov.uk/topics/transport/freight/ffg/" target="_blank">Wales - Welsh Assembly Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>    </td>     </tr>   </tbody>   </table>  </div>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1811
SET @ScriptDesc = 'Script to update EBC URL for Scotland'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO