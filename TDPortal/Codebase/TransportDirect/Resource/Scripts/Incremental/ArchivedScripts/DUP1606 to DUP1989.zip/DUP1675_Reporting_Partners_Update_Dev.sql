-- ***********************************************
-- NAME 		: DUP1675_Reporting_Partners_Update_Dev.sql
-- DESCRIPTION 	: Script to add Reporting partners
-- AUTHOR		: Amit Patel
-- DATE			: 15 APR 2010
-- ************************************************

-- ************************* NOTE ************************************
-- THIS UPDATE IS FOR DEVELOPMENT ENVIRONMENT ONLY. THIS SCRIPT SHOULD
-- ONLY RUN IN DEVELOPMENT ENVIRONMENT
-- *******************************************************************

USE [Reporting]  
GO

-- Add the Partner - DirectGov
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =4 and PartnerName = 'DirectGov')BEGIN
 INSERT INTO Partner VALUES (4,'DirectGov','DirectGov','DirectGov')
END

-- Add the Partner - lastminute
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =5 and PartnerName = 'lastminute')BEGIN
 INSERT INTO Partner VALUES (5,'lastminute','lastminute','iframe')
END

-- Add the Partner - journeycall
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =6 and PartnerName = 'journeycall')BEGIN
 INSERT INTO Partner VALUES (6,'journeycall','journeycall','iframes')
END

-- Add the Partner - TransportDirect
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =10 and PartnerName = 'TransportDirect')BEGIN
 INSERT INTO Partner VALUES (10,'transportdirect.test.transportdirect.info','TransportDirect','TransportDirect')
END

-- Add the Partner - VisitBritain
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =11 and PartnerName = 'VisitBritain')BEGIN
 INSERT INTO Partner VALUES (11,'VisitBritain.test.transportdirect.info','VisitBritain','VisitBritain')
END

-- Add the Partner - BBC
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =12 and PartnerName = 'BBC')BEGIN
 INSERT INTO Partner VALUES (12,'BBC.test.transportdirect.info','BBC','BBC')
END

-- Add the Partner - GNER
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =13 and PartnerName = 'GNER')BEGIN
 INSERT INTO Partner VALUES (13,'GNER.test.transportdirect.info','GNER','GNER')
END

-- Add the Partner - DirectGov
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =14 and PartnerName = 'DirectGov')BEGIN
 INSERT INTO Partner VALUES (14,'DirectGov.test.transportdirect.info','DirectGov','DirectGov')
END


-- Add the Partner - Lauren
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =102 and PartnerName = 'Lauren')BEGIN
 INSERT INTO Partner VALUES (102,'Lauren','Lauren','Lauren')
END

-- Add the Partner - Kizoom
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =103 and PartnerName = 'Kizoom')BEGIN
 INSERT INTO Partner VALUES (103,'Kizoom','Kizoom','Kizoom')
END

-- Add the Partner - DirectGov
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =104 and PartnerName = 'DirectGov')BEGIN
 INSERT INTO Partner VALUES (104,'DirectGov','DirectGov','DirectGov')
END

-- Add the Partner - Google
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =108 and PartnerName = 'Google')BEGIN
 INSERT INTO Partner VALUES (108,'Google','Google','Google')
END

-- Add the Partner - Alcatel
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =109 and PartnerName = 'Alcatel')BEGIN
 INSERT INTO Partner VALUES (109,'Alcatel','Alcatel','EES')
END

-- Add the Partner - HubMed
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =110 and PartnerName = 'HubMed')BEGIN
 INSERT INTO Partner VALUES (110,'HubMed','HubMed','HubMed')
END

-- Add the Partner - Breathe
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =114 and PartnerName = 'Breathe')BEGIN
 INSERT INTO Partner VALUES (114,'Breathe','Breathe','EES')
END

-- Add the Partner - businesslink.test.transportdirect.info
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =115 and PartnerName = 'businesslink.test.transportdirect.info')BEGIN
 INSERT INTO Partner VALUES (115,'businesslink.test.transportdirect.info','businesslink.test.transportdirect.info','BusinessLink')
END

-- Add the Partner - DirectGovMob
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =117 and PartnerName = 'DirectGovMob')BEGIN
 INSERT INTO Partner VALUES (117,'DirectGovMob','DirectGovMob','EES')
END

-- Add the Partner - DirectGovAPP
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =118 and PartnerName = 'DirectGovAPP')BEGIN
 INSERT INTO Partner VALUES (118,'DirectGovAPP','DirectGovAPP','EES')
END

-- Add the Partner - ColinBuchanan
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =120 and PartnerName = 'ColinBuchanan')BEGIN
 INSERT INTO Partner VALUES (120,'ColinBuchanan','ColinBuchanan','EES')
END

-- Add the Partner - DirectGovAPP2
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =121 and PartnerName = 'DirectGovAPP2')BEGIN
 INSERT INTO Partner VALUES (121,'DirectGovAPP2','DirectGovAPP2','EES')
END

-- Add the Partner - DirectGovDTV
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =190 and PartnerName = 'DirectGovDTV')BEGIN
 INSERT INTO Partner VALUES (190,'DirectGovDTV','DirectGovDTV','EES')
END

-- Add the Partner - TestDirectGov
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =198 and PartnerName = 'TestDirectGov')BEGIN
 INSERT INTO Partner VALUES (198,'TestDirectGov','TestDirectGov','TestDirectGov')
END

-- Add the Partner - AOCycle -- Cycle white label test partner site
IF NOT EXISTS (SELECT TOP 1 * FROM Partner
WHERE PartnerId =200 and PartnerName = 'AOCycle')BEGIN
 INSERT INTO Partner VALUES (200,'AOCycle','AOCycle','AOCycle')
END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1675
SET @ScriptDesc = 'Script to add partners- BusinessLink, BusinessGateway, AOCycle'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO