-- ***********************************************
-- NAME 		: DUP1752_CyclePlanner_EES_Operation_Types_Reporting.sql
-- DESCRIPTION 	: Script to add Cycle Planner EES Operation Types for reporting
-- AUTHOR		: Amit Patel
-- DATE			: 27 Sep 2008
-- ************************************************

USE [Reporting]
GO

IF NOT EXISTS(SELECT * FROM EnhancedExposedOperationType
				WHERE EEOTType ='PlanCycleJourney')
BEGIN
INSERT INTO EnhancedExposedOperationType
           (EEOTType
           ,EEOTDescription)
     VALUES
           ('PlanCycleJourney'
           ,'PlanCycleJourney operation for CycleJourneyPlannerSynchronous service')
END

IF NOT EXISTS(SELECT * FROM EnhancedExposedOperationType
				WHERE EEOTType ='GetCycleAlgorithms')
BEGIN
INSERT INTO EnhancedExposedOperationType
           (EEOTType
           ,EEOTDescription)
     VALUES
           ('GetCycleAlgorithms'
           ,'GetCycleAlgorithms operation for CycleJourneyPlannerSynchronous service')
END

IF NOT EXISTS(SELECT * FROM EnhancedExposedOperationType
				WHERE EEOTType ='GetCycleAttributes')
BEGIN
INSERT INTO EnhancedExposedOperationType
           (EEOTType
           ,EEOTDescription)
     VALUES
           ('GetCycleAttributes'
           ,'GetCycleAttributes operation for CycleJourneyPlannerSynchronous service')
END

IF NOT EXISTS(SELECT * FROM EnhancedExposedOperationType
				WHERE EEOTType ='GetCycleRequestPreferences')
BEGIN
INSERT INTO EnhancedExposedOperationType
           (EEOTType
           ,EEOTDescription)
     VALUES
           ('GetCycleRequestPreferences'
           ,'GetCycleRequestPreferences operation for CycleJourneyPlannerSynchronous service')
END

IF NOT EXISTS(SELECT * FROM EnhancedExposedOperationType
				WHERE EEOTType ='GetGradientProfile')
BEGIN
INSERT INTO EnhancedExposedOperationType
           (EEOTType
           ,EEOTDescription)
     VALUES
           ('GetGradientProfile'
           ,'GetGradientProfile operation for GradientProfile service')
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1752
SET @ScriptDesc = 'Script to add Cycle Planner EES Operation Types for reporting'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO