-- ***********************************************
-- NAME 		: DUP1920_CyclingEngland_ExternalLink_Update.sql
-- DESCRIPTION 	: Script to update CyclingEngland external link
-- AUTHOR		: Mitesh Modi
-- DATE			: 06 Sep 2012
-- ************************************************


USE [TransientPortal]   
GO


EXEC AddExternalLink  'CycleEngland', 'http://www.dft.gov.uk/bikeability/','http://www.dft.gov.uk/bikeability/','Cycle England bikeability url' 


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1920
SET @ScriptDesc = 'Script to update CyclingEngland external link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO