-- ***********************************************
-- NAME           : DUP1892_NRELink_Content.sql
-- DESCRIPTION    : Script to add NRE logo and link content
-- AUTHOR         : Phil Scott
-- DATE           : 10 Oct 2011
-- ***********************************************

USE [Content] 


EXEC AddtblContent
1, 1,'langStrings','StopInformationDepartureBoardControl.imageNRELogo' 
,'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/NRELogo.gif' 
,'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/NRELogo.gif' 

EXEC AddtblContent
1, 1 ,'langStrings','StopInformationDepartureBoardControl.labelNRELink' 
,'<p>For more information</p><p>see&nbsp;<a href="http://www.nationalrail.co.uk" target="_blank">www.nationalrail.co.uk&nbsp;<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a></p>' 
,'<p>For more information</p><p>see&nbsp;<a href="http://www.nationalrail.co.uk" target="_blank">www.nationalrail.co.uk&nbsp;<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a></p>'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1892
SET @ScriptDesc = 'SScript to add NRE logo and link content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO