-- ***********************************************
-- NAME 		: DUP1759_CyclePlanner_Algorithm_Properties.sql
-- DESCRIPTION 	: Script to add/update Cycle Planner algorithm properties (ATO687)
-- AUTHOR		: Amit Patel
-- DATE			: 15 Oct 2008
-- ************************************************

-- Doc Ref ATO687

-------------------------------------------------------------------------------------
--********************************** WARNING **************************************--
-------------------------------------------------------------------------------------
--	PATH TO THE CYCLE PLANNER FUNCTION DLLS ARE BASED ON DEV ENVIRONMENT		   --
--  PLEASE UPDATE THE PATH IN PROPERTIES TO REFLECT CORRECT PATHS 
--  ACCORDING TO THE SITEST/BBP/ACP ENVIRONMENT THE SCRIPT RUN ON			       --
-------------------------------------------------------------------------------------

USE [PermanentPortal]
GO

--------------------------------------------
-- Cycle penalty function folder - web
--------------------------------------------
------------------------------------------------------
-- Cycle planner penalty function folder
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.Folder' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.Folder', 'C:\CyclePlanner\Services\RoadInterfaceHostingService', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'C:\CyclePlanner\Services\RoadInterfaceHostingService'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Folder'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-----------------------------------------------------------
-- Algorithm Quickest912 -- EES
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Dll', 'td.cp.CyclePenaltyFunctions.v2.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-----------------------------------------------------------
-- Algorithm Quickest912 -- Web
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Dll' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Dll', 'td.cp.CyclePenaltyFunctions.v2.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Dll'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Prefix' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuickestV912.Prefix'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END


-----------------------------------------------------------
-- Algorithm QuietestV912 -- EES
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Dll', 'td.cp.CyclePenaltyFunctions.v2.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-----------------------------------------------------------
-- Algorithm Quickest912 -- Web
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Dll' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Dll', 'td.cp.CyclePenaltyFunctions.v2.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Dll'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Prefix' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.QuietestV912.Prefix'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-----------------------------------------------------------
-- Algorithm RecreationalV912 -- EES
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Dll' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Dll', 'td.cp.CyclePenaltyFunctions.v2.dll', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Dll'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Prefix' 
		and AID = 'EnhancedExposedServices' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'EnhancedExposedServices', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Prefix'
	and AID = 'EnhancedExposedServices' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END

-----------------------------------------------------------
-- Algorithm Quickest912 -- Web
-----------------------------------------------------------

------------------------------------------------------
-- Cycle planner penalty function dll
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Dll' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Dll', 'td.cp.CyclePenaltyFunctions.v2.dll', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'td.cp.CyclePenaltyFunctions.v2.dll'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Dll'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END



------------------------------------------------------
-- Cycle planner penalty function prefix
IF not exists (
	select top 1 * from properties 
	where pName = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Prefix' 
		and AID = 'Web' 
		and GID = 'UserPortal' 
		and PartnerId = 0 
		and ThemeId = 1)
BEGIN
	insert into properties values ('CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Prefix', 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'TransportDirect.JourneyPlanning.CyclePenaltyFunctions'
	where pname = 'CyclePlanner.PlannerControl.PenaltyFunction.RecreationalV912.Prefix'
	and AID = 'Web' 
	and GID = 'UserPortal' 
	and PartnerId = 0 
	and ThemeId = 1
END




GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1759
SET @ScriptDesc = 'Script to add/update Cycle Planner algorithm properties (ATO687)'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO