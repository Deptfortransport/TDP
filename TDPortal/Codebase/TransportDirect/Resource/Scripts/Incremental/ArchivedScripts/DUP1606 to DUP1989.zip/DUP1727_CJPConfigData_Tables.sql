-- ****************************************************************
-- NAME 		: DUP1727_CJPConfigData_Tables.sql
-- DESCRIPTION 	: Creates the table required for CJP config properties
-- AUTHOR		: Amit Patel
-- DATE			: 29 Jun 2010
-- ****************************************************************


USE [TransientPortal] 
GO

-----------------------------------------------
-- ChangeNotification Table
-----------------------------------------------

-- Drop Existing  CJPConfigData Table

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.CJPConfigData') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CJPConfigData]
END
GO



-- Create ChangeNotification table

IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'dbo.CJPConfigData') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[CJPConfigData](
		[pName] [varchar](255) NOT NULL,
		[pValue] [varchar](2000) NULL,
		[AID] [varchar](50) NOT NULL,
		[GID] [varchar](50) NOT NULL,
		[PartnerId] [int] NOT NULL,
		[ThemeId] [int] NOT NULL,
		[ConfigFiles] [varchar](4000) NULL,
		[IsDifferent] [bit] DEFAULT (0),
		[DifferentFiles] [varchar] (4000) NULL
	 CONSTRAINT [PK_PropertieswithPartnerId] PRIMARY KEY CLUSTERED 
	(
		[pName] ASC,
		[AID] ASC,
		[GID] ASC,
		[PartnerId] ASC,
		[ThemeId] ASC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
	) ON [PRIMARY]

END
GO


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1727
SET @ScriptDesc = 'Creates tables for CJP config properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO