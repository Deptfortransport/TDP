-- ***********************************************
-- AUTHOR      	: Neil Rankin
-- NAME 	: DUP1590_Update_Feedback_Welsh_Response_Email_Text
-- DESCRIPTION 	: Update Feedback Response Email Text In Welsh
-- SOURCE 	: TDP Apps Support
-- Version	: $Revision:   1.1  $
-- ************************************************
--


USE [Content]
GO


IF EXISTS (SELECT TOP 1 * FROM tblContent WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment')
BEGIN
	UPDATE tblContent 
    SET [Value-EN] = 'Thank you for providing feedback to Transport Direct. Please be assured that every comment and suggestion made is taken forward for investigation and action as appropriate. We trust you will understand that we are unable to enter into detailed correspondence in response to your message.

Please be aware that it can take some time to effect necessary changes to correct reported errors, especially where third party data is involved (much of our data is supplied by third parties). Nevertheless all data errors are passed on to our suppliers and together we aim to resolve all of the issues you report.

Transport Direct is not responsible for the operation of public transport; therefore we are unfortunately unable to help with issues relating to the operation of bus or rail services. For matters such as this, including enquiries about lost property, or comments about the conduct of members of staff of a transport operator, you should contact the relevant transport operator directly.

If you require information about rail or coach tickets purchased using our retail hand-off facility, you should contact the relevant retail partner directly.

Suggestions on improvements to the usability and functionality of the system, and on extensions to the range of services offered, are always appreciated. Although it may take time to see such suggestions implemented, your views form an important part of our future plans for the Transport Direct Portal.

Once again thank you for taking the trouble to provide us with feedback. We regret that we cannot enter into correspondence through this e-mail address. If you have comments to make in the future please continue to use the feedback system on the Portal.

Yours sincerely
Charlene Goodman
Feedback Manager
Transport Direct'
    WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment'
END

GO


IF EXISTS (SELECT TOP 1 * FROM tblContent WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment')
BEGIN
	UPDATE tblContent 
    SET [Value-Cy] = 'Diolch ichi am roi adborth i Transport Direct. Gallwn eich sicrhau y bydd ymchwil a chamau priodol yn cael eu cymryd o ganlyniad i bob sylw ac awgrym a wneir.  Hyderwn y byddwch yn deall na allwn ohebu�n fanwl � chi wrth ymateb i�ch neges.

Dylech fod yn ymwybodol y gall y broses o wneud newidiadau angenrheidiol i gywiro gwallau a riportiwyd gymryd cryn amser, yn arbennig pan fo data trydydd parti dan sylw (darparwyd llawer o�n data gan drydydd part�on). Er hynny, anfonir yr holl wallau data ymlaen i�n cyflenwyr a chyda�n gilydd rydym yn amcanu i ddatrys yr holl faterion yr ydych yn eu riportio.

Nid yw Transport Direct yn gyfrifol am weithrediad cludiant cyhoeddus; felly yn anffodus ni allwn helpu � materion sy�n gysylltiedig � gwasanaethau bysiau neu drenau. Yn achos materion o�r fath, gan gynnwys ymholiadau ynghylch eiddo coll, neu sylwadau am ymddygiad aelodau staff gweithredwr cludiant, dylech gysylltu�n uniongyrchol �r gweithredwr cludiant perthnasol.

Os oes arnoch angen gwybodaeth am docynnau tr�n neu goets a brynwyd o un o�n cyfleusterau manwerthu cysylltiedig, dylech gysylltu�n uniongyrchol �r partner manwerthu perthnasol.

Mae awgrymiadau ar sut i wella defnyddioldeb ac ymarferoldeb y system, ac ar sut i ymestyn amrediad y gwasanaethau a gynigir, bob amser yn cael eu gwerthfawrogi. Er y gall gymryd amser i weld awgrymiadau o�r fath yn cael eu gweithredu, mae eich barn yn gyfrifol am ran bwysig o�n cynlluniau i�r dyfodol ar gyfer Porthol Transport Direct.

Unwaith eto diolch am fynd i drafferth i roi adborth inni. Mae�n ddrwg gennym na allwn ohebu � chi drwy�r cyfeiriad e-bost hwn. Os bydd gennych sylwadau yn y dyfodol a fyddai�n bosibl ichi barhau i ddefnyddio�r system adborth ar y Porthol.

Yn gywir
Charlene Goodman
Rheolwr Adborth
Transport Direct'
    WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment'
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1590
SET @ScriptDesc = 'Update Feedback Response Email Text WELSH'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO