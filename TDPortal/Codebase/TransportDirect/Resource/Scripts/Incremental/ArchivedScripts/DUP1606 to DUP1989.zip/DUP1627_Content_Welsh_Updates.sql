-- ***********************************************
-- NAME 		: DUP1627_Content_Welsh_Updates.sql
-- DESCRIPTION 	: Script to correct Welsh
-- AUTHOR		: Mitesh Modi
-- DATE			: 18 Mar 2010
-- ************************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindBusInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCoachInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindFlightInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapResult.commandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyChangeSearchControl.genericBackButton.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsCompare.Back',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.imageBackButtonBottom.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.imageBackButtonTop.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'LoginRegisterPage.BackButton.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'ParkAndRideInput.CommandBack.Text',
'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'VisitPlannerInput.CommandBack.Text',
'Back', 'Yn �l'



EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelInternationalFootnote1.Text',
'All journey times include an estimate of city centre to airport/station transfer time, to see the details select ''more''.', 
'Mae holl amseroedd y siwrneiau yn cynnwys amcangyfrif o amser trosglwyddo o ganol y ddinas i''r maes awyr/gorsaf. Dewiswch fwy i weld y manylion.'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyChangeSearchControl.buttonReturnJourney.Text',
'Plan a Return', 'Cynllunio Taith yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelInternationalReturnFootnoteLine1.Text',
'You can plan a return for this journey by using the return button above, please use printer friendly to retain details of this journey.', 
'Gallwch gynllunio taith yn �l ar gyfer y siwrnai hon drwy ddefnyddio''r botwm ''taith yn �l'' uchod, defnyddiwch y dull argraffu-gyfeillgar i gadw manylion y siwrnai hon.'

GO


USE [TransientPortal]
GO

-- Update welsh for left hand links
EXECUTE [TransientPortal].[dbo].[AddResource] 
   'FindCarInput'
  ,'Find a car route'
  ,'Canfyddwch lwybr car'


EXECUTE [TransientPortal].[dbo].[AddResource] 
   'FindBusInput'
  ,'Find a bus'
  ,'Canfyddwch fws'


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1627
SET @ScriptDesc = 'Script to correct Welsh'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO