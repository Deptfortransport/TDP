-- ***********************************************
-- NAME 		: DUP1916_LocationSuggest_DataImport_Update.sql
-- DESCRIPTION 	: Add/Update Location service data import configuration for locations files
-- AUTHOR		: Mitesh Modi
-- DATE			: 04 Sep 2012
-- ************************************************


-- ****************** IMPORTANT **************************
-- Please change the drive letter to be as required for 
-- the environment
-- *******************************************************


USE [PermanentPortal]
GO

-- Drive where gateway sits
DECLARE @Drive varchar(5) = 'C:/'

-- Delete the feeds no longer required (iwa258 and wsa980)
IF EXISTS (SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258')
BEGIN
	DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258'
END
IF EXISTS (SELECT * FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258')
BEGIN
	DELETE FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258'
END

IF EXISTS (SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980')
BEGIN
	DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980'
END
IF EXISTS (SELECT * FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980')
BEGIN
	DELETE FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980'
END


-- Data Import - Location suggest Gaz Filter data
IF EXISTS (SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'mlp069')
BEGIN
	DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'mlp069'
END
IF EXISTS (SELECT * FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'mlp069')
BEGIN
	DELETE FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'mlp069'
END


INSERT INTO [IMPORT_CONFIGURATION] VALUES ('mlp069', 'TransportDirect.Datagateway.Framework.CommandLineImporter', @Drive + 'Gateway/bin/td.datagateway.framework.dll', @Drive + 'Gateway/bat/LocationGazFilterData.bat', '', '', @Drive + 'Gateway/dat/Processing/mlp069');
INSERT INTO [FTP_CONFIGURATION] VALUES (1, 'mlp069', 'LocalHost', 'TDP28Nov', 'sI1732#3-', @Drive + 'Gateway/dat/Incoming/mlp069', './mlp069', '*.zip', 0, 1, '2012-01-01', '', 1);


-- Data Import - Location suggest Alias data, update to existing avf956 feed
IF EXISTS (SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'avf956')
BEGIN
	DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'avf956'
END
IF EXISTS (SELECT * FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'avf956')
BEGIN
	DELETE FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'avf956'
END


INSERT INTO [IMPORT_CONFIGURATION] VALUES ('avf956', 'TransportDirect.UserPortal.LocationService.DropDownLocationProvider.DropDownLocationImporter', 'td.userportal.locationservice.dll', '', @Drive + 'Gateway/bat/LocationAliasData.bat', '', @Drive + 'Gateway/dat/Processing/avf956');
INSERT INTO [FTP_CONFIGURATION] VALUES (1, 'avf956', 'LocalHost', 'TDP28Nov', 'sI1732#3-', @Drive + 'Gateway/dat/Incoming/avf956', './avf956', '*.zip', 0, 1, '2012-01-01', '', 1);

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1916
SET @ScriptDesc = 'Update Location service data import configuration for locations files'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------