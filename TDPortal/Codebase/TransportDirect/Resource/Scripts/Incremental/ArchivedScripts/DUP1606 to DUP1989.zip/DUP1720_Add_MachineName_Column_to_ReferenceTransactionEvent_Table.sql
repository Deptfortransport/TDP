-- *************************************************************************************
-- NAME 		: DUP1720_Add_MachineName_Column_to_ReferenceTransactionEvent_Table.sql
-- DESCRIPTION 		: Add_MachineName_Column_to_ReferenceTransactionEvent_Table
-- *************************************************************************************
USE [ReportStagingDB]
GO

----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('ReferenceTransactionEvent')
						AND syscolumns.name = 'MachineName')
ALTER TABLE ReferenceTransactionEvent ADD MachineName VARCHAR(50) NULL


GO


-- CHANGE LOG
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)
SET @ScriptNumber = 1720

SET @ScriptDesc = 'Add_MachineName_Column_to_ReferenceTransactionEvent_Table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-----------------------------------------