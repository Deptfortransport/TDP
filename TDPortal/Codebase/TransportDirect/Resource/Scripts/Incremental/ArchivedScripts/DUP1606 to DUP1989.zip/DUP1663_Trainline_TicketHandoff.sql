-- ************************************************************
-- NAME         : DUP1663_Trainline_TicketHandoff.sql
-- DESCRIPTION  : Update TheTrainline ticket retail handoff URL
-- AUTHOR		: Richard Hopkins
-- DATE			: 13 April 2010
-- ************************************************************

USE PermanentPortal
GO

UPDATE Retailers
	SET HandoffURL = 'http://www.thetrainline.com/buytickets/datapassedin.aspx'
WHERE RetailerId = 'TRAINLINE'

GO


-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1663
SET @ScriptDesc = 'Update TheTrainline ticket retail handoff URL'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
