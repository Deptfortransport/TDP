-- ***********************************************
-- NAME 		: DUP1856_Greater_Anglia_TOC_Changes.sql
-- DESCRIPTION 	: Script to make changes required for NXEA changing to "Greater Anglia" on 05/02/2012
-- AUTHOR		: Rich Broddle
-- DATE			: 31 Jan 2012
-- ************************************************

USE [PermanentPortal]
GO

--Update Retail Handoff info
IF not exists (select top 1 * from [PermanentPortal].[dbo].[Retailers] where RetailerId = 'ONE')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[Retailers]
           ([RetailerId]
           ,[Name]
           ,[WebsiteURL]
           ,[HandoffURL]
           ,[PhoneNumber]
           ,[DisplayURL]
           ,[IconURL]
           ,[AllowsMTH]
           ,[SmallIconUrl])
     VALUES
           ('ONE'
           ,'Greater Anglia'
           ,NULL
           ,NULL
           ,'0845 600 7245'
           ,NULL
           ,NULL
           ,'N'
           ,NULL)
END
ELSE
BEGIN
	UPDATE [PermanentPortal].[dbo].[Retailers]
	   SET [Name] = 'Greater Anglia'
		  ,[WebsiteURL] = NULL
		  ,[HandoffURL] = NULL
		  ,[PhoneNumber] = '0845 600 7245'
		  ,[DisplayURL] = NULL
		  ,[IconURL] = NULL
		  ,[AllowsMTH] = 'N'
		  ,[SmallIconUrl] = NULL
	WHERE RetailerId = 'ONE'  
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1856
SET @ScriptDesc = 'National Express East Anglia transfer to Greater Anglia '

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO