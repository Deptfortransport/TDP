-- ***********************************************
-- NAME 		: DUP1914_LocationSuggest_DataImport.sql
-- DESCRIPTION 	: Add Location service data import configuration for locations files
-- AUTHOR		: Mitesh Modi
-- DATE			: 24 Aug 2012
-- ************************************************

USE [PermanentPortal]
GO

-- Data Import - Location suggest Gaz Filter data
IF EXISTS (SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258')
BEGIN
	DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258'
END
IF EXISTS (SELECT * FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258')
BEGIN
	DELETE FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'iwa258'
END


INSERT INTO [IMPORT_CONFIGURATION] VALUES ('iwa258', 'TransportDirect.Datagateway.Framework.CommandLineImporter', 'D:/Gateway/bin/td.datagateway.framework.dll', 'D:/Gateway/bat/LocationGazFilterData.bat', '', '', 'D:/Gateway/dat/Processing/iwa258');
INSERT INTO [FTP_CONFIGURATION] VALUES (1, 'iwa258', 'LocalHost', 'TDP28Nov', 'sI1732#3-', 'D:/Gateway/dat/Incoming/iwa258', './iwa258', '*.zip', 0, 1, '2012-01-01', '', 1);

GO


-- Data Import - Location suggest Alias data
IF EXISTS (SELECT * FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980')
BEGIN
	DELETE FROM [IMPORT_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980'
END
IF EXISTS (SELECT * FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980')
BEGIN
	DELETE FROM [FTP_CONFIGURATION] WHERE [DATA_FEED] = 'wsa980'
END


INSERT INTO [IMPORT_CONFIGURATION] VALUES ('wsa980', 'TransportDirect.Datagateway.Framework.CommandLineImporter', 'D:/Gateway/bin/td.datagateway.framework.dll', 'D:/Gateway/bat/LocationAliasData.bat', '', '', 'D:/Gateway/dat/Processing/wsa980');
INSERT INTO [FTP_CONFIGURATION] VALUES (1, 'wsa980', 'LocalHost', 'TDP28Nov', 'sI1732#3-', 'D:/Gateway/dat/Incoming/wsa980', './wsa980', '*.zip', 0, 1, '2012-01-01', '', 1);

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1914
SET @ScriptDesc = 'Add Location service data import configuration for locations files'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------