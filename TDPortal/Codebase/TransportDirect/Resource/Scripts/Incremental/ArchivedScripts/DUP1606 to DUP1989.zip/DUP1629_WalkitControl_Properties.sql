-- ***********************************************
-- NAME 		: DUP1629_WalkitControl_Properties.sql
-- DESCRIPTION 		: Script to modify walk duration required before Walkit is made available
-- AUTHOR		: Richard Hopkins
-- DATE			: 19 March 2010
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'WalkitLinkControl.MinJourneyDetailDuration' and ThemeId = 1)
BEGIN
	insert into properties values ('WalkitLinkControl.MinJourneyDetailDuration', '10', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '13'
	where pname = 'WalkitLinkControl.MinJourneyDetailDuration' and ThemeId = 1
END

GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1629
SET @ScriptDesc = 'Script to set Walkit min duration to 13 minutes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO