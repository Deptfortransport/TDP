-- ***********************************************
-- NAME 		: DUP1734_AddGatewayEventLogProperties.sql
-- DESCRIPTION 	: Script to add Gateway Event Log Properties
-- AUTHOR		: Rich broddle
-- DATE			: 13 Jul 2010
-- ************************************************


USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'Logging.Publisher.EventLog' and GID = 'DataGateway')
BEGIN
	insert into properties values ('Logging.Publisher.EventLog', 'EventLog1', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'EventLog1' where pname = 'Logging.Publisher.EventLog' and ThemeId = 1 and GID = 'DataGateway'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Publisher.EventLog.EventLog1.Machine' and GID = 'DataGateway')
BEGIN
	insert into properties values ('Logging.Publisher.EventLog.EventLog1.Machine', '.', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = '.' where pname = 'Logging.Publisher.EventLog.EventLog1.Machine' and ThemeId = 1 and GID = 'DataGateway'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Publisher.EventLog.EventLog1.Name' and GID = 'DataGateway')
BEGIN
	insert into properties values ('Logging.Publisher.EventLog.EventLog1.Name', 'Application', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Application' where pname = 'Logging.Publisher.EventLog.EventLog1.Name' and ThemeId = 1 and GID = 'DataGateway'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Publisher.EventLog.EventLog1.Source' and GID = 'DataGateway')
BEGIN
	insert into properties values ('Logging.Publisher.EventLog.EventLog1.Source', 'DataGateway', '', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'DataGateway' where pname = 'Logging.Publisher.EventLog.EventLog1.Source' and ThemeId = 1 and GID = 'DataGateway'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Operational.Error.Publishers' and GID = 'DataGateway')
BEGIN
	insert into properties values ('Logging.Event.Operational.Error.Publishers', 'DataGateway', 'Queue1 File1 EventLog1', 'DataGateway', 0, 1)
END
ELSE
BEGIN
	update properties set pvalue = 'Queue1 File1 EventLog1' where pname = 'Logging.Event.Operational.Error.Publishers' and ThemeId = 1 and GID = 'DataGateway'
END


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1734
SET @ScriptDesc = 'Script to add Gateway Event Log Properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO