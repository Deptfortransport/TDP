-- ***********************************************
-- NAME 		: DUP1968_GISQueryEvent_ReportStaging_Tables.sql
-- DESCRIPTION 	: Script to add table for GISQueryEvent
-- AUTHOR		: Mitesh Modi
-- DATE			: 14 Jan 2013
-- ***********************************************

USE [ReportStagingDB]
GO

----------------------------------------------------------------
-- Create [GISQueryEvent] table
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GISQueryEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[GISQueryEvent]
GO

CREATE TABLE [dbo].[GISQueryEvent] (
	[Id] [bigint] IDENTITY (1, 1) NOT NULL ,
	[GISQueryType] [varchar] (50) NULL ,
	[Submitted] [datetime] NULL,
	[TimeLogged] [datetime] NULL 
) ON [PRIMARY]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1968
SET @ScriptDesc = 'Add ReportStaging tables for GISQueryEvent'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
