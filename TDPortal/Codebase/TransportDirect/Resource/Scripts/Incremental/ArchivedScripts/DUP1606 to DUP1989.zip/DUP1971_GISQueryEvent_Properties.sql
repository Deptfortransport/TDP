-- ***********************************************
-- NAME 		: DUP1971_GISQueryEvent_Properties.sql
-- DESCRIPTION 	: Script to add GISQueryEvent logging properties
-- AUTHOR		: Mitesh Modi
-- DATE			: 14 Jan 2013
-- ************************************************

--************************** NOTE ***********************************
-- Update publishers i.e. 'FILE1' according to SITEST/BBP/ACP
----********************************************************************

USE [PermanentPortal]
GO

---------------------------------------------------------------------
-- LOGGING PROPERTIES

-- Define the custom log event
IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GISQUERY.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GISQUERY.Assembly' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GISQUERY.Assembly', 'td.reportdataprovider.tdpcustomevents', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Assembly', 'td.reportdataprovider.tdpcustomevents', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Assembly', 'td.reportdataprovider.tdpcustomevents', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Assembly', 'td.reportdataprovider.tdpcustomevents', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GISQUERY.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GISQUERY.Name' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GISQUERY.Name', 'GISQueryEvent', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Name', 'GISQueryEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Name', 'GISQueryEvent', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Name', 'GISQueryEvent', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Name', 'GISQueryEvent', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Name', 'GISQueryEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Name', 'GISQueryEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GISQUERY.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GISQUERY.Publishers' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GISQUERY.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Publishers', 'FILE1', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Publishers', 'FILE1', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Publishers', 'FILE1', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.GISQUERY.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.GISQUERY.Trace' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.GISQUERY.Trace', 'On', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Trace', 'Off', 'EnhancedExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Trace', 'Off', 'BatchJourneyPlanner', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Trace', 'Off', 'BatchJourneyPlannerService', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.GISQUERY.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


-- Add the custom event to the defined list
IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and pValue LIKE '%GISQUERY%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' GISQUERY' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'Web')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'Web'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and pValue LIKE '%GISQUERY%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' GISQUERY' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'TDRemotingHost')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'TDRemotingHost'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EnhancedExposedServices' and pValue LIKE '%GISQUERY%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' GISQUERY' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EnhancedExposedServices')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EnhancedExposedServices'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'BatchJourneyPlanner' and pValue LIKE '%GISQUERY%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' GISQUERY' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlanner')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlanner'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'BatchJourneyPlannerService' and pValue LIKE '%GISQUERY%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' GISQUERY' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlannerService')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'BatchJourneyPlannerService'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and pValue LIKE '%GISQUERY%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' GISQUERY' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName = 'Logging.Event.Custom' and AID = 'EventReceiver')
	WHERE pName = 'Logging.Event.Custom' and AID = 'EventReceiver'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and pValue LIKE '%GISQUERY%')
BEGIN
	UPDATE properties
	SET pValue = (SELECT pValue + ' GISQUERY' FROM [PermanentPortal].[dbo].[properties]
				  WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EventReceiverGroup')
	WHERE pName LIKE 'Logging.Event.Custom' and AID LIKE 'EventReceiverGroup'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1971
SET @ScriptDesc = 'GISQueryEvent properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO