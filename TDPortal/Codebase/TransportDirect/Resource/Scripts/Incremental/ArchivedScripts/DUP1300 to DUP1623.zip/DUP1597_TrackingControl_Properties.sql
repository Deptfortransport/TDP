-- ***********************************************
-- NAME 		: DUP1597_TrackingControl_Properties.sql
-- DESCRIPTION 		: Script to add tracking control properties
-- AUTHOR		: Parvez Ghumra
-- DATE			: 16 Feb 2010
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'TrackingControl.IncludeTag' and ThemeId = 1)
BEGIN
	insert into properties values ('TrackingControl.IncludeTag', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'TrackingControl.IncludeTag' and ThemeId = 1
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1597
SET @ScriptDesc = 'Script to add tracking control properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO