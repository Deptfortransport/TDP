-- ***********************************************
-- NAME 		: DUP1329_Email_Properties.sql
-- DESCRIPTION 	: Script to add property for Journey Emails 
-- AUTHOR		: Mitesh Modi
-- DATE			: 30 Apr 2009
-- ************************************************

USE [PermanentPortal]
GO

-- clear existing property
delete from properties where pname = 'Web.AmendSaveSendControl.Email.RowLength'

insert into properties values ('Web.AmendSaveSendControl.Email.RowLength', '80', 'Web', 'UserPortal', 0, 1)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1329
SET @ScriptDesc = 'Email property for max row length'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO