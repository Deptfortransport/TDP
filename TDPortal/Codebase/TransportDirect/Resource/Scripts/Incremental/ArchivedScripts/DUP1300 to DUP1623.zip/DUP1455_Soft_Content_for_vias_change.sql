-- ***********************************************
-- AUTHOR      	: John Frank
-- NAME 	: DUP1455_Soft_Content_for_vias_change.sql
-- DESCRIPTION 	: New soft content for the vias change CCN0518
-- ************************************************

USE Content
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneysSearchedForControl.Via',
'via',
'''galw heibio'''

GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 1455)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Soft content for vias.'
	WHERE ScriptNumber = 1455
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (1455, (getDate()), 'Soft content for vias.')
GO