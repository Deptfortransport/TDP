-- ***********************************************
-- NAME 		: DUP1446_TNHierarchy_Properties_correction.sql
-- DESCRIPTION 	: Script to correct properties for Travel News Hierarchy ccn 485a
--				  DUP1413 should have done this but contained an error
-- AUTHOR		: Rich Broddle
-- DATE			: 16 Sept 2009
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'TravelNews.IncidentStatus.Active.AdvancedNotification.Minutes' and ThemeId = 1)
BEGIN
	insert into properties values ('TravelNews.IncidentStatus.Active.AdvancedNotification.Minutes', '60', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '60'
	where pname = 'TravelNews.IncidentStatus.Active.AdvancedNotification.Minutes' and ThemeId = 1
END

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1446
SET @ScriptDesc = 'Added properties for Travel News Hierarchy'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO