-- ***********************************************
-- NAME 			: DUP1433_Add_newwindow_icon_to_RH_Homepage_FreeTools.sql
-- DESCRIPTION 			: Script to add new window icon to Right Hand Menu
-- DESCRIPTION 			: Free Tools section
-- AUTHOR			: Neil Rankin
-- DATE				: 23 September 2009
-- ***********************************************

USE [Content]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Content
--------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT 1
             FROM tblContent 
            WHERE ControlName = 'TDNewInformationHtmlPlaceholderDefinition' and ThemeId = 1)
BEGIN
    UPDATE tblContent 
       SET [Value-En] = '<div class="Column3Header">  <div class="txtsevenbbl">Free Tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>  <div class="Column3Content">  <table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>  <tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" /></td> <td class="txtseven">Does your website have a �How to get here� page? You can now create links that open Transport Direct with your destination pre-set. For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&id=demo&d=524885,184280&dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br /><br />  Download this <a target="_child" href="http://www.dft.gov.uk/excel/256753/intelligentlink.xls">Excel Link generator <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)"></a> or see our   <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)"></a> for more details.</td></tr></tbody></table></div>'
     WHERE [ControlName] = 'TDNewInformationHtmlPlaceholderDefinition' and [ThemeId] = 1

    UPDATE tblContent 
       SET [Value-Cy] = '<div class="Column3Header">  <div class="txtsevenbbl">Free Tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>  <div class="Column3Content">  <table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>  <tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" /></td> <td class="txtseven">Does your website have a �How to get here� page? You can now create links that open Transport Direct with your destination pre-set. For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&id=demo&d=524885,184280&dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br /><br />  Download this <a target="_child" href="http://www.dft.gov.uk/excel/256753/intelligentlink.xls">Excel Link generator <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)"></a> or see our   <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)"></a> for more details.</td></tr></tbody></table></div>'
     WHERE [ControlName] = 'TDNewInformationHtmlPlaceholderDefinition' and [ThemeId] = 1
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1433
SET @ScriptDesc = 'Script to replace Opens in new window with an icon'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO