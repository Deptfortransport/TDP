-- ***********************************************
-- NAME 			: DUP1389_CyclePlanner_LeftHandLinks.sql
-- DESCRIPTION 		: Script to add the Left hand link to the Find Cycle Input page
-- AUTHOR			: Mitesh Modi
-- DATE				: 27 Aug 2009
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- BEING TIDY UP
-- If this script is run multiple times, we can end up with multiple Find a Cycle input links on the Homepage / Plan a Journey Homepage. 
-- So delete them first.


-- Remove any previously added link to Find Cycle Input page that were added, these should only be there for Category: Plan a journey
DELETE     
--SELECT *
FROM    ContextSuggestionLink
WHERE   (SuggestionLinkId IN
                            (SELECT     SuggestionLinkId    -- Get all suggestion links which are for the Plan a journey category
                             FROM          SuggestionLink   -- and use our the FindACycle resource (this is the Find Cycle Input page)
                             WHERE      (LinkCategoryId =
                                             (SELECT     LinkCategoryId
                                              FROM       LinkCategory
                                              WHERE      [name] = 'Plan a journey'))
                             AND (ResourceNameId =
                                      (SELECT     ResourceNameID
                                       FROM       ResourceName
                                       WHERE      ResourceName = 'FindACycle'))))

AND     (ContextId IN    -- And only for the Homepage or Plan a journey mini homepage
            (SELECT     ContextId
             FROM       Context
             WHERE      [Name] = 'HomePageMenu' OR [Name] = 'HomePageMenuPlanAJourney'))



-- Delete the base link previously added to Suggestion Links for Find a Cycle input. 
-- This ensures the correct one is used for the Homepage context, and the Plan a Journey homepage context when added
DELETE
--SELECT *
FROM    SuggestionLink       -- Get all suggestion links which are for the Plan a journey category
WHERE   (LinkCategoryId =    -- and use our FindACycle (Input page) resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Plan a journey')) 
AND     (ResourceNameId = 
                            (SELECT     ResourceNameID
                             FROM       ResourceName
                             WHERE      ResourceName = 'FindACycle'))

GO

-- END TIDY UP
--------------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- BEGIN

----------------------------------------------------------------
-- Set up the Cycle Planner input page link
----------------------------------------------------------------

-- This adds the actual link, and assigns it to the Home page
EXEC AddInternalSuggestionLink

	'JourneyPlanning/FindCycleInput.aspx',      -- Relative internal link URL
	'Find a cycle',                             -- Description of internal link. Ensure this is a unique internal link description
	'FindACycle',			                    -- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Find a cycle route',		                -- English display text. Populate only if adding new ResourceName or updating existing display text
	'Canfod llwybr beicio',		            -- Welsh display text. Populate only if adding new ResourceName or updating existing display text	
	'Plan a journey',				            -- Category Name (LinkCategory) -- Use 'General' if not a left hand navigation link
	130,						                -- Priority must be unique for the selected CategoryName this link is for
	0,						                    -- Set to 0 if to be used as a Suggestion/Related Link
	0,						                    -- Set to 1 if it is a second level Root link
	'HomePageMenu',	                            -- Context Name (Context) -- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',						                    -- Populate only if adding a new ContextName, or updating description
	1						                    -- Theme this link is added for, use 1 as default

GO

-- This adds it to the Plan a journey mini homepage, and all pages which display the Plan a journey's left nav
-- NOTE: we use the same physical Internal link record, but have a new Suggestion Link with a different priority
EXEC AddInternalSuggestionLink

	'JourneyPlanning/FindCycleInput.aspx',      
	'Find a cycle',                             
	'FindACycle',			                    
	'Find a cycle route',		                
	'Canfod llwybr beicio',		            
	'Plan a journey',				            
	2110,						                
	0,						                    
	0,						                    
	'HomePageMenuPlanAJourney',	                            
	'',						                    
	1						                    

GO


-- Add the new Find a Cycle input page link for the Whitelabel partner sites

------------------------HomePageMenu

-- VisitBritain
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenu',		-- Context Name (Context)
	2					-- Theme

-- BBC
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenu',		-- Context Name (Context)
	3					-- Theme

-- DirecGov
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenu',		-- Context Name (Context)
	5					-- Theme

-- BusinessLink
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenu',		-- Context Name (Context)
	6					-- Theme

-- BusinessGateway
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenu',		-- Context Name (Context)
    7					-- Theme


---------------- HomePageMenuPlanAJourney

-- VisitBritain
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenuPlanAJourney',		-- Context Name (Context)
	2					-- Theme

-- BBC
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenuPlanAJourney',		-- Context Name (Context)
	3					-- Theme

-- DirecGov
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenuPlanAJourney',		-- Context Name (Context)
	5					-- Theme

-- BusinessLink
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenuPlanAJourney',		-- Context Name (Context)
	6					-- Theme

-- BusinessGateway
EXEC AddContextSuggestionLink

	'FindACycle',	    -- Resource Name (ResourceName) ResourceNameID 111
	'Plan a journey',	-- Category Name (LinkCategory)
	'HomePageMenuPlanAJourney',		-- Context Name (Context)
    7					-- Theme

-- END
--------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1389
SET @ScriptDesc = 'Cycle Planner - Left hand link to Input page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO