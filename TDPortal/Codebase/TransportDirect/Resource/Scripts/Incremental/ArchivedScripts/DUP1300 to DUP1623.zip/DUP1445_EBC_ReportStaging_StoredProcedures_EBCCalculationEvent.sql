-- ***********************************************
-- NAME 		: DUP1445_EBC_ReportStaging_StoredProcedures_EBCCalculationEvent.sql
-- DESCRIPTION 		: Script to add stored procedures to create EBCCalculationEvents
-- AUTHOR		: Mitesh Modi
-- DATE			: 5 Oct 2009
-- ************************************************

USE [ReportStagingDB]
GO


-- ****IMPORTANT****
-- If running this script in the Production environment, please uncomment the lines with value "ReportServer.", and comment out the line below it.
-- There are 2 instances of this in the script.

----------------------------------------------------------------
-- Create AddEBCCalculationEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddEBCCalculationEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddEBCCalculationEvent 
        (@Submitted datetime,
         @SessionId varchar(50), 
         @TimeLogged datetime,
		 @Success bit)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO


----------------------------------------------------------------
-- Update AddEBCCalculationEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE AddEBCCalculationEvent (@Submitted datetime, @SessionId varchar(50), @TimeLogged datetime, @Success bit)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into EBCCalculationEvent Table'

    Insert into EBCCalculationEvent (Submitted, SessionId, TimeLogged, Success)
    Values (@Submitted, @SessionId, @TimeLogged, @Success)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Create TransferEBCCalculationEvents stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferEBCCalculationEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE TransferEBCCalculationEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferEBCCalculationEvents stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE TransferEBCCalculationEvents
	@Date varchar(10)
AS
SET NOCOUNT ON
SET DATEFIRST 1
SET XACT_ABORT ON

--DELETE FROM [ReportServer].[Reporting].[dbo].[EBCCalculationEvents]
DELETE FROM [Reporting].[dbo].[EBCCalculationEvents]
WHERE CONVERT(varchar(10), EBCDate, 121) = @Date

--INSERT INTO [ReportServer].[Reporting].[dbo].[EBCCalculationEvents]
INSERT INTO [Reporting].[dbo].[EBCCalculationEvents]
(
	EBCDate,
	EBCHour,
	EBCHourQuarter,
	EBCWeekDay,
	EBCCount,
	EBCAvMsDuration
)
SELECT 
	CAST(CONVERT(varchar(10), EBCCE.Submitted, 121) AS datetime) AS EBCDate,
	DATEPART(hour, EBCCE.Submitted) AS EBCHour,
	CAST(DATEPART(minute, EBCCE.Submitted) / 15 AS smallint) AS EBCHourQuarter,
	DATEPART(weekday, EBCCE.Submitted) AS EBCWeekDay,
	AVG(CAST(DATEDIFF(millisecond, EBCCE.Submitted, EBCCE.TimeLogged) AS decimal(18, 0))) AS EBCAvMsDuration,
	COUNT(*) AS EBCCount

  FROM EBCCalculationEvent EBCCE

  WHERE CONVERT(varchar(10), EBCCE.Submitted, 121) = @Date
  GROUP BY
	CAST(CONVERT(varchar(10), EBCCE.Submitted, 121) AS datetime),
	DATEPART(hour, EBCCE.Submitted),
	CAST(DATEPART(minute, EBCCE.Submitted) / 15 AS smallint),
	DATEPART(weekday, EBCCE.Submitted)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1445
SET @ScriptDesc = 'Add ReportStaging stored procedures for EBCCalculationEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO