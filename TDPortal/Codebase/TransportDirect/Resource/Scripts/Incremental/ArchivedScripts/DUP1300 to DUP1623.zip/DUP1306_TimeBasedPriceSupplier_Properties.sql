-- ***********************************************
-- NAME 			: DUP1306_TimeBasedPriceSupplier_Properties.sql
-- DESCRIPTION 		: Script to insert the TimeBasedPriceSupplier properties
-- AUTHOR			: Amit Patel
-- DATE				: 09 Mar 2009
-- ***********************************************

USE [PermanentPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- PROPERTIES
--------------------------------------------------------------------------------------------------------------------------------

DELETE FROM properties WHERE pName = 'TimeBasedPriceSupplier.AppServerWaitInMiliSecondsForWebServer'

DELETE FROM properties WHERE pName = 'TimeBasedPriceSupplier.AppServerWaitCountForWebServer'


INSERT INTO properties VALUES ('TimeBasedPriceSupplier.AppServerWaitInMiliSecondsForWebServer', '1000', '<DEFAULT>', '<DEFAULT>' ,0,1)

INSERT INTO properties VALUES ('TimeBasedPriceSupplier.AppServerWaitCountForWebServer', '30', '<DEFAULT>', '<DEFAULT>' ,0,1)
    

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1306
SET @ScriptDesc = 'Script to insert the TimeBasedPriceSupplier properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO