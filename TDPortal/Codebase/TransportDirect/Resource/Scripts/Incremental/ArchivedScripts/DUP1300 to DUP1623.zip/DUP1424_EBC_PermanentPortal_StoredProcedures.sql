-- ***********************************************
-- NAME 		: DUP1424_EBC_PermanentPortal_StoredProcedures.sql
-- DESCRIPTION 	: Script to add stored procedures for EBC tables
-- AUTHOR		: Mitesh Modi
-- DATE			: 22 Sep 2009
-- ************************************************

USE [PermanentPortal]
GO

-- ********************* IMPORTANT ************************
-- Please ensure appropriate execute permissions are added to the stored procedures to allow the web and app servers access
-- ********************************************************


----------------------------------------------------------------
-- GetEnvBenRoadCategoryCosts stored proc

-- Create
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEnvBenRoadCategoryCosts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetEnvBenRoadCategoryCosts 
        AS

    ')
END

GO

-- Update
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE GetEnvBenRoadCategoryCosts
AS
BEGIN
	SELECT	RoadCategory,
			Country,
			PencePerMile
	FROM EnvBenRoadCategoryCost	
END
    
GO
----------------------------------------------------------------


----------------------------------------------------------------
-- GetEnvBenHighValueMotorways stored proc

-- Create
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEnvBenHighValueMotorways]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetEnvBenHighValueMotorways
        AS

    ')

END
GO

-- Update
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE GetEnvBenHighValueMotorways
AS
BEGIN
	SELECT	MotorwayName,
			AllHighValue,
			DuplicateMotorwayJunction
	FROM EnvBenHighValueMotorway
END
    
GO
----------------------------------------------------------------


----------------------------------------------------------------
-- GetEnvBenHighValueMotorwayJunctions stored proc

-- Create
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEnvBenHighValueMotorwayJunctions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetEnvBenHighValueMotorwayJunctions
        AS

    ')

END
GO

-- Update
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE GetEnvBenHighValueMotorwayJunctions
AS
BEGIN
	SELECT	MotorwayName,
			JunctionStart,
			JunctionEnd,
			Distance,
			Country
	FROM EnvBenHighValueMotorwayJunction
END
    
GO
----------------------------------------------------------------


----------------------------------------------------------------
-- GetEnvBenUnknownMotorwayJunction stored proc

-- Create
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetEnvBenUnknownMotorwayJunctions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetEnvBenUnknownMotorwayJunctions
        AS

    ')

END
GO

-- Update
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE GetEnvBenUnknownMotorwayJunctions
AS
BEGIN
	SELECT	MotorwayName,
			JoiningRoad,
			JoiningJunction,
			JunctionEntry,
			JunctionExit
	FROM EnvBenUnknownMotorwayJunction
END
    
GO
----------------------------------------------------------------


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1424
SET @ScriptDesc = 'Add stored procedures for EBC tables'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO