-- ***********************************************
-- NAME 		: DUP1420_EBC_Reporting_PageEntry.sql
-- DESCRIPTION 		: Added reporting page entry event type for EBC
-- AUTHOR		: Mitesh Modi
-- DATE			: 14 Sep 2009
-- ************************************************

USE [Reporting]
GO

-- Add new page entries for reporting
IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindEBCInput') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindEBCInput', 'Find EBC Input' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'EBCJourneyDetails') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'EBCJourneyDetails', 'EBC journey details' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'EBCJourneyMap') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'EBCJourneyMap', 'EBC journey map' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableEBCJourneyDetails') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'PrintableEBCJourneyDetails', 'Printable ECB journey details' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableEBCJourneyMap') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'PrintableEBCJourneyMap', 'Printable EBC journey map' FROM PageEntryType
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1420
SET @ScriptDesc = 'Added EBC page entry event types'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO