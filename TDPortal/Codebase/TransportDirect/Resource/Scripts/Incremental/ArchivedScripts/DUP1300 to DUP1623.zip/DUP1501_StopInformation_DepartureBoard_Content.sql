-- ***********************************************
-- NAME 		: DUP1501_StopInformation_DepartureBoard_Content.sql
-- DESCRIPTION 		: Script to add Stop Information page departure board control content
-- AUTHOR		: Amit Patel
-- DATE			: 21 Oct 2009
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.labelDepartureBoardTitle.Departures.Text', 'Next departures', 'cy Next departures'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.labelDepartureBoardTitle.Arrivals.Text', 'Next arrivals', 'cy Next arrivals'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.labelDepartureBoardTime.Text', 'On {0}', 'cy On {0}'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.imageDepartureBoardUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/Departures2.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/Departures2.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.imageArrivalBoardUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/arrivals2.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/arrivals2.gif'


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.imageDepartureBoardUrl.AlternateText', 'Departure boards', 'Byrddau ymadael byw'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.imageArrivalBoardUrl.AlternateText', 'Arrival boards', 'cy Arrival boards'



Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1501
SET @ScriptDesc = 'Script to add Stop Information page departure board control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO