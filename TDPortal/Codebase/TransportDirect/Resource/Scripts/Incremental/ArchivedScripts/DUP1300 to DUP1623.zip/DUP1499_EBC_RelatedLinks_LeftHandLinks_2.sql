-- ***********************************************
-- NAME 			: DUP1499_EBC_RelatedLinks_LeftHandLinks_2.sql
-- DESCRIPTION 		: Script to add the Related links to the EBC Input page
-- AUTHOR			: Mitesh Modi
-- DATE				: 23 Oct 2009
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- BEGIN TIDY UP
-- Remove any previously added Related Links that we added for the EBC planner

DECLARE @ContextId INT

-- Remove any previously added Related Links that were added for the EBC planner
IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindEBCInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindEBCInput')

	DELETE 
    --SELECT *
	FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END

GO


-- Delete the base links previously added to Suggestion Links for the Related links on the EBC input page 
-- Ensures the correct one is used for the RelatedLinksContextFindEBCInput context when added
DELETE
--SELECT *
FROM    SuggestionLink       -- Get all suggestion links which are for the Related links category
WHERE   (LinkCategoryId =    -- and are for the EBC related links resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Related links'))
AND     (ResourceNameId IN ( 
                            (SELECT     ResourceNameID
                             FROM       ResourceName
                             WHERE      ResourceName LIKE 'EBC.%'))) -- All the EBC link Resources start with this

GO

-- END TIDY UP
--------------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for EBC input page
-- CURRRENTLY NO RELATED LINKS ARE DEFINED SO NONE ARE ADDED

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextFindEBCInput'
SET @ThemeId = 1


-- Add our new context for EBC input page related links
EXEC AddContext
    
    @ContextName,                            						-- Context
    'Related Link Context - Suggestions for EBC input Page'			-- Context description


-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


-- Add the actual links. ensure all our link names start with "EBC."
EXEC AddExternalSuggestionLink

	'EBC.FreightBestPractice',									-- ID for ExternalLink table
	'http://www.freightbestpractice.org.uk/multi-modal',      	-- Full external link URL
	'http://www.freightbestpractice.org.uk/multi-modal',		-- Full test external link URL
	'EBC - Freight Best Practice',                              -- Description of external link. Ensure this is a unique external link description   
	'EBC.FreightBestPractice',									-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'DfT freight best practice',								-- English display text. Populate only if adding new ResourceName or updating existing display text
	'DfT freight best practice',								-- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
	'Related links',                                            -- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
	1760,						                                -- Priority must be unique for the selected CategoryName this link is for
	0,                                                          -- Set to 0 if to be used as a Suggestion/Related Link
	0,                                                          -- Set to 1 if it is a second level Root link
	@ContextName,                                               -- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',                                                         -- Populate only if adding a new ContextName, or updating description
	@ThemeId                                                    -- Theme this link is added for, use 1 as default



GO

-- END
--------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1499
SET @ScriptDesc = 'EBC - Related links left navigation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO