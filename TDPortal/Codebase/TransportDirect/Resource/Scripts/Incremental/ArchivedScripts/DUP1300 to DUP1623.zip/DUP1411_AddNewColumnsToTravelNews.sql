-- *************************************************************************************
-- NAME 		: DUP1411_AddNewColumnsToTravelNews.sql
-- DESCRIPTION  : Add New Columns To Travel News for Hierarchy, Times of Roadworks and RSS
-- AUTHOR		: Rich Broddle
-- DATE			: 15 Sept 2009 15:30:00
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER
USE [TransientPortal]
GO
ALTER TABLE [dbo].[TravelNews] ADD 
	[IncidentParent] [varchar](25) NULL,
	[CarriagewayDirection] [varchar](15)  NULL,
	[RoadNumber] [varchar](25) NULL,
	[DayMask] [varchar](14) NULL,
	[DailyStartTime] [time](7) NULL,
	[DailyEndTime] [time](7) NULL,
	[ItemChangeStatus] [varchar](9) NULL
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1411
SET @ScriptDesc = 'Add New Columns To Travel News for Hierarchy, Times of Roadworks and RSS'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
