-- ***********************************************
-- NAME 		: DUP1571_InternationalPlanner_Properties.sql
-- DESCRIPTION 	: Script to add international planner properties
-- AUTHOR		: Amit Patel
-- DATE			: 25 Jan 2010
-- ************************************************

USE [PermanentPortal]
GO

-- ********************* IMPORTANT ******************************
-- Please ensure the AID and GID values are correctly set, in particular the TDRemotingHost settings
-- **************************************************************

---------------------------------------------------------------
-- InternationalData Database connection property
---------------------------------------------------------------
IF not exists (select top 1 * from properties where pName = 'InternationalDataDB' and ThemeId = 1)
BEGIN
	insert into properties values (
		'InternationalDataDB', 
		'Server=.;Initial Catalog=InternationalData;Trusted_Connection=true;', 
		'<DEFAULT>', 
		'<DEFAULT>', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Server=.;Initial Catalog=InternationalData;Trusted_Connection=true;'
	where pname = 'InternationalDataDB' and ThemeId = 1
END

---------------------------------------------------------------
-- Switches International Planner on/off
---------------------------------------------------------------
-- Switches International Planner on/off at the Validate and Run level
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.Available' and ThemeId = 1)
BEGIN
	insert into properties values ('InternationalPlanner.Available', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.Available' and ThemeId = 1
END

-- Switches International Planner links/icons on/off
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.FindInternationalAvailable' and ThemeId = 1)
BEGIN
	insert into properties values ('InternationalPlanner.FindInternationalAvailable', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.FindInternationalAvailable' and ThemeId = 1
END

---------------------------------------------------------------
-- International Planner Control Properties, for both Web and TDRemotingHost
---------------------------------------------------------------

-- Log Requests or not
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogAllRequests' and ThemeId = 1 and AID = 'Web')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogAllRequests', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogAllRequests' and ThemeId = 1 and AID = 'Web'
END

IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogAllRequests' and ThemeId = 1 and AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogAllRequests', 'True', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogAllRequests' and ThemeId = 1 and AID = 'TDRemotingHost'
END


-- Log Responses or not
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogAllResponses' and ThemeId = 1 and AID = 'Web')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogAllResponses', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogAllResponses' and ThemeId = 1 and AID = 'Web'
END


IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogAllResponses' and ThemeId = 1 and AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogAllResponses', 'True', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogAllResponses' and ThemeId = 1 and AID = 'TDRemotingHost'
END


-- Log Failures or not
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogInternationalPlannerFailures' and ThemeId = 1 and AID = 'Web')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogInternationalPlannerFailures', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogInternationalPlannerFailures' and ThemeId = 1 and AID = 'Web'
END

IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogInternationalPlannerFailures' and ThemeId = 1 and AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogInternationalPlannerFailures', 'True', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogInternationalPlannerFailures' and ThemeId = 1 and AID = 'TDRemotingHost'
END


-- Log No of Journey Responses or not
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogNoJourneyResponses' and ThemeId = 1 and AID = 'Web')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogNoJourneyResponses', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogNoJourneyResponses' and ThemeId = 1 and AID = 'Web'
END

IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.LogNoJourneyResponses' and ThemeId = 1 and AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.LogNoJourneyResponses', 'True', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'InternationalPlanner.PlannerControl.LogNoJourneyResponses' and ThemeId = 1 and AID = 'TDRemotingHost'
END


-- Min user type logging
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.MinUserTypeLogging' and ThemeId = 1 and AID = 'Web')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.MinUserTypeLogging', '1', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '1'
	where pname = 'InternationalPlanner.PlannerControl.MinUserTypeLogging' and ThemeId = 1 and AID = 'Web'
END

IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.MinUserTypeLogging' and ThemeId = 1 and AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.MinUserTypeLogging', '1', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '1'
	where pname = 'InternationalPlanner.PlannerControl.MinUserTypeLogging' and ThemeId = 1 and AID = 'TDRemotingHost'
END


-- Time out in milliseconds
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.TimeoutMillisecs' and ThemeId = 1 and AID = 'Web')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.TimeoutMillisecs', '60000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '60000'
	where pname = 'InternationalPlanner.PlannerControl.TimeoutMillisecs' and ThemeId = 1 and AID = 'Web'
END

IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.PlannerControl.TimeoutMillisecs' and ThemeId = 1 and AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('InternationalPlanner.PlannerControl.TimeoutMillisecs', '60000', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '60000'
	where pname = 'InternationalPlanner.PlannerControl.TimeoutMillisecs' and ThemeId = 1 and AID = 'TDRemotingHost'
END


---------------------------------------------------------------
-- International Journey Planning Properties, for both Web and TDRemotingHost
---------------------------------------------------------------

-- Journey Start Time 
IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.Journey.StartTime' and ThemeId = 1 and AID = 'Web')
BEGIN
	insert into properties values ('InternationalPlanner.Journey.StartTime', '0400', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0400'
	where pname = 'InternationalPlanner.Journey.StartTime' and ThemeId = 1 and AID = 'Web'
END

IF not exists (select top 1 * from properties where pName = 'InternationalPlanner.Journey.StartTime' and ThemeId = 1 and AID = 'TDRemotingHost')
BEGIN
	insert into properties values ('InternationalPlanner.Journey.StartTime', '0400', 'TDRemotingHost', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0400'
	where pname = 'InternationalPlanner.Journey.StartTime' and ThemeId = 1 and AID = 'TDRemotingHost'
END


---------------------------------------------------------------
-- Wait Page Properties
---------------------------------------------------------------

-- Wait page refresh interval
IF not exists (select top 1 * from properties where pName = 'WaitPageRefreshSeconds.FindInternational' and ThemeId = 1)
BEGIN
	insert into properties values ('WaitPageRefreshSeconds.FindInternational', '3', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '3'
	where pname = 'WaitPageRefreshSeconds.FindInternational' and ThemeId = 1
END

---------------------------------------------------------------
-- FindSummaryResultControl Properties
---------------------------------------------------------------

-- property defining scrollbar to show after number of journeys defined by value of the property
IF not exists (select top 1 * from properties where pName = 'FindSummaryResultControl.Scrollpoint.International' and ThemeId = 1)
BEGIN
	insert into properties values ('FindSummaryResultControl.Scrollpoint.International', '10', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '10'
	where pname = 'FindSummaryResultControl.Scrollpoint.International' and ThemeId = 1
END

-- property defining hight for the summary result control
IF not exists (select top 1 * from properties where pName = 'FindSummaryResultControl.FixedHeight.International' and ThemeId = 1)
BEGIN
	insert into properties values ('FindSummaryResultControl.FixedHeight.International', '200px', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '200px'
	where pname = 'FindSummaryResultControl.FixedHeight.International' and ThemeId = 1
END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1571
SET @ScriptDesc = 'Script to add International planner properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO