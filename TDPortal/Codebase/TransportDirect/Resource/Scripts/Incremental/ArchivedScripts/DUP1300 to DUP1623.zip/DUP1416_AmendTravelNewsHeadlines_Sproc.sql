-- *************************************************************************************
-- NAME 		: DUP1416_AmendTravelNewsHeadlines_Sproc.sql
-- DESCRIPTION  : Amend Travel News Headlines Sproc for Hierarchy, & Roadworks
-- AUTHOR		: Rich Broddle
-- DATE			: 16 Sept 2009 13:30:00
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER
USE [TransientPortal]
GO

-------------------------------------------------------------------------------------------
--Create IsTravelNewsItemActive function to be used by Travel News Headlines Sproc and RSS.
-------------------------------------------------------------------------------------------

--This function will have a Bit return value, and contain logic to 
--determine wether a travel news incident is active according to it�s daymask, 
--start time, end time, and the value of the 
--TravelNews.IncidentStatus.AdvancedNotification.Minutes property 
--The function will allow for non � contiguous days in the daymask, 
--and an end time which is earlier than the start time to indicate an overmidnight incident.

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = 'IsTravelNewsItemActive' AND ROUTINE_TYPE = N'FUNCTION')
BEGIN     
	EXEC ('CREATE FUNCTION [dbo].[IsTravelNewsItemActive]() RETURNS Bit AS BEGIN RETURN 1 END')
END
GO

ALTER FUNCTION [dbo].[IsTravelNewsItemActive]
(   @NewsItemDaymask	varchar(14), @NewsItemStartTime	TIME, @NewsItemEndTime	TIME,
	@ComparisonDate    DATETIME)
	
RETURNS Bit
AS
BEGIN
		--Clean up input parameters - Default to active all the time so we will SHOW incidents if no details given
	If @NewsItemStartTime IS NULL
		BEGIN
			SET @NewsItemStartTime = '00:00:00'
		END
	If @NewsItemEndTime IS NULL
		BEGIN
			SET @NewsItemEndTime = '23:59:59'
		END
	If (@NewsItemDaymask = '' OR  @NewsItemDaymask IS NULL)
		BEGIN
			SET @NewsItemDaymask = 'SuMoTuWeThFrSa'
		END

	DECLARE @COMPARISONTIME TIME, @NewsItemStartTimeAdjusted TIME
	DECLARE @COMPARISONDAY CHAR(2), @COMPARISONDAYMINUS1 CHAR(2)
	DECLARE @ADVANCEDNOTIFICATIONMINS INT, @RETURNVAL BIT
	
	
	--Adjust Start time for the advanced notification period defined in Properties DB
	SET @ADVANCEDNOTIFICATIONMINS = (SELECT pValue FROM PermanentPortal.dbo.properties WHERE pName = 'TravelNews.IncidentStatus.Active.AdvancedNotification.Minutes') 
	SET @NewsItemStartTimeAdjusted = DATEADD(mi,(0-@ADVANCEDNOTIFICATIONMINS), @NewsItemStartTime)
	If (@NewsItemStartTimeAdjusted > @NewsItemStartTime)
		--If start time after adjustment > orig start time we've gone back over midnight
		--dont want to do that so just set it to midnight
		BEGIN
			SET @NewsItemStartTimeAdjusted = '00:00:00'
		END
	--Get time part of comparison date by simply putting it in TIME data type
	SET @COMPARISONTIME = @ComparisonDate
	--Get 2 char day parts for comparison
	SET @COMPARISONDAY = LEFT(DATENAME(dw, @ComparisonDate),2)
	SET @COMPARISONDAYMINUS1 = LEFT(DATENAME(dw, DATEADD(day, -1, @ComparisonDate)),2)

	If (@NewsItemStartTime > @NewsItemEndTime ) 
		--Start time is after end time - overmidnight incident
		BEGIN
			--Return true if day matches and time between news start time and midnight...
			If (CHARINDEX(@COMPARISONDAY,@NewsItemDaymask) <> 0   
				AND @COMPARISONTIME > @NewsItemStartTimeAdjusted)  
				--or if day - 1 matches and time is between midnight and news end time...
				OR (CHARINDEX(@COMPARISONDAYMINUS1,@NewsItemDaymask) <> 0 
					AND @COMPARISONTIME < @NewsItemEndTime)
					SET @RETURNVAL = 1
			Else
				--return false
					SET @RETURNVAL = 0
		END
	Else
		--Start time before end time - nice and simple not overmidnight
		BEGIN
			--Return true if day matches and time between news 
			--item start time and news item end time...
			If (CHARINDEX(@COMPARISONDAY,@NewsItemDaymask) <> 0 
				AND (@COMPARISONTIME BETWEEN @NewsItemStartTimeAdjusted AND @NewsItemEndTime))  
					SET @RETURNVAL = 1
			Else
					SET @RETURNVAL = 0
		END
	RETURN @RETURNVAL
END

GO

-------------------------------------------------------------------------------------------
--Create TravelNewsHeadlines Stored Procedure
-------------------------------------------------------------------------------------------

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = 'TravelNewsHeadlines' AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
    EXEC ('CREATE PROCEDURE [dbo].[TravelNewsHeadlines] AS BEGIN SELECT 1 END')
END
GO 

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[TravelNewsHeadlines]
AS
SET NOCOUNT ON

SELECT
	TN.UID,
	TN.SeverityLevel,
	TN.HeadlineText,
	TN.SeverityLevel,
	TN.ModeOfTransport,
	TN.Regions,
	DateDiff(mi, TN.StartDateTime, GetDate()) StartToNowMinDiff
FROM TravelNews TN
WHERE TN.SeverityLevel < 4
  AND TN.SeverityLevel <> 1
  AND StartDateTime <=getdate() 
  AND ExpiryDateTime >=getdate()
  AND TN.IncidentStatus ='O'
  AND ISNULL(TN.IncidentParent,'0') IN ('0','')
  AND dbo.IsTravelNewsItemActive(TN.DayMask,TN.DailyStartTime, TN.DailyEndTime,GETDATE()) = 1
        AND EXISTS (SELECT * FROM TravelNewsDataSource TNDS1
				INNER JOIN TravelNewsDataSources TNDSS
				ON TNDS1.DataSourceId = TNDSS.DataSourceId
				WHERE TNDS1.UID = TN.UID AND TNDSS.Trusted = 1)
ORDER BY SeverityLevel ASC, StartDateTime DESC

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1416
SET @ScriptDesc = 'Amend Travel News Headlines Sproc for Hierarchy, & Roadworks'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO