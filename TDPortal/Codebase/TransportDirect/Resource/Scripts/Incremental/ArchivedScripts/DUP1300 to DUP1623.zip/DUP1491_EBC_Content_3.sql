-- ***********************************************
-- NAME 		: DUP1491_EBC_Content_3.sql
-- DESCRIPTION 	: Script to add EBC pages and control content
-- AUTHOR		: Mitesh Modi
-- DATE			: 21 Oct 2009
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Find EBC Input page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.AppendPageTitle', 'Freight Grants - Environmental Benefits Calculator | ', 'Freight Grants - Environmental Benefits Calculator | '

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelFindPageTitle.Text', 'Freight Grants - Environmental Benefits Calculator', 'Freight Grants - Environmental Benefits Calculator'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.imageInputFormSkipLink.AlternateText', 'Skip to input form', 'Neidiwch i ffurf mewnbynnu'

EXEC AddtblContent
1, 1, 'langStrings', 'FindEBCInput.clientLink.BookmarkTitle', 'Transport Direct Freight Grants - Enivronmental Benefits Calculator', 'Transport Direct Freight Grants - Enivronmental Benefits Calculator'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.lblEBC', 'Freight Grants - Environmental Benefits Calculator', 'Freight Grants - Environmental Benefits Calculator'


EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/EnvironmentalBenefitsCalculator.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/EnvironmentalBenefitsCalculator.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Freight Grants - Environmental Benefits Calculator'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC1.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/freighttrain.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/freighttrain.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC1.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Freight Grants - Environmental Benefits Calculator'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC2.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/lorry.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/lorry.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC2.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Freight Grants - Environmental Benefits Calculator'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC3.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/barge.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/barge.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC3.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Freight Grants - Environmental Benefits Calculator'


EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageEBCSkipLink.AlternateText', 'Skip to Freight Grants - Environmental Benefits Calculator', 'Skip to Freight Grants - Environmental Benefits Calculator'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.labelFromToTitle', 'Enter two locations to plan your route.', 'Enter two locations to plan your route.'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.CommandBack.Text', 'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.Information.Text', 
'This calculator is designed for organisations interested in or applying for a <b>Freight Facilities Grant</b>, 
<b>Waterborne Freight Grant</b> or support from the <b>Mode Shift Revenue Support</b> (Bulk and Waterways) scheme. It 
calculates the value of removing a lorry journey, using Mode Shift Benefit values, between two points as set 
out in the guidance for each of the schemes.',
'This calculator is designed for organisations interested in or applying for a <b>Freight Facilities Grant</b>, 
<b>Waterborne Freight Grant</b> or support from the <b>Mode Shift Revenue Support</b> (Bulk and Waterways) scheme. It 
calculates the value of removing a lorry journey, using Mode Shift Benefit values, between two points as set 
out in the guidance for each of the schemes.'

EXEC AddtblContent
1, 1, 'langStrings', 'WaitPageMessage.FindEBC', 'Thank you for waiting while Transport Direct searches for your journey options.', 'Diolch i chi am aros tra bo Transport Direct yn chwilio am eich dewisiadau siwrnai.'

EXEC AddtblContent
1, 1, 'langStrings', 'FindLocationControl.directionLabelVia', 'Via', 'Drwy'

EXEC AddtblContent
1, 1, 'langStrings', 'FindLocationControl.directionLabelTravelVia', 'Near', 'Ger'

EXEC AddtblContent
1, 1, 'langStrings', 'viaSelect.labelSRLocation', 'Type in a location to travl via', 'Teipiwch leoliad i deithio drwyddo'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.EnvironmentalBenefitsCalculatorUnavailable', 'Freight Grants - Environmental Benefits Calculator is currently unavailable.', 'Freight Grants - Environmental Benefits Calculator is currently unavailable.'

--------------------------------------------------------------------------------------------------------------------------------
-- Gazeteer options
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'


EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'




--------------------------------------------------------------------------------------------------------------------------------
-- EBC Journey Details page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.JourneyDetails.AppendPageTitle', 'Journey Details | Freight Grants - Environmental Benefits Calculator | ', 'Manylion y Siwrnai | Freight Grants - Environmental Benefits Calculator | '

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.EBCJourneyDetails.imageJourneySkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneysSearchedForControl.headerRouteFoundFor', 'Route found for', 'Route found for'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCAllDetailsControlTitle.Text.OutwardJourney', 'Route Details', 'Route Details'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCAllDetailsControlTitle.Text.ReturnJourney', 'Route Details', 'Route Details'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerForDistance.Miles', 'For miles', 'For miles'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerForDistance.Km', 'For km', 'For km'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerAccumulatedDistance.Km', 'For km', 'For km'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerAccumulatedDistance.TripKm', 'Trip km', 'Trip km'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationDetailsTableControl.labelCalculationTitle', 'Environmental Benefits Calculation', 'Environmental Benefits Calculation'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationDetailsTableControl.labelErrorMessage', 
'Sorry we are currently unable to perform the environmental benefits calculation for the route you have selected. 
Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom
of the page).', 
'Sorry we are currently unable to perform the environmental benefits calculation for the route you have selected. 
Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom
of the page).'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.Miles', 'miles', 'milltiroedd'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.Km', 'km', 'km'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.PerMile', 'per mile', 'per mile'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.PerKm', 'per km', 'per km'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.Total', 'Total', 'Cyfanswm'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.GrandTotal', 'Grand total', 'Grand total'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategory', 'Road Category', 'Road Category'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryHighMotorway', 'High Motorway', 'High Motorway'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryStandardMotorway', 'Standard Motorway', 'Standard Motorway'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryStandardARoad', 'Standard A Road', 'Standard A Road'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryOtherRoads', 'Other Roads', 'Other Roads'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.CountryEngland', 'England', 'Cymru'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.CountryScotland', 'Scotland', 'Alban'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.CountryWales', 'Wales', 'Lloegr'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.HighValueMotorway.Image',
 '<img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation2.gif" align="middle" alt="Direction contains high value motorway" title="Direction contains high value motorway" />', 
 '<img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation2.gif" align="middle" alt="Direction contains high value motorway" title="Direction contains high value motorway" />'


--------------------------------------------------------------------------------------------------------------------------------
-- EBC Journey Maps page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.JourneyMaps.AppendPageTitle', 'Journey Maps | Freight Grants - Environmental Benefits Calculator | ', 'Mapiau o''r Siwrnai | Freight Grants - Environmental Benefits Calculator | '

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.EBCJourneyMaps.imageMapSkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'


--------------------------------------------------------------------------------------------------------------------------------
-- Feedback page
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackOtherOptions.Environmental Benefits Calculator', 'Environmental benefits calculator', 'Environmental benefits calculator'



GO

-- *****************************************************************************************************************************
-- ******************** SOFT CONTENT SECTIONS **********************************************************************************
-- *****************************************************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- EBC page Group 
--------------------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM tblGroup WHERE [Name] like 'journeyplanning_findebcinput') 
	INSERT INTO tblGroup (GroupId, [Name])
	SELECT MAX(GroupId)+1, 'journeyplanning_findebcinput' FROM tblGroup

DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findebcinput')


--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Information below input panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindEBCInput', 
'<div class="PageSoftContentContainer">  
<div class="PageSoftContent">
<p> </p>
</div>
</div>'
,
'<div class="PageSoftContentContainer">  
<div class="PageSoftContent">
<p> </p>
</div>
</div>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Latest news information - placeholder required to enable page to populate latest news
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindEBCInput', 
'<h1>Latest... NOT POPULATED</h1>',
'<h1>Latest... NOT POPULATED</h1>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Right hand information panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDFindEBCPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindEBCInput',
'<div class="Column3Header">
<div class="txtsevenbbl">
  Freight Grants
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
	<table cellspacing="0" cellpadding="2" width="100%" border="0">
    <tbody>
      <tr>
        <td class="txtseven">
			For more information on the freight mode shift grants available in 
			England, Scotland and Wales covering Freight Facilities Grants (FFG), Mode Shift
			Revenue Support (MSRS) and the Waterborne Freight Grant (WFG) please use the links below.
			<br />
			<br />
			England - Department for Transport
			<a href="http://www.dft.gov.uk/pgr/freight/" target="_blank">http://www.dft.gov.uk/pgr<br />/freight/ <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a> or 
			<a href="http://www.freightbestpractice.org.uk/multi-modal"" target="_blank">http://www.freightbestpractice.<br />org.uk/multi-modal <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />			
			Scotland - Scottish Government	
			<a href="http://www.scotland.gov.uk/Topics/Transport/FT/freightgrants1" target="_blank">http://www.scotland.gov.uk/<br />Topics/Transport/FT/<br />freightgrants1 <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />
			Wales - Welsh Assembly Government
			<a href="http://wales.gov.uk/topics/transport/freight/ffg/" target="_blank">http://wales.gov.uk/topics/<br />transport/freight/ffg/ <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
		</td>
	  </tr>
	</tbody>
	</table>
</div>'
,
'<div class="Column3Header">
<div class="txtsevenbbl">
  Freight Grants
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
	<table cellspacing="0" cellpadding="2" width="100%" border="0">
    <tbody>
      <tr>
        <td class="txtseven">
			For more information on the freight mode shift grants available in 
			England, Scotland and Wales covering Freight Facilities Grants (FFG), Mode Shift
			Revenue Support (MSRS) and the Waterborne Freight Grant (WFG) please use the links below.
			<br />
			<br />
			England - Department for Transport
			<a href="http://www.dft.gov.uk/pgr/freight/" target="_blank">http://www.dft.gov.uk/pgr<br />/freight/ <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a> or 
			<a href="http://www.freightbestpractice.org.uk/multi-modal"" target="_blank">http://www.freightbestpractice.<br />org.uk/multi-modal <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />			
			Scotland - Scottish Government	
			<a href="http://www.scotland.gov.uk/Topics/Transport/FT/freightgrants1" target="_blank">http://www.scotland.gov.uk/<br />Topics/Transport/FT/<br />freightgrants1 <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />
			Wales - Welsh Assembly Government
			<a href="http://wales.gov.uk/topics/transport/freight/ffg/" target="_blank">http://wales.gov.uk/topics/<br />transport/freight/ffg/ <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
		</td>
	  </tr>
	</tbody>
	</table>
</div>'

GO

-- *****************************************************************************************************************************
-- ******************** HELP PAGE SOFT CONTENT SECTIONS **********************************************************************************
-- *****************************************************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- EBC pages - Help urls
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'FindEBCInput.HelpPageUrl', 'Help/HelpFindEBCInput.aspx', 'Help/HelpFindEBCInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'FindEBCInput.HelpAmbiguityUrl', 'Help/HelpFindEBCInput.aspx', 'Help/HelpFindEBCInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCJourneyDetails.HelpPageUrl', 'Help/HelpEBCJourneyDetails.aspx', 'Help/HelpEBCJourneyDetails.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCJourneyMap.HelpPageUrl', 'Help/HelpEBCJourneyMap.aspx', 'Help/HelpEBCJourneyMap.aspx'


--------------------------------------------------------------------------------------------------------------------------------
-- Add the help urls to ensure help pages are displayed
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- Find EBC input - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindEBCInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindEBCInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindEBCInput', 'Channel',
'/Channels/TransportDirect/Help/HelpFindEBCInput',
'/Channels/TransportDirect/Help/HelpFindEBCInput'

-- Find EBC input - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindEBCInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindEBCInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindEBCInput', 'Channel',
'/Channels/TransportDirect/Printer/HelpFindEBCInput',
'/Channels/TransportDirect/Printer/HelpFindEBCInput'

-- EBC journey details - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyDetails', 'Channel',
'/Channels/TransportDirect/Help/HelpEBCJourneyDetails',
'/Channels/TransportDirect/Help/HelpEBCJourneyDetails'

-- EBC journey details - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyDetails', 'Channel',
'/Channels/TransportDirect/Printer/HelpEBCJourneyDetails',
'/Channels/TransportDirect/Printer/HelpEBCJourneyDetails'

-- EBC journey map - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyMap', 'Channel',
'/Channels/TransportDirect/Help/HelpEBCJourneyMap',
'/Channels/TransportDirect/Help/HelpEBCJourneyMap'

-- EBC journey map - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyMap', 'Channel',
'/Channels/TransportDirect/Printer/HelpEBCJourneyMap',
'/Channels/TransportDirect/Printer/HelpEBCJourneyMap'


--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Help text
--------------------------------------------------------------------------------------------------------------------------------
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'helpfulljp')

EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindEBCInput',
'&nbsp;'
,
'&nbsp;'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindEBCInput',
'&nbsp;'
,
'&nbsp;'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey details - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpEBCJourneyDetails',
'&nbsp;'
,
'&nbsp;'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey details - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEBCJourneyDetails',
'&nbsp;'
,
'&nbsp;'


--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey map - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpEBCJourneyMap',
'&nbsp;'
,
'&nbsp;'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey map - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEBCJourneyMap',
'&nbsp;'
,
'&nbsp;'


--------------------------------------------------------------------------------------------------------------------------------
-- EBC Map Page
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'ShowDetails.Text', 'Show details', 'cy Show details'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.EBC', 'Route,StartLocation,EndLocation', 'Route,StartLocation,EndLocation'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.imageRoute', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/UnknownTrafficKey.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/UnknownTrafficKey.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.imageEndLocation.AlternateText', 'Key for route', 'cy Key for route'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.imageRoute.Print', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/UnknownTrafficKeyPrint.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/UnknownTrafficKey.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.labelRoute', 'Route', 'cy Route'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.labelRoute.Print', 'Route', 'cy Route'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.JourneyMaps.imageJourneySkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCMapControlTitle.Text.OutwardJourney', 'Route Map', 'Route Map'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCMapControlTitle.Text.ReturnJourney', 'Route Map', 'Route Map'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC Printer Friendly Page
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.StaticPrinterFriendly.labelPrinterFriendly', 'Environmental Benefits Calculator Printer friendly page', 'Environmental Benefits Calculator Printer friendly page'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1491
SET @ScriptDesc = 'EBC pages and control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO