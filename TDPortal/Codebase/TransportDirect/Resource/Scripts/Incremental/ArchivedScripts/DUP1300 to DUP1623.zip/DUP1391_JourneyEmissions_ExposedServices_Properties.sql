-- ***********************************************
-- NAME 			: DUP1391_JourneyEmissions_ExposedServices_Properties.sql
-- DESCRIPTION 		: Add journey emission properties for use by exposed services
-- AUTHOR			: Mitesh Modi
-- DATE				: 03 Sep 2009
-- ***********************************************

USE [PermanentPortal]
GO

DECLARE @AID VARCHAR(50)
DECLARE @GID VARCHAR(50)

SET @AID = 'TDRemotingHost'
SET @GID = 'TDRemotingHost'

-- Check for the first one and delete if exists
IF EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.AirDistanceFactor' AND AID = @AID AND GID = @GID)
BEGIN
    DELETE FROM properties
    WHERE pName like 'JourneyEmissions.%'
        AND AID = @AID 
        AND GID = @GID
END

-- Add Journey emissions properties for EnhancedExposedServices

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.AirDistanceFactor' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.AirDistanceFactor', '1.09', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.BusDistanceFactor' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.BusDistanceFactor', '1.25', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.CarSize.Default' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.CarSize.Default', 'medium', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.CarSize.Medium' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.CarSize.Medium', 'medium', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.CongestionAndUrbanDrivingFactor' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.CongestionAndUrbanDrivingFactor', '1.03', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.Distance.Air.Medium' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.Distance.Air.Medium', '480', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.Distance.Air.Small' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.Distance.Air.Small', '71', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.EmissionBar.MaxWidth' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.EmissionBar.MaxWidth', '178', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.FuelType.Default' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.FuelType.Default', 'petrol', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.FuelType.Diesel' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.FuelType.Diesel', 'diesel', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.FuelType.Petrol' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.FuelType.Petrol', 'petrol', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.HighMpg' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.HighMpg', '68', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.LowMpg' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.LowMpg', '23', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.MaxDistance' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.MaxDistance', '2000', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.MaxDistance.Air' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.MaxDistance.Air', '2000', @AID, @GID, 0, 1)
END


IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.MinDistance' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.MinDistance', '1', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.MinDistance.Air' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.MinDistance.Air', '150', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.MinDistance.Coach' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.MinDistance.Coach', '30', @AID, @GID, 0, 1)
END

IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'JourneyEmissions.PTAvailable' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('JourneyEmissions.PTAvailable', 'True', @AID, @GID, 0, 1)
END


GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1391
SET @ScriptDesc = 'Journey emissions calculator properties for Exposed Services'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

