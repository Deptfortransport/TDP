-- ***********************************************
-- NAME 		: DUP1518_Maps_Reporting_PageEntry.sql
-- DESCRIPTION 	: Added reporting page entry event type for new Map pages
-- AUTHOR		: Mitesh Modi
-- DATE			: 01 Nov 2009
-- ************************************************

USE [Reporting]
GO

-- Add new page entries for reporting
IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindMapInput') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindMapInput', 'Find Map Input' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'FindMapResult') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'FindMapResult', 'Find Map Result' FROM PageEntryType
GO


IF NOT EXISTS(SELECT * FROM PageEntryType WHERE PETCode = 'PrintableFindMapResult') 
	INSERT INTO PageEntryType(PETID, PETCode, PETDescription)
	SELECT MAX(PETID)+1, 'PrintableFindMapResult', 'Printable Find Map Result' FROM PageEntryType
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1518
SET @ScriptDesc = 'Added new Map page entry event types'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO