-- ***********************************************
-- NAME 		: DUP1490_StopInformation_StopCodeText.sql
-- DESCRIPTION 		: Script to add Stop Information page stop code text
-- AUTHOR		: Amit Patel
-- DATE			: 21 Oct 2009
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelStationCode.Text', 'The short code for {0} is {1}.', 'cy The short code for {0} is {1}.'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelStationCode.MobileService.Text', 'This can be used in our mobile service to find out your next arrivals / departures.', 'cy This can be used in our mobile service to find out your next arrivals / departures.'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.SkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'

EXEC AddtblContent
1, 1, 'langStrings', 'ServiceDetails.serviceHeaderLabel.Text', 'Serivce detail for stop {0}', 'cy Serivce detail for stop {0}'

EXEC AddtblContent
1, 1, 'langStrings', 'StopServiceDetails.NoStopEvents.Text', 'No service detail found', 'cy No service detail found'


Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1490
SET @ScriptDesc = 'Script to add Stop Information page stop code text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO