-- ***********************************************
-- NAME 			: DUP1355_CyclePlanner_Content_Update.sql
-- DESCRIPTION 		: Script to update Cycle PLanner content
-- AUTHOR			: Neil Rankin
-- DATE				: 22 Jul 2009
-- ***********************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle page Group 
--------------------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM tblGroup WHERE [Name] like 'journeyplanning_findcycleinput') 
	INSERT INTO tblGroup (GroupId, [Name])
	SELECT MAX(GroupId)+1, 'journeyplanning_findcycleinput' FROM tblGroup

DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findcycleinput')


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Right hand information panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput',
'<div class="Column3Header">
  <div class="txtsevenbbl">Cycle Planning</div>
  <div class="clearboth"></div>
</div>
<div class="Column3Content">
  <table cellspacing="0" cellpadding="2" width="100%" border="0">
    <tbody>
      <tr>
        <td class="txtseven">This is the first version of Transport
        Direct&#8217;s new cycle planner. We have worked with
        Cycling England, Ordnance Survey and the relevant local
        authorities to ensure that there is good quality
        information on cycling in the following areas: 
        <ul class="listerdisc">
          <li>
            <strong>Derby</strong>
          </li>
          <li>
            <strong>Exeter</strong>
          </li>
          <li>
            <strong>Greater Bristol</strong>
          </li>
          <li>
            <strong>Greater Leicester</strong>
          </li>
          <li>
            <strong>Greater Manchester</strong>
          </li>
          <li>
            <strong>Lancaster</strong>
          </li>
          <li>
            <strong>Merseyside</strong>
          </li>
          <li>
            <strong>Oxford</strong>
          </li>
          <li>
            <strong>Peterborough</strong>
          </li>
          <li>
            <strong>Worcester</strong>
          </li>
        </ul>
        <br />We would really appreciate your feedback on this
        initial version of the planner. Please click on "Contact
        us" at the bottom of the page to let us know what you think
        or report any problems. 
        <br />
        <br />We will consider all feedback and will be improving
        the planner over the coming weeks. Work is also ongoing to
        provide cycle planning information in more areas - please
        check again soon if your local area is not yet available. 
        <br /></td>
      </tr>
    </tbody>
  </table>
</div>'
,
'<div class="Column3Header">
  <div class="txtsevenbbl">Trefnu Taith Feicio</div>
  <div class="clearboth"></div>
</div>
<div class="Column3Content">
  <table cellspacing="0" cellpadding="2" width="100%" border="0">
    <tbody>
      <tr>
        <td class="txtseven">Dyma''r fersiwn gyntaf o drefnwr
        teithiau beicio newydd Transport Direct. Rydym wedi
        gweithio gyda Cycling England, Arolwg Ordnans a''r
        awdurdodau lleol perthnasol i sicrhau bod gwybodaeth o
        ansawdd ar gael am feicio yn yr ardaloedd canlynol: 
        <ul class="listerdisc">
          <li>
            <strong>Derby</strong>
          </li>
          <li>
            <strong>Exeter</strong>
          </li>
          <li>
            <strong>Greater Bristol</strong>
          </li>
          <li>
            <strong>Greater Leicester</strong>
          </li>
          <li>
            <strong>Greater Manchester</strong>
          </li>
          <li>
            <strong>Lancaster</strong>
          </li>
          <li>
            <strong>Merseyside</strong>
          </li>
          <li>
            <strong>Oxford</strong>
          </li>
          <li>
            <strong>Peterborough</strong>
          </li>
          <li>
            <strong>Worcester</strong>
          </li>
        </ul>
        <br />Byddem yn wirioneddol yn gwerthfawrogi eich adborth
        am y fersiwn wreiddiol hon o''r trefnwr. Cliciwch ar
        ''Cysylltwch &#212; ni'' ar waelod y dudalen i roi gwybod
        inni beth yw eich barn neu adrodd am unrhyw broblemau. 
        <br />
        <br />Byddwn yn ystyried pob adborth ac yn gwella''r
        trefnwr dros yr wythnosau nesaf. Mae gwaith yn parhau hefyd
        i roi gwybodaeth i drefnu teithiau beicio mewn mwy o
        ardaloedd - dewch yn''l eto cyn bo hir os nad yw eich
        ardal leol ar gael eto. 
        <br />
        <br /></td>
      </tr>
    </tbody>
  </table>
</div>'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Information below input panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput', 
'<div class="PageSoftContentContainer">
  <div class="PageSoftContent">
    <p>Click the Advanced Options button above to amend some of the
    following options for your journey. Options include:</p>
    <ul>
      <li>Amend the maximum speed at which you would like to
      travel</li>
      <li>Choose to avoid unlit roads, or walking with your bike</li>
      <li>Select a location you would like your journey to go
      via</li>
    </ul>
    <br />
  </div>
</div>'
,
'<div class="PageSoftContentContainer">
  <div class="PageSoftContent">
    <p>Cliciwch y botwm Opsiynau Manwl uchod i newid rhai o''r
    opsiynau canlynol ar gyfer eich siwrnai. Mae opsiynau''n
    cynnwys:</p>
    <ul>
      <li>Newid y cyflymder mwyaf yr hoffech deithio</li>
      <li>Dewis osgoi ffyrdd heb eu goleuo, cerdded gyda''ch beic</li>
      <li>Dewis lleoliad yr hoffech i''ch siwrnai fynd drwyddo</li>
    </ul>
    <br />
  </div>
</div>'




--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Help text
--------------------------------------------------------------------------------------------------------------------------------
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'helpfulljp')

EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindACycleInput',
'<h3>Selecting locations to travel from and to</h3>
<blockquote>
  <h5>Type the location names in the boxes</h5>
  <br />
  <p>It is best to type in the full location name so that you get
  the fewest ''similar matches'' returned to you. Punctuation and
  use of capital letters are not important.</p>
  <p>If you are not sure how to spell the name of the location, you
  can tick the ''Unsure of spelling'' box so that the Journey
  Planner will also search for locations that sound similar to the
  one you type in.</p>
  <p>If you do not know the full location name, type in as much as
  you know and put an asterisk * after the letters.</p>
  <br />
  <h5>Select the type of locations</h5>
  <br />
  <p>Your choice will inform the Journey Planner whether you are
  looking for an address, a postcode, a station or an attraction
  &#8230;etc.</p>
  <p>It is important that you select the appropriate type of
  location. For example, if you are looking for a railway station,
  but you select the ''Address/postcode'' category, the Journey
  Planner will not be able to find it.</p>
  <p>The categories are described below:</p>
  <ul class="listerdisc">
    <li>
    <strong>''Address/postcode'':</strong>If you select this
    option, you can type in part or all of an address and/or a
    postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford",
    "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32
    0PF", "M32 0PF". If you don''t know the postcode include as
    much of the address as possible. 
    <br /></li>
    <li>
    <strong>''Facility/attraction'':</strong>If you select this
    option, you can type in the name of an attraction or facility,
    including: hotels, schools, universities, hospitals, surgeries,
    sports grounds, theatres, cinemas, tourist attractions,
    museums, government buildings and police stations For example
    &#8220;Edinburgh Castle&#8221;, &#8220;Queen''s Head
    Hotel&#8221;, &#8220;British Museum&#8221;, &#8220;Arsenal
    Football Club&#8221; 
    <br /></li>
    <li>
    <strong>''Station/airport'':</strong>If you select this option,
    you can type in the name of a railway station, a coach station,
    an airport or a ferry terminal. You may also type in the name
    of a town and choose to travel from any of the stations in this
    town, e.g. &#8220;Kings Cross&#8221;, &#8220;London&#8221;,
    Derby&#8221;, &#8220;Newcastle&#8221;, &#8220;Gatwick&#8221;,
    &#8220;Victoria Coach Station&#8221; 
    <br /></li>
  </ul>
  <br />
  <h5>Find the location on a map (optional)</h5>
  <br />
  <p>You may click on the ''Find on map'' button to find the
  location on a map.</p>
  <p>Once you have found the location on the map, you will have the
  option to continue planning the journey (by clicking ''Next'' on
  that page). This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
  <h5>Select the dates you would like to leave/return on</h5>
  <br />
  <ul class="listerdisc">
    <li>Select a day from the ''drop-down'' list, then select a
    month/year 
    <br />or</li>
    <li>Click the calendar and select a date from it</li>
    <li>If you are planning a journey that is only one way, choose
    ''No return'' in the month/year ''drop-down'' list.</li>
  </ul>
  <br />
  <h5>Choose how you want to specify the times</h5>
  <br />
  <ul class="listerdisc">
    <li>You have the choice of selecting the time you want to leave
    the location or the time you want to arrive at the
    destination</li>
    <li>Choose ''Leaving at'' to select the earliest time you want
    to leave the location or</li>
    <li>Choose ''Arriving by'' to select the latest time you want
    to arrive at the destination</li>
  </ul>
  <br />
  <h5>Select the times you would like to travel</h5>
  <br />
  <ul class="listerdisc">
    <li>Select the time you want to either leave at or arrive
    by</li>
    <li>Select the hours from the ''drop-down'' list</li>
    <li>Select the minutes from the ''drop-down'' list (the Journey
    Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
  </ul>
  <br />
  <h5>Type of journey</h5>
  <br />
  <p>Choose how the Journey Planner will plan your cycling route.
  Select:</p>
  <ul class="listerdisc">
    <li>&#8220;Quickest&#8221; if you would like a route with the shortest cycling time.</li>
    <li>&#8220;Quietest&#8221; if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling.</li>
    <li>&#8220;Most recreational&#8221; if you would like a route that prioritises cycling through parks and green spaces in addition to prioritising the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling.</li>
  </ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
  <ul class="listerdisc">
    <li>
    <strong>Speed (maximum cycling speed)</strong>
    <br />Choose the maximum speed you are willing to cycle.
    Journey times will be based on this speed, but will also take
    into account the legal speed limits on the various roads in the
    proposed route.</li>
  </ul>
  <br />
  <h5>Journey options</h5>
  <blockquote>
    <ul class="listerdisc">
      <li>
      <strong>Avoid unlit roads, walking with your bike</strong>
      <br />If you would prefer your journey to avoid unlit roads,
      or walking with your bike, tick the relevant box and, where
      possible, the journey planner will avoid them so that they
      are not included in your journey plan.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Avoid time-based access restrictions</strong>
      <br />Some roads and paths have time based access
      restrictions such as &#8216;Closed on market day&#8217;. Due
      to the nature of these restrictions the planner cannot tell
      when planning your journey whether or not access will be
      permitted at the time of travel. Where the information is
      available we will try and show in the journey results that a
      restriction applies to the point of access. 
      <br />You can choose to avoid all such potential time based
      restrictions by clicking &#8216;Advanced options&#8217; at
      the bottom of the input pages ticking the avoid timebased
      restrictions option. Transport Direct will, where possible,
      avoid returning a journey which uses roads and paths with
      time-based restrictions.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Travelling via a location by bicycle</strong>
      <br />Choose where to travel via by typing in the location
      and selecting a location type. For example selecting
      &#8220;Address / Postcode&#8221; and adding a friend&#8217;s
      address. For more details on how to do this, see ''Selecting
      locations to travel from and to'' at the beginning of the Help
      page. You may also use a map to find the location.</li>
    </ul>
  </blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
,
'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote>
  <h5>Teipiwch enwau''r lleoliad yn y blychau</h5>
  <br />
  <p>Mae''n ddoeth teipio enw llawn y lleoliad er mwyn dychwelyd y
  "canlyniadau tebyg" lleiaf i chi. Nid yw''n bwysig atalnodi na
  defnyddio priflythrennau.</p>
  <p>Os ydych yn ansicr sut i sillafu enw''r lleoliad, gallwch
  dicio''r blwch ''Ansicr sut i''w sillafu'' fel y bydd y
  Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n
  debyg i''r un a deipioch i mewn.</p>
  <p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint
  ag y gwyddoch a rhoi seren * ar &#244;l y llythrennau.</p>
  <br />
  <h5>Dewiswch y math o leoliad</h5>
  <br />
  <p>Bydd eich dewis yn rhoi gwybod i''r Cynlluniwr Siwrnai a ydych
  chi''n chwilio am gyfeiriad, cod post, gorsaf neu atyniad ...
  etc.</p>
  <p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er
  enghraifft, os ydych chi''n chwilio am orsaf drenau, ond eich bod
  yn dewis y categori ''Cyfeiriad/cod post'', ni fydd y Cynlluniwr
  Siwrnai yn gallu dod o hyd iddi.</p>
  <p>Caiff y categor&#239;au eu disgrifio isod:</p>
  <ul class="listerdisc">
    <li>
    <strong>''Cyfeiriad/cod post'':</strong>Os dewiswch yr opsiwn
    hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god
    post, e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford",
    "Burleigh Road, Stretford, Manceinion", "3 Burleigh Road, M32
    0PF", "M32 0PF". Os nad ydych yn gwybod y cod post, dylech
    gynnwys cymaint o''r cyfeiriad &#226; phosibl.
    <br /></li>
    <li>
    <strong>''Cyfleuster/atyniad'':</strong>Os dewiswch yr opsiwn
    hwn, gallwch deipio enw atyniad neu gyfleuster, gan gynnwys:
    gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, caeau
    chwaraeon, theatrau, sinem&#226;u, atyniadau i dwristiaid,
    amgueddfeydd, adeiladau llywodraeth a gorsafoedd heddlu. Er
    enghraifft "Castell Caeredin", "Gwesty Queen''s Head&#8221;,
    &#8220;Amgueddfa Prydain", &#8220;Clwb P&#234;l-droed
    Arsenal&#8221;
    <br /></li>
    <li>
    <strong>''Gorsaf/maes awyr'':</strong>Os dewiswch yr opsiwn
    hwn, gallwch deipio enw gorsaf drenau, gorsaf fysiau, maes awyr
    neu derminws fferi. Gallech hefyd deipio enw tref a dewis
    teithio o unrhyw un o''r gorsafoedd yn y dref hon, e.e.
    &#8220;Kings Cross&#8221;, &#8220;Llundain&#8221;,
    Derby&#8221;, &#8220;Newcastle&#8221;, &#8220;Gatwick&#8221;,
    &#8220;Gorsaf Fysiau Victoria&#8221;
    <br /></li>
  </ul>
  <br />
  <h5>Canfod y lleoliad ar fap (dewisol)</h5>
  <br />
  <p>Gallech glicio ar y botwm ''Canfod ar fap'' i ddod o hyd i''r
  lleoliad ar fap.</p>
  <p>Ar &#244;l ichi ganfod y lleoliad ar y map, byddwch chi''n
  gallu dewis parhau i gynllunio''r siwrnai (drwy glicio ''Nesaf''
  ar y dudalen honno). Bydd hyn yn eich dychwelyd i''r dudalen
  gyfredol.</p>
</blockquote>
<h3>Dewis dyddiadau ac amseroedd siwrnai allan a dychwelyd</h3>
<blockquote>
  <h5>Dewiswch y dyddiadau yr hoffech adael/dychwelyd</h5>
  <br />
  <ul class="listerdisc">
    <li>Dewiswch ddiwrnod o''r rhestr "gwympo", wedyn dewis
    mis/blwyddyn
    <br />neu</li>
    <li>Cliciwch y calendr a dewis dyddiad ohono</li>
    <li>Os ydych yn cynllunio siwrnai un ffordd yn unig, dewiswch
    ''Dim dychweliad'' yn y rhestr "gwympo" mis/blwyddyn.</li>
  </ul>
  <br />
  <h5>Dewiswch sut yr hoffech nodi''r amseroedd</h5>
  <br />
  <ul class="listerdisc">
    <li>Gallwch ddewis yr amser yr hoffech adael y lleoliad neu''r
    amser yr hoffech gyrraedd yn y cyrchfan</li>
    <li>Dewiswch ''Gadael am'' i ddewis yr amser cynharaf yr
    hoffech adael y lleoliad neu</li>
    <li>Dewiswch ''Cyrraedd erbyn'' i ddewis yr amser hwyraf yr
    hoffech gyrraedd yn y cyrchfan</li>
  </ul>
  <br />
  <h5>Dewiswch yr amseroedd yr hoffech deithio</h5>
  <br />
  <ul class="listerdisc">
    <li>Dewiswch ar ba amser yr hoffech adael neu erbyn pa amser yr
    hoffech gyrraedd</li>
    <li>Dewiswch yr oriau o''r rhestr "gwympo"</li>
    <li>Dewiswch y munudau o''r rhestr "gwympo" (mae''r Cynlluniwr
    Siwrnai yn defnyddio cloc 24 awr e.e. 5:00pm = 17:00)</li>
  </ul>
  <br />
  <h5>Math o siwrnai</h5>
  <br />
  <p>Dewiswch sut bydd eich Cynlluniwr Siwrnai yn cynllunio eich
  llwybr beicio. Dewiswch:</p>
  <ul class="listerdisc">
    <li>&#8220;Cyflymaf&#8221; os hoffech lwybr �''r amser beicio byrraf.</li>
    <li>&#8220;Tawelaf&#8221; os hoffech lwybr sy''n rhoi blaenoriaeth i ddefnyddio llwybrau beicio, lonydd beicio, strydoedd tawel a llwybrau a argymhellir ar gyfer beicio.</li>
    <li>&#8220;Mwyaf hamddenol&#8221; os hoffech lwybr sy''n rhoi blaenoriaeth i feicio drwy barciau a mannau gwyrdd yn ogystal � defnyddio llwybrau beicio, lonydd beicio, strydoedd tawel a llwybrau a argymhellir ar gyfer beicio.</li>
  </ul>
</blockquote>
<h3>Manwl</h3>
<blockquote>
  <ul class="listerdisc">
    <li>
    <strong>Cyflymder (cyflymder beicio mwyaf)</strong>
    <br />Dewiswch y cyflymder mwyaf rydych yn fodlon ei feicio.
    Bydd amseroedd siwrnai yn seiliedig ar y cyflymder hwn, ond
    hefyd yn ystyried y terfynau cyflymder cyfreithlon ar y ffyrdd
    amrywiol yn y llwybr a gynigir.</li>
  </ul>
  <br />
  <h5>Opsiynau siwrnai</h5>
  <blockquote>
    <ul class="listerdisc">
      <li>
      <strong>Avoid unlit roads, walking with your bike</strong>
      <br />If you would prefer your journey to avoid unlit roads,
      or walking with your bike, tick the relevant box and, where
      possible, the journey planner will avoid them so that they
      are not included in your journey plan.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Avoid time-based access restrictions</strong>
      <br />Some roads and paths have time based access
      restrictions such as &#8216;Closed on market day&#8217;. Due
      to the nature of these restrictions the planner cannot tell
      when planning your journey whether or not access will be
      permitted at the time of travel. Where the information is
      available we will try and show in the journey results that a
      restriction applies to the point of access. 
      <br />You can choose to avoid all such potential time based
      restrictions by clicking &#8216;Advanced options&#8217; at
      the bottom of the input pages ticking the avoid timebased
      restrictions option. Transport Direct will, where possible,
      avoid returning a journey which uses roads and paths with
      time-based restrictions.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Travelling via a location by bicycle</strong>
      <br />Choose where to travel via by typing in the location
      and selecting a location type. For example selecting
      &#8220;Address / Postcode&#8221; and adding a friend&#8217;s
      address. For more details on how to do this, see ''Selecting
      locations to travel from and to'' at the beginning of the Help
      page. You may also use a map to find the location.</li>
    </ul>
  </blockquote>
</blockquote>
<h3>Ar &#244;l ichi gwblhau''r dudalen, cliciwch "Nesaf".</h3>'


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle input page - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindACycleInput',
'<h3>Selecting locations to travel from and to</h3>
<blockquote>
  <h5>Type the location names in the boxes</h5>
  <br />
  <p>It is best to type in the full location name so that you get
  the fewest ''similar matches'' returned to you. Punctuation and
  use of capital letters are not important.</p>
  <p>If you are not sure how to spell the name of the location, you
  can tick the ''Unsure of spelling'' box so that the Journey
  Planner will also search for locations that sound similar to the
  one you type in.</p>
  <p>If you do not know the full location name, type in as much as
  you know and put an asterisk * after the letters.</p>
  <br />
  <h5>Select the type of locations</h5>
  <br />
  <p>Your choice will inform the Journey Planner whether you are
  looking for an address, a postcode, a station or an attraction
  &#8230;etc.</p>
  <p>It is important that you select the appropriate type of
  location. For example, if you are looking for a railway station,
  but you select the ''Address/postcode'' category, the Journey
  Planner will not be able to find it.</p>
  <p>The categories are described below:</p>
  <ul class="listerdisc">
    <li>
    <strong>''Address/postcode'':</strong>If you select this
    option, you can type in part or all of an address and/or a
    postcode, e.g. "3 Burleigh Road", "3 Burleigh Road, Stretford",
    "Burleigh Road, Stretford, Manchester", "3 Burleigh Road, M32
    0PF", "M32 0PF". If you don''t know the postcode include as
    much of the address as possible. 
    <br /></li>
    <li>
    <strong>''Facility/attraction'':</strong>If you select this
    option, you can type in the name of an attraction or facility,
    including: hotels, schools, universities, hospitals, surgeries,
    sports grounds, theatres, cinemas, tourist attractions,
    museums, government buildings and police stations For example
    &#8220;Edinburgh Castle&#8221;, &#8220;Queen''s Head
    Hotel&#8221;, &#8220;British Museum&#8221;, &#8220;Arsenal
    Football Club&#8221; 
    <br /></li>
    <li>
    <strong>''Station/airport'':</strong>If you select this option,
    you can type in the name of a railway station, a coach station,
    an airport or a ferry terminal. You may also type in the name
    of a town and choose to travel from any of the stations in this
    town, e.g. &#8220;Kings Cross&#8221;, &#8220;London&#8221;,
    Derby&#8221;, &#8220;Newcastle&#8221;, &#8220;Gatwick&#8221;,
    &#8220;Victoria Coach Station&#8221; 
    <br /></li>
  </ul>
  <br />
  <h5>Find the location on a map (optional)</h5>
  <br />
  <p>You may click on the ''Find on map'' button to find the
  location on a map.</p>
  <p>Once you have found the location on the map, you will have the
  option to continue planning the journey (by clicking ''Next'' on
  that page). This will return you to the current page.</p>
</blockquote>
<h3>Selecting outward and return journey dates and times</h3>
<blockquote>
  <h5>Select the dates you would like to leave/return on</h5>
  <br />
  <ul class="listerdisc">
    <li>Select a day from the ''drop-down'' list, then select a
    month/year 
    <br />or</li>
    <li>Click the calendar and select a date from it</li>
    <li>If you are planning a journey that is only one way, choose
    ''No return'' in the month/year ''drop-down'' list.</li>
  </ul>
  <br />
  <h5>Choose how you want to specify the times</h5>
  <br />
  <ul class="listerdisc">
    <li>You have the choice of selecting the time you want to leave
    the location or the time you want to arrive at the
    destination</li>
    <li>Choose ''Leaving at'' to select the earliest time you want
    to leave the location or</li>
    <li>Choose ''Arriving by'' to select the latest time you want
    to arrive at the destination</li>
  </ul>
  <br />
  <h5>Select the times you would like to travel</h5>
  <br />
  <ul class="listerdisc">
    <li>Select the time you want to either leave at or arrive
    by</li>
    <li>Select the hours from the ''drop-down'' list</li>
    <li>Select the minutes from the ''drop-down'' list (the Journey
    Planner uses a 24 hour clock e.g. 5:00pm = 17:00)</li>
  </ul>
  <br />
  <h5>Type of journey</h5>
  <br />
  <p>Choose how the Journey Planner will plan your cycling route.
  Select:</p>
  <ul class="listerdisc">
    <li>&#8220;Quickest&#8221; if you would like a route with the shortest cycling time.</li>
    <li>&#8220;Quietest&#8221; if you would like a route that prioritises the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling.</li>
    <li>&#8220;Most recreational&#8221; if you would like a route that prioritises cycling through parks and green spaces in addition to prioritising the use of cycle paths, cycle lanes, quiet streets and routes recommended for cycling.</li>
  </ul>
</blockquote>
<h3>Advanced</h3>
<blockquote>
  <ul class="listerdisc">
    <li>
    <strong>Speed (maximum cycling speed)</strong>
    <br />Choose the maximum speed you are willing to cycle.
    Journey times will be based on this speed, but will also take
    into account the legal speed limits on the various roads in the
    proposed route.</li>
  </ul>
  <br />
  <h5>Journey options</h5>
  <blockquote>
    <ul class="listerdisc">
      <li>
      <strong>Avoid unlit roads, walking with your bike</strong>
      <br />If you would prefer your journey to avoid unlit roads,
      or walking with your bike, tick the relevant box and, where
      possible, the journey planner will avoid them so that they
      are not included in your journey plan.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Avoid time-based access restrictions</strong>
      <br />Some roads and paths have time based access
      restrictions such as &#8216;Closed on market day&#8217;. Due
      to the nature of these restrictions the planner cannot tell
      when planning your journey whether or not access will be
      permitted at the time of travel. Where the information is
      available we will try and show in the journey results that a
      restriction applies to the point of access. 
      <br />You can choose to avoid all such potential time based
      restrictions by clicking &#8216;Advanced options&#8217; at
      the bottom of the input pages ticking the avoid timebased
      restrictions option. Transport Direct will, where possible,
      avoid returning a journey which uses roads and paths with
      time-based restrictions.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Travelling via a location by bicycle</strong>
      <br />Choose where to travel via by typing in the location
      and selecting a location type. For example selecting
      &#8220;Address / Postcode&#8221; and adding a friend&#8217;s
      address. For more details on how to do this, see ''Selecting
      locations to travel from and to'' at the beginning of the Help
      page. You may also use a map to find the location.</li>
    </ul>
  </blockquote>
</blockquote>
<h3>Once you have completed the page, click ''Next''.</h3>'
,
'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote>
  <h5>Teipiwch enwau''r lleoliad yn y blychau</h5>
  <br />
  <p>Mae''n ddoeth teipio enw llawn y lleoliad er mwyn dychwelyd y
  "canlyniadau tebyg" lleiaf i chi. Nid yw''n bwysig atalnodi na
  defnyddio priflythrennau.</p>
  <p>Os ydych yn ansicr sut i sillafu enw''r lleoliad, gallwch
  dicio''r blwch ''Ansicr sut i''w sillafu'' fel y bydd y
  Cynlluniwr Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n
  debyg i''r un a deipioch i mewn.</p>
  <p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint
  ag y gwyddoch a rhoi seren * ar &#244;l y llythrennau.</p>
  <br />
  <h5>Dewiswch y math o leoliad</h5>
  <br />
  <p>Bydd eich dewis yn rhoi gwybod i''r Cynlluniwr Siwrnai a ydych
  chi''n chwilio am gyfeiriad, cod post, gorsaf neu atyniad ...
  etc.</p>
  <p>Mae''n bwysig eich bod yn dewis y math priodol o leoliad. Er
  enghraifft, os ydych chi''n chwilio am orsaf drenau, ond eich bod
  yn dewis y categori ''Cyfeiriad/cod post'', ni fydd y Cynlluniwr
  Siwrnai yn gallu dod o hyd iddi.</p>
  <p>Caiff y categor&#239;au eu disgrifio isod:</p>
  <ul class="listerdisc">
    <li>
    <strong>''Cyfeiriad/cod post'':</strong>Os dewiswch yr opsiwn
    hwn, gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god
    post, e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford",
    "Burleigh Road, Stretford, Manceinion", "3 Burleigh Road, M32
    0PF", "M32 0PF". Os nad ydych yn gwybod y cod post, dylech
    gynnwys cymaint o''r cyfeiriad &#226; phosibl.
    <br /></li>
    <li>
    <strong>''Cyfleuster/atyniad'':</strong>Os dewiswch yr opsiwn
    hwn, gallwch deipio enw atyniad neu gyfleuster, gan gynnwys:
    gwestai, ysgolion, prifysgolion, ysbytai, meddygfeydd, caeau
    chwaraeon, theatrau, sinem&#226;u, atyniadau i dwristiaid,
    amgueddfeydd, adeiladau llywodraeth a gorsafoedd heddlu. Er
    enghraifft "Castell Caeredin", "Gwesty Queen''s Head&#8221;,
    &#8220;Amgueddfa Prydain", &#8220;Clwb P&#234;l-droed
    Arsenal&#8221;
    <br /></li>
    <li>
    <strong>''Gorsaf/maes awyr'':</strong>Os dewiswch yr opsiwn
    hwn, gallwch deipio enw gorsaf drenau, gorsaf fysiau, maes awyr
    neu derminws fferi. Gallech hefyd deipio enw tref a dewis
    teithio o unrhyw un o''r gorsafoedd yn y dref hon, e.e.
    &#8220;Kings Cross&#8221;, &#8220;Llundain&#8221;,
    Derby&#8221;, &#8220;Newcastle&#8221;, &#8220;Gatwick&#8221;,
    &#8220;Gorsaf Fysiau Victoria&#8221;
    <br /></li>
  </ul>
  <br />
  <h5>Canfod y lleoliad ar fap (dewisol)</h5>
  <br />
  <p>Gallech glicio ar y botwm ''Canfod ar fap'' i ddod o hyd i''r
  lleoliad ar fap.</p>
  <p>Ar &#244;l ichi ganfod y lleoliad ar y map, byddwch chi''n
  gallu dewis parhau i gynllunio''r siwrnai (drwy glicio ''Nesaf''
  ar y dudalen honno). Bydd hyn yn eich dychwelyd i''r dudalen
  gyfredol.</p>
</blockquote>
<h3>Dewis dyddiadau ac amseroedd siwrnai allan a dychwelyd</h3>
<blockquote>
  <h5>Dewiswch y dyddiadau yr hoffech adael/dychwelyd</h5>
  <br />
  <ul class="listerdisc">
    <li>Dewiswch ddiwrnod o''r rhestr "gwympo", wedyn dewis
    mis/blwyddyn
    <br />neu</li>
    <li>Cliciwch y calendr a dewis dyddiad ohono</li>
    <li>Os ydych yn cynllunio siwrnai un ffordd yn unig, dewiswch
    ''Dim dychweliad'' yn y rhestr "gwympo" mis/blwyddyn.</li>
  </ul>
  <br />
  <h5>Dewiswch sut yr hoffech nodi''r amseroedd</h5>
  <br />
  <ul class="listerdisc">
    <li>Gallwch ddewis yr amser yr hoffech adael y lleoliad neu''r
    amser yr hoffech gyrraedd yn y cyrchfan</li>
    <li>Dewiswch ''Gadael am'' i ddewis yr amser cynharaf yr
    hoffech adael y lleoliad neu</li>
    <li>Dewiswch ''Cyrraedd erbyn'' i ddewis yr amser hwyraf yr
    hoffech gyrraedd yn y cyrchfan</li>
  </ul>
  <br />
  <h5>Dewiswch yr amseroedd yr hoffech deithio</h5>
  <br />
  <ul class="listerdisc">
    <li>Dewiswch ar ba amser yr hoffech adael neu erbyn pa amser yr
    hoffech gyrraedd</li>
    <li>Dewiswch yr oriau o''r rhestr "gwympo"</li>
    <li>Dewiswch y munudau o''r rhestr "gwympo" (mae''r Cynlluniwr
    Siwrnai yn defnyddio cloc 24 awr e.e. 5:00pm = 17:00)</li>
  </ul>
  <br />
  <h5>Math o siwrnai</h5>
  <br />
  <p>Dewiswch sut bydd eich Cynlluniwr Siwrnai yn cynllunio eich
  llwybr beicio. Dewiswch:</p>
  <ul class="listerdisc">
    <li>&#8220;Cyflymaf&#8221; os hoffech lwybr �''r amser beicio byrraf.</li>
    <li>&#8220;Tawelaf&#8221; os hoffech lwybr sy''n rhoi blaenoriaeth i ddefnyddio llwybrau beicio, lonydd beicio, strydoedd tawel a llwybrau a argymhellir ar gyfer beicio.</li>
    <li>&#8220;Mwyaf hamddenol&#8221; os hoffech lwybr sy''n rhoi blaenoriaeth i feicio drwy barciau a mannau gwyrdd yn ogystal � defnyddio llwybrau beicio, lonydd beicio, strydoedd tawel a llwybrau a argymhellir ar gyfer beicio.</li>
  </ul>
</blockquote>
<h3>Manwl</h3>
<blockquote>
  <ul class="listerdisc">
    <li>
    <strong>Cyflymder (cyflymder beicio mwyaf)</strong>
    <br />Dewiswch y cyflymder mwyaf rydych yn fodlon ei feicio.
    Bydd amseroedd siwrnai yn seiliedig ar y cyflymder hwn, ond
    hefyd yn ystyried y terfynau cyflymder cyfreithlon ar y ffyrdd
    amrywiol yn y llwybr a gynigir.</li>
  </ul>
  <br />
  <h5>Opsiynau siwrnai</h5>
  <blockquote>
    <ul class="listerdisc">
      <li>
      <strong>Avoid unlit roads, walking with your bike</strong>
      <br />If you would prefer your journey to avoid unlit roads,
      or walking with your bike, tick the relevant box and, where
      possible, the journey planner will avoid them so that they
      are not included in your journey plan.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Avoid time-based access restrictions</strong>
      <br />Some roads and paths have time based access
      restrictions such as &#8216;Closed on market day&#8217;. Due
      to the nature of these restrictions the planner cannot tell
      when planning your journey whether or not access will be
      permitted at the time of travel. Where the information is
      available we will try and show in the journey results that a
      restriction applies to the point of access. 
      <br />You can choose to avoid all such potential time based
      restrictions by clicking &#8216;Advanced options&#8217; at
      the bottom of the input pages ticking the avoid timebased
      restrictions option. Transport Direct will, where possible,
      avoid returning a journey which uses roads and paths with
      time-based restrictions.</li>
    </ul>
    <br />
    <ul class="listerdisc">
      <li>
      <strong>Travelling via a location by bicycle</strong>
      <br />Choose where to travel via by typing in the location
      and selecting a location type. For example selecting
      &#8220;Address / Postcode&#8221; and adding a friend&#8217;s
      address. For more details on how to do this, see ''Selecting
      locations to travel from and to'' at the beginning of the Help
      page. You may also use a map to find the location.</li>
    </ul>
  </blockquote>
</blockquote>
<h3>Ar &#244;l ichi gwblhau''r dudalen, cliciwch "Nesaf".</h3>'




--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey details - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneyDetails',
'<blockquote>
  <h5>Journey details</h5>
  <br />
  <p>The directions for your cycle journey are shown in a list. The
  information provided will include information about your route
  &#8211; such as whether it includes any recommended cycling
  routes &#8211; as well as telling you which direction to
  take.</p>
  <br />
  <p>If you prefer, you can view them on a map by clicking "Show on
  map". The map will appear with the directions listed below
  it.</p>
  <br />
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to a website that will
  give you more information about the ferry or toll etc.</p>
  <br />
  <p>To view information about a journey:</p>
  <br />
  <p>Click the buttons above the journeys to view a brief summary
  of your journey options ("Summary"), detailed maps of your
  journey ("Maps"), the CO2 your journey will produce &#8211; and
  the ability to compare this with other modes of transport ("Check
  CO2") for the selected journey.</p>
  <br />
  <p>To print any of the pages, click "Printer friendly". This will
  open a printer-friendly page that you can print as usual.</p>
  <br />
  <h5>Gradient Profile</h5>
  <br />
  <p>The gradient profile graph shows a cross section of your cycle
  route so you are able to judge how flat or steep your route is.
  The X-axis shows the journey distance in miles or km, the Y-axis
  will show the height above sea level for your journey in metres.
  The highest and lowest point on the journey will also be shown
  along with the total climb and descent in metres.</p>
  <br />
  <p>You may be prompted to download ActiveX Controls when first
  viewing the cycle journey results page. This ActiveX Add-on is an
  accessory software program that extends the capabilities of an
  existing application. In the case of the cycle planner it is
  required to draw the gradient profile graph of your journey. If
  you are prompted to download any "ActiveX Controls", you will
  need to accept them if you want to view the gradient profile
  graph. Alternatively you can click the "show table view" button
  to see the gradients for the journey.</p>
  <br />
  <h5>GPX File</h5>
  <br />
  <p>The GPX file produced by Transport Direct''s cycle planner
  describes the tracks and routes taken in your journey. It
  indicates the start and end location, journey directions, as well
  as latitude and longitude of points along the route. You can load
  the GPX file into GPS devices and other software computer
  programs. This will allow you, for example, to view your route on
  your GPS device during your journey, project your track on
  satellite images (in Google Earth), or annotate maps. The format
  is open and can be used without the need to pay license fees.</p>
  <br />
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'
,
'<blockquote>
  <h5>Journey details</h5>
  <br />
  <p>The directions for your cycle journey are shown in a list. The
  information provided will include information about your route
  &#8211; such as whether it includes any recommended cycling
  routes &#8211; as well as telling you which direction to
  take.</p>
  <br />
  <p>If you prefer, you can view them on a map by clicking "Show on
  map". The map will appear with the directions listed below
  it.</p>
  <br />
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to a website that will
  give you more information about the ferry or toll etc.</p>
  <br />
  <p>To view information about a journey:</p>
  <br />
  <p>Click the buttons above the journeys to view a brief summary
  of your journey options ("Summary"), detailed maps of your
  journey ("Maps"), the CO2 your journey will produce &#8211; and
  the ability to compare this with other modes of transport ("Check
  CO2") for the selected journey.</p>
  <br />
  <p>To print any of the pages, click "Printer friendly". This will
  open a printer-friendly page that you can print as usual.</p>
  <br />
  <h5>Gradient Profile</h5>
  <br />
  <p>The gradient profile graph shows a cross section of your cycle
  route so you are able to judge how flat or steep your route is.
  The X-axis shows the journey distance in miles or km, the Y-axis
  will show the height above sea level for your journey in metres.
  The highest and lowest point on the journey will also be shown
  along with the total climb and descent in metres.</p>
  <br />
  <p>You may be prompted to download ActiveX Controls when first
  viewing the cycle journey results page. This ActiveX Add-on is an
  accessory software program that extends the capabilities of an
  existing application. In the case of the cycle planner it is
  required to draw the gradient profile graph of your journey. If
  you are prompted to download any "ActiveX Controls", you will
  need to accept them if you want to view the gradient profile
  graph. Alternatively you can click the "show table view" button
  to see the gradients for the journey.</p>
  <br />
  <h5>GPX File</h5>
  <br />
  <p>The GPX file produced by Transport Direct''s cycle planner
  describes the tracks and routes taken in your journey. It
  indicates the start and end location, journey directions, as well
  as latitude and longitude of points along the route. You can load
  the GPX file into GPS devices and other software computer
  programs. This will allow you, for example, to view your route on
  your GPS device during your journey, project your track on
  satellite images (in Google Earth), or annotate maps. The format
  is open and can be used without the need to pay license fees.</p>
  <br />
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey details - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneyDetails',
'<blockquote>
  <h5>Journey details</h5>
  <br />
  <p>The directions for your cycle journey are shown in a list. The
  information provided will include information about your route
  &#8211; such as whether it includes any recommended cycling
  routes &#8211; as well as telling you which direction to
  take.</p>
  <br />
  <p>If you prefer, you can view them on a map by clicking "Show on
  map". The map will appear with the directions listed below
  it.</p>
  <br />
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to a website that will
  give you more information about the ferry or toll etc.</p>
  <br />
  <p>To view information about a journey:</p>
  <br />
  <p>Click the buttons above the journeys to view a brief summary
  of your journey options ("Summary"), detailed maps of your
  journey ("Maps"), the CO2 your journey will produce &#8211; and
  the ability to compare this with other modes of transport ("Check
  CO2") for the selected journey.</p>
  <br />
  <p>To print any of the pages, click "Printer friendly". This will
  open a printer-friendly page that you can print as usual.</p>
  <br />
  <h5>Gradient Profile</h5>
  <br />
  <p>The gradient profile graph shows a cross section of your cycle
  route so you are able to judge how flat or steep your route is.
  The X-axis shows the journey distance in miles or km, the Y-axis
  will show the height above sea level for your journey in metres.
  The highest and lowest point on the journey will also be shown
  along with the total climb and descent in metres.</p>
  <br />
  <p>You may be prompted to download ActiveX Controls when first
  viewing the cycle journey results page. This ActiveX Add-on is an
  accessory software program that extends the capabilities of an
  existing application. In the case of the cycle planner it is
  required to draw the gradient profile graph of your journey. If
  you are prompted to download any "ActiveX Controls", you will
  need to accept them if you want to view the gradient profile
  graph. Alternatively you can click the "show table view" button
  to see the gradients for the journey.</p>
  <br />
  <h5>GPX File</h5>
  <br />
  <p>The GPX file produced by Transport Direct''s cycle planner
  describes the tracks and routes taken in your journey. It
  indicates the start and end location, journey directions, as well
  as latitude and longitude of points along the route. You can load
  the GPX file into GPS devices and other software computer
  programs. This will allow you, for example, to view your route on
  your GPS device during your journey, project your track on
  satellite images (in Google Earth), or annotate maps. The format
  is open and can be used without the need to pay license fees.</p>
  <br />
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'
,
'<blockquote>
  <h5>Journey details</h5>
  <br />
  <p>The directions for your cycle journey are shown in a list. The
  information provided will include information about your route
  &#8211; such as whether it includes any recommended cycling
  routes &#8211; as well as telling you which direction to
  take.</p>
  <br />
  <p>If you prefer, you can view them on a map by clicking "Show on
  map". The map will appear with the directions listed below
  it.</p>
  <br />
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to a website that will
  give you more information about the ferry or toll etc.</p>
  <br />
  <p>To view information about a journey:</p>
  <br />
  <p>Click the buttons above the journeys to view a brief summary
  of your journey options ("Summary"), detailed maps of your
  journey ("Maps"), the CO2 your journey will produce &#8211; and
  the ability to compare this with other modes of transport ("Check
  CO2") for the selected journey.</p>
  <br />
  <p>To print any of the pages, click "Printer friendly". This will
  open a printer-friendly page that you can print as usual.</p>
  <br />
  <h5>Gradient Profile</h5>
  <br />
  <p>The gradient profile graph shows a cross section of your cycle
  route so you are able to judge how flat or steep your route is.
  The X-axis shows the journey distance in miles or km, the Y-axis
  will show the height above sea level for your journey in metres.
  The highest and lowest point on the journey will also be shown
  along with the total climb and descent in metres.</p>
  <br />
  <p>You may be prompted to download ActiveX Controls when first
  viewing the cycle journey results page. This ActiveX Add-on is an
  accessory software program that extends the capabilities of an
  existing application. In the case of the cycle planner it is
  required to draw the gradient profile graph of your journey. If
  you are prompted to download any "ActiveX Controls", you will
  need to accept them if you want to view the gradient profile
  graph. Alternatively you can click the "show table view" button
  to see the gradients for the journey.</p>
  <br />
  <h5>GPX File</h5>
  <br />
  <p>The GPX file produced by Transport Direct''s cycle planner
  describes the tracks and routes taken in your journey. It
  indicates the start and end location, journey directions, as well
  as latitude and longitude of points along the route. You can load
  the GPX file into GPS devices and other software computer
  programs. This will allow you, for example, to view your route on
  your GPS device during your journey, project your track on
  satellite images (in Google Earth), or annotate maps. The format
  is open and can be used without the need to pay license fees.</p>
  <br />
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'




--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey summary - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneySummary',
'<blockquote>
  <h5>Journey details</h5>
  <br />
  <p>To view information about a journey:</p>
  <ol>
    <li>Click the buttons above the journeys to view a brief
    summary of your journey options (''Summary''), detailed maps of
    your journey (''Maps''), the CO2 your journey will produce
    &#8211; and the ability to compare this with other modes of
    transport (''Check CO2'') for the selected journey</li>
  </ol>
  <p>To print any of the pages, click ''Printer friendly''. This
  will open a printer-friendly page that you can print as
  usual.</p>
  <br />
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'
,
'<blockquote>
  <h5>Manylion siwrnai</h5>
  <br />
  <p>I weld gwybodaeth am siwrnai:</p>
  <ol>
    <li>Cliciwch y botymau uwchlaw''r siwrneiau i weld crynodeb byr
    o''ch opsiynau siwrnai (''Crynodeb''), mapiau manwl o''ch
    siwrnai (''Mapiau''), y CO2 y bydd eich siwrnai yn ei gynhyrchu
    &#8211; a''r gallu i gymharu hyn &#226; dulliau eraill o
    gludiant (''Cyfrif CO2'') ar gyfer y siwrnai a ddewiswyd</li>
  </ol>
  <p>I argraffu unrhyw un o''r tudalennau, cliciwch ''Addas i''w
  hargraffu''. Bydd hyn yn agor tudalen addas i''w hargraffu y
  gallwch ei hargraffu fel arfer.</p>
  <br />
  <h5>Newid dyddiad ac amser</h5>
  <br />
  <p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
  <ol>
    <li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri
    cwympo</li>
    <li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
  </ol>
  <p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar
  frig y dudalen</p>
  <br />
  <h5>Anfon at ffrind</h5>
  <br />
  <p>I anfon y dudalen hon at ffrind:</p>
  <ol>
    <li>Sicrhewch eich bod wedi mewngofnodi i Transport
    Direct.</li>
    <li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich
    enw defnyddiwr a''ch cyfrinair.</li>
    <li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen
    ato yn y blwch</li>
    <li>Cliciwch ''Anfon''</li>
  </ol>
  <p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r
  manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost
  hwnnw. Bydd mapiau (os ydynt yn berthnasol) yn cael eu hatodi fel
  ffeil ddelwedd (mae e-byst tua 150k ar gyfartaledd). Dangosir
  eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey summary - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneySummary',
'<blockquote>
  <h5>Journey details</h5>
  <br />
  <p>To view information about a journey:</p>
  <ol>
    <li>Click the buttons above the journeys to view a brief
    summary of your journey options (''Summary''), detailed maps of
    your journey (''Maps''), the CO2 your journey will produce
    &#8211; and the ability to compare this with other modes of
    transport (''Check CO2'') for the selected journey</li>
  </ol>
  <p>To print any of the pages, click ''Printer friendly''. This
  will open a printer-friendly page that you can print as
  usual.</p>
  <br />
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'
,
'<blockquote>
  <h5>Manylion siwrnai</h5>
  <br />
  <p>I weld gwybodaeth am siwrnai:</p>
  <ol>
    <li>Cliciwch y botymau uwchlaw''r siwrneiau i weld crynodeb byr
    o''ch opsiynau siwrnai (''Crynodeb''), mapiau manwl o''ch
    siwrnai (''Mapiau''), y CO2 y bydd eich siwrnai yn ei gynhyrchu
    &#8211; a''r gallu i gymharu hyn &#226; dulliau eraill o
    gludiant (''Cyfrif CO2'') ar gyfer y siwrnai a ddewiswyd</li>
  </ol>
  <p>I argraffu unrhyw un o''r tudalennau, cliciwch ''Addas i''w
  hargraffu''. Bydd hyn yn agor tudalen addas i''w hargraffu y
  gallwch ei hargraffu fel arfer.</p>
  <br />
  <h5>Newid dyddiad ac amser</h5>
  <br />
  <p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
  <ol>
    <li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri
    cwympo</li>
    <li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
  </ol>
  <p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar
  frig y dudalen</p>
  <br />
  <h5>Anfon at ffrind</h5>
  <br />
  <p>I anfon y dudalen hon at ffrind:</p>
  <ol>
    <li>Sicrhewch eich bod wedi mewngofnodi i Transport
    Direct.</li>
    <li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich
    enw defnyddiwr a''ch cyfrinair.</li>
    <li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen
    ato yn y blwch</li>
    <li>Cliciwch ''Anfon''</li>
  </ol>
  <p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r
  manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost
  hwnnw. Bydd mapiau (os ydynt yn berthnasol) yn cael eu hatodi fel
  ffeil ddelwedd (mae e-byst tua 150k ar gyfartaledd). Dangosir
  eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>'


--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey map - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpCycleJourneyMap',
'<blockquote>
  <h5>Journey maps</h5>
  <br />
  <p>You can view specific stages of the journey in more
  detail:</p>
  <ol>
    <li>Select the journey stage from the drop-down list</li>
    <li>Click ''Show route''</li>
  </ol>
  <p>Click ''Printer friendly'' to open a printer-friendly page
  that you can print as usual.</p>
  <br />
  <p>You can view symbols on the map when it is highly magnified
  (within the top five zoom levels, outlined in yellow). They
  include transport symbols (shown automatically) and a range of
  attraction and facility symbols.</p>
  <p>To show or hide any of these symbols, you must:</p>
  <ol>
    <li>Click on a category radio button e.g.
    ''Accommodation''</li>
    <li>Tick or untick the boxes next to the symbols</li>
    <li>Click ''Show selected symbols''</li>
  </ol>
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'
,
'<blockquote>
  <h5>Mapiau siwrnai</h5>
  <br />
  <p>Gallwch weld cyfnodau penodol o''r siwrnai yn fanylach:</p>
  <ol>
    <li>Dewiswch y cyfnod o''r siwrnai o''r rhestr gwympo</li>
    <li>Cliciwch ''Dangos llwybr''</li>
  </ol>
  <p>Cliciwch ''Addas i''w hargraffu'' i agor tudalen addas i''w
  hargraffu y gallwch ei hargraffu fel arfer.</p>
  <br />
  <p>Gallwch weld symbolau ar y map pan gaiff ei chwyddo''n fawr
  (yn y pum lefel chwyddo brig, wedi''u hamlinellu''n felyn). Maent
  yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac ystod
  o symbolau atyniad a chyfleuster.</p>
  <p>I ddangos neu guddio unrhyw un o''r symbolau hyn, mae''n rhaid
  i chi:</p>
  <ol>
    <li>Glicio ar fotwm radio categori e.e. ''Llety''</li>
    <li>Ticio neu ddileu tic yn y blychau wrth ymyl y symbolau</li>
    <li>Clicio ''Dangos symbolau a ddewiswyd''</li>
  </ol>
  <h5>Newid dyddiad ac amser</h5>
  <br />
  <p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
  <ol>
    <li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri
    cwympo</li>
    <li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
  </ol>
  <p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar
  frig y dudalen</p>
  <br />
  <h5>Anfon at ffrind</h5>
  <br />
  <p>I anfon y dudalen hon at ffrind:</p>
  <ol>
    <li>Sicrhewch eich bod wedi mewngofnodi i Transport
    Direct.</li>
    <li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich
    enw defnyddiwr a''ch cyfrinair.</li>
    <li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen
    hon ato yn y blwch</li>
    <li>Cliciwch ''Anfon''</li>
  </ol>
  <p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r
  manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost
  hwnnw. Bydd mapiau (os yw''n berthnasol) yn cael eu hatodi fel
  ffeil ddelwedd (mae e-bost tua 150k ar gyfartaledd). Dangosir
  eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>'

--------------------------------------------------------------------------------------------------------------------------------
-- Cycle journey map - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpCycleJourneyMap',
'<blockquote>
  <h5>Journey maps</h5>
  <br />
  <p>You can view specific stages of the journey in more
  detail:</p>
  <ol>
    <li>Select the journey stage from the drop-down list</li>
    <li>Click ''Show route''</li>
  </ol>
  <p>Click ''Printer friendly'' to open a printer-friendly page
  that you can print as usual.</p>
  <br />
  <p>You can view symbols on the map when it is highly magnified
  (within the top five zoom levels, outlined in yellow). They
  include transport symbols (shown automatically) and a range of
  attraction and facility symbols.</p>
  <p>To show or hide any of these symbols, you must:</p>
  <ol>
    <li>Click on a category radio button e.g.
    ''Accommodation''</li>
    <li>Tick or untick the boxes next to the symbols</li>
    <li>Click ''Show selected symbols''</li>
  </ol>
  <h5>Amend date and time</h5>
  <br />
  <p>To amend the dates and times of your journey:</p>
  <ol>
    <li>Select the new date(s) and time(s) in the drop-down
    lists</li>
    <li>Click ''Search with new dates/times''</li>
  </ol>
  <p>To amend the entire journey, you can click ''Amend journey''
  at the top of the page</p>
  <br />
  <h5>Send to a friend</h5>
  <br />
  <p>To send this page to a friend:</p>
  <ol>
    <li>Make sure you are logged in to Transport Direct.</li>
    <li>If you are not logged in, you will need to enter your
    username and password.</li>
    <li>Type in the email address of the person you would like to
    send the page to in the box</li>
    <li>Click ''Send''</li>
  </ol>
  <p>A text-based email with a summary of the journey and the
  details/directions will be sent to that email address. Maps (if
  applicable) will be attached as an image file (the average email
  size is around 150k). Your email address will be shown in the
  email.</p>
</blockquote>'
,
'<blockquote>
  <h5>Mapiau siwrnai</h5>
  <br />
  <p>Gallwch weld cyfnodau penodol o''r siwrnai yn fanylach:</p>
  <ol>
    <li>Dewiswch y cyfnod o''r siwrnai o''r rhestr gwympo</li>
    <li>Cliciwch ''Dangos llwybr''</li>
  </ol>
  <p>Cliciwch ''Addas i''w hargraffu'' i agor tudalen addas i''w
  hargraffu y gallwch ei hargraffu fel arfer.</p>
  <br />
  <p>Gallwch weld symbolau ar y map pan gaiff ei chwyddo''n fawr
  (yn y pum lefel chwyddo brig, wedi''u hamlinellu''n felyn). Maent
  yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac ystod
  o symbolau atyniad a chyfleuster.</p>
  <p>I ddangos neu guddio unrhyw un o''r symbolau hyn, mae''n rhaid
  i chi:</p>
  <ol>
    <li>Glicio ar fotwm radio categori e.e. ''Llety''</li>
    <li>Ticio neu ddileu tic yn y blychau wrth ymyl y symbolau</li>
    <li>Clicio ''Dangos symbolau a ddewiswyd''</li>
  </ol>
  <h5>Newid dyddiad ac amser</h5>
  <br />
  <p>I newid dyddiadau ac amseroedd eich siwrnai:</p>
  <ol>
    <li>Dewiswch y dyddiad(au) ac amser(oedd) newydd yn y rhestri
    cwympo</li>
    <li>Cliciwch ''Chwilio gyda dyddiadau/amseroedd newydd''</li>
  </ol>
  <p>I newid y siwrnai gyfan, gallwch glicio ''Newid siwrnai'' ar
  frig y dudalen</p>
  <br />
  <h5>Anfon at ffrind</h5>
  <br />
  <p>I anfon y dudalen hon at ffrind:</p>
  <ol>
    <li>Sicrhewch eich bod wedi mewngofnodi i Transport
    Direct.</li>
    <li>Os nad ydych wedi mewngofnodi, bydd angen i chi nodi eich
    enw defnyddiwr a''ch cyfrinair.</li>
    <li>Teipiwch gyfeiriad e-bost y sawl yr hoffech anfon y dudalen
    hon ato yn y blwch</li>
    <li>Cliciwch ''Anfon''</li>
  </ol>
  <p>Bydd e-bost testun gyda chrynodeb o''r siwrnai a''r
  manylion/cyfarwyddiadau yn cael ei anfon i''r cyfeiriad e-bost
  hwnnw. Bydd mapiau (os yw''n berthnasol) yn cael eu hatodi fel
  ffeil ddelwedd (mae e-bost tua 150k ar gyfartaledd). Dangosir
  eich cyfeiriad e-bost yn yr e-bost.</p>
</blockquote>'




--------------------------------------------------------------------------------------------------------------------------------
-- Validation
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.CyclePlannerUnavailableKey', 'Find a cycle journey is currently unavailable.', 
'Nid oes modd canfod siwrnai feicio ar hyn o bryd.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.CycleSpeedErrorKey', 'The cycle speed must be a number greater than zero. Please enter a new value.', 
'Mae''n rhaid bod y cyflymder beicio yn rhif uwch na dim. Nodwch werth newydd os gwelwch yn dda.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationHasNoPoint', 
'Cycle planning is not available within the area you have selected. Please choose a different start location and/or destination.', 
'Nid yw''r gwasanaeth cynllunio beicio ar gael yn yr ardal a ddewisoch. Dewiswch wahanol man cychwyn a/neu gyrchfan os gwelwch yn dda.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.DistanceBetweenLocationsTooGreat', 
'Transport Direct will only plan a cycle journey which has a maximum distance between the origin and destination of {0}km; the journey you requested was further than this.', 
'Dim ond siwrnai feicio sydd � phellter mwyaf o {0} cilometr rhwng y man cychwyn a''r cyrchfan y bydd Transport Direct yn ei chynllunio; roedd y siwrnai y gofynasoch amdani yn bellach na hyn.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.DistanceBetweenLocationsAndViaTooGreat', 
'Transport Direct will only plan a cycle journey which has a maximum distance between the origin, via and destination of {0}km; the journey you requested was further than this.',
'Dim ond siwrnai feicio sydd � phellter mwyaf o {0} cilometr rhwng y man cychwyn, y mannau canol a''r cyrchfan y bydd Transport Direct yn ei chynllunio; roedd y siwrnai y gofynasoch amdani yn bellach na hyn.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationInInvalidCycleArea', 
'At the moment we are able to plan cycle journeys in a <b>limited number of areas</b>.  To find out which areas are currently available please <a href="/Web2/Help/HelpCycle.aspx#A16.2">go to the FAQ on cycle planning.</a>',
'At the moment we are able to plan cycle journeys in a <b>limited number of areas</b>.  To find out which areas are currently available please <a href="/Web2/Help/HelpCycle.aspx#A16.2">go to the FAQ on cycle planning.</a>'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationPointsNotInSameCycleArea', 
'To plan a cycle journey on Transport Direct the journey origin, destination and via points must all be in the same area. The journey you requested contained points that were in different areas with no direct connection between them. To find out more please <a href="/Web2/Help/HelpCycle.aspx#A16.2">go to the FAQ on cycle data areas</a>.',
'I gynllunio siwrnai feicio ar Transport Direct mae''n rhaid bod man cychwyn, cyrchfan a mannau canol y siwrnai i gyd yn yr un ardal. Roedd y siwrnai y gofynasoch amdani yn cynnwys pwyntiau a oedd mewn gwahanol ardaloedd heb unrhyw gysylltiad uniongyrchol rhyngddynt. I ganfod mwy ewch i''r Cwestiynau Cyffredin ar ardaloedd data beicio <a href="/Web2/Help/HelpCycle.aspx#A16.2">os gwelwch yn dda</a>.'







-- TIDY UP, remove duplicate entries not needed
EXEC DeletetblContent 
1, 1, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1355
SET @ScriptDesc = 'Script to update Cycle PLanner content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO