-- ***********************************************
-- NAME 		: DUP1414_DevEnvironment_Properties
-- DESCRIPTION 		: Script to update GAZ and GIS for the Dev Environment
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Sep 2009
-- ************************************************



-- **************************** IMPORTANT ********************************
-- *********** DO NOT RUN THIS SCRIPT IN SITEST, DR-TEST, OR ACP *********
-- *********** THIS SCRIPT IS ONLY FOR DEVELOPMENT ENVIRONMENT ***********
-- ***********************************************************************

USE [PermanentPortal]
GO


UPDATE PermanentPortal.dbo.properties
SET pValue = 'tdparc93'
WHERE pValue = 'tdparc91'
  
UPDATE PermanentPortal.dbo.properties
SET pValue = 'http://GAZ/GazopsWeb/GazopsWeb.asmx'
WHERE pName = 'locationservice.gazopsweburl'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1414
SET @ScriptDesc = 'Dev Environment - GAZ and GIS update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO