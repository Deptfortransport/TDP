-- ***********************************************
-- NAME 		: DUP1396_StopInformation_Properties.sql
-- DESCRIPTION 		: Script to add stop information page/controls properties
-- AUTHOR		: Amit Patel
-- DATE			: 19 Aug 2009
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowMap' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowMap', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowMap' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowJourney' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowJourney', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowJourney' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowServices' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowServices', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowServices' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowTaxi' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowTaxi', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowTaxi' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowFacilities' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowFacilities', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowFacilities' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowOperator' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowOperator', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowOperator' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowLocality' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowLocality', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowLocality' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowRealTimeLinks' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowRealTimeLinks', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowRealTimeLinks' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ServiceControl.Train.MaxServices' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ServiceControl.Train.MaxServices', '10', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '10'
	where pname = 'StopInformation.ServiceControl.Train.MaxServices' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ServiceControl.Bus.MaxServices' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ServiceControl.Bus.MaxServices', '10', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '10'
	where pname = 'StopInformation.ServiceControl.Bus.MaxServices' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.Departure' and ThemeId = 1)
BEGIN
	insert into properties values ('TDOnTheMove.TDMobileUI.URL.Departure', 'http://tdti.kizoom.co.uk/en/deps/results?fromCode={0}&mode={1}&time={2}&timeReqType=today', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.kizoom.co.uk/en/deps/results?fromCode={0}&mode={1}&time={2}&timeReqType=today'
	where pname = 'TDOnTheMove.TDMobileUI.URL.Departure' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'TDOnTheMove.TDMobileUI.URL.Arrival' and ThemeId = 1)
BEGIN
	insert into properties values ('TDOnTheMove.TDMobileUI.URL.Arrival', 'http://tdti.kizoom.co.uk/en/arrs/results?atCode={0}&mode={1}&time={2}&timeReqType=today', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://tdti.kizoom.co.uk/en/arrs/results?atCode={0}&mode={1}&time={2}&timeReqType=today'
	where pname = 'TDOnTheMove.TDMobileUI.URL.Arrival' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale.Air' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale.Air', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale.Air' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale.Bus' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale.Bus', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale.Bus' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale.Coach' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale.Coach', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale.Coach' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale.Ferry' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale.Ferry', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale.Ferry' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale.LightRail' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale.LightRail', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale.LightRail' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale.Rail' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale.Rail', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale.Rail' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopTypeDefaultScale.Taxi' and ThemeId = 1)
BEGIN
	insert into properties values ('StopTypeDefaultScale.Taxi', '8000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '8000'
	where pname = 'StopTypeDefaultScale.Taxi' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'StopInformation.StopInformationMapControl.StopsVisible' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.StopInformationMapControl.StopsVisible', 'BCX,RLY,TMU,FTD,AIR,TXR,STR,MET,FER', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'BCX,RLY,TMU,FTD,AIR,TXR,STR,MET,FER'
	where pname = 'StopInformation.StopInformationMapControl.StopsVisible' and ThemeId = 1
END






----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1396
SET @ScriptDesc = 'Stop information page/control properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO