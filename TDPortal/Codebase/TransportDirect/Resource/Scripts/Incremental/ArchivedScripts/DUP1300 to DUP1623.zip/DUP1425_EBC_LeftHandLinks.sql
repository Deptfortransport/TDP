-- ***********************************************
-- NAME 			: DUP1425_EBC_LeftHandLinks.sql
-- DESCRIPTION 		: Script to add the Left hand link to the Find EBC Input page
-- AUTHOR			: Mitesh Modi
-- DATE				: 14 Sep 2009
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- BEING TIDY UP
-- If this script is run multiple times, we can end up with multiple EBC links on the Homepage / Tips and Tools Homepage. 
-- So delete them first.


-- Remove any previously added link to EBC Input page that were added, these should only be there for Category: Tips and Tools
DELETE     
--SELECT *
FROM    ContextSuggestionLink
WHERE   (SuggestionLinkId IN
                            (SELECT     SuggestionLinkId    -- Get all suggestion links which are for the Plan a journey category
                             FROM          SuggestionLink   -- and use our the FindACycle resource (this is the Find Cycle Input page)
                             WHERE      (LinkCategoryId =
                                             (SELECT     LinkCategoryId
                                              FROM       LinkCategory
                                              WHERE      [name] = 'Tips and tools'))
                             AND (ResourceNameId =
                                      (SELECT     ResourceNameID
                                       FROM       ResourceName
                                       WHERE      ResourceName = 'EnvironmentalBenefitsCalculator'))))

AND     (ContextId IN    -- And only for the Homepage or Tips and Tools mini homepage
            (SELECT     ContextId
             FROM       Context
             WHERE      [Name] = 'HomePageMenu' OR [Name] = 'HomePageMenuTipsAndTools'))

GO

-- Delete the base link previously added to Suggestion Links for Find a EBC input. 
-- This ensures the correct one is used for the Homepage context, and the Tips and tools homepage context when added
DELETE
--SELECT *
FROM    SuggestionLink       -- Get all suggestion links which are for the Tips and tools category
WHERE   (LinkCategoryId =    -- and use our FindACycle (Input page) resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Tips and tools')) 
AND     (ResourceNameId = 
                            (SELECT     ResourceNameID
                             FROM       ResourceName
                             WHERE      ResourceName = 'EnvironmentalBenefitsCalculator'))

GO

-- END TIDY UP
--------------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- BEGIN

----------------------------------------------------------------
-- Set up the EBC input page link
----------------------------------------------------------------

-- This adds the actual link, and assigns it to the Home page
EXEC AddInternalSuggestionLink

	'JourneyPlanning/FindEBCInput.aspx',			-- Relative internal link URL
	'Environmental benefits calculator input',	    -- Description of internal link. Ensure this is a unique internal link description
	'EnvironmentalBenefitsCalculator',			                    -- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Freight Grants - Environmental benefits calculator',		    -- English display text. Populate only if adding new ResourceName or updating existing display text
	'Freight Grants - Environmental benefits calculator',			-- Welsh display text. Populate only if adding new ResourceName or updating existing display text	
	'Tips and tools',				            -- Category Name (LinkCategory) -- Use 'General' if not a left hand navigation link
	90,						                -- Priority must be unique for the selected CategoryName this link is for
	0,						                    -- Set to 0 if to be used as a Suggestion/Related Link
	0,						                    -- Set to 1 if it is a second level Root link
	'HomePageMenu',	                            -- Context Name (Context) -- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',						                    -- Populate only if adding a new ContextName, or updating description
	1						                    -- Theme this link is added for, use 1 as default

GO

-- This adds it to the Tips and Tools mini homepage, and all pages which display the Tips and tools's left nav
-- NOTE: we use the same physical Internal link record, but have a new Suggestion Link with a different priority
EXEC AddInternalSuggestionLink

	'JourneyPlanning/FindEBCInput.aspx',      
	'Environmental benefits calculator input',                             
	'EnvironmentalBenefitsCalculator',			                    
	'Freight Grants - Environmental benefits calculator',		                
	'Freight Grants - Environmental benefits calculator',		            
	'Tips and tools',				            
	5080,						                
	0,						                    
	0,						                    
	'HomePageMenuTipsAndTools',	                            
	'',						                    
	1						                    

GO


-- NOT ADDING LINK FOR THE Whitelabel partner sites
-- Example shown below if we are to add

------------------------HomePageMenu

-- VisitBritain
--EXEC AddContextSuggestionLink

--	'EnvironmentalBenefitsCalculator',			-- Resource Name (ResourceName) ResourceNameID 111
--	'Tips and tools',			-- Category Name (LinkCategory)
--	'HomePageMenu',				-- Context Name (Context)
--	2							-- Theme


---------------- HomePageMenuTipsAndTools

-- VisitBritain
--EXEC AddContextSuggestionLink

--	'EnvironmentalBenefitsCalculator',			-- Resource Name (ResourceName) ResourceNameID 111
--	'Tips and tools',			-- Category Name (LinkCategory)
--	'HomePageMenuTipsAndTools',	-- Context Name (Context)
--	2							-- Theme

-- END
--------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1425
SET @ScriptDesc = 'EBC - Left hand link to Input page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO