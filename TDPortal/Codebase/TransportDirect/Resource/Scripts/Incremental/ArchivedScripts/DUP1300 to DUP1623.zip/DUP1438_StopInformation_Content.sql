-- ***********************************************
-- NAME 		: DUP1438_StopInformation_Content.sql
-- DESCRIPTION 		: Script to add Stop Information page content
-- AUTHOR		: Amit Patel
-- DATE			: 29 Sep 2009
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelStationCode.Text', 'The {0} code for {1} is {2}', 'cy The {0} code for {1} is {2}'


Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1438
SET @ScriptDesc = 'Script to add Stop Information page content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO