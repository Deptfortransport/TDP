-- ***********************************************
-- NAME 			: DUP1449_SocialBookmarking_RelatedLinks_LeftHandLinks.sql
-- DESCRIPTION 		: Script to add the Related links to the JourneyDetails and FindCarParkResutls pages
-- AUTHOR			: Amit Patel
-- DATE				: 05 Oct 2009
-- ***********************************************

USE [TransientPortal]
GO

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT
DECLARE @ResourceNameId INT
DECLARE @ContextId INT


IF EXISTS(SELECT ResourceNameId FROM ResourceName WHERE ResourceName = 'FAQ.SocialBookmarking')
BEGIN
	SELECT @ResourceNameId = ResourceNameId FROM ResourceName WHERE ResourceName = 'FAQ.SocialBookmarking'

	DELETE FROM ContextSuggestionLink
		WHERE SuggestionLinkId = any(SELECT SuggestionLinkId FROM SuggestionLink WHERE ResourceNameId = @ResourceNameId) 
	
	DELETE FROM SuggestionLink where ResourceNameId = @ResourceNameId	
		
END



SELECT @ResourceNameId = ResourceNameId FROM ResourceName WHERE ResourceName = 'RelatedLinks'
SELECT @ContextId = ContextId FROM Context WHERE Name = 'RelatedLinksContextJourneyDetails' 
	

DELETE FROM ContextSuggestionLink
		WHERE SuggestionLinkId = any(SELECT SuggestionLinkId FROM SuggestionLink WHERE ResourceNameId = @ResourceNameId and ContextId = @ContextId) 



	
SELECT @ResourceNameId = ResourceNameId FROM ResourceName WHERE ResourceName = 'RelatedLinks'
SELECT @ContextId = ContextId FROM Context WHERE Name = 'RelatedLinksContextJourneySummary' 
	

DELETE FROM ContextSuggestionLink
		WHERE SuggestionLinkId = any(SELECT SuggestionLinkId FROM SuggestionLink WHERE ResourceNameId = @ResourceNameId and ContextId = @ContextId) 

	

SELECT @ResourceNameId = ResourceNameId FROM ResourceName WHERE ResourceName = 'RelatedLinks'
SELECT @ContextId = ContextId FROM Context WHERE Name = 'RelatedLinksContextJourneyMap' 
	

DELETE FROM ContextSuggestionLink
		WHERE SuggestionLinkId = any(SELECT SuggestionLinkId FROM SuggestionLink WHERE ResourceNameId = @ResourceNameId and ContextId = @ContextId) 

SELECT @ResourceNameId = ResourceNameId FROM ResourceName WHERE ResourceName = 'RelatedLinks'
SELECT @ContextId = ContextId FROM Context WHERE Name = 'RelatedLinksContextJourneyFares' 
	

DELETE FROM ContextSuggestionLink
		WHERE SuggestionLinkId = any(SELECT SuggestionLinkId FROM SuggestionLink WHERE ResourceNameId = @ResourceNameId and ContextId = @ContextId) 

--------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for Journey Details page
SET @ContextName = 'RelatedLinksContextJourneyDetails'
SET @ThemeId = 1


-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks', -- Resource name
	'Related Links',-- Link category
	@ContextName,
	@ThemeId

-- Add the actual related link url
EXEC AddInternalSuggestionLink

	'Help/HelpUsing.aspx#A13.12',			
	'FAQ - What is Social Bookmarking',			
	'FAQ.SocialBookmarking',			-- Resource Name (ResourceName)
	'What is Social Bookmarking?',		
	'cy What is Social Bookmarking?',			
	'Related links',				-- Category Name (LinkCategory)
	1750,						
	0,						
	0,						
	@ContextName,	-- Context Name (Context)
	'',						
	@ThemeId						-- Theme



--------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for Find car park results page
SET @ContextName = 'RelatedLinksContextFindCarParkResults'
SET @ThemeId = 1




-- Add the actual related link url
EXEC AddContextSuggestionLink

	'FAQ.SocialBookmarking',
	'Related links',
	@ContextName,
	@ThemeId
	

--------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for Journey Summary page
SET @ContextName = 'RelatedLinksContextJourneySummary'
SET @ThemeId = 1


-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks', -- Resource name
	'Related Links',-- Link category
	@ContextName,
	@ThemeId


-- Add the actual related link url
EXEC AddContextSuggestionLink

	'FAQ.SocialBookmarking',
	'Related links',
	@ContextName,
	@ThemeId



-------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for Journey Maps page

SET @ContextName = 'RelatedLinksContextJourneyMap'
SET @ThemeId = 1


-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks', -- Resource name
	'Related Links',-- Link category
	@ContextName,
	@ThemeId


-- Add the actual related link url
EXEC AddContextSuggestionLink

	'FAQ.SocialBookmarking',
	'Related links',
	@ContextName,
	@ThemeId




-------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for Journey Fares page

SET @ContextName = 'RelatedLinksContextJourneyFares'
SET @ThemeId = 1


-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks', -- Resource name
	'Related Links',-- Link category
	@ContextName,
	@ThemeId


-- Add the actual related link url
EXEC AddContextSuggestionLink

	'FAQ.SocialBookmarking',
	'Related links',
	@ContextName,
	@ThemeId



GO
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1488
SET @ScriptDesc = 'Social Bookmarking - Related links left navigation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO