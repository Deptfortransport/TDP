-- ***********************************************
-- NAME 			: DUP1495_decomissioning_gateway_TTBO.sql
-- DESCRIPTION 			: Script to update Opens in new window
-- DESCRIPTION 			: Replace "opens in new window" with an icon
-- AUTHOR			: Neil Rankin
-- DATE				: 22 October 2009
-- ***********************************************

USE [PermanentPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Content
--------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT 1
             FROM properties 
            WHERE pName = 'datagateway.ttbo.rail.ttboservers')
BEGIN
    UPDATE properties 
       SET [pValue] = ''
     WHERE [pName] = 'datagateway.ttbo.rail.ttboservers'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1495
SET @ScriptDesc = 'DUP1495_decomissioning_gateway_TTBO.sql'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO