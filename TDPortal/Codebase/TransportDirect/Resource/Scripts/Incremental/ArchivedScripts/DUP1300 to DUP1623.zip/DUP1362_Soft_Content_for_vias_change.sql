-- ***********************************************
-- AUTHOR      	: John Frank
-- NAME 	: DUP1362_Soft_Content_for_vias_change.sql
-- DESCRIPTION 	: New soft content for the vias change CCN0518
-- ************************************************

USE Content
GO

EXEC AddtblContent
1, 1, 'langStrings', 'JourneysSearchedForControl.Via',
'via',
'via'

GO

-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE PermanentPortal
GO

IF EXISTS (SELECT * FROM dbo.ChangeCatalogue WHERE ScriptNumber = 1362)
	UPDATE dbo.ChangeCatalogue
	SET
		ChangeDate = (getDate()),
		Summary = 'Soft content for vias.'
	WHERE ScriptNumber = 1362
ELSE
	INSERT INTO dbo.ChangeCatalogue (ScriptNumber, ChangeDate, Summary)
		VALUES (1362, (getDate()), 'Soft content for vias.')
GO