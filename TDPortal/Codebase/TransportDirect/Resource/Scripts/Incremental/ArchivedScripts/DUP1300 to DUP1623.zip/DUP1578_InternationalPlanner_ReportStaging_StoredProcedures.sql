-- ***********************************************
-- NAME 		: DUP1578_InternationalPlanner_ReportStaging_StoredProcedures.sql
-- DESCRIPTION 	: Script to add stored procedures to create International planner Events
-- AUTHOR		: Amit Patel
-- DATE			: 25 Jan 2010
-- ************************************************

USE [ReportStagingDB]
GO

-------------------------------------------------------------
-- *********			   WARNING					  *******
-- If running this script in the Production environment, please uncomment the lines with value "ReportServer.", and comment out the line below it.
-- There are 3 instances of this in the script.
--
-- Please ensure appropriate permissions are added to the stored procedures, all will 
-- need ASPUSER execute at a minimum
--
-------------------------------------------------------------


----------------------------------------------------------------
-- Create AddInternationalPlannerRequestEvent  stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddInternationalPlannerRequestEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddInternationalPlannerRequestEvent 
        (@InternationalPlannerRequestId varchar(50),
         @SessionId varchar(50),
         @UserLoggedOn bit, 
         @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO


----------------------------------------------------------------
-- Update AddInternationalPlannerRequestEvent  stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[AddInternationalPlannerRequestEvent] (@InternationalPlannerRequestId varchar(50), @SessionId varchar(50), @UserLoggedOn bit, @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into InternationalPlannerRequestEvent Table'

    Insert into InternationalPlannerRequestEvent (InternationalPlannerRequestId, SessionId, UserLoggedOn, TimeLogged)
		Values (@InternationalPlannerRequestId, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Create AddInternationalPlannerResultEvent   stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddInternationalPlannerResultEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddInternationalPlannerResultEvent
        (@InternationalPlannerRequestId varchar(50),
         @ResponseCategory varchar(50),
         @SessionId varchar(50),
         @UserLoggedOn bit, 
         @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO


----------------------------------------------------------------
-- Update AddInternationalPlannerResultEvent   stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[AddInternationalPlannerResultEvent] (@InternationalPlannerRequestId varchar(50),
		 @ResponseCategory varchar(50),
         @SessionId varchar(50),
         @UserLoggedOn bit, 
         @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into InternationalPlannerResultEvent Table'

    Insert into InternationalPlannerResultEvent (InternationalPlannerRequestId, ResponseCategory, SessionId, UserLoggedOn, TimeLogged)
		Values (@InternationalPlannerRequestId, @ResponseCategory, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Create TransferInternationalPlannerJourneyEvents  stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferInternationalPlannerJourneyEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE TransferInternationalPlannerJourneyEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferInternationalPlannerJourneyEvents  stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[TransferInternationalPlannerJourneyEvents]
	@Date varchar(10)
AS
	SET NOCOUNT ON
	SET DATEFIRST 1
	SET XACT_ABORT ON

	--DELETE FROM [ReportServer].[Reporting].[dbo].[InternationalPlannerJourneyEvents]
	DELETE FROM [Reporting].[dbo].[InternationalPlannerJourneyEvents]
	WHERE CONVERT(varchar(10), IPJEDate, 121) = @Date

	--INSERT INTO [ReportServer].[Reporting].[dbo].[InternationalPlannerJourneyEvents]
	INSERT INTO [Reporting].[dbo].[InternationalPlannerJourneyEvents]
	(
		IPJEDate,
		IPJEHour,
		IPJEHourQuarter,
		IPJEWeekDay,
		IPJEResponseTypeId,
		IPJELoggedOn,
		IPJECount,
		IPJEAvMsDuration
	)
	SELECT Cast(Convert(varchar(10), IPRQE.TimeLogged, 121) AS datetime) IPJEDate,
       DatePart(hour, IPRQE.TimeLogged) AS                           IPJEHour,
       Cast(DatePart(minute, IPRQE.TimeLogged) / 15 AS smallint)     IPJEHourQuarter,
       DatePart(weekday, IPRQE.TimeLogged)                           IPJEWeekDay,
       JPRT.JPRTID                                                   IPJEJPRTID,
       IPRQE.UserLoggedOn                                            IPJQELoggedOn,
       Count(*)                                                      IPJECount,
       Avg(IsNull(Cast(DateDiff(ms, IPRQE.TimeLogged, IPRSE.TimeLogged) AS decimal(18, 0)), 0)) AS IPJEAvMsDuration
	FROM InternationalPlannerRequestEvent IPRQE
	INNER JOIN InternationalPlannerResultEvent IPRSE 
		 ON IPRQE.InternationalPlannerRequestId = IPRSE.InternationalPlannerRequestId
    --LEFT JOIN ReportServer.Reporting.dbo.JourneyPlanResponseType JPRT 
	LEFT JOIN Reporting.dbo.JourneyPlanResponseType JPRT 
		 ON IPRSE.ResponseCategory = JPRT.JPRTCode
	WHERE Convert(varchar(10), IPRQE.TimeLogged, 121) = @Date
	GROUP BY Cast(Convert(varchar(10), IPRQE.TimeLogged, 121) AS datetime),
          DatePart(hour, IPRQE.TimeLogged),
          Cast(DatePart(minute, IPRQE.TimeLogged) / 15 AS smallint),
          DatePart(weekday, IPRQE.TimeLogged),
          JPRT.JPRTID,
          IPRQE.UserLoggedOn


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Create AddInternationalPlannerEvent  stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddInternationalPlannerEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddInternationalPlannerEvent 
        (@InternationalPlannerType varchar(50),
         @SessionId varchar(50),
         @UserLoggedOn bit, 
         @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO


----------------------------------------------------------------
-- Update AddInternationalPlannerEvent  stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[AddInternationalPlannerEvent] (@InternationalPlannerType varchar(50), @SessionId varchar(50), @UserLoggedOn bit, @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into InternationalPlannerRequestEvent Table'

    Insert into InternationalPlannerEvent (InternationalPlannerType, SessionId, UserLoggedOn, TimeLogged)
		Values (@InternationalPlannerType, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Create TransferInternationalPlannerEvents  stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferInternationalPlannerEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE TransferInternationalPlannerEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferInternationalPlannerEvents  stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[TransferInternationalPlannerEvents]
	@Date varchar(10)
AS
	SET NOCOUNT ON
	SET DATEFIRST 1
	SET XACT_ABORT ON

	--DELETE FROM [ReportServer].[Reporting].[dbo].[InternationalPlannerEvents]
	DELETE FROM [Reporting].[dbo].[InternationalPlannerEvents]
	WHERE CONVERT(varchar(10), IPEDate, 121) = @Date

	--INSERT INTO [ReportServer].[Reporting].[dbo].[InternationalPlannerEvents]
	INSERT INTO [Reporting].[dbo].[InternationalPlannerEvents]
	(
		IPEDate,
		IPEHour,
		IPEHourQuarter,
		IPEWeekDay,
		IPEIPTypeId,
		IPELoggedOn,
		IPECount
	)
	SELECT Cast(Convert(varchar(10), IPE.TimeLogged, 121) AS datetime)	IPEDate,
       DatePart(hour, IPE.TimeLogged) AS								IPEHour,
       Cast(DatePart(minute, IPE.TimeLogged) / 15 AS smallint)			IPEHourQuarter,
       DatePart(weekday, IPE.TimeLogged)								IPEWeekDay,
       IPT.IPTID														IPEIPTypeID,
       IPE.UserLoggedOn													IPELoggedOn,
       Count(*)															IPECount
    FROM InternationalPlannerEvent IPE
	--LEFT JOIN ReportServer.Reporting.dbo.InternationalPlannerType IPT 
	LEFT JOIN Reporting.dbo.InternationalPlannerType IPT
		 ON IPE.InternationalPlannerType = IPT.IPTCode
	WHERE Convert(varchar(10), IPE.TimeLogged, 121) = @Date
	GROUP BY Cast(Convert(varchar(10), IPE.TimeLogged, 121) AS datetime),
          DatePart(hour, IPE.TimeLogged),
          Cast(DatePart(minute, IPE.TimeLogged) / 15 AS smallint),
          DatePart(weekday, IPE.TimeLogged),
          IPT.IPTID,
          IPE.UserLoggedOn


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1578
SET @ScriptDesc = 'Add ReportStaging stored procedures for International planner Events'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO