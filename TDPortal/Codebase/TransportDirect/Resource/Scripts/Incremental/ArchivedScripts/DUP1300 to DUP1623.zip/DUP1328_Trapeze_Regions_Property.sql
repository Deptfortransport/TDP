-- ***********************************************
-- NAME 			: DUP1328_Trapeze_Regions_Property.sql
-- DESCRIPTION 		: Script to add property for the Trapeze regions
-- AUTHOR			: John Frank
-- DATE				: 30 Apr 2009
-- ***********************************************

USE [PermanentPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- PROPERTIES
--------------------------------------------------------------------------------------------------------------------------------

DELETE FROM Properties
WHERE pname = 'JourneyControl.Notes.TrapezeRegions'

INSERT INTO Properties (pName,pValue,AID,GID,PartnerId,ThemeId)
VALUES ('JourneyControl.Notes.TrapezeRegions','S,Y,NW,SW,W,WM','Web','UserPortal',0,1)

INSERT INTO Properties (pName,pValue,AID,GID,PartnerId,ThemeId)
VALUES ('JourneyControl.Notes.TrapezeRegions','S,Y,NW,SW,W,WM','TDRemotingHost','TDRemotingHost',0,1)

INSERT INTO Properties (pName,pValue,AID,GID,PartnerId,ThemeId)
VALUES ('JourneyControl.Notes.TrapezeRegions','S,Y,NW,SW,W,WM','EnhancedExposedServices','UserPortal',0,1)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1328
SET @ScriptDesc = 'Add property for Trapeze Regions'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO