-- ***********************************************
-- NAME 			: DUP1393_ExposedServices_CarJourneyPlanner_Properties.sql
-- DESCRIPTION 		: Script to setup the Car exposed service request limits
-- AUTHOR			: Mitesh Modi
-- DATE				: 08 Sep 2009
-- ***********************************************

USE [PermanentPortal]
GO

-- ****** IMPORTANT, ENSURE AID AND GID ARE SET CORRECTLY FOR THE ENHANCED EXPOSED SERVICES *********

DECLARE 
@AID VARCHAR(100),
@GID VARCHAR(100)

SET @AID = 'EnhancedExposedServices'
SET @GID = 'UserPortal'

-- Add max allowed
IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'CarExposedService.JourneysInRequest.MaxAllowed' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO [properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('CarExposedService.JourneysInRequest.MaxAllowed', 1, @AID, @GID, 0, 1)
END
ElSE
BEGIN
    UPDATE [dbo].[properties]
    SET pValue = 1
    WHERE pName = 'CarExposedService.JourneysInRequest.MaxAllowed' AND AID = @AID AND GID = @GID
END

-- Add use max allowed flag
IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = 'CarExposedService.JourneysInRequest.UseMaxAllowed' AND AID = @AID AND GID = @GID)
BEGIN
    INSERT INTO [properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES ('CarExposedService.JourneysInRequest.UseMaxAllowed', 'True', @AID, @GID, 0, 1)
END
ElSE
BEGIN
    UPDATE [dbo].[properties]
    SET pValue = 'True'
    WHERE pName = 'CarExposedService.JourneysInRequest.UseMaxAllowed' AND AID = @AID AND GID = @GID
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1393
SET @ScriptDesc = 'Add Car exposed service request limit'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
