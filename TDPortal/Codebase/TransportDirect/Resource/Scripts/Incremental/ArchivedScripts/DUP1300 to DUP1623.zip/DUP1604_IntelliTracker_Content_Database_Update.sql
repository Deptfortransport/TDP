-- ****************************************************************
-- NAME 		: DUP1604_IntelliTracker_Content_Database_Update.sql
-- DESCRIPTION 	: Updates to Content database for Intellitracker
-- AUTHOR		: Amit Patel
-- DATE			: 01 Mar 2010
-- ****************************************************************


USE [Content]
GO

-----------------------------------------------
-- Drop Existing Table(s)
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.tblTrackingKeys') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[tblTrackingKeys] 
END
GO



-----------------------------------------------
-- Create tblTrackingKeys table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.tblTrackingKeys') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE [dbo].[tblTrackingKeys](
		[PageId] [varchar](50) NOT NULL,
		[ControlId] [varchar](200) NOT NULL,
		[TrackingKey] [varchar](50) NOT NULL,
		[KeyDescription] [varchar](100) NULL,
	) ON [PRIMARY]

	-- Create primary key
	ALTER TABLE dbo.[tblTrackingKeys] ADD CONSTRAINT
		PK_tblTrackingKeys PRIMARY KEY CLUSTERED ( PageId, ControlId )
	
	-- Create Unique key as for each pageId and controlId combination there should be only one tracking key
	ALTER TABLE dbo.[tblTrackingKeys] ADD CONSTRAINT
		UQ_tblTrackingKeys UNIQUE NONCLUSTERED ( TrackingKey)

END
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Create GetPageTrackingKeys stored proc 
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetPageTrackingKeys]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
			CREATE  PROCEDURE [dbo].[GetPageTrackingKeys] 
			(
				@Page      varchar(50)
			)
			AS
			BEGIN 
				SET NOCOUNT ON 
			END
    ')

END
GO

----------------------------------------------------------------
-- Update GetPageTrackingKeys stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetPageTrackingKeys] 
(
	@Page varchar(50)
)
As
    SET NOCOUNT ON

	-- Script to return all keys for given page id
	
	SELECT ControlId,
           TrackingKey
    FROM tblTrackingkeys
    WHERE PageId = @Page
	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Create AddPageTrackingKey stored proc 
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddPageTrackingKey]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
			CREATE  PROCEDURE [dbo].[AddPageTrackingKey] 
			(
				@Page			varchar(50),
				@Control		varchar(200),
				@Key			varchar(50),
				@Description	varchar(100)
			)
			AS
			BEGIN 
				SET NOCOUNT ON 
			END
    ')

END
GO

----------------------------------------------------------------
-- Update AddPageTrackingKey stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[AddPageTrackingKey] 
(
	@Page			varchar(50),
	@Control		varchar(200),
	@Key			varchar(50),
	@Description	varchar(100)
)
As
    IF EXISTS 
		(SELECT * FROM [dbo].tblTrackingKeys
			WHERE PageId = @Page
				AND	ControlId = @Control)
	BEGIN
		UPDATE [dbo].tblTrackingKeys
		SET TrackingKey = @Key 
			,KeyDescription = @Description
		WHERE PageId = @Page
			AND ControlId = @Control
    END
	ELSE
	   BEGIN
	    	INSERT INTO [dbo].tblTrackingKeys (PageId, ControlId, TrackingKey, KeyDescription)
        	VALUES (@Page, @Control, @Key, @Description)
	   END
	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1604
SET @ScriptDesc = 'Updates to Content database for Intellitracker'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO