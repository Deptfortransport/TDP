-- ***********************************************
-- NAME 		: DUP1605_Intellitracker_TrackingKeys.sql
-- DESCRIPTION 	: Script to add Tracking keys for Intellitracker
-- AUTHOR		: Amit patel
-- DATE			: 03 Mar 2010
-- ************************************************

USE [Content]
GO

---------------------------------------------------------------------------------------
-- Tracking key for session key
---------------------------------------------------------------------------------------
EXECUTE dbo.AddPageTrackingKey 
	 'TDPage'
	,'SessionId'
	,'SK'
	,'key used to add session key used for all pages'
GO



---------------------------------------------------------------------------------------
-- Tracking key to track user survey
---------------------------------------------------------------------------------------
EXECUTE dbo.AddPageTrackingKey
	 'UserSurvey'
	,'UserSurvey'
	,'US'
	,'key used to track whether user survey was shown across all pages'

EXECUTE dbo.AddPageTrackingKey
	 'UserSurvey'
	,'ButtonContinuePage1'
	,'US1'
	,'key used to track whether section 1 of user survey was submitted'

EXECUTE dbo.AddPageTrackingKey
	 'UserSurvey'
	,'ButtonContinuePage2'
	,'US2'
	,'key used to track whether section 2 of user survey was submitted'

EXECUTE dbo.AddPageTrackingKey
	 'UserSurvey'
	,'ButtonSubmit'
	,'USC'
	,'key used to track whether user survey was submitted'
GO

-----------------------------------------------------------------------------------------
-- Journey Details Page Trakcing keys
-----------------------------------------------------------------------------------------
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonShowMapOutward'
	,'JD01'
	,'when show map button click for outward journey'
	
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonShowMapReturn'
	,'JD02'
	,'when show map button click for return journey'
	
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonHideMapOutward'
	,'JD03'
	,'when hide map button click for outward journey'
	
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonHideMapReturn'
	,'JD04'
	,'when hide map button click for return journey'
	
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonShowTableOutward'
	,'JD05'
	,'when show table button click for outward journey to show detail in table view'
	
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonShowDiagramOutward'
	,'JD06'
	,'when show diagram button click for outward journey to show detail in diagram view'
	
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonShowTableReturn'
	,'JD07'
	,'when show table button click for return journey to show detail in table view'
	
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyDetails'
	,'buttonShowDiagramReturn'
	,'JD08'
	,'when show diagram button click for return journey to show detail in diagram view'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'summaryResultTableControlOutward'
	,'JD09'
	,'key used to track when selected outward journey option is changed on journey details page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'summaryResultTableControlReturn'
	,'JD10'
	,'key used to track when selected return journey option is changed on journey details page' 

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'OutwardDate'
	,'JD11'
	,'Outward journey date selected by user'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'ReturnDate'
	,'JD12'
	,'Return journey date selected by user' 

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'findSummaryResultTableControlOutward'
	,'JD13'
	,'key used to track when selected outward journey option is changed on journey details page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyDetails'
	,'findSummaryResultTableControlReturn'
	,'JD14'
	,'key used to track when selected return journey option is changed on journey details page' 

GO

-----------------------------------------------------------------------------------------
-- Journey Fares Page Trakcing keys
-----------------------------------------------------------------------------------------
EXECUTE dbo.AddPageTrackingKey 
	 'JourneyFares'
	,'buttonRetailers'
	,'JF01'
	,'when user clicks buy ticket button on fares page'

EXECUTE dbo.AddPageTrackingKey 
	 'JourneyFares'
	,'OutboundJourneyFaresControl'
	,'JF02'
	,'fares selected for outward journey'

EXECUTE dbo.AddPageTrackingKey 
	 'JourneyFares'
	,'ReturnJourneyFaresControl'
	,'JF03'
	,'fares selected for outward journey'
	
EXECUTE dbo.AddPageTrackingKey
	 'JourneyFares'
	,'summaryResultTableControlOutward'
	,'JF04'
	,'key used to track when selected outward journey option is changed on journey fares page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyFares'
	,'summaryResultTableControlReturn'
	,'JF05'
	,'key used to track when selected return journey option is changed on journey fares page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyFares'
	,'findSummaryResultTableControlOutward'
	,'JF06'
	,'key used to track when selected outward journey option is changed on journey fares page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyFares'
	,'findSummaryResultTableControlReturn'
	,'JF07'
	,'key used to track when selected return journey option is changed on journey fares page' 
GO


---------------------------------------------------------------------------------------
-- Tracking keys for JourneyMap page
---------------------------------------------------------------------------------------
EXECUTE dbo.AddPageTrackingKey
	 'JourneyMap'
	,'summaryResultTableControlOutward'
	,'JM01'
	,'key used to track when selected outward journey option is changed on journey map page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyMap'
	,'summaryResultTableControlReturn'
	,'JM02'
	,'key used to track when selected return journey option is changed on journey map page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyMap'
	,'findSummaryResultTableControlOutward'
	,'JM03'
	,'key used to track when selected outward journey option is changed on journey map page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneyMap'
	,'findSummaryResultTableControlReturn'
	,'JM04'
	,'key used to track when selected return journey option is changed on journey map page' 
GO

---------------------------------------------------------------------------------------
-- Tracking keys for JourneySummary page
---------------------------------------------------------------------------------------
EXECUTE dbo.AddPageTrackingKey
	 'JourneySummary'
	,'summaryResultTableControlOutward'
	,'JS01'
	,'key used to track when selected outward journey option is changed on journey summary page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneySummary'
	,'summaryResultTableControlReturn'
	,'JS02'
	,'key used to track when selected return journey option is changed on journey summary page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneySummary'
	,'findSummaryResultTableControlOutward'
	,'JS03'
	,'key used to track when selected outward journey option is changed on journey summary page'

EXECUTE dbo.AddPageTrackingKey
	 'JourneySummary'
	,'findSummaryResultTableControlReturn'
	,'JS04'
	,'key used to track when selected return journey option is changed on journey summary page' 
GO

-----------------------------------------------------------------------------------------
-- Visit Planner Results Page Trakcing keys
-----------------------------------------------------------------------------------------
EXECUTE dbo.AddPageTrackingKey 
	 'VisitPlannerResults'
	,'OutwardDate'
	,'VPR01'
	,'visit planner result date selected by user'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1605
SET @ScriptDesc = 'Script to add Tracking keys for Intellitracker'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO