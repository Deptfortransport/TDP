-- ***********************************************
-- NAME 		: DUP1418_EBC_Properties.sql
-- DESCRIPTION 	: Script to add EBC planner properties
-- AUTHOR		: Mitesh Modi
-- DATE			: 16 Sep 2009
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'WaitPageRefreshSeconds.EnvironmentalBenefitsCalculator' and ThemeId = 1)
BEGIN
	insert into properties values ('WaitPageRefreshSeconds.EnvironmentalBenefitsCalculator', '2', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '2'
	where pname = 'WaitPageRefreshSeconds.EnvironmentalBenefitsCalculator' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.Available' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.Available', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'EnvironmentalBenefitsCalculator.Available' and ThemeId = 1
END


---------------------------------------------------------------------
-- JOURNEY PLANNING PROPERTIES

IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.OutwardDayOfWeek' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.OutwardDayOfWeek', 'Tuesday', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Tuesday'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.OutwardDayOfWeek' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.OutwardTime' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.OutwardTime', '0100', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0100'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.OutwardTime' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.LeaveAt' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.LeaveAt', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.LeaveAt' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.JourneyAlgorithm' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.JourneyAlgorithm', 'Fastest', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Fastest'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.JourneyAlgorithm' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.CarSize' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.CarSize', 'Medium', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Medium'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.CarSize' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.FuelType' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.FuelType', 'Petrol', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'Petrol'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.FuelType' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.IgnoreCongestion' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.IgnoreCongestion', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.IgnoreCongestion' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.CongestionValue' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.CongestionValue', '0', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.CongestionValue' and ThemeId = 1
END

---------------------------------------------------------------------
-- LOGGING PROPERTIES

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom.Trace' 
	and AID = 'TDRemotingHost'
	and GID = 'UserPortal'
	and PartnerId = 0
	and ThemeId = 1)
BEGIN
	insert into properties values ('Logging.Event.Custom.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EBCCalculation.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EBCCalculation.Assembly' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Assembly', 'td.userportal.environmentalbenefits', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Assembly', 'td.userportal.environmentalbenefits', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Assembly', 'td.userportal.environmentalbenefits', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Assembly', 'td.userportal.environmentalbenefits', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EBCCalculation.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EBCCalculation.Name' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Name', 'EBCCalculationEvent', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Name', 'EBCCalculationEvent', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Name', 'EBCCalculationEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Name', 'EBCCalculationEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EBCCalculation.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EBCCalculation.Publishers' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Publishers', 'FILE1', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.EBCCalculation.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.EBCCalculation.Trace' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Trace', 'On', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.EBCCalculation.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and pValue LIKE '%EBCCalculation%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' EBCCalculation'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EventReceiver')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EventReceiver'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and pValue LIKE '%EBCCalculation%')
BEGIN
	UPDATE properties
	SET pValue =  
		(SELECT pValue + ' EBCCalculation'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'EventReceiverGroup')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'EventReceiverGroup'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and pValue LIKE '%EBCCalculation%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' EBCCalculation'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'TDRemotingHost')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'TDRemotingHost'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and pValue LIKE '%EBCCalculation%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' EBCCalculation'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'Web')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'Web'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1418
SET @ScriptDesc = 'EBC planner properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO