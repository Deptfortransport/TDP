-- ***********************************************
-- NAME 		: DUP1366_JourneyEmissions_ChangeNotification.sql
-- DESCRIPTION 		: Add JourneyEmissionsFactor to Change Notification Table
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [PermanentPortal]
GO

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'JourneyEmissionsFactor')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('JourneyEmissionsFactor',1)
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1366
SET @ScriptDesc = 'Added JourneyEmissionsFactor to Change Notification Table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------