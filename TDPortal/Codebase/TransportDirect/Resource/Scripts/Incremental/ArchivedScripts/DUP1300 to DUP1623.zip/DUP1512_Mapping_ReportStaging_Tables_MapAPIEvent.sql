-- ***********************************************
-- NAME 			: DUP1512_Mapping_ReportStaging_Tables_MapAPIEvent.sql
-- DESCRIPTION 			: Script to add table for MapAPIEvents
-- AUTHOR			: Amit Patel
-- DATE				: 12 Nov 2009
-- ***********************************************

USE [ReportStagingDB]
GO

-----------------------------------------------------------------
-- ReportStagingDB - MapAPIEvent table
-----------------------------------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[MapAPIEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[MapAPIEvent]
GO

CREATE TABLE [dbo].[MapAPIEvent](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CommandCategory] [varchar](50) NULL,
	[Submitted] [datetime] NULL,
	[SessionId] [varchar](50) NULL,
	[TimeLogged] [datetime] NULL
) ON [PRIMARY]

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1512
SET @ScriptDesc = 'Add ReportStaging tables for MapAPIEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
