-- *************************************************************************************
-- NAME 		: DUP1447_Add_DepartureBoardServices_CustomEvents.sql
-- DESCRIPTION  	: Add DepartureBoardService custom logging events
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- ****************************** WARNING **********************************************
-- THE SCRIPT NEEDS Logging.Event.Custom.RTTI.Publishers  PROPERTY VALUE 
-- CHANGE FROM 'FILE1' to 'QUEUE1' WHEN IT GOES ON BUILD
-- *************************************************************************************

USE [PermanentPortal]
GO

-- Update existing custom event properties to also mointor for EXP events

DECLARE @LoggingEventCustom VARCHAR(500)


SET @LoggingEventCustom = ( select pValue from properties 
                            where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the events multiple times if the script is run more than once
    IF not exists ( select top 1 * from properties 
                    where pvalue like '% RTTI%' and pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @LoggingEventCustom + ' RTTI'
    	where pName = 'Logging.Event.Custom' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1
    END
END




------------------------------------------------------
-- EXP setup
delete from properties where pname like 'Logging.Event.Custom.RTTI.%' and AID = 'Web' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1
delete from properties where pname like 'Logging.Event.Custom.RTTI.%' and AID = 'TDRemotingHost' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1


-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.RTTI.Assembly', 'td.reportdataprovider.tdpcustomevents', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.RTTI.Name', 'RTTIEvent', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.RTTI.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.RTTI.Trace', 'On', 'Web', 'UserPortal', 0, 1)

-- Change 'FILE1' to 'QUEUE1'
insert into properties values ('Logging.Event.Custom.RTTI.Assembly', 'td.reportdataprovider.tdpcustomevents', 'TDRemotingHost', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.RTTI.Name', 'RTTIEvent', 'TDRemotingHost', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.RTTI.Publishers', 'FILE1', 'TDRemotingHost', 'UserPortal', 0, 1)
insert into properties values ('Logging.Event.Custom.RTTI.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1447
SET @ScriptDesc = 'Add DepartureBoardService custom logging events'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
