-- ***********************************************
-- NAME 			: DUP1365_ExposedServices_CarJourneyPlanner_Reporting.sql
-- DESCRIPTION 		: Script to setup the reporting types for  Car Journey Planner Enhanced Exposed Service
-- AUTHOR			: Mitesh Modi
-- DATE				: 16 Jul 2009
-- ***********************************************

USE [Reporting]
GO

-- Add operation types to Reporting
IF NOT EXISTS (SELECT * FROM [dbo].[EnhancedExposedOperationType] WHERE EEOTType  = 'PlanCarJourney')
BEGIN
	INSERT INTO EnhancedExposedOperationType(EEOTType, EEOTDescription)
	VALUES ('PlanCarJourney', 'PlanCarJourney operation for CarJourneyPlannerSynchronous service')
END

IF NOT EXISTS (SELECT * FROM [dbo].[EnhancedExposedOperationType] WHERE EEOTType  = 'GetGridReference')
BEGIN
	INSERT INTO EnhancedExposedOperationType(EEOTType, EEOTDescription)
	VALUES ('GetGridReference', 'GetGridReference operation for CarJourneyPlannerSynchronous service')
END


-- Add enhanced exposed service type to Reporting
IF NOT EXISTS (SELECT * FROM [dbo].[EnhancedExposedServicesType] WHERE EESTType  = 'TransportDirect_EnhancedExposedServices_CarJourneyPlannerSynchronous_V1')
BEGIN
	INSERT INTO EnhancedExposedServicesType(EESTType, EESTDescription)
	VALUES ('TransportDirect_EnhancedExposedServices_CarJourneyPlannerSynchronous_V1', 'EnhancedExposedServices CarJourneyPlannerSynchronous_V1')
END 

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1365
SET @ScriptDesc = 'Exposed Services - Car Journey Planner Reporting'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

