-- ***********************************************
-- NAME 			: DUP1303_CyclePlanner_SoftContentUpdate.sql
-- DESCRIPTION 			: Script to update Cycle PLanner Right Hand Menu and Error Message
-- AUTHOR			: Amit Patel
-- DATE				: 26 Feb 2009
-- ***********************************************

USE [Content]
GO


-- Right Hand Panel content

EXEC AddtblContent
1, 1, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput',
'<div class="Column3Header"><div class="txtsevenbbl">
Cycle Planning</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
This is the first version of Transport Direct�s new cycle planner. We have worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure that there is good quality information on cycling in the following areas:
<ul>
<li> Merseyside</li>
<li> Manchester</li>
</ul>
<br />
We would really appreciate your feedback on this initial version of the planner. Please click on ''Contact us'' at the bottom of the page to let us know what you think or report any problems.
<br /><br />
We will consider all feedback and will be improving the planner over the coming weeks. Work is also ongoing to provide cycle planning information in more areas - please check again soon if your local area is not yet available.
<br /><br />
Our aim is to provide national coverage for cycle planning soon. Once data is available in more areas and we have considered initial feedback, this page will be 
linked to from the main Transport Direct site.
<br /><br />
</td></tr>
</tbody></table></div>',
'<div class="Column3Header"><div class="txtsevenbbl">
Trefnu Taith Feicio</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
Dyma''r fersiwn gyntaf o drefnwr teithiau beicio newydd Transport Direct. Rydym wedi gweithio gyda Cycling England, Arolwg Ordnans a''r awdurdodau lleol perthnasol i sicrhau bod gwybodaeth o ansawdd ar gael am feicio yn yr ardaloedd canlynol:
<ul>
<li> Glannau Mersi</li>
<li> Manchester</li>
</ul>
<br />
Byddem yn wirioneddol yn gwerthfawrogi eich adborth am y fersiwn wreiddiol hon o''r trefnwr. Cliciwch ar ''Cysylltwch � ni'' ar waelod y dudalen i roi gwybod inni beth yw eich barn neu adrodd am unrhyw broblemau.
<br /><br />
Byddwn yn ystyried pob adborth ac yn gwella''r trefnwr dros yr wythnosau nesaf. Mae gwaith yn parhau hefyd i roi gwybodaeth i drefnu teithiau beicio mewn mwy o ardaloedd - dewch yn �l eto cyn bo hir os nad yw eich ardal leol ar gael eto.
<br /><br />
Ein nod yw rhoi gwybodaeth ar gyfer trefnu teithiau beicio ledled y genedl cyn bo hir. Pan fydd data ar gael mewn mwy o ardaloedd a phan fyddwn wedi ystyried adborth cychwynnol, bydd prif safle Transport Direct yn cysylltu �''r dudalen hon. 
<br /><br />
</td></tr>
</tbody></table></div>'

GO

EXEC AddtblContent
1, 69, 'TDFindCyclePromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindCycleInput',
'<div class="Column3Header"><div class="txtsevenbbl">
Cycle Planning</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
This is the first version of Transport Direct''s new cycle planner. We have worked with Cycling England, Ordnance Survey and the relevant local authorities to ensure that there is good quality information on cycling in the following areas:
<ul>
<li> <strong>Merseyside</strong></li>
<li> <strong>Manchester</strong></li>
</ul>
<br />
We would really appreciate your feedback on this initial version of the planner. Please click on �Contact us� at the bottom of the page to let us know what you think or report any problems.
<br /><br />
We will consider all feedback and will be improving the planner over the coming weeks. Work is also ongoing to provide cycle planning information in more areas - please check again soon if your local area is not yet available.
<br /><br />
Our aim is to provide national coverage for cycle planning soon. Once data is available in more areas and we have considered initial feedback, this page will be linked to from the main Transport Direct site.
<br /><br />
</td></tr>
</tbody></table></div>',
'<div class="Column3Header"><div class="txtsevenbbl">
Trefnu Taith Feicio</div><div class="clearboth"></div></div>
<div class="Column3Content">
<table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>
<tr><td class="txtseven">
Dyma''r fersiwn gyntaf o drefnwr teithiau beicio newydd Transport Direct. Rydym wedi gweithio gyda Cycling England, Arolwg Ordnans a''r awdurdodau lleol perthnasol i sicrhau bod gwybodaeth o ansawdd ar gael am feicio yn yr ardaloedd canlynol:
<ul>
<li> <strong>Glannau Mersi</strong></li>
<li> <strong>Manchester</strong></li>
</ul>
<br />
Byddem yn wirioneddol yn gwerthfawrogi eich adborth am y fersiwn wreiddiol hon o''r trefnwr. Cliciwch ar ''Cysylltwch � ni'' ar waelod y dudalen i roi gwybod inni beth yw eich barn neu adrodd am unrhyw broblemau.
<br /><br />
Byddwn yn ystyried pob adborth ac yn gwella''r trefnwr dros yr wythnosau nesaf. Mae gwaith yn parhau hefyd i roi gwybodaeth i drefnu teithiau beicio mewn mwy o ardaloedd - dewch yn �l eto cyn bo hir os nad yw eich ardal leol ar gael eto.
<br /><br />
Ein nod yw rhoi gwybodaeth ar gyfer trefnu teithiau beicio ledled y genedl cyn bo hir. Pan fydd data ar gael mewn mwy o ardaloedd a phan fyddwn wedi ystyried adborth cychwynnol, bydd prif safle Transport Direct yn cysylltu �''r dudalen hon.
<br /><br />
</td></tr>
</tbody></table></div>'


-- Error Message
EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationInInvalidCycleArea',
'At the moment we are able to plan cycle journeys in Merseyside and Manchester.  Please click the ''clear page'' button below to enter new journey details.  To find out more please <a href="/Web2/Help/HelpInfo.aspx#A1.7">go to the FAQ on cycle data areas</a>.',
'Ar hyn o bryd gallwn gynllunio siwrneiau beicio ym Glannau Mersi. Cliciwch y botwm ''clirio tudalen" isod i nodi manylion siwrnai newydd.  I ganfod mwy ewch i''r Cwestiynau Cyffredin ar ardaloedd data beicio <a href="/Web2/Help/HelpInfo.aspx#A1.7">os gwelwch'




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1302
SET @ScriptDesc = 'Script to update Cycle PLanner Drop Down Lists'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO