-- ***********************************************
-- NAME 		: DUP1509_EastCoast_Changes.sql
-- DESCRIPTION 	: Script to update NXEC Retailer Details update to East Coast
-- AUTHOR		: Rich Broddle
-- DATE			: 11 Nov 2009
-- ************************************************

USE [PermanentPortal]
GO

--Update Retail Handoff info
IF not exists (select top 1 * from [PermanentPortal].[dbo].[Retailers] where RetailerId like 'NEXEC%')
BEGIN
	INSERT INTO [PermanentPortal].[dbo].[Retailers]
           ([RetailerId]
           ,[Name]
           ,[WebsiteURL]
           ,[HandoffURL]
           ,[PhoneNumber]
           ,[DisplayURL]
           ,[IconURL]
           ,[AllowsMTH]
           ,[SmallIconUrl])
     VALUES
           ('NEXEC'
           ,'East Coast'
           ,'http://www.eastcoast.co.uk'
           ,'http://tickets.eastcoast.co.uk/ec/en/landing/TDP'
           ,'08457000125'
           ,'http://www.eastcoast.co.uk/'
           ,'/Web/images/gifs/SoftContent/eastcoast_lg.gif'
           ,'N'
           ,'/Web/images/gifs/SoftContent/eastcoast_sm.gif')
END
ELSE
BEGIN
	UPDATE [PermanentPortal].[dbo].[Retailers]
	   SET [Name] = 'East Coast'
		  ,[WebsiteURL] = 'http://www.eastcoast.co.uk'
		  ,[HandoffURL] = 'http://tickets.eastcoast.co.uk/ec/en/landing/TDP'
		  ,[PhoneNumber] = '08457225225'
		  ,[DisplayURL] = 'http://www.eastcoast.co.uk/'
		  ,[IconURL] = '/Web/images/gifs/SoftContent/eastcoast_lg.gif'
		  ,[AllowsMTH] = 'N'
		  ,[SmallIconUrl] = '/Web/images/gifs/SoftContent/eastcoast_sm.gif'
	WHERE RetailerId = 'NEXEC'  
END

GO

USE [TransientPortal]
GO

--Update all refs to NXEC in IncludedTOCs table
BEGIN
	UPDATE [TransientPortal].[dbo].[IncludedTocs]
	SET [TocRef] = cast('East Coast' as TEXT)
	WHERE cast([TocRef] as varchar(50)) LIKE 'National Express East Coast%'
END

GO

--Update Service Operators table
IF not exists (select top 1 * from [TransientPortal].[dbo].[ServiceOperators] where [OperatorCode] = 'GR')
	BEGIN
	INSERT INTO [TransientPortal].[dbo].[ServiceOperators]
			   ([OperatorCode]
			   ,[OperatorName])
		 VALUES
			   ('GR'
			   ,'East Coast')
	END
ELSE
	BEGIN
	UPDATE [TransientPortal].[dbo].[ServiceOperators]
	   SET [OperatorName] = 'East Coast'
	 WHERE [OperatorCode] = 'GR'
	END

GO
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1509
SET @ScriptDesc = 'NXEC Retailer Details update to East Coast'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO