-- ***********************************************
-- NAME 	: DUP1333_Create_EESGazOverride_Database_Table.sql
-- DESCRIPTION 	: Creates the database table used to override some text strings in the Gaz 
--                DB with more user friendly alternatives.
-- AUTHOR	: Mark Turner
-- ************************************************

USE [PermanentPortal]
GO

-----------------------------------------------
-- Drop Existing Table
-----------------------------------------------
IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.EnhancedExposedServicesGazOverride') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    DROP TABLE [dbo].[EnhancedExposedServicesGazOverride] 
END
GO

-----------------------------------------------
-- Create table
-----------------------------------------------
BEGIN
    CREATE TABLE dbo.EnhancedExposedServicesGazOverride (
        [Identifier] [varchar] (10) NOT NULL, [Replacement] [varchar] (20) NOT NULL)

    ALTER TABLE dbo.EnhancedExposedServicesGazOverride 
        ADD CONSTRAINT PK_Identifier PRIMARY KEY CLUSTERED ( Identifier ) 
END
GO

----------------------------------------------------------------
-- Create GetIdentifiers stored proc
----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE ID = object_id(N'[dbo].[GetIdentifiers]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
BEGIN
    EXEC ('CREATE PROCEDURE GetIdentifiers AS BEGIN SET NOCOUNT ON END')
END
GO

----------------------------------------------------------------
-- Update GetIdentifiers stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO

SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE GetIdentifiers
AS
BEGIN
    SET NOCOUNT OFF

    DECLARE @localized_string_UnableToGet AS VARCHAR(40)
    SET @localized_string_UnableToGet = 'Unable to retrieve Identifiers'

    SELECT Identifier, Replacement FROM EnhancedExposedServicesGazOverride 

    IF @@error <> 0
    BEGIN
        RAISERROR (@localized_string_UnableToGet, 1,1)
        RETURN -1
    END
END
GO

SET QUOTED_IDENTIFIER OFF 
GO

SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Add exec permission to the appropriate user
----------------------------------------------------------------
GRANT EXEC ON [dbo].[GetIdentifiers] TO [?????]
-- Will almost certianly be ASPUSER
GO

----------------------------------------------------------------
-- Populate Table
----------------------------------------------------------------

INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('APP'	,'APPROACH')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('ADJ'	,'ADJACENT')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('ARC'	,'ARCADE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('AV'	,'AVENUE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('BLDG'	,'BUILDING')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('BLVD'	,'BOULEVARD')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('BR'	,'BRIDGE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('BSNS'	,'BUSINESS')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('BWAY'	,'BROADWAY')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('CH'	,'CHURCH')

INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('CLO'	,'CLOSE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('COL'	,'COLLEGE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('CRES'	,'CRESCENT')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('CT'	,'COURT')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('CTR'	,'CENTRE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('DRI'	,'DRIVE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('EST'	,'ESTATE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('GDNS'	,'GARDENS')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('GRN'	,'GREEN')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('GRO'	,'GROVE')

INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('GT'	,'GREAT')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('HOSP'	,'HOSPITAL')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('INFMY'	,'INFIRMARY')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('JCT'	,'JUNCTION')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('LN'	,'LANE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('LT'	,'LITTLE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('LWR'	,'LOWER')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('MKT'	,'MARKET')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('OPP'	,'OPPOSITE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('MT'	,'MOUNT')

INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('PASS'	,'PASSAGE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('PDE'	,'PARADE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('PK'	,'PARK')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('PL'	,'PLACE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('PO'	,'POST OFFICE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('QUAD'	,'QUADRANT')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('RD'	,'ROAD')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('RDBT'	,'ROUNDABOUT')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('SCH'	,'SCHOOL')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('SQ'	,'SQUARE')

INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('STN'	,'STATION')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('TER'	,'TERRACE')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('UPR'	,'UPPER')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('WLK'	,'WALK')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('WY'	,'WAY')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('YD'	,'YARD')
INSERT INTO EnhancedExposedServicesGazOverride (Identifier, Replacement)
VALUES ('PH'	,'PUBLIC HOUSE')

------------------------
-- Change Log 
------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber =1333
SET @ScriptDesc = 'Added table for EES Gaz Override.'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
