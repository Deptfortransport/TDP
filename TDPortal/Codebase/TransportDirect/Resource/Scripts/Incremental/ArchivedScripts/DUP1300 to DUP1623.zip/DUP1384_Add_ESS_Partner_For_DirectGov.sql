-- *************************************************************************************
-- NAME 		: DUP1384_Add_ESS_Partner_For_DirectGov.sql
-- DESCRIPTION  	: Add new EES partner for new direct gov site
-- AUTHOR		: John Frank
-- *************************************************************************************

USE [PermanentPortal]
GO

DELETE FROM dbo.PartnerAllowedServices
WHERE PartnerId = (SELECT PartnerId FROM dbo.Partner WHERE HostName = 'DirectGovJPlan')

DELETE FROM dbo.Partner WHERE HostName = 'DirectGovJPlan'
GO

INSERT INTO dbo.Partner (PartnerId, HostName, PartnerName, Channel, PartnerPassword)
VALUES (111, 'DirectGovJPlan', 'DirectGovJPlan', 'EES', 'zQAI7tNUWMi+izIpEIqvzUPQdujyh/cxjxR5U5z0L4Y=')
GO

INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 1)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 2)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 3)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 4)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 5)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 6)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 7)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 8)
INSERT INTO dbo.PartnerAllowedServices (PartnerId, EESTID)
VALUES (111, 9)
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1384
SET @ScriptDesc = 'Add new DirectGov EES partner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
