-- ***********************************************
-- NAME 		: DUP1564_CyclingWales_ExternalLink.sql
-- DESCRIPTION 		: Script to modify External link for Cycling Wales
-- AUTHOR		: Mark Turner
-- DATE			: 1 Feb 2010 
-- ************************************************


USE [TransientPortal]
GO

-- Cycling Wales
EXEC AddExternalLink
'CyclePlanner.CyclingWales', 
'http://wales.gov.uk/topics/transport/integrated/walkingcycling/?lang=en', 
'http://wales.gov.uk/topics/transport/integrated/walkingcycling/?lang=en', 
'Cycle Planner - Cycling Wales url'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1564
SET @ScriptDesc = 'Change to Cycling Wales url'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO