-- *************************************************************************************
-- NAME 		: DUP1388_TransportDirect_Content_1_MiniHome_PlanAJourney.sql
-- DESCRIPTION  : Updates to Plan a journey homepage information panel
-- AUTHOR		: Mitesh Modi
-- DATE			: 28 Aug 2009
-- *************************************************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER

USE [Content]
GO

DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_home')
SET @ThemeId = 1

-- Add the html text
EXEC AddtblContent
@ThemeId, @GroupId, 'PlanAJourneyInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/Home'
-- ENGLISH
,
'<div class="MinihomeHyperlinksInfoContent">
  <div class="MinihomeHyperlinksInfoHeader">
  <div class="txtsevenbbl">
    <h2>Getting what you want from the journey planners</h2>
  </div>
  <!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</div>
  <div class="MinihomeSoftContent">
    <p>You can plan a journey in a number of different ways to suit
    your needs.</p>
    <br />
    <h3>Plan me a journey door to door...</h3>
    <br />
    <br />
    <p>The simplest way to search is using the 
    <a href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">
    door-to-door journey planner</a>, which searches for up to five
    journey options - by joined-up public transport or by car. You
    can plan from postcodes, places, stations and even local
    attractions.</p>
    <br />
    <p>You can type in where and when you want to travel from and
    travel to...</p>
    <img style="PADDING-RIGHT: 10px"
    alt="An image showing a summary of journey results"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneySummary.JPG"
    align="left" border="0" />
    <p>...and the system will give you a list of options to choose
    from.</p>
    <br clear="left" />
    <br />
    <img style="PADDING-RIGHT: 10px; PADDING-LEFT: 15px"
    alt="An image showing a diagram of the detail of a journey plan"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/journey_details_500L.GIF"
    align="right" border="0" />
    <p>Highlight your preferred journey, the "Details" button
    allows you to see step-by-step directions, including any
    connections you need to make, stations names, interchange times
    or driving instructions if you have selected the car journey.
    Some of the images and text on the Details page contain links
    to further useful information, too.</p>
    <p>&#160;</p>
    <p>The "Maps" and "Tickets/Costs" buttons allow you to see
    route maps, ticket prices and driving costs. 
    <br />
    <br />By clicking "Tickets/Costs", you can check the prices and
    availability of rail and coach tickets. If you want to book, we
    can automatically pass your journey details to one of our
    partner retailer sites so that you can buy online. 
    <br />
    <br />Similarly, you can see your route, or individual sections
    of it, on a map by clicking the "map button". You can also list
    stops for a service by clicking on the transport icon in your
    journey itinerary.</p>
    <img alt="An image of a map showing the route of a specific journey"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyMap.JPG"
    align="left" border="0" />
    <p>
      <img alt="An image showing a sample of car driving instructions"
      src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyCarInstructions.JPG"
      align="top" border="0" />
      <br clear="left" />
    </p>
    <p>&#160;</p>
    <h3>I know how I want to travel...</h3>
    <p>&#160;</p>
    <p>Perhaps you have already decided what form of transport to
    use for the main part of your journey. 
    <br />
    <br />In this case you would be better off starting with 
    <a href="/Web2/JourneyPlanning/FindTrainInput.aspx">Find a
    train</a>, 
    <a href="/Web2/JourneyPlanning/FindFlightInput.aspx">Find a
    flight</a>, 
    <a href="/Web2/JourneyPlanning/FindCarInput.aspx">Find a car
    route</a>, 
    <a href="/Web2/JourneyPlanning/FindCoachInput.aspx">Find a
    coach</a>&#160;or 
    <a href="/Web2/JourneyPlanning/FindCycleInput.aspx">Find a
    cycle route.</a>&#160;These will list journeys for just that
    type of transport.</p>
    <br />
    <br />
    <img alt="Image showing the quick planner icons on Transport Direct"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyQuickPlanners.JPG"
    border="0" />
    <p>&#160;</p>
    <p>If you use 
    <a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Find a
    Train</a>, you can choose between a search by time or by price.
    A search by price allows you to choose from a range of fares
    before you see the journey details relevant to that ticket
    price.</p>
    <p>&#160;</p>
    <p>You may also want to compare train, plane, coach and car
    journeys between two cities or towns in Britain on a given day.
    You can do this using 
    <a href="/Web2/JourneyPlanning/FindTrunkInput.aspx">compare how
    to get from city to city</a>.</p>
    <p>&#160;</p>
    <p>Alternatively you may want to find your nearest station or
    car park and then plan a journey to or from there. Or find a
    place on a map and then plan to or from there. This is easy to
    do - see our 
    <a href="/Web2/Maps/Home.aspx">Find a Place</a>&#160;page for
    more details.</p>
    <p>&#160;</p>
    <h3>Plan me a cycle route&#8230;</h3>
    <p>&#160;</p>
    <p>Planning a cycle route on Transport Direct is simple. You
    can find our cycle planner by clicking the links in the left
    hand menu on the home page and on the journey planner pages.
    There is also a link from the icons at the top of this page and
    in the sitemap.</p>
    <p>&#160;</p>
    <p>The cycle planner is designed to plan you local cycle
    journeys within urban areas &#8211; for example, your journey
    to work or school. Once you are in the cycle planner simply
    enter your start and end location and choose between
    Address/postcode, Facility/attraction or Station/airport. You
    can even select the point you want to start or end your journey
    from a map. Then enter a date and time and choose a type of
    journey. You can chose from the quickest journey, one that
    takes the quietest route, or a recreational journey. Then click
    next.</p>
    <p>&#160;</p>
    <p>There are also advanced options which allow you to :</p>
    <ul class="listerdisc">
      <li>Set your cycling speed (average speed is
      20kph/13mph)</li>
      <li>Nominate a via point for your journey</li>
      <li>Avoid unlit roads, or walking with your bike</li>
      <li>Avoid time based restrictions</li>
    </ul>
    <br class="clearboth" />
    <img style="PADDING-RIGHT: 10px"
    alt="An image showing a Cycle Planner input page"
    title="An image showing a Cycle Planner input page"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/findCycleInput.gif"
    align="left" border="0" />
    <p>At the moment there are a limited number of local authority
    areas included in our cycle planner. This is due to the
    availability of good quality cycle route data. We are working
    closely with Cycling England and local authorities to produce
    data and the areas where you are able to plan a cycle journey
    will increase steadily in 2009. 
    <a href="/Web2/Help/HelpCycle.aspx#A16.2">There is an FAQ
    describing the areas where cycle data is available.</a></p>
    <p>&#160;</p>
    <p>The planner will use roads, cycle paths, bridleways, tow
    paths and other routes available to a bicycle. We have tried to
    make the data as detailed as possible but if you should find a
    route you believe to be incorrect then we would welcome your
    feedback. Please let us know by clicking the &#8220;Contact
    us&#8221; link at the bottom of the journey results page.</p>
    <br class="clearboth" />
    <img style="PADDING-LEFT: 10px"
    alt="An image of a map showing the route of a specific journey"
    title="An image of a map showing the route of a specific journey"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/findCycleMap.gif"
    align="right" border="0" />
    <p>Once Transport Direct has found your cycle route the details
    will be displayed along with a graph showing the gradient of
    the journey. There will also be the option to look at your
    journey alongside other modes of transport to see how CO2
    emissions compare &#8211; click the &#8216;CO2&#8217;
    button.</p>
    <p>&#160;</p>
    <p>The &#8221;Maps&#8221; button allows you to see a route map
    of the journey. If you choose to print the map we will also
    display more detailed tiled views of the journey.</p>
    <p>&#160;</p>
    <p>Those of you with GPS devices for your bike will be able to
    download a 
    <a href="/Web2/Help/HelpCycle.aspx#A16.4">GPX
    file</a>&#160;which you can load onto your mobile device giving
    you a route plan of your journey.</p>
    <br class="clearboth" />
    <img style="PADDING-LEFT: 8px"
    alt="An image showing the details screen of a cycle journey plan"
    title="An image showing the details screen of a cycle journey plan"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/findCycleDetails.gif"
    border="0" />
    <br class="clearboth" />
    <p>&#160;</p>
    <h3>Amending my chosen journey</h3>
    <p>&#160;</p>
    <p>Once you have found a journey you want, you can add further
    parts to your journey or amend some or all of your journey.</p>
    <table class="txtseven" cellspacing="0" cellpadding="2"
    border="0">
      <tbody>
        <tr>
          <td>
            <img alt="Image representing the action of adding to the overall journey"
            src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyExtend.JPG"
            border="0" />
          </td>
          <td>You can find the main part of your journey and then
          extend the plan to show how to get from the station to
          your door by car or public transport.</td>
        </tr>
        <tr>
          <td>
            <img alt="Image representing the action of changing the journey plan"
            src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyReplace.JPG"
            border="0" />
          </td>
          <td>You can modify your journey by replacing a section
          that uses public transport with a car journey, for
          example to travel home from the station by taxi rather
          than by bus.</td>
        </tr>
        <tr>
          <td>
            <img alt="Image representing the action of adjusting the timings of a journey"
            src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyAdjust.JPG"
            border="0" />
          </td>
          <td>If you would like to allow more time at the places
          where you have to change transport, you can adjust your
          journey.</td>
        </tr>
      </tbody>
    </table>
    <p>&#160;</p>
    <img alt="Image of the &#8216;Amend date and time&#8217; feature"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyAmend.JPG"
    border="0" />
    <p>&#160;</p>
    <p>Once you have found some journey options, you can adjust the
    times and the routes, either by clicking the "Amend" button or
    by using the "Amend date and time" feature, at the bottom of
    the page.</p>
    <p>&#160;</p>
    <h3>Can you remember my journey request?</h3>
    <p>&#160;</p>
    <p>Once you have found a journey, you can save it as a bookmark
    ("favourite") in your browser...</p>
    <p>&#160;</p>
    <img alt="Image showing feature to bookmark a journey"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyBookmark.JPG"
    border="0" />
    <p>&#160;</p>
    <p>...and retrieve it at a future time from the "Favourites"
    menu in your browser.</p>
    <p>&#160;</p>
    <img alt="Screenshot showing the browser favourites menu bar"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyFavourites.jpg"
    border="0" />
  </div>
</div>
'
-- WELSH
,
'<div class="MinihomeHyperlinksInfoContent">
  <div class="MinihomeHyperlinksInfoHeader">
  <div class="txtsevenbbl">
    <h2>Dywedwch fwy wrthyf</h2>
  </div>
  <!-- Following spaces help formatting in 2 ways: 1. Give outer div real content to give height; 2. Add a padding to ensure nice wrapping when ramping up text size -->&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</div>
  <div class="MinihomeSoftContent">
    <p>Gallwch gynllunio eich siwrnai mewn nifer o wahanol ffyrdd i
    weddu i&#8217;ch anghenion.</p>
    <br />
    <h3>Cynlluniwch siwrnai o ddrws i ddrws i mi...</h3>
    <br />
    <br />
    <p>Y ffordd symlaf o chwilio yw defnyddio&#8217;r 
    <a href="/Web2/JourneyPlanning/JourneyPlannerInput.aspx">
    cynllunydd siwrnai o ddrws-i-ddrws</a>, sy&#8217;n chwilio am
    hyd at bump o ddewisiadau o ran siwrneion &#8211; drwy gludiant
    cyhoeddus wedi ei gydlynu neu mewn car. Gallwch gynllunio o
    godau post, lleoedd, gorsafoedd a hyd yn oed atyniadau
    lleol.</p>
    <br />
    <p>Gallwch deipio i mewn ble a phryd y dymunwch deithio ohono a
    theithio iddo...</p>
    <img style="PADDING-RIGHT: 10px"
    alt="Delwedd yn dangos crynodeb o ganlyniadau&#8217;r siwrnai"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneySummary.JPG"
    align="left" border="0" />
    <p>...a bydd y system yn rhoi rhestr o ddewisiadau i chi ddewis
    ohonynt.</p>
    <br clear="left" />
    <br />
    <img style="PADDING-RIGHT: 10px; PADDING-LEFT: 15px"
    alt="Delwedd yn dangos diagram o fanylion cynllun siwrnai"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/journey_details_500L.GIF"
    align="right" border="0" />
    <p>Tynnwch sylw at eich hoff siwrnai, yna cliciwch ar
    &#8216;Manylion&#8217; i weld cyfarwyddiadau manwl, gan gynnwys
    unrhyw gysylltiadau y bydd angen i chi eu gwneud, enwau&#8217;r
    gorsafoedd, amserau rhyng-newid neu gyfarwyddiadau gyrru os
    ydych wedi dewis y siwrnai car. Mae rhai o&#8217;r delweddau
    a&#8217;r testun ar y dudalen Manylion yn cynnwys dolennau i
    wybodaeth ddefnyddiol arall hefyd.</p>
    <p>&#160;</p>
    <p>Mae&#8217;r botymau &#8216;Mapiau&#8217; a
    &#8216;Tocynnau/Costau&#8217; yn caniat&#225;u i chi weld
    mapiau o lwybrau, prisiau tocynnau a chostau gyrru. 
    <br />
    <br />Drwy glicio ar &#8216;Tocynnau/Costau&#8217; gallwch
    wirio&#8217;r prisiau ac argaeledd tocynnau rheilffordd a
    bysiau moethus. Os dymunwch archebu, gallwn drosglwyddo
    manylion eich siwrnai yn awtomatig i safle adwerthu un
    o&#8217;n partneriaid fel y gallwch brynu ar-lein. 
    <br />
    <br />Yn yr un modd, gallwch weld eich llwybr neu adrannau
    unigol ohono, ar fap drwy glicio ar &#8216;botwm y map&#8217;.
    Gallwch hefyd restru arosfannau ar gyfer gwasanaeth drwy glicio
    ar yr eicon cludiant yn nisgrifiad eich siwrnai.</p>
    <img alt="Delwedd o fap yn dangos llwybr siwrnai benodol"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyMap.JPG"
    align="left" border="0" />
    <p>
      <img alt="Delwedd yn dangos sampl o&#8217;r cyfarwyddiadau gyrru car"
      src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyCarInstructions.JPG"
      align="top" border="0" />
      <br clear="left" />
    </p>
    <p>&#160;</p>
    <h3>Rwy&#8217;n gwybod sut rydw i eisiau teithio...</h3>
    <p>&#160;</p>
    <p>fallai eich bod eisoes wedi penderfynu pa fath o gludiant
    i&#8217;w ddefnyddio ar gyfer prif ran eich siwrnai. 
    <br />
    <br />Yn yr achos hwn, byddai&#8217;n well i chi ddechrau gyda 
    <a href="/Web2/JourneyPlanning/FindTrainInput.aspx">Canfyddwch
    dr&#234;n</a>, 
    <a href="/Web2/JourneyPlanning/FindFlightInput.aspx">Canfyddwch
    ehediad</a>, 
    <a href="/Web2/JourneyPlanning/FindCarInput.aspx">Canfyddwch
    lwybr car</a>, 
    <a href="/Web2/JourneyPlanning/FindCoachInput.aspx">Canfyddwch
    fws moethus</a>&#160;neu 
    <a href="/Web2/JourneyPlanning/FindCycleInput.aspx">Canfod
    llwybr beicio.</a>&#160;Bydd y rhain yn rhestru&#8217;r
    siwrneion am y math hwnnw o gludiant yn unig.</p>
    <br />
    <br />
    <img alt="Delwedd yn dangos eiconau&#8217;r cynllunydd cyflym ar Transport Direct"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyQuickPlanners.JPG"
    border="0" />
    <p>&#160;</p>
    <p>Os defnyddiwch 
    <a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">
    Canfyddwch Dr&#234;n</a>, gallwch ddewis rhwng chwilio yn
    &#244;l amser neu yn &#244;l pris. Drwy chwilio yn &#244;l pris
    gallwch ddewis o ystod o brisiau cyn i chi weld manylion y
    siwrnai sy''n berthnasol i''r pris tocyn hwnnw.</p>
    <p>&#160;</p>
    <p>Efallai hefyd y dymunwch gymharu siwrneion tr&#234;n, awyren
    a bws moethus rhwng dwy ddinas neu dref ym Mhrydain ar ddiwrnod
    arbennig. Gallwch wneud hyn drwy ddefnyddio 
    <a href="/Web2/JourneyPlanning/FindTrunkInput.aspx">cymharu
    siwrneion dinas-i-ddinas</a>.</p>
    <p>&#160;</p>
    <p>Neu efallai y dymunwch ddod o hyd i&#8217;ch gorsaf neu faes
    parcio agosaf ac yna cynllunio siwrnai i neu oddi yno. Neu
    ddarganfod lle ar fap ac yna cynllunio i fynd yno neu oddi yno.
    Mae hyn yn hawdd &#8211; gweler ein tudalen 
    <a href="/Web2/Maps/Home.aspx">Canfyddwch le</a>&#160;am fwy o
    fanylion.</p>
    <p>&#160;</p>
    <h3>Plan me a cycle route&#8230;</h3>
    <p>&#160;</p>
    <p>Planning a cycle route on Transport Direct is simple. You
    can find our cycle planner by clicking the links in the left
    hand menu on the home page and on the journey planner pages.
    There is also a link from the icons at the top of this page and
    in the sitemap.</p>
    <p>&#160;</p>
    <p>The cycle planner is designed to plan you local cycle
    journeys within urban areas &#8211; for example, your journey
    to work or school. Once you are in the cycle planner simply
    enter your start and end location and choose between
    Address/postcode, Facility/attraction or Station/airport. You
    can even select the point you want to start or end your journey
    from a map. Then enter a date and time and choose a type of
    journey. You can chose from the quickest journey, one that
    takes the quietest route, or a recreational journey. Then click
    next.</p>
    <p>&#160;</p>
    <p>There are also advanced options which allow you to :</p>
    <ul class="listerdisc">
      <li>Set your cycling speed (average speed is
      20kph/13mph)</li>
      <li>Nominate a via point for your journey</li>
      <li>Avoid unlit roads, or walking with your bike</li>
      <li>Avoid time based restrictions</li>
    </ul>
    <br class="clearboth" />
    <img style="PADDING-RIGHT: 10px"
    alt="An image showing a Cycle Planner input page"
    title="An image showing a Cycle Planner input page"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/findCycleInput.gif"
    align="left" border="0" />
    <p>At the moment there are a limited number of local authority
    areas included in our cycle planner. This is due to the
    availability of good quality cycle route data. We are working
    closely with Cycling England and local authorities to produce
    data and the areas where you are able to plan a cycle journey
    will increase steadily in 2009. 
    <a href="/Web2/Help/HelpCycle.aspx#A16.2">There is an FAQ
    describing the areas where cycle data is available.</a></p>
    <p>&#160;</p>
    <p>The planner will use roads, cycle paths, bridleways, tow
    paths and other routes available to a bicycle. We have tried to
    make the data as detailed as possible but if you should find a
    route you believe to be incorrect then we would welcome your
    feedback. Please let us know by clicking the &#8220;Contact
    us&#8221; link at the bottom of the journey results page.</p>
    <br class="clearboth" />
    <img style="PADDING-LEFT: 10px"
    alt="An image of a map showing the route of a specific journey"
    title="An image of a map showing the route of a specific journey"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/findCycleMap.gif"
    align="right" border="0" />
    <p>Once Transport Direct has found your cycle route the details
    will be displayed along with a graph showing the gradient of
    the journey. There will also be the option to look at your
    journey alongside other modes of transport to see how CO2
    emissions compare &#8211; click the &#8216;CO2&#8217;
    button.</p>
    <p>&#160;</p>
    <p>The &#8221;Maps&#8221; button allows you to see a route map
    of the journey. If you choose to print the map we will also
    display more detailed tiled views of the journey.</p>
    <p>&#160;</p>
    <p>Those of you with GPS devices for your bike will be able to
    download a 
    <a href="/Web2/Help/HelpCycle.aspx#A16.4">GPX
    file</a>&#160;which you can load onto your mobile device giving
    you a route plan of your journey.</p>
    <br class="clearboth" />
    <img style="PADDING-LEFT: 8px"
    alt="An image showing the details screen of a cycle journey plan"
    title="An image showing the details screen of a cycle journey plan"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/findCycleDetails.gif"
    border="0" />
    <br class="clearboth" />
    <p>&#160;</p>
    <h3>Diwygio fy newis siwrnai</h3>
    <p>&#160;</p>
    <p>Wedi i chi ddarganfod siwrnai a ddymunwch, gallwch ychwanegu
    rhannau pellach at eich siwrnai neu ddiwygio rhywfaint
    o&#8217;ch siwrnai neu&#8217;r siwrnai i gyd.</p>
    <table class="txtseven" cellspacing="0" cellpadding="2"
    border="0">
      <tbody>
        <tr>
          <td>
            <img alt="Delwedd yn cynrychioli&#8217;r weithred o ychwanegu at y siwrnai gyffredinol"
            src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyExtend.JPG"
            border="0" />
          </td>
          <td>Gallwch ddarganfod prif ran eich siwrnai ac yna
          ymestyn y cynllun i ddangos sut i fynd o&#8217;r orsaf
          i&#8217;ch drws mewn car neu gludiant cyhoeddus.</td>
        </tr>
        <tr>
          <td>
            <img alt="Delwedd yn cynrychioli&#8217;r weithred o newid cynllun y siwrnai"
            src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyReplace.JPG"
            border="0" />
          </td>
          <td>Gallwch ddiwygio eich siwrnai drwy amnewid adran
          sy&#8217;n defnyddio cludiant cyhoeddus gyda siwrnai mewn
          car, er enghraifft i deithio adref o&#8217;r orsaf mewn
          tacsi yn hytrach nag mewn bws.</td>
        </tr>
        <tr>
          <td>
            <img alt="Delwedd yn cynrychioli&#8217;r weithred o addasu amserau siwrnai"
            src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyAdjust.JPG"
            border="0" />
          </td>
          <td>Os hoffech gael mwy o amser yn y mannau lle
          mae&#8217;n rhaid i chi newid cludiant, gallwch addasu
          eich siwrnai.</td>
        </tr>
      </tbody>
    </table>
    <p>&#160;</p>
    <img alt="Delwedd o&#8217;r nodwedd &#8216;Newid dyddiad/amser&#8217;"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyAmend.JPG"
    border="0" />
    <p>&#160;</p>
    <p>Cyn gynted ag yr ydych wedi darganfod rhai dewisiadau ar
    gyfer siwrneion, gallwch addasu&#8217;r amserau a&#8217;r
    llwybrau, naill ai drwy glicio&#8217;r botwm
    &#8216;Newid&#8217; neu drwy ddefnyddio&#8217;r nodwedd
    &#8216;Newid dyddiad/amser&#8217; ar waelod y dudalen.</p>
    <p>&#160;</p>
    <h3>Fedrwch chi gofio fy nghais am siwrnai?</h3>
    <p>&#160;</p>
    <p>Wedi i chi ganfod siwrnai, gallwch ei chadw fel nod llyfr
    (&#8216;ffefryn&#8217;) yn eich porwr...</p>
    <p>&#160;</p>
    <img alt="Delwedd yn dangos nodwedd i roi nod llyfr ar siwrnai"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyBookmark.JPG"
    border="0" />
    <p>&#160;</p>
    <p>...a dod o hyd iddi rywbryd yn y dyfodol o&#8217;r ddewislen
    &#8216;Ffefrynnau&#8217; yn eich porwr.</p>
    <p>&#160;</p>
    <img alt="Delwedd o&#8217;r sgr&#238;n yn dangos bar dewislen ffefrynnau&#8217;r porwr"
    src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomePlanAJourneyFavourites.jpg"
    border="0" />
  </div>
</div>
'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1388
SET @ScriptDesc = 'Updates to Plan a journey homepage information panel'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
