-- ***********************************************
-- NAME 		: DUP1599_TransportDirect_Content_5_Home_RightHandPanel.sql
-- DESCRIPTION 	: Script to add the Right Hand Information panel text
-- AUTHOR		: Mitesh Modi
-- DATE			: 26 Feb 2010
-- ************************************************

USE [Content]
GO


DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')



-- Right hand items 1 and 2
EXEC AddtblContent
1, @GroupId, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  href="/Web2/JourneyPlanning/FindCycleInput.aspx">On your
  bike?</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCycle" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt="Cycle Icon"
          src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/cycle_small.gif"
          border="0" />
        </td>
        <td class="txtseven">Our new 
        <a href="/Web2/JourneyPlanning/FindCycleInput.aspx">cycle
        planner</a> allows you to plan cycle routes in selected areas
        around the country, and to choose whether you prefer the
        quickest or quietest route. We&#8217;d really appreciate
        your feedback on this new feature &#8211; please have a go
        and tell us what you think.</td>
      </tr>
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Act on
  CO2</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
          <img title="" alt="CO2 Icon"
          src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_c02.gif"
          border="0" />
        </td>
        <td class="txtseven">Compare your 
        <a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">
        CO2</a> and choose the route with lowest emissions for your
        journey. On the journey results page click the "Check CO2"
        button.</td>
      </tr>
    </tbody>
  </table>
</div>'
, 
'<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  href="/Web2/JourneyPlanning/FindCycleInput.aspx">On your
  bike?</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCycle" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top">
          <img title="" alt="Cycle Incon"
          src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/cycle_small.gif"
          border="0" />
        </td>
        <td class="txtseven">Our new 
        <a href="/Web2/JourneyPlanning/FindCycleInput.aspx">cycle
        planner</a> allows you to plan cycle routes in selected areas
        around the country, and to choose whether you prefer the
        quickest or quietest route. We&#8217;d really appreciate
        your feedback on this new feature &#8211; please have a go
        and tell us what you think.</td>
      </tr>
    </tbody>
  </table>
</div>
<div class="Column3Header">
<div class="txtsevenbbl">
  <a class="Column3HeaderLink"
  href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">Act on
  CO2</a>
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
  <table id="tableRHInfoCO2" cellspacing="0" cellpadding="2" width="100%"
  border="0">
    <tbody>
      <tr>
        <td class="txtseven" valign="top" align="center"
        width="26">
          <img title="" alt="CO2 Icon"
          src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_c02.gif"
          border="0" />
        </td>
        <td class="txtseven">Compare your 
        <a href="/Web2/JourneyPlanning/JourneyEmissionsCompare.aspx">
        CO2</a> and choose the route with lowest emissions for your
        journey. On the journey results page click the "Check CO2"
        button.</td>
      </tr>
    </tbody>
  </table>
</div>'



-- Right hand item 3
EXEC AddtblContent
1, @GroupId, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home',
'<div class="Column3Header">
<div class="txtsevenbbl">Free Tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="tableRHInfoTools" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" /></td> <td class="txtseven">Does your website have a �How to get here� page? You can now create links that open Transport Direct with your destination pre-set. For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br /><br />
Download this <a target="_child" href="http://www.dft.gov.uk/excel/256753/intelligentlink.xls">Excel Link generator <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a> or see our 
<a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a> for more details.</td></tr></tbody></table></div>

<div class="Column3Header">
<div class="txtsevenbbl">We''ve got EU covered</div>  
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="tableRHInfoExtra" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>
	<td class="txtseven" align="center" valign="top" width="26">
		<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Transport Direct Extra" title="Transport Direct Extra" /></td>
	<td class="txtseven">With <a href="/Web2/journeyplanning/FindInternationalInput.aspx">Transport Direct <i>Extra</i></a>,
		you can view scheduled routes to some popular destinations in Europe.<br />
		Compare journey options, times and even CO2 emissions.</td>
</tr>
</tbody></table></div>
'
,
'<div class="Column3Header">
<div class="txtsevenbbl">Free Tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="tableRHInfoTools" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Free Tools" title="Free Tools" /></td> <td class="txtseven">Does your website have a �How to get here� page? You can now create links that open Transport Direct with your destination pre-set. For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The%20Luminaire,%20Kilburn">Directions to the Luminaire</a><br /><br />
Download this <a target="_child" href="http://www.dft.gov.uk/excel/256753/intelligentlink.xls">Excel Link generator <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a> or see our 
<a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a> for more details.</td></tr></tbody></table></div>

<div class="Column3Header">
<div class="txtsevenbbl">We''ve got EU covered</div>  
<!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="tableRHInfoExtra" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>
	<td class="txtseven" align="center" valign="top" width="26">
		<img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Transport Direct Extra" title="Transport Direct Extra" /></td>
	<td class="txtseven">With <a href="/Web2/journeyplanning/FindInternationalInput.aspx">Transport Direct <i>Extra</i></a>,
		you can view scheduled routes to some popular destinations in Europe.<br />
		Compare journey options, times and even CO2 emissions.</td>
</tr>
</tbody></table></div>
'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1599
SET @ScriptDesc = 'Script to add Homepage Right hand information text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO