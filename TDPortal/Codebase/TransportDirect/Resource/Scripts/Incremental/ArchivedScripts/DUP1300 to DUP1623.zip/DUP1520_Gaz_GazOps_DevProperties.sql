-- ***********************************************
-- NAME 		: DUP1520_Gaz_GazOps_DevProperties.sql
-- DESCRIPTION 	: Script to change Dev properties for Gaz and GazOps services
-- AUTHOR		: Amit Patel
-- DATE			: 18 Nov 2009
-- ************************************************

USE [PermanentPortal]
GO

-- ********************* IMPORTANT ******************************
-- THIS FILE IS FOR DEV ENVIRONMENT ONLY. PLEASE DO NOT RUN ON OTHER SERVERS
-- **************************************************************

IF exists (select * from properties where pName = 'locationservice.gazopsweburl' and ThemeId = 1 and AID in ('ExposedServices','LocationService','Microsite','Web'))
BEGIN
	DELETE FROM properties WHERE pName = 'locationservice.gazopsweburl' and ThemeId = 1 and AID in ('ExposedServices','LocationService','Microsite','Web')
END
BEGIN
	insert into properties values ('locationservice.gazopsweburl', 'http://GAZOPS/GazopsWeb/GazopsWeb.asmx', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('locationservice.gazopsweburl', 'http://GAZOPS/GazopsWeb/GazopsWeb.asmx', 'ExposedServices', 'UserPortal', 0, 1)
	insert into properties values ('locationservice.gazopsweburl', 'http://GAZOPS/GazopsWeb/GazopsWeb.asmx', 'LocationService', 'UserPortal', 0, 1)
	insert into properties values ('locationservice.gazopsweburl', 'http://GAZOPS/GazopsWeb/GazopsWeb.asmx', 'Microsite', 'UserPortal', 0, 1)
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1520
SET @ScriptDesc = 'Script to change Dev properties for Gaz and GazOps services'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO