-- ***********************************************
-- NAME 		: DUP1323_CyclePlanner_Properties.sql
-- DESCRIPTION 	: Script to add property for GPX filename
-- AUTHOR		: Mitesh Modi
-- DATE			: 27 Apr 2009
-- ************************************************

USE [PermanentPortal]
GO

-- clear existing Routing guide properies
delete from properties where pname = 'CyclePlanner.GPXDownload.File.MaxLength'

insert into properties values ('CyclePlanner.GPXDownload.File.MaxLength', '225', 'Web', 'UserPortal', 0, 1)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1323
SET @ScriptDesc = 'Cycle planner properties update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO