-- ***********************************************
-- NAME 		: DUP1528_Maps_Content_2.sql
-- DESCRIPTION 	: Script to add Map pages and control content
-- AUTHOR		: Mitesh Modi
-- DATE			: 25 Nov 2009
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map Input page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.AppendPageTitle', 'Find a map - GB street maps | ', 'Find a map - GB street maps | '

EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.lblFindAPlace', 'Maps for Great Britain', 'Mapiau o Brydain Fawr'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.imageInputFormSkipLink.AlternateText', 'Skip to input form', 'Neidiwch i ffurf mewnbynnu'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.imageFindAPlace.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomeMapBlueBackGround.gif', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomeMapBlueBackGround.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.imageFindAPlace.AlternateText', 'Find a map', 'Canfyddwch le'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.imageFindAPlaceSkipLink.AlternateText', 'Skip to Find a map', 'Neidiwch i Darganfyddwch fap'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.labelFromToTitle', 'Select/type in a location to show on the map. Then click "Next".', 'Dewiswch/teipiwch leoliad i''w ddangos ar y map. Yna cliciwch "Nesa".'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.CommandBack.Text', 'Back', 'Yn �l'


--------------------------------------------------------------------------------------------------------------------------------
-- Find Map Result page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapResult.imageMapSkipLink.AlternateText', 'Skip to map', 'Skip to map'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapResult.buttonNewSearch.Text', 'New search', 'Chwilio o''r Newydd'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapResult.commandBack.Text', 'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapResult.labelMap.Text', 'Map of', 'Map o'


--------------------------------------------------------------------------------------------------------------------------------
-- Map control
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.PlanAJourney.Text', 'Plan a journey', 'Cynlluniwch siwrnai'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.Heading.Text', 'We are sorry, this map is not available without javascript.', 'cy We are sorry, this map is not available without javascript.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.Description.Text', 'To view this map please enable javascript in your browser.', 'cy To view this map please enable javascript in your browser.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.JourneyMap.Text', 'You can also view the journey results by selecting the details option above.','cy You can also view the journey results by selecting the details option above.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.TravelNewsMap.Text', 'You can also view live travel news by selecting the table option above.', 'cy You can also view live travel news by selecting the table option above.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.FindNearest.Text', 'You can also view the results in the results list shown above.', 'cy You can also view the results in the results list shown above.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.FindMapResult.Text', 'You can plan a journey by selecting one of plan a journey option from the menu.', 'cy You can plan a journey by selecting one of plan a journey option from the menu.'

--------------------------------------------------------------------------------------------------------------------------------
-- Map Nearest control 
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'MapNearestControl.commandHideMap.Text', 'Hide', 'Cuddiwch'


--------------------------------------------------------------------------------------------------------------------------------
-- Map Symbols control 
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.lblSelectedCategory', 'Selected Category', 'Categori a Ddewiswyd'

-- contents for adding travel news functionality in map symbols control
EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.buttonToggleTravelNewsAndSymbols.TravelNews.Text', 'See travel News', 'cy See travel news'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.buttonToggleTravelNewsAndSymbols.PointOfInterest.Text', 'See point of interest', 'cy See point of interest'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.labelTravelNews', 'Show travel news for selected date', 'cy Show travel news for selected date'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.publicIncidentsVisible', 'Public transport news', 'cy Public transport news'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.roadIncidentsVisible', 'Road transport news', 'cy Road transport news'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.buttonShowNews.Text', 'Show news', 'cy Show news'


--------------------------------------------------------------------------------------------------------------------------------
-- Map Select Location control 
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'MapSelectLocationControl.labelSelectLocationInfo.Text', 'To select a nearby location, use the toolbar on the map', 'To select a nearby location, use the toolbar on the map'

EXEC AddtblContent
1, 1, 'langStrings', 'MapSelectLocationControl.labelSelectLocationError.Text', 'No nearby locations were found, click on the map again or cancel to return to original location', 'No nearby locations were found, click on the map again or cancel to return to original location'

GO


-- *****************************************************************************************************************************
-- ******************** SOFT CONTENT SECTIONS **********************************************************************************
-- *****************************************************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map page Group 
--------------------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM tblGroup WHERE [Name] like 'maps_findmapinput') 
	INSERT INTO tblGroup (GroupId, [Name])
	SELECT MAX(GroupId)+1, 'maps_findmapinput' FROM tblGroup

DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'maps_findmapinput')


--------------------------------------------------------------------------------------------------------------------------------
-- Find Map input page - Information below input panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/Maps/FindMapInput', 
'<div class="PageSoftContentContainer">  
<div class="PageSoftContent">
	<p> </p>
</div>
</div>'
,
'<div class="PageSoftContentContainer">  
<div class="PageSoftContent">
	<p> </p>
</div>
</div>'

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map input page - Latest news information - placeholder required to enable page to populate latest news
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/FindMapInput', 
'<h1>Latest... NOT POPULATED</h1>',
'<h1>Latest... NOT POPULATED</h1>'

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map input page - Right hand information panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDFindMapPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/Maps/FindMapInput',
''
,
''

GO


-- *****************************************************************************************************************************
-- ******************** HELP PAGE SOFT CONTENT SECTIONS **********************************************************************************
-- *****************************************************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map pages - Help urls
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.HelpPageUrl', 'Help/HelpFindMapInput.aspx', 'Help/HelpFindMapInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.HelpAmbiguityUrl', 'Help/HelpFindMapInput.aspx', 'Help/HelpFindMapInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapResult.HelpPageUrl', 'Help/HelpFindMapResult.aspx', 'Help/HelpFindMapResult.aspx'


--------------------------------------------------------------------------------------------------------------------------------
-- Add the help urls to ensure help pages are displayed
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- Find Map input - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindMapInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindMapInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindMapInput', 'Channel',
'/Channels/TransportDirect/Help/HelpFindMapInput',
'/Channels/TransportDirect/Help/HelpFindMapInput'

-- Find Map input - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindMapInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindMapInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindMapInput', 'Channel',
'/Channels/TransportDirect/Printer/HelpFindMapInput',
'/Channels/TransportDirect/Printer/HelpFindMapInput'

-- Find Map Result - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindMapResult', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindMapResult', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindMapResult', 'Channel',
'/Channels/TransportDirect/Help/HelpFindMapResult',
'/Channels/TransportDirect/Help/HelpFindMapResult'

-- Find Map Result - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindMapResult', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindMapResult', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindMapResult', 'Channel',
'/Channels/TransportDirect/Printer/HelpFindMapResult',
'/Channels/TransportDirect/Printer/HelpFindMapResult'


--------------------------------------------------------------------------------------------------------------------------------
-- Find Map Input page - Help text
--------------------------------------------------------------------------------------------------------------------------------
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'helpfulljp')

EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindMapInput',
'<h1>Using the map to find a location</h1>
<p>&#160;</p>
<p>
<strong>1.&#160; Select what type of location you are going to type
in</strong>
<br />&#160;
<br /></p>
<p class="helpindent1">This will allow the Journey Planner to know
whether you are looking for an address, a postcode, a station or an
attraction etc.</p>
<p>&#160;</p>
<p class="helpindent1">It is important that you select the
appropriate type of location.&#160; For example, if you are looking
for a railway station, but you select the ''Address/postcode''
category, the Journey Planner will not be able to find it.</p>
<p>&#160;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&#160;</p>
<ul>
  <li>
  <strong>''Address/postcode":</strong>If you select this, you can
  type in part or all of an address and/or a postcode,
  <br />e.g. ''3 Burleigh Road'', ''3 Burleigh Road,
  Stretford'', ''Burleigh Road, Stretford,
  Manchester'', ''3 Burleigh Road, M32 0PF'', ''M32
  0PF''. If you don''t know the postcode include as much of the
  address as possible 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Town</strong>
  <strong>/district/village'':</strong>If you select this, you can
  type in the name of a city, town, borough, district, area,
  suburb, village or hamlet,
  <br />e.g. ''Manchester'', ''Maidenhead'',
  ''Anfield'', ''Hockley'',
  ''Chelsea''</li>
</ul>
<p></p>
<p>&#160;</p>
<ul>
  <li>
  <strong>''Facility/attraction'':</strong>If you select this, you
  can type in the name of an attraction or facility, including:
  hotels, schools, universities, hospitals, surgeries, sports
  grounds, theatres, cinemas, tourist attractions, museums,
  government buildings and police stations,
  <br />e.g. ''Edinburgh Castle'', ''Queen''s Head
  Hotel'', ''British Museum'', ''Arsenal Football
  Club'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Station/airport'':</strong>&#160; If you select this, you
  can type in the name of a railway station, a coach station, an
  airport or a ferry terminal.&#160; You may also type in the name
  of a town and choose to travel from any of the stations in this
  town,
  <br />e.g. ''Kings Cross'', ''London'',
  Derby'', ''Newcastle'', ''Gatwick'',
  ''Victoria Coach Station'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''All stops'':</strong>If you select this, you can type in
  the name of a bus stop, an underground stop, a metro stop, or a
  tram stop,
  <br />e.g. ''Trafalgar Square bus stop'', ''Whitley
  Bay'', ''Piccadilly Circus''</li>
</ul>
<p>&#160;</p>
<p>
  <strong>2.&#160; Type the location name in the box</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">It is best to type in the full location name
so that you get the fewest ''similar matches'' returned to you.&#160;
Punctuation and use of capital letters are 
<strong>not</strong>&nbsp;important.</p>
<p class="helpindent1">
<br />&#160;
<br />If you are not sure how to spell the name of the location,
you can tick the ''Unsure of spelling'' box so that the Journey
Planner will also search for locations that sound similar to the
one you type in.</p>
<p class="helpindent1">
<br />&#160;
<br />If you do not know the full location name, type in as much as
you know and put an asterisk * after the letters.
<br />&#160; e.g. If you selected ''Station/airport'' and typed in
''kin*''you would get all the stations and airports in
Britain that start with the letters Kin &#251;
''Kinsbrace'', ''Kingham'', ''Kings Cross
Thameslink'', ''Kings Cross''etc</p>
<p>&#160;</p>
<p>
  <strong>3.&#160; Click ''Next''</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">At this point the Journey Planner will
search for a map location you have typed in. If there is more than
one location similar to the location you typed in, you will need to
choose from a list of possible matches.</p>
<p>
<br />&#160;</p>
'
,
'<h1>Defnyddio''r map i ddod o hyd i leoliad</h1>
<p>&#160;</p>
<p>
<strong>1. &#160;Dewiswch pa fath o leoliad yr ydych yn mynd i''w
deipio</strong>
<br />&#160; 
<br /></p>
<p class="helpindent1">Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a
ydych yn chwilio am gyfeiriad, c&#244;d post, gorsaf neu atyniad...
ac ati.</p>
<p>&#160;</p>
<p class="helpindent1">Mae''n bwysig eich bod yn dewis y math
priodol o leoliad.&#160; Er enghraifft, os ydych yn chwilio am
orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c&#244;d
post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>&#160;</p>
<p class="helpindent1">Disgrifir y categor&#180;au isod:</p>
<p>&#160;</p>
<ul>
  <li>
  <strong>''Cyfeiriad/cod post":</strong>&#160; Os dewiswch hwn,
  gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, 
  <br />e.e. ''3 Burleigh Road'', ''3 Burleigh Road, Stretford'',
  ''Burleigh Road, Stretford, Manchester'', ''3 Burleigh Road, M32
  0PF'', ''M32 0PF''. Os nad ydych yn gwybod y cod post cynhwyswch
  gymaint o''r cyfeiriad &#212; phosibl 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Tref/rhanbarth/pentref'':</strong>&#160; Os dewiswch
  hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth,
  ardal, maestref, pentref neu bentref bychan, 
  <br />e.e. ''Manchester'', ''Maidenhead'', ''Anfield'',
  ''Hockley'', ''Chelsea'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Cyfleuster/atyniad'':</strong>&#160; Os dewiswch hwn,
  gallwch deipio enw''r atyniad neu''r cyfleuster, gan
  gynnwys:&#160; gwestai, ysgolion, prifysgolion, ysbytai,
  meddygfeydd, meysydd chwaraeon, theatrau, sinem&#212;u, atyniadau
  twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd
  yr heddlu, 
  <br />e.e. ''Edinburgh Castle'', ''Queen''s Head Hotel'',
  ''British Museum'', ''Arsenal Football Club'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Gorsaf/maes awyr'':</strong>&#160; Os dewiswch hwn,
  gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus,
  maes awyr neu derfynnell fferi.&#160; Gallwch hefyd deipio enw
  tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,
  
  <br />e.e. ''Kings Cross'', ''London'', Derby'', ''Newcastle'',
  ''Gatwick'', ''Victoria Coach Station'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Pob arhosfan'':</strong>&#160; Os dewiswch hwn, gallwch
  deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan
  metro, neu arhosfan tramiau, 
  <br />e.e ''Trafalgar Square bus stop'', ''Whitley Bay'',
  ''Piccadilly Circus''</li>
</ul>
<p>&#160;</p>
<p>
  <strong>2.&#160; Teipiwch enw''r lleoliad yn y blwch</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn
fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu
hanfon yn &#244;l atoch.&#160; 
<strong>Nid</strong>yw atalnodi a defnyddio prif lythrennau yn
bwysig.</p>
<p class="helpindent1">
<br />Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch
dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr
Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un
yr ydych wedi ei deipio.</p>
<p class="helpindent1">
<br />Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint
ag a wyddoch a rhowch * ar &#244;l y llythrennau. 
<br />&#160; e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio
''Kin*'' byddech yn cael yr holl orsafoedd a''r meysydd awyr ym
Mhrydain sy''n dechrau gyda''r llythrennau Kin - ''Kinsbrace'',
''Kingham'', ''King''s Cross Thameslink'', ''King''s Cross'' ac
ati</p>
<p>&#160;</p>
<p>
  <strong>3.&#160; Cliciwch ar ''Nesa''</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">Yn ystod y cam hwn bydd y Cynlluniwr Siwrnai
yn chwilio am leoliad map yr ydych wedi ei deipio.&#160; Os oes mwy
nag un lleoliad yn debyg i''r lleoliad yr ydych wedi ei deipio,
bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p>
<p>&#160;</p>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map Input page - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindMapInput',
'<h1>Using the map to find a location</h1>
<p>&#160;</p>
<p>
<strong>1.&#160; Select what type of location you are going to type
in</strong>
<br />&#160;
<br /></p>
<p class="helpindent1">This will allow the Journey Planner to know
whether you are looking for an address, a postcode, a station or an
attraction etc.</p>
<p>&#160;</p>
<p class="helpindent1">It is important that you select the
appropriate type of location.&#160; For example, if you are looking
for a railway station, but you select the ''Address/postcode''
category, the Journey Planner will not be able to find it.</p>
<p>&#160;</p>
<p class="helpindent1">The categories are described below:</p>
<p>&#160;</p>
<ul>
  <li>
  <strong>''Address/postcode":</strong>If you select this, you can
  type in part or all of an address and/or a postcode,
  <br />e.g. ''3 Burleigh Road'', ''3 Burleigh Road,
  Stretford'', ''Burleigh Road, Stretford,
  Manchester'', ''3 Burleigh Road, M32 0PF'', ''M32
  0PF''. If you don''t know the postcode include as much of the
  address as possible 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Town</strong>
  <strong>/district/village'':</strong>If you select this, you can
  type in the name of a city, town, borough, district, area,
  suburb, village or hamlet,
  <br />e.g. ''Manchester'', ''Maidenhead'',
  ''Anfield'', ''Hockley'',
  ''Chelsea''</li>
</ul>
<p></p>
<p>&#160;</p>
<ul>
  <li>
  <strong>''Facility/attraction'':</strong>If you select this, you
  can type in the name of an attraction or facility, including:
  hotels, schools, universities, hospitals, surgeries, sports
  grounds, theatres, cinemas, tourist attractions, museums,
  government buildings and police stations,
  <br />e.g. ''Edinburgh Castle'', ''Queen''s Head
  Hotel'', ''British Museum'', ''Arsenal Football
  Club'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Station/airport'':</strong>&#160; If you select this, you
  can type in the name of a railway station, a coach station, an
  airport or a ferry terminal.&#160; You may also type in the name
  of a town and choose to travel from any of the stations in this
  town,
  <br />e.g. ''Kings Cross'', ''London'',
  Derby'', ''Newcastle'', ''Gatwick'',
  ''Victoria Coach Station'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''All stops'':</strong>If you select this, you can type in
  the name of a bus stop, an underground stop, a metro stop, or a
  tram stop,
  <br />e.g. ''Trafalgar Square bus stop'', ''Whitley
  Bay'', ''Piccadilly Circus''</li>
</ul>
<p>&#160;</p>
<p>
  <strong>2.&#160; Type the location name in the box</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">It is best to type in the full location name
so that you get the fewest ''similar matches'' returned to you.&#160;
Punctuation and use of capital letters are 
<strong>not</strong>&nbsp;important.</p>
<p class="helpindent1">
<br />&#160;
<br />If you are not sure how to spell the name of the location,
you can tick the ''Unsure of spelling'' box so that the Journey
Planner will also search for locations that sound similar to the
one you type in.</p>
<p class="helpindent1">
<br />&#160;
<br />If you do not know the full location name, type in as much as
you know and put an asterisk * after the letters.
<br />&#160; e.g. If you selected ''Station/airport'' and typed in
''kin*''you would get all the stations and airports in
Britain that start with the letters Kin &#251;
''Kinsbrace'', ''Kingham'', ''Kings Cross
Thameslink'', ''Kings Cross''etc</p>
<p>&#160;</p>
<p>
  <strong>3.&#160; Click ''Next''</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">At this point the Journey Planner will
search for a map location you have typed in. If there is more than
one location similar to the location you typed in, you will need to
choose from a list of possible matches.</p>
<p>
<br />&#160;</p>
'
,
'<h1>Defnyddio''r map i ddod o hyd i leoliad</h1>
<p>&#160;</p>
<p>
<strong>1. &#160;Dewiswch pa fath o leoliad yr ydych yn mynd i''w
deipio</strong>
<br />&#160; 
<br /></p>
<p class="helpindent1">Bydd hyn yn hysbysu''r Cynlluniwr Siwrnai a
ydych yn chwilio am gyfeiriad, c&#244;d post, gorsaf neu atyniad...
ac ati.</p>
<p>&#160;</p>
<p class="helpindent1">Mae''n bwysig eich bod yn dewis y math
priodol o leoliad.&#160; Er enghraifft, os ydych yn chwilio am
orsaf rheilffordd, ond yn dewis y categori ''Cyfeiriad/c&#244;d
post'', ni fydd y Cynlluniwr Siwrnai yn gallu dod o hyd iddo.</p>
<p>&#160;</p>
<p class="helpindent1">Disgrifir y categor&#180;au isod:</p>
<p>&#160;</p>
<ul>
  <li>
  <strong>''Cyfeiriad/cod post":</strong>&#160; Os dewiswch hwn,
  gallwch deipio rhan neu''r cyfan o gyfeiriad a/neu god post, 
  <br />e.e. ''3 Burleigh Road'', ''3 Burleigh Road, Stretford'',
  ''Burleigh Road, Stretford, Manchester'', ''3 Burleigh Road, M32
  0PF'', ''M32 0PF''. Os nad ydych yn gwybod y cod post cynhwyswch
  gymaint o''r cyfeiriad &#212; phosibl 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Tref/rhanbarth/pentref'':</strong>&#160; Os dewiswch
  hwn, gallwch deipio enw dinas, tref, bwrdeistref, rhanbarth,
  ardal, maestref, pentref neu bentref bychan, 
  <br />e.e. ''Manchester'', ''Maidenhead'', ''Anfield'',
  ''Hockley'', ''Chelsea'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Cyfleuster/atyniad'':</strong>&#160; Os dewiswch hwn,
  gallwch deipio enw''r atyniad neu''r cyfleuster, gan
  gynnwys:&#160; gwestai, ysgolion, prifysgolion, ysbytai,
  meddygfeydd, meysydd chwaraeon, theatrau, sinem&#212;u, atyniadau
  twristaidd, amgueddfeydd, adeiladau''r llywodraeth a gorsafoedd
  yr heddlu, 
  <br />e.e. ''Edinburgh Castle'', ''Queen''s Head Hotel'',
  ''British Museum'', ''Arsenal Football Club'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Gorsaf/maes awyr'':</strong>&#160; Os dewiswch hwn,
  gallwch deipio enw gorsaf rheilffordd, gorsaf bysiau moethus,
  maes awyr neu derfynnell fferi.&#160; Gallwch hefyd deipio enw
  tref, a dewis teithio o unrhyw rai o''r gorsafoedd yn y dref hon,
  
  <br />e.e. ''Kings Cross'', ''London'', Derby'', ''Newcastle'',
  ''Gatwick'', ''Victoria Coach Station'' 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Pob arhosfan'':</strong>&#160; Os dewiswch hwn, gallwch
  deipio enw arhosfan bysiau, arhosfan trenau tanddaearol, arhosfan
  metro, neu arhosfan tramiau, 
  <br />e.e ''Trafalgar Square bus stop'', ''Whitley Bay'',
  ''Piccadilly Circus''</li>
</ul>
<p>&#160;</p>
<p>
  <strong>2.&#160; Teipiwch enw''r lleoliad yn y blwch</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">Mae''n well teipio enw''r lleoliad yn llawn
fel y bydd y nifer lleiaf o ''gyfatebiaethau tebyg'' yn cael eu
hanfon yn &#244;l atoch.&#160; 
<strong>Nid</strong>yw atalnodi a defnyddio prif lythrennau yn
bwysig.</p>
<p class="helpindent1">
<br />Os nad ydych yn sicr sut i sillafu enw''r lleoliad, gallwch
dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr
Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r un
yr ydych wedi ei deipio.</p>
<p class="helpindent1">
<br />Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch gymaint
ag a wyddoch a rhowch * ar &#244;l y llythrennau. 
<br />&#160; e.e. Os bu i chi ddewis ''Gorsaf/maes awyr'' a theipio
''Kin*'' byddech yn cael yr holl orsafoedd a''r meysydd awyr ym
Mhrydain sy''n dechrau gyda''r llythrennau Kin - ''Kinsbrace'',
''Kingham'', ''King''s Cross Thameslink'', ''King''s Cross'' ac
ati</p>
<p>&#160;</p>
<p>
  <strong>3.&#160; Cliciwch ar ''Nesa''</strong>
</p>
<p>
<strong></strong>&#160;</p>
<p class="helpindent1">Yn ystod y cam hwn bydd y Cynlluniwr Siwrnai
yn chwilio am leoliad map yr ydych wedi ei deipio.&#160; Os oes mwy
nag un lleoliad yn debyg i''r lleoliad yr ydych wedi ei deipio,
bydd angen i chi ddewis o restr o gyfatebiaethau posibl.</p>
<p>&#160;</p>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map Result - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindMapResult',
'<h1>Location map tools</h1>
<p>
<strong></strong>&#160;</p>
<p>
  <strong>You can use the tools in this section to:</strong>
</p>
<ul>
  <li>Navigate around the map</li>
  <li>Find information about points on the map</li>
  <li>Select a new point on the map</li>
</ul>
<p>&#160;</p>
<p>
  <strong>Map navigation buttons:</strong>
</p>
<ul>
  <li>
  <strong>''Zoom in''
  <br /></strong>Allows you to zoom into the map so that you can
  view more detail.&#160; 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Zoom out''
  <br /></strong>Allows you to zoom out so that you are able to
  view more of the surrounding areas, but less detail. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Zoom bar''
  <br /></strong>This tool allows you to zoom in or out of the map
  quickly by clicking on one of the bars.&#160; ''Zoom level 13'' is
  closest to ''Zoom in +'' and will show you more detail than ''Zoom
  level 1'', which is closest to ''Zoom in -'', and will show you the
  least detail. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Previous map''
  <br /></strong>Allows you to view the map as it was before your
  last action. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Select new location''</strong>
  <strong>
    <br />
  </strong>Click ''Select new location'' to search for a map of a new
  location.</li>
</ul>
<p></p>
<p>&#160;</p>
<ul>
  <li>
  <strong>Navigation arrows
  <br /></strong>Click the arrows on the edge of the map to move
  up, down, left, right or diagonally. The map will then represent
  the areas you are navigating towards.</li>
</ul>
<p>&#160;</p>
<p>
<strong>''Plan a journey'' button
<br /></strong>&#160;
<br /></p>
<p>Clicking on ''Plan a journey'' will give you the choice to plan a
journey 
<strong>to</strong>&nbsp;or 
<strong>from</strong>&#160;the current location showing on the
map.</p>
<p></p>
<p>If you want to travel to or from the location currently shown on
the map:</p>
<p></p>
<ol class="numberlist">
  <li>Click ''Plan a journey''</li>
  <li>Click either ''Travel 
  <strong>from</strong>&nbsp;this location'' or ''Travel 
  <strong>to</strong>&nbsp;this location''</li>
</ol>
<p></p>
<p>If you want to travel to or from a new location:</p>
<p></p>
<ol class="numberlist">
  <li>Click ''Select new location''</li>
  <li>Use the navigation tools so that you can see the location you
  wish to travel from or to</li>
  <li>Use the pointer to click on the location, and you will be
  shown a drop-down list of all the&#160;locations within 50 metres
  of where you clicked</li>
  <li>Choose the location from the drop-down list and click
  ''OK''</li>
  <li>Click ''Plan a journey''</li>
  <li>Click either ''Travel 
  <strong>from</strong>&nbsp;this location'' or ''Travel 
  <strong>to</strong>&nbsp;this location''</li>
</ol>
<p>
  <strong>''i'' button</strong>
</p>
<p>
<strong></strong>
<br />Clicking on ''i'' will take you to a page which will give you
information about the current location (if it is available).</p>
<p>If you want information about a new location:</p>
<ol class="numberlist">
  <li>Click ''Select new location''</li>
  <li>Use the navigation tools so that you can see the location you
  wish to travel from or to</li>
  <li>Use the pointer to click on the location, and you will be
  shown a drop-down list of all the locations within 50 metres of
  where you clicked</li>
  <li>Choose the location from the drop-down list and click
  ''OK''</li>
  <li>Click ''i''</li>
</ol>
<p>
<strong>''Select new location'' button</strong>
<strong>
  <br />
</strong>&#160; 
<br />Clicking on ''Select new location'' will allow you to select a
location so that you can view a map of it and then proceed with
either planning a journey or finding information.</p>
<ol class="numberlist">
  <li>Click ''Select new location''</li>
  <li>Use the pointer to click on the location, and you will be
  shown a drop-down list of all the locations with 50 metres of
  where you clicked</li>
  <li>Choose the location from the drop-down list and click
  ''OK''</li>
</ol>
<p>
  <strong>To stop any action process click ''Cancel''.</strong>
</p>
<p>&#160;</p>
<p>
  <strong>If you want to print out the map, click ''Printer
  friendly''.&#160; This will open a ''printer friendly'' page that
  you can print as normal.
  <br /></strong>
</p>
'
,
'<h1>Teclynnau map lleoliad</h1>
<p>
<strong></strong>&#160;</p>
<p>
  <strong>Gallwch ddefnyddio''r teclynnau yn yr adran hon
  i:</strong>
</p>
<ul>
  <li>Symud o gwmpas y map</li>
  <li>Darganfod gwybodaeth am bwyntiau ar y map</li>
  <li>Dewis pwynt newydd ar y map</li>
</ul>
<p>&#160;</p>
<p>
  <strong>Botymau i symud o gwmpas y map:</strong>
</p>
<ul>
  <li>
  <strong>''Chwyddo''r map'' 
  <br /></strong>Mae''n caniat&#225;u i chi chwyddo''r map fel y
  gallwch weld yn fwy manwl. &#160; 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Lleihau''r map'' 
  <br /></strong>Mae''n caniat&#225;u i chi leihau''r map fel y
  gallwch weld mwy o''r ardaloedd cyfagos, ond llai o fanylder. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Bar chwyddo/lleihau'' 
  <br /></strong>Mae''r teclyn hwn yn caniat&#225;u i chi chwyddo
  neu leihau''r map yn gyflym drwy glicio ar un o''r bariau.&#160;
  ""Lefel chwyddo 13 yw''r agosaf at ''Chwyddo +'' a bydd yn dangos
  i chi fwy o fanylion na ''Lefel chwyddo 1'' sydd agosaf at
  ''Chwyddo &#251; '' a bydd yn dangos i chi''r lleiaf o fanylder. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Golygfa flaenorol'' 
  <br /></strong>Mae''n caniat&#225;u i chi weld y map fel ag yr
  oedd cyn i chi weithredu y tro diwethaf. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Darganfod map newydd'' 
  <br /></strong>Cliciwch ar ''Darganfod map newydd'' i chwilio am
  fap o leoliad newydd. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>Saethau cyfeirio 
  <br /></strong>Cliciwch ar y saethau ar ymyl y map i symud i
  fyny, i lawr, i''r chwith, i''r dde neu ar draws. Yna bydd y map
  yn cynrychioli''r ardaloedd yr ydych yn symud tuag atynt.</li>
</ul>
<p>&#160;</p>
<p>
<strong>Botwm ''Cynlluniwch siwrnai'' 
<br /></strong>&#160; 
<br /></p>
<p>Bydd clicio ''Cynlluniwch siwrnai'' yn rhoi dewis i chi
gynllunio siwrnai 
<strong>i</strong>&#160;neu 
<strong>o</strong>''r lleoliad cyfredol a ddangosir ar y map.</p>
<p></p>
<p>Os ydych am deithio i neu o''r lleoliad cyfredol a ddangosir ar
y map:</p>
<p></p>
<ol class="numberlist">
  <li>Cliciwch ar ''Cynlluniwch siwrnai''&#160;&#160;</li>
  <li>Cliciwch un ai ''Teithio 
  <strong>o</strong>''r lleoliad hwn" neu ''Teithio 
  <strong>i</strong>''r lleoliad hwn''</li>
</ol>
<p></p>
<p>Os ydych am deithio i neu o leoliad newydd:</p>
<p></p>
<ol class="numberlist">
  <li>Cliciwch ''Dewiswch leoliad newydd''</li>
  <li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld
  y lleoliad rydych am deithio o neu i</li>
  <li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a byddwch yn
  gweld rhestr a ollyngir i lawr o''r holl leoliadau o fewn 50 metr
  o''r man a gliciwyd arno</li>
  <li>Dewiswch y lleoliad o''r rhestr a ollyngir i lawr a chliciwch
  ''Iawn"</li>
  <li>Cliciwch ''Cynlluniwch siwrnai''</li>
  <li>Cliciwch un ai ''Teithio o''r lleoliad hwn'' neu ''Teithio
  i''r lleoliad hwn''</li>
</ol>
<p>&#160;</p>
<p>
  <strong>Botwm ''Gwybodaeth''</strong>
</p>
<p>
<strong></strong>
<br />Bydd clicio ar ''Gwybodaeth'' yn eich arwain at dudalen a
fydd yn rhoi gwybodaeth ynghylch y lleoliad cyfredol (os yw ar
gael).&#160;</p>
<p>Os bydd angen gwybodaeth ynghylch lleoliad newydd arnoch:</p>
<ol class="numberlist">
  <li>Cliciwch ''Dewiswch leoliad newydd''</li>
  <li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld
  y lleoliad rydych yn dymuno teithio i neu oddi yno</li>
  <li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a
  ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50
  metr o''r man a gliciwyd arno</li>
  <li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a
  chliciwch ''Iawn''</li>
  <li>Cliciwch ''Gwybodaeth''</li>
</ol>
<p>
<strong></strong>&#160;</p>
<p>
<strong>''Botwm ''Dewiswch leoliad newydd''</strong>
<strong>
  <br />
</strong>&#160; 
<br />Bydd clicio ar ''Dewiswch leoliad newydd'' yn eich galluogi i
ddewis lleoliad fel eich bod yn gallu gweld map ac yna mynd ymlaen
un ai i gynllunio siwrnai neu ddod o hyd i wybodaeth.</p>
<ol class="numberlist">
  <li>Cliciwch ''Dewiswch leoliad newydd''</li>
  <li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a
  ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50
  metr o''r man a gliciwyd arno</li>
  <li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a
  chliciwch ''Iawn''</li>
</ol>
<p>
  <strong>I atal unrhyw weithred cliciwch ar ''Dileu''.</strong>
</p>
<p>&#160;</p>
<p>
  <strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawwd ei
  argraffu''.&#160; Bydd hyn yn agor tudalen arbennig y gallwch ei
  hargraffu fel arfer.</strong>
</p>
'

--------------------------------------------------------------------------------------------------------------------------------
-- Find Map Result - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindMapResult',
'<h1>Location map tools</h1>
<p>
<strong></strong>&#160;</p>
<p>
  <strong>You can use the tools in this section to:</strong>
</p>
<ul>
  <li>Navigate around the map</li>
  <li>Find information about points on the map</li>
  <li>Select a new point on the map</li>
</ul>
<p>&#160;</p>
<p>
  <strong>Map navigation buttons:</strong>
</p>
<ul>
  <li>
  <strong>''Zoom in''
  <br /></strong>Allows you to zoom into the map so that you can
  view more detail.&#160; 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Zoom out''
  <br /></strong>Allows you to zoom out so that you are able to
  view more of the surrounding areas, but less detail. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Zoom bar''
  <br /></strong>This tool allows you to zoom in or out of the map
  quickly by clicking on one of the bars.&#160; ''Zoom level 13'' is
  closest to ''Zoom in +'' and will show you more detail than ''Zoom
  level 1'', which is closest to ''Zoom in -'', and will show you the
  least detail. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Previous map''
  <br /></strong>Allows you to view the map as it was before your
  last action. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Select new location''</strong>
  <strong>
    <br />
  </strong>Click ''Select new location'' to search for a map of a new
  location.</li>
</ul>
<p></p>
<p>&#160;</p>
<ul>
  <li>
  <strong>Navigation arrows
  <br /></strong>Click the arrows on the edge of the map to move
  up, down, left, right or diagonally. The map will then represent
  the areas you are navigating towards.</li>
</ul>
<p>&#160;</p>
<p>
<strong>''Plan a journey'' button
<br /></strong>&#160;
<br /></p>
<p>Clicking on ''Plan a journey'' will give you the choice to plan a
journey 
<strong>to</strong>&nbsp;or 
<strong>from</strong>&#160;the current location showing on the
map.</p>
<p></p>
<p>If you want to travel to or from the location currently shown on
the map:</p>
<p></p>
<ol class="numberlist">
  <li>Click ''Plan a journey''</li>
  <li>Click either ''Travel 
  <strong>from</strong>&nbsp;this location'' or ''Travel 
  <strong>to</strong>&nbsp;this location''</li>
</ol>
<p></p>
<p>If you want to travel to or from a new location:</p>
<p></p>
<ol class="numberlist">
  <li>Click ''Select new location''</li>
  <li>Use the navigation tools so that you can see the location you
  wish to travel from or to</li>
  <li>Use the pointer to click on the location, and you will be
  shown a drop-down list of all the&#160;locations within 50 metres
  of where you clicked</li>
  <li>Choose the location from the drop-down list and click
  ''OK''</li>
  <li>Click ''Plan a journey''</li>
  <li>Click either ''Travel 
  <strong>from</strong>&nbsp;this location'' or ''Travel 
  <strong>to</strong>&nbsp;this location''</li>
</ol>
<p>
  <strong>''i'' button</strong>
</p>
<p>
<strong></strong>
<br />Clicking on ''i'' will take you to a page which will give you
information about the current location (if it is available).</p>
<p>If you want information about a new location:</p>
<ol class="numberlist">
  <li>Click ''Select new location''</li>
  <li>Use the navigation tools so that you can see the location you
  wish to travel from or to</li>
  <li>Use the pointer to click on the location, and you will be
  shown a drop-down list of all the locations within 50 metres of
  where you clicked</li>
  <li>Choose the location from the drop-down list and click
  ''OK''</li>
  <li>Click ''i''</li>
</ol>
<p>
<strong>''Select new location'' button</strong>
<strong>
  <br />
</strong>&#160; 
<br />Clicking on ''Select new location'' will allow you to select a
location so that you can view a map of it and then proceed with
either planning a journey or finding information.</p>
<ol class="numberlist">
  <li>Click ''Select new location''</li>
  <li>Use the pointer to click on the location, and you will be
  shown a drop-down list of all the locations with 50 metres of
  where you clicked</li>
  <li>Choose the location from the drop-down list and click
  ''OK''</li>
</ol>
<p>
  <strong>To stop any action process click ''Cancel''.</strong>
</p>
<p>&#160;</p>
<p>
  <strong>If you want to print out the map, click ''Printer
  friendly''.&#160; This will open a ''printer friendly'' page that
  you can print as normal.
  <br /></strong>
</p>
'
,
'<h1>Teclynnau map lleoliad</h1>
<p>
<strong></strong>&#160;</p>
<p>
  <strong>Gallwch ddefnyddio''r teclynnau yn yr adran hon
  i:</strong>
</p>
<ul>
  <li>Symud o gwmpas y map</li>
  <li>Darganfod gwybodaeth am bwyntiau ar y map</li>
  <li>Dewis pwynt newydd ar y map</li>
</ul>
<p>&#160;</p>
<p>
  <strong>Botymau i symud o gwmpas y map:</strong>
</p>
<ul>
  <li>
  <strong>''Chwyddo''r map'' 
  <br /></strong>Mae''n caniat&#225;u i chi chwyddo''r map fel y
  gallwch weld yn fwy manwl. &#160; 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Lleihau''r map'' 
  <br /></strong>Mae''n caniat&#225;u i chi leihau''r map fel y
  gallwch weld mwy o''r ardaloedd cyfagos, ond llai o fanylder. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Bar chwyddo/lleihau'' 
  <br /></strong>Mae''r teclyn hwn yn caniat&#225;u i chi chwyddo
  neu leihau''r map yn gyflym drwy glicio ar un o''r bariau.&#160;
  ""Lefel chwyddo 13 yw''r agosaf at ''Chwyddo +'' a bydd yn dangos
  i chi fwy o fanylion na ''Lefel chwyddo 1'' sydd agosaf at
  ''Chwyddo &#251; '' a bydd yn dangos i chi''r lleiaf o fanylder. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Golygfa flaenorol'' 
  <br /></strong>Mae''n caniat&#225;u i chi weld y map fel ag yr
  oedd cyn i chi weithredu y tro diwethaf. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>''Darganfod map newydd'' 
  <br /></strong>Cliciwch ar ''Darganfod map newydd'' i chwilio am
  fap o leoliad newydd. 
  <p></p>
  <p>&#160;</p></li>
  <li>
  <strong>Saethau cyfeirio 
  <br /></strong>Cliciwch ar y saethau ar ymyl y map i symud i
  fyny, i lawr, i''r chwith, i''r dde neu ar draws. Yna bydd y map
  yn cynrychioli''r ardaloedd yr ydych yn symud tuag atynt.</li>
</ul>
<p>&#160;</p>
<p>
<strong>Botwm ''Cynlluniwch siwrnai'' 
<br /></strong>&#160; 
<br /></p>
<p>Bydd clicio ''Cynlluniwch siwrnai'' yn rhoi dewis i chi
gynllunio siwrnai 
<strong>i</strong>&#160;neu 
<strong>o</strong>''r lleoliad cyfredol a ddangosir ar y map.</p>
<p></p>
<p>Os ydych am deithio i neu o''r lleoliad cyfredol a ddangosir ar
y map:</p>
<p></p>
<ol class="numberlist">
  <li>Cliciwch ar ''Cynlluniwch siwrnai''&#160;&#160;</li>
  <li>Cliciwch un ai ''Teithio 
  <strong>o</strong>''r lleoliad hwn" neu ''Teithio 
  <strong>i</strong>''r lleoliad hwn''</li>
</ol>
<p></p>
<p>Os ydych am deithio i neu o leoliad newydd:</p>
<p></p>
<ol class="numberlist">
  <li>Cliciwch ''Dewiswch leoliad newydd''</li>
  <li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld
  y lleoliad rydych am deithio o neu i</li>
  <li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a byddwch yn
  gweld rhestr a ollyngir i lawr o''r holl leoliadau o fewn 50 metr
  o''r man a gliciwyd arno</li>
  <li>Dewiswch y lleoliad o''r rhestr a ollyngir i lawr a chliciwch
  ''Iawn"</li>
  <li>Cliciwch ''Cynlluniwch siwrnai''</li>
  <li>Cliciwch un ai ''Teithio o''r lleoliad hwn'' neu ''Teithio
  i''r lleoliad hwn''</li>
</ol>
<p>&#160;</p>
<p>
  <strong>Botwm ''Gwybodaeth''</strong>
</p>
<p>
<strong></strong>
<br />Bydd clicio ar ''Gwybodaeth'' yn eich arwain at dudalen a
fydd yn rhoi gwybodaeth ynghylch y lleoliad cyfredol (os yw ar
gael).&#160;</p>
<p>Os bydd angen gwybodaeth ynghylch lleoliad newydd arnoch:</p>
<ol class="numberlist">
  <li>Cliciwch ''Dewiswch leoliad newydd''</li>
  <li>Defnyddiwch y teclynnau cyfeirio fel eich bod yn gallu gweld
  y lleoliad rydych yn dymuno teithio i neu oddi yno</li>
  <li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a
  ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50
  metr o''r man a gliciwyd arno</li>
  <li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a
  chliciwch ''Iawn''</li>
  <li>Cliciwch ''Gwybodaeth''</li>
</ol>
<p>
<strong></strong>&#160;</p>
<p>
<strong>''Botwm ''Dewiswch leoliad newydd''</strong>
<strong>
  <br />
</strong>&#160; 
<br />Bydd clicio ar ''Dewiswch leoliad newydd'' yn eich galluogi i
ddewis lleoliad fel eich bod yn gallu gweld map ac yna mynd ymlaen
un ai i gynllunio siwrnai neu ddod o hyd i wybodaeth.</p>
<ol class="numberlist">
  <li>Cliciwch ''Dewiswch leoliad newydd''</li>
  <li>Defnyddiwch y pwyntydd i glicio ar y lleoliad a bydd rhestr a
  ollyngir i lawr yn ymddangos gyda''r holl leoliadau o fewn 50
  metr o''r man a gliciwyd arno</li>
  <li>Dewiswch y lleoliad oddi ar y rhestr a ollyngir i lawr a
  chliciwch ''Iawn''</li>
</ol>
<p>
  <strong>I atal unrhyw weithred cliciwch ar ''Dileu''.</strong>
</p>
<p>&#160;</p>
<p>
  <strong>Os dymunwch argraffu''r map, cliciwch ar ''Hawwd ei
  argraffu''.&#160; Bydd hyn yn agor tudalen arbennig y gallwch ei
  hargraffu fel arfer.</strong>
</p>
'






-- *****************************************************************************************************************************
-- ******************** EXISTING HELP PAGE SOFT CONTENT SECTIONS - UPDATE **********************************************************************************
-- *****************************************************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- Journey Details (Map Shown) - Help text
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'helpLabelJourneyDetailsMap',
'<p>
<strong>Journey details 
<br />
<br />Public transport journey</strong>
<br />The journey details are initially shown on this page in a
diagram format. If you prefer, you can view the details in a table
format by clicking "Show details in table".
<br />
<br />
<strong>Car journey 
<br /></strong>The directions for your car journey are initially
shown in a list. If you prefer, you can view them on a map by
clicking "Show on map". The map will appear with the directions
listed below it.
<br />Journey directions:</p>
<br />
<ul>
  <li>The directions for your journey are summarised at the top of
  the page</li>
  <li>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to their websites.</li>
</ul>
<br />
<p>You can view specific stages of the journey in more detail: 
<br />1. Select the journey stage from the drop-down list 
<br />2. Click ''Show route'' 
<br />
<br />Click ''Printer friendly'' to open a printer-friendly page that
you can print as usual. 
<br />
<br />You can view symbols on the map when it is highly magnified
(within the top five zoom levels, outlined in yellow). They include
transport symbols (shown automatically) and a range of attraction
and facility symbols. 
<br />
<br />To show or hide any of these symbols, you must: 
<br />1. Click on a category radio button e.g. ''Accommodation'' 
<br />2. Tick or untick the boxes next to the symbols 
<br />3. Click ''Show selected symbols''</p>
<br />
<br />
<p>The colour coding used on the map may show traffic levels as: 
<ul>
  <li>Low traffic </li>
  <li>Medium traffic </li>
  <li>High traffic </li>
  <li>Traffic unknown </li>
</ul></p>
<p>Low, medium and high traffic levels are based upon past traffic
measurements provided by the Highways Agency, the Welsh Assembly
and the Scottish Executive. These take into consideration the road,
the direction, and the day and time of travel. Where "Traffic
unknown" is shown, no traffic measurements are available for the
specific roads, so estimated traffic speeds for the time, day and
type of road are used in planning the journey (based on the
National Traffic Model).</p>
<br />
<br />
<p>
<strong>Amend date and time</strong>
<br />To amend the dates and times of your journey: 
<br />1. Select the new date(s) and time(s) in the drop-down lists 
<br />2. Click ''Search with new dates/times'' 
<br />
<br />To amend the entire journey, you can click ''Amend journey''
at the top of the page</p>
<br />
<p>
<strong>Save as a favourite journey</strong>
<br />To save the journey: 
<br />1. Make sure you are logged in 
<br />2. Enter a meaningful name for the journey (e.g.
&#244;Journey to work&#246;) 
<br />3. Click ''OK'' 
<br />
<br />You can save up to five journeys and you can overwrite
existing journeys.</p>
<br />
<p>
<strong>Send to a friend</strong>
<br />To send this page to a friend: 
<br />1. Make sure you are logged in. 
<br />2. If you are not logged in, you will need to enter your
username and password. 
<br />3. Type in the email address of the person you would like to
send the page to in the box 
<br />4. Click ''Send'' 
<br />
<br />A text-based email with a summary of the journey and the
details/directions will be sent to that email address. Maps (if
applicable) will be attached as an image file (Avg. email size
150k). Your email address will be shown in the email.</p>
<br />
'
,
'<p>
<strong>Manylion siwrnai 
<br />
<br />Siwrnai cludiant cyhoeddus</strong>
<br />Dangosir manylion y siwrnai i ddechrau ar y dudalen hon ar
ffurf diagram. Os yw''n well gennych, gallwch weld y manylion ar
ffurf tabl drwy glicio ar ''Dangos manylion mewn tabl''.
<br />
<br />
<strong>Siwrnai car 
<br /></strong>Dangosir y cyfeiriadau ar gyfer eich siwrnai car i
ddechrau mewn rhestr. Os byddai''n well gennych, gallwch eu gweld ar
fap drwy glicio ar ''Dangoswch ar y map''. Bydd y map yn ymddangos
gyda''r cyfarwyddiadau wedi eu rhestru oddi tano. 
<br />Cyfeiriadau''r siwrnai:</p>
<br />
<ul>
  <li>Rhoddir crynodeb o''r cyfarwyddiadau ar gyfer eich siwrnai ar
  frig y dudalen.</li>
  <li>Os yw''r siwrnai yn ymwneud &#212; ffer&#180;au, tollau ac
  ati, gallwch glicio ar yr enw yn y cyfarwyddyd i gael eich cymryd
  i''w gwefannau.</li>
</ul>
<br />
<p>Gallwch weld camau penodol o''r siwrnai yn fanylach:
<br />1. Dewiswch gam y siwrnai fel rhestr a ollyngir i lawr
<br />2. Cliciwch ar ''Dangoswch y Llwybr''
<br />
<br />Cliciwch ar ''Hawdd ei argraffu'' i agor tudalen briodol y
gallwch ei hargraffu fel arfer
<br />
<br />Gallwch weld symbolau ar y map pan fo wedi ei chwyddo''n fawr
(o fewn y pump lefel chwyddo mwyaf a amlinellir mewn melyn). Maent
yn cynnwys symbolau cludiant (a ddangosir yn awtomatig) ac
amrywiaeth o symbolau atyniadau a chyfleusterau 
<br />
<br />I ddangos neu guddio unrhyw rai o''r symbolau hyn, rhaid i
chi:
<br />1. Glicio ar fotwm radio a dewis categori e.e. ''Llety''
<br />2. Dicio neu ddad-dicio''r blychau ger y symbolau
<br />3. Glicio ar ''Dewiswch symbolau detholedig''</p>
<br />
<br />
<p>Mae''n bosibl y bydd y c&#182;d lliw ar y map yn dangos lefelau
trafnidiaeth fel:
<ul>
  <li>Traffig isel</li>
  <li>Traffig canolig</li>
  <li>Traffig uchel</li>
  <li>Traffig anhysbys</li>
</ul></p>
<p>Mae lefelau trafnidiaeth isel, canolig ac uchel yn seiliedig ar
fesurau traffig y gorffennol a ddarparwyd gan Awdurdod y Priffyrdd,
Cynulliad Cenedlaethol Cymru a Gweithrediaeth yr Alban. Mae''r rhain
yn cymryd y ffordd, y cyfeiriad a diwrnod ac amser teithio i
ystyriaeth. Lle dangosir "Traffig anhysbys", nid oes mesuriadau
traffig ar gael ar gyfer y ffyrdd penodol, felly defnyddir
amcangyfrif o gyflymderau traffig ar gyfer yr amser, y diwrnod a''r
math o ffordd wrth gynllunio''r siwrnai (yn seiliedig ar Model
Traffig Cenedlaethol).</p>
<br />
<br />
<p>
<strong>Newidiwch y dyddiad a''r amser</strong>
<br />I ddiwygio dyddiadau ac amserau eich siwrnai:
<br />1. Dewiswch y dyddiad(au) a''r amser(au) newydd yn y rhestrau
a ollyngir i lawr
<br />2. Cliciwch ar ''Chwiliwch gyda dyddiadau/amserau newydd''
<br />
<br />I ddiwygio''r siwrnai gyfan, gallwch glicio ''Diwygiwch y
siwrnai'' ar frig y dudalen.</p>
<br />
<p>
<strong>Cadwch fel hoff siwrnai</strong>
<br />I gadw''r siwrnai:
<br />1. Gofalwch eich bod wedi logio i mewn
<br />2. Rhowch enw ystyrlon i''r siwrnai (e.e. ''Siwrnai i''r
gwaith'')
<br />3. Cliciwch ar ''Iawn''.
<br />
<br />Gallwch gadw hyd at bump siwrnai a gallwch ysgrifennu dros
siwrneion presennol.</p>
<br />
<p>
<strong>Anfonwch y dudalen hon at ffrind drwy ebost</strong>
<br />I anfon y dudalen hon at ffrind:
<br />1. Gofalwch eich bod wedi logio i mewn.
<br />2. Os nad ydych wedi logio i mewn, bydd yn rhaid i chi roi
eich enw defnyddiwr a''ch cyfrinair.
<br />3. Teipiwch gyfeiriad ebost y sawl yr hoffech anfon y dudalen
atynt yn y blwch
<br />4. Cliciwch ''Anfon''
<br />
<br />Anfonir ebost testun gyda chrynodeb o''r siwrnai a''r
manylion/cyfarwyddiadau at y cyfeiriad ebost hwnnw. Atodir mapiau
(os yn berthnasol) fel ffeil ddelwedd (maint ebost cyfartalog
150k). Dangosir eich cyfeiriad ebost yn yr e-bost.</p>
<br />
'



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1528
SET @ScriptDesc = 'Find map pages and control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO