-- ***********************************************
-- NAME 		: DUP1321_TransportDirect_Content_5_Home_RightHandPanel.sql
-- DESCRIPTION 	: Script to add the Right Hand Information panel text
-- AUTHOR		: John Frank
-- DATE			: 24 Apr 2009
-- ************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Content]
GO


DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')



-- Right hand items 1 and 2
EXEC AddtblContent
1, @GroupId, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Day trip on a budget?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Train Image" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" border="0" /></td>  
<td class="txtseven">Plan your day out by train this summer and use our <a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Find cheaper rail fares</a> tool to find the cheapest day to travel.</td></tr></tbody></table></div>
<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Travel at your fingertips?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Mobile Phone Image" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/MobileSmallIcon.gif" border="0" /></td>  
<td class="txtseven">Did you know that you can send your favourite journeys to your mobile? With a click of your mobile you can get live rail departures, bus schedules and travel news including roads. Visit our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">mobile page.</a></td></tr></tbody></table></div>'
, 
'<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Day trip on a budget?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Train Image" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/train_sm.gif" border="0" /></td>  
<td class="txtseven">Plan your day out by train this summer and use our <a href="/Web2/JourneyPlanning/FindTrainCostInput.aspx">Find cheaper rail fares</a> tool to find the cheapest day to travel.</td></tr></tbody></table></div>
<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/TDOnTheMove/TDOnTheMove.aspx">Travel at your fingertips?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Mobile Phone Image" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/MobileSmallIcon.gif" border="0" /></td>  
<td class="txtseven">Did you know that you can send your favourite journeys to your mobile? With a click of your mobile you can get live rail departures, bus schedules and travel news including roads. Visit our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">mobile page.</a></td></tr></tbody></table></div>'


-- Right hand item 3
EXEC AddtblContent
1, @GroupId, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home',
'<div class="Column3Header">
<div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">Does your website have a ''How to get here'' page? You can now create links that open Transport Direct with your destination pre-set. For example:<br/><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The Luminaire, Kilburn">Directions to the Luminaire</a><br /><br />Download this <a href="http://www.dft.gov.uk/excel/256753/intelligentlink.xls" target="_child" >Excel link generator (opens new window)</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page (opens new window)</a> for more details.</td></tr></tbody></table></div>'
,
'<div class="Column3Header">
<div class="txtsevenbbl">Free tools</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">Does your website have a ''How to get here'' page? You can now create links that open Transport Direct with your destination pre-set. For example:<br/><a href="/Web2/journeyplanning/jplandingpage.aspx?&amp;id=demo&amp;d=524885,184280&amp;dn=The Luminaire, Kilburn">Directions to the Luminaire</a><br /><br />Download this <a href="http://www.dft.gov.uk/excel/256753/intelligentlink.xls" target="_child" >Excel link generator (opens new window)</a> or see our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page (opens new window)</a> for more details.</td></tr></tbody></table></div>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1321
SET @ScriptDesc = 'Script to add Homepage Right hand information text for May'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO