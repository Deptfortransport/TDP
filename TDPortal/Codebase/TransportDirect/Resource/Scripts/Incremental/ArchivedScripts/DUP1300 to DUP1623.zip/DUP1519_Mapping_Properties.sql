-- ***********************************************
-- NAME 		: DUP1519_Mapping_Properties.sql
-- DESCRIPTION 	: Script to add mapping properties
-- AUTHOR		: Amit Patel
-- DATE			: 20 Nov 2009
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'MapControl.FindNearest.DefaultMapLevel' and ThemeId = 1)
BEGIN
	insert into properties values ('MapControl.FindNearest.DefaultMapLevel', '9', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '9'
	where pname = 'MapControl.FindNearest.DefaultMapLevel' and ThemeId = 1
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1519
SET @ScriptDesc = 'Script to add mapping properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO