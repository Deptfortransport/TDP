-- ***********************************************
-- NAME 		: DUP1592_InternationalPlanner_DataImport_Propery.sql
-- DESCRIPTION 	: Script to add property for International data import
-- AUTHOR		: Amit Patel
-- DATE			: 24 Feb 2010
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'datagateway.sqlimport.internationalplanner.versiontodeletefromlast' and ThemeId = 1)
BEGIN
	insert into properties values ('datagateway.sqlimport.internationalplanner.versiontodeletefromlast', '5', 'DataGateway', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '5'
	where pname = 'datagateway.sqlimport.internationalplanner.versiontodeletefromlast' and ThemeId = 1
END


GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1592
SET @ScriptDesc = 'Script to add property for International data import'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO