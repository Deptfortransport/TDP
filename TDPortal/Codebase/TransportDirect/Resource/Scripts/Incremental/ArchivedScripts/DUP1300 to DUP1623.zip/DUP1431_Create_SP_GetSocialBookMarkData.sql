-- *************************************************************************************
-- NAME 		: DUP1431_Create_SP_GetSocialBookMarkData.sql
-- DESCRIPTION  	: sp to retreive social book mark lins
-- AUTHOR		: Phil Scott
-- DATE			: 10 Aug 2009 15:00:00
-- *************************************************************************************

USE [TransientPortal]
GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


---------------------------------------------------------------------
-- Get Social Bookmark Data
---------------------------------------------------------------------
Create   PROCEDURE [dbo].GetSocialBookMarkData 
	
AS

SELECT 	
    SBMId, 
    SBMDescription,
    SBMDisplayText,
    SBMDisplayIconPath,
    SBMURLTemplate,
    SBMLandingPartnerCode,
    SBMVisible,SBMThemeId
from dbo.SocialBookMarks
order by SBMId

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1431
SET @ScriptDesc = 'Create SP  GetSocialBookMarkData.sql'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
