-- ***********************************************
-- NAME 			: DUP1302_CyclePlanner_DropDownListsUpdate.sql
-- DESCRIPTION 			: Script to update Cycle PLanner Drop Down Lists
-- AUTHOR			: Mark Turner
-- DATE				: 24 Feb 2009
-- ***********************************************

USE [PermanentPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- PROPERTIES
--------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT TOP 1 * FROM dropdownlists WHERE dataset LIKE 'CycleJourneyType' AND ResourceID LIKE 'Recreational')
BEGIN
	UPDATE dropdownlists 
    SET ItemValue = 'Recreational'
    WHERE dataset LIKE 'CycleJourneyType' AND ResourceID LIKE 'Recreational'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1302
SET @ScriptDesc = 'Script to update Cycle PLanner Drop Down Lists'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO