-- ***********************************************
-- NAME 		: DUP1552_StopData_Import.sql
-- DESCRIPTION 		: Script to transfer data from GAZ to TDP_Maps database
-- AUTHOR		: Amit Patel
-- DATE			: 18 Jan 2010
-- ************************************************

----------------------------------------------------------------------------------
--		SCRIPT TO IMPORT STOP DATA FROM GAZ DATABASE TO TDP_MAPS DATABASE		--
--
--	** WARNING **	
--  This script should run on the server on which TDP_MAPS database resides
--  Before running the script change the neccessary parameters and 
--  uncomment the lines as necessary
----------------------------------------------------------------------------------

USE [TDP_MAPS]
GO

/****** Object:  Table [mapsadmin].[STOPS_GAZ_NAME] ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[mapsadmin].[STOPS_GAZ_NAME]') AND type in (N'U'))
BEGIN

CREATE TABLE [mapsadmin].[STOPS_GAZ_NAME](
	[NAPTANID] [varchar](254) NOT NULL,
	[REPORTING_NAME] [varchar](255) NULL
) 
CREATE  CLUSTERED  INDEX [IX_STOPS_GAZ_NAME] ON [mapsadmin].[STOPS_GAZ_NAME]([NAPTANID])

END

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [mapsadmin].[STOPS_GAZ_NAME]  ******/

-- Adding linked server to server where GAZ database is
-- ** Warning ** change @datasrc to the server where GAZ database is
EXEC sp_addlinkedserver   
   @server='gazRemote', 
   @srvproduct='',
   @provider='SQLNCLI', 
   @datasrc='D02'                 
GO

-- ** Warning ** Uncomment the EXEC line below to connect the remote GAZ database server with specific login
-- This will map <Local Login> to GAZ database server with the gazadmin login

EXEC sp_addlinkedsrvlogin 'gazRemote', 'false', 'bbptdps\siadmin', 'gazadmin', 'Wh1t34lbum!'


--** uncomment the following 2 lines to carry out a dataload **

--truncate table TDP_MAPS.mapsadmin.STOPS_GAZ_NAME;

--insert into TDP_MAPS.mapsadmin.STOPS_GAZ_NAME select ATCOCODE, REPORTING_NAME from gazRemote.GAZ.gazadmin.ALLSTAT_LKP ORDER BY ATCOCODE asc;

--GO

-- ** Warning ** Uncomment the lines below if specific login been used 

-- EXEC sp_droplinkedsrvlogin 'gazRemote', 'bbptdps\siadmin'
-- GO

--EXEC sp_dropserver 'gazRemote'
--GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1552
SET @ScriptDesc = 'Script to transfer data from GAZ to TDP_Maps database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO