-- ***********************************************
-- NAME 		: DUP1421_EBC_ChangeNotification.sql
-- DESCRIPTION 	: Add EnvironmentalBenefits calculator to Change Notification Table
-- AUTHOR		: Mitesh Modi
-- DATE			: 22 Sep 2009
-- ************************************************

USE [PermanentPortal]
GO

--Delete existing entries
IF EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'EnvironmentalBenefits')
BEGIN
    DELETE [dbo].[ChangeNotification]
    WHERE [dbo].[ChangeNotification].[Table] like 'EnvBen%'
END

-- Add all the tables being monitored for Environmental benefits
IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'EnvBenRoadCategoryCost')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('EnvBenRoadCategoryCost', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'EnvBenHighValueMotorway')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('EnvBenHighValueMotorway', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'EnvBenHighValueMotorwayJunction')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('EnvBenHighValueMotorwayJunction', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'EnvBenVirtualMotorwayJunction')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('EnvBenVirtualMotorwayJunction', 1)
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1421
SET @ScriptDesc = 'Added EnvironmentalBenefits tables to Change Notification Table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------