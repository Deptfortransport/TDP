-- ***********************************************
-- NAME 			: DUP1493_Add_newwindow_icon_to_car_costspage_AA_RAC.sql
-- DESCRIPTION 			: Script to update Opens in new window
-- DESCRIPTION 			: Replace "opens in new window" with an icon
-- AUTHOR			: Neil Rankin
-- DATE				: 15 September 2009
-- ***********************************************

USE [Content]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Content
--------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT 1
             FROM tblContent 
            WHERE PropertyName = 'CarJourneyItemisedCostsControl.labelRunningInstruction')
BEGIN
    UPDATE tblContent 
       SET [Value-En] = 'Note: The running costs are based on information from the RAC for a car that is up to three years old and has averaged 12000 miles/year.    We assume you have a medium sized petrol-engined car unless you have specified your own values for car size and fuel type.    More detailed information for running a petrol or diesel car can be obtained from the   <a href="http://www.theaa.com/motoring_advice/running_costs/index.html" target="_blank">AA <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a> or   <a href="http://www.emmerson-hill.co.uk/downloads/Motoring_Costs_April_2008.pdf" target="_blank" >RAC <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>.'
     WHERE [PropertyName] = 'CarJourneyItemisedCostsControl.labelRunningInstruction'

    UPDATE tblContent 
       SET [Value-Cy] = 'Noder:  Seilir y costau rhedeg ar wybodaeth oddi wrth yr RAC am gar sydd hyd at dair blwydd oed ac sydd wedi gwneud cyfartaledd o 12,000   o filltiroedd y flwyddyn, yn seiliedig ar faint eich car a''r math o danwydd os ydych wedi nodi''r rhain.  Gellir cael mwy o wybodaeth fanwl am   gostau oddi wrth yr <a href="http://www.theaa.com/motoring_advice/running_costs/index.html" target="_blank">AA <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a> neu''r   <a href="http://www.emmerson-hill.co.uk/downloads/Motoring_Costs_April_2008.pdf" target="_blank">RAC <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a>.'
     WHERE [PropertyName] = 'CarJourneyItemisedCostsControl.labelRunningInstruction'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1493
SET @ScriptDesc = 'Script to add Opens in new window icon to AA and RAC car costs'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO