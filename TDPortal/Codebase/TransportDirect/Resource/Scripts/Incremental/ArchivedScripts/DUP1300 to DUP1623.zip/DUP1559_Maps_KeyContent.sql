-- ***********************************************
-- NAME 		: DUP1559_Maps_KeyContent.sql
-- DESCRIPTION 	: Script to update the key for journey map
-- AUTHOR		: Mitesh Modi
-- DATE			: 21 Dec 2010
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Map Keys update
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.Private', 
'HighTraffic,MediumTraffic,LowTraffic,TrafficUnknown,StartLocation,EndLocation,ViaLocation,Tollbooth,FerryIcon', 
'HighTraffic,MediumTraffic,LowTraffic,TrafficUnknown,StartLocation,EndLocation,ViaLocation,Tollbooth,FerryIcon'
-- value before changing 'HighTraffic,MediumTraffic,LowTraffic,TrafficUnknown,StartLocation,EndLocation,Tollbooth,FerryIcon'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.Mixed', 
'StartLocation,EndLocation,ViaLocation,Change,Tollbooth,FerryIcon,Rail,Coach,Bus,Metro,Tram,Taxi,Air,Ferry,Walk,HighTraffic,MediumTraffic,LowTraffic,TrafficUnknown',
'StartLocation,EndLocation,ViaLocation,Change,Tollbooth,FerryIcon,Rail,Coach,Bus,Metro,Tram,Taxi,Air,Ferry,Walk,HighTraffic,MediumTraffic,LowTraffic,TrafficUnknown'
-- value before changing 'StartLocation,EndLocation,Change,StopoverLocation,Tollbooth,FerryIcon,Rail,Coach,Bus,Metro,Tram,Taxi,Air,Ferry,Walk,HighTraffic,MediumTraffic,LowTraffic,TrafficUnknown',


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1559
SET @ScriptDesc = 'Update to map key for car journeys'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO