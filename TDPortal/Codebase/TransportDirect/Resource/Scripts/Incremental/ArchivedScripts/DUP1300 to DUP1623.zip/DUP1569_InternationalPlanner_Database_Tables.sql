-- ****************************************************************
-- NAME 		: DUP1569_InternationalPlanner_Database_Tables.sql
-- DESCRIPTION 	: Creates the international planner database tables
-- AUTHOR		: Amit Patel
-- DATE			: 26 Jan 2010
-- ****************************************************************

-------------------------------------------------------------
--*********			   WARNING						*********
-- THIS SCRIPT WILL DROP ALL TABLES IN INTERNATIONALDATA, 
-- THEREFORE ONLY RUN MULTIPLE TIMES WHERE IT IS OK TO LOSE ANY PERMISSIONS ADDED TO THE TABLES.
-------------------------------------------------------------


USE [InternationalData]
GO

-----------------------------------------------
-- Drop Existing Tables
-----------------------------------------------

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleAir') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ScheduleAir] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleRail') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ScheduleRail] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleRailLeg') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ScheduleRailLeg] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleCoach') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ScheduleCoach] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleCoachLeg') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ScheduleCoachLeg] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InternationalCityStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[InternationalCityStop] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InternationalStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[InternationalStop] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.StopDistances') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[StopDistances] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.Country') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[Country] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CountryJourney') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[CountryJourney] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleCar') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ScheduleCar] 
END
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InternationalCity') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[InternationalCity] 
END
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InterchangeTime') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[InterchangeTime] 
END
GO


IF  EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ChangeNotification') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	DROP TABLE [dbo].[ChangeNotification]
END
GO

-----------------------------------------------
-- Create ScheduleAir table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleAir') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ScheduleAir (
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[CarrierCode] [varchar] (5) NOT NULL,
		[FlightNumber] [varchar] (10) NULL,
		[DepartureAirportStopCode] [varchar] (20) NOT NULL,
		[ArrivalAirportStopCode] [varchar] (20) NOT NULL,
		[DepartureTime] [time] NOT NULL,
		[ArrivalTime] [time] NOT NULL,
		[ArrivalDay] [int] NOT NULL,
		[DaysOfOperation] [varchar] (7) NOT NULL,
		[AircraftTypeCode] [varchar] (50) NULL,
		[EffectiveFromDate] [datetime] NOT NULL,
		[EffectiveToDate] [datetime]  NOT NULL,
		[TerminalNumberFrom] [varchar] (20) NULL,
		[TerminalNumberTo] [varchar] (20) NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.ScheduleAir ADD CONSTRAINT
		PK_ScheduleAir PRIMARY KEY CLUSTERED ( Id )

END
GO

-----------------------------------------------
-- Create ScheduleRail table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleRail') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ScheduleRail (
		[Id] [int] NOT NULL,
		[OperatorCode] [varchar] (5) NOT NULL,
		[TrainNumber] [varchar] (10) NOT NULL,
		[DaysOfOperation] [varchar] (14) NOT NULL,
		[ServiceFacilities] [varchar] (10) NULL,
		[EffectiveFromDate] [datetime] NOT NULL,
		[EffectiveToDate] [datetime]  NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.ScheduleRail ADD CONSTRAINT
		PK_ScheduleRail PRIMARY KEY CLUSTERED ( Id )

END
GO


-----------------------------------------------
-- Create ScheduleRailLeg table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleRailLeg') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ScheduleRailLeg (
		[ScheduleRailId] [int] NOT NULL,
		[LegNum] [int] NOT NULL,
		[DepartureStationStopCode] [varchar] (20) NOT NULL,
		[ArrivalStationStopCode] [varchar] (20) NOT NULL,
		[DepartureTime] [time] NOT NULL,
		[DepartureDay] [int] NOT NULL,
		[ArrivalTime] [time] NOT NULL,
		[ArrivalDay] [int] NOT NULL
	) ON [PRIMARY]

END
GO

-----------------------------------------------
-- Create ScheduleCoach table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleCoach') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ScheduleCoach (
		[Id] [int] NOT NULL,
		[OperatorCode] [varchar] (5) NOT NULL,
		[CoachNumber] [varchar] (10) NOT NULL,
		[DaysOfOperation] [varchar] (14) NOT NULL,
		[ServiceFacilities] [varchar] (10) NULL,
		[EffectiveFromDate] [datetime] NOT NULL,
		[EffectiveToDate] [datetime]  NOT NULL,
		[Notes] [varchar] (200) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.ScheduleCoach ADD CONSTRAINT
		PK_ScheduleCoach PRIMARY KEY CLUSTERED ( Id )

END
GO


-----------------------------------------------
-- Create ScheduleCoachLeg table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleCoachLeg') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ScheduleCoachLeg(
		[ScheduleCoachId] [int] NOT NULL,
		[LegNum] [int] NOT NULL,
		[DepartureStationStopCode] [varchar] (20) NOT NULL,
		[ArrivalStationStopCode] [varchar] (20) NOT NULL,
		[DepartureTime] [time] NOT NULL,
		[DepartureDay] [int] NOT NULL,
		[ArrivalTime] [time] NOT NULL,
		[ArrivalDay] [int] NOT NULL
	) ON [PRIMARY]

END
GO



-----------------------------------------------
-- Create InternationalStop table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InternationalStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.InternationalStop (
		[StopCode] [varchar] (20) NOT NULL,
		[StopNaPTAN] [varchar] (12) NOT NULL,
		[StopType] [varchar] (10) NOT NULL,
		[StopName] [varchar] (100) NOT NULL,
		[StopOSGREasting] [int] NULL DEFAULT(-1),
		[StopOSGRNorthing] [int]NULL DEFAULT(-1),
		[StopCountryCode] [varchar] (10) NOT NULL,
		[StopTerminalNumber] [varchar] (10) NULL,
		[StopInformationURL] [varchar] (100) NULL,
		[StopInformationDescription] [varchar] (2000) NULL,
		[StopDeparturesURL] [varchar] (100) NULL,
		[StopDeparturesDescription] [varchar] (2000) NULL,
		[StopAccessabilityURL] [varchar] (100) NULL,
		[StopAccessabilityDescription] [varchar] (2000) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.InternationalStop ADD CONSTRAINT
		PK_InternationalStop PRIMARY KEY CLUSTERED ( StopCode, StopNaptan ) 
	
	ALTER TABLE dbo.InternationalStop ADD CONSTRAINT
		UQ_InternationalStop UNIQUE NONCLUSTERED ( StopNaPTAN )
		
END
GO

-----------------------------------------------
-- Create StopDistances table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.StopDistances') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.StopDistances (
		[OriginStopCode] [varchar] (20) NOT NULL,
		[DestinationStopCode] [varchar] (20) NOT NULL,
		[Distance] [int] NOT NULL,
	) ON [PRIMARY]

	ALTER TABLE dbo.StopDistances ADD CONSTRAINT
		PK_StopDistances PRIMARY KEY CLUSTERED ( OriginStopCode, DestinationStopCode )

END
GO

-----------------------------------------------
-- Create Country table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.Country') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.Country (
		[CountryCode] [varchar] (10) NOT NULL,
		[CountryCodeIANA] [varchar] (5) NOT NULL,
		[CountryAdminCodeUIC] [varchar] (20) NULL,
		[CountryTimeZoneHours] [smallint]  NOT NULL,
		[CountrySchedulesRequired] [varchar] (1) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.Country ADD CONSTRAINT
		PK_Country PRIMARY KEY CLUSTERED ( CountryCode ) 

END
GO

-----------------------------------------------
-- Create CountryJourney table
-----------------------------------------------	

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.CountryJourney') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.CountryJourney (
		[DepartureCountryCode] [varchar] (10) NOT NULL,
		[ArrivalCountryCode] [varchar] (10) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.CountryJourney ADD CONSTRAINT
		PK_CountryJourney PRIMARY KEY CLUSTERED ( DepartureCountryCode, ArrivalCountryCode )


END
GO

-----------------------------------------------
-- Create InternationalCity table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InternationalCity') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.InternationalCity (
		[CityId] [int] IDENTITY(1,1) NOT NULL,
		[CityName] [varchar] (100) NOT NULL,
		[CityCountryCode] [varchar] (10) NULL,
		[CityURL] [varchar] (100) NULL,
		[CityOSGREasting] [int] NULL DEFAULT(-1),
		[CityOSGRNorthing] [int] NULL DEFAULT(-1),
	) ON [PRIMARY]

	ALTER TABLE dbo.InternationalCity ADD CONSTRAINT
		PK_InternationalCity PRIMARY KEY CLUSTERED ( CityId ) 


END
GO

-----------------------------------------------
-- Create InternationalCityStop table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InternationalCityStop') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.InternationalCityStop (
		[CityId] [int] NOT NULL,
		[StopNaPTAN] [varchar] (12) NOT NULL,
		[TransferTimeMinutes] int NULL,
		[TransferInformation] [varchar] (2000) NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.InternationalCityStop ADD CONSTRAINT
		PK_InternationalCityStop PRIMARY KEY CLUSTERED ( CityId, StopNaPTAN ) 

	--ALTER TABLE dbo.InternationalCityStop ADD CONSTRAINT
	--	FK_InternationalCityStop_InternationalCity FOREIGN KEY ( CityId )
	--	REFERENCES dbo.InternationalCity ( CityId )
		
	--ALTER TABLE dbo.InternationalCityStop ADD CONSTRAINT
	--	FK_InternationalCityStop_InternationalStop FOREIGN KEY ( StopNaPTAN )
	--	REFERENCES dbo.InternationalStop ( StopNaPTAN )
END
GO

-----------------------------------------------
-- Create InterchangeTime table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.InterchangeTime') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.InterchangeTime (
		[FromNaPTAN] [varchar] (12) NOT NULL,
		[ToNaPTAN] [varchar] (12) NOT NULL,
		[FromOperator] [varchar] (10) NOT NULL,
		[ToOperator] [varchar] (10) NOT NULL,
		[InterchangeTimeMinutes] [int] NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.InterchangeTime ADD CONSTRAINT
		PK_InterchangeTime PRIMARY KEY CLUSTERED ( FromNaPTAN, ToNaPTAN, FromOperator, ToOperator )

END
GO

-----------------------------------------------
-- Create ScheduleCar table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ScheduleCar') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
	CREATE TABLE dbo.ScheduleCar (
		[DepartureCityId][int] NOT NULL,
		[ArrivalCityId][int] NOT NULL,
		[DepartureTime][time] NOT NULL,
		[ArrivalTime][time] NOT NULL,
		[ArrivalDay][int] NOT NULL,
		[EmissionsGrammes][decimal] NOT NULL,
		[JourneyInformation][varchar] (2000) NOT NULL,
		[JourneyURL][varchar] (100) NOT NULL
	) ON [PRIMARY]

	ALTER TABLE dbo.ScheduleCar ADD CONSTRAINT
		PK_ScheduleCar PRIMARY KEY CLUSTERED ( DepartureCityId, ArrivalCityId )
	
	-- ALTER TABLE dbo.ScheduleCar ADD CONSTRAINT
	--	FK_ScheduleCar_InternationalCity_Departure FOREIGN KEY ( DepartureCityId )
	--	REFERENCES dbo.InternationalCity ( CityId )
	
	-- ALTER TABLE dbo.ScheduleCar ADD CONSTRAINT
	--	FK_ScheduleCar_InternationalCity_Arrival FOREIGN KEY ( ArrivalCityId )
	--	REFERENCES dbo.InternationalCity ( CityId )
	
END
GO		



-----------------------------------------------
-- Create ChangeNotification table
-----------------------------------------------

IF NOT EXISTS (select * from dbo.sysobjects where id = object_id(N'dbo.ChangeNotification') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN

	CREATE TABLE [dbo].[ChangeNotification](
		[Version] [int] NULL,
		[Table] [varchar](100) NULL
	) ON [PRIMARY]

END
GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1569
SET @ScriptDesc = 'Add international planner database tables'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO