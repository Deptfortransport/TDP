-- ***********************************************
-- NAME 		: DUP1568_InternationalPlanner_Database_Create.sql
-- DESCRIPTION 	: Creates the international planner database
-- AUTHOR		: Amit Patel
-- DATE			: 26 Jan 2010
-- ************************************************


-------------------------------------------------------------
--*********			   WARNING						*********
-- UPDATE DATABASE PATHS
-- GRANT APPROPRIATE PERMISSIONS
-------------------------------------------------------------

USE [master]
GO

IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'InternationalData')
BEGIN
	DROP DATABASE [InternationalData]
END
GO

CREATE DATABASE [InternationalData] ON (NAME = N'InternationalData', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\InternationalData.mdf' , SIZE = 3, FILEGROWTH = 10%) LOG ON (NAME = N'InternationalData_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL10.MSSQLSERVER\MSSQL\DATA\InternationalData_log.ldf' , SIZE = 1, FILEGROWTH = 10%) COLLATE SQL_Latin1_General_CP1_CI_AS 
GO

exec sp_dboption N'InternationalData', N'torn page detection', N'true'
GO

exec sp_dboption N'InternationalData', N'autoshrink', N'false'
GO

exec sp_dboption N'InternationalData', N'ANSI null default', N'true'
GO

exec sp_dboption N'InternationalData', N'ANSI nulls', N'true'
GO

exec sp_dboption N'InternationalData', N'ANSI warnings', N'true'
GO

exec sp_dboption N'InternationalData', N'auto create statistics', N'true'
GO

exec sp_dboption N'InternationalData', N'auto update statistics', N'true'
GO

if( ( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) ) or ( (@@microsoftversion / power(2, 24) = 7) and (@@microsoftversion & 0xffff >= 1082) ) )
	exec sp_dboption N'InternationalData', N'db chaining', N'false'
GO


use [master]
ALTER DATABASE [InternationalData] SET RECOVERY SIMPLE
GO

-------------------------------------------------------------
--********			   WARNING					***********--			
-- CREATE appropriate permissions
-------------------------------------------------------------
-- GRANT EXECUTE ON [InternationalData] TO [???]
-- GO


------------------------
-- Change Log 
------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1568
SET @ScriptDesc = 'Create International Planner database'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO