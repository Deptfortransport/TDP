-- ***********************************************
-- NAME 			: DUP1566_Amend_NationalRail_ATOC_URLS.sql
-- DESCRIPTION 			: Script to update NationalRail ATOC URLS
-- AUTHOR			: Neil Rankin
-- DATE				: 10 Feb 2010
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- TransientPortal
--------------------------------------------------------------------------------------------------------------------------------

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/AW/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/AW/details.html'
     WHERE [Id] = 'OperatorLink.AW'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/CC/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/CC/details.html'
     WHERE [Id] = 'OperatorLink.CC'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/CH/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/CH/details.html'
     WHERE [Id] = 'OperatorLink.CH'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/CT/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/CT/details.html'
     WHERE [Id] = 'OperatorLink.CT'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/EC/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/EC/details.html'
     WHERE [Id] = 'OperatorLink.EC'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/EM/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/EM/details.html'
     WHERE [Id] = 'OperatorLink.EM'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/ES/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/ES/details.html'
     WHERE [Id] = 'OperatorLink.ES'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/FC/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/FC/details.html'
     WHERE [Id] = 'OperatorLink.FC'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GC/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GC/details.html'
     WHERE [Id] = 'OperatorLink.GC'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GL/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GL/details.html'
     WHERE [Id] = 'OperatorLink.GL'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GR/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GR/details.html'
     WHERE [Id] = 'OperatorLink.GR'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GW/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GW/details.html'
     WHERE [Id] = 'OperatorLink.GW'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GX/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/GX/details.html'
     WHERE [Id] = 'OperatorLink.GX'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/HC/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/HC/details.html'
     WHERE [Id] = 'OperatorLink.HC'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/HT/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/HT/details.html'
     WHERE [Id] = 'OperatorLink.HT'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/HX/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/HX/details.html'
     WHERE [Id] = 'OperatorLink.HX'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/IL/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/IL/details.html'
     WHERE [Id] = 'OperatorLink.IL'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/LE/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/LE/details.html'
     WHERE [Id] = 'OperatorLink.LE'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/LM/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/LM/details.html'
     WHERE [Id] = 'OperatorLink.LM'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/LO/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/LO/details.html'
     WHERE [Id] = 'OperatorLink.LO'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/ME/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/ME/details.html'
     WHERE [Id] = 'OperatorLink.ME'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/ML/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/ML/details.html'
     WHERE [Id] = 'OperatorLink.ML'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/NT/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/NT/details.html'
     WHERE [Id] = 'OperatorLink.NT'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/PM/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/PM/details.html'
     WHERE [Id] = 'OperatorLink.PM'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SE/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SE/details.html'
     WHERE [Id] = 'OperatorLink.SE'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SN/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SN/details.html'
     WHERE [Id] = 'OperatorLink.SN'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SR/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SR/details.html'
     WHERE [Id] = 'OperatorLink.SR'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SS/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SS/details.html'
     WHERE [Id] = 'OperatorLink.SS'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SW/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/SW/details.html'
     WHERE [Id] = 'OperatorLink.SW'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/TL/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/TL/details.html'
     WHERE [Id] = 'OperatorLink.TL'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/TP/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/TP/details.html'
     WHERE [Id] = 'OperatorLink.TP'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/VT/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/VT/details.html'
     WHERE [Id] = 'OperatorLink.VT'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/WE/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/WE/details.html'
     WHERE [Id] = 'OperatorLink.WE'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/WN/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/WN/details.html'
     WHERE [Id] = 'OperatorLink.WN'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/WS/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/WS/details.html'
     WHERE [Id] = 'OperatorLink.WS'
END

BEGIN
    UPDATE ExternalLinks 
       SET [URL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/XC/details.html',
		[TestURL] = 'http://www.nationalrail.co.uk/tocs_maps/tocs/XC/details.html'
     WHERE [Id] = 'OperatorLink.XC'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1566
SET @ScriptDesc = 'Script to update NationalRail ATOC URLS'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO