-- ***********************************************
-- NAME 		: DUP1563_DECC_ExternalLink.sql
-- DESCRIPTION 		: Script to modify External link for decc
-- AUTHOR		: Mitesh Modi
-- DATE			: 10 Jul 2008 18:00:00
-- ************************************************


USE [TransientPortal]
GO

-- DECC
EXEC AddExternalLink
'JourneyEmissions.OffsetCarbonEmissions', 
'http://www.decc.gov.uk/en/content/cms/what_we_do/lc_uk/co2_offsetting/co2_offsetting.aspx', 
'http://www.decc.gov.uk/en/content/cms/what_we_do/lc_uk/co2_offsetting/co2_offsetting.aspx', 
'Offset Carbon Emissions'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1563
SET @ScriptDesc = 'Change to Offset carbon emissions URL'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO