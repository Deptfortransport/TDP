-- ***********************************************
-- NAME 		: DUP1548_AddLandingPartners.sql
-- DESCRIPTION 	: Script to add LandingPagePartners
-- AUTHOR		: Phil Scott
-- DATE			: 11 Jan 2010
-- ************************************************

USE [Reporting]
GO

 INSERT INTO [dbo].[LandingPagePartner] 
 (LPPID, 
 LPPCode,
 LPPDescription)
select 37,'qype','qype'
union select 38,'bgsite','bgsite'
union select 39,'WGT','WGT'
union select 37,'qype','qype'
union select 38,'bgsite','bgsite'
union select 39,'WGT','WGT'
union select 40,'cambridges','cambridges'
union select 41,'VIS','VIS'
union select 42,'capshop','capshop'
union select 43,'chicken','chicken'
union select 44,'dynamadxma','dynamadxma'
union select 45,'traffordce','traffordce'
union select 46,'quaffaleor','quaffaleor'
union select 47,'capshopls','capshopls'
union select 48,'hmcourtsse','hmcourtsse'
union select 49,'buytickets','buytickets'
union select 50,'urlhere','urlhere'
union select 51,'nhs24com','nhs24com'
union select 52,'brentgovuk','brentgovuk'
union select 53,'ents24','ents24'
union select 54,'visitbita','visitbita'
union select 55,'trainandbus.com','trainandbus.com'
union select 56,'capshopbh','capshopbh'
union select 57,'rspb','rspb'
union select 58,'WhereCanWe','WhereCanWe'
union select 59,'newportcou','newportcou'
union select 60,'bag','bag'
union select 61,'readingfc','readingfc'
union select 62,'necgroupco','necgroupco'
union select 63,'passportse','passportse'
union select 64,'planit','planit'
union select 65,'capshopha','capshopha'
union select 66,'DiamondBus','DiamondBus'





Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1548
SET @ScriptDesc = 'Script to add LandingPagePartners'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO