-- ***********************************************
-- NAME 			: DUP1379_LandingPage_IFrame_Partner_Properties.sql
-- DESCRIPTION 		: Script to setup the Bing partner id for the IFrame landing page
-- AUTHOR			: Mitesh Modi
-- DATE				: 21 Aug 2009
-- ***********************************************

USE [PermanentPortal]
GO

DECLARE 
@pName VARCHAR(100),
@pValue VARCHAR(100)

SET @pName = 'LandingPage.IFrame.JourneyLandingPage.PartnerId.Bing'
SET @pValue = 'Bing'



-- Add the partner id to Properties for Bing
IF NOT EXISTS (SELECT * FROM [dbo].[properties] WHERE pName = @pName AND AID = 'Web' AND GID = 'UserPortal')
BEGIN
    INSERT INTO [properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
    VALUES (@pName, @pValue, 'Web', 'UserPortal', 0, 1)
END
ElSE
BEGIN
    UPDATE [dbo].[properties]
    SET pValue = @pValue
    WHERE pName = @pName AND AID = 'Web' AND GID = 'UserPortal'
END



-- Add landing page partner to Reporting table
USE [Reporting]
GO

DECLARE 
@LPPCode VARCHAR(10),
@LPPDescription VARCHAR(100),
@LPPID tinyint

SET @LPPID = (SELECT MAX(LPPID) FROM [dbo].[LandingPagePartner]) + 1
SET @LPPCode = 'Bing'
SET @LPPDescription = 'Bing'

IF NOT EXISTS (SELECT * FROM [dbo].[LandingPagePartner] WHERE LPPCode = @LPPCode)
BEGIN
	INSERT INTO [dbo].[LandingPagePartner](LPPID, LPPCode, LPPDescription)
	VALUES (@LPPID, @LPPCode, @LPPDescription)
END 
ElSE
BEGIN
    UPDATE [dbo].[LandingPagePartner]
    SET LPPDescription = @LPPDescription
    WHERE LPPCode = @LPPCode
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1379
SET @ScriptDesc = 'Added Bing partner to properties used for landing page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
