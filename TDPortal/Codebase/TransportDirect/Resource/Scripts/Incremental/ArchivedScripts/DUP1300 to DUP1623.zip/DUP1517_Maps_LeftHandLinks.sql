-- ***********************************************
-- NAME 			: DUP1517_Maps_LeftHandLinks.sql
-- DESCRIPTION 		: Script to update the Left hand link for the Find Map Input page
-- AUTHOR			: Mitesh Modi
-- DATE				: 16 Nov 2009
-- ***********************************************

USE [TransientPortal]
GO

----------------------------------------------------------------
-- Update the Find a map internal link to point to the new Find Map Input page
----------------------------------------------------------------

-- Old URL 'Maps/JourneyPlannerLocationMap.aspx'
-- New URL 'Maps/FindMapInput.aspx'

EXEC AddInternalLink

	'Maps/FindMapInput.aspx',
	'Find a map'

GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1517
SET @ScriptDesc = 'Find Map Input page - Left hand link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO