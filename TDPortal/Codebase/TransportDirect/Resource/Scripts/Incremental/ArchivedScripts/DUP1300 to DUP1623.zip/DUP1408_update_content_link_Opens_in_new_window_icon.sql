-- ***********************************************
-- NAME 			: DUP1408_update_link_InNotesFor_Flight_CityToCity.sql
-- DESCRIPTION 			: Script to update Opens in new window
-- DESCRIPTION 			: Replace "opens in new window" with an icon
-- AUTHOR			: Neil Rankin
-- DATE				: 15 September 2009
-- ***********************************************

USE [Content]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Content
--------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT 1
             FROM tblContent 
            WHERE PropertyName = 'ExternalLinks.OpensNewWindowText')
BEGIN
    UPDATE tblContent 
       SET [Value-En] = '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)">'
     WHERE [PropertyName] = 'ExternalLinks.OpensNewWindowText'

    UPDATE tblContent 
       SET [Value-Cy] = '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)">'
     WHERE [PropertyName] = 'ExternalLinks.OpensNewWindowText'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1408
SET @ScriptDesc = 'Script to replace Opens in new window with an icon'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO