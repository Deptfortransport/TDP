-- ***********************************************
-- NAME 		: DUP1476_EBC_ReportStaging_StoredProcedures_Update.sql
-- DESCRIPTION 		: Script to update stored procedures to create EBCCalculationEvents
-- AUTHOR		: Mitesh Modi
-- DATE			: 12 Oct 2009
-- ************************************************

USE [ReportStagingDB]
GO


----------------------------------------------------------------
-- Update AddEBCCalculationEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER  PROCEDURE [dbo].[AddEBCCalculationEvent] (@Submitted datetime, @SessionId varchar(50), @TimeLogged datetime, @Successful bit)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into EBCCalculationEvent Table'

    Insert into EBCCalculationEvent (Submitted, SessionId, TimeLogged, Success)
    Values (@Submitted, @SessionId, @TimeLogged, @Successful)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1476
SET @ScriptDesc = 'Updated ReportStaging stored procedures for EBCCalculationEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO