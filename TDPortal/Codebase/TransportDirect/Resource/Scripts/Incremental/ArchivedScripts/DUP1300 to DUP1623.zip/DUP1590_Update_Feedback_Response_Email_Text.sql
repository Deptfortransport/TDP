-- ***********************************************
-- AUTHOR      	: Neil Rankin
-- NAME 	: DUP1590_Update_Feedback_Response_Email_Text
-- DESCRIPTION 	: Update Feedback Response Email Text
-- SOURCE 	: TDP Apps Support
-- Version	: $Revision:   1.0  $
-- ************************************************
--


USE [Content]
GO


IF EXISTS (SELECT TOP 1 * FROM tblContent WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment')
BEGIN
	UPDATE tblContent 
    SET [Value-EN] = 'Thank you for providing feedback to Transport Direct. Please be assured that every comment and suggestion made is taken forward for investigation and action as appropriate. We trust you will understand that we are unable to enter into detailed correspondence in response to your message.

Please be aware that it can take some time to effect necessary changes to correct reported errors, especially where third party data is involved (much of our data is supplied by third parties). Nevertheless all data errors are passed on to our suppliers and together we aim to resolve all of the issues you report.

Transport Direct is not responsible for the operation of public transport; therefore we are unfortunately unable to help with issues relating to the operation of bus or rail services. For matters such as this, including enquiries about lost property, or comments about the conduct of members of staff of a transport operator, you should contact the relevant transport operator directly.

If you require information about rail or coach tickets purchased using our retail hand-off facility, you should contact the relevant retail partner directly.

Suggestions on improvements to the usability and functionality of the system, and on extensions to the range of services offered, are always appreciated. Although it may take time to see such suggestions implemented, your views form an important part of our future plans for the Transport Direct Portal.

Once again thank you for taking the trouble to provide us with feedback. We regret that we cannot enter into correspondence through this e-mail address. If you have comments to make in the future please continue to use the feedback system on the Portal.

Yours sincerely
Charlene Goodman
Feedback Manager
Transport Direct'
    WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment'
END

GO


IF EXISTS (SELECT TOP 1 * FROM tblContent WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment')
BEGIN
	UPDATE tblContent 
    SET [Value-Cy] = 'Diolch am anfon atborth at Transport Direct. A gaf i''ch sicrhau bod yr holl sylwadau ac awgrymiadau yn cael eu hymchwilio a''u gweithredu fel fo''n briodol.

Rydym yn canolbwyntio ar ddatblygu a gwella''r gwasanaeth a ddarparir ac mae''ch atborth yn rhan bwysig o''r broses honno. Rydw i''n gobeithio felly, eich bod yn deall na allwn anfon gohebiaeth fanwl mewn ymateb i''ch neges.

Byddwch yn ymwybodol os gwelwch yn dda y gall hi gymryd peth amser i wneud y newidiadau angenrheidiol i gywiro gwallau honedig, yn enwedig lle fo data trydydd parti yn gysylltiedig (mae''r rhan fwyaf o''n data yn cael ei ddarparu drwy drydydd part�on). Er hynny, mae''r holl wallau data yn cael eu pasio ymlaen i''n darparwyr a gyda''n gilydd rydym yn anelu at ddatrys yr holl faterion a wnaethoch chi adrodd amdanynt.

Gwerthfawrogir awgrymiadau ar welliannau i ddefnyddioldeb ac ymarferoldeb y system, ac ar ymestyniadau i ystod y gwasanaethau a gynigir. Er mae''n bosibl y bydd yn cymryd peth amser i weld awgrymiadau o''r fath yn cael eu gweithredu, mae eich barn yn ffurfio rhan bwysig o''n cynlluniau i''r dyfodol ar gyfer Porth Transport Direct.

Unwaith eto, diolch yn fawr am fynd i''r drafferth o anfon atborth. Rydym yn ymddiheuro na allwn ddechrau gohebiaeth drwy''r cyfeiriad e-bost hwn. Os bydd gennych sylwadau i''w gwneud yn y dyfodol, os gwelwch yn dda, parhewch i ddefnyddio''r system atborth ar y Porth.

Yn gywir
Charlene Goodman
Rheolwr Adborth
Transport Direct'
    WHERE PropertyName = 'FeedbackInitialPage.AcknowledgementComment'
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1590
SET @ScriptDesc = 'Update Feedback Response Email Text'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO