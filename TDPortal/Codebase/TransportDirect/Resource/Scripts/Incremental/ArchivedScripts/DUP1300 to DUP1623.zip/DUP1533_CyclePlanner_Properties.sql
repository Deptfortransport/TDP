-- ***********************************************
-- NAME 		: DUP1533_CyclePlanner_Properties.sql
-- DESCRIPTION 	: Script to add property to increase Cycle journey planning distance
-- AUTHOR		: Mitesh Modi
-- DATE			: 02 Dec 2009
-- ************************************************

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [dbo].[properties] WHERE pName	= 'CyclePlanner.Planner.MaxJourneyDistance.Metres')
  BEGIN
    UPDATE [dbo].[properties]
    SET pValue = 50000
    WHERE pName	= 'CyclePlanner.Planner.MaxJourneyDistance.Metres'
  END
  
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1533
SET @ScriptDesc = 'Cycle planner properties update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO