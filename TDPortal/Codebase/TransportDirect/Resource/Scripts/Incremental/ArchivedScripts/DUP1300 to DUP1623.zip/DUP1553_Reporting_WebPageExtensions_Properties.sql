-- ***********************************************
-- NAME 		: DUP1553_Reporting_WebPageExtensions_Properties.sql
-- DESCRIPTION 	: Script to add property to update reporting WebPageExtensions properties
-- AUTHOR		: Amit Patel
-- DATE			: 18 Jan 2009
-- ************************************************

USE [PermanentPortal]
GO

IF EXISTS (SELECT * FROM [dbo].[properties] WHERE pName	= 'WebLogReader.WebPageExtensions')
  BEGIN
    UPDATE [dbo].[properties]
    SET pValue = 'asp aspx htm html pdf ashx [none]'
    WHERE pName	= 'WebLogReader.WebPageExtensions'
  END
  
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1553
SET @ScriptDesc = 'Script to add property to update reporting WebPageExtensions properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO