-- ***********************************************
-- NAME 		: DUP1492_StopInformation_Properties.sql
-- DESCRIPTION 		: Script to add stop information Departure controls properties
-- AUTHOR		: Amit Patel
-- DATE			: 22 Oct 2009
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'StopInformation.DepartureBoardControl.ShowMobileLink' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.DepartureBoardControl.ShowMobileLink', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.DepartureBoardControl.ShowMobileLink' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.DepartureBoardControl.ShowServiceButton' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.DepartureBoardControl.ShowServiceButton', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.DepartureBoardControl.ShowServiceButton' and ThemeId = 1
END

--- Departure board service properties

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.MockListenerPath' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.MockListenerPath', 'D:\Inetpub\wwwroot\exposedservices\MockListener\SocketListner.exe', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'D:\Inetpub\wwwroot\exposedservices\MockListener\SocketListner.exe'
	where pname = 'DepartureBoardService.RTTIManager.MockListenerPath' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END


IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.SchemaLocation' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.SchemaLocation', 'D:\Inetpub\wwwroot\web2\Schemas\rttiEPTSchema.xsd', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'D:\Inetpub\wwwroot\web2\Schemas\rttiEPTSchema.xsd'
	where pname = 'DepartureBoardService.RTTIManager.SchemaLocation' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END


IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.SocketPort' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.SocketPort', '9130', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '9130'
	where pname = 'DepartureBoardService.RTTIManager.SocketPort' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.SocketServer' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.SocketServer', '141.196.28.219', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '141.196.28.219'
	where pname = 'DepartureBoardService.RTTIManager.SocketServer' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

GO






----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1492
SET @ScriptDesc = 'Stop information page/control properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO