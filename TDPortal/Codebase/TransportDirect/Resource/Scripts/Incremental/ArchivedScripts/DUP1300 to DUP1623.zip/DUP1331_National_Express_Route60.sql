-- ***********************************************
-- NAME 			: DUP1331_National_Express_Route60.sql
-- DESCRIPTION 			: Script to add properties for National Express Route 60 Fares
-- AUTHOR			: John Frank
-- DATE				: 7 May 2009
-- ***********************************************

USE [PermanentPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- PROPERTIES
--------------------------------------------------------------------------------------------------------------------------------

DELETE FROM Properties
WHERE pname = 'CoachFares.NationalExpress.Route60.Detection'

DELETE FROM Properties
WHERE pname = 'CoachFares.NationalExpress.Route60.AppendString'

INSERT INTO Properties (pName,pValue,AID,GID,PartnerId,ThemeId)
VALUES ('CoachFares.NationalExpress.Route60.Detection','route 60','Web','UserPortal',0,1)

INSERT INTO Properties (pName,pValue,AID,GID,PartnerId,ThemeId)
VALUES ('CoachFares.NationalExpress.Route60.Detection','route 60','TDRemotingHost','TDRemotingHost',0,1)

INSERT INTO Properties (pName,pValue,AID,GID,PartnerId,ThemeId)
VALUES ('CoachFares.NationalExpress.Route60.AppendString','Route 60 - ','Web','UserPortal',0,1)

INSERT INTO Properties (pName,pValue,AID,GID,PartnerId,ThemeId)
VALUES ('CoachFares.NationalExpress.Route60.AppendString','Route 60 - ','TDRemotingHost','TDRemotingHost',0,1)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1331
SET @ScriptDesc = 'Add properties for NX Route 60'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO