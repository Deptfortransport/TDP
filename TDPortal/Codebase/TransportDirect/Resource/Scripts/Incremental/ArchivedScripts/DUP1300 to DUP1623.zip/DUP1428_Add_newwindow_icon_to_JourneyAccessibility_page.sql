-- ***********************************************
-- NAME 			: DUP1428_Add_newwindow_icon_to_JourneyAccessibility_page.sql
-- DESCRIPTION 			: Script to update Opens in new window
-- DESCRIPTION 			: Replace "opens in new window" with an icon
-- AUTHOR			: Neil Rankin
-- DATE				: 17 September 2009
-- ***********************************************

USE [Content]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Content
--------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT 1
             FROM tblContent 
            WHERE PropertyName = 'JourneyAccessibility.labelFooter.LinkText')
BEGIN
    UPDATE tblContent 
       SET [Value-En] = 'accessibility information for travellers with disabilities <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)"></a>'
     WHERE [PropertyName] = 'JourneyAccessibility.labelFooter.LinkText'

    UPDATE tblContent 
       SET [Value-Cy] = 'wybodaeth gyffredinol am hygyrchedd i deithwyr gydag anableddau <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)"></a>'
     WHERE [PropertyName] = 'JourneyAccessibility.labelFooter.LinkText'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1428
SET @ScriptDesc = 'Add newwindow icon to JourneyAccessibility page'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO