-- ***********************************************
-- NAME 		: DUP1382_SoftContentChanges_Welsh.sql
-- DESCRIPTION 		: Script to add Welsh soft content changes
-- AUTHOR		: Amit Patel
-- DATE			: 24 Aug 2009
-- ************************************************

USE [Content]
GO

-- Plan a Journey H1
EXEC AddtblContent
1, 1, 'langStrings', 'HomePlanAJourney.literalPageHeading', 'Route Planners', 'Cynllunwyr Llwybrau Teithio'


-- Live Trav News H1
EXEC AddtblContent
1, 1, 'langStrings', 'HomeTravelInfo.literalPageHeading', 'Live travel news &amp; departures', 'Newyddion teithio ac ymadawiadau byw'

-- Tips and Tools H1
EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.literalPageHeading', 'Tips and tools for travel planning', 'Awgrymiadau a theclynnau ar gyfer cynllunio teithiau'

-- Find a Train H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainInput.labelFindTrainTitle', 'Train routes &amp; timetables', 'Llwybrau ac amserlenni trenau'

-- Find Cheaper train H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainCostInput.labelFindTrainCostTitle', 'Cheaper rail travel', 'Teithiau tr�n rhatach'

-- Find Car H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindCarInput.labelFindCarTitle', 'Car route finder', 'Darganfyddwr llwybrau ceir'

-- Find Coach H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindCoachInput.labelFindCoachTitle', 'Coach routes &amp; timetables', 'Llwybrau ac amserlenni bysiau moethus'

-- City to city H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindTrunkInput.labelFindPageTitle', 'City to city journey comparison', 'Cymharu siwrneiau dinas-i-ddinas'

-- Find Bus H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindBusInput.labelFindBusTitle', 'Bus routes', 'Llwybrau bysiau'

-- Find nearest Car park H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkInput.labelDriveToCarParkTitle', 'Car park locator', 'Lleolydd meysydd parcio'

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkInput.labelFindCarParkTitle', 'Car park locator', 'Lleolydd meysydd parcio'

-- Find Map H1
EXEC AddtblContent
1, 1, 'langStrings', 'HomeFindAPlace.lblFindAPlace', 'Maps for Great Britain', 'Mapiau o Brydain Fawr'

-- Find Nearest Station H1
EXEC AddtblContent
1, 1, 'langStrings', 'FindStationInput.labelTitle', 'Station and airport locator', 'Lleolydd gorsafoedd a meysydd awyr'

-- Traffic Map H1
EXEC AddtblContent
1, 1, 'langStrings', 'panelLocation.labelJourneys', 'Traffic maps for Great Britain', 'Mapiau trafnidiaeth ar gyfer Prydain Fawr'


-- Toolbar H1
EXEC AddtblContent
1, 1, 'langStrings', 'ToolbarDownload.labelPageTitle.Text', 'Transport information toolbar', 'Bar offer gwybodaeth cludiant'

-- CO2 H1
EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsCompare.Title', 'CO2 emissions calculator', 'Mesurydd allyriadau CO2'


-- Home Page H1
EXEC AddtblContent
1, 1, 'langStrings', 'Homepage.literalPageHeading', 'Live travel news, journey planning, train times and more...', 'Newyddion teithio byw, cynllunio teithiau, amseroedd trenau a mwy...'

-- DateControl.labelPlanningTip
EXEC AddtblContent
1, 1, 'langStrings', 'DateControl.labelPlanningTip', 'You can plan journeys for the current calendar month and the next two months.', 'Gallwch gynllunio siwrneiau ar gyfer y mis calendr cyfredol a''r ddau fis nesaf.'

-- JourneyFaresControl.labelSingleTicketsNote
EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelSingleTicketsNote', 'If you choose this route you will need to purchase more than one ticket for your journey.<br />', 'Os byddwch yn dewis y llwybr hwn bydd angen ichi brynu mwy nag un tocyn ar gyfer eith taith.<br />'

-- JourneyFaresControl.labelMultipleTravelcardsNote
EXEC AddtblContent
1, 1, 'FaresAndTickets', 'JourneyFaresControl.labelMultipleTravelcardsNote', 'It may be possible to make this journey using one travelcard.<br />', 'Gall y bydd yn bosibl defnyddio un cerdyn teithio yn unig ar gyfer y daith dr�n hon.<br />'

-- RefineJourney.labelAmendTitle
EXEC AddtblContent
1, 1, 'RefineJourney', 'RefineJourney.labelAmendTitle', 'Amend your journey', 'Diwygio eich taith'

-- RefineJourney.labelAmendOptionOne
EXEC AddtblContent
1, 1, 'RefineJourney', 'RefineJourney.labelAdmendOptionOne', 'Change your origin and / or destination and / or your travel date and time', 'Newid eich man cychwyn ac /neu eich cyrchfan ac / neu eich dyddiad ac amser teithio'

-- ValidateAndRun.LocationInInvalidCycleArea
EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.LocationInInvalidCycleArea', 
	'At the moment we are able to plan cycle journeys in a <b>limited number of areas</b>.  To find out which areas are currently available please <a href="/Web2/Help/HelpCycle.aspx#A16.2">go to the FAQ on cycle planning.</a>', 
	'Ar y funud gallwn gynllunio teithiau beicio mewn <b>nifer gyfyngedig o ardaloedd</b>. Er mwyn darganfod pa ardaloedd sydd ar gael ar hyn o bryd <a href="/Web2/Help/HelpInfo.aspx#A16.2">ewch i''r adran COA sy''n gysylltiedig � chynllunio teithiau beicio.</a>'



Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1382
SET @ScriptDesc = 'Script to add Welsh soft content changes'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO