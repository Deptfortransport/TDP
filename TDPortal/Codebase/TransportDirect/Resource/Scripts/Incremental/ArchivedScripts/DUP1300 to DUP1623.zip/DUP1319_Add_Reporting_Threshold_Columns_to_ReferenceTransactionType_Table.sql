-- *************************************************************************************
-- NAME 		: DUP1319_Add_Reporting_Threshold_Columns_to_ReferenceTransactionType_Table.sql
-- DESCRIPTION 		: Add Reporting Threshold Columns to ReferenceTransactionType Table
-- *************************************************************************************
USE [Reporting]
GO

----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('ReferenceTransactionType')
						AND syscolumns.name = 'RTTChannel')
ALTER TABLE ReferenceTransactionType ADD RTTChannel NVARCHAR(50) NULL


GO

----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('ReferenceTransactionType')
						AND syscolumns.name = 'RTTAmberMsDuration')
ALTER TABLE ReferenceTransactionType ADD RTTAmberMsDuration INT NOT NULL DEFAULT 0


GO



----------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM syscolumns 
					INNER JOIN sysobjects
						ON syscolumns.id = sysobjects.id
					WHERE sysobjects.type='U' 
						AND sysobjects.id = object_id('ReferenceTransactionType')
						AND syscolumns.name = 'RTTInjectionFrequency')
ALTER TABLE ReferenceTransactionType ADD RTTInjectionFrequency TINYINT NOT NULL DEFAULT 0


GO

---------------------------------------------------------------------------------------------------
-- Update new columns with known injection parameters


update ReferenceTransactionType
set RTTChannel = 'Journey Planning Sub-System'
where RTTCOde in ('SLA01','SLA02','SLA03')

update ReferenceTransactionType
set RTTChannel = 'Mapping Planning Sub-System'
where RTTCOde in ('SLA04','SLA05')

update ReferenceTransactionType
set RTTChannel = 'Real Time Sub-System'
where RTTCOde in ('SLA06')

update ReferenceTransactionType
set RTTChannel = 'PC User Channel'
where RTTCOde in ('SLA07','SLA08','SLA09','SLA10')

update ReferenceTransactionType
set RTTChannel = 'Mobile User Channel'
where RTTCOde in ('SLA11')

update ReferenceTransactionType
set RTTChannel = 'Web Services User Channel'
where RTTCOde in ('SLA12','SLA13','SLA14')

update ReferenceTransactionType
set RTTInjectionFrequency = 15
where RTTCOde in (
'SLA01','SLA02','SLA03',
'SLA12','SLA13','SLA14')

update ReferenceTransactionType
set RTTInjectionFrequency = 10
where RTTCOde in (
'SLA04','SLA05','KPI01','KPI02','KPI03',
'KPI04','KPI05','KPI06','KPI07','KPI08','KPI09','KPI10'
)


update ReferenceTransactionType
set RTTInjectionFrequency = 5
where RTTCOde in ('SLA06','SLA11')

update ReferenceTransactionType
set RTTInjectionFrequency = 4
where RTTCOde in ('SLA07','SLA08','SLA09','SLA10')

update ReferenceTransactionType
set RTTInjectionFrequency = 15
where RTTCOde in ('SLA01','SLA02','SLA03')

update ReferenceTransactionType
set RTTAmberMsDuration = 4000
where RTTCOde in ('SLA01','SLA02')

update ReferenceTransactionType
set RTTAmberMsDuration = 1000
where RTTCOde in ('SLA03','SLA06')

update ReferenceTransactionType
set RTTAmberMsDuration = 1500
where RTTCOde in ('SLA04','SLA05')

update ReferenceTransactionType
set RTTAmberMsDuration = 8000
where RTTCOde in ('SLA07')


UPDATE dbo.ReferenceTransactionType
SET RTTChannel = 'Direct'
WHERE RTTCode IN ('KPI04', 'KPI06', 'KPI08', 'KPI10', 'KPI11', 'KPI12')

UPDATE dbo.ReferenceTransactionType
SET RTTChannel = 'Portal'
WHERE RTTCode IN ('KPI03', 'KPI05', 'KPI07', 'KPI09')
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
--No Change catalogue in the Reporting Database