-- *************************************************************************************
-- NAME 		: DUP1392_Add_ESS_Partner_For_DirectGov_MIS.sql
-- DESCRIPTION  : Add new EES partner for new direct gov site
-- AUTHOR		: John Frank
-- *************************************************************************************

USE [Reporting]
GO

DELETE FROM [Partner] WHERE HostName = 'DirectGovJPlan'
GO

INSERT INTO [Partner] (PartnerId, HostName, PartnerName, Channel)
VALUES (111, 'DirectGovJPlan', 'DirectGovJPlan', 'EES')
GO
