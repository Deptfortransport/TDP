-- ***********************************************
-- NAME 		: DUP1609_Content_Updates_Del1010_Welsh.sql
-- DESCRIPTION 	: Script to update Content with Welsh translations for Del 10.10
-- AUTHOR		: Mitesh Modi
-- DATE			: 09 Mar 2010
-- ************************************************

USE [Content]
GO

/* ----------------------------------------------------------- */
/* ----------------------- Mapping --------------------------- */

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.Heading.Text', 
'We are sorry, this map is not available without JavaScript.',
'Mae''n ddrwg gennym, nid yw''r map hwn ar gael heb JavaScript.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.Description.Text',
'To view this map please enable JavaScript in your browser.',
'I weld y map hwn galluogwch JavaScript yn eich porwr.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.JourneyMap.Text',
'You can also view the journey results by selecting the details option below.',
'Hefyd gallwch weld canlyniadau''r siwrnai drwy ddewis yr opsiwn manylion isod.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.TravelNewsMap.Text',
'You can also view live travel news by selecting the details option below.',
'Hefyd gallwch weld newyddion teithio byw drwy ddewis yr opsiwn manylion isod.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapControl.JavaScriptDisabled.FindMapResult.Text',
'You can plan a journey by selecting one of the plan a journey options from the menu.',
'Gallwch gynllunio siwrnai drwy ddewis un o''r opsiynau cynllunio siwrnai o''r ddewislen.'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.buttonToggleTravelNewsAndSymbols.TravelNews.Text',
'See travel news',
'Gweler newyddion teithio'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.buttonToggleTravelNewsAndSymbols.PointOfInterest.Text',
'See point of interest',
'Gweler pwynt diddorol'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.labelTravelNews',
'Show travel news for selected date',
'Dangos newyddion teithio ar gyfer dyddiad penodol'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.publicIncidentsVisible',
'Public transport news',
'Newyddion cludiant cyhoeddus'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.roadIncidentsVisible',
'Road transport news',
'Newyddion cludiant ar y ffordd'

EXEC AddtblContent
1, 1, 'langStrings', 'MapLocationIconsSelectControl.buttonShowNews.Text',
'Show news',
'Dangos newyddion'

/* ----------------------------------------------------------- */
/* ---------------- International Planner -------------------- */

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.InternationalPlannerUnavailableKey',
'Transport Direct Extra journey comparison is currently unavailable.',
'Nid yw cyfleuster cymharu siwrneiau Transport Direct Extra ar gael ar hyn o bryd.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.InternationalPlannerJourneyNotPermitted',
'At the moment Transport Direct Extra only supports journey planning between London and a limited number of cities elsewhere in Europe. Please select London as either your origin or destination.',
'At the moment Transport Direct Extra only supports journey planning between London and a limited number of cities elsewhere in Europe. Please select London as either your origin or destination.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.InternationalPlannerModeNotPermitted',
'The selected transport mode is not permitted in Transport Direct Extra.',
'Ni chaniateir y modd cludiant penodol yn Transport Direct Extra.'

EXEC AddtblContent
1, 1, 'langStrings', 'ValidateAndRun.InternationalLocationHasNoNaptan',
'Transport Direct Extra failed to find any valid stations for the locations you selected, please choose a different start location and/or destination.',
'Mae Transport Direct Extra wedi methu dod o hyd i unrhyw orsafoedd rheilffordd dilys ar gyfer y lleoedd a ddewiswyd gennych. Dewiswch fan cychwyn a/neu gyrchfan gwahanol.'

EXEC AddtblContent
1, 1, 'langStrings', 'FindInternationalInput.labelFindPageTitle',
'Transport Direct Extra journey comparison',
'Cyfleuster cymharu siwrneiau Transport Direct Extra'

EXEC AddtblContent
1, 1, 'langStrings', 'FindInternationalInput.AppendPageTitle',
'Transport Direct Extra journey comparison - Compare trains, plane, coach & car | ',
'Cyfleuster cymharu siwrneiau Transport Direct Extra - Cymharu trenau, awyrennau, bysiau moethus a cheir |'

EXEC AddtblContent
1, 1, 'langStrings', 'FindInternationalInput.clientLink.BookmarkTitle',
'Transport Direct Extra journey comparison',
'Cyfleuster cymharu siwrneiau Transport Direct Extra'

--EXEC AddtblContent
--1, 1, 'langStrings', 'FindPlaceDropDownControl.listInternationalInstructionAmbiguous',
--'Please select a city',
--'Please select a city'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyDetailControl.planJourneyLink.Text',
'To plan your journey to {0} click here',
'I gynllunio eich siwrnai i {0} cliciwch yma
'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyDetailControl.location.city.prefix',
'Central ',
'Canol '

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyChangeSearchControl.buttonReturnJourney.Text',
'Plan a Return',
'Cynllunio Taith yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsCompareControl.showJourneyHyperlink.ShowGraphical.Text',
'Show journey details',
'Dangos manylion y siwrnai'

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelInternationalFootnote1.Text',
'All journey times include an estimate of city centre to airport/station transfer time, to see the details select �more�.',
'Mae holl amseroedd y siwrneiau yn cynnwys amcangyfrif o amser trosglwyddo o ganol y ddinas i''r maes awyr/gorsaf. Dewiswch fwy i weld y manylion.'

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelInternationalReturnFootnoteLine1.Text',
'You can plan a return for this journey by using the return button above, please use printer friendly to retain details of this journey. ',
'Gallwch gynllunio taith yn �l ar gyfer y siwrnai hon drwy ddefnyddio''r botwm ''taith yn �l'' uchod, defnyddiwch y dull argraffu-gyfeillgar i gadw manylion y siwrnai hon. '

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelInternationalFootnote2.Text',
'Service times include check-in and an allowance for baggage reclaim.',
'Mae amseroedd y gwasanaeth yn cynnwys amser cofrestru ac amser ychwanegol ar gyfer adfer bagiau.'

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelInternationalTransferFootnoteLine1.Text',
'Using the link to plan the detail of the transfer within GB will cause details of the Transport Direct Extra journey to be lost, please use the printer friendly page to retain details of this journey.',
'Bydd defnyddio''r cyswllt i gynllunio manylion y daith drosglwyddo o fewn Prydain yn golygu y bydd manylion taith Transport Direct Extra yn cael eu colli. Defnyddiwch ddull argraffu-gyfeillgar i gadw manylion y siwrnai hon.'

EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelJourneyTimesNote1.Text',
'All times quoted are local.',
'All times quoted are local.'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyDetailControl.DoortoDoorLink.Javascript.Warning',
'<div class="popupHeader">
  <img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation.gif" alt="Warning" title="Warning"/>
  <span class="popupheaderText">Warning</span>
</div>
<div class="popupContent">
  <p class="bold">When planning your transfer Transport Direct will not retain details of your European Transport Direct Extra journey.</p>
  <p>If you wish to continue please select next, if not then please select cancel.<p>
  <p>You can retain details of your Transport Direct Extra journey for reference by clicking on �printer friendly� before planning your transfer.</p>
  <br/>
</div>',
'<div class="popupHeader">
  <img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation.gif" alt="Rhybudd" title="Rhybudd"/>
  <span class="popupheaderText">Rhybudd</span>
</div>
<div class="popupContent">
  <p class="bold">When planning your transfer Transport Direct will not retain details of your European Transport Direct Extra journey.</p>
  <p>Os hoffech fynd yn eich blaen dewiswch �nesaf�, os na hoffech barhau dewiswch �canslo�.<p>
  <p>You can retain details of your Transport Direct Extra journey for reference by clicking on �printer friendly� before planning your transfer.</p>
  <br/>
</div>'


EXEC AddtblContent
1, 72, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindInternationalInput',
'<div class="PageSoftContentContainer">
  <div class="PageSoftContent">
    <p>With the Transport Direct Extra Planner you can compare coach, plane, train and car journeys between London and a number of cities elsewhere in Europe. Please select your origin and destination from the drop down lists above.</p>
    <p>You can plan journeys for the current calendar month and the next two months.</p>
  </div>
</div>',
'<div class="PageSoftContentContainer">
  <div class="PageSoftContent">
    <p>With the Transport Direct Extra Planner you can compare coach, plane, train and car journeys between London and a number of cities elsewhere in Europe. Please select your origin and destination from the drop down lists above.</p>
    <p>Gallwch cynllunio siwrneiau ar gyfer y mis calendr cyfredol a''r ddau fis nesaf.</p>
  </div>
</div>'


--EXEC AddtblContent
--1, 1, 'langStrings', 'JourneyDetailControl.planJourneyLink.Text',
--'To plan your journey to {0} click here',
--'To plan your journey to {0} click here'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyDetailsControl.imageTransferUrl',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/transfer.gif',
'/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/transfer.gif'


-- Update the opens new window text
EXEC AddtblContent
1, 1, 'langStrings', 'ResultsFootnotes.labelAccessibilityFootnoteLine2.LinkText',
'your accessibility rights when you fly <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />',
'hawliau hygyrchedd pan fyddwch yn hedfan <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)" title="(yn agor ffenestr newydd)" />'


EXEC AddtblContent
1, 1, 'langStrings', 'JourneyOverview.labelInstructions.Text',
'To get journey details for each mode please select the more button. You can return to this summary table by pressing the back button.',
'I gael manylion siwrnai pob dull dewiswch y botwm mwy. You can return to this summary table by pressing the back button.'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1609
SET @ScriptDesc = 'Script to update welsh content for Del 10.10'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO