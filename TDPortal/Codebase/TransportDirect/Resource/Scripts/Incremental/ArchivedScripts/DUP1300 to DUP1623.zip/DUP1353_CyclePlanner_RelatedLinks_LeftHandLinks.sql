-- ***********************************************
-- NAME 			: DUP1353_CyclePlanner_RelatedLinks_LeftHandLinks.sql
-- DESCRIPTION 		: Script to add the Related links to the Find Cycle Input page
-- AUTHOR			: Mitesh Modi
-- DATE				: 07 Jul 2009
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- BEGIN TIDY UP
-- Remove any previously added Related Links that we added for the Cycle planner

DECLARE @ContextId INT

-- Remove any previously added Related Links that were added for the Cycle planner
IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')

	DELETE 
--    SELECT *
	FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END

GO


-- Delete the base links previously added to Suggestion Links for the Related links on the Find a Cycle input page 
-- Ensures the correct one is used for the RelatedLinksContextFindCycleInput context when added
DELETE
--SELECT *
FROM    SuggestionLink       -- Get all suggestion links which are for the Related links category
WHERE   (LinkCategoryId =    -- and are for the cycle related links resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Related links'))
AND     (ResourceNameId IN ( 
                            (SELECT     ResourceNameID
                             FROM       ResourceName
                             WHERE      ResourceName LIKE 'CyclePlanner.%'))) -- All the cycle link Resources start with this

GO

-- END TIDY UP
--------------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- Set up the Related Links for Cycle Planner input page

DECLARE @ContextName VARCHAR(50)
DECLARE @ThemeId INT

SET @ContextName = 'RelatedLinksContextFindCycleInput'
SET @ThemeId = 1


-- Add our new context for cycle input page related links
EXEC AddContext
    
    @ContextName,                            						-- Context
    'Related Link Context - Suggestions for Find Cycle Input Page'  -- Context description


-- Add the Related Links heading root url for our context
EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


-- Add the actual links. ensure all our link names start with "CyclePlanner."
EXEC AddExternalSuggestionLink

	'CyclePlanner.CyclingEngland',					                   -- ID for ExternalLink table
	'http://www.cyclingengland.co.uk/',      	                       -- Full external link URL
	'http://www.cyclingengland.co.uk/',                                -- Full test external link URL
	'Cycle planner - Cycling England url',                             -- Description of external link. Ensure this is a unique external link description   
	'CyclePlanner.CyclingEngland',                                     -- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Find out about cycling in England (opens new window)',            -- English display text. Populate only if adding new ResourceName or updating existing display text
	'cy Find out about cycling in England (yn agor ffenestr newydd)',  -- Welsh display text. Populate only if adding new ResourceName or updating existing display text   
	'Related links',                                                   -- Category Name (LinkCategory), use 'General' if not a left hand navigation link, use 'Related links' for a related link
	1660,						                                       -- Priority must be unique for the selected CategoryName this link is for
	0,                                                                 -- Set to 0 if to be used as a Suggestion/Related Link
	0,                                                                 -- Set to 1 if it is a second level Root link
	@ContextName,                                                      -- Context Name (Context), populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',                                                                -- Populate only if adding a new ContextName, or updating description
	@ThemeId                                                           -- Theme this link is added for, use 1 as default


EXEC AddExternalSuggestionLink

	'CyclePlanner.CyclingScotland',					
	'http://www.cyclingscotland.org/',      	
	'http://www.cyclingscotland.org/', 		
	'Cycle planner - Cycling Scotland url',         
	'CyclePlanner.CyclingScotland',                 
	'Find out about cycling in Scotland (opens new window)',		        
	'cy Find out about cycling in Scotland (yn agor ffenestr newydd)',
	'Related links',
	1670,
	0,
	0,
	@ContextName,
	'',
	@ThemeId


EXEC AddExternalSuggestionLink

	'CyclePlanner.CyclingWales',					
	'http://wales.gov.uk/topics/transport/IntegratedTransport/walkingcycling/?lang=en',      	
	'http://wales.gov.uk/topics/transport/IntegratedTransport/walkingcycling/?lang=en', 		
	'Cycle planner - Cycling Wales url',         
	'CyclePlanner.CyclingWales',                 
	'Find out about cycling in Wales (opens new window)',		        
	'cy Find out about cycling in Wales (yn agor ffenestr newydd)',    
	'Related links',
	1680,
	0,
	0,
	@ContextName,
	'',
	@ThemeId


EXEC AddExternalSuggestionLink

	'CyclePlanner.NationalCycleRoutes',					
	'http://www.sustrans.org.uk/',      	
	'http://www.sustrans.org.uk/', 		
	'Cycle planner - National Cycle Routes url',         
	'CyclePlanner.NationalCycleRoutes',                 
	'Find out about National cycle routes (opens new window)',		        
	'cy Find out about National cycle routes (yn agor ffenestr newydd)',    
	'Related links',
	1690,
	0,
	0,
	@ContextName,
	'',
	@ThemeId


EXEC AddExternalSuggestionLink

	'CyclePlanner.CycleScheme',					
	'http://www.cyclescheme.co.uk/',      	
	'http://www.cyclescheme.co.uk/', 		
	'Cycle planner - Cycle schemes url',         
	'CyclePlanner.CycleScheme',                 
	'Find out about Bike to work schemes (opens new window)',		        
	'cy Find out about Bike to work schemes (yn agor ffenestr newydd)',    
	'Related links',
	1700,
	0,
	0,
	@ContextName,
	'',
	@ThemeId


EXEC AddExternalSuggestionLink

	'CyclePlanner.CycleSafety',					
	'http://www.dft.gov.uk/think/focusareas/children/?whoareyou_id=&page=Overview',      	
	'http://www.dft.gov.uk/think/focusareas/children/?whoareyou_id=&page=Overview', 		
	'Cycle planner - Cycle safety url',         
	'CyclePlanner.CycleSafety',                 
	'Find out about cycle safety (opens new window)',		        
	'cy Find out about cycle safety (yn agor ffenestr newydd)',    
	'Related links',
	1710,
	0,
	0,
	@ContextName,
	'',
	@ThemeId


EXEC AddExternalSuggestionLink

	'CyclePlanner.CycleSchool',					
	'http://www.bikeforall.net/content/cycling_to_school.php',      	
	'http://www.bikeforall.net/content/cycling_to_school.php', 		
	'Cycle planner - Cycle to school url',         
	'CyclePlanner.CycleSchool',                 
	'Find out about cycling to school (opens new window)',		        
	'cy Find out about cycling to school (yn agor ffenestr newydd)',    
	'Related links',
	1720,
	0,
	0,
	@ContextName,
	'',
	@ThemeId


EXEC AddExternalSuggestionLink

	'CyclePlanner.GPXDownload',
	'http://www.topografix.com/gpx.asp',
	'http://www.topografix.com/gpx.asp',
	'Cycle planner - GPX download url',
	'CyclePlanner.GPXDownload',
	'Find out about GPX downloads (opens new window)',
	'cy Find out about GPX downloads (yn agor ffenestr newydd)',
	'Related links',
	1730,
	0,
	0,
	@ContextName,
	'',
	@ThemeId


EXEC AddExternalSuggestionLink

	'CyclePlanner.Parking',					
	'http://www.dft.gov.uk/pgr/roads/tpm/tal/cyclefacilities/keyelementsofcycleparkingpro4085',      	
	'http://www.dft.gov.uk/pgr/roads/tpm/tal/cyclefacilities/keyelementsofcycleparkingpro4085', 		
	'Cycle planner - Cycle parking url',         
	'CyclePlanner.Parking',                 
	'Find out about cycle parking (opens new window)',		        
	'cy Find out about cycle parking (yn agor ffenestr newydd)',    
	'Related links',
	1740,
	0,
	0,
	@ContextName,
	'',
	@ThemeId




---------------------------------------------------------
-- VisitBritain
SET @ThemeId = 2

EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingEngland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingScotland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingWales',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.NationalCycleRoutes',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleScheme',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSafety',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSchool',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.GPXDownload',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.Parking',
	'Related links',
	@ContextName,
	@ThemeId



---------------------------------------------------------
-- BBC
SET @ThemeId = 3

EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingEngland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingScotland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingWales',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.NationalCycleRoutes',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleScheme',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSafety',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSchool',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.GPXDownload',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.Parking',
	'Related links',
	@ContextName,
	@ThemeId



---------------------------------------------------------
-- DirectGov
SET @ThemeId = 5

EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingEngland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingScotland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingWales',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.NationalCycleRoutes',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleScheme',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSafety',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSchool',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.GPXDownload',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.Parking',
	'Related links',
	@ContextName,
	@ThemeId



---------------------------------------------------------
-- BusinessLink
SET @ThemeId = 6

EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingEngland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingScotland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingWales',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.NationalCycleRoutes',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleScheme',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSafety',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSchool',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.GPXDownload',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.Parking',
	'Related links',
	@ContextName,
	@ThemeId



---------------------------------------------------------
-- BusinessGateway
SET @ThemeId = 7

EXEC AddContextSuggestionLink

	'RelatedLinks',		-- Resource name
	'Related Links',	-- Link category
	@ContextName,		-- Context
	@ThemeId			-- Theme


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingEngland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingScotland',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CyclingWales',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.NationalCycleRoutes',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleScheme',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSafety',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.CycleSchool',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.GPXDownload',
	'Related links',
	@ContextName,
	@ThemeId


EXEC AddContextSuggestionLink

	'CyclePlanner.Parking',
	'Related links',
	@ContextName,
	@ThemeId


GO

-- END
--------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1353
SET @ScriptDesc = 'Cycle Planner - Related links left navigation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO