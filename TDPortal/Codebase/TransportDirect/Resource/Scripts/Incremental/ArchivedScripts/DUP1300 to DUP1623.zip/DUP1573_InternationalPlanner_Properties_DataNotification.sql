-- ***********************************************
-- NAME 		: DUP1573_InternationalPlanner_Properties_DataNotification.sql
-- DESCRIPTION 	: Add InternationalPlanner data notification to properties table
-- AUTHOR		: Mitesh Modi
-- DATE			: 08 Feb 2010
-- ************************************************

USE [PermanentPortal]
GO

---------------------------------------------------
--insert into properties table
IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.InternationalPlanner.Database')
BEGIN
    INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
    VALUES ('DataServices.DataNotification.InternationalPlanner.Database', 'InternationalDataDB', '<DEFAULT>', '<DEFAULT>', 0, 1)
END


IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.InternationalPlanner.Tables')
BEGIN
    INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
    VALUES ('DataServices.DataNotification.InternationalPlanner.Tables', 
    'Country,CountryJourney,InterchangeTime,InternationalCity,InternationalCityStop,InternationalStop,ScheduleAir,ScheduleCar,ScheduleCoach,ScheduleRail,ScheduleIntermediateCoach,ScheduleIntermediateRail', 
    '<DEFAULT>', '<DEFAULT>', 0, 1)
END





---------------------------------------------------
-- update the data notification monitoring list to also check for InternationalPlanner
DECLARE @DataNotificationGroups VARCHAR(500),
		@AID VARCHAR(20),
		@GID VARCHAR(20)

-- added for <DEFAULT>, TDRemotingHost

SET @AID = '<DEFAULT>'
SET @GID = '<DEFAULT>'

SET @DataNotificationGroups = ( select pValue from properties 
                            where pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)

IF EXISTS (select top 1 * from properties where pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the InternationalPlanner multiple times if the script is run more than once
    IF NOT EXISTS ( select top 1 * from properties 
                    where pvalue like '%InternationalPlanner%' and pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @DataNotificationGroups + ',InternationalPlanner'
    	where pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1
    END
END



SET @AID = 'TDRemotingHost'
SET @GID = 'TDRemotingHost'

SET @DataNotificationGroups = ( select pValue from properties 
                            where pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)

IF EXISTS (select top 1 * from properties where pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the InternationalPlanner multiple times if the script is run more than once
    IF NOT EXISTS ( select top 1 * from properties 
                    where pvalue like '%InternationalPlanner%' and pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @DataNotificationGroups + ',InternationalPlanner'
    	where pName = 'DataServices.DataNotification.Groups' and AID = @AID and GID = @GID and PartnerId = 0 and ThemeId = 1
    END
END


GO




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1573
SET @ScriptDesc = 'Add InternationalPlanner data notification to properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------