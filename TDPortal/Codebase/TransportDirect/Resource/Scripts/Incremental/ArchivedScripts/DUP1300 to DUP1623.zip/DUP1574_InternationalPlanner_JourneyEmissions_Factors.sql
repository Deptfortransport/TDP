-- ***********************************************
-- NAME 		: DUP1574_InternationalPlanner_JourneyEmissions_Factors.sql
-- DESCRIPTION 	: Script to add journey emissions factors for international planner
-- AUTHOR		: Amit Patel
-- DATE			: 26 Jan 2010
-- ************************************************

USE [PermanentPortal]
GO

-- Air
IF NOT EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE FactorType = 'AirIntl')
BEGIN
	INSERT INTO JourneyEmissionsFactor VALUES ('AirIntl', 982)
END
ELSE
BEGIN
	UPDATE JourneyEmissionsFactor SET FactorValue = 982 WHERE FactorType = 'AirIntl'
END

-- Coach
IF NOT EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE FactorType = 'CoachIntl')
BEGIN
	INSERT INTO JourneyEmissionsFactor VALUES ('CoachIntl', 400)
END
ELSE
BEGIN
	UPDATE JourneyEmissionsFactor SET FactorValue = 400 WHERE FactorType = 'CoachIntl'
END

-- Rail
IF NOT EXISTS (SELECT * FROM JourneyEmissionsFactor WHERE FactorType = 'RailIntl')
BEGIN
	INSERT INTO JourneyEmissionsFactor VALUES ('RailIntl', 110)
END
ELSE
BEGIN
	UPDATE JourneyEmissionsFactor SET FactorValue = 110 WHERE FactorType = 'RailIntl'
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1574
SET @ScriptDesc = 'Add journey emissions factors for international planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO