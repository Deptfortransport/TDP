-- ***********************************************
-- NAME 			: DUP1472_BusinessLinks_Content.sql
-- DESCRIPTION 		: Script to add content for cycle planner business link templates
-- AUTHOR			: Parvez Ghumra
-- DATE				: 14 Oct 2009
-- ***********************************************

USE [Content]
GO

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.Template6Radio.Text', 'Starting postcode only', 'C�d post dechreuol yn unig'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.Template6Radio.AltText', 'This template features a single text entry field for typing a postcode to start the journey from, and a "Go" button. It also features some instructions.', 'Mae''r templad hwn yn cynnwys un maes cofnodi testun ar gyfer teipio c�d post i ddechrau''r siwrnai ohono, a botwm "Ewch". Mae yma rai cyfarwyddiadau hefyd.'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.Template7Radio.Text', 'Starting postcode plus date and time', 'C�d post dechreuol a dyddiad ac amser'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.Template7Radio.AltText', 'This template features several fields. There is not only a text entry field for typing a postcode to start the journey from, but also fields to select the date and time of travel. It also features some instructions and a "Go" button.', 'Mae''r templad hwn yn cynnwys nifer o feysydd.  Ceir nid yn unig faes cofnodi testun i deipio c�d post i ddechrau''r siwrnai ohoni, ond hefyd feysydd i ddewis dyddiad ac amser y teithio. Mae yma rai cyfarwyddiadau hefyd a botwm "Ewch".'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.Template8Radio.Text', 'Starting postcode plus from/to selection', 'C�d post y cychwyn plws detholiad o/i'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.Template8Radio.AltText', 'This template features a single text entry field for typing a postcode and a drop down list to select whether the journey will be from or to that postcode. The template also contains some instructions and a "Go" button.', 'Mae''r templad hwn yn cynnwys maes i roi un cofnod testun ar gyfer teipio c�d post a rhestr a ollyngir i lawr i ddewis a fydd y siwrnai o neu i''r c�d post hwnnw. Mae''r templad hefyd yn cynnwys rhai cyfarwyddiadau a botwm "Ewch".'

EXEC AddtblContent 
1, 1, 'Tools', 'BusinessLinks.Template9Radio.Text', 'Starting postcode, from/to selection plus date and time', 'C�d post y cychwyn, detholiad o/i plws y dyddiad a''r amser'

EXEC AddtblContent
1, 1, 'Tools', 'BusinessLinks.Template9Radio.AltText', 'This template features several fields. There is a single text entry field for typing a postcode. There is a drop down list to select whether the journey will be from or to that postcode. There are drop down lists for selecting the date and time of travel. The template also contains some instructions and a "Go" button.', 'Mae''r templad hwn yn cynnwys nifer o feysydd. Ceir maes i roi un cofnod testun ar gyfer teipio c�d post. Ceir rhestr a ollyngir i lawr i ddewis a fydd y siwrnai o neu i''r c�d post hwnnw. Ceir rhestrau a ollyngir i lawr ar gyfer dewis dyddiad ac amser y teithio. Mae''r templad hefyd yn cynnwys rhai cyfarwyddiadau a botwm "Ewch".'
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1472
SET @ScriptDesc = 'Script to add content for cycle planner business link templates'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO