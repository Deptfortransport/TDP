-- ***********************************************
-- NAME 		: DUP1514_Mapping_Logging_Properties.sql
-- DESCRIPTION 	: Script to add mapping api logging properties
-- AUTHOR		: Amit Patel
-- DATE			: 12 Nov 2009
-- ************************************************

USE [PermanentPortal]
GO

-- ********************* IMPORTANT ******************************
-- Please update the publisher locations for the property 'Logging.Event.Custom.MapAPI.Publishers'
-- The publisher should be Queue1 instead of File1
-- **************************************************************


---------------------------------------------------------------------
-- LOGGING PROPERTIES

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom.Trace' 
	and AID = 'TDRemotingHost'
	and GID = 'UserPortal'
	and PartnerId = 0
	and ThemeId = 1)
BEGIN
	insert into properties values ('Logging.Event.Custom.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.MapAPI.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.MapAPI.Assembly' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.MapAPI.Assembly', 'td.reportdataprovider.tdpcustomevents', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Assembly', 'td.reportdataprovider.tdpcustomevents', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Assembly', 'td.reportdataprovider.tdpcustomevents', 'EventReceiverJP', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.MapAPI.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.MapAPI.Name' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.MapAPI.Name', 'MapAPIEvent', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Name', 'MapAPIEvent', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Name', 'MapAPIEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Name', 'MapAPIEvent', 'EventReceiverJP', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.MapAPI.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.MapAPI.Publishers' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.MapAPI.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Publishers', 'FILE1', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Publishers', 'TDPDB', 'EventReceiverJP', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.MapAPI.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.MapAPI.Trace' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.MapAPI.Trace', 'On', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Trace', 'On', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.MapAPI.Trace', 'On', 'EventReceiverJP', 'ReportDataProvider', 0, 1)
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and pValue LIKE '%MapAPI%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' MapAPI'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EventReceiver')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EventReceiver'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverJP' and pValue LIKE '%MapAPI%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' MapAPI'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EventReceiverJP')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EventReceiverJP'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and pValue LIKE '%MapAPI%')
BEGIN
	UPDATE properties
	SET pValue =  
		(SELECT pValue + ' MapAPI'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'EventReceiverGroup')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'EventReceiverGroup'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and pValue LIKE '%MapAPI%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' MapAPI'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'TDRemotingHost')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'TDRemotingHost'
END

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and pValue LIKE '%MapAPI%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' MapAPI'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'Web')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'Web'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1514
SET @ScriptDesc = 'Script to add mapping api logging properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO