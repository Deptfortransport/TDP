-- ***********************************************
-- NAME 			: DUP1340_CyclePlanner_FAQ_LinkSetup_Navigation.sql
-- DESCRIPTION 		: Script to add the link for the Cycle FAQ
-- AUTHOR			: Mitesh Modi
-- DATE				: 06 Jul 2009
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- BEGIN TIDY UP
-- Ensure we have a clean Cycle links environment, there may be some residual leftovers from when the links were originally added


DECLARE @ContextId INT

-- Remove any previously added Related Links that were added for the Cycle planner
IF EXISTS (SELECT * FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')
BEGIN
	SET @ContextId = (SELECT ContextId FROM Context WHERE [Name] = 'RelatedLinksContextFindCycleInput')

	DELETE 
--    SELECT *
	FROM	ContextSuggestionLink
	WHERE	ContextId = @ContextId
END

GO


-- Remove any previously added link to Find Cycle Input page that were added, these should only be there for Category: Plan a journey
DELETE     
--SELECT *
FROM    ContextSuggestionLink
WHERE   (SuggestionLinkId IN
                            (SELECT     SuggestionLinkId    -- Get all suggestion links which are for the Plan a journey category
                             FROM          SuggestionLink   -- and use our the FindACycle resource (this is the Find Cycle Input page)
                             WHERE      (LinkCategoryId =
                                             (SELECT     LinkCategoryId
                                              FROM       LinkCategory
                                              WHERE      [name] = 'Plan a journey'))
                             AND (ResourceNameId =
                                      (SELECT     ResourceNameID
                                       FROM       ResourceName
                                       WHERE      ResourceName = 'FindACycle')))) 

AND     (ThemeId IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10))    -- ALL THEMES
AND     (ContextId IN    -- And only for the Homepage or Plan a journey mini homepage
            (SELECT     ContextId
             FROM       Context
             WHERE      [Name] = 'HomePageMenu' OR [Name] = 'HomePageMenuPlanAJourney'))


-- Remove any previously added link to Cycle FAQ page that were added, these should only be there for Category: FAQ
DELETE     
--SELECT *
FROM    ContextSuggestionLink
WHERE   (SuggestionLinkId IN
                            (SELECT     SuggestionLinkId    -- Get all suggestion links which are for the FAQ category
                             FROM          SuggestionLink   -- and use our the FAQ.CyclePlanning resource (this is the Cycle FAQ page)
                             WHERE      (LinkCategoryId =
                                             (SELECT     LinkCategoryId
                                              FROM       LinkCategory
                                              WHERE      [name] = 'FAQ'))
                             AND (ResourceNameId =
                                      (SELECT     ResourceNameID
                                       FROM       ResourceName
                                       WHERE      ResourceName = 'FAQ.CyclePlanning')))) 

AND     (ThemeId IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10))    -- ALL THEMES
AND     (ContextId IN    -- And only for the FAQMenu
            (SELECT     ContextId
             FROM       Context
             WHERE      [Name] = 'FAQMenu'))




-- Delete the base link previously added to Suggestion Links for Find a Cycle input. 
-- This ensures the correct one is used for the Homepage context, and the Plan a Journey homepage context when added
DELETE
--SELECT *
FROM    SuggestionLink       -- Get all suggestion links which are for the Plan a journey category
WHERE   (LinkCategoryId =    -- and use our FindACycle (Input page) resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'Plan a journey')) 
AND     (ResourceNameId = 
                            (SELECT     ResourceNameID
                             FROM       ResourceName
                             WHERE      ResourceName = 'FindACycle'))


-- Delete the base link previously added to Suggestion Links for the Cycle FAQ page
-- This ensures the correct one is used for the FAQMenu context when added
DELETE
--SELECT *
FROM    SuggestionLink       -- Get all suggestion links which are for the FAQ category
WHERE   (LinkCategoryId =    -- and use our FAQ.CyclePlanning (FAQ page) resource 
                            (SELECT     LinkCategoryId
                             FROM          LinkCategory
                             WHERE      [name] = 'FAQ')) 
AND     (ResourceNameId = 
                            (SELECT     ResourceNameID
                             FROM       ResourceName
                             WHERE      ResourceName = 'FAQ.CyclePlanning'))


GO

-- END TIDY UP
--------------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- BEGIN Insert the Cycle FAQ link

-- This adds the actual link, and assigns it to the FAQ category, and to the FAQ pages menu for Transport Direct default theme
EXEC AddInternalSuggestionLink

	'Help/HelpCycle.aspx',      	-- Relative internal link URL
	'Help on cycle planning',       -- Description of internal link. Ensure this is a unique internal link description
	'FAQ.CyclePlanning',			-- Used to bind the Display text to the URL. Ensure value is unique per Link, or use existing ResourceName with caution
	'Cycle planning',		        -- English display text. Populate only if adding new ResourceName or updating existing display text
	'Cynllunio Beicio',		    -- Welsh display text. Populate only if adding new ResourceName or updating existing display text	
	'FAQ',				            -- Category Name (LinkCategory) -- Use 'General' if not a left hand navigation link
	8160,						    -- Priority must be unique for the selected CategoryName this link is for
	0,						        -- Set to 0 if to be used as a Suggestion/Related Link
	0,						        -- Set to 1 if it is a second level Root link
	'FAQMenu',	                    -- Context Name (Context) -- Populate only if adding link to a Context. Used for the grouping of Suggestion/Related links for a page, e.g 'FindTrainInput'
	'',						        -- Populate only if adding a new ContextName, or updating description
	1						        -- Theme this link is added for, use 1 as default

GO

-- Add the new FAQ link for the Whitelabel partner sites

-- VisitBritain
EXEC AddContextSuggestionLink

	'FAQ.CyclePlanning',	-- Resource Name (ResourceName) ResourceNameID 121
	'FAQ',					-- Category Name (LinkCategory)
	'FAQMenu',				-- Context Name (Context)
	2						-- Theme

-- BBC
EXEC AddContextSuggestionLink

	'FAQ.CyclePlanning',	-- Resource Name (ResourceName) ResourceNameID 121
	'FAQ',					-- Category Name (LinkCategory)
	'FAQMenu',				-- Context Name (Context)
	3						-- Theme

-- DirecGov
EXEC AddContextSuggestionLink

	'FAQ.CyclePlanning',	-- Resource Name (ResourceName) ResourceNameID 121
	'FAQ',					-- Category Name (LinkCategory)
	'FAQMenu',				-- Context Name (Context)
	5						-- Theme

-- BusinessLink
EXEC AddContextSuggestionLink

	'FAQ.CyclePlanning',	-- Resource Name (ResourceName) ResourceNameID 121
	'FAQ',					-- Category Name (LinkCategory)
	'FAQMenu',				-- Context Name (Context)
	6						-- Theme

-- BusinessGateway
EXEC AddContextSuggestionLink

	'FAQ.CyclePlanning',	-- Resource Name (ResourceName) ResourceNameID 121
	'FAQ',					-- Category Name (LinkCategory)
	'FAQMenu',				-- Context Name (Context)
    7						-- Theme

-- London2012
EXEC AddContextSuggestionLink

	'FAQ.CyclePlanning',	-- Resource Name (ResourceName) ResourceNameID 121
	'FAQ',					-- Category Name (LinkCategory)
	'FAQMenu',				-- Context Name (Context)
	8						-- Theme

GO

-- END
--------------------------------------------------------------------------------------------------------------------------------




----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1340
SET @ScriptDesc = 'Cycle Planner - FAQ left navigation link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO