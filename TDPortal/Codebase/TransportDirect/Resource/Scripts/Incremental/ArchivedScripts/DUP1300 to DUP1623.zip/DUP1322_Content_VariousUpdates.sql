-- ************************************************************
-- NAME 		: DUP1322_Content_VariousUpdates.sql
-- DESCRIPTION 	: Content updates (various and miscellaneous
-- AUTHOR		: mmodi 
-- ************************************************************


USE [Content]
GO


-- Correct welsh Next type
EXEC AddtblContent
1, 1,'langStrings','JourneyPlannerLocationMap.labelFindMapMessage'
,'Select/type in a location to show on the map. Then click "Next".'
,'Dewiswch/teipiwch leoliad i''w ddangos ar y map. Yna cliciwch "Nesa".'


-- Correct CO2 emissions title typo
EXEC AddtblContent
1, 1,'langStrings','JourneyEmissionsCompare.Title'
,'CO2 emissions calculator'
,'CO2 emissions calculator'


-- Welsh updates
EXEC AddtblContent
1, 1,'langStrings','FindCarParkInput.AppendPageTitle'
,'Find a car park | '
,'Darganfod maes parcio | '

GO
-------------------------------------------------------------------------
-- CHANGE LOG
-------------------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1322
SET @ScriptDesc = 'Content various updates'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
----------------------------------------------------------------------------