-- ***********************************************
-- NAME 		: DUP1515_CyclePlanner_Content_Update.sql
-- DESCRIPTION 	: Script to remove the opens new window text on the Cycle details page
-- AUTHOR		: Mitesh Modi
-- DATE			: 18 Nov 2009
-- ************************************************

USE [Content]
GO

-- Remove opens new window text
EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleAllDetailsControl.hyperlinkCycleEngland.Text', 
'To find Cycling England Bikeability training near you select this link',
'I ddod o hyd i hyfforddiant Bikeability Cycling England yn agos i chi dewiswch y ddolen hon'

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.hyperlinkDownload.Text', 
'Download a GPX file of your route', 
'Llwythwch ffeil GPX o''ch llwybr i lawr'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1515
SET @ScriptDesc = 'Cycle planner content update - opens new window'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO