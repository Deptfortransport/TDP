-- ***********************************************
-- NAME 			: DUP1363_ExposedServices_CarJourneyPlanner_Setup.sql
-- DESCRIPTION 		: Script to setup the Car Journey Planner Enhanced Exposed Service
-- AUTHOR			: Mitesh Modi
-- DATE				: 16 Jul 2009
-- ***********************************************

USE [PermanentPortal]
GO

DECLARE @EESTID INT
DECLARE @ExposedServiceName VARCHAR(100)
DECLARE @PartnerId INT
DECLARE @PartnerName VARCHAR(100)
DECLARE @PartnerPassword VARCHAR(250)

SET @ExposedServiceName = 'TransportDirect_EnhancedExposedServices_CarJourneyPlannerSynchronous_V1'
SET @PartnerId = 101
SET @PartnerName = 'EnhancedExposedWebServiceTest'
SET @PartnerPassword = 'uwV6Rgwmsf8WDC5Zh2P7szt91g0OCqFzT74dkFJpSP3jZht1K8zOIeO7IkoU0DrgnLn2evkRQGp9pT2U2jjIKg=='

-- Add the new Car Journey Planner exposed service
IF NOT EXISTS (SELECT * FROM [dbo].[EnhancedExposedServicesType] WHERE EESTType  = @ExposedServiceName)
BEGIN
    INSERT INTO EnhancedExposedServicesType (EESTType, EESTDescription)
    VALUES (@ExposedServiceName, @ExposedServiceName)
END

-- Get the ID for the exposed service
SET @EESTID = (SELECT EESTID FROM EnhancedExposedServicesType WHERE EESTType = @ExposedServiceName)


-- Check for our Partner and add if not there 
IF NOT EXISTS (SELECT * FROM [dbo].[Partner] WHERE PartnerId = @PartnerId)
BEGIN
	INSERT INTO Partner(PartnerId, HostName, PartnerName, Channel, PartnerPassword)
	VALUES (@PartnerId, @PartnerName, @PartnerName, @PartnerName, @PartnerPassword)
END 


-- Allow the Partner to use the new exposed service
IF EXISTS (SELECT * FROM [dbo].[EnhancedExposedServicesType] WHERE EESTType  = @ExposedServiceName)
BEGIN

    IF NOT EXISTS (SELECT * FROM [dbo].[PartnerAllowedServices] WHERE PartnerId  = @PartnerId AND EESTID = @EESTID)
    BEGIN
        INSERT INTO PartnerAllowedServices (PartnerId,EESTID)
        VALUES (@PartnerId, @EESTID)
    END

END



-- Add partner to Reporting table
USE [Reporting]

IF NOT EXISTS (SELECT * FROM [dbo].[Partner] WHERE PartnerId  = @PartnerId)
BEGIN
	INSERT INTO Partner(PartnerId, HostName, PartnerName, Channel)
	VALUES (@PartnerId, @PartnerName, @PartnerName, @PartnerName)
END 

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1363
SET @ScriptDesc = 'Exposed Services - Car Journey Planner setup'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

