-- ***********************************************
-- NAME 			: DUP1457_update_Resource_link_Opens_in_new_window_icon.sql
-- DESCRIPTION 			: Script to update Opens in new window
-- DESCRIPTION 			: Replace "opens in new window" with an icon
-- AUTHOR			: Amit Patel
-- DATE				: 09 Oct 2009
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Resource
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @FindText as varchar(1000)
DECLARE @ReplaceText as varchar(1000)
SET @FindText = '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)">'
SET @ReplaceText = '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" />'
UPDATE dbo.Resource
   SET Text = REPLACE([Text], @FindText ,@ReplaceText )
  WHERE [Text] LIKE '%'+ @FindText + '%'

SET @FindText = '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)">'
SET @ReplaceText = '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)" />'
UPDATE dbo.Resource
   SET Text = REPLACE([Text], @FindText ,@ReplaceText )
  WHERE [Text] LIKE '%'+ @FindText + '%'

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1457
SET @ScriptDesc = 'Script to replace Opens in new window with an icon'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO