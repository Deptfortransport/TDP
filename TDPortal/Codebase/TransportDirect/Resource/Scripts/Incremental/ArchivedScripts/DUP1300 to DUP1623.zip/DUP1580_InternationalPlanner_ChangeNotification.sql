-- ***********************************************
-- NAME 		: DUP1580_InternationalPlanner_ChangeNotification.sql
-- DESCRIPTION 	: Add InternationalPlanner tables to Change Notification Table
-- AUTHOR		: Mitesh Modi
-- DATE			: 08 Feb 2010
-- ************************************************

USE [InternationalData]
GO

--Delete existing entries
IF EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] like '%')
BEGIN
    DELETE [dbo].[ChangeNotification]
    WHERE [dbo].[ChangeNotification].[Table] like '%'
END

-- Add all the tables being monitored for International Planner
IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'Country')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('Country', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'CountryJourney')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('CountryJourney', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'InterchangeTime')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('InterchangeTime', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'InternationalCity')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('InternationalCity', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'InternationalCityStop')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('InternationalCityStop', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'InternationalStop')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('InternationalStop', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'ScheduleAir')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('ScheduleAir', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'ScheduleCar')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('ScheduleCar', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'ScheduleCoach')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('ScheduleCoach', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'ScheduleRail')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('ScheduleRail', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'ScheduleIntermediateCoach')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('ScheduleIntermediateCoach', 1)
END

IF NOT EXISTS (SELECT * FROM [ChangeNotification] WHERE [Table] = 'ScheduleIntermediateRail')
BEGIN
    INSERT INTO [dbo].[ChangeNotification] ([Table], [Version])
    VALUES ('ScheduleIntermediateRail', 1)
END
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1580
SET @ScriptDesc = 'Added InternationalPlanner tables to Change Notification Table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------