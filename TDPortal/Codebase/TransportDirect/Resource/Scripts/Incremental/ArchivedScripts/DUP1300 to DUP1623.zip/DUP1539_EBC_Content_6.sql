-- ***********************************************
-- NAME 		: DUP1539_EBC_Content_6.sql
-- DESCRIPTION 	: Script to add EBC pages and control content
-- AUTHOR		: Mitesh Modi
-- DATE			: 11 Dec 2009
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- Find EBC Input page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.AppendPageTitle', 'Freight Grants - Environmental Benefits Calculator | ', 'Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol | '

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelFindPageTitle.Text', 'Freight Grants - Environmental Benefits Calculator', 'Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.imageInputFormSkipLink.AlternateText', 'Skip to input form', 'Neidiwch i ffurf mewnbynnu'

EXEC AddtblContent
1, 1, 'langStrings', 'FindEBCInput.clientLink.BookmarkTitle', 'Transport Direct Freight Grants - Enivronmental Benefits Calculator', 'Grantiau Cludo Nwyddau Transport Direct - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.lblEBC', 'Freight Grants - Environmental Benefits Calculator', 'Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/EnvironmentalBenefitsCalculator.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/EnvironmentalBenefitsCalculator.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC1.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/freighttrain.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/freighttrain.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC1.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC2.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/lorry.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/lorry.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC2.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC3.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/barge.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/barge.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageFindEBC3.AlternateText', 'Freight Grants - Environmental Benefits Calculator', 'Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.imageEBCSkipLink.AlternateText', 'Skip to Freight Grants - Environmental Benefits Calculator', 'Neidio i Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.labelFromToTitle', 'Enter two locations to plan your route.', 'Nodwch ddau leoliad i gynllunio eich llwybr.'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.CommandBack.Text', 'Back', 'Yn �l'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.FindEBCInput.Information.Text', 
'This calculator is designed for organisations interested in or applying for a <b>Freight Facilities Grant</b>, 
<b>Waterborne Freight Grant</b> or support from the <b>Mode Shift Revenue Support</b> (Bulk and Waterways) scheme. It 
calculates the value of removing a lorry journey, using Mode Shift Benefit values, between two points as set 
out in the guidance for each of the schemes.',
'Cynlluniwyd y cyfrifiannell hwn i sefydliadau &#226; diddordeb yn y canlynol neu sy''n ymgeisio am 
<b>Grant Cyfleusterau Cludo Nwyddau</b>, 
<b>Grant Cludo Nwyddau a Gludir gan Ddwr</b> neu gymorth gan y cynllun 
<b>Cymorth Refeniw Newid Moddol</b> (Swmp a Dyfrffyrdd). Mae''n
cyfrifo gwerth gwaredu siwrnai lori, gan ddefnyddio gwerthoedd Budd
Newid Moddol, rhwng dau bwynt fel y nodir yn y cyfarwyddyd ar gyfer
pob un o''r cynlluniau.
'

EXEC AddtblContent
1, 1, 'langStrings', 'WaitPageMessage.FindEBC', 'Thank you for waiting while Transport Direct searches for your journey options.', 'Diolch i chi am aros tra bo Transport Direct yn chwilio am eich dewisiadau siwrnai.'

EXEC AddtblContent
1, 1, 'langStrings', 'FindLocationControl.directionLabelVia', 'Via', 'Drwy'

EXEC AddtblContent
1, 1, 'langStrings', 'FindLocationControl.directionLabelTravelVia', 'Near', 'Ger'

EXEC AddtblContent
1, 1, 'langStrings', 'viaSelect.labelSRLocation', 'Type in a location to travl via', 'Teipiwch leoliad i deithio drwyddo'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.EnvironmentalBenefitsCalculatorUnavailable', 'Freight Grants - Environmental Benefits Calculator is currently unavailable.', 'Nid yw Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol ar gael ar hyn o bryd.'

--------------------------------------------------------------------------------------------------------------------------------
-- Gazeteer options
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.FindEBCLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'


EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.Address', 'Address/postcode', 'Cyfeiriad/c�d post'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.Attraction', 'Facility/attraction', 'Cyfleuster/atyniad'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.Stations', 'Station/airport', 'Gorsaf/maes awyr'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.City', 'Town/district/village', 'Tref/rhanbarth/pentref'

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.EBCViaLocationDrop.AllStops', 'All stops (e.g. Bus, Tube, Tram)', 'Pob arhosiad (e.e. Bws, Tiwb, Tram)'




--------------------------------------------------------------------------------------------------------------------------------
-- EBC Journey Details page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.JourneyDetails.AppendPageTitle', 'Journey Details | Freight Grants - Environmental Benefits Calculator | ', 'Manylion y Siwrnai | Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol | '

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.EBCJourneyDetails.imageJourneySkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'

EXEC AddtblContent
1, 1, 'langStrings', 'JourneysSearchedForControl.headerRouteFoundFor', 'Route found for', 'Daethpwyd o hyd i lwybr ar gyfer'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCAllDetailsControlTitle.Text.OutwardJourney', 'Route Details', 'Manylion Llwybr'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCAllDetailsControlTitle.Text.ReturnJourney', 'Route Details', 'Manylion Llwybr'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerForDistance.Miles', 'For miles', 'Mewn milltiroedd'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerForDistance.Km', 'For km', 'Mewn cilometrau'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerAccumulatedDistance.Km', 'For km', 'Mewn cilometrau'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.headerAccumulatedDistance.TripKm', 'Trip km', 'Cyfanswm cilometrau''r daith'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationDetailsTableControl.labelCalculationTitle', 'Environmental Benefits Calculation', 'Cyfrifiad Buddion Amgylcheddol'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationDetailsTableControl.labelErrorMessage', 
'Sorry we are currently unable to perform the environmental benefits calculation for the route you have selected. 
Please help us to investigate this further by completing a feedback form (do this by clicking "Contact us" at the bottom
of the page).', 
'Mae''n ddrwg gennym, ni allwn gyfrifo''r buddion amgylcheddol ar
gyfer y llwybr rydych wedi''i ddewis ar hyn o bryd. Helpwch ni i
ymchwilio ymhellach i hyn drwy lenwi ffurflen adborth (gwnewch hyn
drwy glicio "Cysylltwch &#226; ni" ar waelod y dudalen).'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.Miles', 'miles', 'milltiroedd'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.Km', 'km', 'km'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.PerMile', 'per mile', 'y filltir'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.PerKm', 'per km', 'y cilometr'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.Total', 'Total', 'Cyfanswm'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.GrandTotal', 'Grand total', 'Prif gyfanswm'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategory', 'Road Category', 'Categori Ffordd'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryHighMotorway', 'High Motorway', 'Traffordd ag Effaith Amgylcheddol Uchel'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryStandardMotorway', 'Standard Motorway', 'Traffordd Safonol'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryStandardARoad', 'Standard A Road', 'Cefnffordd Safonol'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.RoadCategoryOtherRoads', 'Other Roads', 'Ffyrdd Eraill'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.CountryEngland', 'England', 'Cymru'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.CountryScotland', 'Scotland', 'Alban'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCCalculationFormatter.CountryWales', 'Wales', 'Lloegr'

EXEC AddtblContent
1, 1, 'langStrings', 'CarJourneyDetailsTableControl.HighValueMotorway.Image',
 '<img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation2.gif" align="middle" alt="Direction contains high value motorway" title="Direction contains high value motorway" />', 
 '<img src="/Web2/App_Themes/TransportDirect/images/gifs/exclamation2.gif" align="middle" alt="Mae''r cyfarwyddyd yn cynnwys traffordd o werth uchel" title="Mae''r cyfarwyddyd yn cynnwys traffordd o werth uchel" />'




--------------------------------------------------------------------------------------------------------------------------------
-- EBC Journey Maps page content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.JourneyMaps.AppendPageTitle', 'Journey Maps | Freight Grants - Environmental Benefits Calculator | ', 'Mapiau o''r Siwrnai | Grantiau Cludo Nwyddau - Cyfrifiannell Buddion Amgylcheddol | '

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.EBCJourneyMaps.imageMapSkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'

EXEC AddtblContent
1, 1, 'langStrings', 'ShowDetails.Text', 'Show details', 'Dangos manylion'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.MapKeyControlItems.EBC', 'Route,StartLocation,EndLocation', 'Route,StartLocation,EndLocation'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.imageRoute', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/UnknownTrafficKey.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/UnknownTrafficKey.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.imageEndLocation.AlternateText', 'Key for route', 'Allwedd ar gyfer llwybr'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.imageRoute.Print', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/UnknownTrafficKeyPrint.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/UnknownTrafficKey.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.labelRoute', 'Route', 'Llwybr'

EXEC AddtblContent
1, 1, 'langStrings', 'MapKeyControl.labelRoute.Print', 'Route', 'Llwybr'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.JourneyMaps.imageJourneySkipLink.AlternateText', 'Skip to main content', 'Neidiwch i''r prif gynnwys'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCMapControlTitle.Text.OutwardJourney', 'Route Map', 'Map Llwybr'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.labelEBCMapControlTitle.Text.ReturnJourney', 'Route Map', 'Map Llwybr'



--------------------------------------------------------------------------------------------------------------------------------
-- EBC Printer Friendly Page
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'EBCPlanner.StaticPrinterFriendly.labelPrinterFriendly', 'Environmental Benefits Calculator Printer friendly page', 'Tudalen y gellir ei hargraffu Cyfrifiannell Buddion Amgylcheddol'



--------------------------------------------------------------------------------------------------------------------------------
-- Feedback page
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'DataServices.UserFeedbackOtherOptions.Environmental Benefits Calculator', 'Environmental benefits calculator', 'Cyfrifiannell Buddion Amgylcheddol'



GO

-- *****************************************************************************************************************************
-- ******************** SOFT CONTENT SECTIONS **********************************************************************************
-- *****************************************************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- EBC page Group 
--------------------------------------------------------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM tblGroup WHERE [Name] like 'journeyplanning_findebcinput') 
	INSERT INTO tblGroup (GroupId, [Name])
	SELECT MAX(GroupId)+1, 'journeyplanning_findebcinput' FROM tblGroup

DECLARE @GroupId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'journeyplanning_findebcinput')


--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Information below input panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDPageInformationHtmlPlaceHolderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindEBCInput', 
'<div class="PageSoftContentContainer">  
<div class="PageSoftContent">
<p> </p>
</div>
</div>'
,
'<div class="PageSoftContentContainer">  
<div class="PageSoftContent">
<p> </p>
</div>
</div>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Latest news information - placeholder required to enable page to populate latest news
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindEBCInput', 
'<h1>Latest... NOT POPULATED</h1>',
'<h1>Latest... NOT POPULATED</h1>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Right hand information panel
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'TDFindEBCPromoHtmlPlaceholderDefinition', '/Channels/TransportDirect/JourneyPlanning/FindEBCInput',
'<div class="Column3Header">
<div class="txtsevenbbl">
  Freight Grants
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
	<table cellspacing="0" cellpadding="2" width="100%" border="0">
    <tbody>
      <tr>
        <td class="txtseven">
			For more information on the freight mode shift grants available in 
			England, Scotland and Wales covering Freight Facilities Grants (FFG), Mode Shift
			Revenue Support (MSRS) and the Waterborne Freight Grant (WFG) please use the links below.
			<br />
			<br />
			<a href="http://www.dft.gov.uk/pgr/freight/" target="_blank">England - Department for Transport <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />			
			<a href="http://www.scotland.gov.uk/Topics/Transport/FT/freightgrants1" target="_blank">Scotland - Scottish Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />
			<a href="http://wales.gov.uk/topics/transport/freight/ffg/" target="_blank">Wales - Welsh Assembly Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
		</td>
	  </tr>
	</tbody>
	</table>
</div>'
,
'<div class="Column3Header">
<div class="txtsevenbbl">
  Freight Grants
</div>
<!-- Don''t remove spaces -->&#160;&#160;</div>
<div class="Column3Content">
	<table cellspacing="0" cellpadding="2" width="100%" border="0">
    <tbody>
      <tr>
        <td class="txtseven">
			For more information on the freight mode shift grants available in 
			England, Scotland and Wales covering Freight Facilities Grants (FFG), Mode Shift
			Revenue Support (MSRS) and the Waterborne Freight Grant (WFG) please use the links below.
			<br />
			<br />
			<a href="http://www.dft.gov.uk/pgr/freight/" target="_blank">England - Department for Transport <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />			
			<a href="http://www.scotland.gov.uk/Topics/Transport/FT/freightgrants1" target="_blank">Scotland - Scottish Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
			<br />
			<br />
			<a href="http://wales.gov.uk/topics/transport/freight/ffg/" target="_blank">Wales - Welsh Assembly Government <img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" /></a>
		</td>
	  </tr>
	</tbody>
	</table>
</div>'

GO

-- *****************************************************************************************************************************
-- ******************** HELP PAGE SOFT CONTENT SECTIONS **********************************************************************************
-- *****************************************************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------
-- EBC pages - Help urls
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'FindEBCInput.HelpPageUrl', 'Help/HelpFindEBCInput.aspx', 'Help/HelpFindEBCInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'FindEBCInput.HelpAmbiguityUrl', 'Help/HelpFindEBCInput.aspx', 'Help/HelpFindEBCInput.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCJourneyDetails.HelpPageUrl', 'Help/HelpEBCJourneyDetails.aspx', 'Help/HelpEBCJourneyDetails.aspx'

EXEC AddtblContent
1, 1, 'langStrings', 'EBCJourneyMap.HelpPageUrl', 'Help/HelpEBCJourneyMap.aspx', 'Help/HelpEBCJourneyMap.aspx'


--------------------------------------------------------------------------------------------------------------------------------
-- Add the help urls to ensure help pages are displayed
--------------------------------------------------------------------------------------------------------------------------------
DECLARE @GroupId int

SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'ContentDatabase')

-- Find EBC input - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindEBCInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindEBCInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpFindEBCInput', 'Channel',
'/Channels/TransportDirect/Help/HelpFindEBCInput',
'/Channels/TransportDirect/Help/HelpFindEBCInput'

-- Find EBC input - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindEBCInput', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindEBCInput', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpFindEBCInput', 'Channel',
'/Channels/TransportDirect/Printer/HelpFindEBCInput',
'/Channels/TransportDirect/Printer/HelpFindEBCInput'

-- EBC journey details - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyDetails', 'Channel',
'/Channels/TransportDirect/Help/HelpEBCJourneyDetails',
'/Channels/TransportDirect/Help/HelpEBCJourneyDetails'

-- EBC journey details - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyDetails', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyDetails', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyDetails', 'Channel',
'/Channels/TransportDirect/Printer/HelpEBCJourneyDetails',
'/Channels/TransportDirect/Printer/HelpEBCJourneyDetails'

-- EBC journey map - Normal
EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Help_HelpEBCJourneyMap', 'Channel',
'/Channels/TransportDirect/Help/HelpEBCJourneyMap',
'/Channels/TransportDirect/Help/HelpEBCJourneyMap'

-- EBC journey map - Printer
EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyMap', 'Page',
'/Web2/helpfulljp.aspx',
'/Web2/helpfulljp.aspx'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyMap', 'QueryString',
'helpfulljp',
'helpfulljp'

EXEC AddtblContent
1, @GroupId, '_Web2_Printer_HelpEBCJourneyMap', 'Channel',
'/Channels/TransportDirect/Printer/HelpEBCJourneyMap',
'/Channels/TransportDirect/Printer/HelpEBCJourneyMap'


--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Help text
--------------------------------------------------------------------------------------------------------------------------------
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'helpfulljp')

EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpFindEBCInput',
'<h3>Selecting locations to travel from and to</h3>
<blockquote>
  <h5>1.&#160; Type the location names in the boxes</h5>
  <p>&#160;</p>
  <p>It is best to type in the full location name so that you get
  the fewest ''similar matches'' returned to you. Punctuation and
  use of capital letters are not important.</p>
  <p>If you are not sure how to spell the name of the location, you
  can tick the ''Unsure of spelling'' box so that the Journey
  Planner will also search for locations that sound similar to the
  one you type in.</p>
  <p>If you do not know the full location name, type in as much as
  you know and put an asterisk * after the letters.</p>
</blockquote>
<br />
<blockquote>
  <h5>2.&#160; Select the type of locations</h5>
  <p>&#160;</p>
  <p>This will inform the Journey Planner whether you are looking
  for an address, a postcode or a town</p>
  <p>The categories are described below:</p>
  <blockquote>
    <p>
    <b>"Address/postcode":</b>If you select this, you can type in
    part or all of an address and/or a postcode, e.g. "3 Burleigh
    Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford,
    Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF". If you
    don''t know the postcode include as much of the address as
    possible.</p>
  </blockquote>
  <blockquote>
    <p>
    <b>"Town/district/village":</b>If you select this, you can type
    in the name of a city, town, borough, district, area, suburb,
    village or hamlet, e.g. "Manchester", "Maidenhead", "Anfield",
    "Hockley", "Chelsea"</p>
  </blockquote>
  <p>If you do not know the full location name, type in as much as
  you know and put an asterisk * after the letters.</p>
</blockquote>
<br />
<blockquote>
  <h5>3.&#160; Travelling via a location</h5>
  <p>&#160;</p>
  <p>Choose where to travel via by typing in the location and
  selecting a location type. For more details on how to do this,
  see ''Selecting locations to travel from and to'' at the
  beginning of the Help page.</p>
</blockquote>
<br />
<h3>Once you have completed the page, click ''Next''.&#160;</h3>'
,
'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote>
  <h5>1.&#160; Teipiwch enwau''r lleoliadau yn y blychau</h5>
  <p>&#160;</p>
  <p>Mae''n well teipio enw llawn y lleoliad er mwyn dychwelyd cyn
  lleied &#226; phosibl o ganlyniadau tebyg i chi. Nid yw''n bwysig
  atalnodi na defnyddio priflythrennau.</p>
  <p>Os nad ydych yn siwr sut i sillafu enw''r lleoliad, gallwch
  dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr
  Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r
  lleoliad a deipiwch i mewn.</p>
  <p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch i mewn
  cymaint ag y gwyddoch a rhowch seren * ar &#244;l y
  llythrennau.</p>
</blockquote>
<br />
<blockquote>
  <h5>2.&#160; Dewis y math o leoliadau</h5>
  <p>&#160;</p>
  <p>Bydd hyn yn rhoi gwybod i''r Cynlluniwr Siwrnai a ydych chi''n
  chwilio am gyfeiriad, cod post neu dref</p>
  <p>Disgrifir y categor&#239;au isod:</p>
  <blockquote>
    <p>
    <b>"Cyfeiriad/cod post":</b>Os byddwch yn dewis hwn, gallwch
    deipio rhan neu''r cyfan o gyfeiriad a/neu god post i mewn,
    e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh
    Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32
    0PF". Os nad ydych yn gwybod y cod post, dylech gynnwys cymaint
    o''r cyfeiriad &#226; phosibl.</p>
  </blockquote>
  <blockquote>
    <p>
    <b>"Tref/dosbarth/pentref":</b>Os byddwch yn dewis hwn, gallwch
    deipio i mewn enw dinas, tref, bwrdeistref, dosbarth, ardal,
    maestref, pentref neu bentrefan, e.e. "Manchester",
    "Maidenhead", "Anfield", "Hockley", "Chelsea"</p>
  </blockquote>
  <p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch i mewn
  gymaint ag y gwyddoch a rhowch seren * ar &#244;l y
  llythrennau.</p>
</blockquote>
<br />
<blockquote>
  <h5>3.&#160; Teithio drwy leoliad</h5>
  <p>&#160;</p>
  <p>Dewiswch drwy ble y byddwch chi''n teithio drwy deipio''r
  lleoliad i mewn a dewis math o leoliad. Am fwy o fanylion ar sut
  i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac
  iddynt'' ar ddechrau''r dudalen Gymorth.</p>
</blockquote>
<br />
<h3>Ar ol ichi gwblhau''r dudalen, cliciwch ''Nesaf''.&#160;</h3>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC input page - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpFindEBCInput',
'<h3>Selecting locations to travel from and to</h3>
<blockquote>
  <h5>1.&#160; Type the location names in the boxes</h5>
  <p>&#160;</p>
  <p>It is best to type in the full location name so that you get
  the fewest ''similar matches'' returned to you. Punctuation and
  use of capital letters are not important.</p>
  <p>If you are not sure how to spell the name of the location, you
  can tick the ''Unsure of spelling'' box so that the Journey
  Planner will also search for locations that sound similar to the
  one you type in.</p>
  <p>If you do not know the full location name, type in as much as
  you know and put an asterisk * after the letters.</p>
</blockquote>
<br />
<blockquote>
  <h5>2.&#160; Select the type of locations</h5>
  <p>&#160;</p>
  <p>This will inform the Journey Planner whether you are looking
  for an address, a postcode or a town</p>
  <p>The categories are described below:</p>
  <blockquote>
    <p>
    <b>"Address/postcode":</b>If you select this, you can type in
    part or all of an address and/or a postcode, e.g. "3 Burleigh
    Road", "3 Burleigh Road, Stretford", "Burleigh Road, Stretford,
    Manchester", "3 Burleigh Road, M32 0PF", "M32 0PF". If you
    don''t know the postcode include as much of the address as
    possible.</p>
  </blockquote>
  <blockquote>
    <p>
    <b>"Town/district/village":</b>If you select this, you can type
    in the name of a city, town, borough, district, area, suburb,
    village or hamlet, e.g. "Manchester", "Maidenhead", "Anfield",
    "Hockley", "Chelsea"</p>
  </blockquote>
  <p>If you do not know the full location name, type in as much as
  you know and put an asterisk * after the letters.</p>
</blockquote>
<br />
<blockquote>
  <h5>3.&#160; Travelling via a location</h5>
  <p>&#160;</p>
  <p>Choose where to travel via by typing in the location and
  selecting a location type. For more details on how to do this,
  see ''Selecting locations to travel from and to'' at the
  beginning of the Help page.</p>
</blockquote>
<br />
<h3>Once you have completed the page, click ''Next''.&#160;</h3>'
,
'<h3>Dewis lleoliadau i deithio ohonynt ac iddynt</h3>
<blockquote>
  <h5>1.&#160; Teipiwch enwau''r lleoliadau yn y blychau</h5>
  <p>&#160;</p>
  <p>Mae''n well teipio enw llawn y lleoliad er mwyn dychwelyd cyn
  lleied &#226; phosibl o ganlyniadau tebyg i chi. Nid yw''n bwysig
  atalnodi na defnyddio priflythrennau.</p>
  <p>Os nad ydych yn siwr sut i sillafu enw''r lleoliad, gallwch
  dicio''r blwch ''Ansicr o sillafiad'' fel y bydd y Cynlluniwr
  Siwrnai hefyd yn chwilio am leoliadau sy''n swnio''n debyg i''r
  lleoliad a deipiwch i mewn.</p>
  <p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch i mewn
  cymaint ag y gwyddoch a rhowch seren * ar &#244;l y
  llythrennau.</p>
</blockquote>
<br />
<blockquote>
  <h5>2.&#160; Dewis y math o leoliadau</h5>
  <p>&#160;</p>
  <p>Bydd hyn yn rhoi gwybod i''r Cynlluniwr Siwrnai a ydych chi''n
  chwilio am gyfeiriad, cod post neu dref</p>
  <p>Disgrifir y categor&#239;au isod:</p>
  <blockquote>
    <p>
    <b>"Cyfeiriad/cod post":</b>Os byddwch yn dewis hwn, gallwch
    deipio rhan neu''r cyfan o gyfeiriad a/neu god post i mewn,
    e.e. "3 Burleigh Road", "3 Burleigh Road, Stretford", "Burleigh
    Road, Stretford, Manchester", "3 Burleigh Road, M32 0PF", "M32
    0PF". Os nad ydych yn gwybod y cod post, dylech gynnwys cymaint
    o''r cyfeiriad &#226; phosibl.</p>
  </blockquote>
  <blockquote>
    <p>
    <b>"Tref/dosbarth/pentref":</b>Os byddwch yn dewis hwn, gallwch
    deipio i mewn enw dinas, tref, bwrdeistref, dosbarth, ardal,
    maestref, pentref neu bentrefan, e.e. "Manchester",
    "Maidenhead", "Anfield", "Hockley", "Chelsea"</p>
  </blockquote>
  <p>Os nad ydych yn gwybod enw llawn y lleoliad, teipiwch i mewn
  gymaint ag y gwyddoch a rhowch seren * ar &#244;l y
  llythrennau.</p>
</blockquote>
<br />
<blockquote>
  <h5>3.&#160; Teithio drwy leoliad</h5>
  <p>&#160;</p>
  <p>Dewiswch drwy ble y byddwch chi''n teithio drwy deipio''r
  lleoliad i mewn a dewis math o leoliad. Am fwy o fanylion ar sut
  i wneud hyn, gweler ''Dewis lleoliadau i deithio ohonynt ac
  iddynt'' ar ddechrau''r dudalen Gymorth.</p>
</blockquote>
<br />
<h3>Ar ol ichi gwblhau''r dudalen, cliciwch ''Nesaf''.&#160;</h3>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey details - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpEBCJourneyDetails',
'<h2>Journey details</h2>
<br />
<br />
<h5>Road journey</h5>
<p>The directions for your road journey are initially shown in a
list on the left of the results page with the environmental
benefits calculations on the right of the page. If you prefer, you
can view them on a map by clicking "Show on map". The map will
appear without the directions and calculations.</p>
<p>You can zoom into specific areas of the map by clicking on that
area or clicking the + - values in the zoom control in the top left
of the map.</p>
<blockquote>
  <p>
    <b>Journey directions:</b>
  </p>
  <p>The directions for your journey are summarised at the top of
  the page.</p>
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to their websites.</p>
  <p>The distance for each journey section is shown in the ''for
  miles column''. If the drive section distance is less than 0.1
  miles or km then a ''-'' is displayed.</p>
  <p>If the journey direction has a section of high value motorway
  then this is indicated through use of the exclamation icon
  against that direction.</p>
</blockquote>
<blockquote>
  <p>
    <b>Calculations:</b>
  </p>
  <p>The distances for each direction are calculated in metres to
  give the most accurate assessment of distance travelled and these
  values are then rounded to display in miles. This process
  combined with not displaying the value of drive sections of less
  than 0.1miles can sometimes mean that there are very small
  variances displayed between the distance in the ''trip miles''
  column and the ''for miles'' column. The calculation to work out
  the environmental benefit of the journey is based on the precise
  distance travelled on each road type in miles multiplied by the
  relevant associated road value.</p>
  <p>Each Row displays the results in distance and the value for
  the road category. The final row displays the total for each
  column.</p>
  <p>Each column represents a country, England, Scotland and Wales.
  The final column is the total for each row.</p>
</blockquote>'
,
'<h2>Manylion siwrnai</h2>
<br />
<br />
<h5>Siwrnai ffordd</h5>
<p>Dangosir y cyfarwyddiadau ar gyfer eich siwrnai ffordd i
ddechrau mewn rhestr ar ochr chwith y dudalen ganlyniadau gyda''r
cyfrifiadau buddion amgylcheddol ar ochr dde''r dudalen. Os yw''n
well gennych, gallwch eu gweld ar fap drwy glicio "Canfyddwch ar y
map". Bydd y map yn ymddangos heb y cyfarwyddiadau a''r
cyfrifiadau.</p>
<p>Gallwch chwyddo i mewn i ardaloedd penodol o''r map drwy glicio
ar yr ardal honno neu glicio''r gwerthoedd + - yn y rheolaeth
chwyddo ar frig y map ar yr ochr chwith.</p>
<blockquote>
  <p>
    <b>Cyfarwyddiadau siwrnai:</b>
  </p>
  <p>Crynhoir y cyfarwyddiadau ar gyfer eich siwrnai ar frig y
  dudalen.</p>
  <p>Os yw''r siwrnai''n cynnwys ffer&#239;au, tollau, ac ati,
  gallwch glicio ar yr enw yn y cyfarwyddyd er mwyn mynd i''w
  gwefannau.</p>
  <p>Dangosir y pellter ar gyfer pob rhan o''r siwrnai yn y golofn
  ''ar gyfer milltiroedd''. Os yw pellter y rhan yrru yn llai na
  0.1 milltir neu gilometr, arddangosir ''-''.</p>
  <p>Os oes gan gyfarwyddyd y siwrnai ran o draffordd o werth
  uchel, nodir hyn drwy ddefnyddio''r eicon ebychnod wrth ymyl y
  cyfarwyddyd hwnnw.</p>
</blockquote>
<blockquote>
  <p>
    <b>Cyfrifiadau:</b>
  </p>
  <p>Cyfrifir y pellteroedd ar gyfer pob cyfarwyddyd mewn metrau i
  roi''r asesiad cywiraf o bellter a deithir ac mae''r gwerthoedd
  hyn yn cael eu talgrynu wedyn i''w harddangos mewn milltiroedd.
  Mae''r broses hon ynghyd &#226; pheidio ag arddangos gwerth
  rhannau gyrru sy''n llai na 0.1 milltir yn gallu golygu weithiau
  fod amrywiannau bach iawn yn cael eu harddangos rhwng y pellter
  yn y golofn ''milltiroedd y daith'' a''r golofn ''am
  filltiroedd''. Mae''r cyfrifiad i gyfrifo budd amgylcheddol y
  siwrnai yn seiliedig ar yr union bellter a deithir ar bob math o
  ffordd mewn milltiroedd wedi''i luosi &#226;''r gwerth ffordd
  cysylltiedig perthnasol.</p>
  <p>Mae pob Rhes yn arddangos y canlyniadau mewn pellter a''r
  gwerth ar gyfer y categori ffordd. Mae''r rhes olaf yn arddangos
  y cyfanswm ar gyfer pob colofn.</p>
  <p>Mae pob colofn yn cynrychioli gwlad, Cymru, Lloegr a''r Alban.
  Y golofn olaf yw''r cyfanswm am bob rhes.</p>
</blockquote>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey details - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEBCJourneyDetails',
'<h2>Journey details</h2>
<br />
<br />
<h5>Road journey</h5>
<p>The directions for your road journey are initially shown in a
list on the left of the results page with the environmental
benefits calculations on the right of the page. If you prefer, you
can view them on a map by clicking "Show on map". The map will
appear without the directions and calculations.</p>
<p>You can zoom into specific areas of the map by clicking on that
area or clicking the + - values in the zoom control in the top left
of the map.</p>
<blockquote>
  <p>
    <b>Journey directions:</b>
  </p>
  <p>The directions for your journey are summarised at the top of
  the page.</p>
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to their websites.</p>
  <p>The distance for each journey section is shown in the ''for
  miles column''. If the drive section distance is less than 0.1
  miles or km then a ''-'' is displayed.</p>
  <p>If the journey direction has a section of high value motorway
  then this is indicated through use of the exclamation icon
  against that direction.</p>
</blockquote>
<blockquote>
  <p>
    <b>Calculations:</b>
  </p>
  <p>The distances for each direction are calculated in metres to
  give the most accurate assessment of distance travelled and these
  values are then rounded to display in miles. This process
  combined with not displaying the value of drive sections of less
  than 0.1miles can sometimes mean that there are very small
  variances displayed between the distance in the ''trip miles''
  column and the ''for miles'' column. The calculation to work out
  the environmental benefit of the journey is based on the precise
  distance travelled on each road type in miles multiplied by the
  relevant associated road value.</p>
  <p>Each Row displays the results in distance and the value for
  the road category. The final row displays the total for each
  column.</p>
  <p>Each column represents a country, England, Scotland and Wales.
  The final column is the total for each row.</p>
</blockquote>'
,
'<h2>Manylion siwrnai</h2>
<br />
<br />
<h5>Siwrnai ffordd</h5>
<p>Dangosir y cyfarwyddiadau ar gyfer eich siwrnai ffordd i
ddechrau mewn rhestr ar ochr chwith y dudalen ganlyniadau gyda''r
cyfrifiadau buddion amgylcheddol ar ochr dde''r dudalen. Os yw''n
well gennych, gallwch eu gweld ar fap drwy glicio "Canfyddwch ar y
map". Bydd y map yn ymddangos heb y cyfarwyddiadau a''r
cyfrifiadau.</p>
<p>Gallwch chwyddo i mewn i ardaloedd penodol o''r map drwy glicio
ar yr ardal honno neu glicio''r gwerthoedd + - yn y rheolaeth
chwyddo ar frig y map ar yr ochr chwith.</p>
<blockquote>
  <p>
    <b>Cyfarwyddiadau siwrnai:</b>
  </p>
  <p>Crynhoir y cyfarwyddiadau ar gyfer eich siwrnai ar frig y
  dudalen.</p>
  <p>Os yw''r siwrnai''n cynnwys ffer&#239;au, tollau, ac ati,
  gallwch glicio ar yr enw yn y cyfarwyddyd er mwyn mynd i''w
  gwefannau.</p>
  <p>Dangosir y pellter ar gyfer pob rhan o''r siwrnai yn y golofn
  ''ar gyfer milltiroedd''. Os yw pellter y rhan yrru yn llai na
  0.1 milltir neu gilometr, arddangosir ''-''.</p>
  <p>Os oes gan gyfarwyddyd y siwrnai ran o draffordd o werth
  uchel, nodir hyn drwy ddefnyddio''r eicon ebychnod wrth ymyl y
  cyfarwyddyd hwnnw.</p>
</blockquote>
<blockquote>
  <p>
    <b>Cyfrifiadau:</b>
  </p>
  <p>Cyfrifir y pellteroedd ar gyfer pob cyfarwyddyd mewn metrau i
  roi''r asesiad cywiraf o bellter a deithir ac mae''r gwerthoedd
  hyn yn cael eu talgrynu wedyn i''w harddangos mewn milltiroedd.
  Mae''r broses hon ynghyd &#226; pheidio ag arddangos gwerth
  rhannau gyrru sy''n llai na 0.1 milltir yn gallu golygu weithiau
  fod amrywiannau bach iawn yn cael eu harddangos rhwng y pellter
  yn y golofn ''milltiroedd y daith'' a''r golofn ''am
  filltiroedd''. Mae''r cyfrifiad i gyfrifo budd amgylcheddol y
  siwrnai yn seiliedig ar yr union bellter a deithir ar bob math o
  ffordd mewn milltiroedd wedi''i luosi &#226;''r gwerth ffordd
  cysylltiedig perthnasol.</p>
  <p>Mae pob Rhes yn arddangos y canlyniadau mewn pellter a''r
  gwerth ar gyfer y categori ffordd. Mae''r rhes olaf yn arddangos
  y cyfanswm ar gyfer pob colofn.</p>
  <p>Mae pob colofn yn cynrychioli gwlad, Cymru, Lloegr a''r Alban.
  Y golofn olaf yw''r cyfanswm am bob rhes.</p>
</blockquote>'


--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey map - Help text
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Help/HelpEBCJourneyMap',
'<h2>Journey details</h2>
<br />
<br />
<h5>Road journey</h5>
<p>The directions for your road journey are initially shown in a
list on the left of the results page with the environmental
benefits calculations on the right of the page. If you prefer, you
can view them on a map by clicking "Show on map". The map will
appear without the directions and calculations.</p>
<p>You can zoom into specific areas of the map by clicking on that
area or clicking the + - values in the zoom control in the top left
of the map.</p>
<blockquote>
  <p>
    <b>Journey directions:</b>
  </p>
  <p>The directions for your journey are summarised at the top of
  the page.</p>
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to their websites.</p>
  <p>The distance for each journey section is shown in the ''for
  miles column''. If the drive section distance is less than 0.1
  miles or km then a ''-'' is displayed.</p>
  <p>If the journey direction has a section of high value motorway
  then this is indicated through use of the exclamation icon
  against that direction.</p>
</blockquote>
<blockquote>
  <p>
    <b>Calculations:</b>
  </p>
  <p>The distances for each direction are calculated in metres to
  give the most accurate assessment of distance travelled and these
  values are then rounded to display in miles. This process
  combined with not displaying the value of drive sections of less
  than 0.1miles can sometimes mean that there are very small
  variances displayed between the distance in the ''trip miles''
  column and the ''for miles'' column. The calculation to work out
  the environmental benefit of the journey is based on the precise
  distance travelled on each road type in miles multiplied by the
  relevant associated road value.</p>
  <p>Each Row displays the results in distance and the value for
  the road category. The final row displays the total for each
  column.</p>
  <p>Each column represents a country, England, Scotland and Wales.
  The final column is the total for each row.</p>
</blockquote>'
,
'<h2>Manylion siwrnai</h2>
<br />
<br />
<h5>Siwrnai ffordd</h5>
<p>Dangosir y cyfarwyddiadau ar gyfer eich siwrnai ffordd i
ddechrau mewn rhestr ar ochr chwith y dudalen ganlyniadau gyda''r
cyfrifiadau buddion amgylcheddol ar ochr dde''r dudalen. Os yw''n
well gennych, gallwch eu gweld ar fap drwy glicio "Canfyddwch ar y
map". Bydd y map yn ymddangos heb y cyfarwyddiadau a''r
cyfrifiadau.</p>
<p>Gallwch chwyddo i mewn i ardaloedd penodol o''r map drwy glicio
ar yr ardal honno neu glicio''r gwerthoedd + - yn y rheolaeth
chwyddo ar frig y map ar yr ochr chwith.</p>
<blockquote>
  <p>
    <b>Cyfarwyddiadau siwrnai:</b>
  </p>
  <p>Crynhoir y cyfarwyddiadau ar gyfer eich siwrnai ar frig y
  dudalen.</p>
  <p>Os yw''r siwrnai''n cynnwys ffer&#239;au, tollau, ac ati,
  gallwch glicio ar yr enw yn y cyfarwyddyd er mwyn mynd i''w
  gwefannau.</p>
  <p>Dangosir y pellter ar gyfer pob rhan o''r siwrnai yn y golofn
  ''ar gyfer milltiroedd''. Os yw pellter y rhan yrru yn llai na
  0.1 milltir neu gilometr, arddangosir ''-''.</p>
  <p>Os oes gan gyfarwyddyd y siwrnai ran o draffordd o werth
  uchel, nodir hyn drwy ddefnyddio''r eicon ebychnod wrth ymyl y
  cyfarwyddyd hwnnw.</p>
</blockquote>
<blockquote>
  <p>
    <b>Cyfrifiadau:</b>
  </p>
  <p>Cyfrifir y pellteroedd ar gyfer pob cyfarwyddyd mewn metrau i
  roi''r asesiad cywiraf o bellter a deithir ac mae''r gwerthoedd
  hyn yn cael eu talgrynu wedyn i''w harddangos mewn milltiroedd.
  Mae''r broses hon ynghyd &#226; pheidio ag arddangos gwerth
  rhannau gyrru sy''n llai na 0.1 milltir yn gallu golygu weithiau
  fod amrywiannau bach iawn yn cael eu harddangos rhwng y pellter
  yn y golofn ''milltiroedd y daith'' a''r golofn ''am
  filltiroedd''. Mae''r cyfrifiad i gyfrifo budd amgylcheddol y
  siwrnai yn seiliedig ar yr union bellter a deithir ar bob math o
  ffordd mewn milltiroedd wedi''i luosi &#226;''r gwerth ffordd
  cysylltiedig perthnasol.</p>
  <p>Mae pob Rhes yn arddangos y canlyniadau mewn pellter a''r
  gwerth ar gyfer y categori ffordd. Mae''r rhes olaf yn arddangos
  y cyfanswm ar gyfer pob colofn.</p>
  <p>Mae pob colofn yn cynrychioli gwlad, Cymru, Lloegr a''r Alban.
  Y golofn olaf yw''r cyfanswm am bob rhes.</p>
</blockquote>'

--------------------------------------------------------------------------------------------------------------------------------
-- EBC journey map - Help text - Printer friendly
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, @GroupId, 'HelpBodyText', '/Channels/TransportDirect/Printer/HelpEBCJourneyMap',
'<h2>Journey details</h2>
<br />
<br />
<h5>Road journey</h5>
<p>The directions for your road journey are initially shown in a
list on the left of the results page with the environmental
benefits calculations on the right of the page. If you prefer, you
can view them on a map by clicking "Show on map". The map will
appear without the directions and calculations.</p>
<p>You can zoom into specific areas of the map by clicking on that
area or clicking the + - values in the zoom control in the top left
of the map.</p>
<blockquote>
  <p>
    <b>Journey directions:</b>
  </p>
  <p>The directions for your journey are summarised at the top of
  the page.</p>
  <p>If the journey involves ferries, tolls, etc. you can click on
  the name in the instruction to be taken to their websites.</p>
  <p>The distance for each journey section is shown in the ''for
  miles column''. If the drive section distance is less than 0.1
  miles or km then a ''-'' is displayed.</p>
  <p>If the journey direction has a section of high value motorway
  then this is indicated through use of the exclamation icon
  against that direction.</p>
</blockquote>
<blockquote>
  <p>
    <b>Calculations:</b>
  </p>
  <p>The distances for each direction are calculated in metres to
  give the most accurate assessment of distance travelled and these
  values are then rounded to display in miles. This process
  combined with not displaying the value of drive sections of less
  than 0.1miles can sometimes mean that there are very small
  variances displayed between the distance in the ''trip miles''
  column and the ''for miles'' column. The calculation to work out
  the environmental benefit of the journey is based on the precise
  distance travelled on each road type in miles multiplied by the
  relevant associated road value.</p>
  <p>Each Row displays the results in distance and the value for
  the road category. The final row displays the total for each
  column.</p>
  <p>Each column represents a country, England, Scotland and Wales.
  The final column is the total for each row.</p>
</blockquote>'
,
'<h2>Manylion siwrnai</h2>
<br />
<br />
<h5>Siwrnai ffordd</h5>
<p>Dangosir y cyfarwyddiadau ar gyfer eich siwrnai ffordd i
ddechrau mewn rhestr ar ochr chwith y dudalen ganlyniadau gyda''r
cyfrifiadau buddion amgylcheddol ar ochr dde''r dudalen. Os yw''n
well gennych, gallwch eu gweld ar fap drwy glicio "Canfyddwch ar y
map". Bydd y map yn ymddangos heb y cyfarwyddiadau a''r
cyfrifiadau.</p>
<p>Gallwch chwyddo i mewn i ardaloedd penodol o''r map drwy glicio
ar yr ardal honno neu glicio''r gwerthoedd + - yn y rheolaeth
chwyddo ar frig y map ar yr ochr chwith.</p>
<blockquote>
  <p>
    <b>Cyfarwyddiadau siwrnai:</b>
  </p>
  <p>Crynhoir y cyfarwyddiadau ar gyfer eich siwrnai ar frig y
  dudalen.</p>
  <p>Os yw''r siwrnai''n cynnwys ffer&#239;au, tollau, ac ati,
  gallwch glicio ar yr enw yn y cyfarwyddyd er mwyn mynd i''w
  gwefannau.</p>
  <p>Dangosir y pellter ar gyfer pob rhan o''r siwrnai yn y golofn
  ''ar gyfer milltiroedd''. Os yw pellter y rhan yrru yn llai na
  0.1 milltir neu gilometr, arddangosir ''-''.</p>
  <p>Os oes gan gyfarwyddyd y siwrnai ran o draffordd o werth
  uchel, nodir hyn drwy ddefnyddio''r eicon ebychnod wrth ymyl y
  cyfarwyddyd hwnnw.</p>
</blockquote>
<blockquote>
  <p>
    <b>Cyfrifiadau:</b>
  </p>
  <p>Cyfrifir y pellteroedd ar gyfer pob cyfarwyddyd mewn metrau i
  roi''r asesiad cywiraf o bellter a deithir ac mae''r gwerthoedd
  hyn yn cael eu talgrynu wedyn i''w harddangos mewn milltiroedd.
  Mae''r broses hon ynghyd &#226; pheidio ag arddangos gwerth
  rhannau gyrru sy''n llai na 0.1 milltir yn gallu golygu weithiau
  fod amrywiannau bach iawn yn cael eu harddangos rhwng y pellter
  yn y golofn ''milltiroedd y daith'' a''r golofn ''am
  filltiroedd''. Mae''r cyfrifiad i gyfrifo budd amgylcheddol y
  siwrnai yn seiliedig ar yr union bellter a deithir ar bob math o
  ffordd mewn milltiroedd wedi''i luosi &#226;''r gwerth ffordd
  cysylltiedig perthnasol.</p>
  <p>Mae pob Rhes yn arddangos y canlyniadau mewn pellter a''r
  gwerth ar gyfer y categori ffordd. Mae''r rhes olaf yn arddangos
  y cyfanswm ar gyfer pob colofn.</p>
  <p>Mae pob colofn yn cynrychioli gwlad, Cymru, Lloegr a''r Alban.
  Y golofn olaf yw''r cyfanswm am bob rhes.</p>
</blockquote>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1539
SET @ScriptDesc = 'EBC pages and control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO