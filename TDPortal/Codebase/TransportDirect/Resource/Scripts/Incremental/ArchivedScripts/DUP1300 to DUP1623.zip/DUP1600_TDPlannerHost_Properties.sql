
-- !!  NOTE WHEN RUNNING THIS SCRIPT ON PRODUCTION ENVIRONMENTS SWAP LINES ENDING "-- DEV --" FOR LINES BEGINNING "-- PROD -- "  !!!!!!!!!!

-- ***********************************************
-- NAME 		: DUP1600_TDPlannerHost_Properties.sql
-- DESCRIPTION 	: Script to add new properties for TDPlannerHost AID & GID
-- AUTHOR		: Rich Broddle
-- DATE			: 26 Feb 2010
-- ************************************************

-- !!  NOTE WHEN RUNNING THIS SCRIPT ON PRODUCTION ENVIRONMENTS SWAP LINES ENDING "-- DEV --" FOR LINES BEGINNING "-- PROD -- "  !!!!!!!!!!

USE [PermanentPortal]
GO

DELETE FROM PROPERTIES WHERE GID = 'TDPlannerHost'
GO

INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('AdditionalDataDB','Server=D03;Initial Catalog=AdditionalData;Trusted_Connection=true;','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('CityToCity.CarJourney.OutwardTime','0830','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('CityToCity.CarJourney.ReturnTime','1630','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('CityToCity.PublicJourney.Interval','22','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('CityToCity.PublicJourney.StartTime','0600','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('CoachFares.NationalExpress.Route60.AppendString','Route 60 - ','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('CoachFares.NationalExpress.Route60.Detection','route 60','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('DataServices.DataNotification.Groups','Air,ExternalLinks,BayTextFilter,CoachRoutesQuotaFare,JourneyEmissionsFactor,InternationalPlanner','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyControl.Notes.TrapezeRegions','S,Y,NW,SW,W,WM','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.AirDistanceFactor','1.09','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.BusDistanceFactor','1.25','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.CarSize.Default','medium','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.CarSize.Medium','medium','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.CongestionAndUrbanDrivingFactor','1.03','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.Distance.Air.Medium','480','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.Distance.Air.Small','71','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.EmissionBar.MaxWidth','178','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.FuelType.Default','petrol','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.FuelType.Diesel','diesel','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.FuelType.Petrol','petrol','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.HighMpg','68','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.LowMpg','23','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.MaxDistance','2000','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.MaxDistance.Air','2000','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.MinDistance','1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.MinDistance.Air','150','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.MinDistance.Coach','30','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('JourneyEmissions.PTAvailable','TRUE','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.addressgazetteerid','ADDP1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.addresspostcode.minscore','20','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.allstations.minscore','20','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.allstationsgazetteerid','ALLSTAT1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.attractions.minscore','20','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.attractionsgazetteerid','POINTX','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.codegazetteerid','CODEGAZ1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('LocationService.FilterGivenNameTag','TRUE','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.gazopsweburl','http://GAZOPS/GazopsWeb/GazopsWeb.asmx','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('LocationService.GivenNameTagFilterValues','Main Coach Stops|Main Rail / Coach|Main Rail Stations','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.locality.minscore','20','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.localitygazetteerid','DRILL1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstations.minscore','20','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.Airport','MAJSTAT4','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.AirportNoGroup','MAJSTAT8','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.Coach','MAJSTAT2','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.CoachNoGroup','MAJSTAT6','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.Rail','MAJSTAT3','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.RailNoGroup','MAJSTAT7','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.Undetermined','MAJSTAT1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.majorstationsgazetteerid.UndeterminedNoGroup','MAJSTAT5','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.maxreturnedrecords','60','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.partpostcodegazetteerid,','PCODE2','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.postcodegazetteerid','PCODE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.servername','GIS','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('locationservice.servicename','tdparc93','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom','JOURNEYREQUEST JOURNEYREQUESTVERBOSE JOURNEYRESULTS JOURNEYRESULTSVERBOSE EnhancedExposedServiceStartEvent EnhancedExposedServiceFinishEvent GATE GAZ CYCLEPLANNERREQUEST CYCLEPLANNERRESULT EBCCalculation MapAPI','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.EXP.Assembly','td.reportdataprovider.tdpcustomevents','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.EXP.Name','ExposedServicesEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.EXP.Publishers','FILE1 Queue1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.EXP.Trace','On','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GATE.Assembly','td.reportdataprovider.tdpcustomevents','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GATE.Name','DataGatewayEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GATE.Publishers','FILE1 Queue1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GATE.Trace','On','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GAZ.Assembly','td.reportdataprovider.tdpcustomevents','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GAZ.Name','GazetteerEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GAZ.Publishers','Queue1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.GAZ.Trace','On','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUEST.Assembly','td.userportal.journeycontrol','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUEST.Name','JourneyPlanRequestEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUEST.Publishers','Queue1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUEST.Trace','On','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Assembly','td.userportal.journeycontrol','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Name','JourneyPlanRequestVerboseEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Publishers','FILE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYREQUESTVERBOSE.Trace','On','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTS.Assembly','td.userportal.journeycontrol','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTS.Name','JourneyPlanResultsEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTS.Publishers','Queue1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTS.Trace','On','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Assembly','td.userportal.journeycontrol','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Name','JourneyPlanResultsVerboseEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Publishers','FILE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.JOURNEYRESULTSVERBOSE.Trace','On','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.MapAPI.Assembly','td.reportdataprovider.tdpcustomevents','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.MapAPI.Name','MapAPIEvent','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.MapAPI.Publishers','FILE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Custom.MapAPI.Trace','On','TDPlannerHost','TDPlannerHost',0,1)

INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.TraceLevel','Verbose','TDPlannerHost','TDPlannerHost',0,1) -- DEV --
-- PROD -- INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.TraceLevel','Error','TDPlannerHost','TDPlannerHost',0,1)

INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.Error.Publishers','FILE1','TDPlannerHost','TDPlannerHost',0,1) -- DEV --
-- PROD -- INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.Error.Publishers','FILE1 Queue1 EventLog1','TDPlannerHost','TDPlannerHost',0,1)

INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.Info.Publishers','FILE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.TraceLevel','Error','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.Verbose.Publishers','FILE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Event.Operational.Warning.Publishers','FILE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Console','','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Custom','','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Default','FILE1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Email','','TDPlannerHost','TDPlannerHost',0,1)

INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.EventLog','','TDPlannerHost','TDPlannerHost',0,1) -- DEV --
-- PROD -- INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.EventLog','EventLog1','TDPlannerHost','TDPlannerHost',0,1)

-- PROD ONLY -- INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.EventLog.EventLog1.Machine','.','TDPlannerHost','TDPlannerHost',0,1)
-- PROD ONLY -- INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.EventLog.EventLog1.Name','Application','TDPlannerHost','TDPlannerHost',0,1)
-- PROD ONLY -- INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.EventLog.EventLog1.Source','TDPlannerHost','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.File','FILE1','TDPlannerHost','TDPlannerHost',0,1)

INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.File.FILE1.Directory','C:\\TDPortal','TDPlannerHost','TDPlannerHost',0,1) -- DEV --
-- PROD -- INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.File.FILE1.Directory','D:\\TDPortal','TDPlannerHost','TDPlannerHost',0,1)

INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.File.FILE1.Rotation','20000','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Queue','Queue1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Queue.Queue1.Delivery','Express','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Queue.Queue1.Path','.\Private$\TDPrimaryQueue','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('Logging.Publisher.Queue.Queue1.Priority','Normal','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('PricingRetail.CoachFaresInterfaces.CoachFaresResponseTimeoutMilliSecs','90000','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.DisplayableRailTickets.query','SELECT KeyName, Value, Category, TicketGroup FROM CategorisedHashes WHERE DataSet = ''DisplayableRailTickets''','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.DisplayableSupplements.db','DefaultDB','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.DisplayableSupplements.query','SELECT listitem FROM Lists WHERE dataset = ''DisplayableSupplements'' ','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.DisplayableSupplements.type','1','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.db','DefaultDB','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.query','SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareTerminalZoneNLC'' ORDER BY NLC','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTerminalZoneNLC.type','2','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.db','TransientPortalDB','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.query','SELECT TicketTypeCode, TicketTypeGroup FROM TicketTypeGroup','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardTicketTypes.type','2','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.db','DefaultDB','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.query','SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareTravelcardZoneNLC'' ORDER BY NLC','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareTravelcardZoneNLC.type','2','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.db','DefaultDB','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.query','SELECT NLC, NLCDescription FROM ZoneNLC WHERE DataSet = ''FareUndergroundZoneNLC'' ORDER BY NLC','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.FareUndergroundZoneNLC.type','2','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.MobileDeviceTypes.db','DefaultDB','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.MobileDeviceTypes.query','SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''MobileDeviceTypes'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.MobileDeviceTypes.type','3','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.MobileTimeRequestDrop.db','DefaultDB','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.MobileTimeRequestDrop.query','SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''MobileTimeRequestDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder','TDPlannerHost','TDPlannerHost',0,1)
INSERT INTO PROPERTIES ( pName,pValue,AID,GID,PartnerId,ThemeId) VALUES ('TransportDirect.UserPortal.DataServices.MobileTimeRequestDrop.type','3','TDPlannerHost','TDPlannerHost',0,1)

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1600
SET @ScriptDesc = 'Script to add new properties for TDPlannerHost AID & GID'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO