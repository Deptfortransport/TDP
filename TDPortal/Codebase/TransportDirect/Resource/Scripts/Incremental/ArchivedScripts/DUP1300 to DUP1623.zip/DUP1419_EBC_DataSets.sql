-- ***********************************************
-- NAME 		: DUP1419_EBC_DataSets.sql
-- DESCRIPTION 	: Script to add Data sets for EBC planner
-- AUTHOR		: Mitesh Modi
-- DATE			: 17 Sep 2009
-- ************************************************


USE [PermanentPortal]
GO

-- The following new datasets are added for cycle planner
--     FindEBCLocationDrop
--     EBCViaLocationDrop
-- This is done by specifying the dataset names, adding the values for the datasets, 
-- and defining the storedprocedure properties to retrieve the datasets

-- A Feedback option is also added to the UserFeedbackOtherOptions dataset


---------------------------------------------------------------------
-- Specify dataset names
IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'FindEBCLocationDrop')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('FindEBCLocationDrop', 0)     
   
    END

IF NOT EXISTS (SELECT * FROM DataSet WHERE DataSet = 'EBCViaLocationDrop')
    BEGIN

        INSERT INTO DataSet (DataSet, PartnerId)
        VALUES ('EBCViaLocationDrop', 0)     
   
    END

---------------------------------------------------------------------
-- Add the dataset values (tidy up first)
IF EXISTS (SELECT * FROM DropDownLists WHERE DataSet = 'FindEBCLocationDrop')
	BEGIN 
		DELETE DropDownLists
		WHERE DataSet = 'FindEBCLocationDrop'
	END
	
IF EXISTS (SELECT * FROM DropDownLists WHERE DataSet = 'EBCViaLocationDrop')
	BEGIN 
		DELETE DropDownLists
		WHERE DataSet = 'EBCViaLocationDrop'
	END
	
IF NOT EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'FindEBCLocationDrop')
    BEGIN

		INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('FindEBCLocationDrop', 'City', 'Locality', 1, 1, 0, 1)
        
        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('FindEBCLocationDrop', 'Address', 'AddressPostCode', 0, 2, 0, 1)

    END

IF NOT EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'EBCViaLocationDrop')
    BEGIN

		INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('EBCViaLocationDrop', 'City', 'Locality', 1, 1, 0, 1)
        
        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
        VALUES ('EBCViaLocationDrop', 'Address', 'AddressPostCode', 0, 2, 0, 1)

    END

---------------------------------------------------------------------
-- Define the Properties to get the dataset values (tidy up first)
IF EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FindEBCLocationDrop%')
	BEGIN 
		DELETE properties
		WHERE pName like 'TransportDirect.UserPortal.DataServices.FindEBCLocationDrop%'
	END
	
IF EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.EBCViaLocationDrop%')
	BEGIN 
		DELETE properties
		WHERE pName like 'TransportDirect.UserPortal.DataServices.EBCViaLocationDrop%'
	END
	
IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.FindEBCLocationDrop%')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FindEBCLocationDrop.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FindEBCLocationDrop.query', 
            'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''FindEBCLocationDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.FindEBCLocationDrop.type', '3', 'DataServices', 'UserPortal', 0, 1)

    END

IF NOT EXISTS (SELECT * FROM properties WHERE pName like 'TransportDirect.UserPortal.DataServices.EBCViaLocationDrop%')
    BEGIN

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.EBCViaLocationDrop.db', 'DefaultDB', 'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.EBCViaLocationDrop.query', 
            'SELECT ResourceID, ItemValue, IsSelected FROM DropDownLists WHERE DataSet = ''EBCViaLocationDrop'' AND PartnerId = 0 And ThemeId = 1 ORDER BY SortOrder', 
            'DataServices', 'UserPortal', 0, 1)

        INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
        VALUES ('TransportDirect.UserPortal.DataServices.EBCViaLocationDrop.type', '3', 'DataServices', 'UserPortal', 0, 1)

    END


---------------------------------------------------------------------
-- Feedback 
-- Add the Environmental Benefits Calculator to the other options drop down

DECLARE @SortOrder INT
DECLARE @ItemValue INT

IF EXISTS (SELECT top 1 * FROM DropDownLists WHERE DataSet = 'UserFeedbackOtherOptions')
    BEGIN

	IF NOT EXISTS (SELECT * FROM DropDownLists WHERE DataSet = 'UserFeedbackOtherOptions' AND ResourceID = 'Environmental Benefits Calculator' )
		BEGIN
		
			-- Get the highest SortOrder and ItemValue value for this data set
			SET @SortOrder = (SELECT TOP 1 [SortOrder]  FROM [PermanentPortal].[dbo].[DropDownLists]
							  WHERE DataSet like 'UserFeedbackOtherOptions'
							  ORDER BY SortOrder DESC)
			
			SET @ItemValue = (SELECT TOP 1 [ItemValue]  FROM [PermanentPortal].[dbo].[DropDownLists]
							  WHERE DataSet like 'UserFeedbackOtherOptions'
							  ORDER BY SortOrder DESC)				  
			
			-- Update this record with a higher SortOrder value
			UPDATE [PermanentPortal].[dbo].[DropDownLists]
			SET SortOrder = (@SortOrder + 1)
			WHERE DataSet like 'UserFeedbackOtherOptions'
				AND SortOrder = @SortOrder
		
			-- Now insert the new record with the previous SortOrder value and new ItemValue
	        INSERT INTO DropDownLists (DataSet, ResourceID, ItemValue, IsSelected, SortOrder, PartnerId, ThemeId)
    	    VALUES ('UserFeedbackOtherOptions', 'Environmental Benefits Calculator', (@ItemValue + 1), 0, @SortOrder, 0, 1)
		END

    END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1419
SET @ScriptDesc = 'Datasets for EBC planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO