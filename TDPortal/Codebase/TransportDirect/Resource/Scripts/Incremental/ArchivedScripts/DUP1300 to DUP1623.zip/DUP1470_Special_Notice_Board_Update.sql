-- ***********************************************
-- AUTHOR       : Mark Turner
-- NAME  	: DUP1470_Special_Notice_Board_Update.sql
-- DESCRIPTION  : Changes the text of the Special Notice Board page. 
-- SOURCE  	: TDP Apps Support
-- Version 	: $Revision:   1.0  $
--
-- ************************************************
--$Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/DUP1470_Special_Notice_Board_Update.sql-arc  $  
--
--   Rev 1.0   Oct 13 2009 16:59:50   nrankin
--Initial revision.
--Resolution for 5320: Accessibility - Opens in new window
--
--   Rev 1.5   Oct 13 2009 16:36:22   nrankin
--Open in new window - WAI Compliance (XHTML) fix
--Resolution for 5320: Accessibility - Opens in new window
--
--   Rev 1.4   Sep 16 2009 10:18:36   nrankin
--Accessibility - Opens in new window
--
--Replace "opens in new window" with an icon.  
--Resolution for 5320: Accessibility - Opens in new window
--
--   Rev 1.3   Aug 10 2009 14:32:12   nrankin
--Amends to concessionary fares URL
--
--   Rev 1.2   Nov 04 2008 13:53:04   mturner
--Final updates for XHTML compliance
--Resolution for 5146: WAI AAA copmpliance work (CCN 474)
--
--   Rev 1.1   Nov 04 2008 13:24:54   mturner
--Updated to resolve IR5156 - Broken Links on special notice board.  Also took the opportunity to make compliant with post Del10 portal and make some XHTML compliance fixes.
--Resolution for 5156: Special Noticeboard Contains broken link
--
--   Rev 1.0   Nov 08 2007 12:42:26   mturner
--Initial revision.
--
--   Rev 1.4   Sep 25 2007 16:09:48   nrankin
--Change USD C447790
--
--Update "Special Notice Board" on homepage for DfT.
--
--   Rev 1.3   Dec 21 2006 13:41:38   sangle
--Updated Car park listing...
--
--   Rev 1.3   DEC 19 2006 11:26:02   SAngle 
--Amended Carpark city listings
--
--   Rev 1.2   Oct 27 2006 13:40:02   jfrank
--Updated for Del 9.0
--
--   Rev 1.1   Oct 10 2006 14:09:36   jfrank
--Update to special notice board page for Del 9.0 car parks.
--Resolution for 4219: Find a Car Park - Soft content changes for the homepage
--
--   Rev 1.0   Apr 13 2006 14:29:20   CRees
--Initial revision.
--


USE TransientPortal
GO

-- Special Notice Board page text
-- This should be fully formatted, remembering to escape any apostrophes ( use '' instead of ') 

IF EXISTS (SELECT * FROM dbo.SpecialContent WHERE Posting = 'SpecialNoticeBoard' and Placeholder = 'SpecialNoticeBoardHtmlPlaceHolder' and Culture = 'cy-GB')
BEGIN
	UPDATE dbo.SpecialContent
	SET
		[Text] = '<table id="Table1" cellspacing="0" cellpadding="5" width="100%" border="0">
			  	<tr>
					<td><br />
					<p><b>Beth yw Cynllun Teithio Rhatach Lloegr?</b><br />
					O 1af Ebrill 2008 ymlaen, bydd pobl dros 60 oed, a phobl anabl cymwys, sy''n 
					byw yn Lloegr yn gallu defnyddio''u cardiau Lloegr-gyfan newydd sy''n rhoi''r 
					hawl iddynt deithio''n ddi-d�l ar fysiau lleol ar adegau tawel yn unrhyw le yn 
					Lloegr. Y cyfnod amser minimwm statudol y mae hyn yn berthnasol iddo yw dydd 
					Llun i ddydd Gwener, o 9.30am i 11pm ac unrhyw bryd ar benwythnosau a gwyliau 
					banc. Gall awdurdodau lleol gynnig buddion ychwanegol i''w trigolion fel rhan 
					o''u cynllun teithio rhatach � er enghraifft, teithiau di-d�l neu brisiau 
					gostyngol ar dramiau neu drenau ar adegau tawel, neu deithiau di-d�l ar fysiau 
					cyn 9.30 am o Ddydd Llun i Ddydd Gwener; dylid gwirio''r manylion drwy gysylltu 
					�''r awdurdod lleol.<br />
					<br />
					Gellir cael mwy o wybodaeth ar:<br />
					<a target="child" title="cy Click to view information in a new browser window" href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640">
						http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640 <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a></p>
					<br />
					<p><b>Pa wasanaethau bysiau Transport Direct sy''n gynwysedig yng Nghynllun Teithio 
					Rhatach Lloegr?</b><br />
					Mae''r cynllun yn gymwys i deithiau ar adegau tawel ar bron bob gwasanaeth yn 
					Lloegr a ddisgrifir ar y wefan hon fel �gwasanaeth bysiau�. Gobeithiwn nodi pan 
					na fydd hyn yn gymwys wrth inni gael mwy o wybodaeth am eithriadau. Yn achos 
					teithiau a ddisgrifir fel teithiau �bysiau moethus/coets�, cynghorir teithwyr i 
					wirio manylion, costau a materion cysylltiedig ymlaen llaw gyda''r gweithredwr. 
					Er enghraifft, os bydd angen archebu''r gwasanaeth ymlaen llaw, efallai y bydd 
					ffi yn daladwy. Nid yw''r rhan fwyaf o wasanaethau bysiau moethus pellter hir 
					yn gynwysedig yn y cynllun, er bod gan gwmn�au bysiau moethus megis National 
					Express eisoes brisiau arbennig i bobl dros 60 felly gwiriwch drwy gysylltu 
					�''r cwmni.</p>
					<br />
					<p><b>Beth yw Cynllun Teithio Rhatach yr Alban?</b><br />
					Cychwynodd Scotland-Wide Free Bus Travel ar 1af Ebrill 2006 ac mae''n caniat�u 
					i unrhyw un sydd dros 60 ac i bobl anabl cymwys, deithio''n ddi-d�l ar 
					wasanaethau bysiau rheolaidd ar deithiau lleol a phell o fewn yr Alban. Nid oes 
					unrhyw gyfyngiadau amseroedd brig.
					<br />
					<br />
					Er mwyn manteisio ar y gwasanaeth bysiau di-d�l hwn mae angen ichi gael Cerdyn 
					Hawl Cenedlaethol. Nifer fechan yn unig o wasanaethau na fyddant yn cydnabod y 
					cerdyn, er enghraifft bysiau prisiau premiwm a bysiau City Sightseeing.<br />
					<br />
					Gellir cael mwy o wybodaeth ar: <a target="child" title="cy Click to view information in a new browser window" href="http://www.transportscotland.gov.uk/concessionarytravel">
						http://www.transportscotland.gov.uk/concessionarytravel <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a></p>
					<br />
					<p><b>Beth yw Cynllun Teithio Rhatach Cymru?</b><br />
					<br />
					Mae Llywodraeth Cynulliad Cymru yn rhoi cymorth ariannol i ganiat�u i 
					awdurdodau lleol yng Nghymru ddarparu teithiau di-d�l ar wasanaethau bysiau 
					rheolaidd yn lleol i drigolion Cymru sy''n 60 neu hyn ac i bobl anabl o unrhyw 
					oedran. Mae hefyd yn darparu gwasanaeth teithio di-d�l ar fysiau lleol i rai 
					sy''n cyd-deithio � phobl anabl.
					<br />
					<br />
					Mae''r cynllun yn gweithredu ledled Cymru a gall deiliaid p�s rhatach 
					deithio''n ddi-d�l ar unrhyw adeg o''r dydd.
					<br />
					<br />
					Gellir cael mwy o wybodaeth ar:<br />
					<a target="child" title="cy Click to view information in a new browser window" href="http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=cy">
						http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=cy <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a></p>
					<br />
					</td>
				</tr>
			</table>'
	WHERE Posting = 'SpecialNoticeBoard' and Placeholder = 'SpecialNoticeBoardHtmlPlaceHolder' and Culture = 'cy-GB'
END
ELSE
BEGIN
	INSERT INTO dbo.SpecialContent
	(
		Posting,
		Placeholder,
		Culture,
		[Text]
	)
	VALUES
	(
		'SpecialNoticeBoard',
		'SpecialNoticeBoardHtmlPlaceHolder',
		'cy-GB',
		'<table id="Table1" cellspacing="0" cellpadding="5" width="100%" border="0">
			  	<tr>
					<td><br />
						<p><b>Beth yw Cynllun Teithio Rhatach Lloegr?</b><br />
						O 1af Ebrill 2008 ymlaen, bydd pobl dros 60 oed, a phobl anabl cymwys, sy''n 
						byw yn Lloegr yn gallu defnyddio''u cardiau Lloegr-gyfan newydd sy''n rhoi''r 
						hawl iddynt deithio''n ddi-d�l ar fysiau lleol ar adegau tawel yn unrhyw le yn 
						Lloegr. Y cyfnod amser minimwm statudol y mae hyn yn berthnasol iddo yw dydd 
						Llun i ddydd Gwener, o 9.30am i 11pm ac unrhyw bryd ar benwythnosau a gwyliau 
						banc. Gall awdurdodau lleol gynnig buddion ychwanegol i''w trigolion fel rhan 
						o''u cynllun teithio rhatach � er enghraifft, teithiau di-d�l neu brisiau 
						gostyngol ar dramiau neu drenau ar adegau tawel, neu deithiau di-d�l ar fysiau 
						cyn 9.30 am o Ddydd Llun i Ddydd Gwener; dylid gwirio''r manylion drwy gysylltu 
						�''r awdurdod lleol.<br />
						<br />
						Gellir cael mwy o wybodaeth ar:<br />
						<a target="child" title="cy Click to view information in a new browser window" href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640">
							http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640 <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a></p>
					<br />
					<p><b>Pa wasanaethau bysiau Transport Direct sy''n gynwysedig yng Nghynllun Teithio 
							Rhatach Lloegr?</b><br />
						Mae''r cynllun yn gymwys i deithiau ar adegau tawel ar bron bob gwasanaeth yn 
						Lloegr a ddisgrifir ar y wefan hon fel �gwasanaeth bysiau�. Gobeithiwn nodi pan 
						na fydd hyn yn gymwys wrth inni gael mwy o wybodaeth am eithriadau. Yn achos 
						teithiau a ddisgrifir fel teithiau �bysiau moethus/coets�, cynghorir teithwyr i 
						wirio manylion, costau a materion cysylltiedig ymlaen llaw gyda''r gweithredwr. 
						Er enghraifft, os bydd angen archebu''r gwasanaeth ymlaen llaw, efallai y bydd 
						ffi yn daladwy. Nid yw''r rhan fwyaf o wasanaethau bysiau moethus pellter hir 
						yn gynwysedig yn y cynllun, er bod gan gwmn�au bysiau moethus megis National 
						Express eisoes brisiau arbennig i bobl dros 60 felly gwiriwch drwy gysylltu 
						�''r cwmni.</p>
					<br />
					<p><b>Beth yw Cynllun Teithio Rhatach yr Alban?</b><br />
						Cychwynodd Scotland-Wide Free Bus Travel ar 1af Ebrill 2006 ac mae''n caniat�u 
						i unrhyw un sydd dros 60 ac i bobl anabl cymwys, deithio''n ddi-d�l ar 
						wasanaethau bysiau rheolaidd ar deithiau lleol a phell o fewn yr Alban. Nid oes 
						unrhyw gyfyngiadau amseroedd brig.
						<br />
						<br />
						Er mwyn manteisio ar y gwasanaeth bysiau di-d�l hwn mae angen ichi gael Cerdyn 
						Hawl Cenedlaethol. Nifer fechan yn unig o wasanaethau na fyddant yn cydnabod y 
						cerdyn, er enghraifft bysiau prisiau premiwm a bysiau City Sightseeing.<br />
						<br />
						Gellir cael mwy o wybodaeth ar: <a target="child" title="cy Click to view information in a new browser window" href="http://www.transportscotland.gov.uk/concessionarytravel">
							http://www.transportscotland.gov.uk/concessionarytravel <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a></p>
					<br />
					<p><b>Beth yw Cynllun Teithio Rhatach Cymru?</b><br />
						<br />
						Mae Llywodraeth Cynulliad Cymru yn rhoi cymorth ariannol i ganiat�u i 
						awdurdodau lleol yng Nghymru ddarparu teithiau di-d�l ar wasanaethau bysiau 
						rheolaidd yn lleol i drigolion Cymru sy''n 60 neu hyn ac i bobl anabl o unrhyw 
						oedran. Mae hefyd yn darparu gwasanaeth teithio di-d�l ar fysiau lleol i rai 
						sy''n cyd-deithio � phobl anabl.
						<br />
						<br />
						Mae''r cynllun yn gweithredu ledled Cymru a gall deiliaid p�s rhatach 
						deithio''n ddi-d�l ar unrhyw adeg o''r dydd.
						<br />
						<br />
						Gellir cael mwy o wybodaeth ar:<br />
						<a target="child" title="cy Click to view information in a new browser window" href="http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=cy">
							http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=cy <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(yn agor ffenestr newydd)" /></a></p>
						<br />
					</td>
				</tr>
			</table>'
	)
END

IF EXISTS (SELECT * FROM dbo.SpecialContent WHERE Posting = 'SpecialNoticeBoard' and Placeholder = 'SpecialNoticeBoardHtmlPlaceHolder' and Culture = 'en-GB')
BEGIN
	UPDATE dbo.SpecialContent
	SET
		[Text] = '<table id="Table2" cellspacing="0" cellpadding="5" width="100%" border="0">
				<tr>
					<td><br />
						<p><b>What is the English Concessionary Travel Scheme?</b><br />
						From 1 April 2008 people living in England who are aged 60 and over, and 
						eligible disabled people, will be able to use their new England-wide passes 
						which entitle them to free off-peak local bus travel <b>anywhere</b> in 
						England. The statutory minimum time period to which this applies is Monday to 
						Friday, from 9.30am to 11pm and any time at weekends and bank holidays. Local 
						authorities may offer extra benefits to their residents as part of their 
						concessionary scheme � for example, free or reduced off-peak tram or rail 
						travel, or free bus travel before 9.30am Monday to Friday; details should be 
						checked with the local authority.
						<br />
						<br />
						Further information can be found at:<br />
						<a target="child" title="Click to view information in a new browser window" href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640">
							http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640 <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(opens in new window)" /></a></p>
						<br />
						<p><b>Which bus services on Transport Direct are included in the English Concessionary Travel Scheme?</b><br />
						The scheme applies to off-peak journeys on almost all services in England 
						described on this site as �bus�. We hope to indicate where this is not the case 
						as more information about exclusions becomes available. For journeys shown as 
						�coach�, passengers are advised to check details costs and associated issues in 
						advance with the operator. For example if the service requires pre-booking, a 
						booking fee may still be charged. Most long-distance coach services are not 
						included in the scheme, although coach operators such as National Express 
						already have special fares for the over-60''s so please check with the 
						operator.</p>
						<br />
						<p><b>What is the Scottish Concessionary Travel Scheme?</b><br />
						Scotland-Wide Free Bus Travel started on 1st April 2006 and allows anyone aged 
						over 60 and eligible disabled people, to travel free on both local registered 
						services and long distance bus services within Scotland. There are no peak-time 
						restrictions.
						<br />
						To take advantage of this free bus travel you need to have a National 
						Entitlement Card. Only a small number of services will not recognise the card, 
						for example premium fare buses and City Sightseeing buses.
						<br />
						<br />
						Further information can be found at: <a target="child" title="Click to view information in a new browser window" href="http://www.transportscotland.gov.uk/concessionarytravel">
							http://www.transportscotland.gov.uk/concessionarytravel <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(opens in new window)" /></a></p>
						<br />
						<p><b>What is the Welsh Concessionary Travel Scheme?</b><br />
						The Welsh Assembly Government provides financial support to enable local 
						authorities in Wales to provide freetravel on registered local bus services for 
						residents of Wales aged over 60 years and disabled of any age. Italso provides 
						free travel on local buses by companions to disabled persons.
						<br />
						<br />
						The scheme operates across Wales and concessionary pass holders can travel free 
						at any time of day.<br />
						<br />
						Further information can be found at:<br />
						<a target="child" title="Click to view information in a new browser window" href="http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=en">
							http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=en <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(opens in new window)" /></a></p>
						<br />
					</td>
				</tr>
			</table>'
	WHERE Posting = 'SpecialNoticeBoard' and Placeholder = 'SpecialNoticeBoardHtmlPlaceHolder' and Culture = 'en-GB'
END
ELSE
BEGIN
	INSERT INTO dbo.SpecialContent
	(
		Posting,
		Placeholder,
		Culture,
		[Text]
	)
	VALUES
	(
		'SpecialNoticeBoard',
		'SpecialNoticeBoardHtmlPlaceHolder',
		'en-GB',
		'<table id="Table2" cellspacing="0" cellpadding="5" width="100%" border="0">
				<tr>
					<td><br />
						<p><b>What is the English Concessionary Travel Scheme?</b><br />
						From 1 April 2008 people living in England who are aged 60 and over, and 
						eligible disabled people, will be able to use their new England-wide passes 
						which entitle them to free off-peak local bus travel <b>anywhere</b> in 
						England. The statutory minimum time period to which this applies is Monday to 
						Friday, from 9.30am to 11pm and any time at weekends and bank holidays. Local 
						authorities may offer extra benefits to their residents as part of their 
						concessionary scheme � for example, free or reduced off-peak tram or rail 
						travel, or free bus travel before 9.30am Monday to Friday; details should be 
						checked with the local authority.
						<br />
						<br />
						Further information can be found at:<br />
						<a target="child" title="Click to view information in a new browser window" href="http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640">
							http://www.direct.gov.uk/en/TravelAndTransport/PublicTransport/BusAndCoachTravel/DG_071640 <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(opens in new window)" /></a></p>
						<br />
						<p><b>Which bus services on Transport Direct are included in the English Concessionary Travel Scheme?</b><br />
						The scheme applies to off-peak journeys on almost all services in England 
						described on this site as �bus�. We hope to indicate where this is not the case 
						as more information about exclusions becomes available. For journeys shown as 
						�coach�, passengers are advised to check details costs and associated issues in 
						advance with the operator. For example if the service requires pre-booking, a 
						booking fee may still be charged. Most long-distance coach services are not 
						included in the scheme, although coach operators such as National Express 
						already have special fares for the over-60''s so please check with the 
						operator.</p>
						<br />
						<p><b>What is the Scottish Concessionary Travel Scheme?</b><br />
						Scotland-Wide Free Bus Travel started on 1st April 2006 and allows anyone aged 
						over 60 and eligible disabled people, to travel free on both local registered 
						services and long distance bus services within Scotland. There are no peak-time 
						restrictions.
						<br />
						To take advantage of this free bus travel you need to have a National 
						Entitlement Card. Only a small number of services will not recognise the card, 
						for example premium fare buses and City Sightseeing buses.
						<br />
						<br />
						Further information can be found at: <a target="child" title="Click to view information in a new browser window" href="http://www.transportscotland.gov.uk/concessionarytravel">
							http://www.transportscotland.gov.uk/concessionarytravel <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(opens in new window)" /></a></p>
						<br />
						<p><b>What is the Welsh Concessionary Travel Scheme?</b><br />
						The Welsh Assembly Government provides financial support to enable local 
						authorities in Wales to provide freetravel on registered local bus services for 
						residents of Wales aged over 60 years and disabled of any age. Italso provides 
						free travel on local buses by companions to disabled persons.
						<br />
						<br />
						The scheme operates across Wales and concessionary pass holders can travel free 
						at any time of day.<br />
						<br />
						Further information can be found at:<br />
						<a target="child" title="Click to view information in a new browser window" href="http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=en">
							http://new.wales.gov.uk/topics/transport/integrated/concessionary/fares/?lang=en <img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/newwindow.gif" alt="(opens in new window)" /></a></p>
						<br />
					</td>
				</tr>
			</table>'
	)
END

GO


----------------
-- Change Log --
----------------

USE PermanentPortal

Declare @@value decimal(7,3)
Select @@value = left(right('$Revision:   1.0  $',8),7)


IF EXISTS (SELECT * FROM dbo.MDSChangeCatalogue WHERE ScriptNumber = 005 and VersionNumber = @@value)
BEGIN
 UPDATE dbo.MDSChangeCatalogue
 SET
  ChangeDate = getdate(),
  Summary = 'Special Notice Board Update' 
 WHERE ScriptNumber = 005 AND VersionNumber = @@value
END
ELSE
BEGIN
 INSERT INTO dbo.MDSChangeCatalogue
 (
  ScriptNumber,
  VersionNumber,
  Summary
 )
 VALUES
 (
  005,
  @@value, 
  'Special Notice Board Update'
 )
END
