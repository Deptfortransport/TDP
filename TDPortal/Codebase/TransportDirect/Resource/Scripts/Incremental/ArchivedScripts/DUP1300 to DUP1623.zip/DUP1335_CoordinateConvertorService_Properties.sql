-- ***********************************************
-- NAME 		: DUP1335_CoordinateConvertorService_Properties.sql
-- DESCRIPTION 	: Script to add properties needed by the CoordinateConvertor web service
-- AUTHOR		: Mitesh Modi
-- DATE			: 28 May 2009
-- ************************************************

USE [PermanentPortal]
GO

-- ----------------------------------------
-- Coordinate Convertor web service
-- ----------------------------------------

-- clear existing properties
DELETE FROM properties WHERE AID = 'CoordinateConvertorService'

-- add new properties
INSERT INTO properties VALUES ('Logging.Event.Operational.Error.Publishers', 'FILE1', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Operational.Info.Publishers', 'FILE1', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Operational.Verbose.Publishers', 'FILE1', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Operational.Warning.Publishers', 'FILE1', 'CoordinateConvertorService', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('Logging.Event.Operational.TraceLevel', 'Verbose', 'CoordinateConvertorService', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('Logging.Publisher.Default', 'FILE1', 'CoordinateConvertorService', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('Logging.Publisher.File', 'FILE1', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.File.FILE1.Directory', 'C:\TDPortal', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.File.FILE1.Rotation', '5000', 'CoordinateConvertorService', 'UserPortal', 0, 1)

-- following are set as blanks as not needed by the CoordinateConvertorService
INSERT INTO properties VALUES ('Logging.Event.Custom', '', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Event.Custom.Trace', 'Off', 'CoordinateConvertorService', 'UserPortal', 0, 1)

INSERT INTO properties VALUES ('Logging.Publisher.Console', '', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.Email', '', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.EventLog', '', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.Queue', '', 'CoordinateConvertorService', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('Logging.Publisher.Custom', '', 'CoordinateConvertorService', 'UserPortal', 0, 1)

GO


-- ----------------------------------------
-- Portal Coordinate Convertor web service properties
-- ----------------------------------------

-- clear existing properties
DELETE FROM properties WHERE pName like 'CoordinateConvertor%'

-- add new properties
INSERT INTO properties VALUES ('CoordinateConvertor.WebService.URL', 'http://localhost/TDPWebServices/CoordinateConvertorService/CoordinateConvertor.asmx', 'Web', 'UserPortal', 0, 1)
INSERT INTO properties VALUES ('CoordinateConvertor.WebService.TimeoutMillisecs', '60000', 'Web', 'UserPortal', 0, 1)

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1335
SET @ScriptDesc = 'Properties for CoordinateConvertorService'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO