-- ***********************************************
-- NAME 		: DUP1367_JourneyEmissions_DataNotification.sql
-- DESCRIPTION 		: Add JourneyEmissionsFactor data notification to properties table
-- AUTHOR		: Mitesh Modi
-- ************************************************

USE [PermanentPortal]
GO

---------------------------------------------------
--insert into properties table
IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.JourneyEmissionsFactor.Database')
BEGIN
    INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
    VALUES ('DataServices.DataNotification.JourneyEmissionsFactor.Database', 'DefaultDB', '<DEFAULT>', '<DEFAULT>', 0, 1)
END


IF NOT EXISTS (SELECT * FROM properties WHERE [pName] = 'DataServices.DataNotification.JourneyEmissionsFactor.Tables')
BEGIN
    INSERT INTO [dbo].[properties] ([pName], [pValue], [AID], [GID], [PartnerId], [ThemeId])
    VALUES ('DataServices.DataNotification.JourneyEmissionsFactor.Tables', 'JourneyEmissionsFactor', '<DEFAULT>', '<DEFAULT>', 0, 1)
END


---------------------------------------------------
-- update the data notification monitoring list to also check for JourneyEmissionsFactor
DECLARE @DataNotificationGroups VARCHAR(500)


SET @DataNotificationGroups = ( select pValue from properties 
                            where pName = 'DataServices.DataNotification.Groups' and AID = '<DEFAULT>' and GID = '<DEFAULT>' and PartnerId = 0 and ThemeId = 1)

IF EXISTS (select top 1 * from properties where pName = 'DataServices.DataNotification.Groups' and AID = '<DEFAULT>' and GID = '<DEFAULT>' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the JourneyEmissionsFactor multiple times if the script is run more than once
    IF NOT EXISTS ( select top 1 * from properties 
                    where pvalue like '%JourneyEmissionsFactor%' and pName = 'DataServices.DataNotification.Groups' and AID = '<DEFAULT>' and GID = '<DEFAULT>' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @DataNotificationGroups + ',JourneyEmissionsFactor'
    	where pName = 'DataServices.DataNotification.Groups' and AID = '<DEFAULT>' and GID = '<DEFAULT>' and PartnerId = 0 and ThemeId = 1
    END
END


SET @DataNotificationGroups = ( select pValue from properties 
                            where pName = 'DataServices.DataNotification.Groups' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)

IF EXISTS (select top 1 * from properties where pName = 'DataServices.DataNotification.Groups' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the JourneyEmissionsFactor multiple times if the script is run more than once
    IF NOT EXISTS ( select top 1 * from properties 
                    where pvalue like '%JourneyEmissionsFactor%' and pName = 'DataServices.DataNotification.Groups' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @DataNotificationGroups + ',JourneyEmissionsFactor'
    	where pName = 'DataServices.DataNotification.Groups' and AID = 'EnhancedExposedServices' and GID = 'UserPortal' and PartnerId = 0 and ThemeId = 1
    END
END



SET @DataNotificationGroups = ( select pValue from properties 
                            where pName = 'DataServices.DataNotification.Groups' and AID = 'TDRemotingHost' and GID = 'TDRemotingHost' and PartnerId = 0 and ThemeId = 1)

IF EXISTS (select top 1 * from properties where pName = 'DataServices.DataNotification.Groups' and AID = 'TDRemotingHost' and GID = 'TDRemotingHost' and PartnerId = 0 and ThemeId = 1)
BEGIN
    -- This prevents adding the JourneyEmissionsFactor multiple times if the script is run more than once
    IF NOT EXISTS ( select top 1 * from properties 
                    where pvalue like '%JourneyEmissionsFactor%' and pName = 'DataServices.DataNotification.Groups' and AID = 'TDRemotingHost' and GID = 'TDRemotingHost' and PartnerId = 0 and ThemeId = 1)
    BEGIN
    	update properties 
	    set pvalue = @DataNotificationGroups + ',JourneyEmissionsFactor'
    	where pName = 'DataServices.DataNotification.Groups' and AID = 'TDRemotingHost' and GID = 'TDRemotingHost' and PartnerId = 0 and ThemeId = 1
    END
END



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1367
SET @ScriptDesc = 'Add JourneyEmissionsFactor data notification to properties table'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
-------------------------------------------