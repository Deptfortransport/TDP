-- ***********************************************
-- NAME 		: DUP1536_StopInformation_DepartureBoard_Switches.sql
-- DESCRIPTION 		: Script to add properties to switch on/off stop information departure board for bus or rail
-- AUTHOR		: Amit Patel
-- DATE			: 19 Aug 2009
-- ************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowServices.Rail' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowServices.Rail', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowServices.Rail' and ThemeId = 1
END

IF not exists (select top 1 * from properties where pName = 'StopInformation.ShowServices.Bus' and ThemeId = 1)
BEGIN
	insert into properties values ('StopInformation.ShowServices.Bus', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'StopInformation.ShowServices.Bus' and ThemeId = 1
END





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1536
SET @ScriptDesc = 'Script to add properties to switch on/off stop information departure board for bus or rail'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO