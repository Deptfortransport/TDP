-- ***********************************************
-- NAME 		: DUP1572_InternationalPlanner_Properties_Logging.sql
-- DESCRIPTION 	: Script to add international planner logging properties
-- AUTHOR		: Amit Patel
-- DATE			: 25 Jan 2009
-- ************************************************

USE [PermanentPortal]
GO

-- ********************* IMPORTANT ******************************
-- Please update the publisher locations for the property 'Logging.Event.Custom.INTLPLANNERREQUEST.Publishers'
-- Please update the publisher locations for the property 'Logging.Event.Custom.INTLPLANNERRESULT.Publishers'
-- Please update the publisher locations for the property 'Logging.Event.Custom.INTLPLANNEREVENT.Publishers'
-- The publisher should be Queue1 instead of File1

-- Please ensure the AID and GID values are correctly set, in particular the TDRemotingHost settings

-- **************************************************************


---------------------------------------------------------------------
-- LOGGING PROPERTIES
---------------------------------------------------------------------
IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom.Trace' 
	and AID = 'TDRemotingHost'
	and GID = 'UserPortal'
	and PartnerId = 0
	and ThemeId = 1)
BEGIN
	insert into properties values ('Logging.Event.Custom.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)
END

-----------------------------------------------------------------------
-- LOGGING PROPERTIES FOR INTERNATIONALPLANNERREQUEST EVENT
-----------------------------------------------------------------------

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Assembly' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Assembly', 'td.userportal.internationalplannercontrol', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Assembly', 'td.userportal.internationalplannercontrol', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Assembly', 'td.userportal.internationalplannercontrol', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Assembly', 'td.userportal.internationalplannercontrol', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Name' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Name', 'InternationalPlannerRequestEvent', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Name', 'InternationalPlannerRequestEvent', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Name', 'InternationalPlannerRequestEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Name', 'InternationalPlannerRequestEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Publishers' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Publishers', 'FILE1', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERREQUEST.Trace' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Trace', 'On', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERREQUEST.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


-- Update the customer events to monitor to include InternationalPlannerRequestEvent

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and pValue LIKE '%INTLPLANNERREQUEST%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNERREQUEST'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EventReceiver')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EventReceiver'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and pValue LIKE '%INTLPLANNERREQUEST%')
BEGIN
	UPDATE properties
	SET pValue =  
		(SELECT pValue + ' INTLPLANNERREQUEST'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'EventReceiverGroup')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'EventReceiverGroup'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and pValue LIKE '%INTLPLANNERREQUEST%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNERREQUEST'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'TDRemotingHost')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'TDRemotingHost'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and pValue LIKE '%INTLPLANNERREQUEST%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNERREQUEST'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'Web')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'Web'
END

-----------------------------------------------------------------------
-- LOGGING PROPERTIES FOR INTERNATIONALPLANNERRESULTEVENT
-----------------------------------------------------------------------

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Assembly' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Assembly', 'td.userportal.internationalplannercontrol', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Assembly', 'td.userportal.internationalplannercontrol', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Assembly', 'td.userportal.internationalplannercontrol', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Assembly', 'td.userportal.internationalplannercontrol', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Name' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Name', 'InternationalPlannerResultEvent', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Name', 'InternationalPlannerResultEvent', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Name', 'InternationalPlannerResultEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Name', 'InternationalPlannerResultEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Publishers' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Publishers', 'FILE1', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNERRESULT.Trace' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Trace', 'On', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNERRESULT.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


-- Update the customer events to monitor to include InternationalPlannerResultEvent

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and pValue LIKE '%INTLPLANNERRESULT%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNERRESULT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EventReceiver')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EventReceiver'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and pValue LIKE '%INTLPLANNERRESULT%')
BEGIN
	UPDATE properties
	SET pValue =  
		(SELECT pValue + ' INTLPLANNERRESULT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'EventReceiverGroup')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'EventReceiverGroup'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and pValue LIKE '%INTLPLANNERRESULT%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNERRESULT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'TDRemotingHost')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'TDRemotingHost'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and pValue LIKE '%INTLPLANNERRESULT%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNERRESULT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'Web')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'Web'
END



-----------------------------------------------------------------------
-- LOGGING PROPERTIES FOR INTERNATIONALPLANNER EVENT
-----------------------------------------------------------------------

IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Assembly' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Assembly' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Assembly', 'td.userportal.internationalplannercontrol', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Assembly', 'td.userportal.internationalplannercontrol', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Assembly', 'td.userportal.internationalplannercontrol', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Assembly', 'td.userportal.internationalplannercontrol', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Name' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Name' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Name', 'InternationalPlannerEvent', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Name', 'InternationalPlannerEvent', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Name', 'InternationalPlannerEvent', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Name', 'InternationalPlannerEvent', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Publishers' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Publishers' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Publishers', 'FILE1', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Publishers', 'FILE1', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Publishers', 'TDPDB', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Publishers', 'TDPDB', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


IF exists (select top 1 * from properties where pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Trace' and ThemeId = 1)
BEGIN
	DELETE FROM properties WHERE pName = 'Logging.Event.Custom.INTLPLANNEREVENT.Trace' and ThemeId = 1
END
BEGIN
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Trace', 'On', 'Web', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Trace', 'On', 'TDRemotingHost', 'UserPortal', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Trace', 'On', 'EventReceiver', 'ReportDataProvider', 0, 1)
	insert into properties values ('Logging.Event.Custom.INTLPLANNEREVENT.Trace', 'On', 'EventReceiverGroup', 'ReportDataProvider', 0, 1)
END


-- Update the customer events to monitor to include InternationalPlannerRequestEvent

IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiver' and pValue LIKE '%INTLPLANNEREVENT%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNEREVENT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName = 'Logging.Event.Custom'
			and AID = 'EventReceiver')
	WHERE pName = 'Logging.Event.Custom'
		and AID = 'EventReceiver'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'EventReceiverGroup' and pValue LIKE '%INTLPLANNEREVENT%')
BEGIN
	UPDATE properties
	SET pValue =  
		(SELECT pValue + ' INTLPLANNEREVENT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'EventReceiverGroup')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'EventReceiverGroup'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'TDRemotingHost' and pValue LIKE '%INTLPLANNERREQUEST%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNEREVENT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'TDRemotingHost')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'TDRemotingHost'
END


IF not exists (select top 1 * from properties where pName = 'Logging.Event.Custom' and AID = 'Web' and pValue LIKE '%INTLPLANNEREVENT%')
BEGIN
	UPDATE properties
	SET pValue = 
		(SELECT pValue + ' INTLPLANNEREVENT'
		 FROM [PermanentPortal].[dbo].[properties]
		 WHERE pName LIKE 'Logging.Event.Custom'
			and AID LIKE 'Web')
	WHERE pName LIKE 'Logging.Event.Custom'
		and AID LIKE 'Web'
END

GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1572
SET @ScriptDesc = 'Script to add international planner logging properties'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO