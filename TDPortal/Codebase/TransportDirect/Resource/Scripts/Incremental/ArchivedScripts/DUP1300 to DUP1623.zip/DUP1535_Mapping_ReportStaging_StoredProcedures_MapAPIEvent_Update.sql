-- ***********************************************
-- NAME 		: DUP1535_Mapping_ReportStaging_StoredProcedures_MapAPIEvent_Update.sql
-- DESCRIPTION 	: Script to add stored procedures to create MapAPIEvents
-- AUTHOR		: Mitesh Modi (correcting issues introduced by Amit Patel)
-- DATE			: 07 Dec 2009
-- ************************************************

USE [ReportStagingDB]
GO


-- ****IMPORTANT****
-- If running this script in the Production environment, please uncomment the lines with value "ReportServer.", and comment out the line below it.
-- There are 3 instances of this in the script.

----------------------------------------------------------------
-- Create AddMapAPIEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddMapAPIEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddMapAPIEvent 
        (@CommandCategory varchar(50),
         @Submitted datetime,
         @SessionId varchar(50), 
         @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO


----------------------------------------------------------------
-- Update AddMapAPIEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[AddMapAPIEvent] (@CommandCategory varchar(50), @Submitted datetime, @SessionId varchar(50), @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into MapAPIEvent Table'

    Insert into MapAPIEvent (CommandCategory, Submitted, SessionId, TimeLogged)
		Values (@CommandCategory, @Submitted, @SessionId, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Create TransferMapAPIEvents stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[TransferMapAPIEvents]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN 

    EXEC ('
        CREATE PROCEDURE TransferMapAPIEvents
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')
END
GO

----------------------------------------------------------------
-- Update TransferMapAPIEvents stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[TransferMapAPIEvents]
	@Date varchar(10)
AS
	SET NOCOUNT ON
	SET DATEFIRST 1
	SET XACT_ABORT ON

	--DELETE FROM [ReportServer].[Reporting].[dbo].[MapAPIEvents]
	DELETE FROM [Reporting].[dbo].[MapAPIEvents]
	WHERE CONVERT(varchar(10), MAEDate, 121) = @Date

	--INSERT INTO [ReportServer].[Reporting].[dbo].[MapAPIEvents]
	INSERT INTO [Reporting].[dbo].[MapAPIEvents]
	(
		MAEDate,
		MAEHour,
		MAEHourQuarter,
		MAEWeekDay,
		MAEMAETID,
		MAEAvMsDuration,
		MAECount
	)
	SELECT
		CAST(CONVERT(varchar(10), MAE.Submitted, 121) AS datetime) AS MAEDate,
		DATEPART(hour, MAE.Submitted) AS MAEHour,
		CAST(DATEPART(minute, MAE.Submitted) / 15 AS smallint) AS MAEHourQuarter,
		DATEPART(weekday, MAE.Submitted) AS MAEWeekDay,
		MAET.MAETID AS MEMDTID,
		AVG(CAST(DATEDIFF(millisecond, MAE.Submitted, MAE.TimeLogged) AS decimal(18, 0))) AS MAEAvMsDuration,
		COUNT(*) AS MAECount
	FROM MapAPIEvent MAE
	--LEFT OUTER JOIN ReportServer.Reporting.dbo.MapAPIEventType MAET ON MAE.CommandCategory = MAET.MAETCode
	LEFT OUTER JOIN Reporting.dbo.MapAPIEventType MAET ON MAE.CommandCategory = MAET.MAETCode
	WHERE CONVERT(varchar(10), MAE.Submitted, 121) = @Date
	GROUP BY
		CAST(CONVERT(varchar(10), MAE.Submitted, 121) AS datetime),
		DATEPART(hour, MAE.Submitted),
		CAST(DATEPART(minute, MAE.Submitted) / 15 AS smallint),
		DATEPART(weekday, MAE.Submitted),
		MAET.MAETID


GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- *************************************************************
-- Fix AddMapEvent which was broken by DUP1513.
-- *************************************************************

----------------------------------------------------------------
-- Create AddMapEvent stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AddMapEvent]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE AddMapEvent 
        (@CommandCategory varchar(50), 
		 @Submitted datetime, 
		 @DisplayCategory varchar(50), 
		 @SessionId varchar(50),
		 @UserLoggedOn bit, 
		 @TimeLogged datetime)
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')


END
GO

----------------------------------------------------------------
-- Update AddMapEvent stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[AddMapEvent] (@CommandCategory varchar(50), @Submitted datetime, @DisplayCategory varchar(50), @SessionId varchar(50), @UserLoggedOn bit, @TimeLogged datetime)
As
    set nocount off

    declare @localized_string_UnableToInsert AS nvarchar(256)
    set @localized_string_UnableToInsert = 'Unable to Insert a new record into MapEvent Table'

    Insert into MapEvent (CommandCategory, Submitted, DisplayCategory, SessionId, UserLoggedOn, TimeLogged)
		Values (@CommandCategory, @Submitted, @DisplayCategory, @SessionId, @UserLoggedOn, @TimeLogged)

    if @@error <> 0
    Begin
        raiserror (@localized_string_UnableToInsert, 1,1)
        return -1
    end
    else
    begin
        return @@rowcount
    End

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1535
SET @ScriptDesc = 'Add ReportStaging stored procedures for MapAPIEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO