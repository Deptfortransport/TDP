-- ***********************************************
-- NAME 		: DUP1582_InternationalPlanner_Database_StoredProcedures_1.sql
-- DESCRIPTION 	: Script to update stored procedures for the International planner database
-- AUTHOR		: Mitesh Modi
-- DATE			: 22 Feb 2010
-- ************************************************

USE [InternationalData]
GO

-------------------------------------------------------------
-- *********			   WARNING					  *******
-- Please ensure appropriate permissions are added to the stored procedures, all will 
-- need ASPUSER execute at a minimum.

-- This script adds the following stored procedures:
-- GetAllInternationalCities 
-- GetInternationalStopsForCity
-- GetInternationalStops
-- GetInternationalCity
-- GetInternationalJourneysAir
-- GetInternationalJourneysCoach
-- GetInternationalJourneysRail
-- GetInternationalJourneysCar
-- GetInterchangeTime
-- GetInternationalCityTransfer
-- GetInternationalStopDistances
-- IsPermittedInternationalJourney
-- GetChangeTable 

-------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------------------
-- Create GetAllInternationalCities stored proc (for Gaz)
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetAllInternationalCities]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetAllInternationalCities
        (@CityId varchar(20))
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetAllInternationalCities stored proc (for Gaz)
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetAllInternationalCities] 
As
    SET NOCOUNT ON

	-- Script to return all International City data (with country codes) for Gazetteer
	
	SELECT 
		[CityId],
		[CityName],
		[CityURL],
		[CityOSGREasting],
		[CityOSGRNorthing],
		[CountryCode],
		[CountryCodeIANA],
		[CountryAdminCodeUIC],
		[CountryTimeZoneHours]
	FROM InternationalCity
		INNER JOIN Country
		ON [CityCountryCode] = [CountryCode]
	
	WHERE CountrySchedulesRequired = 'Y'
	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalStopsForCity stored proc (for Gaz)
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalStopsForCity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalStopsForCity
        (@StopNaPTAN varchar(100))
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalStopsForCity stored proc (for Gaz)
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalStopsForCity] (@CityID varchar(100))
As
    SET NOCOUNT ON

	-- Script to return all the stops whose NaPTAN relates to the passed in city,
	-- for population of the TDLocation object

	SELECT 
		[StopCode],
		[StopNaPTAN],
		[StopType],
		[StopName],
		[StopOSGREasting],
		[StopOSGRNorthing],
		[StopTerminalNumber],
		[StopInformationURL],
		[StopInformationDescription],
		[StopDeparturesURL],
		[StopDeparturesDescription],
		[StopAccessabilityURL],
		[StopAccessabilityDescription]
	FROM InternationalStop
	WHERE [StopNaPTAN] in (SELECT StopNaPTAN FROM dbo.InternationalCityStop WHERE CityId = @CityID)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalStops stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalStops]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalStops 
        (@StopNaPTAN varchar(500))
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalStops stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalStops] (@StopNaPTANs varchar(500))
As
    SET NOCOUNT ON

	-- Script to return InternationalStop data and the Country data it belongs to
	-- Dynamic sql is created to allow an array of StopNaPTAN codes to be passed to help reduce
	-- the number of database calls needed by the appllication
	
	DECLARE @SQL varchar(1000)

	SET @SQL = 
	'
	SELECT 
		[StopCode],
		[StopNaPTAN],
		[StopType],
		[StopName],
		[StopOSGREasting],
		[StopOSGRNorthing],
		[StopTerminalNumber],
		[StopInformationURL],
		[StopInformationDescription],
		[StopDeparturesURL],
		[StopDeparturesDescription],
		[StopAccessabilityURL],
		[StopAccessabilityDescription],
		[CountryCode],
		[CountryCodeIANA],
		[CountryAdminCodeUIC],
		[CountryTimeZoneHours]
	FROM InternationalStop
	INNER JOIN Country
		 ON [StopCountryCode] = [CountryCode]
	WHERE StopNaPTAN in (' + @StopNaPTANs + ')'
	
	EXEC(@SQL)
    

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO






--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalCity stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalCity]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalCity 
        (@CityId varchar(20))
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalCity stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalCity] (@CityId varchar(20))
As
    SET NOCOUNT ON

	-- Script to return International City data (but not its associated InternationalStops)
	
	SELECT 
		[CityId],
		[CityName],
		[CityURL],
		[CityOSGREasting],
		[CityOSGRNorthing],
		[CountryCode],
		[CountryCodeIANA],
		[CountryAdminCodeUIC],
		[CountryTimeZoneHours]
	FROM InternationalCity
	INNER JOIN Country
		 ON [CityCountryCode] = [CountryCode]
	WHERE CityId = @CityId
	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalJourneysAir stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalJourneysAir]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalJourneysAir 
        (@OriginStopCode varchar(20),
         @DestinationStopCode varchar(20),
         @TerminalFrom varchar(10),
         @TerminalTo varchar(10),
         @OutwardDateTime datetime )
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalJourneysAir stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalJourneysAir] (
	@OriginStopCode varchar(20), @DestinationStopCode varchar(20), 
	@TerminalFrom varchar(10), @TerminalTo varchar(10),
	@OutwardDateTime datetime)
As
    SET NOCOUNT ON

	-- Script to return International Air schedules journey data

	SELECT  IS1.[StopNaPTAN] AS [DepartureStopNaptan]
           ,IS2.[StopNaPTAN] AS [ArrivalStopNaptan]
           ,SA.[DepartureTime]
           ,SA.[ArrivalTime]
           ,SA.[ArrivalDay]
           ,SA.[DaysOfOperation]
	 	   ,SA.[CarrierCode]
           ,SA.[FlightNumber]
           ,SA.[AircraftTypeCode]
           ,SA.[TerminalNumberFrom]
           ,SA.[TerminalNumberTo]           
           
	FROM [InternationalData].[dbo].[ScheduleAir] SA
   INNER JOIN [InternationalData].[dbo].[InternationalStop] IS1
		   ON SA.[DepartureAirportStopCode] = IS1.[StopCode]
   INNER JOIN [InternationalData].[dbo].[InternationalStop] IS2
		   ON SA.[ArrivalAirportStopCode] = IS2.[StopCode]
		   
	WHERE	SA.DepartureAirportStopCode = @OriginStopCode
	and		SA.ArrivalAirportStopCode = @DestinationStopCode
	and		REPLACE(SA.TerminalNumberFrom, ' ','') = REPLACE(@TerminalFrom, ' ','')
	and		REPLACE(SA.TerminalNumberTo, ' ','') = REPLACE(@TerminalTo, ' ','')
	-- Choose the correct international stop records
	and		REPLACE(SA.TerminalNumberFrom, ' ', '') = REPLACE(IS1.StopTerminalNumber, ' ', '')
	and		REPLACE(SA.TerminalNumberTo, ' ', '') = REPLACE(IS2.StopTerminalNumber, ' ', '')
	and		SA.EffectiveFromDate <= @OutwardDateTime
	and		SA.EffectiveToDate >= @OutwardDateTime
	
	ORDER BY SA.DepartureTime, SA.ArrivalTime, SA.ArrivalDay

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO







--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalJourneysCoach stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalJourneysCoach]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalJourneysCoach 
        (@OriginStopCode varchar(20),
         @DestinationStopCode varchar(20),
         @OutwardDateTime datetime )
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalJourneysCoach stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalJourneysCoach] (
	@OriginStopCode varchar(20), @DestinationStopCode varchar(20), @OutwardDateTime datetime)
As
    SET NOCOUNT ON

	-- Script to return International Coach schedules journey data
	
	SELECT		 SC.Id
				,SC.CoachNumber
				,SC.OperatorCode
				,SC.DaysOfOperation
				,SC.ServiceFacilities
				,SCL.LegNum
				,IS1.[StopNaPTAN] AS [DepartureStopNaptan]
				,IS2.[StopNaPTAN] AS [ArrivalStopNaptan]
				,SCL.DepartureTime
				,SCL.DepartureDay
				,SCL.ArrivalTime
				,SCL.ArrivalDay
		FROM [InternationalData].[dbo].[ScheduleCoachLeg] SCL
		
		INNER JOIN [InternationalData].[dbo].[ScheduleCoach] SC
		   ON SCL.[ScheduleCoachId] = SC.[Id]
		   
		INNER JOIN [InternationalData].[dbo].[InternationalStop] IS1
		   ON SCL.[DepartureStationStopCode] = IS1.[StopCode]
	
		INNER JOIN [InternationalData].[dbo].[InternationalStop] IS2
		   ON SCL.[ArrivalStationStopCode] = IS2.[StopCode]
		   
		WHERE SCL.ScheduleCoachId in (
			-- Identify the rail schedules which start at the origin stop
				SELECT ScheduleCoachId
				FROM [InternationalData].[dbo].[ScheduleCoachLeg]
		   
				WHERE DepartureStationStopCode = @OriginStopCode
		   
		   )
		
		and SCL.ScheduleCoachId in (
			-- Identify the rail schedules which end at the destination stop
				SELECT ScheduleCoachId
				FROM [InternationalData].[dbo].[ScheduleCoachLeg]
		   
				WHERE ArrivalStationStopCode = @DestinationStopCode
			)
		
		and SCL.ScheduleCoachId in (
			-- Only select rail schedules which are for valid Effective from/until dates
				SELECT Id
				FROM [InternationalData].[dbo].[ScheduleCoach]

				WHERE	EffectiveFromDate <= @OutwardDateTime
				and		EffectiveToDate >= @OutwardDateTime
			)

			-- Ensure the journey's and legs are ordered together before returning
		ORDER BY SC.Id, SCL.LegNum

	
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO






--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalJourneysRail stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalJourneysRail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalJourneysRail 
        (@OriginStopCode varchar(20),
         @DestinationStopCode varchar(20),
         @OutwardDateTime datetime )
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalJourneysRail stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalJourneysRail] (
	@OriginStopCode varchar(20), @DestinationStopCode varchar(20), @OutwardDateTime datetime)
As
    SET NOCOUNT ON

	-- Script to return International Rail schedules journey data

		SELECT	 SR.Id
				,SR.TrainNumber
				,SR.OperatorCode
				,SR.DaysOfOperation
				,SR.ServiceFacilities
				,SRL.LegNum
				,IS1.[StopNaPTAN] AS [DepartureStopNaptan]
				,IS2.[StopNaPTAN] AS [ArrivalStopNaptan]
				,SRL.DepartureTime
				,SRL.DepartureDay
				,SRL.ArrivalTime
				,SRL.ArrivalDay
		FROM [InternationalData].[dbo].[ScheduleRailLeg] SRL
		
		INNER JOIN [InternationalData].[dbo].[ScheduleRail] SR
		   ON SRL.[ScheduleRailId] = SR.[Id]
		   
		INNER JOIN [InternationalData].[dbo].[InternationalStop] IS1
		   ON SRL.[DepartureStationStopCode] = IS1.[StopCode]
	
		INNER JOIN [InternationalData].[dbo].[InternationalStop] IS2
		   ON SRL.[ArrivalStationStopCode] = IS2.[StopCode]
		   
		WHERE SRL.ScheduleRailId in (
			-- Identify the rail schedules which start at the origin stop
				SELECT ScheduleRailId
				FROM [InternationalData].[dbo].[ScheduleRailLeg]
		   
				WHERE DepartureStationStopCode = @OriginStopCode
		   
		   )
		
		and SRL.ScheduleRailId in (
			-- Identify the rail schedules which end at the destination stop
				SELECT ScheduleRailId
				FROM [InternationalData].[dbo].[ScheduleRailLeg]
		   
				WHERE ArrivalStationStopCode = @DestinationStopCode
			)
		
		and SRL.ScheduleRailId in (
			-- Only select rail schedules which are for valid Effective from/until dates
				SELECT Id
				FROM [InternationalData].[dbo].[ScheduleRail]

				WHERE	EffectiveFromDate <= @OutwardDateTime
				and		EffectiveToDate >= @OutwardDateTime
			)

			-- Ensure the journey's and legs are ordered together before returning
		ORDER BY SR.Id, SRL.LegNum
		
	
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO







--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalJourneysCar stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalJourneysCar]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalJourneysCar 
        (@DepartureCityId varchar(20),
         @ArrivalCityId varchar(20))
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalJourneysCar stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalJourneysCar] (
	@DepartureCityId varchar(20), @ArrivalCityId varchar(20))
As
    SET NOCOUNT ON

	-- Script to return International Car journey data

	SELECT  [DepartureCityId]
           ,[ArrivalCityId]
           ,[DepartureTime]
           ,[ArrivalTime]
           ,[ArrivalDay]
           ,[EmissionsGrammes]
           ,[JourneyInformation]
           ,[JourneyURL]
                      
	FROM [InternationalData].[dbo].[ScheduleCar]
   
   	WHERE	DepartureCityId = @DepartureCityId
	and		ArrivalCityId = @ArrivalCityId

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO







--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInterchangeTime stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInterchangeTime]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInterchangeTime 
        (@FromNaPTAN varchar(12),
         @ToNaPTAN varchar(12),
         @FromOperator varchar(10),
         @ToOperator varchar(10))
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInterchangeTime stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInterchangeTime] (
		@FromNaPTAN varchar(12),
        @ToNaPTAN varchar(12))
As
    SET NOCOUNT ON

	-- Script to return the Interchange (check-in/out) time for the specified stop naptan and operator
	
	SELECT 
		[FromNaPTAN],
		[ToNaPTAN],
		[FromOperator],
		[ToOperator],
		[InterchangeTimeMinutes]
	FROM InterchangeTime
	
	WHERE	FromNaPTAN = @FromNaPTAN
    and		ToNaPTAN = @ToNaPTAN


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO






--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalCityTransfer stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalCityTransfer]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalCityTransfer 
        (@CityId varchar(20),
         @StopNaPTAN varchar(12))
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalCityTransfer stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalCityTransfer] (
		@CityId varchar(20),
        @StopNaPTAN varchar(12))
As
    SET NOCOUNT ON

	-- Script to return the City Transfer details and time for the specified city id to stop naptan
	
	SELECT 
		 [CityId]
		,[StopNaPTAN]
		,[TransferTimeMinutes]
		,[TransferInformation]
	FROM InternationalCityStop
	
	WHERE	CityId = @CityId
    and		StopNaPTAN = @StopNaPTAN

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


--------------------------------------------------------------------------------------------------------------------------------
-- Create GetInternationalStopDistances stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetInternationalStopDistances]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetInternationalStopDistances 
        
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetInternationalStopDistances stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[GetInternationalStopDistances] 
As
    SET NOCOUNT ON

	-- Script to return the stop to stop distances
	
	SELECT 
		 [OriginStopCode]
		,[DestinationStopCode]
		,[Distance]
	FROM StopDistances
	
	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




--------------------------------------------------------------------------------------------------------------------------------
-- Create IsPermittedInternationalJourney stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[IsPermittedInternationalJourney]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE IsPermittedInternationalJourney 
        
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update IsPermittedInternationalJourney stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [dbo].[IsPermittedInternationalJourney] 
As
    SET NOCOUNT ON

	-- Script to return the permitted international country combinations
	SELECT 
		 [DepartureCountryCode]
		,[ArrivalCountryCode]
	FROM CountryJourney
	
	

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




--------------------------------------------------------------------------------------------------------------------------------
-- Create GetChangeTable stored proc
----------------------------------------------------------------
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetChangeTable]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
BEGIN
    EXEC ('
        CREATE PROCEDURE GetChangeTable 
        AS
        BEGIN 
            SET NOCOUNT ON 
        END
    ')

END
GO

----------------------------------------------------------------
-- Update GetChangeTable stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


ALTER PROCEDURE [dbo].[GetChangeTable] 
AS

	SELECT [Table], Version FROM ChangeNotification
	ORDER BY [Table]

GO


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1582
SET @ScriptDesc = 'Add InternationalData database stored procedures'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO