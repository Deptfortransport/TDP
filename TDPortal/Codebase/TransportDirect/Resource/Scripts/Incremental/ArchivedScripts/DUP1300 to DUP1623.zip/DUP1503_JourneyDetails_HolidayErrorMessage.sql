-- ***********************************************
-- NAME 		: DUP1503_JourneyDetails_HolidayErrorMessage.sql
-- DESCRIPTION 		: Script to update holiday error message for JourneyPlanner Output
-- AUTHOR		: Amit Patel
-- DATE			: 04 Nov 2009
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlannerOutput.Holiday.EnglandWelsh'
, '<ul class="listerdisc"><li>The date the journey was planned on is a Bank Holiday; normal public transport services may not be available.</li></ul>'
, '<ul class="listerdisc"><li>The date the journey was planned on is a Bank Holiday; normal public transport services may not be available.</li></ul>'



GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1503
SET @ScriptDesc = 'Script to update holiday error message for JourneyPlanner Output'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO