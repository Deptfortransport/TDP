-- ***********************************************
-- NAME 		: DUP1487_EBC_Properties_3.sql
-- DESCRIPTION 	: Script to update EBC planner properties
-- AUTHOR		: Mitesh Modi
-- DATE			: 20 Oct 2009
-- ************************************************

USE [PermanentPortal]
GO

IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.IgnoreCongestion' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.IgnoreCongestion', 'True', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'True'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.IgnoreCongestion' and ThemeId = 1
END


IF not exists (select top 1 * from properties where pName = 'EnvironmentalBenefitsCalculator.JourneyParameters.CongestionValue' and ThemeId = 1)
BEGIN
	insert into properties values ('EnvironmentalBenefitsCalculator.JourneyParameters.CongestionValue', '0', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '0'
	where pname = 'EnvironmentalBenefitsCalculator.JourneyParameters.CongestionValue' and ThemeId = 1
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1487
SET @ScriptDesc = 'EBC planner properties update'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO