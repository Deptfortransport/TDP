-- ***********************************************
-- AUTHOR      	: Mark Turner
-- NAME 	: MDS003_HomepageText.sql
-- DESCRIPTION 	: Updates the homepage text.
-- SOURCE 	: TDP Apps Support
-- Version	: $Revision:   1.0  $
-- ************************************************
--$Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/DUP1435_HomepageText_Christmas_warning.sql-arc  $   
--
--   Rev 1.0   Sep 28 2009 12:19:34   nrankin
--Initial revision.
--
--   Rev 1.15   Aug 07 2009 10:10:50   nrankin
--amended
--
--   Rev 1.14   Aug 03 2009 11:32:46   nrankin
--August bank hol message amends (Tuesday 4 August). Remove Scotland BH text - slight amend
--
--   Rev 1.13   Aug 03 2009 11:01:42   nrankin
--August bank hol message amends (Tuesday 4 August). Remove Scotland BH text
--
--   Rev 1.12   Jul 24 2009 16:18:14   nrankin
--August bank hol message amends (Fr1 31st July). Link to seasonal notice board
--
--   Rev 1.11   Jun 24 2009 12:00:44   pscott
--August bank hol message adjustment (Scotland running normally msg)
--
--   Rev 1.10   Jun 01 2009 09:34:36   jfrank
--Removed link from August Bank Holiday message.
--
--   Rev 1.9   May 19 2009 15:19:46   nrankin
--Script to remove link and message for Seasonal Notice Board (26th May). Note : 2nd June text already added - just marked as not displaying!
--
--   Rev 1.8   Apr 29 2009 13:21:34   nrankin
--Seasonal Notice Board - Change wording to remove reference to 4th May
--
--   Rev 1.7   Apr 28 2009 10:15:50   jfrank
--Update alert message for SELMA
--
--   Rev 1.6   Apr 07 2009 13:57:58   nrankin
--Seasonal Notice Board - Change wording to remove reference to Easter on the 14th April
--
--   Rev 1.5   Mar 25 2009 13:54:44   nrankin
--AMENDS -Update to amend Seasonl Notice Board link to be applied on the 6th April.
--
--   Rev 1.4   Mar 25 2009 13:43:32   nrankin
--Update to amend Seasonl Notice Board link to be applied on the 6th April.
--
--   Rev 1.3   Dec 10 2008 15:47:50   rbroddle
--Added Seasonal Noticeboard bit back in as this needs to be in one script - otherwise we lose rows when one or other MDS script is run!!!!
--
--   Rev 1.2   Oct 31 2008 11:02:26   sangle
--Commented out the seasonal section (3) as this functionality has been relocated to MDS015.
--
--   Rev 1.1   Oct 30 2008 15:31:36   mturner
--Manually merged because of failure in automatic merge
--
--   Rev 1.0.1.0   Oct 16 2008 17:24:28   mturner
--Updated to make messages XHTML compliant
--Resolution for 5146: WAI AAA copmpliance work (CCN 474)
--
--   Rev 1.0   Nov 08 2007 12:42:26   mturner
--Initial revision.
--
--   Rev 1.16   Sep 13 2007 13:36:58   nrankin
---- Additional Steps Required : Update C02 RHM text (for DEL9.7) CCN409
--
--Remove the folowing text....
-- " on the 'Details' button and then"
-- " which is just below your list of options "
--
--   Rev 1.15   Jun 13 2007 14:11:16   nrankin
--IR4410
--
--Yet another amend by DfT for RHM Homepage
--
--Change "selected" to "select"
--
--Resolution for 4220: Rail Search by Price
--Resolution for 4410: Add CO2 Icon and Home Page right hand menu text changes
--
--   Rev 1.14   Jun 07 2007 10:20:06   nrankin
--IR 4410 - Additonal changes requested by Kirsty Gibson to right hand menu
--Resolution for 4410: Add CO2 Icon and Home Page right hand menu text changes
--
--   Rev 1.13   Jun 01 2007 09:22:38   nrankin
--IR4410 - CCN391
--
--   Rev 1.12   May 24 2007 16:22:50   nrankin
--IR4410
--
--Right Hand menu text changes (Car Park amends and C02 addition - removal of  "On a Budget")
--Resolution for 4410: Add CO2 Icon and Home Page right hand menu text changes
--
--   Rev 1.12   May 24 2007 14:26:58   NRankin
--Update to car parks text / removal of On A Budget / C02 Emissions addition required for del 9.6
--
--
--   Rev 1.11   Oct 18 2006 14:26:58   jfrank
--Update to car parks text required for del 9.0
--
--   Rev 1.10   Oct 10 2006 14:07:22   jfrank
--Soft content change to homepage for DEL 9.0.
--Resolution for 4219: Find a Car Park - Soft content changes for the homepage
--
--   Rev 1.9   May 02 2006 16:40:14   CRees
--Welsh text added for 8.1, removed references to Inspirational Places, changed Door-to-door reference to Plan a journey.
--
--   Rev 1.8   Apr 26 2006 17:03:52   CRees
--Update to Free Tools section, following Vantive 4252862. This version of the message should be applied to Del 8.1 and above.
--
--   Rev 1.7   Apr 11 2006 13:39:22   CRees
--Updates to Homepage requested by Kirsty Gibson. Removes Welsh from Green RH panel, as no translation available. This is as requested by KG.
--
--   Rev 1.6   Feb 17 2006 15:17:44   scraddock
--corrected typo in sql
--
--   Rev 1.5   Feb 17 2006 15:05:26   scraddock
--Update promotional panel welsh text from TT038 del8
--
--   Rev 1.4   Feb 06 2006 10:34:06   scraddock
--Updated welsh text to translate what's new? - Beth sy'n newydd?
--
--   Rev 1.3   Feb 02 2006 15:10:28   CRees
--Added auto CMS update code, and removed Tips and Tools section - in DUP script instead. DUPLICATE CHECK-IN (Previous check-in branched to 1.2.1.0)
--
--   Rev 1.2   Jan 24 2006 14:54:14   pcross
--Entered translation for "Plan a day trip to two destinations with our new Day trip planner, on the Door-to-door page."
--
--   Rev 1.1   Jan 24 2006 12:36:20   scraddock
--Partial update for additional welsh from doc TT03604.
--
--   Rev 1.0   Jan 17 2006 16:22:34   AViitanen
--Initial revision.

USE PermanentPortal

SET NOEXEC OFF
SET ANSI_WARNINGS ON
SET XACT_ABORT ON
SET IMPLICIT_TRANSACTIONS OFF
SET NOCOUNT ON

BEGIN TRAN
GO

-- ***************************************************
-- *********SEASONAL NOTICEBOARD TEMPLATES ***********
-- ***************************************************
-- WITHOUT LINK: 	'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">TEXT GOES HERE</td></tr>',
-- WITH LINK:		'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/web2/SeasonalNoticeBoard.aspx">TEXT GOES HERE</a></td></tr>',
-- ***************************************************



-- =======================================================
-- Synchronization Script for: [dbo].[HomePageMessage]
-- =======================================================
Print 'Synchronization Script for: [dbo].[HomePageMessage]'

EXEC sp_executesql N'
ALTER TABLE [dbo].[HomePageMessage] NOCHECK CONSTRAINT ALL
ALTER TABLE [dbo].[HomePageMessage] DISABLE TRIGGER ALL'

UPDATE HomePageMessage
SET valueFR = NULL
GO

UPDATE HomePageMessage
SET valueEN = NULL
GO

UPDATE HomePageMessage
SET valueCY = NULL
GO

ALTER TABLE HomePageMessage
    ALTER COLUMN valueFR varchar(1)
GO

ALTER TABLE HomePageMessage
    ALTER COLUMN valueEN varchar(3900)
GO

ALTER TABLE HomePageMessage
    ALTER COLUMN valueCY varchar(3900)
GO

DELETE FROM [dbo].[HomepageMessage]

INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (0, N'Header', 1, 1, NULL, NULL, N'<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>', N'<div class="Column3Header"><div class="txtsevenbbl">Latest...</div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div><div class="Column3Content"><table cellspacing="0" cellpadding="2" width="100%" border="0"><tbody>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (1, N'Special Notice Board', 1, 1, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/web2/SpecialNoticeBoard.aspx">Click here for details on concessionary bus pass schemes.</a></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/web2/SpecialNoticeBoard.aspx">Click here for details on concessionary bus pass schemes.</a></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (2, N'London Alert', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">For details of disruptions following the recent incidents in London please <a href="http://www.tfl.gov.uk/tfl/service_realtime_all.shtml" target="_child">click here.</a></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven">For details of disruptions following the recent incidents in London please <a href="http://www.tfl.gov.uk/tfl/service_realtime_all.shtml" target="_child">click here.</a></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (3, N'Seasonal', 1, 1, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/web2/SeasonalNoticeBoard.aspx">Public transport information for the Christmas and New Year period may not be correct at present. Please re-check nearer the time.</A></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><a href="/web2/SeasonalNoticeBoard.aspx">Public transport information for the Christmas and New Year period may not be correct at present. Please re-check nearer the time.</A></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (4, N'SouthEast', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  London<br>  &bull;  South East of England including the Isle of Wight<br>   &bull;  East Midlands including Derby and Nottingham<br>  &bull;  East Anglia<br> We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  London<br>  &bull;  South East of England including the Isle of Wight<br>   &bull;  East Midlands including Derby and Nottingham<br>  &bull;  East Anglia<br> We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (5, N'MRMD', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br>  &bull;  West Midlands<br>  &bull;  Yorkshire<br>   &bull;  Wales<br>  &bull;  North West of England including Liverpool and Manchester<br> We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the following areas:-<br>  &bull;  South West England including Hampshire<br>  &bull;  West Midlands<br>  &bull;  Yorkshire<br>   &bull;  Wales<br>  &bull;  North West of England including Liverpool and Manchester<br> We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'')
--INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (6, N'EastAnglia', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in East Anglia.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in East Anglia.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'')
--INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (7, N'EastMidlands', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the East Midlands including Derby and Nottingham.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the East Midlands including Derby and Nottingham.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (8, N'AllRegion', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are working to fix a problem affecting local public transport information in our Door to Door planner.  If you require train times, driving directions or domestic flight schedules, please use the appropriate �Find a�� planner</font></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are working to fix a problem affecting local public transport information in our Door to Door planner.  If you require train times, driving directions or domestic flight schedules, please use the appropriate �Find a�� planner</font></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (11, N'NorthEast', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the North East of England and Cumbria / Lake District.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in the North East of England and Cumbria / Lake District.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (13, N'Scotland', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Scotland.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about local public transport services in Scotland.  We are working to fix this problem, which will be resolved shortly.</font></td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (14, N'NCSD', 1, 0, NULL, NULL, N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</td></tr>', N'<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</td></tr>', N'')
INSERT INTO [dbo].[HomePageMessage] ([SeqNo], [Description], [Changed], [Display], [DisplayFrom], [DisplayUntil], [valueEN], [valueCY], [valueFR]) VALUES (16, N'Footer', 1, 1, NULL, NULL, N'</tbody></table></div>', N'</tbody></table></div>', N'')

EXEC sp_executesql N'
ALTER TABLE [dbo].[HomePageMessage] CHECK CONSTRAINT ALL
ALTER TABLE [dbo].[HomePageMessage] ENABLE TRIGGER ALL'


COMMIT
GO

SET NOEXEC OFF
GO




----------------
-- Change Log --
----------------

USE PermanentPortal

Declare @@value decimal(7,3)
Select @@value = left(right('$Revision:   1.0  $',8),7)


IF EXISTS (SELECT * FROM dbo.MDSChangeCatalogue WHERE ScriptNumber = 003 and VersionNumber = @@value)
BEGIN
	UPDATE dbo.MDSChangeCatalogue
	SET
		ChangeDate = getdate(),
		Summary = 'Updated for warning about christmas period'
	WHERE ScriptNumber = 003 AND VersionNumber = @@value
END
ELSE
BEGIN
	INSERT INTO dbo.MDSChangeCatalogue
	(
		ScriptNumber,
		VersionNumber,
		Summary
	)
	VALUES
	(
		003,
		@@value,
		'Updated for August Bank Holidays'
	)
END
