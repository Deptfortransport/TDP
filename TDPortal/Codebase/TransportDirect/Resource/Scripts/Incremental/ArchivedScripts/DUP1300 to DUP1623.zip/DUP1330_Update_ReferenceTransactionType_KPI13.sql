-- ***********************************************
-- NAME 		: DUP1330_Update_ReferenceTransactionType_KPI13.sql
-- DESCRIPTION 		: Update ReferenceTransactionType KPI13
-- AUTHOR		: Neil Rankin
-- DATE			: 01 May 2009
-- ************************************************

USE [Reporting]
GO

INSERT INTO ReferenceTransactionType VALUES ('77', 'KPI13', 'Direct - Scotland', '0', '0', '0', '95', '90', 'Direct', '0', '10)

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1330
SET @ScriptDesc = 'Update ReferenceTransactionType KPI13'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO