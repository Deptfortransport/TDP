-- ************************************************************
-- NAME 	: DUP1307_GetWebServerSessionLockState_Procedure.sql
-- AUTHOR	: Amit Patel
-- DESCRIPTION 	: GetWebServerSessionLockState Procedure
-- ************************************************************
--

USE [ASPState]
GO


--------------------------------------------
--Create procedure if not present
-------------------------------------------
IF NOT EXISTS (SELECT 1 
                 FROM sysobjects 
                WHERE [Name] = N'GetWebServerSessionLockState'
                  AND xtype = 'P') 
	BEGIN
		EXEC ('CREATE PROCEDURE [dbo].[GetWebServerSessionLockState] AS BEGIN SET NOCOUNT ON END')
	END
GO

-------------------------------
--Create New Stored Procedure
-------------------------------
ALTER PROCEDURE GetWebServerSessionLockState ( @SessionID varchar(32) )
AS


-- Test for an entry in ASPStateTempSessions.SessionID Like the Session ID passed in @SessionID
IF EXISTS (SELECT SessionID FROM ASPState..ASPStateTempSessions ats WHERE ats.SessionID = @SessionID )

BEGIN

	SELECT Locked  FROM ASPStateTempSessions  Where SessionId = @SessionID
END
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO




-------------------------------------------------
-- Updates to ChangeCatalogue
-------------------------------------------------

USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1307
SET @ScriptDesc = 'GetWebServerSessionLockState Procedure'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO