-- ***********************************************
-- NAME 		: DUP1334_TransportDirect_Content_5_Home_RightHandPanel.sql
-- DESCRIPTION 	: Script to add the Right Hand Information panel text
-- AUTHOR		: John Frank
-- DATE			: 28 May 2009 15:00:00
-- ************************************************

-- **** IMPORTANT ****
-- ENSURE THE CHANGE CATALOGUE @ScriptNumber VALUE IS UPDATED WHEN COPYING TO INCREMENTAL UPDATES FOLDER


USE [Content]
GO


DECLARE @GroupId int,
	@ThemeId int
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'home')



-- Right hand items 1 and 2
EXEC AddtblContent
1, @GroupId, 'TDAdditionalInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home'
, '<div class="Column3Header"> 
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/VisitPlannerInput.aspx">Visiting two places?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Mobile Phone Image" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/MobileSmallIcon.gif" border="0" /></td>  
<td class="txtseven">Plan your day out this summer using our <a href="/Web2/JourneyPlanning/VisitPlannerInput.aspx">Day trip planner</a> and use our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">mobile page</a> to find travel updates on the move.</td></tr></tbody></table></div>
<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/FindCarParkInput.aspx">Parking stress?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top" align="center" width="26"><img title="" alt="Car Park Icon" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_carpark.gif" border="0" /></td>  
<td class="txtseven">Use our <a href="/Web2/JourneyPlanning/FindCarParkInput.aspx">find a car park</a> function to find car parks close to your destination before you travel.  Or check to see if there is a <a href="/Web2/JourneyPlanning/FindAStationInput.aspx">nearby station</a> and go by public transport instead.</a></td></tr></tbody></table></div>'
, 
'<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/VisitPlannerInput.aspx">Visiting two places?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top"><img title="" alt="Mobile Phone Image" src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/MobileSmallIcon.gif" border="0" /></td>  
<td class="txtseven">Plan your day out this summer using our <a href="/Web2/JourneyPlanning/VisitPlannerInput.aspx">Day trip planner</a> and use our <a href="/Web2/TDOnTheMove/TDOnTheMove.aspx">mobile page</a> to find travel updates on the move.</td></tr></tbody></table></div>
<div class="Column3Header">  
<div class="txtsevenbbl"><a class="Column3HeaderLink" href="/Web2/JourneyPlanning/FindCarParkInput.aspx">Parking stress?</a></div><!-- Don''t remove spaces -->&nbsp;&nbsp;</div>  
<div class="Column3Content">  
<table id="Table2" cellspacing="0" cellpadding="2" width="100%" border="0">  <tbody>  
<tr>  
<td class="txtseven" valign="top" align="center" width="26"><img title="" alt="Car Park Icon" src="/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/trspt_carpark.gif" border="0" /></td>  
<td class="txtseven">Use our <a href="/Web2/JourneyPlanning/FindCarParkInput.aspx">find a car park</a> function to find car parks close to your destination before you travel.  Or check to see if there is a <a href="/Web2/JourneyPlanning/FindAStationInput.aspx">nearby station</a> and go by public transport instead.</a></td></tr></tbody></table></div>'



-- Right hand item 3
EXEC AddtblContent
1, @GroupId, 'TDNewInformationHtmlPlaceholderDefinition', '/Channels/TransportDirect/Home',
'<div class="Column3Header">
<div class="txtsevenbbl">Sending an invitation?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">It''s easy to create links that open Transport Direct with your own choice of destination, date and time.  For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&id=invitation&d=258785,665494&dn=Steph''s%20sales%20meeting%20at%20150%20St%20Vincent%20St,%20Glasgow&da=a&dt=28082008&t=0945">Directions to my meeting</a><br /><br />See our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page (opens new window)</a> for more details.</td></tr></tbody></table></div>'
,
'<div class="Column3Header">
<div class="txtsevenbbl">Sending an invitation?</div>  <!-- Don''t remove spaces -->&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="Column3Content">
<table id="Table3" border="0" cellpadding="2" cellspacing="0" width="100%"><tbody>
<tr>  <td class="txtseven" align="center" valign="top" width="26"><img src="/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/en/WebsiteLinkB70_small.gif" alt="Add Transport Direct to your website for free" title="Add Transport Direct to your website for free" /></td> <td class="txtseven">It''s easy to create links that open Transport Direct with your own choice of destination, date and time.  For example:<br /><a href="/Web2/journeyplanning/jplandingpage.aspx?&id=invitation&d=258785,665494&dn=Steph''s%20sales%20meeting%20at%20150%20St%20Vincent%20St,%20Glasgow&da=a&dt=28082008&t=0945">Directions to my meeting</a><br /><br />See our <a target="_child" href="http://www.dft.gov.uk/transportdirect/tools/intelligentlinks">Intelligent Links page (opens new window)</a> for more details.</td></tr></tbody></table></div>'


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1334
SET @ScriptDesc = 'Script to add Homepage Right hand text for June'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO