-- ***********************************************
-- NAME 		: DUP1550_CycleJourneyDetail_GPXControl_FAQ_Link.sql
-- DESCRIPTION 		: Script to update Cycle Journey GPX FAQ link
-- AUTHOR		: Amit Patel
-- DATE			: 13 Jan 2010
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.CycleJourneyGPXControl.labelDownloadDescription.Text', 
'Click on the link below to save a GPX file <a href="/Web2/Help/HelpCycle.aspx#A16.12">(What is GPX?)</a> of your route for use on a GPS device', 
'Cliciwch ar y ddolen isod i gadw ffeil GPX <a href="/Web2/Help/HelpCycle.aspx#A16.12">(Beth yw GPX)</a> o''ch llwybr i''w defnyddio ar ddyfais GPS'

Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1550
SET @ScriptDesc = 'Script to update Cycle Journey GPX FAQ link'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO