-- ***********************************************
-- NAME 			: DUP1364_ExposedServices_CarJourneyPlanner_Content.sql
-- DESCRIPTION 		: Script to setup the Car Journey Planner Enhanced Exposed Service
-- AUTHOR			: Mitesh Modi
-- DATE				: 16 Jul 2009
-- ***********************************************

USE [Content]
GO

-- Add car journey detail strings to be used by the JourneyPlannerService (car exposed web service)
DECLARE @GroupId int, @ThemeId int, @ControlName varchar (50)

SET @ThemeId = 1
SET @GroupId = (SELECT GroupId FROM tblGroup WHERE [Name] = 'General')
SET @ControlName = 'JourneyPlannerService'


-- These text strings are the same as from the default langStrings
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ThroughRoute', 'Follow the road on to', 'Dilynwch y ffordd i'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitOne', 'Take first available exit off roundabout on to', 'Cymerwch yr allanfa gyntaf sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitTwo', 'Take second available exit off roundabout on to', 'Cymerwch yr ail allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitThree', 'Take third available exit off roundabout on to', 'Cymerwch y drydedd allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitFour', 'Take fourth available exit off roundabout on to', 'Cymerwch y bedwaredd allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitFive', 'Take fifth available exit off roundabout on to', 'Cymerwch y bumed allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitSix', 'Take sixth available exit off roundabout on to', 'Cymerwch y chweched allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitSeven', 'Take seventh available exit off roundabout on to', 'Cymerwch y seithfed allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitEight', 'Take eighth available exit off roundabout on to', 'Cymerwch yr wythfed allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitNine', 'Take ninth available exit off roundabout on to', 'Cymerwch y nawfed allanfa sydd ar gael oddi ar y gylchfan i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RoundaboutExitTen', 'Take tenth available exit off roundabout on to', 'Cymerwch y ddegfed allanfa sydd ar gael oddi ar y gylchfan i'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Continue', 'Go on to', 'Ewch ymlaen i''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ContinueMiniRoundabout', 'At mini-roundabout continue on to', 'Wrth y gylchfan mini parhewch i''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.LeftMiniRoundabout', 'Turn left at mini-roundabout on to', 'Trowch i''r chwith wrth y gylchfan mini i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.LeftMiniRoundabout2', 'Turn left at mini-roundabout', 'Trowch i''r chwith wrth y gylchfan mini'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RightMiniRoundabout', 'Turn right at mini-roundabout on to', 'Trowch i''r dde wrth y gylchfan mini i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.RightMiniRoundabout2', 'Turn right at mini-roundabout', 'Trowch i''r dde wrth y gylchfan mini'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.UTurnMiniRoundabout', 'U-turn at mini-roundabout on to', 'Tro pedol wrth y gylchfan mini i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.UTurnMiniRoundabout2', 'U-turn at mini-roundabout', 'Tro pedol wrth y gylchfan mini'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ImmediatelyTurnLeft', 'Immediately take first available left on to', 'Cymerwch y chwith cyntaf sydd ar gael ar unwaith i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ImmediatelyTurnRight', 'Immediately take first available right on to', 'Cymerwch y troad cyntaf i''r dde ar unwaith i'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftOne', 'Take first available left on to', 'Cymerwch y troad cyntaf i''r chwith sydd ar gael i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftThree', 'Take third available left on to', 'Cymerwch y trydydd troad i''r chwith sydd ar gael i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftTwo', 'Take second available left on to', 'Cymerwch yr ail droad i''r chwith sydd ar gael i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftFour', 'Take fourth available left on to', 'Cymerwch y pedwerydd troad i''r chwith sydd ar gael i'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightOne', 'Take first available right on to', 'Cymerwch y troad cyntaf sydd ar gael i''r dde i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightTwo', 'Take second available right on to', 'Cymerwch yr ail droad sydd ar gael i''r dde i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightThree', 'Take third available right on to', 'Cymerwch y trydydd troad sydd ar gael i''r dde i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightFour', 'Take fourth available right on to', 'Cymerwch y pedwerydd troad sydd ar gael i''r dde i'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftInDistance', 'Turn left on to', 'Trowch i''r chwith i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightInDistance', 'Turn right on to', 'Trowch i''r dde ar'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.BearLeft', 'Bear left on to', 'Dilyn y chwith i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.BearRight', 'Bear right on to', 'Dilyn y dde i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ImmediatelyBearLeft', 'Immediately bear left on to', 'Dilyn y chwith ar unwaith i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ImmediatelyBearRight', 'Immediately bear right on to', 'Dilyn y dde ar unwaith i'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ArriveAt', 'Arrive at ', 'Cyrraedd am '
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Leave', 'Starting from', 'Dechrau o'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.NotApplicable', '-', '-'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.LocalRoad', 'local road', 'ffordd leol'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.AtJunctionLeave', 'At junction', 'Wrth gyffordd'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.LeaveMotorway', 'leave motorway', 'gadewch y draffordd'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.UntilJunction', 'until junction', 'hyd at gyffordd'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.OnTo', 'on to', 'i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Towards', 'towards', 'tuag at'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ContinueFor', ', continue for', ', parhewch am'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Miles', 'miles', 'milltir'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftToJoin', 'Turn left to join', 'Trowch i''r chwith i ymuno a''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightToJoin', 'Turn right to join', 'Trowch i''r dde i ymuno a''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.AtJunctionJoin', 'at junction', 'wrth gyffordd'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.BearLeftToJoin', 'Bear left to join', 'Dilyn y chwith i ymuno a''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.BearRightToJoin', 'Bear right to join', 'Dilyn y dde i ymuno a''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Join', 'Join', 'Ymunwch a''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.For', ', for', ', am'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Follow', 'Follow', 'Dilyn'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.To', 'to', 'i'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Enter', 'Enter', 'Ewch i mewn i''r'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.CongestionCharge', 'congestion charge zone', 'gylchfa taliadau tagfeydd'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Charge', 'Charge: ', 'T�l: '
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.CertainTimes', 'applies to your journey at certain times.', 'Mae''r t�l hwn yn berthnasol ar adegau arbennig'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.CertainTimesNoCharge', 'A charge applies at certain times.', 'Mae t�l yn daladwy ar adegau penodol.'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Board', 'Board', 'Byrddio'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.DepartingAt', 'departing at:', 'yn ymadael am:'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Toll', 'Toll:', 'Toll:'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.HighTraffic', 'High traffic levels likely on this road - see map', 'Lefelau trafnidiaeth uchel sy''n debygol ar y ffordd hon - gweler y map'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.PlanStop', 'Plan to stop for a 15 minute break every 2 hours on a long journey. This time is not included in the above itinerary.', 'Cynlluniwch i aros am egwyl 15 munud bob 2 awr ar siwrnai hir.  Nid yw''r amser hwn yn cael ei gynnwys yn y daith uchod.'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.WaitForFerry', 'Arrive at ferry terminal and wait to board', 'Cyrhaeddwch derfynell y fferi ac arhoswch am gael mynd ar ei bwrdd'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.FerryCrossing', 'Ferry crossing', 'Croesiad fferi'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ViaArriveAt', 'Arrive at', 'Cyrraedd am'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.LeaveFerry', 'Leave ferry', 'Gadael y fferi'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Exit', 'Exit', 'Allanfa'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.End', 'End', 'Diwedd'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.UnspecifedWaitForFerry', 'Arrive at ferry terminal and wait for ferry (no timetable available)', 'Cyrhaeddwch derfynell y fferi ac arhoswch am y fferi (dim amserlen ar gael)'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.IntermediateFerry', 'Arrive at intermediate ferry terminal', 'Cyrraedd terfynell rhyngol y fferi'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.WaitAtTerminal', 'Arrive at ferry terminal and wait', 'Cyrraedd terfynell y fferi ac aros'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.NotAvailable', 'Not available', 'Ddim ar gael'

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.StraightOn', 'straight on', 'yn syth ymlaen'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.AtMiniRoundabout', 'At mini-roundabout ', 'Wrth y gylchfan fach '
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ImmediatelyTurnLeftOnto', 'Immediately turn left on to', 'Trowch i''r chwith ar unwaith i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ImmediatelyTurnRightOnto', 'Immediately turn right on to', 'Trowch i''r dde ar unwaith i'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.WhereRoadSplits', 'where the road splits', 'lle mae''r ffordd yn rhannu '

EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'ParkAndRide.Suffix', ' park and ride', ' parcio a theithio'
EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'ParkAndRide.CarkPark.Suffix', '  car park', '  maes parcio'


-- THE FOLLOWING ARE NOT REQUIRED AS THEY ARE FOR THE CYCLE JOURNEY FORMATTER
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.LocalPath', 'unnamed path ', 'llwybr heb ei enwi'
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Street', 'street ', 'stryd '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.Path', 'path ', 'llwybr '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.ChargeAdultAndCycle', 'Charge for adult and cycle:', 'T�l am oedolyn a beic:'
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.UTurn', 'Make a U-Turn on', 'Gwnewch dro pedol ar'
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.AtMiniRoundabout2', 'at mini-roundabout ', 'wrth y gylchfan fach '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftOne2', 'Take first available left ', 'Cymerwch y troad cyntaf i''r chwith sydd ar gael '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftTwo2', 'Take second available left ', 'Cymerwch yr ail droad i''r chwith sydd ar gael '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftThree2', 'Take third available left ', 'Cymerwch y trydydd troad i''r chwith sydd ar gael '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnLeftFour2', 'Take fourth available left ', 'Cymerwch y pedwerydd troad i''r chwith sydd ar gael '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightOne2', 'Take first available right ', 'Cymerwch y troad cyntaf sydd ar gael i''r dde '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightTwo2', 'Take second available right ', 'Cymerwch yr ail droad sydd ar gael i''r dde '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightThree2', 'Take third available right ', 'Cymerwch y trydydd troad sydd ar gael i''r dde '
--EXEC AddtblContent @ThemeId, @GroupId, @ControlName, 'RouteText.TurnRightFour2', 'Take fourth available right ', 'Cymerwch y pedwerydd troad sydd ar gael i''r dde '



GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1364
SET @ScriptDesc = 'Exposed Services - Car Journey Planner content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

