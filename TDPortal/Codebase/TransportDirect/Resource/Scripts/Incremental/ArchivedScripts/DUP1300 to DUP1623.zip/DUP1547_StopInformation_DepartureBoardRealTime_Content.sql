-- ***********************************************
-- NAME 		: DUP1547_StopInformation_DepartureBoardRealTime_Content.sql
-- DESCRIPTION 		: Script to add Stop Information page departure board control content
-- AUTHOR		: Amit Patel
-- DATE			: 07 Jan 2010
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.RealTimeText.OnTime.Text', 'On time', 'Yn brydlon'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.RealTimeText.Cancelled.Text', 'Cancelled', 'Dilewyd'


Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1547
SET @ScriptDesc = 'Script to add Stop Information page departure board control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO