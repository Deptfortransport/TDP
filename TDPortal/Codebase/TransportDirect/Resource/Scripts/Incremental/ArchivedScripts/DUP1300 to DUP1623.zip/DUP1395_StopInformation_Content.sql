-- ***********************************************
-- NAME 		: DUP1395_StopInformation_Content.sql
-- DESCRIPTION 		: Script to add Stop Information page and control content
-- AUTHOR		: Amit Patel
-- DATE			: 20 Aug 2009
-- ************************************************

USE [Content]
GO

--------------------------------------------------------------------------------------------------------------------------------
-- External link image
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'ExternalLinks.OpensNewWindowImage', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(opens in new window)" title="(opens in new window)" />', '<img src="/Web2/App_Themes/TransportDirect/images/gifs/newwindow.gif" alt="(yn agor ffenestr newydd)" title="(yn agor ffenestr newydd)" />'


--------------------------------------------------------------------------------------------------------------------------------
-- Stop Information Page Content
--------------------------------------------------------------------------------------------------------------------------------

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelErroMessage.unknownStopCode.Text', 'Error - unknown stop code used', 'cy Error - unknown stop code used'


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelLocationInformationTitle', 'Stop information', 'cy Stop information'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelLocationInformationTitle.coach', 'Coach stop information', 'cy Coach stop information'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelLocationInformationTitle.rail', 'Station information', 'cy Station information'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelLocationInformationTitle.air', 'Airport information', 'cy Airport information'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelLocationInformationTitle.ferry', 'Ferry terminal information', 'cy Ferry terminal information'

--------------------------------------------------------------------------------------------------------------------------------
-- Stop Information Taxi Control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationTaxiControl.labelSummaryTitle.Text', 'Taxis', 'cy Taxis'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationTaxiControl.imageTaxi.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/en/Taxi.gif', '/Web2/App_Themes/TransportDirect/images/gifs/JourneyPlanning/cy/Taxi.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationTaxiControl.imageTaxi.AlternateText', 'Taxis', 'Cy Taxis'



--------------------------------------------------------------------------------------------------------------------------------
-- Stop Information Facility Control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.ferryFacilities.Text', 'Ferry terminal facilities', 'cy Ferry terminal facilities'

EXEC AddtblContent
1, 1, 'langStrings', 'LocationInformation.facilities.Text', 'Stop facilities', 'cy Stop facilities'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.labelStationFacilitiesText.Text', 'To find out more information about the facilities at {0} please select the links below', 'cy To find out more information about the facilities at {0} please select the links below'

--------------------------------------------------------------------------------------------------------------------------------
-- Stop Information Map Control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'StopInformation.ExpandButton.Text', 'Expand', 'cy Expand'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationMapTitle.Text', 'Maps', 'cy Maps'


--------------------------------------------------------------------------------------------------------------------------------
-- Stop Information Departure Board Control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.departureResults.EmptyDataText', 'No departure results found', 'cy No departure results found'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.arrivalResults.EmptyDataText', 'No departure results found', 'cy No departure results found'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.serviceButton.Arrivals.Text', 'Arrivals', 'cy Arrivals'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.serviceButton.Departures.Text', 'Departures', 'cy Departures'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.labelDepartureBoardTitle.Text', 'Next departures', 'cy Next departures'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardControl.mobileServiceLink.Text', 'Send result to your mobile', 'cy Send result to your mobile'


--------------------------------------------------------------------------------------------------------------------------------
-- Stop Information Departure Board Result Control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.labelServiceNumberHeading.bus.Text', 'Bus', 'cy Bus'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.labelServiceNumberHeading.train.Text', 'Train', 'cy Train'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.labelServiceDetailHeading.arrival.Text', 'From', 'cy From'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.labelServiceDetailHeading.departure.Text', 'To', 'cy To'


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.labelServiceNumberHeading.arrival.Text', 'Arr.', 'cy Arr.'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.labelServiceNumberHeading.departure.Text', 'Dep.', 'cy Dep.'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.labelRealTimeInfoHeading.Text', 'Exp.', 'cy Exp.'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationDepartureBoardResultControl.RealTimeText.NoReport.Text', 'No Report', 'cy No Report'



--------------------------------------------------------------------------------------------------------------------------------
-- Stop Information Plan a Journey Control
--------------------------------------------------------------------------------------------------------------------------------
EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.imageDoorToDoor.ImageUrl', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomeJourneyPlannerBlueBackground.gif', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/HomeJourneyPlannerBlueBackground.gif'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.imageDoorToDoor.AlternateText', 'Plan a door-to-door journey', 'Cynlluniwch siwrnai'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.buttonSubmit.AlternateText', 'Click to plan your door-to-door journey', 'Cliciwch i gynllunio eich siwrnai o ddrws-i-ddrws'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.buttonSubmit.Text', 'Go', 'Mwy'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.checkboxCarRoute.Text', 'Car route', 'Llwybr car'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.checkboxPublicTransport.Text', 'Public transport', 'Trafnidiaeth gyhoeddus'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.labelFrom.Text', 'From', 'O'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.labelTo.Text', 'To', 'I'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.labelLeave.Text', 'On', 'cy On'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.leaveAfterOption.Text', 'Depart', 'cy Depart'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.arriveBeforeOption.Text', 'Arrive', 'cy Arrive'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.labelTravel.Text', 'Travel', 'cy Travel'

EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.labelShow.Text', 'Show', 'Dangos'


EXEC AddtblContent
1, 1, 'langStrings', 'StopInformationPlanAJourneyControl.labelPlanAJourneyTitle.Text', 'Plan a journey', 'Cynlluniwch siwrnai'





Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1395
SET @ScriptDesc = 'Stop Information page and control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO