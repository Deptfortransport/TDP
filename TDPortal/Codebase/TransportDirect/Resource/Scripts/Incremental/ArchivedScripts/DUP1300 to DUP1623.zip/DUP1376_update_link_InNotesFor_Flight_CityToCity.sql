-- ***********************************************
-- NAME 			: DUP1376_update_link_InNotesFor_Flight_CityToCity.sql
-- DESCRIPTION 			: Script to update the link in notes on journey results
-- DESCRIPTION 			: for flight or city to city
-- AUTHOR			: Neil Rankin
-- DATE				: 10 August 2009
-- ***********************************************

USE [TransientPortal]
GO


--------------------------------------------------------------------------------------------------------------------------------
-- ExternalLinks
--------------------------------------------------------------------------------------------------------------------------------

IF EXISTS (SELECT TOP 1 * 
             FROM ExternalLinks 
            WHERE URL = 'http://www.equalityhumanrights.com/en/yourrights/rightsindifferentsettings/transport/Pages/Stepbystepguide.aspx')
BEGIN
    UPDATE ExternalLinks 
       SET URL = 'http://www.equalityhumanrights.com/your-rights/rights-in-different-settings/air-travel/'
     WHERE [Id] = 'Accessibility.Rights'

    UPDATE ExternalLinks 
       SET TestURL = 'http://www.equalityhumanrights.com/your-rights/rights-in-different-settings/air-travel/'
     WHERE [Id] = 'Accessibility.Rights'
END


GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1376
SET @ScriptDesc = 'Script to update the link in notes on journey results'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO