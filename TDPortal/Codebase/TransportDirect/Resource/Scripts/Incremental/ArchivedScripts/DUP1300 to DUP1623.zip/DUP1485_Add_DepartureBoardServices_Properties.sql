-- *************************************************************************************
-- NAME 		: DUP1485_Add_DepartureBoardServices_Properties.sql
-- DESCRIPTION  	: Add DepartureBoardService properties for web
-- AUTHOR		: Amit Patel
-- *************************************************************************************

-- ****************************** WARNING **********************************************
-- THE SCRIPT NEEDS MockListenerPath, SchemaLocation, SocketPort, SocketServer PROPERTY  
-- VALUE NEEDS CHANGING WHEN IT GOES ON BUILD
-- *************************************************************************************

USE [PermanentPortal]
GO


IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.DefaultDuration' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.DefaultDuration', '240', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '240'
	where pname = 'DepartureBoardService.RTTIManager.DefaultDuration' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.FirstServiceDuration' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.FirstServiceDuration', '240', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '240'
	where pname = 'DepartureBoardService.RTTIManager.FirstServiceDuration' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.FirstServiceHour' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.FirstServiceHour', '4', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '4'
	where pname = 'DepartureBoardService.RTTIManager.FirstServiceHour' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.LastServiceDuartion' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.LastServiceDuartion', '240', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '240'
	where pname = 'DepartureBoardService.RTTIManager.LastServiceDuartion' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.LastServiceHour' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.LastServiceHour', '22', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '22'
	where pname = 'DepartureBoardService.RTTIManager.LastServiceHour' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.MaxDurationAllowed' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.MaxDurationAllowed', '720', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '720'
	where pname = 'DepartureBoardService.RTTIManager.MaxDurationAllowed' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.MilliSecondWaitTime' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.MilliSecondWaitTime', '1000', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '1000'
	where pname = 'DepartureBoardService.RTTIManager.MilliSecondWaitTime' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.MockListenerPath' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.MockListenerPath', 'C:\TDPortal\CodeBase\TransportDirect\DepartureBoardService\Test\MockListener\SocketListner.exe', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'C:\TDPortal\CodeBase\TransportDirect\DepartureBoardService\Test\MockListener\SocketListner.exe'
	where pname = 'DepartureBoardService.RTTIManager.MockListenerPath' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.RequestTemplate.StationRequestByCRS' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.RequestTemplate.StationRequestByCRS', '<?xml version="1.0" ?>   <Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="------" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">  <StationReq>  <ByCRS crs="---" />   </StationReq>  </Eport>', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '<?xml version="1.0" ?>   <Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="------" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">  <StationReq>  <ByCRS crs="---" />   </StationReq>  </Eport>'
	where pname = 'DepartureBoardService.RTTIManager.RequestTemplate.StationRequestByCRS' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.RequestTemplate.TrainRequestByRID' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.RequestTemplate.TrainRequestByRID', '<?xml version="1.0"?>  <Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="-----" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">  <TrainReq>  <ByRID rid="-----" />   </TrainReq>  </Eport>', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '<?xml version="1.0"?>  <Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="-----" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">  <TrainReq>  <ByRID rid="-----" />   </TrainReq>  </Eport>'
	where pname = 'DepartureBoardService.RTTIManager.RequestTemplate.TrainRequestByRID' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.RequestTemplate.TripRequestByCRS' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.RequestTemplate.TripRequestByCRS', '<?xml version="1.0" ?>   <Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="-----" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">  <TripReq>  <ByCRS main="---" interest="-----" time="-----" secondary="---" dur="120"/>   </TripReq>  </Eport>', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '<?xml version="1.0" ?>   <Eport xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" msgId="0" ts="-----" version="1.0" xmlns="http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd">  <TripReq>  <ByCRS main="---" interest="-----" time="-----" secondary="---" dur="120"/>   </TripReq>  </Eport>'
	where pname = 'DepartureBoardService.RTTIManager.RequestTemplate.TripRequestByCRS' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.RetryCount' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.RetryCount', '3', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '3'
	where pname = 'DepartureBoardService.RTTIManager.RetryCount' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.SchemaLocation' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.SchemaLocation', 'D:\Inetpub\wwwroot\enhancedexposedservices\Schema\rttiEPTSchema.xsd', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'D:\Inetpub\wwwroot\enhancedexposedservices\Schema\rttiEPTSchema.xsd'
	where pname = 'DepartureBoardService.RTTIManager.SchemaLocation' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.SchemaNamespace' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.SchemaNamespace', 'http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = 'http://www.thales-is.com/rtti/EnquriyPorts/v6/rttiEPTSchema.xsd'
	where pname = 'DepartureBoardService.RTTIManager.SchemaNamespace' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.SocketPort' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.SocketPort', '9125', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '9125'
	where pname = 'DepartureBoardService.RTTIManager.SocketPort' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

IF not exists (select top 1 * from properties where pName = 'DepartureBoardService.RTTIManager.SocketServer' and ThemeId = 1 and AID='Web' and GID='UserPortal')
BEGIN
	insert into properties values ('DepartureBoardService.RTTIManager.SocketServer', '212.188.138.216', 'Web', 'UserPortal', 0, 1)
END
ELSE
BEGIN
	update properties 
	set pvalue = '212.188.138.216'
	where pname = 'DepartureBoardService.RTTIManager.SocketServer' and ThemeId = 1  and AID='Web' and GID='UserPortal'
END

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1485
SET @ScriptDesc = 'Add DepartureBoardService properties for web'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
