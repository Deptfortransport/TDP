-- ***********************************************
-- NAME 			: DUP1577_InternationalPlanner_ReportStaging_Tables.sql
-- DESCRIPTION 		: Script to add ReportStaging tables for International planner
-- AUTHOR			: Amit Patel
-- DATE				: 25 Jan 2010
-- ***********************************************

USE [ReportStagingDB]
GO

----------------------------------------------------------------
-- Create InternationalPlannerRequestEvent table
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[InternationalPlannerRequestEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[InternationalPlannerRequestEvent]
GO

CREATE TABLE [dbo].[InternationalPlannerRequestEvent] (
	[Id] [bigint] IDENTITY (1, 1) NOT NULL ,
	[InternationalPlannerRequestId] [varchar] (50) NULL,
	[SessionId] [varchar] (50) NULL ,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL 
) ON [PRIMARY]
GO

----------------------------------------------------------------
-- Create InternationalPlannerResultEvent table
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[InternationalPlannerResultEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[InternationalPlannerResultEvent]
GO

CREATE TABLE [dbo].[InternationalPlannerResultEvent] (
	[Id] [bigint] IDENTITY (1, 1) NOT NULL ,
	[InternationalPlannerRequestId] [varchar] (50) NULL,
	[ResponseCategory] [varchar] (50) NULL,
	[SessionId] [varchar] (50) NULL ,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL 
) ON [PRIMARY]
GO

----------------------------------------------------------------
-- Create InternationalPlannerEvent table
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[InternationalPlannerEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[InternationalPlannerEvent]
GO

CREATE TABLE [dbo].[InternationalPlannerEvent] (
	[Id] [bigint] IDENTITY (1, 1) NOT NULL ,
	[InternationalPlannerType] [varchar] (50) NULL,
	[SessionId] [varchar] (50) NULL ,
	[UserLoggedOn] [bit] NULL,
	[TimeLogged] [datetime] NULL 
) ON [PRIMARY]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1577
SET @ScriptDesc = 'Script to add ReportStaging tables for International planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
