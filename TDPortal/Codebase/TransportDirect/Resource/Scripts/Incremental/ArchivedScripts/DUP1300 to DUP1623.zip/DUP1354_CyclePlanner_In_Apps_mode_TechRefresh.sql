-- ***********************************************
-- NAME 			: DUP1354_CyclePlanner_In_Apps_mode_TechRefresh.sql
-- DESCRIPTION 			: Script to enable Cycle planner to be put in to Apps Mode
-- AUTHOR			: John Frank
-- DATE				: 13 Jul 2009
-- ***********************************************

USE [PermanentPortal]
GO

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.MinUserTypeLogging'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.MinUserTypeLogging',1,'TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.LogAllRequests'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.LogAllRequests','true','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.LogAllResponses'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.LogAllResponses','true','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.LogCyclePlannerFailures'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.LogCyclePlannerFailures','true','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.LogNoJourneyResponses'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.LogNoJourneyResponses','true','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.WebService.URL'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.WebService.URL','http://JP/cycleplannerservice/service.asmx','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERREQUEST.Assembly'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Assembly','td.userportal.cycleplannercontrol','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERREQUEST.Name'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Name','CyclePlannerRequestEvent','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERREQUEST.Publishers'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Publishers','TDPDB','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERREQUEST.Trace'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Trace','On','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERRESULT.Assembly'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERRESULT.Assembly','td.userportal.cycleplannercontrol','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERRESULT.Name'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERRESULT.Name','CyclePlannerResultEvent','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERRESULT.Publishers'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERRESULT.Publishers','TDPDB','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERRESULT.Trace'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERRESULT.Trace','On','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.JourneyRequest.IncludeToids'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.JourneyRequest.IncludeToids','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeToids'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeToids','true','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.EastingNorthingSeperator'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.EastingNorthingSeperator',',','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeGeometry'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeGeometry','true','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.IncludeText'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.IncludeText','true','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.JourneyResultSetting.PointSeperator'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.JourneyResultSetting.PointSeperator',' ','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERREQUEST.Publishers'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERREQUEST.Publishers','Queue1','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Logging.Event.Custom.CYCLEPLANNERRESULT.Publishers'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Logging.Event.Custom.CYCLEPLANNERRESULT.Publishers','Queue1','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'GradientProfiler.WebService.URL'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('GradientProfiler.WebService.URL','http://JP/gradientprofilerservice/service.asmx','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'GradientProfiler.WebService.TimeoutMillisecs'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('GradientProfiler.WebService.TimeoutMillisecs','30000','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.NumberOfPreferences'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.NumberOfPreferences','15','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference0'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference0','850','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference1'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference1','11000','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference10'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference10','','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference11'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference11','','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference12'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference12','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference13'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference13','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference14'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference14','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference2'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference2','Congestion','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference3'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference3','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference4'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference4','Bicycle','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference5'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference5','19','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference6'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference6','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference7'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference7','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference8'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference8','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.TDUserPreference.Preference9'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.TDUserPreference.Preference9','false','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.WebService.TimeoutMillisecs'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.WebService.TimeoutMillisecs','30000','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Location'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Location','D:\TransportDirect\Services\CycleHost\td.cp.CyclePenaltyFunctions.v1.dll','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.PenaltyFunction.Prefix'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.PenaltyFunction.Prefix','TransportDirect.JourneyPlanning.CyclePenaltyFunctions','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.PlannerControl.TimeoutMillisecs'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.PlannerControl.TimeoutMillisecs','60000','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CyclePlanner.InteractiveMapping.Map.CycleJourney.Xslt'

INSERT INTO [PermanentPortal].[dbo].[properties] (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CyclePlanner.InteractiveMapping.Map.CycleJourney.Xslt','/TDRemotingHost/Xslt/PolylinesTransform.xslt','TDRemotingHost','TDRemotingHost',0,1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CoordinateConvertor.WebService.URL'

INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CoordinateConvertor.WebService.URL', 'http://localhost/TDPWebServices/CoordinateConvertorService/CoordinateConvertor.asmx', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'CoordinateConvertor.WebService.TimeoutMillisecs'

INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('CoordinateConvertor.WebService.TimeoutMillisecs', '60000', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Coordinate.Convertor.InitialiseString'

INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Coordinate.Convertor.InitialiseString', 'GIQ.6.0', 'TDRemotingHost', 'TDRemotingHost', 0, 1)

DELETE FROM [PermanentPortal].[dbo].[properties]
WHERE AID = 'TDRemotingHost'
AND GID = 'TDRemotingHost'
AND pname = 'Coordinate.Convertor.DataPath'

INSERT INTO properties (pName, pValue, AID, GID, PartnerId, ThemeId)
VALUES ('Coordinate.Convertor.DataPath', 'D:\Inetpub\wwwroot\TDPWebServices\CoordinateConvertorService\bin\', 'TDRemotingHost', 'TDRemotingHost', 0, 1)
GO

IF NOT EXISTS (SELECT * FROM [PermanentPortal].[dbo].[properties] 
               WHERE AID = 'TDRemotingHost' AND GID = 'TDRemotingHost'
               AND pvalue like '%CYCLEPLANNERREQUEST CYCLEPLANNERRESULT%')
BEGIN
  UPDATE [PermanentPortal].[dbo].[properties]
  SET pValue = pValue + ' CYCLEPLANNERREQUEST CYCLEPLANNERRESULT'
  WHERE pName = 'Logging.Event.Custom'
  AND AID = 'TDRemotingHost'
END
GO

UPDATE [PermanentPortal].[dbo].[properties]
SET pValue = 'D:\Inetpub\wwwroot\TDPWebServices\CoordinateConvertorService\bin\'
WHERE pName = 'Coordinate.Convertor.DataPath'
AND AID = 'Web'
AND GID = 'UserPortal'
GO
	
-- Run this to put Cycle Planner in Apps Mode
--UPdate [PermanentPortal].[dbo].[properties]
--SET pvalue = '/TDRemotingHost/Xslt/PolylinesTransform.xslt'
--Where pname = 'CyclePlanner.InteractiveMapping.Map.CycleJourney.Xslt'

-- Run this to put Cycle Planner in Direct Connect Mode
--UPdate [PermanentPortal].[dbo].[properties]
--SET pvalue = '/Web2/Xslt/PolylinesTransform.xslt'
--Where pname = 'CyclePlanner.InteractiveMapping.Map.CycleJourney.Xslt'


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1354
SET @ScriptDesc = 'Cycle Planner - Properties for Apps Mode on Tech Refresh'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

