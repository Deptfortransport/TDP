-- ***********************************************
-- NAME 		: DUP1437_SocialBookmarking_Content.sql
-- DESCRIPTION 		: Script to add Social Bookmark control content
-- AUTHOR		: Amit Patel
-- DATE			: 29 Sep 2009
-- ************************************************

USE [Content]
GO


EXEC AddtblContent
1, 1, 'langStrings', 'SocialBookmarkLinkControl.clientLink.LinkText', 'Favourites', 'cy Favourites'

EXEC AddtblContent
1, 1, 'langStrings', 'SocialBookmarkLinkControl.linkTitle.Text', 'Bookmark this and share this journey', 'cy Bookmark this and share this journey'

EXEC AddtblContent
1, 1, 'langStrings', 'SocialBookmarkLinkControl.imageEmail.Url', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/email.gif', '/Web2/App_Themes/TransportDirect/images/gifs/SoftContent/email.gif'


EXEC AddtblContent
1, 1, 'langStrings', 'SocialBookmarkLinkControl.lableEmail.Text', 'Email', 'cy Email'


Go

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1437
SET @ScriptDesc = 'Script to add Social Bookmark control content'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO