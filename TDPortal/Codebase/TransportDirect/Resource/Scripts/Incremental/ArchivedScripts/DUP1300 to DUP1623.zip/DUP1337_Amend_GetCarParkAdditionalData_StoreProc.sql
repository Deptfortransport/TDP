-- **********************************************************************
-- NAME 	: DUP1336_Amend_GetCarParkAdditionalData_StoreProc.sql
-- AUTHOR       : nrankin
-- DATE CREATED : 10/06/2009
-- REVISION     : Initial
-- DESCRIPTION  : Amend GetCarParkAdditionalData StoreProc
-- **********************************************************************
--
--
--
USE CarParks
GO
 
IF NOT EXISTS(SELECT 1
                FROM INFORMATION_SCHEMA.ROUTINES
               WHERE ROUTINE_NAME = 'GetCarParkAdditionalData'
                 AND ROUTINE_TYPE = N'PROCEDURE')
BEGIN
    EXEC ('CREATE PROCEDURE [dbo].[GetCarParkAdditionalData] AS BEGIN SELECT 1 END')
 
END
GO 
 
GO 
-- GetCarParkAdditionalData stored procedure

ALTER PROCEDURE dbo.GetCarParkAdditionalData
(
    @CarParkingId varchar (50)
)
AS
BEGIN

    SELECT cpOpeningTimes.OpensAt, 
           cpOpeningTimes.ClosesAt, 
           IsNull(cpCarParkingSpace.totalSpaces,0) NumberOfSpaces, 
           IsNull(cpAdditional.MaximumWidth,0) MaximumWidth, 
           IsNull(cpAdditional.MaximumHeight,0) MaximumHeight, 
           cpAdditional.PMSPA, 
           cpAdditional.AdvancedReservationsAvailable,
           IsNull(cpCarParkingType.Description,'') Description, 
           IsNull(disabledSpaces.totalDisabledSpaces,0) totalDisabledSpaces
      FROM dbo.CarParkingAdditionalData AS cpAdditional 
     INNER JOIN dbo.DataVersion
             ON cpAdditional .VersionId = DataVersion.[Id]
      LEFT JOIN CarParkingOpeningTimes AS cpOpeningTimes 
             ON cpOpeningTimes.CarParkRef = cpAdditional.CarParkingId
      LEFT JOIN (SELECT CarParkRef,Sum(IsNull(NumberOfSpaces,0)) as totalSpaces
                   FROM CarParkingCarParkSpace
                   WHERE VersionId = (SELECT MAX([Id])
                                        FROM DataVersion 
                                       WHERE Active = 1)
                  GROUP BY CarParkRef
                 ) cpCarParkingSpace 
             ON cpCarParkingSpace.CarParkRef = cpAdditional.CarParkingId
      LEFT JOIN CarParkingCarParkType AS cpCarParkingType 
             ON cpCarParkingType.CarParkRef = cpAdditional.CarParkingId
      LEFT JOIN (SELECT CarParkRef,
                        SUM(IsNull(NumberOfSpaces,0)) as totalDisabledSpaces
                   FROM dbo.CarParkingCarParkSpace
                  WHERE CarParkingCarParkSpace.Description = 'Disabled' 
                        OR CarParkingCarParkSpace.Description = 'Shopmobility'
                  GROUP BY CarParkRef) disabledSpaces
             ON disabledSpaces.CarParkRef = cpAdditional.CarParkingId
      WHERE cpAdditional.CarParkingId= @CarParkingId 
        AND DataVersion.Active = 1

END


GO 


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1336
SET @ScriptDesc = 'Amend GetCarParkAdditionalData StoreProc'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
