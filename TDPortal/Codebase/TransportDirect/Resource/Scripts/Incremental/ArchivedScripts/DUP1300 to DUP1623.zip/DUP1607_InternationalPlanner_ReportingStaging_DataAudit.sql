-- ***********************************************
-- NAME 		: DUP1607_InternationalPlanner_ReportingStaging_DataAudit.sql
-- DESCRIPTION 	: Added report staging data audit entries for International Planner
-- AUTHOR		: Rich Broddle
-- DATE			: 05 March 2010
-- ************************************************

USE [ReportStagingDB]
GO

-- Add new data types for reporting

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataType] 
WHERE [RSDTName] = 'TransferInternationalPlannerEvents') 
	INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataType] ([RSDTID],[RSDTName])
		 VALUES (33,'TransferInternationalPlannerEvents')
GO
		 
IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataType] 
WHERE [RSDTName] = 'TransferInternationalPlannerJourneyEvents') 
INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataType] ([RSDTID],[RSDTName])
     VALUES (34,'TransferInternationalPlannerJourneyEvents')
GO

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataAudit]
WHERE [RSDTID] = 33) 
	BEGIN
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (33,1,'20100305 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (33,2,'20100304 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (33,3,'20100306 01:00:00')
	END
GO

IF NOT EXISTS(SELECT * FROM [ReportStagingDB].[dbo].[ReportStagingDataAudit] WHERE [RSDTID] = 34) 
	BEGIN
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (34,1,'20100305 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (34,2,'20100304 01:00:00')
		INSERT INTO [ReportStagingDB].[dbo].[ReportStagingDataAudit]
				   ([RSDTID],[RSDATID],[Event])
			 VALUES
				   (34,3,'20100306 01:00:00')
	END			   
GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1607
SET @ScriptDesc = 'Added report staging data audit entries for International Planner'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO