-- ***********************************************
-- NAME 		: DUP1603_OperatorLink_Euroline.sql
-- DESCRIPTION 	: Script to add/update the Euroline operator to the OperatorLinks table,
--				: for display in International journeys
-- AUTHOR		: Mitesh Modi
-- DATE			: 02 Mar 2010
-- ************************************************

USE [TransientPortal]
GO

DECLARE @OperatorCode varchar(10)
DECLARE @OperatorName varchar(20)
DECLARE @OperatorLink varchar(50)
DECLARE @OperatorLinkId varchar (20)
DECLARE @ModeId varchar(10)

SET @OperatorCode = 'EL'
SET @OperatorName = 'Eurolines'
SET @OperatorLink = 'http://www.eurolines.co.uk'
SET @OperatorLinkId = 'OperatorLink.EL' 
SET @ModeId = 'Coach'

-- Update Service Operators table
IF not exists (select top 1 * from [TransientPortal].[dbo].[ServiceOperators] where [OperatorCode] = @OperatorCode)
	BEGIN
	INSERT INTO [TransientPortal].[dbo].[ServiceOperators]
			   ([OperatorCode]
			   ,[OperatorName])
		 VALUES
			   (@OperatorCode
			   ,@OperatorName)
	END
ELSE
	BEGIN
	UPDATE [TransientPortal].[dbo].[ServiceOperators]
	   SET [OperatorName] = @OperatorName
	 WHERE [OperatorCode] = @OperatorCode
	END


-- Update Service Operations
IF not exists (select top 1 * from [TransientPortal].[dbo].[ServiceOperations] where [OperatorCode] = @OperatorCode)
	BEGIN
	INSERT INTO [TransientPortal].[dbo].[ServiceOperations]
			   ([OperatorCode]
			   ,[ModeId])
		 VALUES
			   (@OperatorCode
			   ,@ModeId)
	END


-- Update External Links
EXEC AddExternalLink @OperatorLinkId, @OperatorLink, @OperatorLink, 'Operator website'


-- Update Operator Links
IF not exists (select top 1 * from [TransientPortal].[dbo].[OperatorLinks] where [OperatorCode] = @OperatorCode)
	BEGIN
	INSERT INTO [TransientPortal].[dbo].[OperatorLinks]
			   ([OperatorCode]
			   ,[ModeId]
			   ,[OperatorLinkId])
		 VALUES
			   (@OperatorCode
			   ,@ModeId
			   ,@OperatorLinkId)
	END
ELSE
	BEGIN
	UPDATE [TransientPortal].[dbo].[OperatorLinks]
	   SET [OperatorLinkId] = @OperatorLinkId
	 WHERE [OperatorCode] = @OperatorCode
	 and   [ModeId]	= @ModeId
	END


GO
----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1603
SET @ScriptDesc = 'Eurolines operator link updated'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO