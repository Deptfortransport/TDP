-- ***********************************************
-- NAME 			: DUP1390_ExposedServices_TestPartner_Setup.sql
-- DESCRIPTION 		: Script to add the test exposed service partner to have access to all the exposed services
-- AUTHOR			: Mitesh Modi
-- DATE				: 16 Jul 2009
-- ***********************************************

USE [PermanentPortal]
GO

-- *********** IMPORTANT **************
-- THIS SCRIPT SHOULD ONLY BE RUN ON SITEST AND BBP 
-- Although, can be run on ACP if we want to give the test EES account access
-- ************************************

DECLARE @PartnerId INT
DECLARE @PartnerName VARCHAR(100)

SET @PartnerName = 'EnhancedExposedWebServiceTest'

-- Check for partner before adding
IF EXISTS (SELECT * FROM [dbo].[Partner] WHERE PartnerName = @PartnerName)
BEGIN

    -- Get the PartnerId
    SET @PartnerId = (SELECT TOP 1 PartnerId FROM [dbo].[Partner] WHERE PartnerName = @PartnerName)

    -- Delete all previous allowed services for this partner
    DELETE FROM [dbo].[PartnerAllowedServices]
    WHERE PartnerId = @PartnerId

    -- Insert partner to allowed service for each exposed service type
    INSERT INTO [dbo].[PartnerAllowedServices] (PartnerId,EESTID)
    SELECT @PartnerId, EESTID FROM [dbo].[EnhancedExposedServicesType] ORDER BY EESTID


END 

GO

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1390
SET @ScriptDesc = 'Add Test Exposed Services partner to all allowed services'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO

