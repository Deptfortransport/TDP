-- ***********************************************
-- NAME 		: DUP1443_EBC_Reporting_StoredProcedures_EBCCalculationEvent.sql
-- DESCRIPTION 		: Script to update the stored procedure to delete EBCCalculationEvents data
-- AUTHOR		: Mitesh Modi
-- DATE			: 5 Oct 2009
-- ************************************************

USE [Reporting]
GO


----------------------------------------------------------------
-- Update DeleteReportData stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



ALTER   PROCEDURE DeleteReportData
(
	@reportdate DATETIME
)
AS

DELETE FROM  GazetteerEvents 			WHERE CONVERT( DATETIME, CONVERT( CHAR(10), GEDATE,   110 ) ) <= @reportdate
DELETE FROM  JourneyPlanLocationEvents  WHERE CONVERT( DATETIME, CONVERT( CHAR(10), JPLEDate, 110 ) ) <= @reportdate
DELETE FROM  JourneyPlanModeEvents  	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), JPMEDate, 110 ) ) <= @reportdate
DELETE FROM  JourneyProcessingEvents  	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), JPEDate,  110 ) ) <= @reportdate
DELETE FROM  JourneyWebRequestEvents  	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), JWREDate, 110 ) ) <= @reportdate
DELETE FROM  LoginEvents  				WHERE CONVERT( DATETIME, CONVERT( CHAR(10), LEDate,   110 ) ) <= @reportdate
DELETE FROM  MapEvents 					WHERE CONVERT( DATETIME, CONVERT( CHAR(10), MEDate,   110 ) ) <= @reportdate
DELETE FROM  OperationalEvents 			WHERE CONVERT( DATETIME, CONVERT( CHAR(10), OETimeLogged, 110 ) ) <= @reportdate
DELETE FROM  PageEntryEvents  			WHERE CONVERT( DATETIME, CONVERT( CHAR(10), PEEDate,  110 ) ) <= @reportdate
DELETE FROM  ReferenceTransactionEvents WHERE CONVERT( DATETIME, CONVERT( CHAR(10), RTEDate,  110 ) ) <= @reportdate
DELETE FROM  RepeatVisitorEvents 		WHERE CONVERT( DATETIME, CONVERT( CHAR(10), RVEDate,  110 ) ) <= @reportdate
DELETE FROM  RetailerHandoffEvents  	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), RHEDate,  110 ) ) <= @reportdate
DELETE FROM  RoadPlanEvents  			WHERE CONVERT( DATETIME, CONVERT( CHAR(10), RPEDate,  110 ) ) <= @reportdate
DELETE FROM  CyclePlannerEvents  		WHERE CONVERT( DATETIME, CONVERT( CHAR(10), CPEDate,  110 ) ) <= @reportdate
DELETE FROM  GradientProfileEvents  	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), GPEDate,  110 ) ) <= @reportdate
DELETE FROM  UserPreferenceSaveEvents  	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), UPSEDate, 110 ) ) <= @reportdate
DELETE FROM  WorkloadEvents  		WHERE CONVERT( DATETIME, CONVERT( CHAR(10), WEDate,   110 ) ) <= @reportdate
DELETE FROM  DataGatewayEvents  	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), DGETimeLogged,   110 ) ) <= @reportdate
DELETE FROM  SessionEvents  		WHERE CONVERT( DATETIME, CONVERT( CHAR(10), SEDate,   110 ) ) <= @reportdate
DELETE FROM  InternalRequestEvents 	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), IREDate, 110 ) ) <= @reportdate
DELETE FROM  UserFeedbackEvents 	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), UfeDate, 110 ) ) <= @reportdate
DELETE FROM  EBCCalculationEvents 	WHERE CONVERT( DATETIME, CONVERT( CHAR(10), EBCDate, 110 ) ) <= @reportdate

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update TransferComplete stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



ALTER   PROCEDURE TransferComplete
AS

CREATE INDEX [IX_GazetteerEvents] ON [dbo].[GazetteerEvents]([GEDate], [GEHour], [GEHourQuarter], [GEGTID]) ON [PRIMARY]
CREATE INDEX [IX_JourneyPlanLocationEvents] ON [dbo].[JourneyPlanLocationEvents]([JPLEDate], [JPLEHour], [JPLEHourQuarter], [JPLEJPTID], [JPLEJAATID], [JPLEJPRTID]) ON [PRIMARY]
CREATE INDEX [IX_JourneyPlanModeEvents] ON [dbo].[JourneyPlanModeEvents]([JPMEDate], [JPMEHour], [JPMEHourQuarter], [JPMEJMTID]) ON [PRIMARY]
CREATE INDEX [IX_JourneyProcessingEvents] ON [dbo].[JourneyProcessingEvents]([JPEDate], [JPEHour], [JPEHourQuarter]) ON [PRIMARY]
CREATE INDEX [IX_JourneyWebRequestEvents] ON [dbo].[JourneyWebRequestEvents]([JWREDate], [JWREHour], [JWREHourQuarter], [JWREJRTID]) ON [PRIMARY]
CREATE INDEX [IX_LoginEvents] ON [dbo].[LoginEvents]([LEDate], [LEHour], [LEHourQuarter]) ON [PRIMARY]
CREATE INDEX [IX_MapEvents] ON [dbo].[MapEvents]([MEDate], [MEHour], [MEHourQuarter], [MEMDTID], [MEMCTID]) ON [PRIMARY]
CREATE INDEX [IX_PageEntryEvents] ON [dbo].[PageEntryEvents]([PEEDate], [PEEHour], [PEEHourQuarter], [PEEPETID]) ON [PRIMARY]
CREATE INDEX [IX_RepeatVisitorEvents] ON [dbo].[RepeatVisitorEvents]([RVEDate], [RVEHour], [RVEHourQuarter], [RVERVTID]) ON [PRIMARY]
CREATE INDEX [IX_RetailerHandoffEvents] ON [dbo].[RetailerHandoffEvents]([RHEDate], [RHEHour], [RHEHourQuarter], [RHERHTID]) ON [PRIMARY]
CREATE INDEX [IX_RoadPlanEvents] ON [dbo].[RoadPlanEvents]([RPEDate], [RPEHour], [RPEHourQuarter]) ON [PRIMARY]
CREATE INDEX [IX_CyclePlannerEvents] ON [dbo].[CyclePlannerEvents]([CPEDate], [CPEHour], [CPEHourQuarter]) ON [PRIMARY]
CREATE INDEX [IX_GradientProfileEvents] ON [dbo].[GradientProfileEvents]([GPEDate], [GPEHour], [GPEHourQuarter], [GPEGPDTID]) ON [PRIMARY]
CREATE INDEX [IX_UserPreferenceSaveEvents] ON [dbo].[UserPreferenceSaveEvents]([UPSEDate], [UPSEHour], [UPSEHourQuarter], [UPSEUPTID]) ON [PRIMARY]
CREATE INDEX [IX_WorkloadEvents] ON [dbo].[WorkloadEvents]([WEDate], [WEHour], [WEMinute]) ON [PRIMARY]
CREATE INDEX [IX_InternalRequestEvents] ON [dbo].[InternalRequestEvents]([IREDate], [IREHour], [IREHourQuarter], [IREIRTID]) ON [PRIMARY]
CREATE INDEX [IX_UserFeedbackEvents] ON [dbo].[UserFeedbackEvents]([UfeDate], [UfeHour], [UfeHourQuarter],[UfeTypeId]) ON [PRIMARY]
CREATE INDEX [IX_EBCCalculationEvents] ON [dbo].[EBCCalculationEvents]([EBCDate], [EBCHour], [EBCHourQuarter]) ON [PRIMARY]

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


----------------------------------------------------------------
-- Update TransferInitialise stored proc
----------------------------------------------------------------
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



ALTER   PROCEDURE TransferInitialise
AS

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_GazetteerEvents')
	DROP INDEX [dbo].[GazetteerEvents].[IX_GazetteerEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_JourneyPlanLocationEvents')
	DROP INDEX [dbo].[JourneyPlanLocationEvents].[IX_JourneyPlanLocationEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_JourneyPlanModeEvents')
	DROP INDEX [dbo].[JourneyPlanModeEvents].[IX_JourneyPlanModeEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_JourneyProcessingEvents')
	DROP INDEX [dbo].[JourneyProcessingEvents].[IX_JourneyProcessingEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_JourneyWebRequestEvents')
	DROP INDEX [dbo].[JourneyWebRequestEvents].[IX_JourneyWebRequestEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_LoginEvents')
	DROP INDEX [dbo].[LoginEvents].[IX_LoginEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_MapEvents')
	DROP INDEX [dbo].[MapEvents].[IX_MapEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_PageEntryEvents')
	DROP INDEX [dbo].[PageEntryEvents].[IX_PageEntryEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_RepeatVisitorEvents')
	DROP INDEX [dbo].[RepeatVisitorEvents].[IX_RepeatVisitorEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_RetailerHandoffEvents')
	DROP INDEX [dbo].[RetailerHandoffEvents].[IX_RetailerHandoffEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_RoadPlanEvents')
	DROP INDEX [dbo].[RoadPlanEvents].[IX_RoadPlanEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_CyclePlannerEvents')
	DROP INDEX [dbo].[CyclePlannerEvents].[IX_CyclePlannerEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_GradientProfileEvents')
	DROP INDEX [dbo].[GradientProfileEvents].[IX_GradientProfileEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_UserPreferenceSaveEvents')
	DROP INDEX [dbo].[UserPreferenceSaveEvents].[IX_UserPreferenceSaveEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_WorkloadEvents')
	DROP INDEX [dbo].[WorkloadEvents].[IX_WorkloadEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_InternalRequestEvents')
	DROP INDEX [dbo].[InternalRequestEvents].[IX_InternalRequestEvents]

IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_UserFeedbackEvents')
	DROP INDEX [dbo].[UserFeedbackEvents].[IX_UserFeedbackEvents]
	
IF EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_EBCCalculationEvents')
	DROP INDEX [dbo].[EBCCalculationEvents].[IX_EBCCalculationEvents]


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1443
SET @ScriptDesc = 'Update Reporting stored procedures for EBCCalculationEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO