-- ***********************************************
-- NAME 		: DUP1601_Update_Page_Titles.sql
-- DESCRIPTION 		: Update content for Search Engine Optimisation
-- AUTHOR		: Phil Scott
-- DATE			:22/02/2010
-- ************************************************

USE [Content]
GO




-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyPlannerInput.AppendPageTitle',
'Route Planner | Public Transport &amp; Car Journey Planner | ',
'Route Planner | Public Transport &amp; Car Journey Planner | '
Go 

-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'Homepage.PageTitle',
'Route Planner, Online Journey Planner &amp; Travel News | Transport Direct',
'Route Planner, Online Journey Planner &amp; Travel News | Transport Direct'
GO

EXEC AddtblContent
1, 1, 'langStrings', 'HomeDefault.MetaContent.PageDescription',
'Transport Direct is Britain''s online journey planner for both car and public transport. Get directions, travel news, car parking info, bus routes, train times and much more.',
'Transport Direct is Britain''s online journey planner for both car and public transport. Get directions, travel news, car parking info, bus routes, train times and much more.'

-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrainInput.AppendPageTitle',
'Train Times and Timetables | Rail Travel Planner | ',
'Train Times and Timetables | Rail Travel Planner | '
GO

-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindBusInput.AppendPageTitle',
'Bus Times and Routes | Bus Route Planner | ',
'Bus Times and Routes | Bus Route Planner | '
GO


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarInput.AppendPageTitle',
'Car Route Finder &amp; Travel Planner | Car Directions from ',
'Car Route Finder &amp; Travel Planner | Car Directions from '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'CyclePlanner.AppendPageTitle',
'Cycle Route Planner | Bike Routes | Cycle Routes | ',
'Cycle Route Planner | Bike Routes | Cycle Routes | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindCoachInput.AppendPageTitle',
'Coach Times &amp; Services | Coach Travel Information | ',
'Coach Times &amp; Services | Coach Travel Information | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNews.AppendPageTitle',
'Traffic News &amp; Reports | Live Travel News Updates | ',
'Traffic News &amp; Reports | Live Travel News Updates | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindFlightInput.AppendPageTitle',
'Flight Times | Flight Arrivals &amp; Departures | ',
'Flight Times | Flight Arrivals &amp; Departures | '



-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindTrunkInput.AppendPageTitle',
'City to City Journey Planner | Rail,  Plane, Coach &amp; Car Travel | ',
'City to City Journey Planner | Rail,  Plane, Coach &amp; Car Travel | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'VisitPlanner.AppendPageTitle',
'Day Trip journey planner | Travel Planner | ',
'Day Trip journey planner | Travel Planner | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'VisitPlanner', 'VisitPlanner.AppendPageTitle',
'Day Trip journey planner | Travel Planner | ',
'Day Trip journey planner | Travel Planner | '




-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'ParkAndRideInput.AppendPageTitle',
'Park &amp; Ride | Car Parking Locator | ',
'Park &amp; Ride | Car Parking Locator | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindCarParkInput.AppendPageTitle',
'Car Park Finder | Car Parking  Information | ',
'Car Park Finder | Car Parking  Information | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindMapInput.AppendPageTitle',
'Street Maps &amp; Road Maps | Online GB Map Finder | ',
'Street Maps &amp; Road Maps | Online GB Map Finder | '



-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'FindAStationInput.AppendPageTitle',
'Train Station Finder &amp; Airport Locator | ',
'Train Station Finder &amp; Airport Locator | '




-- *******************************************************************************************************

EXEC AddtblContent
1, 2, '_Web2_maps_networkmaps', 'Title',
'Transport Network Maps | Rail, Bus, Coach, Tube | ',
'Transport Network Maps | Rail, Bus, Coach, Tube | '



-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'TrafficMaps.AppendPageTitle',
'Traffic Maps | Traffic Level Data For Great Britain''s Roads | ',
'Traffic Maps | Traffic Level Data For Great Britain''s Roads | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'HomeTravelInfo.PageTitle',
'Live Travel News | Arrivals &amp; Departures | Transport Direct',
'Live Travel News | Arrivals &amp; Departures | Transport Direct'


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'TravelNews.AppendPageTitle',	
'Live Travel News | Arrivals &amp; Departures | ',
'TLive Travel News | Arrivals &amp; Departures | '

-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'DepartureBoards.AppendPageTitle',	
'Transport News | Rail Updates &amp; Live Travel News| ',
'Transport News | Rail Updates &amp; Live Travel News| '

-- *******************************************************************************************************




EXEC AddtblContent
1, 1, 'langStrings', 'HomeTipsTools.PageTitle',
'Travel Planning Tools, Tips &amp; Resources | Transport Direct',
'Travel Planning Tools, Tips &amp; Resources | Transport Direct'




EXEC AddtblContent
1, 1, 'tools', 'BusinessLinks.AppendPageTitle',
'Feature Transport Direct''s Journey Planners on Your Own Website',
'Feature Transport Direct''s Journey Planners on Your Own Website'



-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'ToolbarDownload.AppendPageTitle',
'Transport Information Toolbar | Travel Planning from ',
'Transport Information Toolbar | Travel Planning from '


-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'TDOnTheMove.AppendPageTitle',
'Mobile Travel News | Bus &amp; Train Times | ',
'Mobile Travel News | Bus &amp; Train Times | '



-- *******************************************************************************************************

EXEC AddtblContent
1, 1, 'langStrings', 'JourneyEmissionsCompare.AppendPageTitle',
'Carbon Calculator | Compare Transport CO2 Emissions | ',
'Carbon Calculator | Compare Transport CO2 Emissions | '


-- *******************************************************************************************************

EXEC AddtblContent
1, 2, '_Web2_help_newhelp', 'Title',
'Frequently Asked Questions | Transport Direct',
'Frequently Asked Questions | Transport Direct'

EXEC AddtblContent
1, 2, '_Web2_help_newhelp', 'Page',
'/Web2/staticdefault.aspx',
'/Web2/staticdefault.aspx'




EXEC AddtblContent
1, 1, 'langStrings', 'ParkAndRideSchemes.AppendPageTitle',
'Park &amp; Ride Locator | Car Parking | ',
'Park &amp; Ride Locator | Car Parking | '

----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1601
SET @ScriptDesc = 'Update content for Search Engine Optimisation'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO