-- ***********************************************
-- AUTHOR      	: Mark Turner
-- NAME 	: MDS003_HomepageText.sql
-- DESCRIPTION 	: Updates the homepage text.
-- SOURCE 	: TDP Apps Support
-- Version	: $Revision:   1.0  $
-- ************************************************
--$Log:   P:/TDPortal/archives/DotNet2.0Codebase/TransportDirect/Resource/DEL8_2/Incremental/DUP1544_HomepageText.sql-arc  $   
--
--   Rev 1.0   Dec 17 2009 09:47:50   nrankin
--Initial revision.


USE [PermanentPortal]
GO


IF EXISTS (SELECT TOP 1 * FROM HomePageMessage WHERE Description LIKE 'NCSD')
BEGIN
	UPDATE HomePageMessage 
    SET valueEN = '<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</td></tr>'
    WHERE Description LIKE 'NCSD'
END

GO

IF EXISTS (SELECT TOP 1 * FROM HomePageMessage WHERE Description LIKE 'NCSD')
BEGIN
	UPDATE HomePageMessage 
    SET valueCY = '<tr><td class="VertAlignTop"><img id="imageAttention" src="/Web2/App_Themes/{Theme_Name}/images/gifs/exclamation.gif" alt="Attention" border="0" width="26" height="21" /></td><td class="txtseven"><font color="red">We are currently unable to provide information about long-distance coach journeys (using either the Door-to-Door planner or ''Find a Coach''). We are working to fix this problem, which will be resolved shortly.</td></tr>'
    WHERE Description LIKE 'NCSD'
END

GO

IF EXISTS (SELECT TOP 1 * FROM HomePageMessage WHERE Description LIKE 'NCSD')
BEGIN
	UPDATE HomePageMessage 
    SET CHANGED = '1'
    WHERE Description LIKE 'NCSD'
END

GO
    
    

----------------
-- Change Log --
----------------

USE PermanentPortal

Declare @@value decimal(7,3)
Select @@value = left(right('$Revision:   1.0  $',8),7)


IF EXISTS (SELECT * FROM dbo.MDSChangeCatalogue WHERE ScriptNumber = 003 and VersionNumber = @@value)
BEGIN
	UPDATE dbo.MDSChangeCatalogue
	SET
		ChangeDate = getdate(),
		Summary = 'Add Exclaimation Mark GIF to NCSD'
	WHERE ScriptNumber = 003 AND VersionNumber = @@value
END
ELSE
BEGIN
	INSERT INTO dbo.MDSChangeCatalogue
	(
		ScriptNumber,
		VersionNumber,
		Summary
	)
	VALUES
	(
		003,
		@@value,
		'Add Exclaimation Mark GIF to NCSD'
	)
END
