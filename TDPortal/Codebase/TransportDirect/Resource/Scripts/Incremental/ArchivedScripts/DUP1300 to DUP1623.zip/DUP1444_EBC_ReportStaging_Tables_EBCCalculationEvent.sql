-- ***********************************************
-- NAME 			: DUP1444_EBC_ReportStaging_Tables_EBCCalculationEvent.sql
-- DESCRIPTION 			: Script to add table for EBCCalculationEvents
-- AUTHOR			: Mark Turner
-- DATE				: 29 Sep 2009
-- ***********************************************

USE [ReportStagingDB]
GO

----------------------------------------------------------------
-- Create EBCCalculationEvent table
----------------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EBCCalculationEvent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[EBCCalculationEvent]
GO

CREATE TABLE [dbo].[EBCCalculationEvent] (
	[Id] [bigint] IDENTITY (1, 1) NOT NULL ,
	[Submitted] [datetime] NULL,
	[SessionId] [varchar] (50) NULL ,
	[TimeLogged] [datetime] NULL ,
	[Success] [bit] NULL
) ON [PRIMARY]
GO


----------------------------------------------------------------
-- Update change catalogue
----------------------------------------------------------------
USE [PermanentPortal]
GO

DECLARE @ScriptNumber INT
DECLARE @ScriptDesc VARCHAR(200)

SET @ScriptNumber = 1444
SET @ScriptDesc = 'Add ReportStaging tables for EBCCalculationEvents'

IF EXISTS (SELECT * FROM [dbo].[ChangeCatalogue] WHERE ScriptNumber = @ScriptNumber)
  BEGIN
    UPDATE [dbo].[ChangeCatalogue]
    SET ChangeDate = getDate(), Summary = @ScriptDesc
    WHERE ScriptNumber = @ScriptNumber
  END
ELSE
  BEGIN
    INSERT INTO [dbo].[ChangeCatalogue] (ScriptNumber, ChangeDate, Summary)
    VALUES (@ScriptNumber, getDate(), @ScriptDesc)
  END
GO
